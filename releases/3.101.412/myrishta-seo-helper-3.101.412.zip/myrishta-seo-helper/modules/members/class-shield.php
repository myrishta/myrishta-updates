<?php
/**
 * Security Shield: failed-login lockout, failed-login log, new-device sign-in emails, password rules,
 * extra hardening switches, "sign everyone out", and a live security checklist with a score.
 * Everything runs inside this plugin (no extra plugin).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Shield {

	const OPT   = 'mrsh_shield';
	const LOG   = 'mrsh_shield_log';
	const LOCKS = 'mrsh_shield_locks';
	const DEV   = 'mrsh_sh_dev';

	public static function o( $k = null ) {
		$d = array(
			'bf_on' => 1, 'bf_tries' => 10, 'bf_window' => 15, 'bf_lock' => 5, 'allow' => '',
			'alert_new' => 1, 'pw_min' => 6, 'pw_weak' => 1,
			'no_file_edit' => 1, 'hsts' => 0, 'no_app_pw' => 0,
		);
		$s = get_option( self::OPT, array() );
		$s = is_array( $s ) ? array_merge( $d, $s ) : $d;
		return null === $k ? $s : ( $s[ $k ] ?? null );
	}

	/** Smallest password length members may use (set in Security Shield; 6 by default). */
	public static function pw_min() {
		return max( 6, (int) self::o( 'pw_min' ) );
	}

	public static function init() {
		if ( ! get_option( 'mrsh_shield_relaxed' ) ) { // 3.101.411: easier rules for everyday members, once
			$o = get_option( self::OPT, array() );
			$o = is_array( $o ) ? $o : array();
			$o['pw_min'] = 6; $o['bf_tries'] = 10; $o['bf_lock'] = 5;
			update_option( self::OPT, $o, false );
			update_option( 'mrsh_shield_relaxed', 1, false );
		}
		add_filter( 'authenticate', array( __CLASS__, 'gate' ), 99, 3 );
		add_action( 'wp_login_failed', array( __CLASS__, 'failed' ), 10, 1 );
		add_action( 'wp_login', array( __CLASS__, 'ok' ), 5, 2 );
		add_action( 'set_auth_cookie', array( __CLASS__, 'device' ), 10, 6 );
		add_filter( 'user_profile_update_errors', array( __CLASS__, 'pw_profile' ), 10, 3 );
		add_action( 'validate_password_reset', array( __CLASS__, 'pw_reset' ), 10, 2 );
		add_filter( 'map_meta_cap', array( __CLASS__, 'no_edit' ), 10, 2 );
		add_action( 'send_headers', array( __CLASS__, 'hsts' ) );
		add_filter( 'wp_is_application_passwords_available', array( __CLASS__, 'app_pw' ) );
		if ( is_admin() ) {
			add_action( 'admin_menu', array( __CLASS__, 'menu' ), 25 );
			foreach ( array( 'save', 'unlock', 'block', 'signout', 'clearlog', 'reset' ) as $a ) {
				add_action( 'admin_post_mrsh_shield_' . $a, array( __CLASS__, $a ) );
			}
		}
	}

	/* ---------------------------------------------------------------- helpers */
	public static function ip() {
		$v = '';
		if ( ! empty( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) {
			$v = trim( sanitize_text_field( wp_unslash( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) );
		} elseif ( ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
			$v = trim( sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) );
		}
		return filter_var( $v, FILTER_VALIDATE_IP ) ? $v : '';
	}

	private static function allowed( $ip ) {
		if ( '' === $ip ) {
			return true;
		}
		foreach ( preg_split( '/\s+/', (string) self::o( 'allow' ), -1, PREG_SPLIT_NO_EMPTY ) as $a ) {
			if ( $a === $ip ) {
				return true;
			}
		}
		return false;
	}

	private static function k( $ip, $login = '' ) {
		$login = strtolower( trim( (string) $login ) );
		return 'mrsh_bf_' . md5( '' === $login ? $ip : $ip . '|' . $login );
	}

	private static function locks() {
		$l = get_option( self::LOCKS, array() );
		$l = is_array( $l ) ? $l : array();
		$n = array();
		foreach ( $l as $ip => $until ) {
			if ( (int) $until > time() ) {
				$n[ $ip ] = (int) $until;
			}
		}
		return $n;
	}

	private static function log( $ip, $user, $ev ) {
		$l   = (array) get_option( self::LOG, array() );
		$l[] = array( time(), $ip, mb_substr( (string) $user, 0, 60 ), $ev );
		update_option( self::LOG, array_slice( $l, -150 ), false );
	}

	/* ---------------------------------------------------------------- failed-login lockout */
	public static function gate( $user, $login = '', $pass = '' ) {
		if ( ! self::o( 'bf_on' ) ) {
			return $user;
		}
		$ip = self::ip();
		if ( self::allowed( $ip ) ) {
			return $user;
		}
		// Many Pakistani mobile users share one carrier address, so the pause is per member name first;
		// the address-wide pause only trips on a very large number of failures (a real attack).
		foreach ( array( self::k( $ip, $login ), self::k( $ip ) ) as $key ) {
			if ( '' === $login && $key === self::k( $ip, $login ) ) {
				continue;
			}
			$c = get_transient( $key );
			if ( is_array( $c ) && ! empty( $c['lock'] ) && $c['lock'] > time() ) {
				$min = max( 1, (int) ceil( ( $c['lock'] - time() ) / 60 ) );
				return new WP_Error( 'mrsh_locked', 'Too many wrong attempts. For safety, login is paused. Please try again in about ' . $min . ' minute' . ( 1 === $min ? '' : 's' ) . ', or use "Forgot password".' );
			}
		}
		return $user;
	}

	private static function bump( $key, $label, $limit, $login ) {
		$ip  = self::ip();
		$win = max( 1, (int) self::o( 'bf_window' ) ) * MINUTE_IN_SECONDS;
		$c   = get_transient( $key );
		$c   = is_array( $c ) ? $c : array( 'n' => 0, 'first' => time(), 'lock' => 0 );
		if ( ! empty( $c['lock'] ) && $c['lock'] > time() ) {
			return;
		}
		if ( time() - (int) $c['first'] > $win ) {
			$c = array( 'n' => 0, 'first' => time(), 'lock' => 0 );
		}
		$c['n']++;
		if ( $c['n'] >= $limit ) {
			$len       = max( 1, (int) self::o( 'bf_lock' ) ) * MINUTE_IN_SECONDS;
			$c['lock'] = time() + $len;
			$l         = self::locks();
			$l[ $label ] = $c['lock'];
			update_option( self::LOCKS, $l, false );
			self::log( $ip, $login, 'locked' );
			set_transient( $key, $c, $len + $win );
			return;
		}
		set_transient( $key, $c, $win );
	}

	public static function failed( $login ) {
		if ( ! self::o( 'bf_on' ) ) {
			return;
		}
		$ip = self::ip();
		if ( '' === $ip || self::allowed( $ip ) ) {
			return;
		}
		self::log( $ip, $login, 'fail' );
		$tries = max( 3, (int) self::o( 'bf_tries' ) );
		if ( '' !== trim( (string) $login ) ) {
			self::bump( self::k( $ip, $login ), $ip . '|' . strtolower( trim( (string) $login ) ), $tries, $login );
		}
		self::bump( self::k( $ip ), $ip, max( 40, $tries * 8 ), $login ); // shared-address ceiling
	}

	public static function ok( $login, $user ) {
		$ip = self::ip();
		if ( '' !== $ip ) {
			delete_transient( self::k( $ip, $login ) );
		}
	}

	/* ---------------------------------------------------------------- new-device email */
	private static function ua() {
		return isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
	}

	private static function describe( $ua ) {
		$os = 'an unknown device';
		foreach ( array( 'iPhone' => 'an iPhone', 'iPad' => 'an iPad', 'Android' => 'an Android phone', 'Windows' => 'a Windows computer', 'Macintosh' => 'a Mac', 'Linux' => 'a Linux computer' ) as $k => $v ) {
			if ( false !== stripos( $ua, $k ) ) {
				$os = $v;
				break;
			}
		}
		$br = 'a browser';
		foreach ( array( 'Edg' => 'Edge', 'OPR' => 'Opera', 'Firefox' => 'Firefox', 'Chrome' => 'Chrome', 'CriOS' => 'Chrome', 'Safari' => 'Safari' ) as $k => $v ) {
			if ( false !== strpos( $ua, $k ) ) {
				$br = $v;
				break;
			}
		}
		return $br . ' on ' . $os;
	}

	public static function device( $cookie, $exp, $expiration, $uid ) {
		if ( ! self::o( 'alert_new' ) || ! $uid ) {
			return;
		}
		$ua = self::ua();
		if ( '' === $ua ) {
			return;
		}
		$id   = md5( preg_replace( '/[\d\.]+/', '', $ua ) );
		$list = get_user_meta( $uid, self::DEV, true );
		$list = is_array( $list ) ? $list : array();
		if ( in_array( $id, $list, true ) ) {
			return;
		}
		$first  = empty( $list );
		$list[] = $id;
		update_user_meta( $uid, self::DEV, array_slice( $list, -12 ) );
		if ( $first || get_transient( 'mrsh_sh_al_' . $uid ) ) {
			return;
		}
		set_transient( 'mrsh_sh_al_' . $uid, 1, HOUR_IN_SECONDS );
		$u = get_userdata( $uid );
		if ( ! $u || ! is_email( $u->user_email ) ) {
			return;
		}
		$ip   = self::ip();
		$mask = $ip ? ( false !== strpos( $ip, ':' ) ? substr( $ip, 0, 9 ) . '…' : preg_replace( '/\.\d+$/', '.xxx', $ip ) ) : 'unknown';
		$body = 'Hello ' . $u->display_name . ",\n\nYour " . wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) . " account was just signed in from a device we have not seen before.\n\nDevice: " . self::describe( $ua ) . "\nNetwork: " . $mask . "\nTime: " . wp_date( 'j M Y, g:i a' ) . "\n\nIf this was you, no action is needed.\nIf it was not you, change your password now: " . wp_lostpassword_url() . "\n\nStay safe,\n" . wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$to = $u->user_email;
		// Sent after the page has gone to the member, so a slow mail server never keeps them waiting.
		add_action( 'shutdown', function () use ( $to, $body ) {
			ignore_user_abort( true );
			if ( function_exists( 'litespeed_finish_request' ) ) {
				litespeed_finish_request();
			} elseif ( function_exists( 'fastcgi_finish_request' ) ) {
				fastcgi_finish_request();
			}
			wp_mail( $to, 'New sign-in to your account', $body );
		}, 1 );
	}

	/* ---------------------------------------------------------------- password rule */
	private static function pw_errors( $pw, $login = '', $email = '' ) {
		$min = self::pw_min();
		if ( strlen( $pw ) < $min ) {
			return 'Please choose a password with at least ' . $min . ' characters.';
		}
		if ( self::o( 'pw_weak' ) ) {
			$weak = array( 'password', 'password1', 'password123', '12345678', '123456789', '1234567890', 'qwertyui', 'qwerty123', 'iloveyou', 'pakistan', 'pakistan123', 'allah123', 'muhammad', 'muhammad123', 'myrishta', 'rishta123', 'abcd1234', '11111111', '00000000', 'admin123', 'welcome1' );
			$p    = strtolower( $pw );
			if ( in_array( $p, $weak, true ) || ( '' !== $login && $p === strtolower( $login ) ) || ( '' !== $email && $p === strtolower( $email ) ) || preg_match( '/^(.)\1+$/', $pw ) ) {
				return 'That password is too easy to guess. Please choose a harder one.';
			}
		}
		return '';
	}

	public static function pw_profile( $errors, $update, $user ) {
		if ( ! empty( $user->user_pass ) ) {
			$m = self::pw_errors( (string) $user->user_pass, (string) ( $user->user_login ?? '' ), (string) ( $user->user_email ?? '' ) );
			if ( $m ) {
				$errors->add( 'mrsh_pw', $m );
			}
		}
	}

	public static function pw_reset( $errors, $user ) {
		$pw = isset( $_POST['pass1'] ) ? (string) wp_unslash( $_POST['pass1'] ) : ''; // phpcs:ignore WordPress.Security
		if ( '' !== $pw && $user instanceof WP_User ) {
			$m = self::pw_errors( $pw, $user->user_login, $user->user_email );
			if ( $m ) {
				$errors->add( 'mrsh_pw', $m );
			}
		}
	}

	/* ---------------------------------------------------------------- hardening switches */
	public static function no_edit( $caps, $cap ) {
		if ( self::o( 'no_file_edit' ) && in_array( $cap, array( 'edit_themes', 'edit_plugins', 'edit_files' ), true ) ) {
			return array( 'do_not_allow' );
		}
		return $caps;
	}

	public static function hsts() {
		if ( self::o( 'hsts' ) && is_ssl() && ! headers_sent() ) {
			header( 'Strict-Transport-Security: max-age=31536000' );
		}
	}

	public static function app_pw( $a ) {
		return self::o( 'no_app_pw' ) ? false : $a;
	}

	/* ---------------------------------------------------------------- actions */
	private static function guard( $n ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( $n );
	}

	private static function back( $m ) {
		wp_safe_redirect( add_query_arg( 'msg', rawurlencode( $m ), admin_url( 'admin.php?page=mrsh-shield' ) ) );
		exit;
	}

	public static function save() {
		self::guard( 'mrsh_shield_save' );
		$allow = array();
		foreach ( preg_split( '/\s+/', (string) wp_unslash( $_POST['allow'] ?? '' ), -1, PREG_SPLIT_NO_EMPTY ) as $i ) { // phpcs:ignore WordPress.Security
			if ( filter_var( $i, FILTER_VALIDATE_IP ) ) {
				$allow[] = $i;
			}
		}
		if ( ! empty( $_POST['add_me'] ) && self::ip() ) {
			$allow[] = self::ip();
		}
		update_option( self::OPT, array(
			'bf_on'        => empty( $_POST['bf_on'] ) ? 0 : 1,
			'bf_tries'     => max( 3, min( 20, (int) ( $_POST['bf_tries'] ?? 5 ) ) ),
			'bf_window'    => max( 1, min( 120, (int) ( $_POST['bf_window'] ?? 15 ) ) ),
			'bf_lock'      => max( 1, min( 1440, (int) ( $_POST['bf_lock'] ?? 15 ) ) ),
			'allow'        => implode( "\n", array_unique( $allow ) ),
			'alert_new'    => empty( $_POST['alert_new'] ) ? 0 : 1,
			'pw_min'       => max( 6, min( 32, (int) ( $_POST['pw_min'] ?? 8 ) ) ),
			'pw_weak'      => empty( $_POST['pw_weak'] ) ? 0 : 1,
			'no_file_edit' => empty( $_POST['no_file_edit'] ) ? 0 : 1,
			'hsts'         => empty( $_POST['hsts'] ) ? 0 : 1,
			'no_app_pw'    => empty( $_POST['no_app_pw'] ) ? 0 : 1,
		), false );
		self::back( 'Security settings saved.' );
	}

	public static function unlock() {
		self::guard( 'mrsh_shield_unlock' );
		$ip = isset( $_POST['ip'] ) ? sanitize_text_field( wp_unslash( $_POST['ip'] ) ) : '';
		$parts = explode( '|', $ip, 2 );
		if ( filter_var( $parts[0], FILTER_VALIDATE_IP ) ) {
			delete_transient( self::k( $parts[0], $parts[1] ?? '' ) );
			$l = self::locks();
			unset( $l[ $ip ] );
			update_option( self::LOCKS, $l, false );
		}
		self::back( 'Unblocked ' . $ip . '.' );
	}

	/** Email a password-reset link to the member behind a failed login (number, email or name they typed). */
	public static function reset() {
		self::guard( 'mrsh_shield_reset' );
		$t = isset( $_POST['who'] ) ? sanitize_text_field( wp_unslash( $_POST['who'] ) ) : '';
		$u = class_exists( 'MRSH_Mobile' ) ? MRSH_Mobile::find( $t ) : null;
		if ( ! $u || user_can( $u, 'manage_options' ) || user_can( $u, 'edit_others_posts' ) || ! is_email( $u->user_email ) || false !== strpos( $u->user_email, '@noemail.' ) ) {
			self::back( 'No member with a usable email matches "' . $t . '".' );
		}
		$key = get_password_reset_key( $u );
		if ( is_wp_error( $key ) ) {
			self::back( 'Could not make a reset link.' );
		}
		$url  = network_site_url( 'wp-login.php?action=rp&key=' . $key . '&login=' . rawurlencode( $u->user_login ), 'login' );
		$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		wp_mail( $u->user_email, 'Log in to ' . $site, 'Hello ' . $u->display_name . ",\n\nWe saw a login attempt on your " . $site . " account that did not work. Please choose a new password here:\n\n" . $url . "\n\nTip: log in with your email address (" . $u->user_email . ") or your mobile number.\n\nIf this was not you, ignore this email." );
		self::back( 'Reset link emailed to ' . $u->user_email . '.' );
	}

	public static function block() {
		self::guard( 'mrsh_shield_block' );
		$ip = isset( $_POST['ip'] ) ? sanitize_text_field( wp_unslash( $_POST['ip'] ) ) : '';
		if ( filter_var( $ip, FILTER_VALIDATE_IP ) && class_exists( 'MRSH_Guard' ) && ! self::allowed( $ip ) ) {
			MRSH_Guard::add_ip( $ip );
			self::back( $ip . ' was added to the permanent block list (Security and places).' );
		}
		self::back( 'That address could not be blocked.' );
	}

	public static function signout() {
		self::guard( 'mrsh_shield_signout' );
		$all = ! empty( $_POST['all'] );
		$me  = get_current_user_id();
		if ( $all ) {
			WP_Session_Tokens::destroy_all_for_all_users();
			wp_safe_redirect( wp_login_url() );
			exit;
		}
		$ids = get_users( array( 'meta_key' => 'session_tokens', 'meta_compare' => 'EXISTS', 'fields' => 'ID', 'number' => 5000 ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		$n   = 0;
		foreach ( (array) $ids as $id ) {
			if ( (int) $id !== $me ) {
				WP_Session_Tokens::get_instance( (int) $id )->destroy_all();
				$n++;
			}
		}
		self::back( 'Signed out ' . $n . ' other accounts. You stayed signed in.' );
	}

	public static function clearlog() {
		self::guard( 'mrsh_shield_clearlog' );
		delete_option( self::LOG );
		self::back( 'The failed-login log was cleared.' );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Security Shield', 'Security Shield', 'manage_options', 'mrsh-shield', array( __CLASS__, 'page' ) );
	}

	/* ---------------------------------------------------------------- checklist */
	private static function checks() {
		$o   = self::o();
		$out = array();
		$add = function ( $ok, $w, $title, $fix ) use ( &$out ) {
			$out[] = array( (bool) $ok, (int) $w, $title, $fix );
		};
		$add( is_ssl(), 10, 'The site uses HTTPS', 'Install or force an SSL certificate in your hosting panel.' );
		$add( ! empty( $o['bf_on'] ), 15, 'Wrong-password lockout is on', 'Turn on the lockout in card 1.' );
		$add( ! username_exists( 'admin' ), 8, 'No account is named "admin"', 'Make a new administrator with another name, then delete the "admin" account.' );
		$tf = class_exists( 'MRSH_TwoFactor' ) ? MRSH_TwoFactor::settings() : array( 'enabled' => 0 );
		$adm = get_users( array( 'role' => 'administrator', 'fields' => 'ID', 'number' => 200 ) );
		$ok  = 0;
		if ( class_exists( 'MRSH_TwoFactor' ) ) {
			foreach ( (array) $adm as $a ) {
				if ( MRSH_TwoFactor::method_for( (int) $a ) ) {
					$ok++;
				}
			}
		}
		$add( ! empty( $tf['enabled'] ) && $adm && $ok === count( $adm ), 15, 'Every administrator has a second step (2FA)', 'Open Login Security and tick Administrator under "Required for these roles".' );
		$add( count( (array) $adm ) <= 3, 5, 'Three or fewer administrator accounts', 'Change extra administrators to Editor.' );
		$add( ! empty( $o['no_file_edit'] ) || ( defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT ), 6, 'The theme and plugin file editor is off', 'Turn it on in card 3.' );
		$add( (int) $o['pw_min'] >= 6, 6, 'Passwords must be 6 or more characters', 'Raise the minimum in card 2.' );
		$add( ! empty( $o['alert_new'] ), 5, 'Members get an email for a new-device sign-in', 'Turn it on in card 2.' );
		$add( ! ( defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'WP_DEBUG_DISPLAY' ) && WP_DEBUG_DISPLAY ), 6, 'Error messages are hidden from visitors', 'Set WP_DEBUG_DISPLAY to false in wp-config.php.' );
		$core = get_site_transient( 'update_core' );
		$cu   = ! empty( $core->updates[0]->response ) && 'upgrade' === $core->updates[0]->response;
		$add( ! $cu, 8, 'WordPress is up to date', 'Update WordPress from Dashboard, Updates.' );
		$pl = get_site_transient( 'update_plugins' );
		$pn = ! empty( $pl->response ) ? count( (array) $pl->response ) : 0;
		$add( 0 === $pn, 8, 'All plugins are up to date' . ( $pn ? ' (' . $pn . ' waiting)' : '' ), 'Open Plugins and update them.' );
		$add( ! empty( $o['hsts'] ), 4, 'Browsers are told to always use HTTPS (HSTS)', 'Turn it on in card 3 once HTTPS works on every page.' );
		return $out;
	}

	/* ---------------------------------------------------------------- page */
	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		global $wpdb;
		$o      = self::o();
		$checks = self::checks();
		$tot    = 0;
		$got    = 0;
		foreach ( $checks as $c ) {
			$tot += $c[1];
			$got += $c[0] ? $c[1] : 0;
		}
		$score = $tot ? (int) round( 100 * $got / $tot ) : 0;
		$col   = $score >= 85 ? '#0b8f4d' : ( $score >= 60 ? '#d97706' : '#dc2626' );
		$locks = self::locks();
		$log   = array_reverse( (array) get_option( self::LOG, array() ) );
		$day   = 0;
		foreach ( $log as $l ) {
			if ( 'fail' === $l[3] && $l[0] > time() - DAY_IN_SECONDS ) {
				$day++;
			}
		}
		$post = esc_url( admin_url( 'admin-post.php' ) );
		$me   = self::ip();
		$sw   = function ( $name, $title, $desc ) use ( $o ) {
			echo '<label class="sh-sw"><input type="checkbox" name="' . esc_attr( $name ) . '" value="1"' . checked( ! empty( $o[ $name ] ), true, false ) . '><div><b>' . esc_html( $title ) . '</b><span>' . wp_kses_post( $desc ) . '</span></div></label>';
		};
		if ( class_exists( 'MRSH_Admin' ) ) {
			MRSH_Admin::open( 'Security Shield', 'Stops password guessing, tells members about new devices, sets password rules, and checks your site against a security checklist.' );
		} else {
			echo '<div class="wrap"><h1>Security Shield</h1>';
		}
		if ( isset( $_GET['msg'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="notice notice-info"><p>' . esc_html( rawurldecode( (string) wp_unslash( $_GET['msg'] ) ) ) . '</p></div>'; // phpcs:ignore
		}
		?>
<style>
.sh{max-width:1000px;margin:18px 0 40px;font-size:14px}.sh *{box-sizing:border-box}
.sh-hero{display:flex;gap:22px;align-items:center;flex-wrap:wrap;background:#fff;border-radius:20px;padding:20px 24px;margin:0 0 16px;box-shadow:0 1px 3px rgba(17,24,39,.07),0 0 0 1px rgba(17,24,39,.04)}
.sh-ring{--p:0;--c:#0b8f4d;width:112px;height:112px;border-radius:50%;background:conic-gradient(var(--c) calc(var(--p)*1%),#e8eaf0 0);display:grid;place-items:center;flex:none}
.sh-ring i{width:86px;height:86px;border-radius:50%;background:#fff;display:grid;place-items:center;font-style:normal;font-weight:800;font-size:26px;color:var(--c)}
.sh-hero h2{margin:0 0 4px;font-size:20px}.sh-hero p{margin:0;color:#6b7280;max-width:560px;line-height:1.5}
.sh-chips{display:flex;gap:10px;flex-wrap:wrap;margin-left:auto}
.sh-chip{background:#f8fafc;border-radius:14px;padding:10px 16px;min-width:120px}.sh-chip small{display:block;color:#6b7280;text-transform:uppercase;letter-spacing:.06em;font-size:11px}.sh-chip b{font-size:18px}
.sh-card{background:#fff;border-radius:20px;padding:22px 26px;margin:0 0 16px;box-shadow:0 1px 3px rgba(17,24,39,.07),0 0 0 1px rgba(17,24,39,.04)}
.sh-hd{display:flex;align-items:center;gap:12px;margin:0 0 6px}.sh-hd h2{margin:0;font-size:17px}
.sh-n{width:30px;height:30px;border-radius:10px;background:linear-gradient(135deg,#1c8a6a,#0b4d3b);color:#fff;display:grid;place-items:center;font-weight:700}
.sh-sub{margin:0 0 14px;color:#6b7280;line-height:1.55;max-width:780px}
.sh-sw{display:flex;gap:12px;align-items:flex-start;padding:12px 14px;border:1px solid #e5e7eb;border-radius:14px;margin:0 0 10px;cursor:pointer}
.sh-sw input{margin-top:4px;width:18px;height:18px;accent-color:#0b8f4d}.sh-sw b{display:block}.sh-sw span{color:#6b7280;font-size:13px}
.sh-g{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;margin:8px 0 4px}
.sh label.f{display:block;font-weight:600}.sh label.f span{display:block;font-weight:400;color:#6b7280;font-size:12.5px;margin-top:3px}
.sh input[type=number],.sh textarea{border:1px solid #d6dae1;border-radius:12px;padding:10px 14px;background:#f8fafc;margin-top:6px;width:100%}
.sh-btn{border:0;border-radius:12px;padding:10px 20px;font-weight:700;cursor:pointer;background:#fff;color:#111827;box-shadow:0 0 0 1px #d6dae1}
.sh-btn.p{background:linear-gradient(135deg,#1c8a6a,#0b4d3b);color:#fff;box-shadow:none}.sh-btn.d{color:#b91c1c}.sh-btn.s{padding:5px 12px;font-size:12.5px}
.sh table{width:100%;border-collapse:collapse}.sh td,.sh th{padding:9px 6px;border-bottom:1px solid #eef0f3;text-align:left;vertical-align:top}.sh th{color:#6b7280;font-size:12px;text-transform:uppercase;letter-spacing:.05em}
.sh-ck{display:flex;gap:10px;align-items:flex-start;padding:9px 0;border-bottom:1px solid #eef0f3}.sh-ck:last-child{border:0}
.sh-ck i{flex:none;width:22px;height:22px;border-radius:50%;display:grid;place-items:center;font-style:normal;font-weight:800;font-size:13px;color:#fff;margin-top:1px}
.sh-ck.ok i{background:#0b8f4d}.sh-ck.no i{background:#dc2626}.sh-ck span{display:block;color:#6b7280;font-size:12.5px}
.sh-pill{display:inline-block;border-radius:999px;padding:2px 10px;font-size:12px;background:#fee2e2;color:#7f1d1d}.sh-pill.k{background:#fef3c7;color:#78350f}
.sh-x{overflow-x:auto}
</style>
<div class="sh">
	<div class="sh-hero">
		<div class="sh-ring" style="--p:<?php echo (int) $score; ?>;--c:<?php echo esc_attr( $col ); ?>"><i><?php echo (int) $score; ?></i></div>
		<div><h2>Security score: <?php echo (int) $score; ?> out of 100</h2><p><?php echo $score >= 85 ? 'Strong. Keep updates on and review the log now and then.' : 'Work down the checklist below. Each green tick raises the score.'; ?></p></div>
		<div class="sh-chips">
			<div class="sh-chip"><small>Wrong passwords, 24h</small><b><?php echo (int) $day; ?></b></div>
			<div class="sh-chip"><small>Paused right now</small><b><?php echo (int) count( $locks ); ?></b></div>
		</div>
	</div>

	<form method="post" action="<?php echo $post; // phpcs:ignore ?>">
		<input type="hidden" name="action" value="mrsh_shield_save"><?php wp_nonce_field( 'mrsh_shield_save' ); ?>
		<div class="sh-card">
			<div class="sh-hd"><span class="sh-n">1</span><h2>Stop password guessing</h2></div>
			<p class="sub sh-sub">After too many wrong passwords from one address, login from that address pauses for a while. Real members who forget a password only wait a few minutes.</p>
			<?php $sw( 'bf_on', 'Pause login after repeated wrong passwords', 'Works for the website login, the app login and the admin login.' ); ?>
			<div class="sh-g">
				<label class="f">Wrong tries allowed<input type="number" name="bf_tries" min="3" max="20" value="<?php echo (int) $o['bf_tries']; ?>"><span>3 to 20</span></label>
				<label class="f">Counted within (minutes)<input type="number" name="bf_window" min="1" max="120" value="<?php echo (int) $o['bf_window']; ?>"><span>Time window for the tries</span></label>
				<label class="f">Pause for (minutes)<input type="number" name="bf_lock" min="1" max="1440" value="<?php echo (int) $o['bf_lock']; ?>"><span>How long login stays paused</span></label>
			</div>
			<label class="f" style="margin-top:12px">Never pause these addresses (one per line)<textarea name="allow" rows="3" placeholder="Your office or home address"><?php echo esc_textarea( (string) $o['allow'] ); ?></textarea><span>Your current address is <b><?php echo esc_html( $me ? $me : 'unknown' ); ?></b>.</span></label>
			<label class="sh-sw" style="margin-top:10px"><input type="checkbox" name="add_me" value="1"><div><b>Add my current address to the safe list</b><span>Recommended for the person who manages the site.</span></div></label>
		</div>
		<div class="sh-card">
			<div class="sh-hd"><span class="sh-n">2</span><h2>Members and passwords</h2></div>
			<?php $sw( 'alert_new', 'Email a member when their account is opened on a new device', 'The first device is remembered quietly. Later new devices get a "was this you?" email with a link to change the password.' ); ?>
			<?php $sw( 'pw_weak', 'Refuse easy passwords', 'Blocks passwords like 12345678, password, pakistan123, or one that equals the member\'s name or email.' ); ?>
			<div class="sh-g"><label class="f">Minimum password length<input type="number" name="pw_min" min="6" max="32" value="<?php echo (int) $o['pw_min']; ?>"><span>Used when a member sets or resets a password. 6 is easy for everyday members; raise it if you wish.</span></label></div>
		</div>
		<div class="sh-card">
			<div class="sh-hd"><span class="sh-n">3</span><h2>Extra hardening</h2></div>
			<?php $sw( 'no_file_edit', 'Turn off the theme and plugin file editor', 'Stops an intruder who gets into the dashboard from editing code there.' ); ?>
			<?php $sw( 'hsts', 'Tell browsers to always use HTTPS (HSTS)', 'Turn on only after every page works on https. It lasts one year in the browser.' ); ?>
			<?php $sw( 'no_app_pw', 'Turn off WordPress application passwords', 'Leave this off if you use an AI connector or the mobile app that signs in with an application password.' ); ?>
		</div>
		<div style="margin:0 0 16px"><button class="sh-btn p">Save security settings</button></div>
	</form>

	<div class="sh-card">
		<div class="sh-hd"><span class="sh-n">4</span><h2>Security checklist</h2></div>
		<p class="sh-sub">Live checks of this site. Red items show what to do.</p>
		<?php foreach ( $checks as $c ) : ?>
		<div class="sh-ck <?php echo $c[0] ? 'ok' : 'no'; ?>"><i><?php echo $c[0] ? '&#10003;' : '!'; ?></i><div><b><?php echo esc_html( $c[2] ); ?></b><?php if ( ! $c[0] ) : ?><span><?php echo esc_html( $c[3] ); ?></span><?php endif; ?></div></div>
		<?php endforeach; ?>
	</div>

	<div class="sh-card">
		<div class="sh-hd"><span class="sh-n">5</span><h2>Paused addresses and failed logins</h2></div>
		<?php if ( $locks ) : ?>
		<p class="sh-sub">Paused now. Press Unblock if a real member is stuck.</p>
		<div class="sh-x"><table><thead><tr><th>Address</th><th>Paused until</th><th></th></tr></thead><tbody>
		<?php foreach ( $locks as $ip => $until ) : ?>
			<tr><td><code><?php echo esc_html( $ip ); ?></code></td><td><?php echo esc_html( wp_date( 'g:i a', $until ) ); ?></td><td><form method="post" action="<?php echo $post; // phpcs:ignore ?>" style="margin:0"><input type="hidden" name="action" value="mrsh_shield_unlock"><input type="hidden" name="ip" value="<?php echo esc_attr( $ip ); ?>"><?php wp_nonce_field( 'mrsh_shield_unlock' ); ?><button class="sh-btn s">Unblock</button></form></td></tr>
		<?php endforeach; ?>
		</tbody></table></div>
		<?php endif; ?>
		<?php if ( ! $log ) : ?>
			<p>No failed logins recorded yet.</p>
		<?php else : ?>
		<div class="sh-x"><table style="margin-top:10px"><thead><tr><th>When</th><th>Address</th><th>Name tried</th><th>What happened</th><th></th></tr></thead><tbody>
		<?php foreach ( array_slice( $log, 0, 25 ) as $l ) : ?>
			<tr><td><?php echo esc_html( wp_date( 'j M, g:i a', (int) $l[0] ) ); ?></td><td><code><?php echo esc_html( $l[1] ); ?></code></td><td><?php echo esc_html( $l[2] ); ?></td><td><span class="sh-pill<?php echo 'locked' === $l[3] ? '' : ' k'; ?>"><?php echo 'locked' === $l[3] ? 'login paused' : 'wrong password'; ?></span></td>
			<td style="white-space:nowrap"><?php $mm = class_exists( 'MRSH_Mobile' ) ? MRSH_Mobile::find( $l[2] ) : null; if ( $mm && ! user_can( $mm, 'manage_options' ) ) : ?><form method="post" action="<?php echo $post; // phpcs:ignore ?>" style="margin:0 6px 0 0;display:inline"><input type="hidden" name="action" value="mrsh_shield_reset"><input type="hidden" name="who" value="<?php echo esc_attr( $l[2] ); ?>"><?php wp_nonce_field( 'mrsh_shield_reset' ); ?><button class="sh-btn s" title="Real member: <?php echo esc_attr( $mm->display_name ); ?>">Email reset link</button></form><?php endif; ?><form method="post" action="<?php echo $post; // phpcs:ignore ?>" style="margin:0;display:inline"><input type="hidden" name="action" value="mrsh_shield_block"><input type="hidden" name="ip" value="<?php echo esc_attr( $l[1] ); ?>"><?php wp_nonce_field( 'mrsh_shield_block' ); ?><button class="sh-btn s d">Block for good</button></form></td></tr>
		<?php endforeach; ?>
		</tbody></table></div>
		<form method="post" action="<?php echo $post; // phpcs:ignore ?>" style="margin-top:12px;display:inline-block"><input type="hidden" name="action" value="mrsh_mobile_backfill"><?php wp_nonce_field( 'mrsh_mobile_backfill' ); ?><button class="sh-btn s">Save phone numbers from profiles (so members can log in with their mobile)</button></form> <form method="post" action="<?php echo $post; // phpcs:ignore ?>" style="margin-top:12px;display:inline-block"><input type="hidden" name="action" value="mrsh_shield_clearlog"><?php wp_nonce_field( 'mrsh_shield_clearlog' ); ?><button class="sh-btn s">Clear this log</button></form>
		<?php endif; ?>
	</div>

	<div class="sh-card">
		<div class="sh-hd"><span class="sh-n">6</span><h2>Emergency: sign people out</h2></div>
		<p class="sh-sub">Use after a suspected break-in, or if you shared a password by mistake. Everyone signed out must log in again.</p>
		<div style="display:flex;gap:10px;flex-wrap:wrap">
			<form method="post" action="<?php echo $post; // phpcs:ignore ?>" onsubmit="return confirm('Sign out everyone except you?')" style="margin:0"><input type="hidden" name="action" value="mrsh_shield_signout"><?php wp_nonce_field( 'mrsh_shield_signout' ); ?><button class="sh-btn">Sign out everyone except me</button></form>
			<form method="post" action="<?php echo $post; // phpcs:ignore ?>" onsubmit="return confirm('Sign out EVERYONE including you?')" style="margin:0"><input type="hidden" name="action" value="mrsh_shield_signout"><input type="hidden" name="all" value="1"><?php wp_nonce_field( 'mrsh_shield_signout' ); ?><button class="sh-btn d">Sign out everyone including me</button></form>
		</div>
	</div>
</div>
		<?php
		echo '</div>';
	}
}

MRSH_Shield::init();
