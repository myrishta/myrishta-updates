<?php
/**
 * Member manager: one table of every member with filters, sorting and all the buttons an admin needs
 * (verify, ban, approve, reject, plan, email, reset password). Everything happens from the member's row.
 * Uses the same data the older Members/Profiles pages use, so nothing is lost if you go back to those.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Desk {

	const SLUG = 'mrsh-desk';
	const PER  = 25;

	/** Ready-made emails: array( title, subject, message ). {name} = member name, {site} = site name. */
	public static function email_defaults() {
		return array(
			array( 'Welcome', 'Welcome to My Rishta Pakistan', "Assalam o Alaikum {name},\n\nWelcome to {site}. Your account is ready. Please complete your profile and add a clear photo so families can find you.\n\nIf you need help, just reply to this email.\n\nJazakallah khair" ),
			array( 'Profile approved', 'Your profile is now live', "Assalam o Alaikum {name},\n\nGood news: your profile has been checked and is now visible on {site}.\n\nKeep your details up to date for better replies.\n\nJazakallah khair" ),
			array( 'Complete your profile', 'Please complete your profile', "Assalam o Alaikum {name},\n\nYour profile on {site} is not complete yet. Please add your education, work, family details and a clear photo. Complete profiles get many more replies.\n\nJazakallah khair" ),
			array( 'Photo needed', 'A clear photo is needed', "Assalam o Alaikum {name},\n\nWe could not accept the photo on your profile because it was not clear or did not follow our guidelines. Please upload a recent, clear photo of yourself and we will review it again.\n\nJazakallah khair" ),
			array( 'Please verify your email', 'Please confirm your email address', "Assalam o Alaikum {name},\n\nPlease confirm your email address from your account page so we can keep your account safe and send you matches.\n\nJazakallah khair" ),
			array( 'Plan activated', 'Your plan is active', "Assalam o Alaikum {name},\n\nThank you. Your plan on {site} is now active. You can see it in My account.\n\nJazakallah khair" ),
			array( 'Payment proof needed', 'Please send your payment proof', "Assalam o Alaikum {name},\n\nWe have not received your payment screenshot yet. Please upload it from My account (Payment proof) so we can activate your plan.\n\nJazakallah khair" ),
			array( 'Profile paused', 'Your profile has been paused', "Assalam o Alaikum {name},\n\nYour profile has been paused because it does not follow our guidelines. Please reply to this email and we will help you fix it.\n\nJazakallah khair" ),
			array( 'Safety reminder', 'Staying safe while looking for a rishta', "Assalam o Alaikum {name},\n\nA small reminder: never send money to anyone you meet here, meet only with your family, and use Report or Block on any profile that worries you.\n\nJazakallah khair" ),
			array( 'Delete my account', 'How to delete your account', "Assalam o Alaikum {name},\n\nPlease visit {site} and log in to your account. Under My account, open \"Delete my account\", enter your password and confirm. If you cannot log in, reply to this email from the same address and we will remove it for you.\n\nJazakallah khair" ),
			array( 'Thank you, solved', 'Your request is solved', "Assalam o Alaikum {name},\n\nThank you for writing to us. We have looked into this and it is now solved. If you need anything else, just reply to this email.\n\nJazakallah khair" ),
		);
	}

	public static function email_templates() {
		$o = get_option( 'mrsh_em_tpl', null );
		if ( is_array( $o ) && $o ) {
			return array_values( $o );
		}
		return self::email_defaults();
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 21 );
		add_action( 'admin_post_mrsh_desk_act', array( __CLASS__, 'act' ) );
		add_action( 'admin_post_mrsh_desk_csv', array( __CLASS__, 'csv' ) );
		add_action( 'admin_post_mrsh_desk_auto', array( __CLASS__, 'auto_toggle' ) );
		add_action( 'mrsh_desk_remind', array( __CLASS__, 'remind_cron' ) );
		add_action( 'admin_post_mrsh_desk_newnow', array( __CLASS__, 'new_now' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
	}

	/* ---------- 3.101.226: completeness, notes, CSV, automatic reminders ---------- */

	public static function schedule() {
		$on   = (int) get_option( 'mrsh_desk_auto', 1 );
		$next = wp_next_scheduled( 'mrsh_desk_remind' );
		if ( $on && ! $next ) {
			wp_schedule_event( time() + 1800, 'daily', 'mrsh_desk_remind' );
		} elseif ( ! $on && $next ) {
			wp_unschedule_event( $next, 'mrsh_desk_remind' );
		}
	}

	public static function auto_toggle() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_desk_auto' );
		$to = isset( $_POST['to'] ) && 'on' === $_POST['to'] ? 1 : 0; // phpcs:ignore
		update_option( 'mrsh_desk_auto', $to, false );
		self::schedule();
		wp_safe_redirect( add_query_arg( 'msg', rawurlencode( $to ? 'Automatic reminders are ON. Each day, members with an incomplete profile (joined 3+ days ago) get one reminder, at most once every 14 days, up to 30 emails a day.' : 'Automatic reminders are OFF.' ), admin_url( 'admin.php?page=' . self::SLUG ) ) );
		exit;
	}

	/** Send the ready "Complete your profile" email to one member, at most once every 14 days. */
	private static function remind_one( $uid ) {
		$u = get_userdata( $uid );
		if ( ! $u || user_can( $u, 'manage_options' ) || get_user_meta( $uid, 'mrt_banned', true ) ) {
			return false;
		}
		if ( time() - (int) get_user_meta( $uid, 'mrsh_desk_reminded', true ) < 14 * DAY_IN_SECONDS ) {
			return false;
		}
		$subject = 'Please complete your profile';
		$body    = "Assalam o Alaikum {name},\n\nYour profile on {site} is not complete yet. Please add your education, work, family details and a clear photo so families can find you.\n\nJazakallah khair";
		foreach ( self::email_templates() as $t ) {
			if ( isset( $t[0] ) && 'Complete your profile' === $t[0] ) {
				$subject = $t[1];
				$body    = $t[2];
			}
		}
		$body = str_replace( array( '{name}', '{site}' ), array( $u->display_name ?: $u->user_login, wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) ), $body );
		if ( self::send_mail( $u, $subject, $body ) ) {
			update_user_meta( $uid, 'mrsh_desk_reminded', time() );
			return true;
		}
		return false;
	}

	/** Button: remind every new member (last 7 days) whose profile is not complete, right now. */
	public static function new_now() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_desk_newnow' );
		$ids  = array_map( function ( $e ) {
			return (int) $e['uid'];
		}, class_exists( 'MRSH_Attn' ) ? MRSH_Attn::new_members( 7 ) : array() );
		$sent = 0;
		foreach ( self::load() as $r ) {
			if ( $sent >= 40 ) {
				break;
			}
			if ( in_array( (int) $r['id'], $ids, true ) && self::match( $r, 'incomplete' ) && self::remind_one( (int) $r['id'] ) ) {
				$sent++;
			}
		}
		wp_safe_redirect( add_query_arg( 'msg', rawurlencode( $sent . ' new member(s) got the "Complete your profile" email.' ), admin_url( 'admin.php?page=' . self::SLUG ) ) );
		exit;
	}

	/** New-members strip: handled automatically, with manual buttons. */
	public static function new_panel() {
		$new  = class_exists( 'MRSH_Attn' ) ? MRSH_Attn::new_members( 7 ) : array();
		$ids  = array();
		foreach ( $new as $e ) {
			$ids[] = (int) $e['uid'];
		}
		$inc = 0;
		foreach ( self::load() as $r ) {
			if ( in_array( (int) $r['id'], $ids, true ) && self::match( $r, 'incomplete' ) ) {
				$inc++;
			}
		}
		echo '<div class="mx-tabs" style="margin-top:10px;align-items:center"><b>New members this week: ' . count( $new ) . '</b> <span class="description">' . (int) $inc . ' still have an incomplete profile. Each one gets the Welcome email at sign-up and the "Complete your profile" email automatically after 3 days. Nothing needs you in the Inbox.</span> ';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline">' . wp_nonce_field( 'mrsh_desk_newnow', '_wpnonce', true, false ) . '<input type="hidden" name="action" value="mrsh_desk_newnow"><button class="mx-btn s p">Remind new members now</button></form></div>';
	}

	public static function remind_cron() {
		$sent = 0;
		foreach ( self::load() as $r ) {
			if ( $sent >= 30 ) {
				break;
			}
			if ( self::match( $r, 'incomplete' ) && $r['reg'] < time() - 3 * DAY_IN_SECONDS && self::remind_one( (int) $r['id'] ) ) {
				$sent++;
			}
		}
		update_option( 'mrsh_desk_last_auto', array( 'time' => time(), 'sent' => $sent ), false );
	}

	public static function csv() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_desk_csv' );
		$f = isset( $_GET['f'] ) ? sanitize_key( $_GET['f'] ) : 'all'; // phpcs:ignore
		$q = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : ''; // phpcs:ignore
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=members-' . gmdate( 'Y-m-d' ) . '.csv' );
		$out = fopen( 'php://output', 'w' );
		fwrite( $out, "\xEF\xBB\xBF" );
		fputcsv( $out, array( 'ID', 'Name', 'Email', 'Joined', 'Last seen', 'Verified', 'Blocked', 'Profile status', 'Profile name', 'Profile % complete', 'Plan', 'Plan ends', 'Note' ) );
		foreach ( self::load() as $r ) {
			if ( ! self::match( $r, $f ) ) {
				continue;
			}
			if ( '' !== $q && false === strpos( strtolower( $r['name'] . ' ' . $r['login'] . ' ' . $r['email'] . ' ' . $r['ptitle'] . ' #' . $r['id'] ), strtolower( $q ) ) ) {
				continue;
			}
			fputcsv( $out, array( $r['id'], $r['name'], $r['email'], wp_date( 'Y-m-d', $r['reg'] ), $r['seen'] ? wp_date( 'Y-m-d', $r['seen'] ) : '', $r['ver'] ? 'yes' : 'no', $r['ban'] ? 'yes' : 'no', $r['pid'] ? self::status_label( $r['pst'] ) : 'no profile', $r['ptitle'], $r['pid'] ? $r['score'] : '', $r['plan'], $r['exp'] ? wp_date( 'Y-m-d', $r['exp'] ) : '', $r['note'] ) );
		}
		fclose( $out );
		exit;
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Member manager', 'Member manager', 'manage_options', self::SLUG, array( __CLASS__, 'page' ) );
	}

	/* ---------- data ---------- */

	private static function status_label( $s ) {
		$m = array( 'publish' => 'Live', 'pending' => 'Waiting approval', 'pending_approval' => 'Waiting approval', 'draft' => 'Paused', 'expired' => 'Expired', 'payment' => 'Awaiting payment' );
		return $m[ $s ] ?? ucfirst( (string) $s );
	}

	private static function plans() {
		$o = array();
		if ( function_exists( 'mrt_plans' ) ) {
			foreach ( (array) mrt_plans() as $p ) {
				if ( isset( $p[0] ) && '' !== (string) $p[0] ) {
					$o[] = (string) $p[0];
				}
			}
		}
		return $o;
	}

	/** All non-admin members with the facts the table needs. */
	private static function load() {
		$users = get_users( array( 'fields' => 'all', 'number' => 5000 ) );
		$ids   = array();
		foreach ( $users as $u ) {
			$ids[] = (int) $u->ID;
		}
		if ( $ids ) {
			update_meta_cache( 'user', $ids );
		}
		$prof = array();
		$ps   = get_posts( array( 'post_type' => 'listing_type', 'post_status' => array( 'publish', 'draft', 'pending', 'pending_approval', 'payment', 'expired' ), 'numberposts' => 5000, 'orderby' => 'ID', 'order' => 'DESC', 'no_found_rows' => true ) );
		foreach ( $ps as $p ) {
			$a = (int) $p->post_author;
			if ( ! isset( $prof[ $a ] ) ) {
				$prof[ $a ] = $p;
			}
		}
		$pids = array();
		foreach ( $prof as $pp ) {
			$pids[] = (int) $pp->ID;
		}
		if ( $pids ) {
			update_object_term_cache( $pids, 'listing_type' );
			update_postmeta_cache( $pids );
		}
		$now = time();
		$out = array();
		foreach ( $users as $u ) {
			if ( user_can( $u, 'manage_options' ) ) {
				continue;
			}
			$id  = (int) $u->ID;
			$p   = $prof[ $id ] ?? null;
			$exp = (int) get_user_meta( $id, 'mrt_plan_exp', true );
			$out[ $id ] = array(
				'id'    => $id,
				'name'  => $u->display_name ?: $u->user_login,
				'login' => $u->user_login,
				'email' => $u->user_email,
				'reg'   => strtotime( $u->user_registered . ' UTC' ),
				'seen'  => (int) get_user_meta( $id, 'mrt_seen', true ),
				'ban'   => (bool) get_user_meta( $id, 'mrt_banned', true ),
				'ver'   => (int) get_user_meta( $id, '_mrsh_id_verified', true ),
				'plan'  => (string) get_user_meta( $id, 'mrt_plan', true ),
				'exp'   => $exp,
				'req'   => (string) get_user_meta( $id, 'mrt_plan_req', true ),
				'hp'    => (string) get_user_meta( $id, 'mrsh_helper', true ),
				'vreq'  => '' !== (string) get_user_meta( $id, 'mrt_vreq', true ) && ! (int) get_user_meta( $id, '_mrsh_id_verified', true ),
				'flags' => (int) get_user_meta( $id, 'mrsh_flags', true ),
				'pid'   => $p ? (int) $p->ID : 0,
				'pst'   => $p ? (string) $p->post_status : '',
				'ptitle' => $p ? (string) $p->post_title : '',
				'score' => $p ? self::score( $p ) : 0,
				'note'  => (string) get_user_meta( $id, 'mrsh_desk_note', true ),
				'pexp'  => $exp && $exp < $now,
				'soon'  => $exp && $exp >= $now && $exp < $now + 7 * DAY_IN_SECONDS,
			);
		}
		return $out;
	}

	/** Profile completeness 0-100: photo 30, a written about text 20, details (terms such as age, city, education) up to 50. */
	private static function score( $p ) {
		$n = 0;
		foreach ( get_object_taxonomies( 'listing_type' ) as $tx ) {
			$t = get_object_term_cache( (int) $p->ID, $tx );
			if ( is_array( $t ) ) {
				$n += count( $t );
			}
		}
		return min( 100, ( get_post_thumbnail_id( $p->ID ) ? 30 : 0 ) + ( strlen( wp_strip_all_tags( (string) $p->post_content ) ) >= 40 ? 20 : 0 ) + min( 50, $n * 10 ) );
	}

	private static function has_photo( $pid ) {
		if ( ! $pid ) {
			return false;
		}
		if ( function_exists( 'mrt_photo_candidates' ) ) {
			return (bool) mrt_photo_candidates( $pid );
		}
		return (bool) get_post_thumbnail_id( $pid );
	}

	private static function filters() {
		return array(
			'all'       => 'All members',
			'unverified' => 'Not verified',
			'verified'  => 'Verified',
			'banned'    => 'Blocked',
			'live'      => 'Profile live',
			'waiting'   => 'Waiting approval',
			'paused'    => 'Paused profile',
			'expired'   => 'Expired profile',
			'noprofile' => 'No profile yet',
			'nophoto'   => 'No photo',
			'flagged'   => 'Flagged for behaviour',
			'needs'     => 'Needs attention (any problem)',
			'vreq'      => 'Asked to be verified',
			'hreq'      => 'Asked to become a Rishta Agency',
			'helpers'   => 'Rishta Agencies',
			'planreq'   => 'Asked for a plan',
			'paid'      => 'Has a plan',
			'noplan'    => 'No plan',
			'planexp'   => 'Plan expired',
			'plansoon'  => 'Plan ends in 7 days',
			'incomplete' => 'Profile under 60% complete',
			'new7'      => 'Joined in the last 7 days',
			'neverseen' => 'Never came back after joining',
			'inactive30' => 'Not seen for 30 days',
			'noted'     => 'Has a private note',
		);
	}

	/** Things that need a person: verification asked, plan asked, behaviour flags, profile waiting for approval. */
	private static function issues( $r ) {
		$n = 0;
		$n += ! empty( $r['vreq'] ) ? 1 : 0;
		$n += 'pending' === $r['hp'] ? 1 : 0;
		$n += '' !== $r['req'] ? 1 : 0;
		$n += $r['flags'] > 0 ? 1 : 0;
		$n += in_array( $r['pst'], array( 'pending', 'pending_approval', 'payment' ), true ) ? 1 : 0;
		return $n;
	}

	/** Short red chips that say why a member needs attention. */
	private static function issue_chips( $r ) {
		$o = '';
		if ( ! empty( $r['vreq'] ) ) {
			$o .= '<span class="mx-pill bad">Asked to be verified</span> ';
		}
		if ( 'pending' === $r['hp'] ) {
			$o .= '<span class="mx-pill bad">Asked to become a Rishta Agency</span> ';
		}
		if ( 'ok' === $r['hp'] ) {
			$o .= '<span class="mx-pill ok">Rishta Agency</span> ';
		}
		if ( '' !== $r['req'] ) {
			$o .= '<span class="mx-pill bad">Asked for ' . esc_html( $r['req'] ) . '</span> ';
		}
		if ( in_array( $r['pst'], array( 'pending', 'pending_approval', 'payment' ), true ) ) {
			$o .= '<span class="mx-pill bad">Profile waiting approval</span> ';
		}
		return $o;
	}

	private static function match( $r, $f ) {
		switch ( $f ) {
			case 'unverified':
				return ! $r['ver'];
			case 'verified':
				return (bool) $r['ver'];
			case 'banned':
				return $r['ban'];
			case 'live':
				return 'publish' === $r['pst'];
			case 'waiting':
				return in_array( $r['pst'], array( 'pending', 'pending_approval', 'payment' ), true );
			case 'paused':
				return 'draft' === $r['pst'];
			case 'expired':
				return 'expired' === $r['pst'];
			case 'noprofile':
				return ! $r['pid'];
			case 'nophoto':
				return $r['pid'] && ! self::has_photo( $r['pid'] );
			case 'flagged':
				return $r['flags'] > 0;
			case 'needs':
				return self::issues( $r ) > 0;
			case 'vreq':
				return $r['vreq'];
			case 'hreq':
				return 'pending' === $r['hp'];
			case 'helpers':
				return 'ok' === $r['hp'];
			case 'planreq':
				return '' !== $r['req'];
			case 'paid':
				return '' !== $r['plan'];
			case 'noplan':
				return '' === $r['plan'];
			case 'planexp':
				return $r['pexp'];
			case 'plansoon':
				return $r['soon'];
			case 'incomplete':
				return ! $r['ban'] && ( ! $r['pid'] || $r['score'] < 60 );
			case 'new7':
				return $r['reg'] > time() - 7 * DAY_IN_SECONDS;
			case 'neverseen':
				return ! $r['seen'] && $r['reg'] < time() - DAY_IN_SECONDS;
			case 'inactive30':
				return $r['seen'] && $r['seen'] < time() - 30 * DAY_IN_SECONDS;
			case 'noted':
				return '' !== $r['note'];
		}
		return true;
	}

	/* ---------- actions ---------- */

	private static function msg_sig() {
		return "\n\n" . wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) . "\n" . home_url( '/' ) . "\nNever send money to anyone you meet online.\nآن لائن ملنے والے کسی شخص کو کبھی رقم نہ بھیجیں۔";
	}

	/** Urdu lines for the ready-made emails, keyed by the English subject. Added when the message has no Urdu of its own. */
	private static function urdu_for( $subject ) {
		static $m = array(
			'Welcome to My Rishta Pakistan'        => 'مائی رشتہ پاکستان میں خوش آمدید۔ آپ کا اکاؤنٹ تیار ہے۔ براہ کرم اپنا پروفائل مکمل کریں اور صاف تصویر لگائیں تاکہ خاندان آپ کو تلاش کر سکیں۔',
			'Your profile is now live'             => 'خوشخبری: آپ کا پروفائل چیک ہو چکا ہے اور اب ویب سائٹ پر نظر آ رہا ہے۔ بہتر جوابات کے لیے اپنی تفصیلات تازہ رکھیں۔',
			'Please complete your profile'         => 'آپ کا پروفائل ابھی مکمل نہیں ہے۔ براہ کرم اپنی تعلیم، کام، خاندان کی تفصیل اور ایک صاف تصویر شامل کریں۔ مکمل پروفائل پر بہت زیادہ جوابات ملتے ہیں۔',
			'A clear photo is needed'              => 'آپ کے پروفائل کی تصویر واضح نہیں تھی یا ہماری ہدایات کے مطابق نہیں تھی، اس لیے قبول نہ ہو سکی۔ براہ کرم اپنی حالیہ اور صاف تصویر لگائیں، ہم دوبارہ دیکھ لیں گے۔',
			'Please confirm your email address'    => 'براہ کرم اپنے اکاؤنٹ کے صفحے سے اپنا ای میل ایڈریس تصدیق کریں تاکہ ہم آپ کا اکاؤنٹ محفوظ رکھ سکیں اور آپ کو رشتے بھیج سکیں۔',
			'Your plan is active'                  => 'شکریہ۔ آپ کا پیکج اب فعال ہے۔ آپ اسے My account میں دیکھ سکتے ہیں۔',
			'Please send your payment proof'       => 'ہمیں آپ کی ادائیگی کا اسکرین شاٹ ابھی تک نہیں ملا۔ براہ کرم My account میں Payment proof سے اپلوڈ کریں تاکہ ہم آپ کا پیکج فعال کر سکیں۔',
			'Your profile has been paused'         => 'آپ کا پروفائل روک دیا گیا ہے کیونکہ وہ ہماری ہدایات کے مطابق نہیں۔ براہ کرم اس ای میل کا جواب دیں، ہم درست کرنے میں مدد کریں گے۔',
			'Staying safe while looking for a rishta' => 'ایک چھوٹی یاد دہانی: یہاں ملنے والے کسی شخص کو رقم نہ بھیجیں، صرف اپنے گھر والوں کے ساتھ ملیں، اور کسی بھی مشکوک پروفائل کو Report یا Block کریں۔',
			'How to delete your account'           => 'اکاؤنٹ ختم کرنے کے لیے ویب سائٹ پر لاگ ان کریں، My account میں "Delete my account" کھولیں، پاس ورڈ لکھ کر تصدیق کریں۔ لاگ ان نہ ہو سکے تو اسی ای میل سے جواب دیں، ہم ختم کر دیں گے۔',
			'Your request is solved'               => 'ہم سے رابطہ کرنے کا شکریہ۔ آپ کا مسئلہ حل ہو چکا ہے۔ مزید کچھ چاہیے ہو تو اس ای میل کا جواب دیں۔',
		);
		return isset( $m[ $subject ] ) ? $m[ $subject ] : '';
	}

	private static function send_mail( $user, $subject, $body ) {
		$body = wp_specialchars_decode( (string) $body, ENT_QUOTES );
		if ( ! preg_match( '/[\x{0600}-\x{06FF}]/u', $body ) ) {
			$ur = self::urdu_for( $subject );
			if ( '' !== $ur ) {
				$body .= "\n\n" . $ur;
			}
		}
		$text = $body . self::msg_sig();
		if ( class_exists( 'MRSH_Mailq' ) ) {
			return (bool) MRSH_Mailq::add( $user->user_email, $subject, $text, array( 'kind' => 'desk', 'uid' => (int) $user->ID ) );
		}
		return wp_mail( $user->user_email, $subject, $text );
	}

	/** Short plain reason list for a member's open flags, e.g. "Same IP, many accounts x3". */
	private static function flag_why( $uid ) {
		if ( ! class_exists( 'MRSH_Act' ) ) {
			return '';
		}
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT reason, COUNT(*) c FROM ' . MRSH_Act::tbl() . ' WHERE uid=%d AND flag=1 GROUP BY reason ORDER BY c DESC LIMIT 4', (int) $uid ) ); // phpcs:ignore WordPress.DB
		$out  = array();
		foreach ( (array) $rows as $r ) {
			$out[] = mb_substr( (string) $r->reason, 0, 60 ) . ' x' . (int) $r->c;
		}
		return $out ? implode( '; ', $out ) : 'see the Activity log';
	}

	private static function do_one( $do, $uid, $x ) {
		$u = get_userdata( $uid );
		if ( ! $u || user_can( $u, 'manage_options' ) ) {
			return false;
		}
		$p = class_exists( 'MRSH_Members' ) ? MRSH_Members::my_profile( $uid ) : null;
		switch ( $do ) {
			case 'helper_ok':
				update_user_meta( $uid, 'mrsh_helper', 'ok' );
				self::send_mail( $u, 'You are now a Rishta Agency', "Assalam o Alaikum " . $u->display_name . ",\n\nThank you. Our team approved you as a Rishta Agency. Open My account and find the Rishta Agency box to add family profiles. Please always keep the family's agreement, and never ask for money." );
				return true;
			case 'helper_off':
				update_user_meta( $uid, 'mrsh_helper', 'off' );
				return true;
			case 'verify':
				update_user_meta( $uid, '_mrsh_id_verified', time() );
				delete_transient( 'mrsh_verified_map' );
				return true;
			case 'unverify':
				delete_user_meta( $uid, '_mrsh_id_verified' );
				delete_transient( 'mrsh_verified_map' );
				return true;
			case 'ban':
				update_user_meta( $uid, 'mrt_banned', 1 );
				if ( class_exists( 'MRSH_Manage' ) ) {
					MRSH_Manage::enforce_ban( $uid );
				} elseif ( $p && 'publish' === $p->post_status ) {
					wp_update_post( array( 'ID' => $p->ID, 'post_status' => 'draft' ) );
				}
				return true;
			case 'unban':
				if ( class_exists( 'MRSH_PermBan' ) && MRSH_PermBan::is_perm( $uid ) ) {
					return false; // banned for good: undo that first
				}
				delete_user_meta( $uid, 'mrt_banned' );
				return true;
			case 'permban':
				return class_exists( 'MRSH_PermBan' ) && MRSH_PermBan::ban( $uid, 'Banned for good by an administrator' );
			case 'unpermban':
				return class_exists( 'MRSH_PermBan' ) && MRSH_PermBan::undo( $uid );
			case 'clearflags':
				if ( class_exists( 'MRSH_Act' ) ) {
					global $wpdb;
					$wpdb->query( $wpdb->prepare( 'UPDATE ' . MRSH_Act::tbl() . ' SET flag=2 WHERE uid=%d AND flag=1', $uid ) ); // phpcs:ignore WordPress.DB
					delete_user_meta( $uid, 'mrsh_flags' );
					delete_transient( 'mrsh_cnt' );
					return true;
				}
				return false;
			case 'hide':
				if ( $p ) {
					wp_update_post( array( 'ID' => $p->ID, 'post_status' => 'draft' ) );
					delete_post_meta( $p->ID, 'featured' );
					MRSH_Manage::purge_member( $uid, $p->ID );
					return true;
				}
				return false;
			case 'retire':
				if ( $p ) {
					wp_update_post( array( 'ID' => $p->ID, 'post_status' => 'draft' ) );
					delete_post_meta( $p->ID, 'featured' );
					MRSH_Manage::purge_member( $uid, $p->ID );
				}
				update_user_meta( $uid, 'mrsh_retired', time() );
				update_user_meta( $uid, 'mrsh_mm_off', 1 );
				return true;
			case 'unretire':
				delete_user_meta( $uid, 'mrsh_retired' );
				delete_user_meta( $uid, 'mrsh_self_paused' );
				delete_user_meta( $uid, 'mrsh_mm_off' );
				return true;
			case 'feature':
			case 'unfeature':
				if ( $p && 'publish' === $p->post_status && ! get_user_meta( $uid, 'mrt_banned', true ) ) {
					'feature' === $do ? update_post_meta( $p->ID, 'featured', 1 ) : delete_post_meta( $p->ID, 'featured' );
					MRSH_Manage::purge_member( $uid, $p->ID );
					return true;
				}
				return false;
			case 'logout':
				if ( class_exists( 'WP_Session_Tokens' ) ) {
					WP_Session_Tokens::get_instance( $uid )->destroy_all();
					return true;
				}
				return false;
			case 'suspend':
				$d = isset( $x['days'] ) && absint( $x['days'] ) ? min( 365, absint( $x['days'] ) ) : 7;
				update_user_meta( $uid, 'mrt_banned', 1 );
				update_user_meta( $uid, 'mrsh_ban_until', time() + $d * DAY_IN_SECONDS );
				MRSH_Manage::enforce_ban( $uid );
				return true;
			case 'warn':
				$n = (int) get_user_meta( $uid, 'mrsh_warns', true ) + 1;
				update_user_meta( $uid, 'mrsh_warns', $n );
				self::send_mail( $u, 'A warning about your My Rishta account', "Hello,\n\nWe received a report about your account or profile. Please make sure your details are true and that you follow our rules (respectful messages, real photos, no money requests). This is warning number " . $n . ". Repeated problems can lead to your account being closed." );
				return true;
			case 'drop':
				$snap = (array) get_option( 'mrsh_dropped', array() );
				$meta = array();
				if ( $p ) {
					foreach ( (array) get_post_meta( $p->ID ) as $mk => $mv ) {
						if ( 0 !== strpos( $mk, '_' ) ) {
							$meta[ $mk ] = maybe_unserialize( $mv[0] );
						}
					}
				}
				$snap[] = array( 'time' => time(), 'id' => $uid, 'login' => $u->user_login, 'email' => $u->user_email, 'name' => $u->display_name, 'title' => $p ? $p->post_title : '', 'about' => $p ? $p->post_content : '', 'meta' => $meta );
				update_option( 'mrsh_dropped', array_slice( $snap, -300 ), false );
				if ( ! function_exists( 'wp_delete_user' ) ) {
					require_once ABSPATH . 'wp-admin/includes/user.php';
				}
				$pids = get_posts( array( 'post_type' => 'any', 'author' => $uid, 'post_status' => 'any', 'numberposts' => 50, 'fields' => 'ids' ) );
				foreach ( $pids as $pid ) {
					wp_delete_post( $pid, true );
				}
				$ok = wp_delete_user( $uid );
				MRSH_Manage::purge_member( $uid, 0 );
				return (bool) $ok;
			case 'drop_block':
				if ( class_exists( 'MRSH_PermBan' ) ) {
					MRSH_PermBan::ban( $uid, 'Dropped and blocked by an administrator' ); // remembers the email
				}
				return self::do_one( 'drop', $uid, $x );
			case 'approve':
				if ( $p && ! get_user_meta( $uid, 'mrt_banned', true ) ) {
					wp_update_post( array( 'ID' => $p->ID, 'post_status' => 'publish' ) );
					return true;
				}
				return false;
			case 'reject':
				if ( $p ) {
					wp_update_post( array( 'ID' => $p->ID, 'post_status' => 'draft' ) );
					update_user_meta( $uid, 'mrt_rejected', time() );
					return true;
				}
				return false;
			case 'plan_set':
				$pl = isset( $x['plan'] ) ? sanitize_text_field( $x['plan'] ) : '';
				$d  = isset( $x['days'] ) ? max( 0, min( 3650, absint( $x['days'] ) ) ) : 0;
				if ( '' === $pl ) {
					delete_user_meta( $uid, 'mrt_plan' );
					delete_user_meta( $uid, 'mrt_plan_exp' );
				} else {
					update_user_meta( $uid, 'mrt_plan', $pl );
					$d ? update_user_meta( $uid, 'mrt_plan_exp', time() + $d * DAY_IN_SECONDS ) : delete_user_meta( $uid, 'mrt_plan_exp' );
				}
				delete_user_meta( $uid, 'mrt_plan_req' );
				return true;
			case 'plan_approve':
				$req = (string) get_user_meta( $uid, 'mrt_plan_req', true );
				if ( '' === $req ) {
					return false;
				}
				$d = isset( $x['days'] ) && '' !== $x['days'] ? max( 0, min( 3650, absint( $x['days'] ) ) ) : 30;
				update_user_meta( $uid, 'mrt_plan', $req );
				$d ? update_user_meta( $uid, 'mrt_plan_exp', time() + $d * DAY_IN_SECONDS ) : delete_user_meta( $uid, 'mrt_plan_exp' );
				delete_user_meta( $uid, 'mrt_plan_req' );
				return true;
			case 'plan_reject':
				if ( class_exists( 'MRSH_Orders' ) ) {
					MRSH_Orders::reject_user( $uid );
				}
				delete_user_meta( $uid, 'mrt_plan_req' );
				return true;
			case 'email':
				$s = isset( $x['subject'] ) ? sanitize_text_field( $x['subject'] ) : '';
				$b = isset( $x['message'] ) ? sanitize_textarea_field( $x['message'] ) : '';
				if ( '' === $s || '' === $b ) {
					return false;
				}
				return self::send_mail( $u, $s, $b );
			case 'reset_link':
				$key = get_password_reset_key( $u );
				if ( is_wp_error( $key ) ) {
					return false;
				}
				$url = network_site_url( 'wp-login.php?action=rp&key=' . $key . '&login=' . rawurlencode( $u->user_login ), 'login' );
				return self::send_mail( $u, 'Reset your My Rishta password', "Hello,\n\nYou asked us to help you reset your password. Open this link and choose a new one:\n\n" . $url . "\n\nIf you did not ask for this, you can ignore this email." );
			case 'rename':
				if ( ! $p ) {
					return false;
				}
				$nn = isset( $x['pname'] ) ? trim( sanitize_text_field( $x['pname'] ) ) : '';
				if ( '' === $nn ) {
					$nn = trim( $u->display_name ); // empty box: use the account name
				}
				$nn = mb_substr( $nn, 0, 80 );
				if ( '' === $nn || $nn === $p->post_title ) {
					return false;
				}
				$args = array( 'ID' => $p->ID, 'post_title' => $nn );
				if ( $p->post_name === sanitize_title( $p->post_title ) ) { // the address was made from the old name: follow the new name
					$args['post_name'] = wp_unique_post_slug( sanitize_title( $nn ), $p->ID, $p->post_status, $p->post_type, 0 );
				}
				wp_update_post( $args );
				MRSH_Manage::purge_member( $uid, $p->ID );
				return true;
			case 'note_set':
				$n = isset( $x['note'] ) ? sanitize_textarea_field( $x['note'] ) : '';
				'' === $n ? delete_user_meta( $uid, 'mrsh_desk_note' ) : update_user_meta( $uid, 'mrsh_desk_note', mb_substr( $n, 0, 1000 ) );
				return true;
			case 'remind':
				return self::remind_one( $uid );
			case 'set_pass':
				$pw = isset( $x['pass'] ) ? (string) $x['pass'] : '';
				if ( strlen( $pw ) < ( class_exists( 'MRSH_Shield' ) ? MRSH_Shield::pw_min() : 6 ) ) {
					return false;
				}
				wp_set_password( $pw, $uid );
				return true;
		}
		return false;
	}

	public static function act() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_desk' );
		delete_transient( 'mrsh_cnt' );
		$back = wp_get_referer() ? remove_query_arg( 'msg', wp_get_referer() ) : admin_url( 'admin.php?page=' . self::SLUG );
		$xs   = isset( $_POST['x'] ) && is_array( $_POST['x'] ) ? wp_unslash( $_POST['x'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$jobs = array();
		if ( ! empty( $_POST['row'] ) ) {
			$parts = explode( ':', sanitize_text_field( wp_unslash( $_POST['row'] ) ) );
			if ( 2 === count( $parts ) ) {
				$jobs[] = array( sanitize_key( $parts[0] ), absint( $parts[1] ) );
			}
		} elseif ( ! empty( $_POST['do'] ) && ! empty( $_POST['uids'] ) && is_array( $_POST['uids'] ) ) {
			$do = sanitize_key( wp_unslash( $_POST['do'] ) );
			foreach ( array_slice( array_map( 'absint', wp_unslash( $_POST['uids'] ) ), 0, 200 ) as $id ) { // phpcs:ignore
				$jobs[] = array( $do, $id );
			}
		}
		$bulk = ( isset( $_POST['bulk'] ) && is_array( $_POST['bulk'] ) ) ? array_map( 'wp_unslash', $_POST['bulk'] ) : array(); // phpcs:ignore
		$ok   = 0;
		$bad  = 0;
		foreach ( $jobs as $j ) {
			$data = empty( $_POST['row'] ) ? $bulk : ( $xs[ $j[1] ] ?? array() );
			if ( self::do_one( $j[0], $j[1], is_array( $data ) ? $data : array() ) ) {
				$ok++;
			} else {
				$bad++;
			}
		}
		$m = $jobs ? ( $ok . ' done' . ( $bad ? ', ' . $bad . ' skipped (nothing to change, or details missing)' : '' ) . '.' ) : 'Nothing selected.';
		wp_safe_redirect( add_query_arg( 'msg', rawurlencode( $m ), $back ) );
		exit;
	}

	/* ---------- page ---------- */

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		if ( ! class_exists( 'MRSH_Boost' ) ) {
			echo '<div class="wrap"><h1>Member manager</h1><p>The page styles are missing. Reinstall the plugin zip.</p></div>';
			return;
		}
		$all = self::load();
		$f   = isset( $_GET['f'] ) ? sanitize_key( $_GET['f'] ) : 'all'; // phpcs:ignore
		$f   = isset( self::filters()[ $f ] ) ? $f : 'all';
		$q   = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : ''; // phpcs:ignore
		$so  = isset( $_GET['o'] ) ? sanitize_key( $_GET['o'] ) : ( 'needs' === $f ? 'issues' : 'new' ); // phpcs:ignore
		$pg  = isset( $_GET['pg'] ) ? max( 1, absint( $_GET['pg'] ) ) : 1; // phpcs:ignore

		$cnt = array( 'all' => count( $all ), 'unverified' => 0, 'verified' => 0, 'banned' => 0, 'live' => 0, 'waiting' => 0, 'planreq' => 0, 'expired' => 0, 'planexp' => 0, 'needs' => 0, 'vreq' => 0, 'hreq' => 0 );
		foreach ( $all as $r ) {
			foreach ( array_keys( $cnt ) as $k ) {
				if ( 'all' !== $k && self::match( $r, $k ) ) {
					$cnt[ $k ]++;
				}
			}
		}

		$list = array();
		foreach ( $all as $r ) {
			if ( ! self::match( $r, $f ) ) {
				continue;
			}
			if ( '' !== $q ) {
				$hay = strtolower( $r['name'] . ' ' . $r['login'] . ' ' . $r['email'] . ' ' . $r['ptitle'] . ' #' . $r['id'] );
				if ( false === strpos( $hay, strtolower( $q ) ) ) {
					continue;
				}
			}
			$list[] = $r;
		}
		usort( $list, function ( $a, $b ) use ( $so ) {
			switch ( $so ) {
				case 'old':
					return $a['reg'] <=> $b['reg'];
				case 'seen':
					return $b['seen'] <=> $a['seen'];
				case 'name':
					return strcasecmp( $a['name'], $b['name'] );
				case 'issues':
					return ( self::issues( $b ) <=> self::issues( $a ) ) ?: ( $b['reg'] <=> $a['reg'] );
				case 'score':
					return $a['score'] <=> $b['score'];
				case 'expiry':
					$x = $a['exp'] ?: PHP_INT_MAX;
					$y = $b['exp'] ?: PHP_INT_MAX;
					return $x <=> $y;
			}
			return $b['reg'] <=> $a['reg'];
		} );
		$total = count( $list );
		$pages = max( 1, (int) ceil( $total / self::PER ) );
		$pg    = min( $pg, $pages );
		$rows  = array_slice( $list, ( $pg - 1 ) * self::PER, self::PER );
		$base  = admin_url( 'admin.php?page=' . self::SLUG );
		$plans = self::plans();

		MRSH_Boost::ui_open( 'Member manager', 'Every member in one table. Filter, sort, and act on a member from the same row: verify, block, approve, reject, change plan, send email, reset password.', 'g-blue', 'M16 11a4 4 0 1 0-8 0 4 4 0 0 0 8 0zM4 21a8 8 0 0 1 16 0z' );
		if ( isset( $_GET['msg'] ) ) { // phpcs:ignore
			MRSH_Boost::ui_ok( sanitize_text_field( wp_unslash( $_GET['msg'] ) ) ); // phpcs:ignore
		}
		echo '<div class="mx-stats">';
		echo MRSH_Boost::ui_stat( $cnt['all'], 'Members', '#4a69d6' ) . MRSH_Boost::ui_stat( $cnt['verified'], 'Verified', '#10b981' ) . MRSH_Boost::ui_stat( $cnt['unverified'], 'Not verified', '#f59e0b' ) . MRSH_Boost::ui_stat( $cnt['waiting'], 'Waiting approval', '#7c3aed' ) . MRSH_Boost::ui_stat( $cnt['planreq'], 'Asked for a plan', '#e11d74' ) . MRSH_Boost::ui_stat( $cnt['banned'], 'Blocked', '#e11d48' ) . MRSH_Boost::ui_stat( $cnt['expired'], 'Expired profiles', '#6b7280' ) . MRSH_Boost::ui_stat( $cnt['planexp'], 'Plan expired', '#6b7280' ); // phpcs:ignore
		echo '</div>';

		// filter bar
		echo '<form method="get" class="mx-tabs"><input type="hidden" name="page" value="' . esc_attr( self::SLUG ) . '">';
		echo '<input type="search" name="q" value="' . esc_attr( $q ) . '" placeholder="Name, email or ID" style="min-width:220px"> ';
		echo '<select name="f">';
		foreach ( self::filters() as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $f, $k, false ) . '>' . esc_html( $l ) . ( isset( $cnt[ $k ] ) ? ' (' . (int) $cnt[ $k ] . ')' : '' ) . '</option>';
		}
		echo '</select> <select name="o">';
		foreach ( array( 'new' => 'Newest first', 'old' => 'Oldest first', 'seen' => 'Last seen', 'name' => 'Name A to Z', 'expiry' => 'Plan ends soonest', 'score' => 'Least complete first', 'issues' => 'Most issues first' ) as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $so, $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select> <button class="mx-btn p s">Show</button> <a class="mx-btn s" href="' . esc_url( $base ) . '">Reset</a> <span class="mx-msg" style="margin:0">' . (int) $total . ' shown</span></form>';

		// 3.101.226 tools: automatic reminders (button) and CSV download
		$auto = (int) get_option( 'mrsh_desk_auto', 1 );
		$last = get_option( 'mrsh_desk_last_auto', array() );
		echo '<div class="mx-tabs" style="margin-top:10px;align-items:center"><b>Automatic reminders: ' . ( $auto ? 'ON' : 'OFF' ) . '</b> ';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline">' . wp_nonce_field( 'mrsh_desk_auto', '_wpnonce', true, false ) . '<input type="hidden" name="action" value="mrsh_desk_auto"><input type="hidden" name="to" value="' . ( $auto ? 'off' : 'on' ) . '"><button class="mx-btn s ' . ( $auto ? '' : 'p' ) . '">' . ( $auto ? 'Turn off' : 'Turn on' ) . '</button></form> ';
		echo '<span class="description">Once a day it emails members whose profile is under 60% complete (joined 3+ days ago), at most once every 14 days each, up to 30 emails a day. ' . ( is_array( $last ) && ! empty( $last['time'] ) ? 'Last run: ' . esc_html( human_time_diff( (int) $last['time'] ) ) . ' ago, ' . (int) $last['sent'] . ' sent.' : '' ) . '</span> ';
		echo '<a class="mx-btn s" href="' . esc_url( wp_nonce_url( add_query_arg( array( 'action' => 'mrsh_desk_csv', 'f' => $f, 'q' => $q ), admin_url( 'admin-post.php' ) ), 'mrsh_desk_csv' ) ) . '">Download this list (CSV)</a></div>';

		self::new_panel();
		if ( class_exists( 'MRSH_Noprofile' ) ) {
			MRSH_Noprofile::panel();
		}

		// table inside one form
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'mrsh_desk' );
		echo '<input type="hidden" name="action" value="mrsh_desk_act">';
		echo '<div class="mx-tabs" style="margin-top:10px"><b>With the ticked members:</b> <select name="do"><option value="">Choose...</option>';
		foreach ( array( 'verify' => 'Verify', 'unverify' => 'Remove verified', 'approve' => 'Approve profile', 'reject' => 'Reject (pause profile)', 'ban' => 'Block', 'unban' => 'Unblock', 'permban' => 'Ban for good (keep the record)', 'clearflags' => 'Clear the flags (they are fine)', 'hide' => 'Hide profile (keep account)', 'retire' => 'Retire (hide, keep everything, can return later)', 'unretire' => 'Welcome back (undo retire)', 'feature' => 'Make featured', 'unfeature' => 'Remove featured', 'logout' => 'Sign out everywhere', 'suspend' => 'Suspend for 7 days', 'warn' => 'Send a warning email', 'drop' => 'DROP from site (delete account and profile)', 'drop_block' => 'DROP and block the email for good', 'remind' => 'Send the "Complete your profile" reminder', 'reset_link' => 'Email a password reset link', 'email' => 'Send the email below', 'plan_approve' => 'Approve the plan they asked for', 'helper_ok' => 'Approve as Rishta Agency', 'helper_off' => 'Remove Rishta Agency' ) as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '">' . esc_html( $l ) . '</option>';
		}
		echo '</select> <button class="mx-btn p s">Apply</button></div>';
		echo '<details style="margin:0 0 10px"><summary style="cursor:pointer;font-weight:700">Email to the ticked members</summary><p><input type="text" name="bulk[subject]" placeholder="Subject" style="width:100%;max-width:520px"></p><p><textarea name="bulk[message]" rows="4" placeholder="Message (plain text)" style="width:100%;max-width:520px"></textarea></p><p><label>Days for plan approval <input type="number" name="bulk[days]" min="0" max="3650" value="30" style="width:80px"></label> <span class="description">0 means no end date</span></p></details>';

		echo '<div class="mx-tbl"><table class="widefat striped"><thead><tr><td style="width:28px"><input type="checkbox" onclick="document.querySelectorAll(\'.mrsh-desk-cb\').forEach(function(c){c.checked=this.checked}.bind(this))"></td><th>Member</th><th>Profile</th><th>Plan</th><th>Seen</th><th>Quick actions</th></tr></thead><tbody>';
		if ( ! $rows ) {
			echo '<tr><td colspan="6">Nobody matches this filter.</td></tr>';
		}
		foreach ( $rows as $r ) {
			$id = (int) $r['id'];
			$b  = function ( $do, $label, $cls = '' ) use ( $id ) {
				return '<button type="submit" name="row" value="' . esc_attr( $do . ':' . $id ) . '" class="mx-btn s ' . esc_attr( $cls ) . '">' . esc_html( $label ) . '</button> ';
			};
			$need = $r['flags'] || '' !== $r['req'] || $r['pexp'] || in_array( $r['pst'], array( 'pending', 'draft' ), true );
			echo '<tr data-attn="' . ( $need ? '1' : '0' ) . '">';
			echo '<td><input type="checkbox" class="mrsh-desk-cb" name="uids[]" value="' . $id . '"></td>';
			$ulink = $r['pid'] ? get_permalink( $r['pid'] ) : get_edit_user_link( $id );
			echo '<td><b><a href="' . esc_url( $ulink ) . '" target="_blank" rel="noopener" title="' . ( $r['pid'] ? 'Open profile' : 'Open user (no profile yet)' ) . '">' . esc_html( $r['name'] ) . '</a></b> <span class="description">#' . $id . '</span><br><span class="description">' . esc_html( $r['email'] ) . '</span><br><span class="description">Joined ' . esc_html( wp_date( 'j M Y', $r['reg'] ) ) . '</span>' . ( '' !== $r['note'] ? '<br><span class="mx-pill" style="background:#fef9c3;color:#854d0e" title="' . esc_attr( $r['note'] ) . '">Note: ' . esc_html( mb_substr( $r['note'], 0, 40 ) ) . '</span>' : '' ) . '<br>';
			echo self::issue_chips( $r ) . ( $r['ver'] ? '<span class="mx-pill ok">Verified</span> ' : '<span class="mx-pill">Not verified</span> ' ) . ( $r['ban'] ? '<span class="mx-pill bad">Blocked</span> ' : '' ) . ( $r['flags'] ? '<span class="mx-pill bad" title="' . esc_attr( self::flag_why( $id ) ) . '">' . (int) $r['flags'] . ' flags</span> ' . $b( 'clearflags', 'Clear flags' ) . '<br><span class="description">' . esc_html( self::flag_why( $id ) ) . '</span> ' : '' ) . '<br>' . ( $r['pid'] ? '<a href="' . esc_url( get_permalink( $r['pid'] ) ) . '" target="_blank" rel="noopener">View profile</a> &middot; ' : '' ) . '<a href="' . esc_url( get_edit_user_link( $id ) ) . '" target="_blank" rel="noopener">Edit user</a> &middot; <a href="' . esc_url( add_query_arg( array( 'page' => 'mrsh-activity', 'uid' => $id ), admin_url( 'admin.php' ) ) ) . '">Activity log</a></td>';
			echo '<td>';
			if ( $r['pid'] ) {
				echo '<a href="' . esc_url( get_permalink( $r['pid'] ) ) . '" target="_blank" rel="noopener">' . esc_html( $r['ptitle'] ) . '</a><br><span class="mx-pill">' . esc_html( self::status_label( $r['pst'] ) ) . '</span> <span class="mx-pill ' . ( $r['score'] >= 60 ? 'ok' : 'bad' ) . '">' . (int) $r['score'] . '% complete</span>';
			} else {
				echo '<span class="description">No profile yet</span>';
				$ph = preg_replace( '/\D/', '', (string) get_user_meta( $id, 'mrt_mobile', true ) );
				if ( $ph && class_exists( 'MRSH_Noprofile' ) && get_userdata( $id ) ) {
					echo '<br><a class="mx-btn s" target="_blank" rel="noopener" href="' . esc_url( 'https://wa.me/' . $ph . '?text=' . rawurlencode( MRSH_Noprofile::remind_text( get_userdata( $id ) ) ) ) . '">WhatsApp reminder</a>';
				}
			}
			echo '</td>';
			echo '<td>' . ( $r['plan'] ? '<b>' . esc_html( $r['plan'] ) . '</b>' : '<span class="description">None</span>' );
			if ( $r['exp'] ) {
				echo '<br><span class="description">' . ( $r['pexp'] ? 'Expired ' : 'Ends ' ) . esc_html( wp_date( 'j M Y', $r['exp'] ) ) . '</span>';
			}
			if ( '' !== $r['req'] ) {
				echo '<br><span class="mx-pill" style="background:#fdf2f8;color:#be185d">Asked: ' . esc_html( $r['req'] ) . '</span>';
			}
			echo '</td>';
			echo '<td>' . ( $r['seen'] ? esc_html( human_time_diff( $r['seen'] ) . ' ago' ) : '-' ) . '</td>';
			echo '<td style="min-width:300px">';
			echo $b( $r['ver'] ? 'unverify' : 'verify', $r['ver'] ? 'Remove verified' : 'Verify' ); // phpcs:ignore
			if ( $r['pid'] ) {
				echo ( 'publish' === $r['pst'] ? $b( 'reject', 'Reject', 'd' ) : $b( 'approve', 'Approve' ) ); // phpcs:ignore
			}
			$perm = class_exists( 'MRSH_PermBan' ) && MRSH_PermBan::is_perm( $id );
			if ( $perm ) {
				echo '<span class="mx-pill bad">Banned for good</span> ' . $b( 'unpermban', 'Undo ban for good' ); // phpcs:ignore
			} else {
				echo $b( $r['ban'] ? 'unban' : 'ban', $r['ban'] ? 'Unblock' : 'Block', 'd' ); // phpcs:ignore
				echo '<button type="submit" name="row" value="permban:' . $id . '" class="mx-btn s d" onclick="return confirm(\'Ban this member for good? They can never come back. Their record is kept.\')">Ban for good</button> '; // phpcs:ignore
			}
			echo $b( 'logout', 'Sign out' ); // phpcs:ignore
			echo get_user_meta( $id, 'mrsh_retired', true ) ? '<span class="mx-pill">Retired</span> ' . $b( 'unretire', 'Welcome back' ) : $b( 'retire', 'Retire (keep record)' ); // phpcs:ignore
			if ( $r['pid'] && 'publish' === $r['pst'] ) {
				echo $b( 'hide', 'Hide profile' ) . $b( 'feature', 'Feature' ) . $b( 'unfeature', 'Unfeature' ); // phpcs:ignore
			}
			if ( ! $perm ) {
				echo $b( 'warn', 'Warn' ) . '<input type="number" name="x[' . $id . '][days]" min="1" max="365" placeholder="days" style="width:60px"> ' . $b( 'suspend', 'Suspend' ); // phpcs:ignore
			}
			echo '<button type="submit" name="row" value="drop:' . $id . '" class="mx-btn s d" onclick="return confirm(\'DROP deletes the account AND the profile record. To keep the record so he can come back later, press Retire instead. Delete anyway?\')">Drop from site</button> '; // phpcs:ignore
			echo '<button type="submit" name="row" value="drop_block:' . $id . '" class="mx-btn s d" onclick="return confirm(\'Drop and block their email for good? Account and profile are deleted and they cannot sign up again.\')">Drop + block email</button> '; // phpcs:ignore
			if ( '' !== $r['req'] ) {
				echo $b( 'plan_approve', 'Approve plan' ) . $b( 'plan_reject', 'Decline plan', 'd' ); // phpcs:ignore
			}
			if ( $r['pid'] ) {
				echo '<div style="margin:8px 0 2px"><input type="text" name="x[' . $id . '][pname]" maxlength="80" placeholder="' . esc_attr( 'New profile name (empty = ' . $r['name'] . ')' ) . '" style="width:200px"> ' . $b( 'rename', 'Rename profile' ) . '</div>'; // phpcs:ignore
			}
			echo '<details style="margin-top:6px"><summary style="cursor:pointer;font-weight:700">More: plan, email, password</summary>';
			echo '<p style="margin:8px 0 4px"><b>Plan</b><br><select name="x[' . $id . '][plan]"><option value="">No plan</option>';
			foreach ( $plans as $pl ) {
				echo '<option' . selected( $r['plan'], $pl, false ) . '>' . esc_html( $pl ) . '</option>';
			}
			echo '</select> <input type="number" name="x[' . $id . '][days]" min="0" max="3650" placeholder="days" style="width:80px"> ' . $b( 'plan_set', 'Set plan' ) . '<br><span class="description">Days: how long the plan lasts. Leave empty or 0 for no end date. For "Approve plan", empty means 30 days.</span></p>'; // phpcs:ignore
			echo '<p style="margin:8px 0 4px"><b>Private note</b> <span class="description">(only you see this)</span><br><textarea name="x[' . $id . '][note]" rows="2" maxlength="1000" placeholder="For example: called on 12 Nov, wants verification" style="width:100%">' . esc_textarea( $r['note'] ) . '</textarea><br>' . $b( 'note_set', 'Save note' ) . '</p>';
			if ( class_exists( 'MRSH_Guard' ) ) {
				echo MRSH_Guard::history( (int) $id ); // phpcs:ignore WordPress.Security.EscapeOutput
			}
			$mn = get_userdata( $id );
			echo '<p style="margin:8px 0 4px"><b>Quick email</b><br><select class="mrsh-qe" data-id="' . (int) $id . '" data-name="' . esc_attr( $mn ? $mn->display_name : '' ) . '" style="width:100%"><option value="">Choose a ready email...</option>';
			foreach ( self::email_templates() as $qi => $qt ) {
				echo '<option value="' . (int) $qi . '">' . esc_html( $qt[0] ) . '</option>';
			}
			echo '</select></p>';
			echo '<p style="margin:8px 0 4px"><b>Email this member</b><br><input type="text" name="x[' . $id . '][subject]" placeholder="Subject" style="width:100%"><br><textarea name="x[' . $id . '][message]" rows="3" placeholder="Message" style="width:100%"></textarea><br>' . $b( 'email', 'Send email' ) . '</p>'; // phpcs:ignore
			echo '<p style="margin:8px 0 4px"><b>Password</b><br>' . $b( 'reset_link', 'Email a reset link' ) . '<br><input type="text" name="x[' . $id . '][pass]" placeholder="New password (8+ characters)" autocomplete="off" style="width:60%"> ' . $b( 'set_pass', 'Set password' ) . '</p>'; // phpcs:ignore
			echo '</details></td></tr>';
		}
		echo '<script>(function(){var T=' . wp_json_encode( array_map( function ( $q ) { return array( $q[1], $q[2] ); }, self::email_templates() ) ) . ',S=' . wp_json_encode( get_bloginfo( 'name' ) ) . ';document.addEventListener("change",function(e){var s=e.target;if(!s.classList||!s.classList.contains("mrsh-qe")||s.value==="")return;var t=T[s.value],n=s.dataset.name||"",id=s.dataset.id,r=function(x){return x.replace(/\{name\}/g,n).replace(/\{site\}/g,S)},f=s.closest("td")||document;var a=f.querySelector("[name=\"x["+id+"][subject]\"]"),b=f.querySelector("[name=\"x["+id+"][message]\"]");if(a)a.value=r(t[0]);if(b)b.value=r(t[1])})})();</script>';
		echo '</tbody></table></div></form>';

		if ( $pages > 1 ) {
			echo '<div class="mx-tabs" style="margin:14px 0 0">';
			$from = max( 1, $pg - 4 );
			$to   = min( $pages, $pg + 4 );
			if ( $pg > 1 ) {
				echo '<a class="mx-btn s" href="' . esc_url( add_query_arg( array( 'f' => $f, 'q' => $q, 'o' => $so, 'pg' => $pg - 1 ), $base ) ) . '">Previous</a>';
			}
			for ( $i = $from; $i <= $to; $i++ ) {
				echo '<a class="mx-btn s' . ( $i === $pg ? ' p' : '' ) . '" href="' . esc_url( add_query_arg( array( 'f' => $f, 'q' => $q, 'o' => $so, 'pg' => $i ), $base ) ) . '">' . (int) $i . '</a>';
			}
			if ( $pg < $pages ) {
				echo '<a class="mx-btn s" href="' . esc_url( add_query_arg( array( 'f' => $f, 'q' => $q, 'o' => $so, 'pg' => $pg + 1 ), $base ) ) . '">Next</a>';
			}
			echo '</div>';
		}
		echo '</div>';
	}
}
MRSH_Desk::init();
