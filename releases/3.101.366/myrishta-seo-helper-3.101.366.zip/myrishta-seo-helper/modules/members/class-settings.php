<?php
/**
 * My account → Settings: one tidy place for password, email, two-step login, devices and account deletion.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Settings {

	public static function init() {
		add_action( 'admin_post_mrsh_set_pw', array( __CLASS__, 'save_pw' ) );
		add_action( 'admin_post_mrsh_set_email', array( __CLASS__, 'save_email' ) );
		add_action( 'admin_post_mrsh_set_others', array( __CLASS__, 'logout_others' ) );
		add_action( 'admin_post_mrsh_set_mobile', array( __CLASS__, 'save_mobile' ) );
		add_action( 'admin_post_mrsh_set_chan', array( __CLASS__, 'save_chan' ) );
		add_action( 'mrt_account_extra', array( __CLASS__, 'home_link' ), 60 );
	}

	private static function url( $args = array() ) {
		$base = function_exists( 'mrt_link' ) ? mrt_link( 'myaccount', '/my-account/' ) : home_url( '/my-account/' );
		return add_query_arg( array_merge( array( 'tab' => 'settings' ), $args ), $base );
	}

	private static function back( $args, $hash ) {
		wp_safe_redirect( self::url( $args ) . $hash );
		exit;
	}

	private static function guard( $action ) {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( wp_login_url() );
			exit;
		}
		check_admin_referer( $action );
		return wp_get_current_user();
	}

	private static function pw_ok( $u, $pw ) {
		return '' !== (string) $pw && wp_check_password( (string) $pw, $u->user_pass, $u->ID );
	}

	private static function notify( $u, $to, $subject, $en, $ur ) {
		$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		wp_mail( $to, $subject, 'Assalam o Alaikum ' . ( $u->display_name ?: $u->user_login ) . ",\n\n" . $en . "\n\n" . $ur . "\n\n--\n" . $site . "\n" . home_url( '/' ) );
	}

	public static function save_pw() {
		$u   = self::guard( 'mrsh_set_pw' );
		$cur = isset( $_POST['cur'] ) ? wp_unslash( $_POST['cur'] ) : ''; // phpcs:ignore
		$new = isset( $_POST['new'] ) ? wp_unslash( $_POST['new'] ) : ''; // phpcs:ignore
		$cf  = isset( $_POST['new2'] ) ? wp_unslash( $_POST['new2'] ) : ''; // phpcs:ignore
		if ( ! self::pw_ok( $u, $cur ) ) {
			self::back( array( 'err' => 'pw_cur' ), '#mrsh-pw' );
		}
		if ( strlen( $new ) < 8 ) {
			self::back( array( 'err' => 'pw_short' ), '#mrsh-pw' );
		}
		if ( $new !== $cf ) {
			self::back( array( 'err' => 'pw_match' ), '#mrsh-pw' );
		}
		if ( $new === $cur ) {
			self::back( array( 'err' => 'pw_same' ), '#mrsh-pw' );
		}
		wp_set_password( $new, $u->ID ); // signs out every device
		wp_set_current_user( $u->ID );
		wp_set_auth_cookie( $u->ID, true ); // keeps this device signed in
		self::notify( $u, $u->user_email, 'Your password was changed', 'Your password was just changed. If this was you, nothing more to do. If it was not you, please contact us right away from the Contact page.', 'آپ کا پاس ورڈ ابھی تبدیل ہوا ہے۔ اگر یہ آپ نے کیا تو کچھ کرنے کی ضرورت نہیں۔ اگر آپ نے نہیں کیا تو فوراً رابطہ صفحے سے ہم سے رابطہ کریں۔' );
		self::back( array( 'ok' => 'pw' ), '#mrsh-pw' );
	}

	/** Members may change their email only when the owner has switched it on (Switch mode). */
	public static function email_allowed() {
		return class_exists( 'MRSH_Switch' ) && MRSH_Switch::on( 'emailchange' );
	}

	public static function save_email() {
		$u  = self::guard( 'mrsh_set_email' );
		if ( ! self::email_allowed() ) {
			self::back( array( 'err' => 'em_off' ), '#mrsh-acc' );
		}
		$pw = isset( $_POST['pw'] ) ? wp_unslash( $_POST['pw'] ) : ''; // phpcs:ignore
		$em = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : ''; // phpcs:ignore
		if ( ! self::pw_ok( $u, $pw ) ) {
			self::back( array( 'err' => 'em_pw' ), '#mrsh-em' );
		}
		if ( ! is_email( $em ) ) {
			self::back( array( 'err' => 'em_bad' ), '#mrsh-em' );
		}
		if ( 0 === strcasecmp( $em, $u->user_email ) ) {
			self::back( array( 'err' => 'em_same' ), '#mrsh-em' );
		}
		$ex = email_exists( $em );
		if ( $ex && (int) $ex !== (int) $u->ID ) {
			self::back( array( 'err' => 'em_used' ), '#mrsh-em' );
		}
		$old = $u->user_email;
		$r   = wp_update_user( array( 'ID' => $u->ID, 'user_email' => $em ) );
		if ( is_wp_error( $r ) ) {
			self::back( array( 'err' => 'em_bad' ), '#mrsh-em' );
		}
		self::notify( $u, $old, 'Your email address was changed', 'The email address on your account was changed to ' . $em . '. If this was not you, please contact us right away.', 'آپ کے اکاؤنٹ کا ای میل ایڈریس ' . $em . ' میں تبدیل ہوا ہے۔ اگر یہ آپ نے نہیں کیا تو فوراً ہم سے رابطہ کریں۔' );
		self::back( array( 'ok' => 'email' ), '#mrsh-em' );
	}

	public static function logout_others() {
		$u = self::guard( 'mrsh_set_others' );
		$s = WP_Session_Tokens::get_instance( $u->ID );
		$s->destroy_others( wp_get_session_token() );
		self::back( array( 'ok' => 'others' ), '#mrsh-dev' );
	}

	/** A shortcut on the Home tab. */
	public static function home_link() {
		if ( ! is_user_logged_in() ) {
			return;
		}
		echo '<div class="box"><h3>Account settings / اکاؤنٹ سیٹنگز</h3><p class="sm" style="color:#666">Change your password or email, turn on two-step login, or sign out of other devices.</p><a class="btn" href="' . esc_url( self::url() ) . '">Open settings</a></div>'; // phpcs:ignore
	}

	private static function mask_num( $d ) {
		$d = preg_replace( '/\D/', '', (string) $d );
		return strlen( $d ) > 6 ? '+' . substr( $d, 0, 2 ) . str_repeat( '*', strlen( $d ) - 5 ) . substr( $d, -3 ) : ( '' === $d ? '' : '***' );
	}

	private static function norm_num( $raw ) {
		if ( class_exists( 'MRSH_WhatsApp' ) ) {
			return MRSH_WhatsApp::normalize( $raw );
		}
		return class_exists( 'MRSH_Mobile' ) ? (string) MRSH_Mobile::norm( $raw ) : preg_replace( '/\D/', '', (string) $raw );
	}

	/** Change the mobile number (it is also a login name), with the password. */
	public static function save_mobile() {
		$u  = self::guard( 'mrsh_set_mobile' );
		$pw = isset( $_POST['pw'] ) ? wp_unslash( $_POST['pw'] ) : ''; // phpcs:ignore
		$raw = isset( $_POST['mobile'] ) ? sanitize_text_field( wp_unslash( $_POST['mobile'] ) ) : ''; // phpcs:ignore
		if ( ! self::pw_ok( $u, $pw ) ) {
			self::back( array( 'err' => 'mo_pw' ), '#mrsh-mob' );
		}
		$n = class_exists( 'MRSH_Mobile' ) ? (string) MRSH_Mobile::norm( $raw ) : self::norm_num( $raw );
		if ( '' === $n ) {
			self::back( array( 'err' => 'mo_bad' ), '#mrsh-mob' );
		}
		if ( class_exists( 'MRSH_Mobile' ) ) {
			$o = MRSH_Mobile::user_by( $n );
			if ( $o && (int) $o->ID !== (int) $u->ID ) {
				self::back( array( 'err' => 'mo_used' ), '#mrsh-mob' );
			}
		}
		update_user_meta( $u->ID, 'mrt_mobile', $n );
		delete_user_meta( $u->ID, 'mrt_mobile_ok' ); // the new number is not confirmed yet
		self::back( array( 'ok' => 'mobile' ), '#mrsh-mob' );
	}

	/** Which ways the member is happy to be reached, plus the WhatsApp number and the Telegram name. */
	public static function save_chan() {
		$u = self::guard( 'mrsh_set_chan' );
		update_user_meta( $u->ID, 'mrt_ch_sms', empty( $_POST['sms'] ) ? 0 : 1 );
		update_user_meta( $u->ID, 'mrt_ch_wa', empty( $_POST['wa'] ) ? 0 : 1 );
		update_user_meta( $u->ID, 'mrt_ch_tg', empty( $_POST['tg'] ) ? 0 : 1 );
		$same = ! empty( $_POST['wa_same'] );
		$wa   = isset( $_POST['wa_num'] ) ? sanitize_text_field( wp_unslash( $_POST['wa_num'] ) ) : ''; // phpcs:ignore
		if ( $same || '' === trim( $wa ) ) {
			delete_user_meta( $u->ID, 'mrt_wa_number' );
		} else {
			$n = self::norm_num( $wa );
			if ( '' === $n ) {
				self::back( array( 'err' => 'wa_bad' ), '#mrsh-chan' );
			}
			update_user_meta( $u->ID, 'mrt_wa_number', $n );
		}
		$tg = isset( $_POST['tg_user'] ) ? preg_replace( '/[^A-Za-z0-9_]/', '', ltrim( trim( wp_unslash( $_POST['tg_user'] ) ), '@' ) ) : ''; // phpcs:ignore
		if ( '' !== $tg && ( strlen( $tg ) < 4 || strlen( $tg ) > 32 ) ) {
			self::back( array( 'err' => 'tg_bad' ), '#mrsh-chan' );
		}
		if ( '' === $tg ) {
			delete_user_meta( $u->ID, 'mrt_tg_user' );
		} else {
			update_user_meta( $u->ID, 'mrt_tg_user', $tg );
		}
		self::back( array( 'ok' => 'chan' ), '#mrsh-chan' );
	}

	private static function msg() {
		$ok  = isset( $_GET['ok'] ) ? sanitize_key( wp_unslash( $_GET['ok'] ) ) : ''; // phpcs:ignore
		$err = isset( $_GET['err'] ) ? sanitize_key( wp_unslash( $_GET['err'] ) ) : ''; // phpcs:ignore
		$okm = array( 'pw' => 'Your password was changed.', 'email' => 'Your email address was changed.', 'others' => 'You are now signed out of every other device.', 'mobile' => 'Your mobile number was saved.', 'chan' => 'Your contact choices were saved.' );
		$erm = array(
			'pw_cur'   => 'The current password was not correct.',
			'pw_short' => 'The new password must be at least 8 characters.',
			'pw_match' => 'The two new passwords do not match.',
			'pw_same'  => 'The new password must be different from the current one.',
			'em_pw'    => 'The password was not correct. The email was not changed.',
			'em_bad'   => 'Please type a valid email address.',
			'em_same'  => 'That is already your email address.',
			'em_used'  => 'That email address is used by another account.',
			'em_off'   => 'Changing the email is not available. Please contact us if you need it changed.',
			'mo_pw'    => 'The password was not correct. The number was not changed.',
			'mo_bad'   => 'Please type a valid mobile number, for example 0300 1234567.',
			'mo_used'  => 'That number is already used by another account.',
			'wa_bad'   => 'Please type a valid WhatsApp number.',
			'tg_bad'   => 'A Telegram username has 4 to 32 letters, numbers or underscores.',
		);
		if ( isset( $okm[ $ok ] ) ) {
			return '<div class="box" style="border-left:4px solid #16a34a"><b>' . esc_html( $okm[ $ok ] ) . '</b></div>';
		}
		if ( isset( $erm[ $err ] ) ) {
			return '<div class="box" style="border-left:4px solid #dc2626"><b>' . esc_html( $erm[ $err ] ) . '</b></div>';
		}
		return '';
	}

	/** One settings card: round coloured icon, title (English / Urdu), a short line, then the content. */
	private static function card( $id, $icon, $tone, $en, $ur, $sub, $body, $form = false ) {
		$ic   = function_exists( 'mrt_icon' ) ? mrt_icon( $icon ) : '';
		$tt   = esc_html( $en );
		if ( ! ( function_exists( 'mrt_bi_find' ) && '' !== mrt_bi_find( $en ) ) ) {
			$tt .= ' / <span class="sx-ur" lang="ur" dir="rtl">' . esc_html( $ur ) . '</span>';
		}
		$head = '<div class="sx-h"><span class="sx-ic" style="--t:' . esc_attr( $tone ) . '">' . $ic . '</span><div><div class="sx-t">' . $tt . '</div>' . ( '' !== $sub ? '<div class="sx-s">' . esc_html( $sub ) . '</div>' : '' ) . '</div></div>'; // phpcs:ignore
		if ( is_array( $form ) ) {
			return '<form class="sx-card sx-form" id="' . esc_attr( $id ) . '" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="' . esc_attr( $form[0] ) . '">' . wp_nonce_field( $form[1], '_wpnonce', true, false ) . $head . $body . '</form>'; // phpcs:ignore
		}
		return '<section class="sx-card" id="' . esc_attr( $id ) . '">' . $head . $body . '</section>';
	}

	public static function css() {
		return '<style id="sx-css">
.setx{--sx-ac:var(--a-ac,#9b1b4b);--sx-bd:var(--a-bd,#ebdfcf);--sx-mut:var(--a-mut,#7a6f66);--sx-in:var(--a-in,#fdfaf5)}
.setx .sx-card{display:block;background:#fff;border:1px solid var(--sx-bd);border-radius:22px;padding:20px 22px;margin:0 0 16px;box-shadow:0 10px 30px rgba(90,60,20,.07)}
.setx .sx-form{display:block}
.setx .sx-h{display:flex;align-items:center;gap:13px;margin:0 0 16px}
.setx .sx-ic{flex:none;width:44px;height:44px;border-radius:14px;display:grid;place-items:center;color:#fff;background:linear-gradient(135deg,var(--t),color-mix(in srgb,var(--t) 70%,#000));box-shadow:0 8px 16px color-mix(in srgb,var(--t) 35%,transparent)}
.setx .sx-ic .ic{width:21px;height:21px}
.setx .sx-t{font-weight:750;font-size:1.06rem;line-height:1.3;color:var(--a-ink,#2b2433)}
.setx .sx-ur{font-weight:500;font-size:.86em;color:var(--sx-mut)}
.setx .sx-s{font-size:.86rem;color:var(--sx-mut);margin-top:2px}
.setx .sx-card label{display:block;margin:12px 0 5px;font-weight:650;font-size:.86rem;color:var(--a-ink,#2b2433)}
.setx .sx-card label:has(>input[type=checkbox]),.setx .sx-card label:has(>input[type=radio]){display:flex;align-items:center;gap:10px;font-weight:500;font-size:.95rem;margin:8px 0}
.setx .sx-card input[type=text],.setx .sx-card input[type=tel],.setx .sx-card input[type=email],.setx .sx-card input[type=password]{width:100%;max-width:420px;box-sizing:border-box;height:48px;padding:0 14px;border:1.5px solid var(--sx-bd);border-radius:14px;background:var(--sx-in);font-size:1rem}
.setx .sx-card input:focus{outline:0;border-color:var(--sx-ac);box-shadow:0 0 0 4px color-mix(in srgb,var(--sx-ac) 14%,transparent)}
.setx .sx-card .sm{color:var(--sx-mut);font-size:.9rem;margin:6px 0 10px}
.setx .sx-card .btn{margin-top:12px}
.setx .sx-card .sx-row .btn,.setx .sx-card .sx-acts .btn{margin-top:0}
.setx .sx-acc{display:grid;grid-template-columns:auto 1fr;gap:6px 16px;align-items:center}
.setx .sx-av{grid-row:span 2;width:68px;height:68px;border-radius:50%;display:grid;place-items:center;font-size:1.7rem;font-weight:750;color:#fff;background:linear-gradient(135deg,var(--sx-ac),#6e1230);box-shadow:0 10px 20px rgba(110,18,48,.28)}
.setx .sx-nm{font-size:1.2rem;font-weight:750;color:var(--a-ink,#2b2433);overflow-wrap:anywhere}
.setx .sx-em{color:var(--sx-mut);font-size:.92rem;overflow-wrap:anywhere}
.setx .sx-chips{grid-column:1/-1;display:flex;flex-wrap:wrap;gap:8px;margin:12px 0 4px}
.setx .sx-chip{display:inline-flex;align-items:center;gap:6px;padding:6px 12px;border-radius:99px;background:var(--sx-in);border:1px solid var(--sx-bd);font-size:.82rem;font-weight:650;color:var(--a-ink,#2b2433)}
.setx .sx-chip.gold{background:#fff7e0;border-color:#f3dc9a;color:#8a5a00}
.setx .sx-chip.ok{background:#e9f8ef;border-color:#b6e5c8;color:#0a7a3d}
.setx .sx-rows{grid-column:1/-1;margin-top:6px}
.setx .sx-row{display:flex;justify-content:space-between;gap:14px;padding:11px 0;border-top:1px solid var(--sx-bd);font-size:.93rem}
.setx .sx-row b{font-weight:600;color:var(--sx-mut);flex:none}
.setx .sx-row span{text-align:end;overflow-wrap:anywhere}
.setx .sx-acts{grid-column:1/-1;display:flex;flex-wrap:wrap;gap:10px;margin-top:12px}
.setx .sx-pill{display:inline-flex;align-items:center;gap:7px;padding:7px 14px;border-radius:99px;font-weight:700;font-size:.88rem;margin:0 0 12px}
.setx .sx-pill:before{content:"";width:9px;height:9px;border-radius:50%;background:currentColor}
.setx .sx-pill.on{background:#e9f8ef;color:#0a7a3d}
.setx .sx-pill.off{background:#f1eeea;color:#6b6259}
.setx #mrsh-2fa .mrsh-2fa>form>p>label,.setx #mrsh-2fa .mrsh-2fa form>p>label{display:flex;align-items:flex-start;gap:12px;padding:13px 15px;margin:9px 0;border:1.5px solid var(--sx-bd);border-radius:16px;background:#fff;cursor:pointer;font-weight:600;font-size:.95rem;line-height:1.4}
.setx #mrsh-2fa .mrsh-2fa label:has(input:checked){border-color:var(--sx-ac);background:color-mix(in srgb,var(--sx-ac) 7%,#fff)}
.setx #mrsh-2fa .mrsh-2fa input[type=radio]{width:20px;height:20px;margin:2px 0 0;accent-color:var(--sx-ac);flex:none}
.setx #mrsh-2fa .mrsh-2fa br{display:none}
.setx #mrsh-2fa .mrsh-2fa input[name=wa_phone]{height:42px;margin:4px 0 4px 32px;max-width:260px}
.setx #mrsh-2fa .button{display:inline-flex;align-items:center;justify-content:center;height:46px;padding:0 20px;border-radius:14px;border:1.5px solid var(--sx-bd);background:#fff;color:var(--a-ink,#2b2433);font-weight:700;cursor:pointer;margin:6px 8px 0 0}
.setx #mrsh-2fa .button-primary{background:linear-gradient(135deg,var(--sx-ac),#6e1230);color:#fff;border-color:transparent;box-shadow:0 8px 18px rgba(110,18,48,.25)}
.setx #mrsh-2fa input[name=code]{width:100%;max-width:240px;height:54px;text-align:center;font-size:1.5rem;letter-spacing:.35em;font-weight:700}
.setx #mrsh-2fa pre{background:var(--sx-in);border:1px dashed var(--sx-bd);border-radius:14px;padding:12px 14px}
.setx #mrsh-2fa .mrsh-2fa a[target=_blank]{border-radius:99px!important}
@media(max-width:520px){.setx .sx-card{padding:17px 16px}.setx .sx-row{flex-direction:column;gap:2px}.setx .sx-row span{text-align:start}}
</style>';
	}

	private static function row( $k, $v ) {
		return '<div class="sx-row"><b>' . esc_html( $k ) . '</b><span>' . $v . '</span></div>'; // phpcs:ignore
	}

	private static function edit_button( $uid ) {
		$mine = class_exists( 'MRSH_Members' ) ? MRSH_Members::my_profile( $uid ) : null;
		$add  = function_exists( 'mrt_link' ) ? mrt_link( 'add', '/add-listing/' ) : home_url( '/add-listing/' );
		if ( $mine ) {
			return '<a class="btn" href="' . esc_url( add_query_arg( 'edit', $mine->ID, $add ) ) . '">Edit profile / پروفائل ایڈٹ کریں</a><a class="btn line" href="' . esc_url( get_permalink( $mine ) ) . '">View</a>';
		}
		return '<a class="btn" href="' . esc_url( $add ) . '">Create my profile / پروفائل بنائیں</a>';
	}

	/** The whole Settings tab. */
	public static function render() {
		$u    = wp_get_current_user();
		$plan = (string) get_user_meta( $u->ID, 'mrt_plan', true );
		$name = $u->display_name ?: $u->user_login;
		$ini  = function_exists( 'mb_substr' ) ? mb_strtoupper( mb_substr( $name, 0, 1 ) ) : strtoupper( substr( $name, 0, 1 ) );
		$mob  = (string) get_user_meta( $u->ID, 'mrt_mobile', true );
		$ok1  = get_user_meta( $u->ID, 'mrt_mobile_ok', true );
		$wan  = (string) get_user_meta( $u->ID, 'mrt_wa_number', true );
		$tgu  = (string) get_user_meta( $u->ID, 'mrt_tg_user', true );
		echo self::css() . '<div class="setx">'; // phpcs:ignore
		echo self::msg(); // phpcs:ignore

		// Your account.
		$chips = ( $plan ? '<span class="sx-chip gold">' . esc_html( $plan ) . ' package</span>' : '' ) . '<span class="sx-chip">Member since ' . esc_html( mysql2date( 'M Y', $u->user_registered ) ) . '</span>' . ( get_user_meta( $u->ID, '_mrsh_id_verified', true ) ? '<span class="sx-chip ok">Verified</span>' : '' );
		$rows  = self::row( 'Login name', esc_html( $u->user_login ) ) . self::row( 'Email', esc_html( $u->user_email ) ) . ( '' !== $mob ? self::row( 'Mobile', esc_html( self::mask_num( $mob ) ) ) : '' );
		$note  = '<p class="sm" style="grid-column:1/-1;margin:8px 0 0">' . ( self::email_allowed() ? '' : 'Your email address is fixed for your safety. If it must change, contact us. ' ) . 'To change your name, photo or details, edit your profile.</p>';
		$acc   = '<div class="sx-acc"><div class="sx-av" aria-hidden="true">' . esc_html( $ini ) . '</div><div><div class="sx-nm">' . esc_html( $name ) . '</div><div class="sx-em">' . esc_html( $u->user_email ) . '</div></div><div class="sx-chips">' . $chips . '</div><div class="sx-rows">' . $rows . '</div>' . $note . '<div class="sx-acts">' . self::edit_button( $u->ID ) . '</div></div>';
		echo self::card( 'mrsh-acc', 'user', '#9b1b4b', 'Your account', 'آپ کا اکاؤنٹ', 'Your details at a glance', $acc ); // phpcs:ignore

		// Password.
		$pw = '<label>Current password</label><input type="password" name="cur" autocomplete="current-password" required><label>New password (at least 8 characters)</label><input type="password" name="new" autocomplete="new-password" minlength="8" required><label>Repeat the new password</label><input type="password" name="new2" autocomplete="new-password" minlength="8" required><p class="sm">You stay signed in on this device. We also email you to say it changed.</p><div class="sx-acts"><button class="btn">Change password</button><a href="' . esc_url( wp_lostpassword_url() ) . '">Forgot your current password?</a></div>';
		echo self::card( 'mrsh-pw', 'shield', '#0f9d8a', 'Change password', 'پاس ورڈ تبدیل کریں', 'Use a strong password only you know', $pw, array( 'mrsh_set_pw', 'mrsh_set_pw' ) ); // phpcs:ignore

		// Email (only when the owner switched it on).
		if ( self::email_allowed() ) {
			$em = '<p class="sm">Now: <b>' . esc_html( $u->user_email ) . '</b></p><label>New email address</label><input type="email" name="email" autocomplete="email" required><label>Your password (to confirm)</label><input type="password" name="pw" autocomplete="current-password" required><p class="sm">We send a notice to your old address too.</p><button class="btn">Change email</button>';
			echo self::card( 'mrsh-em', 'mail', '#e8833a', 'Change email', 'ای میل تبدیل کریں', 'We confirm with your password', $em, array( 'mrsh_set_email', 'mrsh_set_email' ) ); // phpcs:ignore
		}

		// Mobile.
		$mo = '<p class="sm">' . ( '' !== $mob ? 'Now: <b>' . esc_html( self::mask_num( $mob ) ) . '</b> ' . ( $ok1 ? '<span class="sx-chip ok">Confirmed</span>' : '<span class="sx-chip">Not confirmed yet</span>' ) : 'No mobile number saved yet.' ) . '<br>You can also log in with it. It is never shown to other members.</p><label>' . ( '' !== $mob ? 'New mobile number' : 'Mobile number' ) . '</label><input type="tel" name="mobile" autocomplete="tel" placeholder="0300 1234567" required><label>Your password (to confirm)</label><input type="password" name="pw" autocomplete="current-password" required><button class="btn">' . ( '' !== $mob ? 'Change number' : 'Save number' ) . '</button>';
		echo self::card( 'mrsh-mob', 'phone', '#d99a00', 'Mobile number', 'موبائل نمبر', 'For login and, soon, codes', $mo, array( 'mrsh_set_mobile', 'mrsh_set_mobile' ) ); // phpcs:ignore

		// SMS, WhatsApp, Telegram.
		$ch = '<p class="sm">Tell us how you would like to be reached. Soon you can get login codes and important notices this way, including two-step login. Until then nothing is sent. Your numbers are never shown or shared.</p><label><input type="checkbox" name="sms" value="1" style="width:auto"' . checked( (bool) get_user_meta( $u->ID, 'mrt_ch_sms', true ), true, false ) . '> SMS on my mobile number</label><label><input type="checkbox" name="wa" value="1" style="width:auto"' . checked( (bool) get_user_meta( $u->ID, 'mrt_ch_wa', true ), true, false ) . '> WhatsApp</label><label><input type="checkbox" name="tg" value="1" style="width:auto"' . checked( (bool) get_user_meta( $u->ID, 'mrt_ch_tg', true ), true, false ) . '> Telegram</label><label>WhatsApp number</label><label><input type="checkbox" name="wa_same" value="1" style="width:auto"' . checked( '' === $wan, true, false ) . '> Same as my mobile number</label><input type="tel" name="wa_num" autocomplete="off" placeholder="' . esc_attr( '' !== $wan ? self::mask_num( $wan ) : 'Another WhatsApp number (optional)' ) . '"><label>Telegram username (optional)</label><input type="text" name="tg_user" maxlength="33" autocomplete="off" placeholder="@username" value="' . esc_attr( $tgu ? '@' . $tgu : '' ) . '"><button class="btn">Save</button>';
		echo self::card( 'mrsh-chan', 'chat', '#1f9d55', 'SMS, WhatsApp and Telegram', 'ایس ایم ایس، واٹس ایپ اور ٹیلی گرام', 'How we may reach you', $ch, array( 'mrsh_set_chan', 'mrsh_set_chan' ) ); // phpcs:ignore

		// Two-step login (its own card).
		if ( class_exists( 'MRSH_TwoFactor' ) ) {
			MRSH_TwoFactor::$back = self::url() . '#mrsh-2fa';
			echo MRSH_TwoFactor::account_box(); // phpcs:ignore
		}

		// Devices.
		$dv = '<p class="sm">You stay signed in on your own phone for 30 days. If you lost a phone or used a shared computer, sign out everywhere else.</p><button class="btn">Sign out of all other devices</button>';
		echo self::card( 'mrsh-dev', 'globe', '#475569', 'Devices', 'ڈیوائسز', 'Where you are signed in', $dv, array( 'mrsh_set_others', 'mrsh_set_others' ) ); // phpcs:ignore

		// Notifications.
		if ( function_exists( 'mrt_icon' ) ) {
			$nt = '<p class="sm">Get an alert on this device for new messages and interests, even when the site is closed.</p><div class="sx-acts"><button type="button" class="btn" data-push>Turn on notifications</button><a href="' . esc_url( add_query_arg( 'tab', 'prefs', self::url() ) ) . '">Weekly match email and who you look for</a></div>';
			echo self::card( 'mrsh-nt', 'heart', '#c0392b', 'Notifications', 'اطلاعات', 'Messages, interests and matches', $nt ); // phpcs:ignore
		}

		// Delete account.
		if ( class_exists( 'MRSH_Delacct' ) ) {
			ob_start();
			MRSH_Delacct::box();
			echo ob_get_clean(); // phpcs:ignore
		}
		echo '</div>';
	}
}
MRSH_Settings::init();
