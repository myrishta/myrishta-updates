<?php
/**
 * Extras: last-seen, hide / block, admin Match Desk + Overview + CSV export, limits setting, PWA (manifest, service worker),
 * theme installer and page creator. No redirect to /app/ when the My Rishta theme is active (the site itself is the app).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Mem_Extras {

	public static function init() {
		add_action( 'init', array( __CLASS__, 'last_seen' ) );
		add_action( 'init', array( __CLASS__, 'pwa_routes' ), 1 );
		add_action( 'wp_ajax_mrt_x', array( __CLASS__, 'ajax' ) );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 27 );
		add_action( 'admin_post_mrt_intro', array( __CLASS__, 'intro' ) );
		add_action( 'admin_post_mrt_vdo', array( __CLASS__, 'vdo' ) );
		add_action( 'admin_post_mrt_approve', array( __CLASS__, 'approve' ) );
		add_action( 'admin_post_mrt_csv', array( __CLASS__, 'csv' ) );
		add_action( 'admin_post_mrt_install_theme', array( __CLASS__, 'install_theme' ) );
		add_action( 'admin_post_mrt_theme_auto', array( __CLASS__, 'save_auto' ) );
		add_action( 'init', array( __CLASS__, 'auto_theme' ), 20 );
		add_action( 'admin_notices', array( __CLASS__, 'notice' ) );
		add_action( 'wp_head', array( __CLASS__, 'head' ), 2 );
		add_action( 'wp_footer', array( __CLASS__, 'sw_register' ), 99 );
		add_action( 'init', function () {
			if ( 'myrishta' === get_template() ) {
				remove_action( 'wp_head', 'mrapp_mobile_redirect', 1 );
			}
		}, 99 );
	}

	/* ---------- last seen (one write per 10 minutes) ---------- */
	public static function last_seen() {
		if ( ! is_user_logged_in() ) {
			return;
		}
		$uid = get_current_user_id();
		$t   = (int) get_user_meta( $uid, 'mrt_seen', true );
		if ( time() - $t > 600 ) {
			update_user_meta( $uid, 'mrt_seen', time() );
		}
	}

	public static function seen_label( $uid ) {
		$t = (int) get_user_meta( $uid, 'mrt_seen', true );
		if ( ! $t ) {
			return '';
		}
		$d = time() - $t;
		if ( $d < 900 ) {
			return 'Online now';
		}
		if ( $d < DAY_IN_SECONDS ) {
			return 'Active today';
		}
		if ( $d < 7 * DAY_IN_SECONDS ) {
			return 'Active this week';
		}
		return '';
	}

	/* ---------- hide / block / report ---------- */
	public static function ajax() {
		check_ajax_referer( 'mrt', 'n' );
		$uid = get_current_user_id();
		if ( ! $uid ) {
			wp_send_json( array( 'ok' => false, 'msg' => 'Please log in first.' ) );
		}
		$act = isset( $_POST['act'] ) ? sanitize_key( wp_unslash( $_POST['act'] ) ) : '';
		if ( 'vreq' === $act ) {
			if ( get_user_meta( $uid, '_mrsh_id_verified', true ) ) {
				wp_send_json( array( 'ok' => true, 'msg' => 'You are already verified.' ) );
			}
			$me  = get_userdata( $uid );
			$em  = $me ? $me->user_email : '';
			if ( get_user_meta( $uid, 'mrt_vreq', true ) ) {
				wp_send_json( array( 'ok' => true, 'msg' => 'Your request is already with our team.' . ( $em ? ' We emailed ' . $em . '. Please check your inbox and Spam folder.' : '' ) ) );
			}
			update_user_meta( $uid, 'mrt_vreq', time() );
			wp_mail( get_option( 'admin_email' ), 'Verification requested', 'User #' . $uid . ' asked to be verified. Review it in My Rishta SEO > Members and matches > Overview.' );
			if ( $em && is_email( $em ) ) {
				$body = 'Assalam o Alaikum ' . $me->display_name . ",\n\nWe received your request to verify your profile.\n\nWhat happens next:\n1. Our team reviews your profile. Please keep your photo and details real and complete.\n2. We may call you on the mobile number in your profile, so keep it correct.\n3. If your account shows a selfie check, please do it in My account, under Trust and membership.\n\nSafety: never send ID photos or money by email or message. We never ask for your password.\n\nOpen your account: " . home_url( '/my-account/' ) . "\n\nMy Rishta Pakistan";
				// Sent straight away, after the answer has gone back to the member, so the page is never held up.
				add_action( 'shutdown', function () use ( $em, $body ) {
					ignore_user_abort( true );
					if ( function_exists( 'litespeed_finish_request' ) ) {
						litespeed_finish_request();
					} elseif ( function_exists( 'fastcgi_finish_request' ) ) {
						fastcgi_finish_request();
					}
					wp_mail( $em, 'Your profile verification request', $body );
				}, 1 );
			}
			wp_send_json( array( 'ok' => true, 'msg' => $em ? 'Email sent to ' . $em . '. Please check your inbox (and Spam) and follow the steps to verify your profile.' : 'Request sent. Our team will contact you.' ) );
		}
		if ( 'savesearch' === $act || 'delsearch' === $act ) {
			$list = array_values( (array) get_user_meta( $uid, 'mrt_searches', true ) );
			$list = array_values( array_filter( $list, 'is_array' ) );
			if ( 'delsearch' === $act ) {
				$i = isset( $_POST['i'] ) ? absint( $_POST['i'] ) : -1;
				unset( $list[ $i ] );
				update_user_meta( $uid, 'mrt_searches', array_values( $list ) );
				wp_send_json( array( 'ok' => true, 'msg' => 'Removed.' ) );
			}
			$q = isset( $_POST['q'] ) ? sanitize_text_field( wp_unslash( $_POST['q'] ) ) : '';
			$q = ltrim( (string) $q, '?' );
			if ( false === strpos( $q, 'post_type=listing_type' ) || count( $list ) >= 10 ) {
				wp_send_json( array( 'ok' => false, 'msg' => count( $list ) >= 10 ? 'You can save up to 10 searches.' : 'Nothing to save.' ) );
			}
			foreach ( $list as $old ) {
				if ( class_exists( 'MRSH_Useful' ) && MRSH_Useful::same_search( $old['q'] ?? '', $q ) ) {
					wp_send_json( array( 'ok' => true, 'msg' => 'This search is already saved.' ) );
				}
			}
			$list[] = array( 'q' => $q, 'd' => current_time( 'mysql' ) );
			update_user_meta( $uid, 'mrt_searches', $list );
			wp_send_json( array( 'ok' => true, 'msg' => 'Search saved in My account.' ) );
		}
		$pid = isset( $_POST['pid'] ) ? absint( $_POST['pid'] ) : 0;
		$p   = $pid ? get_post( $pid ) : null;
		if ( ! $p || 'listing_type' !== $p->post_type ) {
			wp_send_json( array( 'ok' => false, 'msg' => 'Profile not found.' ) );
		}
		if ( 'hide' === $act ) {
			$h   = array_map( 'intval', (array) get_user_meta( $uid, 'mrt_hidden', true ) );
			$h[] = $pid;
			update_user_meta( $uid, 'mrt_hidden', array_values( array_unique( $h ) ) );
			$m = MRSH_Members::my_profile( $uid );
			if ( $m ) {
				foreach ( array( 12, 40 ) as $n ) {
					delete_transient( 'mrt_best_' . $m->ID . '_' . $n );
				}
			}
			wp_send_json( array( 'ok' => true, 'msg' => 'Hidden from your matches.' ) );
		}
		if ( 'block' === $act ) {
			$a = (int) $p->post_author;
			if ( $a === $uid ) {
				wp_send_json( array( 'ok' => false, 'msg' => 'This is your own profile.' ) );
			}
			$b   = array_map( 'intval', (array) get_user_meta( $a, 'blocked', true ) );
			$b[] = $uid;
			update_user_meta( $a, 'blocked', array_values( array_unique( $b ) ) );
			$mb   = (array) get_user_meta( $uid, 'mrt_my_blocks', true );
			$mb[] = array( 'u' => (int) $a, 't' => time() );
			update_user_meta( $uid, 'mrt_my_blocks', array_slice( array_values( array_filter( $mb ) ), -100 ) );
			wp_send_json( array( 'ok' => true, 'msg' => 'Blocked. This member can no longer contact you.' ) );
		}
		if ( 'report' === $act ) {
			$r = (array) get_post_meta( $pid, 'mrt_reports', true );
			if ( in_array( $uid, $r, true ) ) {
				wp_send_json( array( 'ok' => true, 'msg' => 'Already reported. Thank you.' ) );
			}
			$r[] = $uid;
			update_post_meta( $pid, 'mrt_reports', array_values( array_filter( $r ) ) );
			$lg   = array_slice( (array) get_post_meta( $pid, 'mrt_report_log', true ), -40 );
			$lg[] = array( 'u' => $uid, 'r' => sanitize_text_field( wp_unslash( $_POST['reason'] ?? '' ) ), 't' => time() ); // phpcs:ignore
			update_post_meta( $pid, 'mrt_report_log', array_values( array_filter( $lg ) ) );
			$mine   = (array) get_user_meta( $uid, 'mrt_my_reports', true );
			$mine[] = array( 'p' => (int) $pid, 't' => time() );
			update_user_meta( $uid, 'mrt_my_reports', array_slice( array_values( array_filter( $mine ) ), -100 ) );
			$ap = (int) MRSH_Manage::get()['autopause'];
			if ( $ap > 0 && count( array_filter( $r ) ) >= $ap && 'publish' === $p->post_status ) {
				wp_update_post( array( 'ID' => $pid, 'post_status' => 'draft' ) );
			}
			wp_mail( get_option( 'admin_email' ), 'Profile reported: ' . $p->post_title, get_edit_post_link( $pid, 'raw' ) );
			wp_send_json( array( 'ok' => true, 'msg' => 'Reported. Our team will review it.' ) );
		}
		wp_send_json( array( 'ok' => false, 'msg' => 'Unknown action.' ) );
	}

	/* ---------- admin ---------- */
	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Overview', 'Overview', 'manage_options', 'mrsh-overview', array( __CLASS__, 'page_overview' ) );
		add_submenu_page( 'myrishta-seo', 'Match Desk', 'Match Desk', 'manage_options', 'mrsh-matchdesk', array( __CLASS__, 'page_desk' ) );
		add_submenu_page( 'myrishta-seo', 'Theme and App', 'Theme and App', 'manage_options', 'mrsh-theme', array( __CLASS__, 'page_theme' ) );
	}

	private static function count( $status ) {
		$c = wp_count_posts( 'listing_type' );
		return isset( $c->$status ) ? (int) $c->$status : 0;
	}

	public static function page_overview() {
		$u   = count_users();
		$new = (int) ( new WP_User_Query( array( 'date_query' => array( array( 'after' => '1 day ago' ) ), 'count_total' => true, 'fields' => 'ID', 'number' => 1 ) ) )->get_total();
		$msg = wp_count_posts( 'ppt_message' );
		$pend = get_posts( array( 'post_type' => 'listing_type', 'post_status' => array( 'pending', 'pending_approval' ), 'numberposts' => 20 ) );
		$rep  = get_posts( array( 'post_type' => 'listing_type', 'post_status' => array( 'publish', 'draft' ), 'numberposts' => 10, 'meta_key' => 'mrt_reports', 'meta_compare' => 'EXISTS' ) );
		echo '<div class="wrap"><h1>Overview</h1><p class="mrx-q"><a class="button button-primary" href="' . esc_url( admin_url( 'admin.php?page=mrsh-profiles' ) ) . '">Approve profiles</a> <a class="button" href="' . esc_url( admin_url( 'admin.php?page=mrsh-users' ) ) . '">Members</a> <a class="button" href="' . esc_url( admin_url( 'admin.php?page=mrsh-msgs' ) ) . '">Messages</a> <a class="button" href="' . esc_url( admin_url( 'admin.php?page=mrsh-theme' ) ) . '">Theme and App</a> <a class="button" href="' . esc_url( home_url( '/' ) ) . '" target="_blank" rel="noopener">View site</a></p><style>.mrx{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin:14px 0}.mrx div{background:#fff;border:1px solid #e3e6ee;border-radius:14px;padding:14px}.mrx b{font-size:26px;display:block}.mrx span{color:#667}</style><div class="mrx">';
		$cards = array( 'Members' => $u['total_users'], 'New today' => $new, 'Live profiles' => self::count( 'publish' ), 'Waiting approval' => self::count( 'pending' ) + self::count( 'pending_approval' ), 'Paused' => self::count( 'draft' ), 'Messages' => isset( $msg->publish ) ? (int) $msg->publish : 0 );
		foreach ( $cards as $k => $v ) {
			echo '<div><b>' . (int) $v . '</b><span>' . esc_html( $k ) . '</span></div>';
		}
		echo '</div><h2>Waiting for approval</h2>';
		if ( ! $pend ) {
			echo '<p>Nothing waiting.</p>';
		}
		foreach ( $pend as $p ) {
			$url = wp_nonce_url( admin_url( 'admin-post.php?action=mrt_approve&pid=' . $p->ID ), 'mrt_approve' . $p->ID );
			echo '<p><b>' . esc_html( $p->post_title ) . '</b> (#' . (int) $p->ID . ') <a class="button" href="' . esc_url( $url ) . '">Approve</a> <a href="' . esc_url( get_edit_post_link( $p->ID ) ) . '">Open</a></p>';
		}
		echo '<h2>Verification requests</h2>';
		$vr = get_users( array( 'meta_key' => 'mrt_vreq', 'meta_compare' => 'EXISTS', 'number' => 30 ) );
		if ( ! $vr ) {
			echo '<p>No requests.</p>';
		}
		foreach ( $vr as $u ) {
			$mk = function ( $do ) use ( $u ) {
				return wp_nonce_url( admin_url( 'admin-post.php?action=mrt_vdo&uid=' . $u->ID . '&do=' . $do ), 'mrt_vdo' . $u->ID );
			};
			echo '<p><b>' . esc_html( $u->display_name ) . '</b> (' . esc_html( $u->user_email ) . ') asked ' . esc_html( human_time_diff( (int) get_user_meta( $u->ID, 'mrt_vreq', true ) ) ) . ' ago <a class="button" href="' . esc_url( $mk( 'yes' ) ) . '">Mark verified</a> <a class="button" href="' . esc_url( $mk( 'no' ) ) . '">Decline</a></p>';
		}
		echo '<h2>Reported profiles</h2>';
		if ( ! $rep ) {
			echo '<p>No reports.</p>';
		}
		foreach ( $rep as $p ) {
			echo '<p><b>' . esc_html( $p->post_title ) . '</b> - ' . count( array_filter( (array) get_post_meta( $p->ID, 'mrt_reports', true ) ) ) . ' report(s), status ' . esc_html( $p->post_status ) . ' <a href="' . esc_url( get_edit_post_link( $p->ID ) ) . '">Open</a></p>';
		}
		echo '<h2>Tools</h2><p><a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mrt_csv' ), 'mrt_csv' ) ) . '">Download profiles CSV (no phone numbers)</a></p></div>';
	}

	public static function vdo() {
		$id = isset( $_GET['uid'] ) ? absint( $_GET['uid'] ) : 0;
		if ( ! current_user_can( 'manage_options' ) || ! $id ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrt_vdo' . $id );
		if ( isset( $_GET['do'] ) && 'yes' === $_GET['do'] ) {
			update_user_meta( $id, '_mrsh_id_verified', time() );
		}
		if ( ! ( isset( $_GET['do'] ) && 'yes' === $_GET['do'] ) && class_exists( 'MRSH_Mem_Mail' ) && ( $uu = get_userdata( $id ) ) ) { // phpcs:ignore
			MRSH_Mem_Mail::send( $uu->user_email, 'unverified', array( 'name' => $uu->display_name, 'link' => MRSH_Mem_Mail::acct() ) );
		}
		delete_user_meta( $id, 'mrt_vreq' );
		delete_transient( 'mrsh_verified_map' );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-overview' ) );
		exit;
	}

	public static function approve() {
		$id = isset( $_GET['pid'] ) ? absint( $_GET['pid'] ) : 0;
		if ( ! current_user_can( 'manage_options' ) || ! $id ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrt_approve' . $id );
		wp_update_post( array( 'ID' => $id, 'post_status' => 'publish' ) );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-overview' ) );
		exit;
	}

	public static function csv() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrt_csv' );
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=profiles-' . gmdate( 'Y-m-d' ) . '.csv' );
		$o = fopen( 'php://output', 'w' );
		fputcsv( $o, array( 'ID', 'Name', 'Status', 'Age', 'Gender', 'Religion', 'Education', 'Occupation', 'Country', 'Date' ) );
		$ids = get_posts( array( 'post_type' => 'listing_type', 'post_status' => 'any', 'numberposts' => 5000, 'fields' => 'ids' ) );
		foreach ( $ids as $id ) {
			$c = wp_get_object_terms( $id, 'country', array( 'fields' => 'names', 'number' => 1 ) );
			fputcsv( $o, array( $id, get_the_title( $id ), get_post_status( $id ), get_post_meta( $id, 'daage', true ), MRSH_Match::gender( $id ), MRSH_Match::val( $id, 'religion', 'custom-18' ), MRSH_Match::val( $id, 'education', 'custom-2322' ), MRSH_Match::val( $id, 'occupation', 'custom-24' ), is_wp_error( $c ) || ! $c ? '' : $c[0], get_the_date( 'Y-m-d', $id ) ) );
		}
		exit;
	}

	/** Admin helper: pick a profile, see its best matches, send an introduction email to both families. */
	public static function page_desk() {
		echo '<div class="wrap"><h1>Match Desk</h1><form method="get"><input type="hidden" name="page" value="mrsh-matchdesk"><p>Profile ID or name: <input name="q" value="' . esc_attr( isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : '' ) . '"> <button class="button button-primary">Find matches</button></p></form>'; // phpcs:ignore
		$q = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : '';
		if ( '' !== $q ) {
			$a = ctype_digit( $q ) ? get_post( (int) $q ) : null;
			if ( ! $a ) {
				$f = get_posts( array( 'post_type' => 'listing_type', 's' => $q, 'numberposts' => 1, 'post_status' => 'publish' ) );
				$a = $f ? $f[0] : null;
			}
			if ( ! $a || 'listing_type' !== $a->post_type ) {
				echo '<p>No profile found.</p></div>';
				return;
			}
			delete_transient( 'mrt_best_' . $a->ID . '_20' );
			echo '<h2>' . esc_html( $a->post_title ) . ', ' . (int) get_post_meta( $a->ID, 'daage', true ) . '</h2><table class="widefat striped"><thead><tr><th>Match</th><th>Profile</th><th>Why</th><th>Both ways</th><th></th></tr></thead><tbody>';
			foreach ( MRSH_Match::best( $a, 20, 40 ) as $m ) {
				$back = MRSH_Match::score( $m['post'], $a );
				$url  = wp_nonce_url( admin_url( 'admin-post.php?action=mrt_intro&a=' . $a->ID . '&b=' . $m['post']->ID ), 'mrt_intro' . $a->ID . '_' . $m['post']->ID );
				echo '<tr><td><b>' . (int) $m['pct'] . '%</b></td><td><a href="' . esc_url( get_edit_post_link( $m['post']->ID ) ) . '">' . esc_html( $m['post']->post_title ) . '</a>, ' . (int) get_post_meta( $m['post']->ID, 'daage', true ) . '</td><td>' . esc_html( implode( ', ', $m['why'] ) ) . '</td><td>' . (int) $back[0] . '%</td><td><a class="button" href="' . esc_url( $url ) . '" onclick="return confirm(\'Send an introduction email to both members?\')">Introduce</a></td></tr>';
			}
			echo '</tbody></table>';
		}
		if ( isset( $_GET['sent'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success"><p>Introduction sent.</p></div>';
		}
		echo '</div>';
	}

	public static function intro() {
		$a = isset( $_GET['a'] ) ? absint( $_GET['a'] ) : 0;
		$b = isset( $_GET['b'] ) ? absint( $_GET['b'] ) : 0;
		if ( ! current_user_can( 'manage_options' ) || ! $a || ! $b ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrt_intro' . $a . '_' . $b );
		foreach ( array( array( $a, $b ), array( $b, $a ) ) as $pair ) {
			$me = get_post( $pair[0] );
			$ot = get_post( $pair[1] );
			$u  = $me ? get_userdata( $me->post_author ) : null;
			if ( $u && $ot ) {
				wp_mail( $u->user_email, 'A suggested match for you', "Assalam o Alaikum,\n\nOur team thinks this profile may suit you:\n" . get_the_title( $ot ) . ' - ' . get_permalink( $ot ) . "\n\nIf you like it, send your interest from the profile page. Never send money to anyone you meet online.\n\n" . get_bloginfo( 'name' ) );
			}
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-matchdesk&q=' . $a . '&sent=1' ) );
		exit;
	}

	/* ---------- theme installer, pages ---------- */
	public static function theme_dir() {
		return MRSH_DIR . 'theme/myrishta';
	}

	public static function theme_version( $dir ) {
		$css = $dir . '/style.css';
		if ( is_readable( $css ) && preg_match( '/Version:\s*([0-9.]+)/', (string) file_get_contents( $css, false, null, 0, 800 ), $m ) ) { // phpcs:ignore
			return $m[1];
		}
		return '';
	}

	public static function notice() {
		if ( ! current_user_can( 'switch_themes' ) || ! is_dir( self::theme_dir() ) ) {
			return;
		}
		$inst = self::theme_version( get_theme_root() . '/myrishta' );
		$mine = self::theme_version( self::theme_dir() );
		if ( 'myrishta' === get_template() && $inst === $mine ) {
			return;
		}
		echo '<div class="notice notice-info"><p><b>My Rishta theme</b> is included in this plugin. <a class="button button-primary" href="' . esc_url( admin_url( 'admin.php?page=mrsh-theme' ) ) . '">Open Theme and App</a></p></div>';
	}

	public static function page_theme() {
		$inst = self::theme_version( get_theme_root() . '/myrishta' );
		$mine = self::theme_version( self::theme_dir() );
		echo '<div class="wrap"><h1>Theme and App</h1><p>Theme in this plugin: <b>' . esc_html( $mine ? $mine : 'missing' ) . '</b>. Installed: <b>' . esc_html( $inst ? $inst : 'not installed' ) . '</b>. Active: <b>' . esc_html( wp_get_theme()->get( 'Name' ) ) . '</b></p>';
		if ( isset( $_GET['done'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success"><p>Done. Open the website and check it.</p></div>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrt_install_theme">';
		wp_nonce_field( 'mrt_install_theme' );
		echo '<p><label><input type="checkbox" name="activate" value="1"> Also switch the website to the My Rishta theme</label></p><p><label><input type="checkbox" name="pages" value="1" checked> Create the pages it needs (My account, Add profile, Matches) if they do not exist</label></p><p><button class="button button-primary">Install or update theme</button></p></form>';
		if ( function_exists( 'mrt_photo_source' ) ) {
			echo '<h2>Photo check</h2><p class="description">Where the newest profiles get their photo from. "local" = file is on this site. "live" = borrowed from the live site (test copies). "address" = old picture link, may be broken. "none" = no photo found.</p><table class="widefat striped" style="max-width:900px"><thead><tr><th>Profile</th><th>Source</th><th>Picture address</th></tr></thead><tbody>';
			$q = get_posts( array( 'post_type' => 'listing_type', 'post_status' => 'any', 'numberposts' => 12, 'orderby' => 'date', 'order' => 'DESC' ) );
			foreach ( $q as $pp ) {
				$src = mrt_photo_source( $pp->ID );
				echo '<tr><td>' . esc_html( get_the_title( $pp ) ) . ' (#' . (int) $pp->ID . ')</td><td><b>' . esc_html( $src[0] ) . '</b></td><td style="word-break:break-all">' . esc_html( $src[1] ) . '</td></tr>';
			}
			echo '</tbody></table><p class="description">Photo borrowing from: <b>' . esc_html( mrt_remote_host() ? mrt_remote_host() : 'off (local files only)' ) . '</b></p>';
		}
		$last = (string) get_option( 'mrsh_theme_auto_last', '' );
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin:14px 0;padding:12px 14px;background:#f0f6ff;border-radius:12px"><input type="hidden" name="action" value="mrt_theme_auto">';
		wp_nonce_field( 'mrt_theme_auto' );
		echo '<p style="margin:0"><label><input type="checkbox" name="auto" value="1"' . checked( get_option( 'mrsh_theme_auto', '1' ), '1', false ) . '> <b>Update the theme automatically</b> whenever I update this plugin</label> <button class="button">Save</button></p>' . ( $last ? '<p class="description">Last automatic update: ' . esc_html( $last ) . '</p>' : '' ) . '</form>';
		echo '<p>Going back is safe: choose your old theme in Appearance > Themes. No profile, user, message or setting is changed by the theme.</p></div>';
	}

	/** Keep the installed theme in step with the plugin: when the plugin ships a newer theme, copy it over by itself. */
	public static function auto_theme() {
		if ( '0' === get_option( 'mrsh_theme_auto', '1' ) || get_transient( 'mrsh_theme_lock' ) ) {
			return;
		}
		$inst = self::theme_version( get_theme_root() . '/myrishta' );
		$mine = self::theme_version( self::theme_dir() );
		if ( ! $inst || ! $mine || version_compare( $inst, $mine, '>=' ) ) {
			return; // not installed on purpose, or already current
		}
		set_transient( 'mrsh_theme_lock', 1, 300 );
		self::copy_dir( self::theme_dir(), get_theme_root() . '/myrishta' );
		delete_transient( 'mrsh_verified_map' );
		do_action( 'litespeed_purge_all' );
		if ( function_exists( 'wp_cache_flush' ) ) {
			wp_cache_flush();
		}
		update_option( 'mrsh_theme_auto_last', $mine . ' on ' . gmdate( 'Y-m-d H:i' ) . ' UTC', false );
	}

	public static function save_auto() {
		if ( ! current_user_can( 'switch_themes' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrt_theme_auto' );
		update_option( 'mrsh_theme_auto', empty( $_POST['auto'] ) ? '0' : '1' );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-theme&done=1' ) );
		exit;
	}

	private static function copy_dir( $from, $to ) {
		wp_mkdir_p( $to );
		foreach ( scandir( $from ) as $f ) {
			if ( '.' === $f || '..' === $f ) {
				continue;
			}
			is_dir( "$from/$f" ) ? self::copy_dir( "$from/$f", "$to/$f" ) : copy( "$from/$f", "$to/$f" );
		}
	}

	public static function install_theme() {
		if ( ! current_user_can( 'switch_themes' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrt_install_theme' );
		self::copy_dir( self::theme_dir(), get_theme_root() . '/myrishta' );
		if ( ! empty( $_POST['pages'] ) ) {
			self::make_pages();
		}
		if ( ! empty( $_POST['activate'] ) ) {
			switch_theme( 'myrishta' );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-theme&done=1' ) );
		exit;
	}

	public static function make_pages() {
		$want = array(
			'my-account'  => array( 'My account', 'page-my-account.php', 'myaccount' ),
			'add-listing' => array( 'Add your profile', 'page-add-listing.php', 'add' ),
		);
		$links = get_option( 'core_admin_values' );
		foreach ( $want as $slug => $d ) {
			$p = get_page_by_path( $slug );
			if ( ! $p ) {
				$id = wp_insert_post( array( 'post_title' => $d[0], 'post_name' => $slug, 'post_type' => 'page', 'post_status' => 'publish', 'post_content' => '' ) );
				if ( $id && ! is_wp_error( $id ) ) {
					update_post_meta( $id, '_wp_page_template', $d[1] );
				}
			} elseif ( ! get_post_meta( $p->ID, '_wp_page_template', true ) || 'default' === get_post_meta( $p->ID, '_wp_page_template', true ) ) {
				// Existing page from the old theme keeps its address and gets the new template.
				update_post_meta( $p->ID, '_wp_page_template', $d[1] );
			}
		}
	}

	/* ---------- PWA ---------- */
	public static function pwa_routes() {
		$u = isset( $_SERVER['REQUEST_URI'] ) ? wp_parse_url( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH ) : ''; // phpcs:ignore
		$u = untrailingslashit( (string) $u );
		$b = untrailingslashit( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ) );
		if ( $u === $b . '/mr-manifest.json' ) {
			header( 'Content-Type: application/manifest+json; charset=utf-8' );
			$col = ( class_exists( 'MRSH_Site' ) && MRSH_Site::get( 'c1' ) ) ? MRSH_Site::get( 'c1' ) : '#e11d74';
			$ic  = self::icon_url();
			$sc  = function ( $n, $path ) use ( $ic ) {
				return array( 'name' => $n, 'short_name' => $n, 'url' => home_url( $path ), 'icons' => array( array( 'src' => MRSH_Mem_Polish::u( 'icon-96.png' ), 'sizes' => '96x96', 'type' => 'image/png' ) ) );
			};
			echo wp_json_encode( array(
				'id' => home_url( '/' ), 'name' => get_bloginfo( 'name' ), 'short_name' => 'My Rishta', 'description' => 'Free rishta service for Pakistani families. Find matches, send interest and message safely.',
				'start_url' => home_url( '/?pwa=1' ), 'scope' => home_url( '/' ), 'display' => 'standalone', 'orientation' => 'portrait', 'lang' => 'en', 'dir' => 'auto',
				'background_color' => '#fff7fa', 'theme_color' => $col, 'categories' => array( 'lifestyle', 'social' ),
				'icons' => array(
					array( 'src' => MRSH_Mem_Polish::u( 'icon-192.png' ), 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any' ),
					array( 'src' => get_site_icon_url( 512 ) ? $ic : MRSH_Mem_Polish::u( 'icon-512.png' ), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any' ),
					array( 'src' => MRSH_Mem_Polish::u( 'maskable-192.png' ), 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'maskable' ),
					array( 'src' => MRSH_Mem_Polish::u( 'maskable-512.png' ), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'maskable' ),
				),
				'shortcuts' => array(
					$sc( 'Search', '/?post_type=listing_type&s=&pwa=1' ),
					$sc( 'Matches', '/my-account/?tab=matches&pwa=1' ),
					$sc( 'Messages', '/my-account/?tab=messages&pwa=1' ),
					$sc( 'My profile', '/add-listing/?pwa=1' ),
				),
			) );
			exit;
		}
		if ( $u === $b . '/mr-sw.js' ) {
			header( 'Content-Type: application/javascript; charset=utf-8' );
			header( 'Service-Worker-Allowed: ' . home_url( '/' ) );
			header( 'Cache-Control: no-cache' );
			$v = 'mr-' . ( defined( 'MRSH_VERSION' ) ? MRSH_VERSION : '1' );
			echo 'var V=' . wp_json_encode( $v ) . ';var OFF=' . wp_json_encode( '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Offline</title><body style="margin:0;font-family:system-ui,sans-serif;text-align:center;padding:18vh 24px;background:#fff7fa;color:#1f2937"><div style="font-size:56px">&#128246;</div><h2 style="margin:8px 0">You are offline</h2><p style="color:#6b7280">Check your internet connection. Pages you opened before may still work.</p><button onclick="location.reload()" style="margin-top:14px;border:0;border-radius:12px;padding:12px 22px;background:#e11d74;color:#fff;font-weight:700;font-size:1rem">Try again</button>' ) . ";\n";
			echo 'var AJ=' . wp_json_encode( admin_url( 'admin-ajax.php' ) ) . ';var IC=' . wp_json_encode( self::icon_url() ) . ';';
			echo <<<'SWJS'
var HOME='/__mr_home_shell';
function lin(t){return /<body[^>]*\blogged-in\b/.test(t)?'1':'0'}
function tell(){return self.clients.matchAll({type:'window'}).then(function(l){l.forEach(function(c){c.postMessage({mr:'home-changed'})})})}
self.addEventListener('install',function(e){e.waitUntil(caches.open(V).then(function(c){return fetch('/?pwa=1',{credentials:'same-origin'}).then(function(r){if(r&&r.ok&&!r.redirected)return c.put(HOME,r)}).catch(function(){})}).then(function(){return self.skipWaiting()}))});
function homeFast(e){var r=e.request;return caches.open(V).then(function(c){return c.match(HOME).then(function(m){
var upd=Promise.resolve(e.preloadResponse).then(function(p){return p||fetch(r)}).then(function(res){if(res&&res.ok&&res.type==='basic'&&!res.redirected){var a=res.clone(),b=res.clone();return b.text().then(function(t){var done=m?m.clone().text().then(function(o){return lin(o)!==lin(t)}):Promise.resolve(false);return done.then(function(ch){return c.put(HOME,a).then(function(){if(ch)tell();return res})})})}return res}).catch(function(){return null});
e.waitUntil(upd);
if(m)return m;
return upd.then(function(res){return res||new Response(OFF,{headers:{'Content-Type':'text/html; charset=utf-8'}})})})})}
self.addEventListener('activate',function(e){e.waitUntil((self.registration.navigationPreload?self.registration.navigationPreload.enable().catch(function(){}):Promise.resolve()).then(function(){return caches.keys()}).then(function(k){return Promise.all(k.filter(function(n){return n.indexOf('mr-')===0&&n!==V}).map(function(n){return caches.delete(n)}))}).then(function(){return self.clients.claim()}))});
function skip(u,r){return r.method!=='GET'||/wp-admin|wp-login|admin-ajax|wp-json|\/mr-sw|preview=|wc-api/.test(u.pathname+u.search)}
self.addEventListener('fetch',function(e){var r=e.request,u=new URL(r.url);if(u.origin!==location.origin||skip(u,r))return;
if(r.mode==='navigate'&&u.pathname==='/'&&(u.search===''||u.search==='?pwa=1')){e.respondWith(homeFast(e));return}
if(r.mode==='navigate'){e.respondWith(fetch(r).then(function(res){if(res.ok&&res.type==='basic'&&!/my-account|add-listing/.test(u.pathname)){var c=res.clone();caches.open(V).then(function(h){h.put(r,c)})}return res}).catch(function(){return caches.match(r).then(function(m){return m||new Response(OFF,{headers:{'Content-Type':'text/html; charset=utf-8'}})})}));return}
if(/\.(css|js|woff2?|ttf)$/.test(u.pathname)){e.respondWith(caches.match(r).then(function(m){var f=fetch(r).then(function(res){if(res.ok){var c=res.clone();caches.open(V).then(function(h){h.put(r,c)})}return res}).catch(function(){return m});return m||f}));return}
if(/\.(png|jpe?g|webp|gif|svg|avif)$/.test(u.pathname)){e.respondWith(caches.open(V).then(function(h){return h.match(r).then(function(m){var f=fetch(r).then(function(res){if(res.ok)h.put(r,res.clone());return res}).catch(function(){return m});return m||f})}))}});
self.addEventListener('push',function(e){e.waitUntil(fetch(AJ+'?action=mrt_notif',{credentials:'same-origin'}).then(function(r){return r.json()}).catch(function(){return {}}).then(function(d){return self.registration.showNotification(d.title||'My Rishta',{body:d.body||'You have new activity on your profile.',icon:IC,badge:IC,tag:'mrt',data:{url:d.url||'/'}})}))});
self.addEventListener('notificationclick',function(e){e.notification.close();var u=(e.notification.data&&e.notification.data.url)||'/';e.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(function(l){for(var i=0;i<l.length;i++){if('focus' in l[i]){l[i].navigate(u);return l[i].focus()}}return clients.openWindow(u)}))});
SWJS;
			exit;
		}
	}

	private static function icon_url() {
		$i = get_site_icon_url( 512 );
		return $i ? $i : MRSH_Mem_Polish::u( 'icon-512.png' );
	}

	public static function head() {
		if ( 'myrishta' !== get_template() ) {
			return;
		}
		echo '<link rel="manifest" href="' . esc_url( home_url( '/mr-manifest.json' ) ) . '"><meta name="theme-color" content="#e11d74"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-title" content="My Rishta"><meta name="apple-mobile-web-app-status-bar-style" content="default"><link rel="apple-touch-icon" href="' . esc_url( self::icon_url() ) . '">' . "\n";
	}

	public static function sw_register() {
		if ( 'myrishta' !== get_template() ) {
			return;
		}
		// The app updates itself: a new plugin/theme version means a new service worker. The page checks for it when the app is opened or comes back to the front, and once an hour.
		echo '<script>(function(){if(!("serviceWorker" in navigator))return;var had=!!navigator.serviceWorker.controller,go=false;
function bar(){if(document.getElementById("mr-upd"))return;var d=document.createElement("div");d.id="mr-upd";d.setAttribute("style","position:fixed;left:12px;right:12px;bottom:78px;z-index:99999;background:#1f2937;color:#fff;border-radius:14px;padding:12px 14px;display:flex;gap:10px;align-items:center;justify-content:space-between;font:600 14px system-ui,sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.3)");d.innerHTML="<span>New version ready<br><small style=\"font-weight:400;opacity:.8\">نیا ورژن تیار ہے</small></span><button type=\"button\" style=\"border:0;border-radius:99px;padding:9px 16px;background:#e11d74;color:#fff;font:700 14px system-ui\">Update / اپڈیٹ</button>";d.querySelector("button").onclick=function(){location.reload()};document.body.appendChild(d)}
navigator.serviceWorker.register(' . wp_json_encode( home_url( '/mr-sw.js' ) ) . ',{scope:"/"}).then(function(r){
function chk(){try{r.update()}catch(e){}}
document.addEventListener("visibilitychange",function(){if(document.visibilityState==="visible"){if(go){location.reload();return}chk()}else if(go){}});
setInterval(chk,3600000);chk()}).catch(function(){});
navigator.serviceWorker.addEventListener("controllerchange",function(){if(!had){had=true;return}go=true;if(document.visibilityState==="hidden"){return}bar()})})();</script>';
	}
}
MRSH_Mem_Extras::init();
