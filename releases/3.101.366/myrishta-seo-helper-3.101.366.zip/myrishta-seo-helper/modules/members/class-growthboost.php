<?php
/**
 * Growth boosters. Every feature is OFF until switched on at Growth > Growth boosters,
 * so they can be applied later without another upload.
 *  1. WhatsApp share button on a profile (never includes a phone number).
 *  2. Success stories: public page plus a moderated submit form (stories wait for approval).
 *  3. Profile completeness meter on My Account.
 *
 * @package MyRishta_SEO_Helper
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Growthboost {
	const OPT = 'mrsh_boost';

	public static function get() {
		return array_merge( array( 'share' => 0, 'share_who' => 'owner', 'stories' => 0, 'meter' => 0, 'invite' => 0 ), (array) get_option( self::OPT, array() ) );
	}

	public static function init() {
		add_action( 'init', array( __CLASS__, 'cpt' ) );
		add_action( 'init', array( __CLASS__, 'maybe_page' ), 40 );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 31 );
		add_action( 'admin_post_mrsh_boost_save', array( __CLASS__, 'save' ) );
		add_action( 'mrt_profile_after', array( __CLASS__, 'share' ), 8 );
		add_action( 'mrt_account_extra', array( __CLASS__, 'meter' ), 12 );
		add_action( 'init', array( __CLASS__, 'ref_cookie' ) );
		add_action( 'user_register', array( __CLASS__, 'ref_save' ) );
		add_action( 'mrt_account_extra', array( __CLASS__, 'invite' ), 13 );
		add_action( 'admin_post_nopriv_mrsh_story', array( __CLASS__, 'submit' ) );
		add_action( 'admin_post_mrsh_story', array( __CLASS__, 'submit' ) );
	}

	/* ---------- 1. WhatsApp share ---------- */
	public static function share( $pid ) {
		$o = self::get();
		if ( empty( $o['share'] ) ) {
			return;
		}
		$p = get_post( $pid ? $pid : get_the_ID() );
		if ( ! $p || 'publish' !== $p->post_status ) {
			return;
		}
		if ( 'owner' === $o['share_who'] && (int) $p->post_author !== get_current_user_id() ) {
			return;
		}
		$txt = 'Rishta profile on ' . get_bloginfo( 'name' ) . ' (free, phone numbers stay private): ' . get_permalink( $p );
		echo '<div class="wrap" style="margin:10px auto"><a class="btn" style="background:#16a34a;color:#fff;border-radius:99px;padding:12px 20px;display:inline-block;font-weight:700;text-decoration:none" target="_blank" rel="noopener" href="' . esc_url( 'https://wa.me/?text=' . rawurlencode( $txt ) ) . '">Share this profile on WhatsApp</a></div>'; // phpcs:ignore
	}

	/* ---------- 2. Success stories ---------- */
	public static function cpt() {
		register_post_type( 'mrsh_story', array(
			'labels'       => array( 'name' => 'Success stories', 'singular_name' => 'Success story' ),
			'public'       => false,
			'show_ui'      => true,
			'menu_icon'    => 'dashicons-heart',
			'supports'     => array( 'title', 'editor' ),
			'show_in_menu' => true,
		) );
	}

	public static function maybe_page() {
		if ( empty( self::get()['stories'] ) || get_option( 'mrsh_stories_page' ) ) {
			return;
		}
		$ex = get_page_by_path( 'success-stories' );
		if ( $ex ) {
			update_option( 'mrsh_stories_page', (int) $ex->ID, false );
			return;
		}
		$id = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => 'Success Stories', 'post_name' => 'success-stories', 'post_content' => '[mrsh_stories]' ) );
		if ( $id && ! is_wp_error( $id ) ) {
			update_option( 'mrsh_stories_page', (int) $id, false );
		}
	}

	/** The thank-you message and the submit form (used by the Success Stories page, MRSH_Hub::stories). */
	public static function form_html() {
		if ( empty( self::get()['stories'] ) ) {
			return '';
		}
		$o   = '';
		$msg = isset( $_GET['story'] ) ? sanitize_key( wp_unslash( $_GET['story'] ) ) : ''; // phpcs:ignore
		if ( 'ok' === $msg ) {
			$o .= '<div class="ss-ok"><b>Thank you!</b> Your story will appear after our team reads it and you are happy with it.</div>';
		} elseif ( $msg ) {
			$o .= '<div class="ss-bad">Please fill every field (the story needs at least 40 characters) and tick the consent box, then try again.</div>';
		}
		$o .= '<form class="ss-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
			. '<input type="hidden" name="action" value="mrsh_story">' . wp_nonce_field( 'mrsh_story', '_wpnonce', true, false )
			. '<input name="who" placeholder="First names only, e.g. Ayesha &amp; Bilal" maxlength="80" required>'
			. '<input name="city" placeholder="City" maxlength="60" required>'
			. '<textarea name="story" rows="5" maxlength="1200" placeholder="How did you meet and what would you tell others?" required></textarea>'
			. '<input name="website" tabindex="-1" autocomplete="off" style="position:absolute;left:-9999px" aria-hidden="true">'
			. '<label class="ss-c"><input type="checkbox" name="ok" value="1" required> I agree this story may be published on this website. I will not include phone numbers or addresses.</label>'
			. '<button type="submit">Send my story</button></form>';
		return $o;
	}

	public static function submit() {
		$back = wp_get_referer() ? remove_query_arg( 'story', wp_get_referer() ) : home_url( '/success-stories/' );
		$go   = function ( $r ) use ( $back ) {
			wp_safe_redirect( add_query_arg( 'story', $r, $back ) );
			exit;
		};
		if ( empty( self::get()['stories'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ?? '' ) ), 'mrsh_story' ) || ! empty( $_POST['website'] ) ) { // phpcs:ignore
			$go( 'bad' );
		}
		$ip  = md5( isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '' ); // phpcs:ignore
		$key = 'mrsh_st_' . $ip;
		if ( get_transient( $key ) ) {
			$go( 'bad' );
		}
		$who   = sanitize_text_field( wp_unslash( $_POST['who'] ?? '' ) ); // phpcs:ignore
		$city  = sanitize_text_field( wp_unslash( $_POST['city'] ?? '' ) ); // phpcs:ignore
		$story = sanitize_textarea_field( wp_unslash( $_POST['story'] ?? '' ) ); // phpcs:ignore
		if ( ! $who || ! $city || strlen( $story ) < 40 || empty( $_POST['ok'] ) ) { // phpcs:ignore
			$go( 'bad' );
		}
		// Phone numbers are never published.
		$story = preg_replace( '/\+?\d[\d\s\-]{8,}\d/', '[number removed]', $story );
		wp_insert_post( array( 'post_type' => 'mrsh_story', 'post_status' => 'pending', 'post_title' => $who . ', ' . $city, 'post_content' => $story ) );
		set_transient( $key, 1, HOUR_IN_SECONDS );
		$go( 'ok' );
	}

	/* ---------- 3. Profile completeness ---------- */
	public static function meter( $uid ) {
		if ( class_exists( 'MRSH_Mem_More5' ) || empty( self::get()['meter'] ) ) { // one strength box only (the round graph)
			return;
		}
		$q = get_posts( array( 'post_type' => 'listing_type', 'author' => (int) $uid, 'post_status' => array( 'publish', 'pending', 'draft' ), 'posts_per_page' => 1, 'no_found_rows' => true ) );
		if ( ! $q ) {
			return;
		}
		$p     = $q[0];
		$meta  = 0;
		foreach ( (array) get_post_meta( $p->ID ) as $k => $v ) {
			if ( '_' !== substr( $k, 0, 1 ) && '' !== trim( (string) ( $v[0] ?? '' ) ) ) {
				$meta++;
			}
		}
		$steps = array(
			array( 'Add a clear profile photo', has_post_thumbnail( $p ) ),
			array( 'Write a short about-me (30+ words)', str_word_count( wp_strip_all_tags( $p->post_content ) ) >= 30 ),
			array( 'Fill in your details (8+ fields)', $meta >= 8 ),
		);
		$done = count( array_filter( array_column( $steps, 1 ) ) );
		$pct  = (int) round( $done / count( $steps ) * 100 );
		echo '<div class="wrap" style="margin:14px auto"><div style="background:#fff;border:1px solid #e5d9c4;border-radius:14px;padding:16px"><b>Profile strength: ' . (int) $pct . '%</b><div style="height:8px;background:#eee;border-radius:99px;margin:8px 0"><div style="height:8px;width:' . (int) $pct . '%;background:#12a375;border-radius:99px"></div></div>'; // phpcs:ignore
		foreach ( $steps as $s ) {
			echo '<div>' . ( $s[1] ? '&#10003; ' : '&#9675; ' ) . esc_html( $s[0] ) . '</div>'; // phpcs:ignore
		}
		echo '</div></div>';
	}

	/* ---------- 4. Invite family and friends ---------- */
	public static function ref_cookie() {
		if ( empty( self::get()['invite'] ) || empty( $_GET['mrref'] ) || headers_sent() ) { // phpcs:ignore
			return;
		}
		$id = absint( wp_unslash( $_GET['mrref'] ) ); // phpcs:ignore
		if ( $id ) {
			setcookie( 'mrsh_ref', (string) $id, time() + 30 * DAY_IN_SECONDS, COOKIEPATH ? COOKIEPATH : '/', '', is_ssl(), true );
		}
	}

	public static function ref_save( $uid ) {
		if ( empty( self::get()['invite'] ) || empty( $_COOKIE['mrsh_ref'] ) ) {
			return;
		}
		$r = absint( wp_unslash( $_COOKIE['mrsh_ref'] ) );
		if ( $r && $r !== (int) $uid && get_userdata( $r ) ) {
			update_user_meta( $uid, 'mrsh_ref_by', $r );
		}
	}

	public static function invite( $uid ) {
		if ( empty( self::get()['invite'] ) || ! $uid ) {
			return;
		}
		$n    = count( get_users( array( 'meta_key' => 'mrsh_ref_by', 'meta_value' => (int) $uid, 'fields' => 'ID', 'number' => 500 ) ) ); // phpcs:ignore
		$link = add_query_arg( 'mrref', (int) $uid, home_url( '/' ) );
		$txt  = 'Free and safe rishta service for Pakistani families: ' . $link;
		echo '<div class="wrap" style="margin:14px auto"><div style="background:#fff;border:1px solid #e5d9c4;border-radius:14px;padding:16px"><b>Invite family and friends</b><p style="margin:6px 0">Share ' . esc_html( get_bloginfo( 'name' ) ) . ' with someone looking for a rishta. It is free. Joined through your link so far: <b>' . (int) $n . '</b></p><a target="_blank" rel="noopener" style="background:#16a34a;color:#fff;border-radius:99px;padding:11px 18px;display:inline-block;font-weight:700;text-decoration:none" href="' . esc_url( 'https://wa.me/?text=' . rawurlencode( $txt ) ) . '">Invite on WhatsApp</a></div></div>'; // phpcs:ignore
	}

	/* ---------- admin ---------- */
	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Growth boosters', 'Growth boosters', 'manage_options', 'mrsh-boost', array( __CLASS__, 'page' ) );
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'mrsh_boost' ) ) {
			wp_die( 'Not allowed.' );
		}
		$o = array(
			'share'     => empty( $_POST['share'] ) ? 0 : 1, // phpcs:ignore
			'share_who' => ( isset( $_POST['share_who'] ) && 'all' === $_POST['share_who'] ) ? 'all' : 'owner', // phpcs:ignore
			'stories'   => empty( $_POST['stories'] ) ? 0 : 1, // phpcs:ignore
			'meter'     => empty( $_POST['meter'] ) ? 0 : 1, // phpcs:ignore
			'invite'    => empty( $_POST['invite'] ) ? 0 : 1, // phpcs:ignore
		);
		update_option( self::OPT, $o, false );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-boost&ok=1' ) );
		exit;
	}

	public static function page() {
		$o = self::get();
		$n = wp_count_posts( 'mrsh_story' );
		echo '<div class="wrap"><h1>Growth boosters</h1>';
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success"><p>Saved. Clear the cache so visitors see the change.</p></div>';
		}
		echo '<p>Everything here is off until you switch it on. Nothing changes on the live site before that.</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_boost_save">';
		wp_nonce_field( 'mrsh_boost' );
		echo '<table class="form-table">';
		echo '<tr><th>WhatsApp share button</th><td><label><input type="checkbox" name="share" value="1" ' . checked( $o['share'], 1, false ) . '> Show a "Share this profile on WhatsApp" button</label><br>Who sees it: <select name="share_who"><option value="owner" ' . selected( $o['share_who'], 'owner', false ) . '>Only the profile owner (safest)</option><option value="all" ' . selected( $o['share_who'], 'all', false ) . '>Every visitor</option></select><p class="description">The shared message holds only the profile link, never a phone number.</p></td></tr>';
		echo '<tr><th>Success stories</th><td><label><input type="checkbox" name="stories" value="1" ' . checked( $o['stories'], 1, false ) . '> Create the /success-stories/ page with a submit form</label><p class="description">New stories wait as Pending under "Success stories" in the admin menu. Publish only real, approved ones. Waiting for approval: <b>' . (int) ( $n->pending ?? 0 ) . '</b>, published: <b>' . (int) ( $n->publish ?? 0 ) . '</b>.</p></td></tr>';
		echo '<tr><th>Profile strength meter</th><td><label><input type="checkbox" name="meter" value="1" ' . checked( $o['meter'], 1, false ) . '> Show members a progress bar on My Account</label></td></tr>';
		echo '<tr><th>Invite family and friends</th><td><label><input type="checkbox" name="invite" value="1" ' . checked( $o['invite'], 1, false ) . '> Show members a WhatsApp invite link on My Account and count who joined through it</label><p class="description">No rewards are given. It only counts sign-ups.</p></td></tr>';
		echo '</table><p><button class="button button-primary">Save</button></p></form></div>';
	}
}

MRSH_Growthboost::init();
