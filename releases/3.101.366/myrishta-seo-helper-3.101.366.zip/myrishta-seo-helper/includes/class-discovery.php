<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Finds new phrases from data the site owner really has: visitor searches on the site,
 * a Search Console export, and the site's own content. It never asks Google for suggestions
 * and never adds anything to the bank without the owner choosing it.
 */
class MRSH_Discovery {

	const OPT        = 'mrsh_custom_keywords';
	const SEARCH_LOG = 'mrsh_search_log';

	public static function init() {
		add_action( 'template_redirect', array( __CLASS__, 'log_search' ), 20 );
		add_action( 'mrsh_weekly_scan', array( __CLASS__, 'run_scan' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
	}

	/* ---------------- Custom phrases ---------------- */

	/** Weekly automatic scan of the site's own content. */
	public static function schedule() {
		$on   = ! empty( MRSH_Options::get()['auto_discover'] );
		$next = wp_next_scheduled( 'mrsh_weekly_scan' );
		if ( $on && ! $next ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'weekly', 'mrsh_weekly_scan' );
		} elseif ( ! $on && $next ) {
			wp_unschedule_event( $next, 'mrsh_weekly_scan' );
		}
	}

	public static function run_scan() {
		if ( empty( MRSH_Options::get()['auto_discover'] ) ) {
			return 0;
		}
		$terms = array();
		foreach ( array_slice( self::content_candidates( self::site_posts() ), 0, 20 ) as $c ) {
			$terms[] = $c['term'];
		}
		$added = self::add( $terms );
		update_option( 'mrsh_last_scan', array( 'time' => time(), 'added' => $added ), false );
		return $added;
	}

	public static function custom_rows() {
		$rows = get_option( self::OPT, array() );
		return is_array( $rows ) ? $rows : array();
	}

	public static function add( $terms ) {
		$cur  = self::custom_rows();
		$max  = 1000;
		$have = array();
		foreach ( MRSH_Keywords::all() as $r ) {
			$max = max( $max, (int) $r['n'] );
			foreach ( MRSH_Keywords::variants( $r ) as $v ) {
				$have[ $v ] = true;
			}
		}
		$added = 0;
		foreach ( (array) $terms as $t ) {
			$t   = trim( preg_replace( '/\s+/u', ' ', sanitize_text_field( (string) $t ) ) );
			$key = mb_strtolower( $t );
			if ( mb_strlen( $t ) < 3 || mb_strlen( $t ) > 80 || isset( $have[ $key ] ) ) {
				continue;
			}
			$urdu  = (bool) preg_match( '/\p{Arabic}/u', $t );
			$cur[] = array(
				'n'         => ++$max,
				'list'      => 'Discovered',
				'group'     => 'Discovered',
				'urdu'      => $urdu ? $t : '',
				'roman'     => $urdu ? '' : $key,
				'treatment' => 'Target',
				'use'       => 'Review and assign a page',
				'priority'  => 'Medium',
			);
			$have[ $key ] = true;
			$added++;
		}
		if ( $added ) {
			update_option( self::OPT, $cur, false );
			MRSH_Keywords::flush();
		}
		return $added;
	}

	public static function remove( $n ) {
		$cur = array();
		foreach ( self::custom_rows() as $r ) {
			if ( (int) $r['n'] !== (int) $n ) {
				$cur[] = $r;
			}
		}
		update_option( self::OPT, $cur, false );
		MRSH_Keywords::flush();
	}

	/* ---------------- Source 1: visitor searches ---------------- */

	/** Stores the search words only: no IP address, user or time per visit. Site admins are skipped. */
	public static function log_search() {
		if ( is_admin() || ! is_search() || is_paged() || current_user_can( 'manage_options' ) ) {
			return;
		}
		$term = mb_strtolower( trim( preg_replace( '/\s+/u', ' ', (string) get_search_query( false ) ) ) );
		if ( mb_strlen( $term ) < 3 || mb_strlen( $term ) > 60 || 'mrsh-check' === $term ) {
			return;
		}
		// Drop anything that looks personal: emails, links, phone-like numbers.
		if ( false !== strpos( $term, '@' ) || false !== strpos( $term, 'http' ) || preg_match( '/\d{6,}/', $term ) ) {
			return;
		}
		$log = get_option( self::SEARCH_LOG, array() );
		$log = is_array( $log ) ? $log : array();
		if ( isset( $log[ $term ] ) ) {
			$log[ $term ]['count']++;
			$log[ $term ]['last'] = time();
		} else {
			if ( count( $log ) >= 500 ) {
				uasort(
					$log,
					function ( $a, $b ) {
						return $a['count'] - $b['count'] ?: $a['last'] - $b['last'];
					}
				);
				array_shift( $log );
			}
			$log[ $term ] = array( 'count' => 1, 'last' => time() );
		}
		update_option( self::SEARCH_LOG, $log, false );
	}

	public static function search_rows() {
		$log = get_option( self::SEARCH_LOG, array() );
		$log = is_array( $log ) ? $log : array();
		$out = array();
		foreach ( $log as $term => $d ) {
			$out[] = array( 'term' => (string) $term, 'count' => (int) $d['count'], 'last' => (int) $d['last'] );
		}
		usort(
			$out,
			function ( $a, $b ) {
				return $b['count'] - $a['count'];
			}
		);
		return $out;
	}

	/* ---------------- Source 2: Search Console export ---------------- */

	/** Parse the "Queries" CSV from Search Console > Performance > Export. */
	public static function parse_csv( $text ) {
		$text  = preg_replace( '/^\xEF\xBB\xBF/', '', (string) $text );
		$lines = preg_split( '/\R/', $text );
		if ( ! $lines || '' === trim( $lines[0] ) ) {
			return array();
		}
		$delim = ',';
		foreach ( array( "\t", ';' ) as $d ) {
			if ( substr_count( $lines[0], $d ) > substr_count( $lines[0], $delim ) ) {
				$delim = $d;
			}
		}
		$header = str_getcsv( array_shift( $lines ), $delim );
		$col    = array( 'clicks' => null, 'impressions' => null, 'position' => null );
		foreach ( $header as $i => $h ) {
			$h = mb_strtolower( trim( $h ) );
			foreach ( $col as $k => $v ) {
				if ( null === $v && false !== strpos( $h, $k ) ) {
					$col[ $k ] = $i;
				}
			}
		}
		$out = array();
		foreach ( $lines as $line ) {
			if ( '' === trim( $line ) ) {
				continue;
			}
			$f = str_getcsv( $line, $delim );
			$q = trim( isset( $f[0] ) ? $f[0] : '' );
			if ( '' === $q || mb_strlen( $q ) > 80 ) {
				continue;
			}
			$num   = function ( $i, $dec ) use ( $f ) {
				if ( null === $i || ! isset( $f[ $i ] ) ) {
					return null;
				}
				return (float) str_replace( $dec ? ',' : ',', $dec ? '.' : '', (string) $f[ $i ] );
			};
			$out[] = array(
				'term'        => $q,
				'clicks'      => $num( $col['clicks'], false ),
				'impressions' => $num( $col['impressions'], false ),
				'position'    => $num( $col['position'], true ),
			);
			if ( count( $out ) >= 300 ) {
				break;
			}
		}
		return $out;
	}

	/* ---------------- Source 3: the site's own content ---------------- */

	private static $seeds = array( 'rishta', 'rishte', 'rishtay', 'shadi', 'shaadi', 'nikah', 'nikkah', 'larki', 'larka', 'dulhan', 'dulha', 'bahu', 'mangni', 'jahez', 'walima', 'rukhsati', 'رشتہ', 'شادی', 'نکاح', 'لڑکی', 'لڑکا', 'دلہن', 'دولہا' );
	private static $stop  = array( 'the', 'a', 'an', 'in', 'on', 'of', 'for', 'to', 'and', 'or', 'is', 'are', 'with', 'your', 'you', 'our', 'we', 'at', 'by', 'from', 'this', 'that', 'it', 'as', 'be', 'can', 'how', 'what', 'ka', 'ki', 'ke', 'ko', 'se', 'mein', 'main', 'hai', 'hain', 'aur', 'ya' );

	/** Two and three word phrases around rishta-related words that appear on 2+ pages and are not in the bank. */
	public static function content_candidates( $posts ) {
		$bank = array();
		foreach ( MRSH_Keywords::all() as $r ) {
			foreach ( MRSH_Keywords::variants( $r ) as $v ) {
				$bank[ $v ] = true;
			}
		}
		$count = array();
		foreach ( $posts as $p ) {
			$words = preg_split( '/[^\p{L}\p{N}]+/u', mb_strtolower( wp_strip_all_tags( $p->post_title . ' ' . $p->post_content ) ), -1, PREG_SPLIT_NO_EMPTY );
			$seen  = array();
			$n     = count( $words );
			for ( $i = 0; $i < $n; $i++ ) {
				for ( $len = 2; $len <= 3 && $i + $len <= $n; $len++ ) {
					$gram = array_slice( $words, $i, $len );
					if ( in_array( $gram[0], self::$stop, true ) || in_array( $gram[ $len - 1 ], self::$stop, true ) || ! array_intersect( $gram, self::$seeds ) ) {
						continue;
					}
					$phrase = implode( ' ', $gram );
					if ( mb_strlen( $phrase ) < 5 || isset( $bank[ $phrase ] ) ) {
						continue;
					}
					$seen[ $phrase ] = true;
				}
			}
			foreach ( $seen as $phrase => $_ ) {
				$count[ $phrase ] = isset( $count[ $phrase ] ) ? $count[ $phrase ] + 1 : 1;
			}
		}
		$out = array();
		foreach ( $count as $phrase => $c ) {
			if ( $c >= 2 ) {
				$out[] = array( 'term' => $phrase, 'pages' => $c );
			}
		}
		usort(
			$out,
			function ( $a, $b ) {
				return $b['pages'] - $a['pages'];
			}
		);
		return array_slice( $out, 0, 30 );
	}

	public static function site_posts() {
		$o     = MRSH_Options::get();
		$skip  = array_merge( array( 'attachment' ), MRSH_Options::to_list( $o['noindex_post_types'] ) );
		$types = array_values( array_diff( array_keys( get_post_types( array( 'public' => true ) ) ), $skip ) );
		return get_posts( array( 'post_type' => $types, 'post_status' => 'publish', 'numberposts' => 300, 'suppress_filters' => true ) );
	}
}
