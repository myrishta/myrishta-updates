<?php
/**
 * Two-step login: authenticator app (Google / Microsoft Authenticator or any TOTP app)
 * or a one-time code by email. Each member chooses; admins can require it per role.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_TwoFactor {

	const OPT      = 'mrsh_2fa_settings';
	const M_METHOD = '_mrsh2fa_method';   // '', 'app', 'email'
	const M_SECRET = '_mrsh2fa_secret';   // encrypted base32 secret
	const M_PEND   = '_mrsh2fa_pending';  // secret waiting for first code
	const M_LAST   = '_mrsh2fa_last';     // last used time step (replay guard)
	const M_BACKUP = '_mrsh2fa_backup';   // hashed one-time backup codes
	const M_WA     = '_mrsh2fa_wa';       // confirmed WhatsApp number (digits), private to the member
	const M_WAP    = '_mrsh2fa_wa_pend';  // number + code hash waiting for the member to confirm
	const M_TG     = '_mrsh2fa_tg';       // linked Telegram chat id, private to the member
	const M_TGP    = '_mrsh2fa_tg_pend';  // one-time Telegram link waiting to be used

	/* ---------- settings ---------- */

	public static function settings() {
		$d = array(
			'enabled'  => 1,
			'required' => array(),
			'issuer'   => 'MyRishta',
			'ttl'      => 10,
			'social_skip'   => 1,
			'remember_days' => 0,
			'allow_app'     => 1,
			'allow_email'   => 1,
			'allow_wa'      => 1,
			'allow_tg'      => 1,
			'max_tries'     => 5,
		);
		$s = get_option( self::OPT, array() );
		return is_array( $s ) ? array_merge( $d, $s ) : $d;
	}

	public static function init() {
		// The settings screens must always exist, otherwise 2FA could never be switched back on once off.
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 20 );
		add_action( 'admin_post_mrsh_2fa_settings', array( __CLASS__, 'save_settings' ) );
		add_action( 'admin_post_mrsh_2fa_reset', array( __CLASS__, 'reset_member' ) );
		if ( ! self::settings()['enabled'] ) {
			return;
		}
		add_filter( 'authenticate', array( __CLASS__, 'note_password' ), 999, 3 );
		add_action( 'wp_login', array( __CLASS__, 'intercept' ), 1, 2 );
		add_action( 'login_form_mrsh2fa', array( __CLASS__, 'challenge' ) );
		add_action( 'show_user_profile', array( __CLASS__, 'profile' ) );
		add_action( 'edit_user_profile', array( __CLASS__, 'profile_admin' ) );
		add_action( 'admin_post_mrsh_2fa', array( __CLASS__, 'save' ) );
		add_shortcode( 'mrsh_2fa', array( __CLASS__, 'shortcode' ) );
	}

	/* ---------- crypto helpers (pure, testable) ---------- */

	const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

	public static function b32_encode( $bin ) {
		$bits = '';
		foreach ( str_split( $bin ) as $c ) {
			$bits .= str_pad( decbin( ord( $c ) ), 8, '0', STR_PAD_LEFT );
		}
		$out = '';
		foreach ( str_split( $bits, 5 ) as $chunk ) {
			$out .= self::B32[ bindec( str_pad( $chunk, 5, '0' ) ) ];
		}
		return $out;
	}

	public static function b32_decode( $str ) {
		$str  = strtoupper( preg_replace( '/[^A-Za-z2-7]/', '', $str ) );
		$bits = '';
		foreach ( str_split( $str ) as $c ) {
			$bits .= str_pad( decbin( strpos( self::B32, $c ) ), 5, '0', STR_PAD_LEFT );
		}
		$out = '';
		foreach ( str_split( $bits, 8 ) as $byte ) {
			if ( 8 === strlen( $byte ) ) {
				$out .= chr( bindec( $byte ) );
			}
		}
		return $out;
	}

	public static function new_secret() {
		return self::b32_encode( random_bytes( 20 ) );
	}

	public static function totp( $secret, $step = null, $digits = 6 ) {
		$step = null === $step ? (int) floor( time() / 30 ) : (int) $step;
		$key  = self::b32_decode( $secret );
		$msg  = pack( 'N2', $step >> 32, $step & 0xFFFFFFFF );
		$hash = hash_hmac( 'sha1', $msg, $key, true );
		$off  = ord( $hash[19] ) & 0x0F;
		$bin  = ( ( ord( $hash[ $off ] ) & 0x7F ) << 24 ) | ( ord( $hash[ $off + 1 ] ) << 16 ) | ( ord( $hash[ $off + 2 ] ) << 8 ) | ord( $hash[ $off + 3 ] );
		return str_pad( (string) ( $bin % pow( 10, $digits ) ), $digits, '0', STR_PAD_LEFT );
	}

	/** Returns the matched time step (int) or false. Accepts one step either side for clock drift. */
	public static function totp_check( $secret, $code, $after_step = 0, $now = null ) {
		$code = preg_replace( '/\D/', '', (string) $code );
		if ( 6 !== strlen( $code ) ) {
			return false;
		}
		$cur = (int) floor( ( null === $now ? time() : $now ) / 30 );
		for ( $s = $cur - 1; $s <= $cur + 1; $s++ ) {
			if ( $s > $after_step && hash_equals( self::totp( $secret, $s ), $code ) ) {
				return $s;
			}
		}
		return false;
	}

	private static function key() {
		return hash( 'sha256', wp_salt( 'auth' ), true );
	}

	public static function enc( $plain ) {
		if ( ! function_exists( 'openssl_encrypt' ) ) {
			return 'p:' . $plain;
		}
		$iv = random_bytes( 16 );
		return 'e:' . base64_encode( $iv . openssl_encrypt( $plain, 'aes-256-cbc', self::key(), OPENSSL_RAW_DATA, $iv ) );
	}

	public static function dec( $stored ) {
		if ( 0 === strpos( $stored, 'p:' ) ) {
			return substr( $stored, 2 );
		}
		if ( 0 !== strpos( $stored, 'e:' ) || ! function_exists( 'openssl_decrypt' ) ) {
			return '';
		}
		$raw = base64_decode( substr( $stored, 2 ) );
		$out = openssl_decrypt( substr( $raw, 16 ), 'aes-256-cbc', self::key(), OPENSSL_RAW_DATA, substr( $raw, 0, 16 ) );
		return false === $out ? '' : $out;
	}

	private static function hash_code( $code ) {
		return hash_hmac( 'sha256', preg_replace( '/\s|-/', '', strtolower( $code ) ), wp_salt( 'auth' ) );
	}

	public static function make_backup_codes() {
		$plain = array();
		$hash  = array();
		for ( $i = 0; $i < 8; $i++ ) {
			$c       = strtolower( substr( bin2hex( random_bytes( 4 ) ), 0, 8 ) );
			$plain[] = substr( $c, 0, 4 ) . '-' . substr( $c, 4 );
			$hash[]  = self::hash_code( $c );
		}
		return array( $plain, $hash );
	}

	/* ---------- user state ---------- */

	/** The method the member will really be asked for. A method the owner switched off falls back to email, so nobody is locked out. */
	public static function method_for( $user_id ) {
		$m = self::method_raw( $user_id );
		$s = self::settings();
		$k = array( 'app' => 'allow_app', 'email' => 'allow_email', 'whatsapp' => 'allow_wa', 'telegram' => 'allow_tg' );
		if ( $m && isset( $k[ $m ] ) && empty( $s[ $k[ $m ] ] ) ) {
			return 'email';
		}
		return $m;
	}

	/** Store links for the two authenticator apps. */
	public static function app_links( $style = 'admin' ) {
		$a = array(
			array( 'Google Authenticator', 'Android', 'https://play.google.com/store/apps/details?id=com.google.android.apps.authenticator2' ),
			array( 'Google Authenticator', 'iPhone', 'https://apps.apple.com/app/google-authenticator/id388497605' ),
			array( 'Microsoft Authenticator', 'Android', 'https://play.google.com/store/apps/details?id=com.azure.authenticator' ),
			array( 'Microsoft Authenticator', 'iPhone', 'https://apps.apple.com/app/microsoft-authenticator/id983156458' ),
		);
		$h = '<span class="mrsh-apps" style="display:flex;flex-wrap:wrap;gap:8px;margin:8px 0">';
		foreach ( $a as $r ) {
			$h .= '<a href="' . esc_url( $r[2] ) . '" target="_blank" rel="noopener" style="display:inline-block;border:1px solid #d6dae1;border-radius:10px;padding:6px 12px;text-decoration:none;background:#fff;color:#111827;font-size:13px">Get ' . esc_html( $r[0] ) . ' <b>(' . esc_html( $r[1] ) . ')</b></a>';
		}
		return $h . '</span>';
	}

	private static function method_raw( $user_id ) {
		$m = get_user_meta( $user_id, self::M_METHOD, true );
		if ( 'app' === $m && get_user_meta( $user_id, self::M_SECRET, true ) ) {
			return 'app';
		}
		if ( 'email' === $m ) {
			return 'email';
		}
		if ( 'whatsapp' === $m && get_user_meta( $user_id, self::M_WA, true ) ) {
			// If the owner later switches WhatsApp off, fall back to email so nobody is locked out.
			return ( class_exists( 'MRSH_WhatsApp' ) && MRSH_WhatsApp::enabled() ) ? 'whatsapp' : 'email';
		}
		if ( 'telegram' === $m && get_user_meta( $user_id, self::M_TG, true ) ) {
			// If the owner later switches Telegram off, fall back to email so nobody is locked out.
			return ( class_exists( 'MRSH_Telegram' ) && MRSH_Telegram::enabled() ) ? 'telegram' : 'email';
		}
		// Required role without a choice: fall back to email so the rule still protects them.
		$u = get_userdata( $user_id );
		if ( $u && array_intersect( (array) $u->roles, (array) self::settings()['required'] ) ) {
			return 'email';
		}
		return '';
	}

	/* ---------- login interception ---------- */

	/** Remember that this request signed in with a username and password (so the second step must run). */
	public static function note_password( $user, $username = '', $password = '' ) {
		if ( $user instanceof WP_User && '' !== (string) $password ) {
			$GLOBALS['mrsh_2fa_pw'] = 1;
		}
		return $user;
	}

	/** True when this sign-in came from Google (Site Kit 'Sign in with Google', One Tap) or another non-password route. */
	private static function social_login() {
		if ( empty( self::settings()['social_skip'] ) || ! empty( $GLOBALS['mrsh_2fa_pw'] ) ) {
			return false;
		}
		$a = isset( $_REQUEST['action'] ) ? sanitize_key( wp_unslash( $_REQUEST['action'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		return ( 'googlesitekit_auth' === $a || isset( $_POST['credential'] ) || empty( $_POST['pwd'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
	}

	public static function intercept( $login, $user ) {
		if ( ! $user instanceof WP_User ) {
			return;
		}
		$method = self::method_for( $user->ID );
		if ( ! $method ) {
			return;
		}
		if ( 'mrsh2fa_done' === ( $GLOBALS['mrsh_2fa_pass'] ?? '' ) || self::social_login() || self::dev_ok( $user->ID ) ) {
			return;
		}
		wp_clear_auth_cookie();
		$token = bin2hex( random_bytes( 16 ) );
		$ttl   = max( 3, (int) self::settings()['ttl'] ) * MINUTE_IN_SECONDS;
		$data  = array(
			'uid'      => $user->ID,
			'remember' => ! empty( $_POST['rememberme'] ), // phpcs:ignore WordPress.Security.NonceVerification
			'redirect' => isset( $_REQUEST['redirect_to'] ) ? esc_url_raw( wp_unslash( $_REQUEST['redirect_to'] ) ) : admin_url(), // phpcs:ignore WordPress.Security.NonceVerification
			'method'   => $method,
			'tries'    => 0,
			'sent'     => 0,
			'hash'     => '',
		);
		if ( 'email' === $method ) {
			$data = self::send_email_code( $user, $data );
		} elseif ( 'whatsapp' === $method ) {
			$data = self::send_wa_code( $user, $data );
		} elseif ( 'telegram' === $method ) {
			$data = self::send_tg_code( $user, $data );
		}
		set_transient( 'mrsh2fa_' . $token, $data, $ttl );
		$url = add_query_arg( array( 'action' => 'mrsh2fa', 't' => $token ), wp_login_url() );
		if ( wp_doing_ajax() ) {
			wp_send_json( array( 'success' => false, 'twofactor' => true, 'redirect' => $url, 'message' => 'Check your second step: ' . $url ) );
		}
		wp_safe_redirect( $url );
		exit;
	}

	/** WhatsApp code. If the company cannot send it right now, the member gets the code by email instead. */
	private static function send_wa_code( $user, $data ) {
		$num  = (string) get_user_meta( $user->ID, self::M_WA, true );
		$code = (string) random_int( 100000, 999999 );
		$ttl  = (int) self::settings()['ttl'];
		$sent = ( $num && class_exists( 'MRSH_WhatsApp' ) ) ? MRSH_WhatsApp::send( $num, $code, $ttl ) : false;
		if ( true === $sent ) {
			$data['hash'] = self::hash_code( $code );
			$data['sent']++;
			$data['via']  = 'whatsapp';
			return $data;
		}
		$data['method'] = 'email';
		$data['via']    = 'email-fallback';
		return self::send_email_code( $user, $data );
	}

	/** Telegram code. If Telegram cannot deliver it right now, the member gets the code by email instead. */
	private static function send_tg_code( $user, $data ) {
		$chat = (string) get_user_meta( $user->ID, self::M_TG, true );
		$code = (string) random_int( 100000, 999999 );
		$ttl  = (int) self::settings()['ttl'];
		$sent = ( $chat && class_exists( 'MRSH_Telegram' ) ) ? MRSH_Telegram::send( $chat, $code, $ttl ) : false;
		if ( true === $sent ) {
			$data['hash'] = self::hash_code( $code );
			$data['sent']++;
			$data['via']  = 'telegram';
			return $data;
		}
		$data['method'] = 'email';
		$data['via']    = 'email-fallback-tg';
		return self::send_email_code( $user, $data );
	}

	private static function send_email_code( $user, $data ) {
		$code = (string) random_int( 100000, 999999 );
		$data['hash'] = self::hash_code( $code );
		$data['sent']++;
		$ttl  = (int) self::settings()['ttl'];
		$name = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$plain = "$code is your one-time login code.\n\nYour one-time login code is: $code\n\nIt works for $ttl minutes. If you did not try to log in, change your password now.\n\n" . home_url( '/' );
		$alt   = static function ( $m ) use ( $plain ) {
			$m->AltBody = $plain;
		};
		add_action( 'phpmailer_init', $alt, 200 );
		wp_mail(
			$user->user_email,
			$code . ' is your ' . $name . ' login code | آپ کا لاگ اِن کوڈ',
			self::code_html( $code, $ttl, $name ),
			array( 'Content-Type: text/html; charset=UTF-8' )
		);
		remove_action( 'phpmailer_init', $alt, 200 );
		return $data;
	}

	/** The login code email: big digit boxes, English and Urdu, plain tables so every mail app shows it right. */
	public static function code_html( $code, $ttl, $site ) {
		$cells = '';
		foreach ( str_split( (string) $code ) as $d ) {
			$cells .= '<td style="width:46px;height:56px;background:#f5f3ff;border:1px solid #ddd6fe;border-radius:10px;text-align:center;font:700 30px/56px Consolas,Menlo,monospace;color:#5b21b6">' . esc_html( $d ) . '</td><td style="width:8px"></td>';
		}
		return '<!doctype html><html><body style="margin:0;background:#f3f4f8"><div style="max-width:560px;margin:0 auto;padding:16px;font-family:Arial,Helvetica,sans-serif">'
			. '<div style="background:#fff;border-radius:16px;overflow:hidden;border:1px solid #e5e7eb">'
			. '<div style="background:linear-gradient(110deg,#e11d74,#7c3aed);color:#fff;padding:16px 22px;font-size:20px;font-weight:800">' . esc_html( $site ) . '</div>'
			. '<div style="padding:24px 22px 8px;color:#1f2430"><div style="font-size:18px;font-weight:700">Your login code</div>'
			. '<div dir="rtl" style="font-size:18px;margin-top:4px;color:#4b5563">آپ کا لاگ اِن کوڈ</div></div>'
			. '<div style="padding:8px 22px 18px"><table role="presentation" cellpadding="0" cellspacing="0" style="margin:0"><tr>' . $cells . '</tr></table></div>'
			. '<div style="padding:0 22px 20px;font-size:15px;line-height:1.6;color:#374151">This code works for <b>' . (int) $ttl . ' minutes</b> and can be used once.<br>'
			. '<span dir="rtl" style="display:block;margin-top:6px">یہ کوڈ ' . (int) $ttl . ' منٹ کے لیے ہے اور صرف ایک بار استعمال ہو سکتا ہے۔</span></div>'
			. '<div style="background:#fff7ed;border-top:1px solid #fed7aa;padding:12px 22px;font-size:13px;color:#9a3412;line-height:1.5"><b>Never share this code.</b> We will never ask for it by phone, WhatsApp or email. If you did not try to log in, change your password now.<br><span dir="rtl" style="display:block;margin-top:4px">یہ کوڈ کسی کو نہ بتائیں۔ اگر آپ نے لاگ اِن نہیں کیا تو فوراً پاس ورڈ بدل لیں۔</span></div>'
			. '</div></div></body></html>';
	}

	/* ---------- challenge screen ---------- */

	public static function challenge() {
		$token = isset( $_REQUEST['t'] ) ? preg_replace( '/[^a-f0-9]/', '', (string) wp_unslash( $_REQUEST['t'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$data  = $token ? get_transient( 'mrsh2fa_' . $token ) : false;
		if ( ! is_array( $data ) ) {
			wp_safe_redirect( add_query_arg( 'mrsh2fa', 'expired', wp_login_url() ) );
			exit;
		}
		$user  = get_userdata( $data['uid'] );
		$error = '';
		$note  = '';
		if ( $user && 'POST' === $_SERVER['REQUEST_METHOD'] ) {
			check_admin_referer( 'mrsh2fa_' . $token, 'mrsh_nonce' );
			if ( ! empty( $_POST['resend'] ) && 'app' !== $data['method'] ) {
				if ( $data['sent'] < 4 ) {
					if ( 'whatsapp' === $data['method'] ) {
						$data = self::send_wa_code( $user, $data );
						$note = 'whatsapp' === $data['method'] ? 'A new code was sent to your WhatsApp.' : 'WhatsApp could not send the code, so we emailed it.';
					} elseif ( 'telegram' === $data['method'] ) {
						$data = self::send_tg_code( $user, $data );
						$note = 'telegram' === $data['method'] ? 'A new code was sent to your Telegram.' : 'Telegram could not send the code, so we emailed it.';
					} else {
						$data = self::send_email_code( $user, $data );
						$note = 'A new code was sent to your email.';
					}
				} else {
					$error = 'Too many codes requested. Please log in again later.';
				}
				set_transient( 'mrsh2fa_' . $token, $data, MINUTE_IN_SECONDS * 15 );
			} else {
				$code = isset( $_POST['code'] ) ? sanitize_text_field( wp_unslash( $_POST['code'] ) ) : '';
				$ok   = self::verify( $user, $data, $code );
				if ( $ok ) {
					delete_transient( 'mrsh2fa_' . $token );
					if ( ! empty( $_POST['mrsh_remember'] ) ) {
						self::dev_add( $user->ID );
					}
					$GLOBALS['mrsh_2fa_pass'] = 'mrsh2fa_done';
					wp_set_auth_cookie( $user->ID, $data['remember'] );
					wp_set_current_user( $user->ID );
					$dest = $data['redirect'] ? $data['redirect'] : admin_url();
					$dest = add_query_arg( 'mrl', time(), $dest ); // a new address, so a phone can never show an old logged-out copy
					nocache_headers();
					do_action( 'litespeed_control_set_nocache', '2fa done' );
					wp_safe_redirect( $dest );
					exit;
				}
				$data['tries']++;
				if ( $data['tries'] >= max( 3, (int) self::settings()['max_tries'] ) ) {
					delete_transient( 'mrsh2fa_' . $token );
					wp_safe_redirect( add_query_arg( 'mrsh2fa', 'locked', wp_login_url() ) );
					exit;
				}
				set_transient( 'mrsh2fa_' . $token, $data, MINUTE_IN_SECONDS * 15 );
				$error = 'That code is not correct. ' . ( max( 3, (int) self::settings()['max_tries'] ) - $data['tries'] ) . ' tries left.';
			}
		}
		login_header( 'Two-step login', '', $error ? new WP_Error( 'mrsh2fa', $error ) : null );
		if ( $note ) {
			echo '<p class="message">' . esc_html( $note ) . '</p>';
		}
		$app = 'app' === $data['method'];
		$wa  = 'whatsapp' === $data['method'];
		$tg  = 'telegram' === $data['method'];
		echo '<form method="post" action="' . esc_url( add_query_arg( array( 'action' => 'mrsh2fa', 't' => $token ), wp_login_url() ) ) . '">';
		wp_nonce_field( 'mrsh2fa_' . $token, 'mrsh_nonce' );
		echo '<p>' . ( $app ? 'Open Google Authenticator, Microsoft Authenticator or your authenticator app and enter the 6-digit code for MyRishta.' : ( $tg ? 'We sent a 6-digit code to your Telegram chat. It expires in a few minutes.' : ( $wa ? 'We sent a 6-digit code to your WhatsApp number ' . esc_html( MRSH_WhatsApp::mask( get_user_meta( $user->ID, self::M_WA, true ) ) ) . '. It expires in a few minutes.' : ( ( 0 === strpos( (string) ( $data['via'] ?? '' ), 'email-fallback' ) ? ( 'email-fallback-tg' === ( $data['via'] ?? '' ) ? 'Telegram could not send your code right now, so we emailed a 6-digit code to the address on your account. ' : 'WhatsApp could not send your code right now, so we emailed a 6-digit code to the address on your account. ' ) : 'We emailed a 6-digit code to the address on your account. ' ) . 'It expires in a few minutes.' ) ) ) ) . '</p>';
		echo '<p><label for="mrsh_code">Code</label><input type="text" name="code" id="mrsh_code" class="input" inputmode="numeric" autocomplete="one-time-code" autofocus maxlength="12" /></p>';
		if ( (int) self::settings()['remember_days'] > 0 ) {
			echo '<p><label><input type="checkbox" name="mrsh_remember" value="1"> Remember this device for ' . (int) self::settings()['remember_days'] . ' days</label></p>';
		}
		echo '<p class="submit"><input type="submit" class="button button-primary button-large" value="Verify and log in" /></p>';
		if ( ! $app ) {
			echo '<p><button type="submit" name="resend" value="1" class="button" formnovalidate>Send a new code</button></p>';
		}
		echo '<p style="color:#555;font-size:12px">Lost your phone? Enter one of your backup codes instead.</p></form>';
		if ( ! $app && ! $wa && ! $tg && preg_match( '/@(gmail|googlemail)\.com$/i', $user->user_email ) ) {
			echo '<p><a class="button" target="_blank" rel="noopener" href="https://mail.google.com/mail/u/0/#search/from%3A' . rawurlencode( wp_parse_url( home_url(), PHP_URL_HOST ) ) . '+newer_than%3A1h">Open Gmail to see the code</a></p>';
		}
		echo self::otp_js(); // phpcs:ignore
		login_footer();
		exit;
	}

	public static function verify( $user, &$data, $code ) {
		$code = trim( $code );
		if ( '' === $code ) {
			return false;
		}
		// Backup code (works for either method).
		$backup = get_user_meta( $user->ID, self::M_BACKUP, true );
		if ( is_array( $backup ) && preg_match( '/^[a-f0-9]{4}-?[a-f0-9]{4}$/i', $code ) ) {
			$h = self::hash_code( $code );
			foreach ( $backup as $i => $b ) {
				if ( hash_equals( $b, $h ) ) {
					unset( $backup[ $i ] );
					update_user_meta( $user->ID, self::M_BACKUP, array_values( $backup ) );
					return true;
				}
			}
		}
		if ( 'app' === $data['method'] ) {
			$secret = self::dec( (string) get_user_meta( $user->ID, self::M_SECRET, true ) );
			$last   = (int) get_user_meta( $user->ID, self::M_LAST, true );
			$step   = $secret ? self::totp_check( $secret, $code, $last ) : false;
			if ( $step ) {
				update_user_meta( $user->ID, self::M_LAST, $step );
				return true;
			}
			return false;
		}
		return $data['hash'] && hash_equals( $data['hash'], self::hash_code( $code ) );
	}

	/* ---------- member settings UI ---------- */

	public static function profile_admin( $user ) {
		if ( current_user_can( 'edit_users' ) ) {
			echo '<h2>Two-step login</h2><p>Current method: <strong>' . esc_html( self::method_for( $user->ID ) ?: 'off' ) . '</strong>. Members change this themselves; to reset a locked-out member, set the method to off:</p>';
			echo '<p><a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_2fa&do=reset&uid=' . (int) $user->ID ), 'mrsh_2fa_reset' ) ) . '">Reset two-step login for this member</a></p>';
		}
	}

	public static function label( $m ) {
		if ( 'app' === $m ) {
			return 'On (authenticator app)';
		}
		if ( 'whatsapp' === $m ) {
			return 'On (WhatsApp code)';
		}
		if ( 'telegram' === $m ) {
			return 'On (Telegram code)';
		}
		return $m ? 'On (email code)' : 'Off';
	}

	public static function profile( $user ) {
		$m = self::method_for( $user->ID );
		echo '<h2>Two-step login</h2><p>Status: <strong>' . esc_html( self::label( $m ) ) . '</strong> &nbsp; <a class="button" href="' . esc_url( self::my_url() ) . '">Set up or change two-step login</a></p>';
	}

	public static function shortcode() {
		if ( ! is_user_logged_in() ) {
			return '<p>Please <a href="' . esc_url( wp_login_url( get_permalink() ) ) . '">log in</a> to manage your account security.</p>';
		}
		return '<div class="mrsh-2fa">' . self::panel( get_current_user_id() ) . '</div>';
	}

	/** Two-step login inside My account (returns the card). */
	public static function account_box() {
		if ( ! is_user_logged_in() || current_user_can( 'manage_options' ) ) {
			return '';
		}
		$st = self::settings();
		if ( empty( $st['enabled'] ) || ( empty( $st['allow_app'] ) && empty( $st['allow_email'] ) && empty( $st['allow_wa'] ) && empty( $st['allow_tg'] ) ) ) {
			return '';
		}
		$uid   = get_current_user_id();
		$m     = self::method_for( $uid );
		$on    = (bool) $m;
		$panel = self::panel( $uid );
		$panel = preg_replace( '#<p>Status: <strong>.*?</strong>\. Add a second step[^<]*</p>#s', '', $panel );
		$ic    = function_exists( 'mrt_icon' ) ? mrt_icon( 'shield' ) : '';
		return '<section class="sx-card" id="mrsh-2fa"><div class="sx-h"><span class="sx-ic" style="--t:#4f46e5">' . $ic . '</span><div><div class="sx-t">Two-step login (optional) / <span class="sx-ur" lang="ur" dir="rtl">دو مرحلہ لاگ ان</span></div><div class="sx-s">A second step so a password alone is never enough</div></div></div>'
			. '<span class="sx-pill ' . ( $on ? 'on' : 'off' ) . '">' . esc_html( self::label( $m ) ) . '</span>'
			. '<p class="sm">Free and optional. After your password you confirm with a code. / پاس ورڈ کے بعد ایک کوڈ سے تصدیق۔</p><div class="mrsh-2fa">' . $panel . '</div>' . self::otp_js() . '</section>'; // phpcs:ignore
	}

	/** Makes any one-time-code box easy: numbers only, fills from a paste or from the phone, and sends itself at 6 digits. */
	public static function otp_js() {
		return '<script>(function(){var is=document.querySelectorAll(\'input[autocomplete="one-time-code"]\');
is.forEach(function(i){if(i.dataset.otp)return;i.dataset.otp=1;var f=i.form;i.setAttribute("inputmode","numeric");i.setAttribute("autocapitalize","off");
function go(){var v=i.value.replace(/\D/g,"");if(/^\d{6}$/.test(i.value.replace(/[\s-]/g,""))&&!i.dataset.sent){i.value=v;i.dataset.sent=1;setTimeout(function(){var sb=f.querySelector(\'.button-primary\');try{f.requestSubmit?f.requestSubmit(sb||undefined):f.submit()}catch(e){f.submit()}},250)}}
i.addEventListener("input",function(){var d=i.value.replace(/[\s-]/g,"");if(/^\d+$/.test(d)&&d!==i.value)i.value=d;go()});
i.addEventListener("paste",function(){setTimeout(go,40)});
if("OTPCredential" in window&&f){var ac=new AbortController();f.addEventListener("submit",function(){ac.abort()});navigator.credentials.get({otp:{transport:["sms"]},signal:ac.signal}).then(function(o){if(o&&o.code){i.value=o.code;go()}}).catch(function(){})}});
document.querySelectorAll(\'button[name="resend"]\').forEach(function(b){var t=30,l=b.textContent;b.disabled=true;var h=setInterval(function(){t--;if(t<=0){clearInterval(h);b.disabled=false;b.textContent=l}else b.textContent=l+" ("+t+")"},1000);b.textContent=l+" (30)"});})();</script>';
	}

	/** Where the panel sends the member back to after a button (set by the Settings tab). */
	public static $back = '';

	private static function panel( $uid ) {
		$m    = self::method_for( $uid );
		$raw  = get_user_meta( $uid, self::M_METHOD, true );
		$u    = get_userdata( $uid );
		$post = esc_url( admin_url( 'admin-post.php' ) );
		$back = '<input type="hidden" name="back" value="' . esc_url( self::$back ? self::$back : ( is_admin() ? self::my_url() : get_permalink() ) ) . '">';
		$non  = wp_nonce_field( 'mrsh_2fa_save', '_wpnonce', true, false );
		$h    = '';
		$flash = get_transient( 'mrsh2fa_flash_' . $uid );
		if ( $flash ) {
			delete_transient( 'mrsh2fa_flash_' . $uid );
			$h .= '<p style="padding:10px;background:#eef7ee;border-left:4px solid #2a8f4a"><strong>' . esc_html( $flash['msg'] ) . '</strong></p>';
			if ( ! empty( $flash['codes'] ) ) {
				$h .= '<p>Save these backup codes somewhere safe. Each works once if you lose your phone or email:</p><pre style="font-size:16px;background:#f6f6f6;padding:10px">' . esc_html( implode( "\n", $flash['codes'] ) ) . '</pre>';
			}
		}
		$h .= '<p>Status: <strong>' . esc_html( self::label( $m ) ) . '</strong>. Add a second step so nobody can enter your account with only your password.</p>';

		$wap = get_user_meta( $uid, self::M_WAP, true );
		if ( is_array( $wap ) && ! empty( $wap['exp'] ) && $wap['exp'] > time() ) {
			$h .= '<form method="post" action="' . $post . '"><input type="hidden" name="action" value="mrsh_2fa">' . $non . $back;
			$h .= '<p><strong>Confirm your WhatsApp number</strong></p><p>We sent a 6-digit code to ' . esc_html( MRSH_WhatsApp::mask( $wap['phone'] ) ) . '. Type it here:</p>';
			$h .= '<p><input type="text" name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" required> <button class="button button-primary" name="do" value="wa_confirm">Turn on</button> <button class="button" name="do" value="cancel" formnovalidate>Cancel</button></p></form>';
			return $h;
		}
		$tgp = get_user_meta( $uid, self::M_TGP, true );
		if ( is_array( $tgp ) && ! empty( $tgp['exp'] ) && $tgp['exp'] > time() && class_exists( 'MRSH_Telegram' ) && MRSH_Telegram::enabled() ) {
			$h .= '<form method="post" action="' . $post . '"><input type="hidden" name="action" value="mrsh_2fa">' . $non . $back;
			$h .= '<p><strong>Link your Telegram</strong></p><ol><li><a class="button button-primary" target="_blank" rel="noopener" href="https://t.me/' . rawurlencode( MRSH_Telegram::settings()['bot'] ) . '?start=' . esc_attr( $tgp['t'] ) . '">Open Telegram and tap Start</a></li><li>Come back here and press the button below.</li></ol>';
			$h .= '<p><button class="button button-primary" name="do" value="tg_confirm">I have tapped Start</button> <button class="button" name="do" value="cancel" formnovalidate>Cancel</button></p><p style="color:#555">The link works once and expires in 15 minutes.</p></form>';
			return $h;
		}
		$pend = get_user_meta( $uid, self::M_PEND, true );
		if ( $pend ) {
			$secret = self::dec( $pend );
			$uri    = 'otpauth://totp/' . rawurlencode( self::settings()['issuer'] . ':' . $u->user_email ) . '?secret=' . $secret . '&issuer=' . rawurlencode( self::settings()['issuer'] ) . '&digits=6&period=30';
			$h .= '<form method="post" action="' . $post . '"><input type="hidden" name="action" value="mrsh_2fa"><input type="hidden" name="do" value="confirm">' . $non . $back;
			$h .= '<p><strong>Set up your authenticator app</strong></p><div class="mrsh-qr" data-uri="' . esc_attr( $uri ) . '" style="margin:10px 0"></div><script src="' . esc_url( MRSH_URL . 'assets/mrsh-qr.js?v=' . MRSH_VERSION ) . '"></script><p style="margin:6px 0 0">First install an authenticator app on your phone (free):</p>' . self::app_links() . '<ol><li>Open Google Authenticator or Microsoft Authenticator and tap "Add account", then "Scan a QR code" and scan the picture above.</li><li>If you cannot scan, choose "Enter a setup key" instead. Account: MyRishta. Key (time based):<br><code style="font-size:16px;letter-spacing:2px">' . esc_html( implode( ' ', str_split( $secret, 4 ) ) ) . '</code></li><li>On the same phone you can also tap <a href="' . esc_attr( $uri ) . '">this link</a> to add it automatically.</li><li>Type the 6-digit code the app shows:</li></ol>';
			$h .= '<p><input type="text" name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" required> <button class="button button-primary" name="do" value="confirm">Turn on</button> <button class="button" name="do" value="cancel" formnovalidate>Cancel</button></p><p style="color:#555">This key stays the same until you press Turn on or Cancel. You do not need to make a new one.</p></form>';
			return $h;
		}
		if ( 'app' === $raw && 'app' === $m ) {
			$h .= '<form method="post" action="' . $post . '"><input type="hidden" name="action" value="mrsh_2fa">' . $non . $back;
			$h .= '<p style="padding:10px;background:#eef7ee;border-left:4px solid #2a8f4a"><strong>Your authenticator app is working and two-step login is ON.</strong> Nothing more to do.</p>';
			$h .= '<p><button class="button" name="do" value="email">Use email codes instead</button> ';
			$h .= '<button class="button" name="do" value="off" onclick="return confirm(\'Turn off two-step login?\')">Turn off</button> ';
			$h .= '<button class="button" name="do" value="app" onclick="return confirm(\'This makes a NEW key. You must scan it again, and the old one stops working once you confirm. Continue?\')">Make a new key</button></p></form>';
			return $h;
		}
		$h .= '<form method="post" action="' . $post . '"><input type="hidden" name="action" value="mrsh_2fa">' . $non . $back;
		$h .= '<p><strong>Choose how to get your second step:</strong></p>';
		$st = self::settings();
		$h .= '<p>';
		if ( ! empty( $st['allow_app'] ) ) {
			$h .= '<label><input type="radio" name="do" value="app"> Authenticator app (Google Authenticator or Microsoft Authenticator)</label><br>' . self::app_links() ;
		}
		if ( ! empty( $st['allow_email'] ) ) {
			$h .= '<label><input type="radio" name="do" value="email"' . ( 'email' === $raw ? ' checked' : '' ) . '> Code by email (' . esc_html( $u->user_email ) . ')</label><br>';
		}
		if ( ! empty( $st['allow_wa'] ) && class_exists( 'MRSH_WhatsApp' ) && MRSH_WhatsApp::enabled() ) {
			$cur = (string) get_user_meta( $uid, self::M_WA, true );
			$h  .= '<label><input type="radio" name="do" value="wa_start"' . ( 'whatsapp' === $raw ? ' checked' : '' ) . '> Code by WhatsApp</label> <input type="text" name="wa_phone" placeholder="' . esc_attr( $cur ? MRSH_WhatsApp::mask( $cur ) : '0300 1234567' ) . '" style="width:170px"><br>';
		}
		if ( ! empty( $st['allow_tg'] ) && class_exists( 'MRSH_Telegram' ) && MRSH_Telegram::enabled() ) {
			$cur = (string) get_user_meta( $uid, self::M_TG, true );
			$h  .= '<label><input type="radio" name="do" value="tg_start"' . ( 'telegram' === $raw ? ' checked' : '' ) . '> Code by Telegram' . ( $cur ? ' (linked ' . esc_html( MRSH_Telegram::mask( $cur ) ) . ')' : '' ) . '</label><br>';
		}
		$h .= '<label><input type="radio" name="do" value="off"' . ( 'email' !== $raw && 'whatsapp' !== $raw && 'telegram' !== $raw ? ' checked' : '' ) . '> Off</label></p>';
		$h .= '<p><button class="button button-primary">Save</button></p></form>';
		return $h;
	}

	public static function save() {
		if ( ! is_user_logged_in() ) {
			wp_die( 'Please log in.' );
		}
		$uid  = get_current_user_id();
		$do   = isset( $_REQUEST['do'] ) ? sanitize_key( wp_unslash( $_REQUEST['do'] ) ) : '';
		$back = isset( $_POST['back'] ) ? esc_url_raw( wp_unslash( $_POST['back'] ) ) : self::my_url();
		if ( ! $back ) {
			$back = self::my_url();
		}
		if ( 'reset' === $do ) {
			check_admin_referer( 'mrsh_2fa_reset' );
			if ( ! current_user_can( 'edit_users' ) ) {
				wp_die( 'Not allowed.' );
			}
			$t = (int) ( $_GET['uid'] ?? 0 );
			foreach ( array( self::M_METHOD, self::M_SECRET, self::M_PEND, self::M_LAST, self::M_BACKUP, self::M_WA, self::M_WAP, self::M_TG, self::M_TGP ) as $k ) {
				delete_user_meta( $t, $k );
			}
			wp_safe_redirect( get_edit_user_link( $t ) );
			exit;
		}
		check_admin_referer( 'mrsh_2fa_save' );
		$msg   = '';
		$codes = array();
		if ( 'off' === $do ) {
			if ( self::method_for( $uid ) && ! get_user_meta( $uid, self::M_METHOD, true ) ) {
				$msg = 'Your role requires a second step, so it stays on (email code).';
			} else {
				foreach ( array( self::M_SECRET, self::M_PEND, self::M_LAST, self::M_BACKUP, self::M_WA, self::M_WAP, self::M_TG, self::M_TGP ) as $k ) {
					delete_user_meta( $uid, $k );
				}
				update_user_meta( $uid, self::M_METHOD, '' );
				$msg = 'Two-step login is off.';
				if ( array_intersect( (array) get_userdata( $uid )->roles, (array) self::settings()['required'] ) ) {
					$msg = 'Your role requires a second step, so email codes stay on.';
				}
			}
		} elseif ( 'email' === $do ) {
			update_user_meta( $uid, self::M_METHOD, 'email' );
			delete_user_meta( $uid, self::M_PEND );
			list( $codes, $hashes ) = self::make_backup_codes();
			update_user_meta( $uid, self::M_BACKUP, $hashes );
			$msg = 'Email codes are on.';
		} elseif ( 'app' === $do ) {
			update_user_meta( $uid, self::M_PEND, self::enc( self::new_secret() ) );
			$msg = 'Now add the key to your authenticator app.';
		} elseif ( 'wa_start' === $do ) {
			$num = class_exists( 'MRSH_WhatsApp' ) ? MRSH_WhatsApp::normalize( sanitize_text_field( wp_unslash( $_POST['wa_phone'] ?? '' ) ) ) : '';
			$lim = 'mrsh2fa_wa_lim_' . $uid;
			if ( ! $num ) {
				$msg = 'Type your WhatsApp number, for example 0300 1234567.';
			} elseif ( (int) get_transient( $lim ) >= 4 ) {
				$msg = 'Too many codes requested. Please wait 10 minutes.';
			} else {
				$code = (string) random_int( 100000, 999999 );
				$r    = MRSH_WhatsApp::send( $num, $code, 10 );
				set_transient( $lim, (int) get_transient( $lim ) + 1, 10 * MINUTE_IN_SECONDS );
				if ( true === $r ) {
					update_user_meta( $uid, self::M_WAP, array( 'phone' => $num, 'hash' => self::hash_code( $code ), 'exp' => time() + 10 * MINUTE_IN_SECONDS, 'tries' => 0 ) );
					$msg = 'We sent a code to your WhatsApp. Type it below.';
				} else {
					$msg = 'We could not send the WhatsApp code. Please check the number, or choose email codes instead.';
				}
			}
		} elseif ( 'wa_confirm' === $do ) {
			$wap  = get_user_meta( $uid, self::M_WAP, true );
			$code = isset( $_POST['code'] ) ? sanitize_text_field( wp_unslash( $_POST['code'] ) ) : '';
			if ( is_array( $wap ) && ! empty( $wap['hash'] ) && $wap['exp'] > time() && (int) $wap['tries'] < 5 && hash_equals( $wap['hash'], self::hash_code( $code ) ) ) {
				update_user_meta( $uid, self::M_WA, $wap['phone'] );
				update_user_meta( $uid, self::M_METHOD, 'whatsapp' );
				delete_user_meta( $uid, self::M_WAP );
				list( $codes, $hashes ) = self::make_backup_codes();
				update_user_meta( $uid, self::M_BACKUP, $hashes );
				$msg = 'WhatsApp codes are on.';
			} else {
				if ( is_array( $wap ) ) {
					$wap['tries'] = (int) $wap['tries'] + 1;
					update_user_meta( $uid, self::M_WAP, $wap );
				}
				$msg = 'That code did not match or has expired. Choose WhatsApp again to get a new code.';
			}
		} elseif ( 'tg_start' === $do ) {
			$lim = 'mrsh2fa_tg_lim_' . $uid;
			if ( ! class_exists( 'MRSH_Telegram' ) || ! MRSH_Telegram::enabled() ) {
				$msg = 'Telegram codes are not available right now. Choose email codes instead.';
			} elseif ( (int) get_transient( $lim ) >= 6 ) {
				$msg = 'Too many tries. Please wait 10 minutes.';
			} else {
				set_transient( $lim, (int) get_transient( $lim ) + 1, 10 * MINUTE_IN_SECONDS );
				MRSH_Telegram::link_for( $uid );
				$msg = 'Now link your Telegram.';
			}
		} elseif ( 'tg_confirm' === $do ) {
			if ( get_user_meta( $uid, self::M_TG, true ) && class_exists( 'MRSH_Telegram' ) && MRSH_Telegram::enabled() ) {
				update_user_meta( $uid, self::M_METHOD, 'telegram' );
				delete_user_meta( $uid, self::M_TGP );
				list( $codes, $hashes ) = self::make_backup_codes();
				update_user_meta( $uid, self::M_BACKUP, $hashes );
				$msg = 'Telegram codes are on.';
			} else {
				$msg = 'We have not seen your Telegram yet. Open the link, tap Start in Telegram, then press the button again.';
			}
		} elseif ( 'cancel' === $do ) {
			delete_user_meta( $uid, self::M_PEND );
			delete_user_meta( $uid, self::M_WAP );
			delete_user_meta( $uid, self::M_TGP );
			$msg = 'Setup cancelled.';
		} elseif ( 'confirm' === $do ) {
			$pend   = get_user_meta( $uid, self::M_PEND, true );
			$secret = $pend ? self::dec( $pend ) : '';
			$step   = $secret ? self::totp_check( $secret, isset( $_POST['code'] ) ? sanitize_text_field( wp_unslash( $_POST['code'] ) ) : '' ) : false;
			if ( $step ) {
				update_user_meta( $uid, self::M_SECRET, self::enc( $secret ) );
				update_user_meta( $uid, self::M_METHOD, 'app' );
				update_user_meta( $uid, self::M_LAST, $step - 1 );
				delete_user_meta( $uid, self::M_PEND );
				list( $codes, $hashes ) = self::make_backup_codes();
				update_user_meta( $uid, self::M_BACKUP, $hashes );
				$msg = 'Authenticator app is on.';
			} else {
				$msg = 'That code did not match. Check the phone clock is automatic and try again.';
			}
		}
		set_transient( 'mrsh2fa_flash_' . $uid, array( 'msg' => $msg, 'codes' => $codes ), 120 );
		wp_safe_redirect( $back ? $back : self::my_url() );
		exit;
	}

	/* ---------- admin settings ---------- */

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Login Security', 'Login Security', 'manage_options', 'mrsh-2fa', array( __CLASS__, 'page' ) );
		// Members' own page. The profile screen is already one big <form>, and browsers drop a nested
		// <form>, so the setup panel must live on its own page, not inside the profile.
		if ( self::settings()['enabled'] ) {
			add_users_page( 'Two-step login', 'Two-step login', 'read', 'mrsh-2fa-me', array( __CLASS__, 'my_page' ) );
		}
	}

	public static function my_url() {
		return admin_url( 'users.php?page=mrsh-2fa-me' );
	}

	public static function my_page() {
		echo '<div class="wrap"><h1>Two-step login</h1>' . self::panel( get_current_user_id() ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/** Trusted devices: a member who ticks "remember this device" skips the second step on it for a few days. */
	private static function dev_ok( $uid ) {
		$days = (int) self::settings()['remember_days'];
		if ( $days < 1 || empty( $_COOKIE['mrsh2fa_dev'] ) ) {
			return false;
		}
		$h    = hash( 'sha256', (string) wp_unslash( $_COOKIE['mrsh2fa_dev'] ) );
		$devs = (array) get_user_meta( $uid, '_mrsh2fa_devs', true );
		return isset( $devs[ $h ] ) && (int) $devs[ $h ] > time();
	}

	private static function dev_add( $uid ) {
		$days = (int) self::settings()['remember_days'];
		if ( $days < 1 ) {
			return;
		}
		$tok  = bin2hex( random_bytes( 24 ) );
		$devs = array_filter( (array) get_user_meta( $uid, '_mrsh2fa_devs', true ), function ( $t ) {
			return (int) $t > time();
		} );
		$devs[ hash( 'sha256', $tok ) ] = time() + $days * DAY_IN_SECONDS;
		update_user_meta( $uid, '_mrsh2fa_devs', array_slice( $devs, -5, 5, true ) );
		setcookie( 'mrsh2fa_dev', $tok, array( 'expires' => time() + $days * DAY_IN_SECONDS, 'path' => '/', 'secure' => is_ssl(), 'httponly' => true, 'samesite' => 'Lax' ) );
	}

	/** Admin: remove a member's second step (lost phone). */
	public static function reset_member() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_2fa_reset' );
		$u = false;
		if ( ! empty( $_POST['uid'] ) ) {
			$u = get_userdata( (int) $_POST['uid'] );
		} elseif ( ! empty( $_POST['email'] ) ) {
			$u = get_user_by( 'email', sanitize_email( wp_unslash( $_POST['email'] ) ) );
		}
		$msg = 'No member found with that email.';
		if ( $u ) {
			foreach ( array( self::M_METHOD, self::M_SECRET, self::M_PEND, self::M_LAST, self::M_BACKUP, self::M_WA, self::M_WAP, self::M_TG, self::M_TGP, '_mrsh2fa_devs' ) as $k ) {
				delete_user_meta( $u->ID, $k );
			}
			$msg = 'Two-step login was removed for ' . $u->user_email . '. They can set it up again after logging in.';
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-2fa&msg=' . rawurlencode( $msg ) ) );
		exit;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		global $wpdb;
		$s = self::settings();
		MRSH_Admin::open( 'Login Security', 'Members can add a second step to their login: an authenticator app (Google or Microsoft Authenticator) or a code by email, WhatsApp or Telegram. Members set it on their account page or on a page with the shortcode [mrsh_2fa].' );
		if ( isset( $_GET['msg'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="notice notice-info"><p>' . esc_html( rawurldecode( (string) wp_unslash( $_GET['msg'] ) ) ) . '</p></div>'; // phpcs:ignore
		}
		$rows = (array) $wpdb->get_results( "SELECT user_id, meta_value FROM {$wpdb->usermeta} WHERE meta_key = '" . self::M_METHOD . "' AND meta_value <> ''" ); // phpcs:ignore
		$cnt  = array( 'app' => 0, 'email' => 0, 'whatsapp' => 0, 'telegram' => 0 );
		foreach ( $rows as $r ) {
			if ( isset( $cnt[ $r->meta_value ] ) ) {
				$cnt[ $r->meta_value ]++;
			}
		}
		$total = array_sum( $cnt );
		$adm_ids = get_users( array( 'role' => 'administrator', 'fields' => 'ID', 'number' => 200 ) );
		$adm_n   = count( (array) $adm_ids );
		$adm_ok  = 0;
		foreach ( (array) $adm_ids as $aid ) {
			if ( self::method_for( (int) $aid ) ) {
				$adm_ok++;
			}
		}
		$all_users = (int) ( count_users()['total_users'] ?? 0 );
		$wa_on     = class_exists( 'MRSH_WhatsApp' ) && MRSH_WhatsApp::enabled();
		$tg_on     = class_exists( 'MRSH_Telegram' ) && MRSH_Telegram::enabled();
		$score     = 0;
		$score    += $s['enabled'] ? 30 : 0;
		$score    += ( $adm_n && $adm_ok === $adm_n ) ? 30 : ( $adm_n ? (int) round( 30 * $adm_ok / $adm_n ) : 0 );
		$score    += ! empty( $s['required'] ) ? 20 : 0;
		$score    += ( ! empty( $s['allow_app'] ) ? 10 : 0 ) + ( (int) $s['max_tries'] <= 5 ? 10 : 5 );
		$todo      = array();
		if ( ! $s['enabled'] ) {
			$todo[] = 'Turn on two-step login (card 1).';
		}
		if ( $adm_n && $adm_ok < $adm_n ) {
			$todo[] = ( $adm_n - $adm_ok ) . ' administrator(s) have no second step. Tick Administrator under "Required for these roles".';
		}
		if ( empty( $s['required'] ) ) {
			$todo[] = 'Require a second step for at least the Administrator and Editor roles.';
		}
		if ( ! empty( $s['allow_wa'] ) && ! $wa_on ) {
			$todo[] = 'WhatsApp codes are allowed but WhatsApp is not set up yet (WhatsApp and Telegram page).';
		}
		if ( ! empty( $s['allow_tg'] ) && ! $tg_on ) {
			$todo[] = 'Telegram codes are allowed but the Telegram bot is not set up yet (WhatsApp and Telegram page).';
		}
		if ( $all_users > 0 && $total < $all_users * 0.1 ) {
			$todo[] = 'Fewer than 1 in 10 members use a second step. Share the page with the [mrsh_2fa] shortcode in your newsletter or app.';
		}
		?>
<style>
.mtf{max-width:980px;margin:18px 0 40px;font-size:14px}.mtf *{box-sizing:border-box}
.mtf .chips{display:flex;gap:10px;flex-wrap:wrap;margin:0 0 18px}
.mtf .chip{background:#fff;border-radius:14px;padding:12px 16px;min-width:150px;box-shadow:0 1px 3px rgba(17,24,39,.08),0 0 0 1px rgba(17,24,39,.04)}
.mtf .chip small{display:block;color:#6b7280;text-transform:uppercase;letter-spacing:.06em;font-size:11px}.mtf .chip b{font-size:18px}
.mtf .ok{color:#047857}.mtf .no{color:#b91c1c}
.mtf .card{background:#fff;border-radius:20px;padding:22px 26px;margin:0 0 16px;box-shadow:0 1px 3px rgba(17,24,39,.07),0 0 0 1px rgba(17,24,39,.04)}
.mtf .hd{display:flex;align-items:center;gap:12px;margin:0 0 6px}.mtf .hd h2{margin:0;font-size:17px}
.mtf .n{width:30px;height:30px;border-radius:10px;background:linear-gradient(135deg,#1c8a6a,#0b4d3b);color:#fff;display:grid;place-items:center;font-weight:700}
.mtf .sub{margin:0 0 16px;color:#6b7280;line-height:1.55;max-width:760px}
.mtf .sw{display:flex;gap:12px;align-items:flex-start;padding:12px 14px;border:1px solid #e5e7eb;border-radius:14px;margin:0 0 10px;cursor:pointer}
.mtf .sw input{margin-top:4px;width:18px;height:18px;accent-color:#0b8f4d}.mtf .sw b{display:block}.mtf .sw span{color:#6b7280;font-size:13px}
.mtf .roles{display:flex;flex-wrap:wrap;gap:8px}
.mtf .role{display:flex;gap:8px;align-items:center;border:1px solid #e5e7eb;border-radius:999px;padding:7px 14px;cursor:pointer;background:#fafafa}
.mtf .role input{accent-color:#0b8f4d}
.mtf label.f{display:block;font-weight:600;margin:12px 0 0}.mtf label.f span{display:block;font-weight:400;color:#6b7280;font-size:12.5px;margin-top:3px}
.mtf input[type=number],.mtf input[type=text],.mtf input[type=email]{border:1px solid #d6dae1;border-radius:12px;padding:10px 14px;background:#f8fafc;margin-top:6px;width:200px}
.mtf .btn{border:0;border-radius:12px;padding:10px 20px;font-weight:700;cursor:pointer;background:#fff;color:#111827;box-shadow:0 0 0 1px #d6dae1}
.mtf .btn.p{background:linear-gradient(135deg,#1c8a6a,#0b4d3b);color:#fff;box-shadow:none}.mtf .btn.d{color:#b91c1c}.mtf .btn.s{padding:5px 12px;font-size:12.5px}
.mtf table{width:100%;border-collapse:collapse}.mtf td,.mtf th{padding:9px 6px;border-bottom:1px solid #eef0f3;text-align:left}.mtf th{color:#6b7280;font-size:12px;text-transform:uppercase;letter-spacing:.05em}
.mtf .pill{display:inline-block;background:#e8f7ee;color:#14532d;border-radius:999px;padding:2px 10px;font-size:12px}
</style>
<div class="mtf">
	<div class="chips">
		<div class="chip"><small>Two-step login</small><b class="<?php echo $s['enabled'] ? 'ok' : 'no'; ?>"><?php echo $s['enabled'] ? 'ON' : 'OFF'; ?></b></div>
		<div class="chip"><small>Members using it</small><b><?php echo (int) $total; ?></b></div>
		<div class="chip"><small>Authenticator app</small><b><?php echo (int) $cnt['app']; ?></b></div>
		<div class="chip"><small>Email code</small><b><?php echo (int) $cnt['email']; ?></b></div>
		<div class="chip"><small>WhatsApp / Telegram</small><b><?php echo (int) ( $cnt['whatsapp'] + $cnt['telegram'] ); ?></b></div>
		<div class="chip"><small>Admins protected</small><b class="<?php echo $adm_n && $adm_ok === $adm_n ? 'ok' : 'no'; ?>"><?php echo (int) $adm_ok; ?> of <?php echo (int) $adm_n; ?></b></div>
		<div class="chip"><small>Security score</small><b><?php echo (int) $score; ?>/100</b></div>
	</div>
	<?php if ( $todo ) : ?>
	<div class="card" style="border-left:4px solid #d97706"><div class="hd"><h2>To do to reach 100/100</h2></div><ul style="margin:6px 0 0 18px;list-style:disc"><?php foreach ( $todo as $t ) : ?><li><?php echo esc_html( $t ); ?></li><?php endforeach; ?></ul></div>
	<?php else : ?>
	<div class="card" style="border-left:4px solid #0b8f4d"><div class="hd"><h2>Everything recommended is in place</h2></div><p class="sub" style="margin:0">Admins are protected and the second step is required for the chosen roles.</p></div>
	<?php endif; ?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="mrsh_2fa_settings">
		<?php wp_nonce_field( 'mrsh_2fa_settings' ); ?>
		<div class="card">
			<div class="hd"><span class="n">1</span><h2>Switch and rules</h2></div>
			<p class="sub">Members choose their own second step. Roles you tick below must use it: they get email codes automatically until they pick a method.</p>
			<label class="sw"><input type="checkbox" name="enabled" value="1"<?php checked( $s['enabled'], 1 ); ?>><div><b>Turn on two-step login</b><span>Members with a second step set up are asked for a code after their password.</span></div></label>
			<label class="sw"><input type="checkbox" name="social_ask" value="1"<?php checked( empty( $s['social_skip'] ), true ); ?>><div><b>Also ask for the second step after Google or Facebook sign-in</b><span>Off (easiest): Google and Facebook sign-ins go straight in because Google or Facebook already verified the person. On: members who set up a second step are asked for it after social sign-in too. Password logins always ask.</span></div></label>
			<p style="margin:14px 0 6px"><b>Required for these roles</b></p>
			<div class="roles">
			<?php foreach ( wp_roles()->roles as $key => $r ) : ?>
				<label class="role"><input type="checkbox" name="required[]" value="<?php echo esc_attr( $key ); ?>"<?php checked( in_array( $key, (array) $s['required'], true ) ); ?>><?php echo esc_html( translate_user_role( $r['name'] ) ); ?></label>
			<?php endforeach; ?>
			</div>
		</div>
		<div class="card">
			<div class="hd"><span class="n">2</span><h2>Which second steps members can choose</h2></div>
			<p class="sub">Tick the ones you want to offer. If you switch one off, members who used it get email codes instead, so nobody is locked out.</p>
			<label class="sw"><input type="checkbox" name="allow_app" value="1"<?php checked( $s['allow_app'], 1 ); ?>><div><b>Authenticator app (strongest, works offline)</b><span>Google Authenticator or Microsoft Authenticator. Members scan a QR code once.</span><?php echo self::app_links(); // phpcs:ignore ?></div></label>
			<label class="sw"><input type="checkbox" checked disabled><div><b>Code by email (always on)</b><span>Needs no app. It is the safe fallback for locked-out roles, so it stays on.</span></div></label>
			<label class="sw"><input type="checkbox" name="allow_wa" value="1"<?php checked( $s['allow_wa'], 1 ); ?>><div><b>Code by WhatsApp <span class="pill" style="background:<?php echo $wa_on ? '#e8f7ee' : '#fef3c7'; ?>"><?php echo $wa_on ? 'ready' : 'not set up'; ?></span></b><span>Members get the code in WhatsApp. <a href="<?php echo esc_url( admin_url( 'admin.php?page=mrsh-whatsapp' ) ); ?>">Open WhatsApp and Telegram setup</a></span></div></label>
			<label class="sw"><input type="checkbox" name="allow_tg" value="1"<?php checked( $s['allow_tg'], 1 ); ?>><div><b>Code by Telegram <span class="pill" style="background:<?php echo $tg_on ? '#e8f7ee' : '#fef3c7'; ?>"><?php echo $tg_on ? 'ready' : 'not set up'; ?></span></b><span>Free and instant. Members link Telegram once with one tap. <a href="<?php echo esc_url( admin_url( 'admin.php?page=mrsh-whatsapp' ) ); ?>">Open WhatsApp and Telegram setup</a></span></div></label>
		</div>
		<div class="card">
			<div class="hd"><span class="n">3</span><h2>Codes, tries and trusted devices</h2></div>
			<label class="f">Code lifetime (minutes)<input type="number" name="ttl" min="3" max="30" value="<?php echo (int) $s['ttl']; ?>"><span>How long an emailed, WhatsApp or Telegram code works. 3 to 30.</span></label>
			<label class="f">Wrong codes allowed before the login is blocked<input type="number" name="max_tries" min="3" max="10" value="<?php echo (int) $s['max_tries']; ?>"><span>3 to 10. After this many wrong codes the member must log in again. Lower is safer.</span></label>
			<label class="f">Remember this device for (days)<input type="number" name="remember_days" min="0" max="90" value="<?php echo (int) $s['remember_days']; ?>"><span>0 = off. When set, the login step shows a "Remember this device" box, and members who tick it are not asked again on that browser until the days pass.</span></label>
		</div>
		<div class="card" style="background:transparent;box-shadow:none;padding:0"><button class="btn p">Save settings</button></div>
	</form>
	<div class="card">
		<div class="hd"><span class="n">4</span><h2>Member locked out? Reset their second step</h2></div>
		<p class="sub">If a member lost their phone, remove their second step. They can sign in with their password and set it up again.</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
			<input type="hidden" name="action" value="mrsh_2fa_reset"><?php wp_nonce_field( 'mrsh_2fa_reset' ); ?>
			<input type="email" name="email" placeholder="member@email.com" style="width:300px"> <button class="btn d">Reset two-step login</button>
		</form>
		<?php if ( $rows ) : ?>
		<table style="margin-top:16px"><thead><tr><th>Member</th><th>Method</th><th></th></tr></thead><tbody>
			<?php foreach ( array_slice( $rows, 0, 40 ) as $r ) : $u = get_userdata( (int) $r->user_id ); if ( ! $u ) { continue; } ?>
			<tr><td><a href="<?php echo esc_url( get_edit_user_link( $u->ID ) ); ?>"><?php echo esc_html( $u->display_name ); ?></a> <small style="color:#6b7280"><?php echo esc_html( $u->user_email ); ?></small></td><td><span class="pill"><?php echo esc_html( self::label( $r->meta_value ) ); ?></span></td>
			<td><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:0"><input type="hidden" name="action" value="mrsh_2fa_reset"><input type="hidden" name="uid" value="<?php echo (int) $u->ID; ?>"><?php wp_nonce_field( 'mrsh_2fa_reset' ); ?><button class="btn s d">Reset</button></form></td></tr>
			<?php endforeach; ?>
		</tbody></table>
		<?php endif; ?>
	</div>
</div>
		<?php
		echo '</div>';
	}

	public static function save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_2fa_settings' );
		$roles = isset( $_POST['required'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['required'] ) ) : array();
		update_option( self::OPT, array(
			'enabled'  => empty( $_POST['enabled'] ) ? 0 : 1,
			'required' => $roles,
			'issuer'   => 'MyRishta',
			'ttl'      => max( 3, min( 30, (int) ( $_POST['ttl'] ?? 10 ) ) ),
			'social_skip'   => empty( $_POST['social_ask'] ) ? 1 : 0,
			'allow_app'     => empty( $_POST['allow_app'] ) ? 0 : 1,
			'allow_email'   => 1, // email is always the safe fallback
			'allow_wa'      => empty( $_POST['allow_wa'] ) ? 0 : 1,
			'allow_tg'      => empty( $_POST['allow_tg'] ) ? 0 : 1,
			'max_tries'     => max( 3, min( 10, (int) ( $_POST['max_tries'] ?? 5 ) ) ),
			'remember_days' => max( 0, min( 90, (int) ( $_POST['remember_days'] ?? 0 ) ) ),
		) );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-2fa' ) );
		exit;
	}
}
