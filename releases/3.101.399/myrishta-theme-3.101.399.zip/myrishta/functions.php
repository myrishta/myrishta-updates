<?php
require_once __DIR__ . '/inc-bilingual.php';
require_once __DIR__ . '/inc-license.php';
/** Unlicensed copy of the theme: visitors see a short notice instead of the site. Login and the license page stay open. */
add_action( 'template_redirect', function () {
	if ( MRSH_License::ok() || current_user_can( 'manage_options' ) ) {
		return;
	}
	status_header( 503 );
	nocache_headers();
	wp_die( 'This copy of the My Rishta theme is not licensed. The site owner can activate it under Settings > MyRishta license.', 'Not licensed', array( 'response' => 503 ) );
}, 0 );
/** My Rishta theme: small and fast. Reads the same profiles, fields and settings as the old theme. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
define( 'MRT_VER', '3.101.399' );

add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'custom-logo' );
	register_nav_menus( array( 'primary' => 'Main menu', 'footer' => 'Footer menu' ) );
	// Small images only: cards use the 300px size every upload already has.
} );

/** The stylesheet is printed inline (about 15 KB): it cannot be missed by caching or CSS optimisers and saves a request. */
add_action( 'wp_head', function () {
	$f   = get_template_directory() . '/assets/theme.css';
	$css = is_readable( $f ) ? file_get_contents( $f ) : ''; // phpcs:ignore
	if ( '' === $css ) {
		echo '<link rel="stylesheet" href="' . esc_url( get_template_directory_uri() . '/assets/theme.css?v=' . MRT_VER ) . '">';
		return;
	}
	$css = preg_replace( '#/\*.*?\*/#s', '', $css );
	$css = preg_replace( '/\s+/', ' ', $css );
	echo '<style id="mrt-css" data-no-optimize="1" data-no-minify="1">' . $css . '</style>' . "\n"; // phpcs:ignore
}, 1 );

/** One value from the saved settings of the old theme (option core_admin_values), e.g. mrt_opt('design','logo_url'). */
function mrt_opt( $a, $b = null, $default = '' ) {
	static $o = null;
	if ( null === $o ) {
		$o = get_option( 'core_admin_values' );
		$o = is_array( $o ) ? $o : array();
	}
	if ( null === $b ) {
		return isset( $o[ $a ] ) ? $o[ $a ] : $default;
	}
	return isset( $o[ $a ][ $b ] ) ? $o[ $a ][ $b ] : $default;
}

function mrt_link( $key, $fallback = '/' ) {
	$u = mrt_opt( 'links', $key, '' );
	return $u ? $u : home_url( $fallback );
}

/** Profile fields (option cfields) as a list of [label, key, type, taxonomy]. */
function mrt_fields() {
	$cf  = get_option( 'cfields' );
	$out = array();
	if ( is_array( $cf ) && ! empty( $cf['dbkey'] ) ) {
		foreach ( (array) $cf['dbkey'] as $n => $key ) {
			$out[] = array(
				'label' => isset( $cf['name'][ $n ] ) ? trim( (string) $cf['name'][ $n ] ) : $key,
				'key'   => $key,
				'type'  => isset( $cf['fieldtype'][ $n ] ) ? $cf['fieldtype'][ $n ] : 'input',
				'tax'   => isset( $cf['taxonomy'][ $n ] ) ? $cf['taxonomy'][ $n ] : '',
			);
		}
	}
	return $out;
}

/** Fields that are never shown on a public page. */
function mrt_private( $f ) {
	return (bool) preg_match( '/phone|mobile|contact|whatsapp|email/i', $f['label'] . ' ' . $f['key'] );
}

function mrt_card_image( $id, $size = 'medium' ) {
	if ( has_post_thumbnail( $id ) ) {
		return get_the_post_thumbnail( $id, $size, array( 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '(max-width:600px) 46vw, 240px' ) );
	}
	$fb = mrt_opt( 'design', 'fallback_image', mrt_opt( 'fallback_image', null, '' ) );
	$fb = $fb ? $fb : mrt_opt( 'fallback_image', null, '' );
	return $fb ? '<img src="' . esc_url( $fb ) . '" alt="" loading="lazy" decoding="async">' : '';
}

/** Photo to show for a profile: featured image, or the first real photo attached to it (the file must exist). Remembered in post meta. */
function mrt_photo_id( $id ) {
	$t = (int) get_post_thumbnail_id( $id );
	if ( $t && file_exists( (string) get_attached_file( $t ) ) ) {
		return $t;
	}
	$c = (int) get_post_meta( $id, '_mrt_ph', true );
	if ( $c > 0 && file_exists( (string) get_attached_file( $c ) ) ) {
		return $c;
	}
	$found = 0;
	// The old theme also kept the main photo as image_aid (attachment id) or image (address).
	$aid = (int) get_post_meta( $id, 'image_aid', true );
	if ( $aid && file_exists( (string) get_attached_file( $aid ) ) ) {
		$found = $aid;
	}
	if ( ! $found ) {
		$u = (string) get_post_meta( $id, 'image', true );
		if ( $u ) {
			$x = (int) attachment_url_to_postid( $u );
			if ( $x && file_exists( (string) get_attached_file( $x ) ) ) {
				$found = $x;
			}
		}
	}
	if ( ! $found ) {
		foreach ( get_children( array( 'post_parent' => $id, 'post_type' => 'attachment', 'post_mime_type' => 'image', 'numberposts' => 8, 'orderby' => 'menu_order ID', 'order' => 'ASC' ) ) as $a ) {
			if ( file_exists( (string) get_attached_file( $a->ID ) ) ) {
				$found = $a->ID;
				break;
			}
		}
	}
	if ( $found ) {
		update_post_meta( $id, '_mrt_ph', $found );
		return $found;
	}
	// The file may be served by the host even when PHP cannot see it (for example a proxy or CDN in front of uploads).
	// Use the first attached image anyway; if its address fails to load, the card shows the private-photo box.
	$t = (int) get_post_thumbnail_id( $id );
	if ( $t ) {
		return $t;
	}
	foreach ( get_children( array( 'post_parent' => $id, 'post_type' => 'attachment', 'post_mime_type' => 'image', 'numberposts' => 1, 'orderby' => 'menu_order ID', 'order' => 'ASC' ) ) as $a ) {
		return (int) $a->ID;
	}
	return 0;
}

/** Address of the live site to borrow photos from when this copy has no uploads folder (test sites such as test.example.com). '' = use local files only. */
function mrt_remote_host() {
	static $h = null;
	if ( null === $h ) {
		$cur = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		$set = trim( (string) mrt_site( 'photo_host', '' ) );
		$set = preg_replace( '#^https?://#', '', rtrim( $set, '/' ) );
		if ( '' === $set && preg_match( '/^(test|staging|stage|dev|new)\./i', $cur ) ) {
			$set = preg_replace( '/^(test|staging|stage|dev|new)\./i', '', $cur );
		}
		$h = ( $set && 0 !== strcasecmp( $set, $cur ) && 'off' !== strtolower( $set ) ) ? $set : '';
	}
	return $h;
}

/** Same file on the live site. */
function mrt_remote_url( $url ) {
	$rh = mrt_remote_host();
	if ( ! $rh || ! $url ) {
		return $url;
	}
	$cur = (string) wp_parse_url( home_url(), PHP_URL_HOST );
	return preg_replace( '#^(https?://)' . preg_quote( $cur, '#' ) . '#i', '$1' . $rh, $url );
}

/** Attachment ids that could be the main photo of a profile, whether or not the file exists here. */
function mrt_photo_candidates( $id ) {
	$c = array( (int) get_post_thumbnail_id( $id ), (int) get_post_meta( $id, '_mrt_ph', true ), (int) get_post_meta( $id, 'image_aid', true ) );
	$u = (string) get_post_meta( $id, 'image', true );
	if ( $u ) {
		$c[] = (int) attachment_url_to_postid( $u );
	}
	foreach ( get_children( array( 'post_parent' => $id, 'post_type' => 'attachment', 'post_mime_type' => 'image', 'numberposts' => 4, 'orderby' => 'menu_order ID', 'order' => 'ASC', 'fields' => 'ids' ) ) as $k => $v ) {
		$c[] = (int) ( is_object( $v ) ? $v->ID : $v );
	}
	return array_values( array_unique( array_filter( $c ) ) );
}

/** Where a profile's photo comes from: array( source, url ). source is local, live or none. Used by the Photo check in the admin. */
function mrt_photo_source( $id, $size = 'medium' ) {
	$pid = mrt_photo_id( $id );
	if ( $pid ) {
		return array( 'local', (string) wp_get_attachment_image_url( $pid, $size ) );
	}
	if ( class_exists( 'MRSH_PhotoBak' ) ) { // safety copy saved in the database
		foreach ( mrt_photo_candidates( $id ) as $cid ) {
			$bu = MRSH_PhotoBak::url( $cid );
			if ( $bu ) {
				return array( 'backup', $bu );
			}
		}
	}
	if ( mrt_remote_host() ) {
		foreach ( mrt_photo_candidates( $id ) as $cid ) {
			$u = wp_get_attachment_image_url( $cid, $size );
			if ( $u ) {
				return array( 'live', mrt_remote_url( $u ) );
			}
		}
		$u = (string) get_post_meta( $id, 'image', true );
		if ( $u && preg_match( '#^https?://#', $u ) ) {
			return array( 'live', mrt_remote_url( $u ) );
		}
	}
	$u = (string) get_post_meta( $id, 'image', true );
	if ( $u && preg_match( '#^https?://#', $u ) ) {
		return array( 'address', $u );
	}
	return array( 'none', '' );
}

/** Address of one attachment size: the local file when it exists, else the same file on the live site. */
function mrt_att_url( $aid, $size = 'large' ) {
	$u = (string) wp_get_attachment_image_url( $aid, $size );
	if ( $u && ! file_exists( (string) get_attached_file( $aid ) ) ) {
		if ( class_exists( 'MRSH_PhotoBak' ) && MRSH_PhotoBak::has( $aid ) ) {
			return MRSH_PhotoBak::url( $aid );
		}
		return mrt_remote_url( $u );
	}
	return $u;
}

/** Picture HTML for a profile: a real attachment in the wanted size, or a copy from the live site, or the old theme's image address, or ''. */
function mrt_photo( $id, $size = 'medium', $attr = array() ) {
	$pid = mrt_photo_id( $id );
	if ( $pid ) {
		$full = (string) wp_get_attachment_image_url( $pid, 'full' );
		$here = file_exists( (string) get_attached_file( $pid ) );
		if ( ! $here && $full ) {
			// File is not in this copy's uploads folder: use the same file from the live site, else the full-size address.
			$u   = mrt_att_url( $pid, $size );
			$alt = isset( $attr['alt'] ) ? $attr['alt'] : '';
			return '<img src="' . esc_url( $u ) . '" alt="' . esc_attr( $alt ) . '" loading="lazy" decoding="async" referrerpolicy="no-referrer" data-full="' . esc_url( mrt_remote_url( $full ) ) . '" onerror="var f=this.getAttribute(\'data-full\');if(f&&this.src!==f){this.removeAttribute(\'data-full\');this.src=f}else{this.parentNode.classList.add(\'nop\');this.remove()}">';
		}
		$attr['data-full'] = $full;
		$attr['onerror']   = "var f=this.getAttribute('data-full');if(f&&this.src!==f){this.removeAttribute('data-full');this.removeAttribute('srcset');this.src=f}else{this.parentNode.classList.add('nop');this.remove()}";
		return wp_get_attachment_image( $pid, $size, false, $attr );
	}
	$src = mrt_photo_source( $id, $size );
	if ( $src[1] ) {
		return '<img src="' . esc_url( $src[1] ) . '" alt="' . esc_attr( isset( $attr['alt'] ) ? $attr['alt'] : '' ) . '" loading="lazy" decoding="async" referrerpolicy="no-referrer" onerror="this.parentNode.classList.add(\'nop\');this.remove()">';
	}
	return '';
}

/** Neutral picture used when there is no photo: soft colour and a person icon, no letters. */
function mrt_placeholder() {
	return mrt_icon( 'user', 'phi' );
}

/** One profile card with a small photo (lazy loaded), badges, quick shortlist and the main details. */
function mrt_card( $p = null ) {
	$p    = get_post( $p );
	$id   = $p->ID;
	$age  = get_post_meta( $id, 'daage', true );
	$name = get_the_title( $p );
	$ini  = function_exists( 'mb_substr' ) ? mb_strtoupper( mb_substr( trim( $name ), 0, 1 ) ) : strtoupper( substr( trim( $name ), 0, 1 ) );
	$link = esc_url( get_permalink( $p ) );
	$set  = class_exists( 'MRSH_Manage' ) ? MRSH_Manage::get() : array( 'photos' => 1, 'blurguest' => 0 );
	$blur = ! empty( $set['blurguest'] ) && ! is_user_logged_in();
	$blur = (bool) apply_filters( 'mrt_blur', $blur, $id );
	$img  = ! empty( $set['photos'] ) ? mrt_photo( $id, 'medium', array( 'loading' => 'lazy', 'decoding' => 'async', 'alt' => $name, 'sizes' => '(max-width:600px) 46vw, 240px' ) ) : '';
	$bits = array();
	$ic   = array( 'country' => 'pin', 'education' => 'cap', 'occupation' => 'work', 'maritalstatus' => 'ring' );
	foreach ( array_keys( $ic ) as $t ) {
		if ( ! taxonomy_exists( $t ) ) {
			continue;
		}
		$n = wp_get_object_terms( $id, $t );
		if ( is_wp_error( $n ) || ! $n ) {
			continue;
		}
		$pick = $n[0];
		foreach ( $n as $tm ) {
			if ( (int) $tm->parent ) { // city (child) is more useful than the country
				$pick = $tm;
			}
		}
		$bits[ $t ] = str_replace( '_', ' ', $pick->name );
	}
	$new  = ( time() - get_post_time( 'U', true, $p ) ) < 7 * DAY_IN_SECONDS;
	$on   = class_exists( 'MRSH_Mem_Extras' ) && 'Online now' === MRSH_Mem_Extras::seen_label( (int) $p->post_author );
	$fav  = is_user_logged_in() && in_array( $id, array_map( 'intval', (array) get_user_meta( get_current_user_id(), 'favorite', true ) ), true );
	$pm   = ( is_user_logged_in() && class_exists( 'MRSH_Match' ) ) ? MRSH_Match::pct_for_viewer( $p ) : null;
	$bg   = mrt_badges( $p );
	$gen  = '';
	if ( taxonomy_exists( 'dagender' ) ) {
		$gn  = wp_get_object_terms( $id, 'dagender', array( 'fields' => 'names', 'number' => 1 ) );
		$gen = ( ! is_wp_error( $gn ) && $gn ) ? $gn[0] : '';
	}
	$nop = ( '' === trim( (string) $img ) );
	echo '<article class="card"><div class="phw"><a class="ph av c' . (int) ( $id % 6 ) . ( $blur ? ' blur' : '' ) . ( $nop ? ' nop' : '' ) . '" href="' . $link . '" aria-label="' . esc_attr( $name ) . '">'; // phpcs:ignore
	$pvl = ( $nop && ! mrt_photo_candidates( $id ) && '' === (string) get_post_meta( $id, 'image', true ) ) ? 'Photo coming soon' : 'Photo is private';
	echo '<span>' . mrt_placeholder() . '</span>' . $img . '<span class="pvt">' . mrt_icon( 'shield' ) . '<b>' . esc_html( $pvl ) . '</b></span>'; // phpcs:ignore
	echo '<span class="bdg">';
	if ( 'yes' === get_post_meta( $id, 'featured', true ) ) {
		echo '<em class="b-f">' . mrt_icon( 'star' ) . 'Featured</em>'; // phpcs:ignore
	}
	if ( $bg['ver'] ) {
		echo '<em class="b-v">' . mrt_icon( 'shield' ) . 'Verified</em>'; // phpcs:ignore
	}
	if ( $bg['plan'] ) {
		echo '<em class="b-p"' . ( $bg['col'] ? ' style="background:' . esc_attr( $bg['col'] ) . '"' : '' ) . '>' . esc_html( $bg['plan'] ) . '</em>';
	}
	if ( ! empty( $bg['found'] ) ) {
		echo '<em class="b-fm">Founding member</em>';
	}
	if ( $new ) {
		echo '<em class="b-n">New</em>';
	}
	echo '</span>';
	if ( $on ) {
		echo '<i class="dot" title="Online now"></i>';
	}
	echo '</a>';
	echo '<button type="button" class="reqph" data-photoreq="' . (int) $id . '">' . mrt_icon( 'user' ) . 'Request photo</button>'; // phpcs:ignore
	echo '<button type="button" class="hrt' . ( $fav ? ' on' : '' ) . '" data-act="fav" data-pid="' . (int) $id . '" aria-label="Shortlist">' . mrt_icon( 'heart' ) . '</button></div>'; // phpcs:ignore
	echo '<div class="bd2"><a class="tt" href="' . $link . '"><b>' . esc_html( $name ) . '</b>' . ( $age ? '<span class="ag">' . esc_html( $age ) . ' yrs</span>' : '' ) . '</a>'; // phpcs:ignore
	if ( $gen || $pm ) {
		echo '<div class="ln">' . ( $gen ? '<span>' . esc_html( $gen ) . '</span>' : '' ) . ( $pm ? '<span class="pct2">' . mrt_icon( 'heart' ) . (int) $pm[0] . '% match</span>' : '' ) . '</div>'; // phpcs:ignore
	}
	echo '<dl class="kv">';
	$lab = array( 'country' => 'Lives in', 'education' => 'Education', 'occupation' => 'Work', 'maritalstatus' => 'Status' );
	foreach ( $ic as $t => $icon ) {
		if ( ! empty( $bits[ $t ] ) ) {
			echo '<div><dt>' . esc_html( $lab[ $t ] ) . '</dt><dd>' . esc_html( $bits[ $t ] ) . '</dd></div>';
		}
	}
	$wamsg = 'https://wa.me/?text=' . rawurlencode( $name . ' on My Rishta Pakistan: ' . get_permalink( $p ) );
	echo '</dl><div class="cact2"><button type="button" class="btn sm" data-act="interest" data-pid="' . (int) $id . '">' . mrt_icon( 'heart' ) . 'Send interest</button><a class="btn sm line" href="' . $link . '">View profile</a><a class="btn sm line ico" target="_blank" rel="noopener" href="' . esc_url( $wamsg ) . '" aria-label="Share this profile on WhatsApp" title="Share on WhatsApp">' . mrt_icon( 'chat' ) . '</a><button type="button" class="btn sm line ico" data-act="report" data-pid="' . (int) $id . '" aria-label="Report this profile" title="Report">' . mrt_icon( 'flag' ) . '</button></div></div></article>'; // phpcs:ignore
}

/** One match tile for My account > Matches: photo, name, score ring, reason chips and buttons. $both = also show how well you fit them. */
function mrt_match_tile( $m, $both = false ) {
	$p    = $m['post'];
	$id   = (int) $p->ID;
	$name = get_the_title( $p );
	$age  = (int) get_post_meta( $id, 'daage', true );
	$link = esc_url( get_permalink( $p ) );
	$pct  = max( 0, min( 100, (int) $m['pct'] ) );
	$back = isset( $m['back'] ) ? max( 0, min( 100, (int) $m['back'] ) ) : null;
	$img  = mrt_photo( $id, 'medium', array( 'loading' => 'lazy', 'decoding' => 'async', 'alt' => $name ) );
	$nop  = '' === trim( (string) $img );
	$o    = '<article class="mt"><a class="mt-ph c' . ( $id % 6 ) . ( $nop ? ' nop' : '' ) . '" href="' . $link . '" aria-label="' . esc_attr( $name ) . '"><span class="mt-i">' . mrt_icon( 'user' ) . '</span>' . $img . '</a>'; // phpcs:ignore
	$o   .= '<div class="mt-b"><div class="mt-h"><a class="mt-n" href="' . $link . '"><b>' . esc_html( $name ) . '</b>' . ( $age ? '<small>' . $age . ' yrs</small>' : '' ) . '</a>';
	$o   .= '<span class="mt-ring" style="--p:' . $pct . '"><b>' . $pct . '%</b></span></div>';
	if ( null !== $back ) {
		$o .= '<div class="mt-bars"><div><span>You fit them</span><i><u style="width:' . $pct . '%"></u></i><em>' . $pct . '%</em></div><div><span>They fit you</span><i><u style="width:' . $back . '%"></u></i><em>' . $back . '%</em></div></div>';
	}
	if ( ! empty( $m['why'] ) ) {
		$o .= '<ul class="mt-w">';
		foreach ( array_slice( (array) $m['why'], 0, 5 ) as $w ) {
			$o .= '<li>' . mrt_icon( 'shield' ) . esc_html( $w ) . '</li>'; // phpcs:ignore
		}
		$o .= '</ul>';
	}
	$o .= '<div class="mt-a"><a class="btn sm" href="' . $link . '">View profile</a><button type="button" class="btn sm line" data-act="hide" data-pid="' . $id . '">Not interested</button></div></div></article>';
	return $o;
}

/** Numbers for the home page (cached 6 hours). */
function mrt_stats() {
	$s = get_transient( 'mrt_stats' );
	if ( is_array( $s ) ) {
		return $s;
	}
	$c = wp_count_posts( 'listing_type' );
	$s = array( 'profiles' => (int) ( $c->publish ?? 0 ), 'cities' => 0, 'week' => 0 );
	if ( taxonomy_exists( 'country' ) ) {
		$n = wp_count_terms( array( 'taxonomy' => 'country', 'hide_empty' => true ) );
		$s['cities'] = is_wp_error( $n ) ? 0 : (int) $n;
	}
	$w = new WP_Query( array( 'post_type' => 'listing_type', 'posts_per_page' => 1, 'fields' => 'ids', 'date_query' => array( array( 'after' => '7 days ago' ) ) ) );
	$s['week'] = (int) $w->found_posts;
	set_transient( 'mrt_stats', $s, 6 * HOUR_IN_SECONDS );
	return $s;
}

/** Browse chips for one taxonomy: [name, url, count], most used first (cached 12 hours). */
function mrt_chips( $tax, $n = 10 ) {
	$k = 'mrt_ch_' . $tax . $n;
	$c = get_transient( $k );
	if ( is_array( $c ) ) {
		return $c;
	}
	$out = array();
	if ( taxonomy_exists( $tax ) ) {
		$t = get_terms( array( 'taxonomy' => $tax, 'orderby' => 'count', 'order' => 'DESC', 'number' => $n, 'hide_empty' => true ) );
		if ( ! is_wp_error( $t ) ) {
			foreach ( $t as $x ) {
				$out[] = array( $x->name, add_query_arg( array( 'post_type' => 'listing_type', 's' => '', 'tax_' . $tax => $x->slug ), home_url( '/' ) ), (int) $x->count );
			}
		}
	}
	set_transient( $k, $out, 12 * HOUR_IN_SECONDS );
	return $out;
}

/** The filters shown on the search forms. name => taxonomy. Uses the same parameter names as the old theme. */
function mrt_filters() {
	return array(
		'tax_dagender'      => 'Gender',
		'tax_country'       => 'Country',
		'tax_religion'      => 'Religion',
		'tax_caste'         => 'Caste',
		'tax_education'     => 'Education',
		'tax_occupation'    => 'Occupation',
		'tax_maritalstatus' => 'Marital status',
	);
}

function mrt_search_form( $compact = false ) {
	$act = home_url( '/' );
	echo '<form class="sbox" method="get" action="' . esc_url( $act ) . '" role="search"><input type="hidden" name="post_type" value="listing_type">';
	echo '<input type="search" name="s" placeholder="Search name or keyword" value="' . esc_attr( get_search_query() ) . '">';
	$show = $compact ? array( 'tax_dagender', 'tax_country' ) : array_keys( mrt_filters() );
	foreach ( mrt_filters() as $k => $label ) {
		if ( ! in_array( $k, $show, true ) ) {
			continue;
		}
		$tax = substr( $k, 4 );
		if ( ! taxonomy_exists( $tax ) ) {
			continue;
		}
		$terms = get_terms( array( 'taxonomy' => $tax, 'hide_empty' => true, 'number' => 300 ) );
		if ( is_wp_error( $terms ) || ! $terms ) {
			continue;
		}
		$cur = isset( $_GET[ $k ] ) ? sanitize_title( wp_unslash( $_GET[ $k ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		echo '<select name="' . esc_attr( $k ) . '" aria-label="' . esc_attr( $label ) . '"><option value="">' . esc_html( $label ) . '</option>';
		foreach ( $terms as $t ) {
			echo '<option value="' . esc_attr( $t->slug ) . '"' . selected( $cur, $t->slug, false ) . '>' . esc_html( $t->name ) . '</option>';
		}
		echo '</select>';
	}
	if ( ! $compact ) {
		$a = isset( $_GET['age_min'] ) ? absint( $_GET['age_min'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$b = isset( $_GET['age_max'] ) ? absint( $_GET['age_max'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		echo '<input type="number" min="18" max="99" name="age_min" placeholder="Age from" value="' . esc_attr( $a ) . '"><input type="number" min="18" max="99" name="age_max" placeholder="Age to" value="' . esc_attr( $b ) . '">';
	}
	echo '<button class="btn" type="submit">' . mrt_icon( 'search' ) . 'Search</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput
}

/** Profile searches: turn the form fields into a query. */
add_action( 'pre_get_posts', function ( $q ) {
	if ( is_admin() || ! $q->is_main_query() ) {
		return;
	}
	$is_prof = $q->is_post_type_archive( 'listing_type' ) || ( $q->is_search() && isset( $_GET['post_type'] ) && 'listing_type' === $_GET['post_type'] ); // phpcs:ignore WordPress.Security.NonceVerification
	if ( ! $is_prof ) {
		return;
	}
	$q->set( 'post_type', 'listing_type' );
	$sort = isset( $_GET['sort'] ) ? sanitize_key( $_GET['sort'] ) : ''; // phpcs:ignore
	if ( 'young' === $sort || 'old' === $sort ) {
		$q->set( 'meta_key', 'daage' );
		$q->set( 'orderby', 'meta_value_num' );
		$q->set( 'order', 'young' === $sort ? 'ASC' : 'DESC' );
	}
	if ( 'pop' === $sort ) {
		$pop = mrt_popular_ids();
		if ( $pop ) {
			$q->set( 'post__in', $pop );
			$q->set( 'orderby', 'post__in' );
		}
	}
	$q->set( 'posts_per_page', max( 6, (int) mrt_opt( 'search', 'perpage', 12 ) ) );
	$tax = array();
	foreach ( array_keys( mrt_filters() ) as $k ) {
		if ( ! empty( $_GET[ $k ] ) && taxonomy_exists( substr( $k, 4 ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$tax[] = array( 'taxonomy' => substr( $k, 4 ), 'field' => 'slug', 'terms' => sanitize_title( wp_unslash( $_GET[ $k ] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification
		}
	}
	if ( $tax ) {
		$q->set( 'tax_query', $tax );
	}
	$min = isset( $_GET['age_min'] ) ? absint( $_GET['age_min'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
	$max = isset( $_GET['age_max'] ) ? absint( $_GET['age_max'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
	if ( $min || $max ) {
		$q->set( 'meta_query', array( array( 'key' => 'daage', 'value' => array( $min ? $min : 18, $max ? $max : 99 ), 'type' => 'NUMERIC', 'compare' => 'BETWEEN' ) ) );
	}
} );

/** The old theme's rule "members must log in to search". */
function mrt_must_login() {
	return ! is_user_logged_in() && '1' === (string) mrt_opt( 'search', 'mustlogin', '0' );
}

function mrt_login_url() {
	return mrt_link( 'myaccount', '/my-account/' );
}

/** Menu items as plain links (no lists), to keep the header light. */
class MRT_Flat_Walker extends Walker_Nav_Menu {
	public function start_lvl( &$output, $depth = 0, $args = null ) {}
	public function end_lvl( &$output, $depth = 0, $args = null ) {}
	public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
		if ( $depth > 0 ) {
			return;
		}
		$output .= '<a href="' . esc_url( $item->url ) . '">' . esc_html( $item->title ) . '</a>';
	}
	public function end_el( &$output, $item, $depth = 0, $args = null ) {}
}


/** Light icons: one small SVG sprite, no icon font and no extra requests. */
function mrt_icon( $n, $cls = '' ) {
	return '<svg class="ic ' . esc_attr( $cls ) . '" aria-hidden="true" width="20" height="20"><use href="#i-' . esc_attr( $n ) . '"/></svg>';
}

/** Puts a round icon in front of the heading of each account box, chosen from the heading words. */
if ( ! function_exists( 'mrt_account_icons' ) ) {
	function mrt_account_icons( $html ) {
		$map = array( 'view' => 'user', 'payment' => 'shield', 'proof' => 'shield', 'guardian' => 'shield', 'selfie' => 'user', 'strength' => 'star', 'calendar' => 'book', 'meeting' => 'book', 'guide' => 'book', 'saved' => 'search', 'search' => 'search', 'invite' => 'share', 'friend' => 'share', 'refer' => 'share', 'folder' => 'heart', 'shortlist' => 'heart', 'notif' => 'mail', 'verif' => 'check', 'trust' => 'shield', 'safety' => 'shield', 'profile' => 'user', 'match' => 'heart', 'phone' => 'phone', 'message' => 'chat' );
		$n   = 0;
		return (string) preg_replace_callback(
			'#(<(?:div|form|section)[^>]*class="[^"]*\bbox\b[^"]*"[^>]*>)\s*<h([23])([^>]*)>(.*?)</h\2>#s',
			function ( $m ) use ( $map, &$n ) {
				if ( false !== strpos( $m[4], 'class="ib' ) || false !== strpos( $m[4], '<svg' ) ) {
					return $m[0];
				}
				$icon = 'star';
				$low  = strtolower( wp_strip_all_tags( $m[4] ) );
				foreach ( $map as $k => $v ) {
					if ( false !== strpos( $low, $k ) ) {
						$icon = $v;
						break;
					}
				}
				++$n;
				return $m[1] . '<h' . $m[2] . $m[3] . ' class="xh"><span class="ib c' . ( ( $n % 5 ) + 1 ) . '">' . mrt_icon( $icon ) . '</span><span>' . $m[4] . '</span></h' . $m[2] . '>';
			},
			$html
		);
	}
}

function mrt_sprite() {
	$p = array(
		'home'   => 'M3 11.5 12 4l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z',
		'search' => 'M10.5 3a7.5 7.5 0 1 0 4.6 13.4l4.8 4.8 1.4-1.4-4.8-4.8A7.5 7.5 0 0 0 10.5 3zm0 2a5.5 5.5 0 1 1 0 11 5.5 5.5 0 0 1 0-11z',
		'plus'   => 'M11 4h2v7h7v2h-7v7h-2v-7H4v-2h7z',
		'user'   => 'M12 12a5 5 0 1 0 0-10 5 5 0 0 0 0 10zm-8 9a8 8 0 0 1 16 0z',
		'star'   => 'm12 2 3 6.5 7 .8-5.2 4.8 1.5 7L12 17.6 5.7 21l1.5-7L2 9.3l7-.8z',
		'heart'  => 'M12 21s-8-5.2-8-11a4.6 4.6 0 0 1 8-3 4.6 4.6 0 0 1 8 3c0 5.800-8 11-8 11z',
		'chat'   => 'M4 4h16a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1H9l-5 4V5a1 1 0 0 1 1-1z',
		'smile'  => 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm-3.500 7a1.200 1.200 0 1 1 0 2.400A1.200 1.200 0 0 1 8.500 9zm7 0a1.200 1.200 0 1 1 0 2.400 1.200 1.200 0 0 1 0-2.400zM7.500 14h9a4.500 4.500 0 0 1-9 0z',
		'share'  => 'M18 16a3 3 0 0 0-2.200 1l-6.500-3.300a3 3 0 0 0 0-1.400L15.800 9A3 3 0 1 0 15 7l-6.500 3.300a3 3 0 1 0 0 3.400L15 17a3 3 0 1 0 3-1z',
		'flag'   => 'M5 3h2v18H5zm3 1h11l-2.500 4L19 12H8z',
		'phone'  => 'M6.600 10.800a15 15 0 0 0 6.600 6.600l2.200-2.200a1 1 0 0 1 1-.250 11 11 0 0 0 3.600.600 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.500a1 1 0 0 1 1 1c0 1.300.200 2.500.600 3.600a1 1 0 0 1-.250 1z',
		'mail'   => 'M3 5h18a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1zm1 2v.500l8 5 8-5V7zm0 3v7h16v-7l-8 5z',
		'check'  => 'M9 16.200 4.800 12l-1.400 1.400L9 19 21 7l-1.400-1.400z',
		'chev'   => 'M7 10l5 5 5-5z',
		'pin'    => 'M12 2a7 7 0 0 0-7 7c0 5.200 7 13 7 13s7-7.800 7-13a7 7 0 0 0-7-7zm0 9.500A2.500 2.500 0 1 1 12 6.500a2.500 2.500 0 0 1 0 5z',
		'cap'    => 'M12 3 1 9l11 6 9-4.900V17h2V9zM5 13.200V17c0 1.700 3.100 3 7 3s7-1.300 7-3v-3.800L12 17z',
		'work'   => 'M9 4h6a1 1 0 0 1 1 1v2h4a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1h4V5a1 1 0 0 1 1-1zm1 2v1h4V6z',
		'shield' => 'M12 2 4 5v6c0 5 3.400 9.500 8 11 4.600-1.500 8-6 8-11V5z',
		'ring'   => 'M12 8a7 7 0 1 0 0 14 7 7 0 0 0 0-14zm0 2a5 5 0 1 1 0 10 5 5 0 0 1 0-10zM9 2h6l2 3-5 2-5-2z',
		'book'   => 'M5 3h12a2 2 0 0 1 2 2v16H7a2 2 0 0 1-2-2zm2 2v12.500A2 2 0 0 1 8 17h9V5z',
		'globe'  => 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm6.900 9h-3.100a15 15 0 0 0-1.200-5.200A8 8 0 0 1 18.900 11zM12 4.100c.9 1.100 1.700 3.200 1.900 5.900h-3.800c.2-2.700 1-4.800 1.900-5.900zM4.100 13h3.100c.1 1.900.5 3.700 1.200 5.200A8 8 0 0 1 4.100 13zm3.100-2H4.100a8 8 0 0 1 4.300-5.200A15 15 0 0 0 7.200 11zM12 19.900c-.9-1.100-1.700-3.200-1.900-5.900h3.800c-.2 2.700-1 4.800-1.900 5.900zM15.600 18.200c.7-1.500 1.100-3.300 1.200-5.200h3.100a8 8 0 0 1-4.300 5.200z',
	);
	$o = '<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>';
	foreach ( $p as $k => $d ) {
		$o .= '<symbol id="i-' . $k . '" viewBox="0 0 24 24"><path fill="currentColor" d="' . $d . '"/></symbol>';
	}
	return $o . '</defs></svg>';
}

/** Icon and colour for each kind of detail on a profile. */
function mrt_field_style( $label ) {
	$l = strtolower( $label );
	$map = array(
		'/education/'              => array( 'cap', 'c3' ),
		'/occupation|job|work/'    => array( 'work', 'c4' ),
		'/religion|sect/'          => array( 'book', 'c2' ),
		'/caste/'                  => array( 'star', 'c5' ),
		'/marital|children/'       => array( 'ring', 'c1' ),
		'/national|country|city/'  => array( 'globe', 'c3' ),
		'/age|gender/'             => array( 'user', 'c1' ),
		'/created/'                => array( 'user', 'c4' ),
	);
	foreach ( $map as $re => $v ) {
		if ( preg_match( $re, $l ) ) {
			return $v;
		}
	}
	return array( 'check', 'c2' );
}

/** Brand colours from the old theme settings (design > color_primary / color_secondary). */
add_action( 'wp_head', function () {
	$p = sanitize_hex_color( (string) mrt_opt( 'design', 'color_primary', '' ) );
	$s = sanitize_hex_color( (string) mrt_opt( 'design', 'color_secondary', '' ) );
	if ( $p || $s ) {
		echo '<style id="mrt-vars">:root{' . ( $p ? '--p:' . esc_attr( $p ) . ';' : '' ) . ( $s ? '--s:' . esc_attr( $s ) . ';' : '' ) . '}</style>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}, 5 );

/** Small script for wink / shortlist / message buttons. Loaded only for visitors who can use them. */
add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_script( 'mrt-app', get_template_directory_uri() . '/assets/app.js', array(), wp_get_theme()->get( 'Version' ), true );
	wp_enqueue_script( 'mrt-urdu', get_template_directory_uri() . '/assets/urdu.js', array(), wp_get_theme()->get( 'Version' ), true );
	wp_add_inline_script( 'mrt-urdu', 'window.MRT_UR=' . wp_json_encode( get_template_directory_uri() . '/assets/urdu-tr.js?ver=' . wp_get_theme()->get( 'Version' ) ) . ';', 'before' );
	wp_localize_script( 'mrt-app', 'MRT', array( 'ajax' => admin_url( 'admin-ajax.php' ), 'n' => wp_create_nonce( 'mrt' ), 'in' => is_user_logged_in() ? '1' : '', 'login' => mrt_login_url(), 'vapid' => ( is_user_logged_in() && class_exists( 'MRSH_Mem_Push' ) ) ? MRSH_Mem_Push::public_key() : '' ) );
}, 20 );

/** Interface styles. Chosen in the admin: My Rishta SEO > Member settings > Interface style. */
function mrt_styles() {
	return array(
		'emerald' => array( 'Maroon and gold', '#9b1b4b', '#6e1230', '#6e1230', '#fbf7f4', 'Georgia,"Times New Roman",serif', 10 ),
		'rose'    => array( 'Rose and violet', '#e11d74', '#7c3aed', '#be185d', '#f6f4ff', '', 16 ),
		'ocean'   => array( 'Ocean blue', '#0369a1', '#0891b2', '#075985', '#f0f9ff', '', 12 ),
		'sunset'  => array( 'Sunset orange', '#ea580c', '#db2777', '#9a3412', '#fff7ed', '', 14 ),
		'night'   => array( 'Night (dark)', '#f472b6', '#a78bfa', '#f9a8d4', '#12121a', '', 14 ),
	);
}

function mrt_style_key() {
	$s = class_exists( 'MRSH_Manage' ) ? MRSH_Manage::get() : array();
	$k = isset( $s['style'] ) ? $s['style'] : 'emerald';
	return isset( mrt_styles()[ $k ] ) ? $k : 'emerald';
}

add_action( 'wp_head', function () {
	$k = mrt_style_key();
	list( , $a, $b, $d, $bg, $font, $r ) = mrt_styles()[ $k ];
	$dark = 'night' === $k;
	$g    = "linear-gradient(90deg,$a,$b)";
	$css  = ":root{--brand:$a;--s:$b;--r:{$r}px}";
	$css .= "body{background:$bg" . ( $dark ? ';color:#e8e8f0' : '' ) . '}';
	if ( $font ) {
		$css .= "h1,h2,h3,.nm,.brand span,.stats b{font-family:$font;letter-spacing:0}";
	}
	$css .= ".btn,.nav a.btn,.pager .current,.tabs a.cur,.chip.on,.chip:hover,.btn.alt,.hsearch .btn{background:$g;color:" . ( $dark ? '#12121a' : '#fff' ) . ';border-color:transparent}';
	$css .= ".btn.line,.nav a.btn.line{background:" . ( $dark ? '#242434' : '#eef2f1' ) . ';color:' . ( $dark ? '#eee' : '#1f2330' ) . '}';
	$css .= ".pct{background:" . ( $dark ? '#1f3a2c' : '#fbeef2' ) . ";color:" . ( $dark ? '#86efac' : '#6e1230' ) . '}';
	$css .= ".hrt.on,.hrt:hover,.shead a,.stats b,.pill{color:$d}.hrt.on svg{fill:$d}.pill{border-color:$a}";
	$css .= ".meter i{background:$g}.bub.me{background:{$a}22}.card .mi svg{color:$a}.vt{color:$a}";
	$css .= ".hero h1{background:$g;-webkit-background-clip:text;background-clip:text;color:transparent}";
	$css .= ".cta{background:linear-gradient(110deg,$a,$b)}.cta .btn{background:#fff;color:$d}";
	$css .= ".hero{background:" . ( $dark ? 'linear-gradient(180deg,#1a1326,#12121a)' : "radial-gradient(900px 300px at 80% -20%,{$b}33,transparent 60%),radial-gradient(800px 300px at 0 0,{$a}26,transparent 55%),$bg" ) . '}';
	if ( 'emerald' === $k ) {
		$css .= ".hero{background:linear-gradient(135deg,#3b0a19,#9b1b4b);color:#fff;padding:34px 0 26px}.hero h1{background:none;color:#fff;-webkit-text-fill-color:#fff}.hero p,.trust{color:#fbe9ee}.stats b{color:#f5d77a}.stats span{color:#f3d9a4}.pill{background:#3b0a19;color:#f5d77a;border-color:#c9962f}.trust svg{color:#f5d77a}";
		$css .= ".site-head{border-bottom:3px solid #c9962f}.card{border-radius:8px}.card .ph{border-radius:0}.hsearch{border-radius:10px}.sec{border-left:4px solid #c9962f;padding-left:10px}.chip{border-radius:6px}.btn,.nav a.btn{border-radius:8px}";
	}
	if ( $dark ) {
		$css .= ".site-head,.card,.box,.steps>div,.hsearch,details.filters,.chip,.msgl a,form.frm{background:#1b1b28;color:#e8e8f0}.site-head{border-color:#2a2a3c}.hsearch select,.hsearch input,.sbox select,.sbox input,.frm input,.frm select,.frm textarea{background:#12121a;color:#eee;border-color:#33344a}.nav a:not(.btn),.card .nm,a,.brand,.brand span{color:#e8e8f0}.card .mi{color:#a0a0b8}.hero p,.trust{color:#cbd5e1}.safe{background:#10261d;color:#86efac}";
	}
	echo '<style id="mrt-style">' . $css . "</style>\n"; // phpcs:ignore
}, 2 );

/** One value from Site Settings (My Rishta SEO > Site Settings). */
function mrt_site( $k, $d = '' ) {
	if ( class_exists( 'MRSH_Site' ) ) {
		$v = MRSH_Site::get( $k );
		return '' === $v || null === $v ? $d : $v;
	}
	return $d;
}

/** Settings that change the look: own colours, profiles per row, profiles per page. */
add_action( 'wp_head', function () {
	$a = mrt_site( 'c1' );
	$b = mrt_site( 'c2' );
	$n = max( 3, min( 8, (int) mrt_site( 'per_row', 4 ) ) );
	$c = '@media(min-width:901px){.grid{grid-template-columns:repeat(' . $n . ',1fr)}}';
	if ( $a ) {
		$b  = $b ? $b : $a;
		$g  = "linear-gradient(90deg,$a,$b)";
		$c .= ":root{--brand:$a;--s:$b}.btn,.nav a.btn,.pager .current,.tabs a.cur,.chip.on,.chip:hover,.btn.alt,.hsearch .btn{background:$g;color:#fff}.hero h1{background:$g;-webkit-background-clip:text;background-clip:text}.cta{background:$g}.cta .btn{color:$a}.meter i{background:$g}.shead a,.stats b{color:$a}";
	}
	echo '<style id="mrt-site">' . $c . "</style>\n"; // phpcs:ignore
}, 3 );

add_action( 'pre_get_posts', function ( $q ) {
	if ( ! is_admin() && $q->is_main_query() && ( $q->is_search() || $q->is_post_type_archive( 'listing_type' ) ) && 'listing_type' === $q->get( 'post_type' ) ) {
		$q->set( 'posts_per_page', max( 6, min( 60, (int) mrt_site( 'per_page', 24 ) ) ) );
	}
}, 20 );

/** Parse "A | B" lines. */
function mrt_pairs( $text ) {
	$out = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $l ) {
		$p = array_map( 'trim', explode( '|', $l, 2 ) );
		if ( 2 === count( $p ) && '' !== $p[0] && '' !== $p[1] ) {
			$out[] = $p;
		}
	}
	return $out;
}

/** Google FAQ markup for the questions on the home page. */
add_action( 'wp_head', function () {
	if ( ! is_front_page() || ! mrt_site( 's_faq', 1 ) ) {
		return;
	}
	$f = mrt_pairs( mrt_site( 'faq' ) );
	if ( ! $f ) {
		return;
	}
	$items = array();
	foreach ( $f as $p ) {
		$items[] = array( '@type' => 'Question', 'name' => $p[0], 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $p[1] ) );
	}
	echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $items ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "</script>\n"; // phpcs:ignore
}, 5 );

/** Floating WhatsApp button. */
add_action( 'wp_footer', function () {
	$n = preg_replace( '/\D/', '', (string) mrt_site( 'whatsapp' ) );
	if ( ! $n || ! mrt_site( 'wa_float', 1 ) ) {
		return;
	}
	echo '<a class="wafab" href="' . esc_url( 'https://wa.me/' . $n ) . '" target="_blank" rel="noopener" aria-label="Chat on WhatsApp"><svg width="26" height="26" viewBox="0 0 24 24" fill="#fff"><path d="M12 2a10 10 0 0 0-8.6 15l-1.4 5 5.2-1.4A10 10 0 1 0 12 2zm5.2 14.2c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.1-4.5-4-4.7-4.2-.1-.2-1.1-1.5-1.1-2.8s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.4 0 .5l-.4.6c-.1.2-.3.3-.1.6.2.3.8 1.3 1.7 2.1 1.2 1 2.1 1.3 2.4 1.5.3.1.4.1.6-.1l.8-1c.2-.3.4-.2.6-.1l1.9.9c.3.1.5.2.5.3.1.2.1.8-.2 1.4z"/></svg></a>'; // phpcs:ignore
}, 30 );

/** Extra search filters: with photo, verified. */
add_action( 'pre_get_posts', function ( $q ) {
	if ( is_admin() || ! $q->is_main_query() || 'listing_type' !== $q->get( 'post_type' ) ) {
		return;
	}
	$mq = (array) $q->get( 'meta_query' );
	if ( ! empty( $_GET['photo'] ) ) { // phpcs:ignore
		$mq[] = array( 'key' => '_thumbnail_id', 'compare' => 'EXISTS' );
	}
	if ( ! empty( $_GET['verified'] ) ) { // phpcs:ignore
		$q->set( 'post__in', mrt_verified_ids() );
	}
	if ( ! empty( $_GET['online'] ) ) { // phpcs:ignore
		$q->set( 'author__in', mrt_online_users() );
	}
	if ( $mq ) {
		$q->set( 'meta_query', $mq );
	}
}, 25 );

/** Profile of the day: a featured (or any) profile, changed every day. */
function mrt_pod() {
	$id = (int) get_transient( 'mrt_pod' );
	if ( $id && 'publish' === get_post_status( $id ) ) {
		return get_post( $id );
	}
	$q = get_posts( array( 'post_type' => 'listing_type', 'post_status' => 'publish', 'numberposts' => 1, 'orderby' => 'rand', 'meta_key' => '_thumbnail_id', 'meta_compare' => 'EXISTS', 'fields' => 'ids' ) );
	if ( ! $q ) {
		return null;
	}
	set_transient( 'mrt_pod', $q[0], DAY_IN_SECONDS );
	return get_post( $q[0] );
}

add_action( 'add_attachment', function ( $aid ) {
	$par = (int) wp_get_post_parent_id( $aid );
	if ( $par ) {
		delete_post_meta( $par, '_mrt_ph' );
	}
} );
add_action( 'set_post_thumbnail', function ( $pid ) {
	delete_post_meta( $pid, '_mrt_ph' );
} );

/** Plans from Site Settings: array of [name, price, [features]]. Empty setting = one Free plan. */
function mrt_plans() {
	$out = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) mrt_site( 'plans' ) ) as $l ) {
		$p = array_map( 'trim', explode( '|', $l ) );
		if ( count( $p ) >= 2 && '' !== $p[0] ) {
			$out[] = array( $p[0], $p[1], isset( $p[2] ) ? array_filter( array_map( 'trim', explode( ';', $p[2] ) ) ) : array(), ( isset( $p[3] ) && preg_match( '/^#[0-9a-f]{3,6}$/i', $p[3] ) ) ? $p[3] : '' );
		}
	}
	if ( ! $out ) {
		$out = array(
			array( 'Free', 'Free', array( 'Create your profile', 'Send interest and messages', 'Match suggestions', 'Phone number stays private' ), '' ),
			array( 'Bronze', 'Rs 1,500', array( 'Everything in Free', 'Bronze badge on your profile', 'Shown higher in search' ), '#b0702d' ),
			array( 'Silver', 'Rs 3,000', array( 'Everything in Bronze', 'Silver badge', 'Priority verification', 'See who viewed you' ), '#8a94a6' ),
			array( 'Gold', 'Rs 5,000', array( 'Everything in Silver', 'Gold badge', 'Featured on the home page', 'Top of search results' ), '#d99a00' ),
		);
	}
	if ( get_option( 'mrsh_plans_free', 0 ) ) {
		foreach ( $out as $i => $o ) {
			$out[ $i ][1] = 0 === $i ? 'Free' : 'Free (launch offer)'; // launch offer (3.101.226)
		}
	}
	return $out;
}

/** Name of the plan to highlight as most popular ('' = automatic). */
function mrt_plan_hot() {
	return (string) get_option( 'mrsh_plans_hot', '' );
}

/** Badges for a profile: verified by the team, secure account, membership plan. */
function mrt_badges( $post ) {
	$post = get_post( $post );
	$b    = array( 'ver' => false, 'sec' => false, 'plan' => '', 'col' => '', 'found' => false );
	if ( ! $post ) {
		return $b;
	}
	$au = (int) $post->post_author;
	$b['found'] = (bool) get_user_meta( $au, 'mrt_founding', true );
	if ( class_exists( 'MRSH_Verified' ) && method_exists( 'MRSH_Verified', 'map' ) ) {
		$m        = (array) MRSH_Verified::map();
		$b['ver'] = in_array( $post->ID, array_map( 'intval', (array) ( $m['v'] ?? array() ) ), true );
		$b['sec'] = in_array( $post->ID, array_map( 'intval', (array) ( $m['s'] ?? array() ) ), true );
	}
	if ( ! $b['ver'] && ( get_user_meta( $au, '_mrsh_id_verified', true ) || in_array( strtolower( (string) get_user_meta( $au, 'ppt_verified', true ) ), array( '1', 'yes', 'true', 'verified' ), true ) ) ) {
		$b['ver'] = true;
	}
	$pl = (string) get_user_meta( $au, 'mrt_plan', true );
	if ( '' === $pl ) {
		$old = trim( (string) get_user_meta( $au, 'ppt_membership', true ) ); // old theme: matched by plan name only
		if ( '' !== $old && ! is_numeric( $old ) ) {
			$pl = $old;
		}
	}
	if ( $pl ) {
		foreach ( mrt_plans() as $i => $p ) {
			if ( 0 === strcasecmp( $p[0], $pl ) ) {
				if ( $i > 0 ) {
					$b['plan'] = $p[0];
					$b['col']  = $p[3];
				}
				break;
			}
		}
	}
	return $b;
}

/** Pills for the profile page. */
function mrt_badge_pills( $post ) {
	$b = mrt_badges( $post );
	$h = '';
	if ( $b['ver'] ) {
		$h .= '<span class="pill pv" title="Checked by the My Rishta team">' . mrt_icon( 'shield' ) . 'Verified by My Rishta</span>';
	}
	if ( ! empty( $b['found'] ) ) {
		$h .= '<span class="pill pp" style="background:#b45309" title="One of the first members who helped start My Rishta">' . mrt_icon( 'star' ) . 'Founding member</span>';
	}
	if ( $b['sec'] ) {
		$h .= '<span class="pill ps" title="Two-step login is on">' . mrt_icon( 'shield' ) . 'Secure account</span>';
	}
	if ( $b['plan'] ) {
		$h .= '<span class="pill pp"' . ( $b['col'] ? ' style="background:' . esc_attr( $b['col'] ) . '"' : '' ) . '>' . mrt_icon( 'star' ) . esc_html( $b['plan'] ) . ' member</span>';
	}
	if ( get_post_meta( get_post( $post )->ID ?? 0, 'mrt_complete', true ) ) {
		$h .= '<span class="pill pp" style="background:#0f766e" title="This profile is fully filled in">' . mrt_icon( 'star' ) . 'Complete profile</span>';
	}
	return $h ? '<p class="pills">' . $h . '</p>' : ''; // phpcs:ignore
}

/** Number of unread messages for the header bubble. */
function mrt_unread() {
	return ( is_user_logged_in() && class_exists( 'MRSH_Members' ) && method_exists( 'MRSH_Members', 'unread_count' ) ) ? (int) MRSH_Members::unread_count( get_current_user_id() ) : 0;
}

/** Profile IDs of verified profiles (for the Verified filter). */
function mrt_verified_ids() {
	$ids = array();
	if ( class_exists( 'MRSH_Verified' ) && method_exists( 'MRSH_Verified', 'map' ) ) {
		$m   = (array) MRSH_Verified::map();
		$ids = array_map( 'intval', (array) ( $m['v'] ?? array() ) );
	}
	return $ids ? $ids : array( 0 );
}

/** Users seen in the last 15 minutes. */
function mrt_online_users() {
	$u = get_users( array( 'meta_key' => 'mrt_seen', 'meta_value' => time() - 900, 'meta_compare' => '>', 'meta_type' => 'NUMERIC', 'fields' => 'ID', 'number' => 200 ) );
	return $u ? array_map( 'intval', $u ) : array( 0 );
}

/** The profile button for the header: "Add profile" for visitors and new members, "Update profile" for members who have one. */
function mrt_cta() {
	static $c = null;
	if ( null === $c ) {
		$add = mrt_link( 'add', '/add-listing/' );
		$c   = array( 'Add profile', $add, 'plus' );
		if ( is_user_logged_in() && class_exists( 'MRSH_Members' ) ) {
			$p = MRSH_Members::my_profile();
			if ( $p ) {
				$c = array( 'Update profile', add_query_arg( 'edit', $p->ID, $add ), 'user' );
			}
		}
	}
	return $c;
}


/* ---------- inner pages: memberships, about, contact, blog, articles ---------- */
/** Pages the theme provides: slug => array( title, template ). */
function mrt_inner_pages() {
	return array(
		'memberships'      => array( 'Memberships', 'page-memberships.php' ),
		'membership-plans' => array( 'Membership plans', 'page-memberships.php' ),
		'badges'           => array( 'Badges', 'page-badges.php' ),
		'about-us'         => array( 'About us', 'page-about.php' ),
		'contact'          => array( 'Contact', 'page-contact.php' ),
		'blog'             => array( 'Blog', 'page-blog.php' ),
	);
}

/** Create any of these pages that do not exist yet (once per theme version, never touches existing pages). */
add_action( 'init', function () {
	if ( get_option( 'mrt_pages_made' ) === MRT_VER ) {
		return;
	}
	update_option( 'mrt_pages_made', MRT_VER, false );
	foreach ( array( 'memberships', 'membership-plans', 'badges', 'contact', 'blog' ) as $slug ) {
		$inn = mrt_inner_pages();
		if ( get_page_by_path( $slug ) || get_posts( array( 'name' => $slug, 'post_type' => 'page', 'post_status' => 'any', 'numberposts' => 1, 'fields' => 'ids' ) ) ) {
			continue;
		}
		$nid = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => $inn[ $slug ][0], 'post_name' => $slug, 'post_content' => '' ) );
		if ( $nid && in_array( $slug, array( 'badges', 'membership-plans' ), true ) ) {
			update_post_meta( $nid, '_mrsh_noindex', 1 ); // these repeat pages that already exist, so keep them out of Google
		}
	}
	foreach ( array( 'badges', 'membership-plans' ) as $dup ) {
		$dp = get_page_by_path( $dup );
		if ( $dp && ! get_post_meta( $dp->ID, '_mrsh_noindex', true ) && ! trim( $dp->post_content ) ) {
			update_post_meta( $dp->ID, '_mrsh_noindex', 1 );
		}
	}
}, 20 );

add_filter( 'template_include', function ( $t ) {
	$map  = mrt_inner_pages();
	$slug = '';
	if ( is_page() ) {
		$slug = (string) get_post_field( 'post_name', get_queried_object_id() );
	} elseif ( is_404() ) {
		$slug = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ), '/' ); // phpcs:ignore
		$slug = basename( $slug );
		if ( isset( $map[ $slug ] ) ) {
			global $wp_query;
			$wp_query->is_404 = false;
			status_header( 200 );
		}
	}
	if ( $slug && isset( $map[ $slug ] ) && file_exists( get_theme_file_path( $map[ $slug ][1] ) ) ) {
		return get_theme_file_path( $map[ $slug ][1] );
	}
	return $t;
}, 99 );

/** Coloured banner at the top of an inner page. */
function mrt_page_hero( $title, $sub = '', $icon = 'star', $crumb = '' ) {
	echo '<section class="phero"><div class="wrap"><span class="pi">' . mrt_icon( $icon ) . '</span><div>'; // phpcs:ignore
	if ( $crumb ) {
		echo '<div class="crumb"><a href="' . esc_url( home_url( '/' ) ) . '">Home</a> &rsaquo; ' . esc_html( $crumb ) . '</div>';
	}
	echo '<h1>' . esc_html( $title ) . '</h1>' . ( $sub ? '<p>' . esc_html( $sub ) . '</p>' : '' ) . '</div></div></section>';
}

/** Contact details, from Site Settings with the organisation's own details as fallback. */
function mrt_contact_info() {
	$host = preg_replace( '/^(test|staging|stage|dev|new|www)\./i', '', (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
	$wa   = preg_replace( '/\D/', '', (string) mrt_site( 'whatsapp', '' ) );
	return array(
		'phone'   => (string) mrt_site( 'phone', ( class_exists( 'MRSH_Options' ) && ! empty( MRSH_Options::org()['phone'] ) ) ? MRSH_Options::org()['phone'] : '+92-42-29292921' ),
		'email'   => (string) mrt_site( 'email', 'support@' . $host ),
		'address' => (string) mrt_site( 'address', 'Shahdara, Lahore 54000, Punjab, Pakistan' ),
		'wa'      => $wa,
	);
}

/** Guides for the Blog page: posts first, then the site's long guide pages. Cached 6 hours. */
function mrt_guides() {
	$c = get_transient( 'mrt_guides' );
	if ( is_array( $c ) ) {
		return $c;
	}
	$out = array();
	foreach ( get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'numberposts' => 80 ) ) as $p ) {
		$out[] = $p;
	}
	$skip = '/terms|privacy|cookie|disclaimer|sitemap|data-deletion|report|profile-guidelines|about|contact|memberships|how-it-works|faq|login|registration|forgot|callback|chatroom|categories|country|profile|add-listing|my-account|top-listings|latest-profiles|success-stories|proposals$|^privacy$|^terms$/i';
	foreach ( get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 'numberposts' => 300, 'orderby' => 'date', 'order' => 'DESC' ) ) as $p ) {
		if ( preg_match( $skip, $p->post_name ) || mb_strlen( wp_strip_all_tags( $p->post_content ) ) < 1800 ) {
			continue;
		}
		$out[] = $p;
	}
	$ids = array_map( function ( $p ) {
		return $p->ID;
	}, $out );
	set_transient( 'mrt_guides', $ids, 6 * HOUR_IN_SECONDS );
	return $ids;
}
add_action( 'save_post', function () {
	delete_transient( 'mrt_guides' );
} );

/** Label and icon for a guide, from its title. */
function mrt_guide_kind( $title ) {
	if ( preg_match( '/scam|safe|fake|notice|warning|red flag|beware/i', $title ) ) {
		return array( 'Safety', 'shield', 'k1' );
	}
	if ( preg_match( '/\brishta in\b|rishta-in|districts/i', $title ) ) {
		return array( 'City guide', 'pin', 'k2' );
	}
	if ( preg_match( '/overseas|uk\b|usa|canada|uae|saudi|abroad|jobs/i', $title ) ) {
		return array( 'Overseas', 'globe', 'k3' );
	}
	if ( preg_match( '/how to|guide|step|proposals|decide/i', $title ) ) {
		return array( 'Guide', 'book', 'k4' );
	}
	return array( 'Article', 'star', 'k5' );
}

/** One guide card. */
function mrt_guide_card( $p ) {
	$p    = get_post( $p );
	$k    = mrt_guide_kind( $p->post_title );
	$txt  = trim( wp_strip_all_tags( strip_shortcodes( $p->post_content ) ) );
	$mins = max( 1, (int) ceil( str_word_count( $txt ) / 200 ) );
	echo '<article class="gcard ' . esc_attr( $k[2] ) . '"><a class="gtop" href="' . esc_url( get_permalink( $p ) ) . '"><span class="gi">' . mrt_icon( $k[1] ) . '</span><em>' . esc_html( $k[0] ) . '</em></a><div class="gb"><a class="gt" href="' . esc_url( get_permalink( $p ) ) . '">' . esc_html( $p->post_title ) . '</a><p class="gm">' . esc_html( wp_trim_words( $txt, 22 ) ) . '</p><span class="gm">' . (int) $mins . ' min read</span></div></article>'; // phpcs:ignore
}

/** Latest guides row for the end of an article. */
function mrt_more_guides( $exclude = 0, $n = 3 ) {
	$ids = array_values( array_diff( mrt_guides(), array( (int) $exclude ) ) );
	if ( ! $ids ) {
		return;
	}
	echo '<h2 class="sec">More guides</h2><div class="gg">';
	foreach ( array_slice( $ids, 0, $n ) as $i ) {
		mrt_guide_card( $i );
	}
	echo '</div>';
}

/** Contact form: sends an email to the site, with a honeypot, a time check and a limit per visitor. */
add_action( 'admin_post_nopriv_mrt_contact', 'mrt_contact_send' );
add_action( 'admin_post_mrt_contact', 'mrt_contact_send' );
function mrt_contact_send() {
	$back = mrt_link( 'contact', '/contact/' );
	if ( is_user_logged_in() ) {
		check_admin_referer( 'mrt_contact' ); // guests: cached pages carry old nonces, so they rely on the honeypot, timer and limit below
	}
	$ip  = mrt_ip();
	$key = 'mrt_ct_' . md5( $ip );
	$n   = (int) get_transient( $key );
	$t   = isset( $_POST['t'] ) ? (int) $_POST['t'] : 0; // phpcs:ignore
	if ( ! empty( $_POST['website'] ) || time() - $t < 4 ) { // phpcs:ignore
		wp_safe_redirect( add_query_arg( 'sent', 1, $back ) );
		exit;
	}
	if ( $n >= 4 ) {
		wp_safe_redirect( add_query_arg( 'sent', 'limit', $back ) );
		exit;
	}
	$name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : ''; // phpcs:ignore
	$mail = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : ''; // phpcs:ignore
	$sub  = isset( $_POST['topic'] ) ? sanitize_text_field( wp_unslash( $_POST['topic'] ) ) : 'Question'; // phpcs:ignore
	$msg  = isset( $_POST['msg'] ) ? sanitize_textarea_field( wp_unslash( $_POST['msg'] ) ) : ''; // phpcs:ignore
	if ( strlen( $name ) < 2 || ! is_email( $mail ) || strlen( $msg ) < 10 ) {
		wp_safe_redirect( add_query_arg( 'sent', 'bad', $back ) );
		exit;
	}
	set_transient( $key, $n + 1, HOUR_IN_SECONDS );
	$ci = mrt_contact_info();
	$to = array( get_option( 'admin_email' ) );
	if ( is_email( $ci['email'] ) && $ci['email'] !== $to[0] ) {
		$to[] = $ci['email'];
	}
	wp_mail( $to, '[' . get_bloginfo( 'name' ) . '] ' . $sub . ' from ' . $name, $msg . "\n\n--\n" . $name . ' <' . $mail . ">\nProfile / phone: " . ( isset( $_POST['ref'] ) ? sanitize_text_field( wp_unslash( $_POST['ref'] ) ) : '' ), array( 'Reply-To: ' . $name . ' <' . $mail . '>' ) ); // phpcs:ignore
	if ( class_exists( 'MRSH_Mem_Mail' ) ) {
		MRSH_Mem_Mail::send( $mail, 'contact', array( 'name' => $name ) );
	}
	wp_safe_redirect( add_query_arg( 'sent', 1, $back ) );
	exit;
}

/** Newsletter sign-up from the footer: stored in option mrt_news and emailed to the admin. */
function mrt_news_send() {
	$back = wp_get_referer() ? wp_get_referer() : home_url( '/' );
	$back = remove_query_arg( 'news', $back );
	$em   = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : ''; // phpcs:ignore
	$nok = ! is_user_logged_in() || ( isset( $_POST['_wpnonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'mrt_news' ) ); // guests: pages are cached, so a stale nonce must not block them
	if ( ! $nok || ! empty( $_POST['website'] ) || ! is_email( $em ) ) { // phpcs:ignore
		wp_safe_redirect( add_query_arg( 'news', 'bad', $back ) . '#newsl' );
		exit;
	}
	$list = (array) get_option( 'mrt_news', array() );
	if ( ! isset( $list[ $em ] ) && count( $list ) < 5000 ) {
		$list[ $em ] = time();
		update_option( 'mrt_news', $list, false );
		wp_mail( get_option( 'admin_email' ), 'New newsletter sign-up', $em );
	}
	if ( class_exists( 'MRSH_Mem_Mail' ) ) {
		MRSH_Mem_Mail::send( $em, 'news', array() );
	}
	wp_safe_redirect( add_query_arg( 'news', '1', $back ) . '#newsl' );
	exit;
}
add_action( 'admin_post_nopriv_mrt_news', 'mrt_news_send' );
add_action( 'admin_post_mrt_news', 'mrt_news_send' );

/** Most viewed profiles, from the old theme's hits_array field (daily counts). Cached for an hour. */
function mrt_popular_ids() {
	$c = get_transient( 'mrt_pop' );
	if ( is_array( $c ) ) {
		return $c;
	}
	$ids = get_posts( array( 'post_type' => 'listing_type', 'post_status' => 'publish', 'numberposts' => 1500, 'fields' => 'ids', 'orderby' => 'date', 'order' => 'DESC', 'no_found_rows' => true ) );
	$sc  = array();
	foreach ( $ids as $id ) {
		$d = get_post_meta( $id, 'hits_array', true );
		$n = 0;
		if ( is_array( $d ) ) {
			foreach ( $d as $h ) {
				$n += is_array( $h ) && isset( $h['hits'] ) ? (int) $h['hits'] : ( is_numeric( $h ) ? (int) $h : 0 );
			}
		}
		if ( $n > 0 ) {
			$sc[ $id ] = $n;
		}
	}
	arsort( $sc );
	$out = array_slice( array_keys( $sc ), 0, 300 );
	set_transient( 'mrt_pop', $out, HOUR_IN_SECONDS );
	return $out;
}

/* ---------- member data kept in the database (user meta), not in the browser ---------- */

/** Profile form draft: save, read, clear. Phone-like fields are never stored (the form script leaves them out). */
add_action( 'wp_ajax_mrt_draft', function () {
	check_ajax_referer( 'mrt', 'n' );
	$uid = get_current_user_id();
	$op  = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : '';
	if ( ! $uid ) {
		wp_send_json( array( 'ok' => false ) );
	}
	if ( 'save' === $op ) {
		$raw = json_decode( isset( $_POST['data'] ) ? wp_unslash( $_POST['data'] ) : '', true ); // phpcs:ignore
		$out = array();
		if ( is_array( $raw ) ) {
			foreach ( array_slice( $raw, 0, 60, true ) as $k => $v ) {
				if ( is_scalar( $v ) && ! preg_match( '/phone|mobile|whatsapp|contact|pass/i', (string) $k ) ) {
					$out[ sanitize_key( $k ) ] = mb_substr( sanitize_textarea_field( (string) $v ), 0, 4000 );
				}
			}
		}
		$out ? update_user_meta( $uid, 'mrt_draft', array( 't' => time(), 'd' => $out ) ) : delete_user_meta( $uid, 'mrt_draft' );
		wp_send_json( array( 'ok' => true ) );
	}
	if ( 'clear' === $op ) {
		delete_user_meta( $uid, 'mrt_draft' );
		wp_send_json( array( 'ok' => true ) );
	}
	$d = get_user_meta( $uid, 'mrt_draft', true );
	wp_send_json( array( 'ok' => true, 'data' => ( is_array( $d ) && ! empty( $d['d'] ) ) ? $d['d'] : null ) );
} );

/** Language choice (English or Urdu) follows the member to every device. */
add_action( 'wp_ajax_mrt_lang', function () {
	check_ajax_referer( 'mrt', 'n' );
	$l = isset( $_POST['lang'] ) && 'ur' === $_POST['lang'] ? 'ur' : 'en';
	if ( get_current_user_id() ) {
		update_user_meta( get_current_user_id(), 'mrt_lang', $l );
	}
	wp_send_json( array( 'ok' => true ) );
} );
add_action( 'init', function () {
	if ( is_user_logged_in() && ! headers_sent() ) {
		$l = get_user_meta( get_current_user_id(), 'mrt_lang', true );
		$c = isset( $_COOKIE['mrt_lang'] ) ? sanitize_key( wp_unslash( $_COOKIE['mrt_lang'] ) ) : ''; // phpcs:ignore
		if ( $l && $c !== $l && ! isset( $_GET['lang'] ) ) { // phpcs:ignore
			$_COOKIE['mrt_lang'] = $l;
			setcookie( 'mrt_lang', $l, time() + YEAR_IN_SECONDS, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN, is_ssl(), false );
		}
	}
}, 5 );

/** Recently viewed profiles of a logged-in member (ids), newest first. */
add_action( 'template_redirect', function () {
	if ( is_singular( 'listing_type' ) && is_user_logged_in() ) {
		$uid = get_current_user_id();
		$id  = get_queried_object_id();
		$rv  = array_values( array_filter( array_map( 'intval', (array) get_user_meta( $uid, 'mrt_rv', true ) ) ) );
		if ( ! $rv || (int) $rv[0] !== (int) $id ) {
			array_unshift( $rv, (int) $id );
			update_user_meta( $uid, 'mrt_rv', array_slice( array_values( array_unique( $rv ) ), 0, 8 ) );
		}
	}
} );
function mrt_recent_ids() {
	return is_user_logged_in() ? array_values( array_filter( array_map( 'intval', (array) get_user_meta( get_current_user_id(), 'mrt_rv', true ) ) ) ) : array();
}

/** Visitor address for rate limits. Uses REMOTE_ADDR; only when that is a private/proxy address does it read the forwarded header. */
function mrt_ip() {
	// Security: the forwarded-for headers are set by the visitor, so they are trusted only when the site
	// owner turns on mrt_trust_proxy (for example behind Cloudflare or a load balancer that sets them).
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	if ( apply_filters( 'mrt_trust_proxy', false ) ) {
		foreach ( array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR' ) as $k ) {
			if ( ! empty( $_SERVER[ $k ] ) ) {
				$parts = explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $k ] ) ) );
				$c     = trim( $parts[0] );
				if ( filter_var( $c, FILTER_VALIDATE_IP ) ) {
					return $c;
				}
			}
		}
	}
	return $ip ? $ip : 'x';
}

/** The theme prints one H1 per page, so any H1 inside page text becomes an H2 (one H1 per page is better for search engines). */
add_filter( 'the_content', function ( $c ) {
	if ( ! is_admin() && ( is_page() || is_singular( 'post' ) ) && ! is_front_page() && in_the_loop() ) {
		$c = preg_replace( '~<(/?)h1(\b[^>]*)?>~i', '<$1h2$2>', (string) $c );
	}
	return $c;
}, 20 );

/** The Urdu switch changes only the display; the ?lang= address repeats the same page, so it is kept out of search results. */
add_filter( 'wp_robots', function ( $r ) {
	if ( isset( $_GET['lang'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$r['noindex'] = true;
		$r['follow']  = true;
		unset( $r['index'] );
	}
	return $r;
}, 100 );

/**
 * Pages that were empty on the old theme because its templates filled them (top listings, categories, country list,
 * callback, chatroom). With this theme they show real content so the same web addresses keep working. No redirects.
 * Returns true when it printed the whole page.
 */
function mrt_special_page( $slug, $title ) {
	$grid = function ( $ids ) {
		echo '<div class="grid">';
		foreach ( $ids as $i ) {
			$p = get_post( $i );
			if ( $p && 'publish' === $p->post_status ) {
				$GLOBALS['post'] = $p; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
				setup_postdata( $p );
				mrt_card();
			}
		}
		wp_reset_postdata();
		echo '</div>';
	};
	$terms = function ( $tax ) {
		if ( ! taxonomy_exists( $tax ) ) {
			return;
		}
		$t = get_terms( array( 'taxonomy' => $tax, 'hide_empty' => true, 'number' => 80, 'orderby' => 'count', 'order' => 'DESC' ) );
		if ( is_wp_error( $t ) || ! $t ) {
			return;
		}
		$o = get_taxonomy( $tax );
		echo '<h2 class="sec">' . esc_html( $o->labels->name ) . '</h2><div class="row" style="flex-wrap:wrap;gap:8px">';
		foreach ( $t as $x ) {
			$l = get_term_link( $x );
			if ( ! is_wp_error( $l ) ) {
				echo '<a class="chip" href="' . esc_url( $l ) . '">' . esc_html( $x->name ) . ' <small>' . (int) $x->count . '</small></a>';
			}
		}
		echo '</div>';
	};
	$known = array( 'top-listings', 'categories', 'country-list', 'callback', 'chatroom' );
	if ( ! in_array( $slug, $known, true ) ) {
		return false;
	}
	mrt_page_hero( $title, '', 'star', 'Browse' );
	echo '<main class="pg"><div class="wrap">';
	if ( 'top-listings' === $slug ) {
		$grid( array_slice( mrt_popular_ids(), 0, 24 ) );
	} elseif ( 'categories' === $slug ) {
		foreach ( array( 'religion', 'sect', 'caste', 'education', 'occupation', 'maritalstatus', 'nationality', 'country' ) as $tx ) {
			$terms( $tx );
		}
	} elseif ( 'country-list' === $slug ) {
		$terms( 'country' );
		$terms( 'nationality' );
	} elseif ( 'callback' === $slug ) {
		$sent = isset( $_GET['sent'] ) ? sanitize_key( $_GET['sent'] ) : ''; // phpcs:ignore
		echo '<div class="wrap narrow"><div class="card2" style="padding:18px">';
		if ( $sent ) {
			echo '<p class="note2">' . ( '1' === $sent ? 'Thank you. We will call you back.' : 'Please check your details and try again.' ) . '</p>';
		}
		echo '<p>Leave your details and the best time. We will call you back.</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrt_contact"><input type="hidden" name="topic" value="Call back request"><input type="hidden" name="t" value="' . (int) time() . '">';
		if ( is_user_logged_in() ) {
			wp_nonce_field( 'mrt_contact' );
		}
		echo '<div style="position:absolute;left:-9999px" aria-hidden="true"><input name="website" tabindex="-1" autocomplete="off"></div><label>Your name</label><input name="name" required autocomplete="name"><label>Email</label><input type="email" name="email" required autocomplete="email"><label>Phone number</label><input name="ref" required autocomplete="tel"><label>Best time and what you need</label><textarea name="msg" rows="4" minlength="10" required placeholder="For example: evenings after 6, help with my profile"></textarea><p><button class="btn">Request call back</button></p></form></div></div>';
	} else {
		echo '<div class="wrap narrow"><div class="card2" style="padding:18px"><h2>Chat with members</h2>';
		if ( is_user_logged_in() ) {
			$n = class_exists( 'MRSH_Members' ) ? (int) MRSH_Members::unread_count( get_current_user_id() ) : 0;
			echo '<p>' . ( $n ? 'You have <b>' . (int) $n . '</b> unread message(s).' : 'Your conversations are in your account.' ) . '</p><p><a class="btn" href="' . esc_url( add_query_arg( 'tab', 'messages', mrt_link( 'myaccount', '/my-account/' ) ) ) . '">Open my messages</a></p>';
		} else {
			echo '<p>Log in to message members. Messaging is free.</p><p><a class="btn" href="' . esc_url( wp_login_url( home_url( '/chatroom/' ) ) ) . '">Log in</a> <a class="btn alt" href="' . esc_url( mrt_link( 'add-listing', '/add-listing/' ) ) . '">Create free profile</a></p>';
		}
		echo '</div></div>';
	}
	echo '</div></main>';
	return true;
}

/** Extra block under an existing page text (latest profiles). */
function mrt_page_extra( $slug ) {
	if ( 'latest-profiles' !== $slug ) {
		return;
	}
	$ids = get_posts( array( 'post_type' => 'listing_type', 'post_status' => 'publish', 'numberposts' => 24, 'fields' => 'ids', 'orderby' => 'date', 'order' => 'DESC' ) );
	if ( $ids ) {
		echo '<div class="wrap"><h2 class="sec">Newest profiles</h2><div class="grid">';
		foreach ( $ids as $i ) {
			$GLOBALS['post'] = get_post( $i ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride
			setup_postdata( $GLOBALS['post'] );
			mrt_card();
		}
		wp_reset_postdata();
		echo '</div></div>';
	}
}


/**
 * Pop-ups wait for the visitor (3.101.303): sign-in card, install sheet and message notice never open while the page is loading.
 * Each one asks window.mrtLate(); it runs only after the visitor has scrolled and stopped, the page has fully loaded, and at most
 * one pop-up every 20 seconds. A page that is never scrolled gets its pop-up after 25 seconds.
 */
/**
 * Slow-network mode (3.101.303): on a weak connection (2G / 3G, very slow download, Data Saver) the page drops animations, shadows
 * and pop-ups and checks for new messages less often. A visitor can switch it on or off from the footer (remembered on the phone).
 */
add_action( 'wp_head', function () {
	echo '<script id="mrt-net">(function(){try{var h=document.documentElement,c=navigator.connection||navigator.mozConnection||{},m=null;try{m=localStorage.getItem("mrt_lite")}catch(e){}function slow(){if(m==="on")return true;if(m==="off")return false;var t=c.effectiveType||"";return !!(c.saveData||/(^|-)2g$|3g/.test(t)||(c.downlink&&c.downlink<1.2)||(c.rtt&&c.rtt>900))}function ap(){var s=slow();h.classList.toggle("slownet",s);window.MRT_SLOW=s}ap();if(c.addEventListener)c.addEventListener("change",ap);window.mrtNet=function(v){try{if(v)localStorage.setItem("mrt_lite",v);else localStorage.removeItem("mrt_lite")}catch(e){}m=v||null;ap()}}catch(e){}})();</script>' . "\n";
}, 0 );

add_action( 'wp_head', function () {
	echo '<script id="mrt-late">(function(){var q=[],eng=0,last=0,tm,busy=0;function run(){if(!q.length||!eng||busy||document.readyState!=="complete")return;var n=Date.now();if(n-last<20000){setTimeout(run,20000-(n-last)+60);return}busy=1;last=n;var f=q.shift();try{f()}catch(e){}busy=0;if(q.length)setTimeout(run,20100)}window.addEventListener("scroll",function(){clearTimeout(tm);if((window.pageYOffset||0)>180){eng=1;tm=setTimeout(run,1200)}},{passive:true});window.addEventListener("load",function(){setTimeout(run,0)});setTimeout(function(){eng=1;run()},25000);window.mrtLate=function(k,f){if(window.MRT_SLOW)return;q.push(f);run()}})();</script>' . "\n";
}, 1 );
