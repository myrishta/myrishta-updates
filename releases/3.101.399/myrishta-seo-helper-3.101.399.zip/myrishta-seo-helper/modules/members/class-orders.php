<?php
/**
 * Package orders. Every package request becomes an order (open). When the member gets the package (robot, ticket or
 * by hand) the order closes by itself. Nothing can be missed: an order stays open until the plan is really on the
 * account. Prices are stored on the order, so paid packages work later without changes.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Orders {

	const CPT = 'mrsh_order';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ), 5 );
		add_action( 'added_user_meta', array( __CLASS__, 'on_meta' ), 10, 4 );
		add_action( 'updated_user_meta', array( __CLASS__, 'on_meta' ), 10, 4 );
		add_action( 'mrsh_tk_poll', array( __CLASS__, 'sweep' ), 55 );
		add_action( 'admin_post_mrsh_ord', array( __CLASS__, 'act' ) );
		add_action( 'admin_post_mrsh_ord_print', array( __CLASS__, 'print_report' ) );
	}

	/** Order number shown to the team, for example PO-000123. */
	public static function number( $id ) {
		return 'PO-' . str_pad( (string) (int) $id, 6, '0', STR_PAD_LEFT );
	}

	public static function register() {
		register_post_type( self::CPT, array( 'label' => 'Package orders', 'public' => false, 'show_ui' => false, 'show_in_rest' => false, 'supports' => array( 'title' ), 'rewrite' => false, 'query_var' => false ) );
	}

	private static function plan_row( $name ) {
		if ( ! function_exists( 'mrt_plans' ) ) {
			return null;
		}
		foreach ( mrt_plans() as $i => $p ) {
			if ( 0 === strcasecmp( trim( $p[0] ), trim( (string) $name ) ) ) {
				return array( $i, $p );
			}
		}
		return null;
	}

	/** The open order of this member for this plan, or 0. */
	public static function find_open( $uid, $plan ) {
		$q = get_posts( array( 'post_type' => self::CPT, 'post_status' => 'publish', 'numberposts' => 1, 'fields' => 'ids', 'no_found_rows' => true, 'meta_query' => array( 'relation' => 'AND', array( 'key' => '_uid', 'value' => (int) $uid ), array( 'key' => '_plan', 'value' => $plan ), array( 'key' => '_state', 'value' => 'open' ) ) ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		return $q ? (int) $q[0] : 0;
	}

	/** Make an order for a package request (once per open request). */
	public static function open( $uid, $plan, $src = 'request' ) {
		$uid  = (int) $uid;
		$plan = trim( (string) $plan );
		$row  = self::plan_row( $plan );
		if ( ! $uid || '' === $plan || ! $row || 0 === (int) $row[0] || ! post_type_exists( self::CPT ) ) {
			return 0; // Free is what everybody already has
		}
		$u = get_userdata( $uid );
		if ( ! $u || 0 === strcasecmp( (string) get_user_meta( $uid, 'mrt_plan', true ), $row[1][0] ) ) {
			return 0;
		}
		$ex = self::find_open( $uid, $row[1][0] );
		if ( $ex ) {
			return $ex;
		}
		$price = (string) $row[1][1];
		$free  = (bool) get_option( 'mrsh_plans_free', 0 ) || (bool) preg_match( '/^(free|0|rs\.?\s*0)\b/i', trim( $price ) );
		$amt   = $free ? 0 : (int) preg_replace( '/\D/', '', $price );
		$id    = wp_insert_post( array( 'post_type' => self::CPT, 'post_status' => 'publish', 'post_title' => $row[1][0] . ' package for ' . ( $u->display_name ?: $u->user_login ) ) );
		if ( ! $id || is_wp_error( $id ) ) {
			return 0;
		}
		update_post_meta( $id, '_uid', $uid );
		update_post_meta( $id, '_plan', $row[1][0] );
		update_post_meta( $id, '_price', $price );
		update_post_meta( $id, '_amount', $amt );
		update_post_meta( $id, '_free', $free ? 1 : 0 );
		update_post_meta( $id, '_paid', $free ? 1 : 0 ); // a free order needs no payment
		update_post_meta( $id, '_src', sanitize_key( $src ) );
		update_post_meta( $id, '_state', 'open' );
		delete_transient( 'mrsh_cnt' );
		return (int) $id;
	}

	public static function close( $id, $state, $note = '' ) {
		update_post_meta( $id, '_state', $state );
		update_post_meta( $id, '_closed', time() );
		if ( ! get_post_meta( $id, '_by', true ) ) {
			// Who closed it: the team member who is logged in, otherwise the package robot / safety net.
			$me = get_current_user_id();
			update_post_meta( $id, '_by', ( $me && current_user_can( 'manage_options' ) && $me !== (int) get_post_meta( $id, '_uid', true ) ) ? 'u:' . $me : 'auto' );
		}
		if ( $note ) {
			update_post_meta( $id, '_note', sanitize_text_field( $note ) );
		}
		delete_transient( 'mrsh_cnt' );
	}

	/** A request creates an order; the plan landing on the account closes it. */
	public static function on_meta( $mid, $uid, $key, $val ) {
		if ( 'mrt_plan_req' === $key && '' !== trim( (string) $val ) ) {
			self::open( $uid, (string) $val, 'request' );
		} elseif ( 'mrt_plan' === $key && '' !== trim( (string) $val ) ) {
			$id = self::find_open( $uid, (string) $val );
			if ( $id ) {
				self::close( $id, 'done', 'Package is on the account.' );
				if ( class_exists( 'MRSH_Attn' ) ) {
					MRSH_Attn::close( 'planreq', (int) $uid );
				}
			}
		}
	}

	/** Safety net, every few minutes: close what is done, and put a free request back in front of the robot when its mark has gone. */
	public static function sweep() {
		if ( get_transient( 'mrsh_ord_run' ) ) {
			return;
		}
		set_transient( 'mrsh_ord_run', 1, 10 * MINUTE_IN_SECONDS );
		$os = get_posts( array( 'post_type' => self::CPT, 'post_status' => 'publish', 'numberposts' => 40, 'orderby' => 'ID', 'order' => 'ASC', 'meta_key' => '_state', 'meta_value' => 'open' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		foreach ( $os as $o ) {
			$uid  = (int) get_post_meta( $o->ID, '_uid', true );
			$plan = (string) get_post_meta( $o->ID, '_plan', true );
			if ( ! get_userdata( $uid ) ) {
				self::close( $o->ID, 'cancelled', 'Member no longer exists.' );
				continue;
			}
			if ( 0 === strcasecmp( (string) get_user_meta( $uid, 'mrt_plan', true ), $plan ) ) {
				self::close( $o->ID, 'done', 'Package is on the account.' );
				continue;
			}
			if ( get_post_meta( $o->ID, '_free', true ) && '' === trim( (string) get_user_meta( $uid, 'mrt_plan_req', true ) ) && ( time() - strtotime( $o->post_date_gmt . ' UTC' ) ) > 15 * MINUTE_IN_SECONDS ) {
				update_user_meta( $uid, 'mrt_plan_req', $plan ); // the package robot looks at it again (it gives the package or tells the member what is missing)
			}
		}
	}

	/** Declined from the member manager: close that member's open orders as declined. */
	public static function reject_user( $uid ) {
		$q = get_posts( array( 'post_type' => self::CPT, 'post_status' => 'publish', 'numberposts' => 20, 'fields' => 'ids', 'meta_query' => array( array( 'key' => '_uid', 'value' => (int) $uid ), array( 'key' => '_state', 'value' => 'open' ) ) ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		foreach ( $q as $id ) {
			self::close( $id, 'rejected', 'Declined by the team.' );
		}
	}

	public static function open_count() {
		$q = new WP_Query( array( 'post_type' => self::CPT, 'post_status' => 'publish', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_state', 'meta_value' => 'open', 'no_found_rows' => false ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		return (int) $q->found_posts;
	}

	/** A clean A4 page of the orders (open, closed or all) with order numbers, to print or save as PDF. */
	public static function print_report() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_ord_print' );
		$st   = isset( $_GET['st'] ) ? sanitize_key( $_GET['st'] ) : 'all';
		$st   = in_array( $st, array( 'open', 'closed', 'all' ), true ) ? $st : 'all';
		$args = array( 'post_type' => self::CPT, 'post_status' => 'publish', 'posts_per_page' => 500, 'orderby' => 'ID', 'order' => 'DESC' );
		if ( 'open' === $st ) {
			$args['meta_query'] = array( array( 'key' => '_state', 'value' => 'open' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		} elseif ( 'closed' === $st ) {
			$args['meta_query'] = array( array( 'key' => '_state', 'value' => 'open', 'compare' => '!=' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		}
		$ids = isset( $_GET['ids'] ) ? array_values( array_filter( array_map( 'absint', explode( ',', (string) wp_unslash( $_GET['ids'] ) ) ) ) ) : array(); // phpcs:ignore WordPress.Security.NonceVerification
		if ( $ids ) {
			$args = array( 'post_type' => self::CPT, 'post_status' => 'publish', 'posts_per_page' => 200, 'orderby' => 'ID', 'order' => 'DESC', 'post__in' => array_slice( $ids, 0, 200 ) );
			$st   = 'all';
		}
		$os   = get_posts( $args );
		$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$lbl  = array( 'open' => 'Open orders', 'closed' => 'Closed orders', 'all' => $ids ? 'Selected orders' : 'All orders' );
		$rows = '';
		$n_done = 0;
		foreach ( $os as $o ) {
			$uid  = (int) get_post_meta( $o->ID, '_uid', true );
			$u    = get_userdata( $uid );
			$stt  = (string) get_post_meta( $o->ID, '_state', true );
			$by   = (string) get_post_meta( $o->ID, '_by', true );
			if ( 0 === strpos( $by, 'u:' ) ) {
				$bu = get_userdata( (int) substr( $by, 2 ) );
				$by = $bu ? ( $bu->display_name ?: $bu->user_login ) : 'Team member';
			} elseif ( 'auto' === $by ) {
				$by = 'Robot';
			} else {
				$by = 'open' === $stt ? '' : 'Not recorded';
			}
			$n_done += 'done' === $stt ? 1 : 0;
			$cl   = (int) get_post_meta( $o->ID, '_closed', true );
			$paid = get_post_meta( $o->ID, '_free', true ) ? 'Free' : ( get_post_meta( $o->ID, '_paid', true ) ? 'Paid' : 'Not paid' );
			$pct  = ( $u && class_exists( 'MRSH_Concierge' ) ) ? (int) MRSH_Concierge::profile_pct( $uid )[0] : 0;
			$exp  = $u ? (int) get_user_meta( $uid, 'mrt_plan_exp', true ) : 0;
			$src  = (string) get_post_meta( $o->ID, '_src', true );
			$note = (string) get_post_meta( $o->ID, '_note', true );
			$amt  = (string) get_post_meta( $o->ID, '_amount', true );
			$contact = $u ? esc_html( $u->user_email ) . '<br>' . esc_html( $u->user_login ) : '';
			$rows .= '<tr><td><b>' . esc_html( self::number( $o->ID ) ) . '</b></td><td>' . esc_html( mysql2date( 'j M Y', $o->post_date ) ) . '<br><small>' . esc_html( mysql2date( 'g:i a', $o->post_date ) ) . '</small></td><td><b>' . esc_html( $u ? ( $u->display_name ?: $u->user_login ) : 'Deleted member' ) . '</b> <small>#' . (int) $uid . '</small><br><small>' . $contact . '</small></td><td>' . esc_html( (string) get_post_meta( $o->ID, '_plan', true ) ) . '<br><small>Source: ' . esc_html( $src ?: '-' ) . '</small></td><td>' . esc_html( (string) get_post_meta( $o->ID, '_price', true ) ) . ( '' !== $amt && $amt !== (string) get_post_meta( $o->ID, '_price', true ) ? '<br><small>Amount: ' . esc_html( $amt ) . '</small>' : '' ) . '<br><small>' . esc_html( $paid ) . '</small></td><td>' . (int) $pct . '%</td><td><b>' . esc_html( 'open' === $stt ? 'Open' : ( 'done' === $stt ? 'Given' : ucfirst( $stt ) ) ) . '</b>' . ( $cl ? '<br><small>' . esc_html( wp_date( 'j M Y, g:i a', $cl ) ) . '</small>' : '' ) . ( 'done' === $stt && $exp ? '<br><small>Package until ' . esc_html( wp_date( 'j M Y', $exp ) ) . '</small>' : '' ) . '</td><td>' . esc_html( $by ) . ( '' !== $note ? '<br><small>' . esc_html( $note ) . '</small>' : '' ) . '</td></tr>';
		}
		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Package orders ' . esc_html( wp_date( 'Y-m-d' ) ) . '</title><style id="pgsz">@page{size:A4 landscape;margin:8mm}</style><style>*{box-sizing:border-box}body{margin:0;background:#eef0f6;font:11px/1.35 system-ui,Arial,sans-serif;color:#1f2937}.bar{background:#4f46e5;color:#fff;padding:10px 16px;text-align:center}.bar button{margin-left:8px;padding:7px 16px;border:0;border-radius:8px;background:#fff;color:#4f46e5;font-weight:700;cursor:pointer}.bar button.on{background:#c7d2fe}.pg{width:980px;margin:12px auto;background:#fff;padding:14px 16px;box-shadow:0 4px 18px rgba(0,0,0,.12);}h1{margin:0;font-size:17px}.hd{display:flex;justify-content:space-between;align-items:flex-end;border-bottom:2px solid #4f46e5;padding-bottom:6px;margin-bottom:8px;gap:12px}.hd small{color:#6b7280}table{width:100%;border-collapse:collapse;table-layout:fixed}th{background:#f3f4f9;text-align:left;font-size:9px;text-transform:uppercase;letter-spacing:.03em;color:#4b5563}th,td{padding:4px 6px;border-bottom:1px solid #e5e7eb;vertical-align:top;overflow-wrap:anywhere}tr{break-inside:avoid}small{color:#6b7280;font-size:9.5px}.ft{margin-top:8px;color:#6b7280;font-size:9.5px}@media print{body{background:#fff}.bar{display:none}.pg{box-shadow:none;margin:0;padding:0}}</style></head><body><div class="bar">Package orders report &middot; paper: <button id="bA" class="on" onclick="setP(\'A4\')">A4</button><button id="bL" onclick="setP(\'Letter\')">Letter</button> <button onclick="window.print()">Print / Save as PDF</button> <small style="color:#e0e7ff;margin-left:8px">The report is shrunk to fit one page when it can.</small></div><div class="pg" id="pg"><div class="hd"><div><h1>' . esc_html( $site ) . ' - Package orders</h1><small>' . esc_html( $lbl[ $st ] ) . ' &middot; ' . count( $os ) . ' orders &middot; ' . (int) $n_done . ' packages given</small></div><small>Printed ' . esc_html( wp_date( 'j M Y, g:i a' ) ) . '</small></div>';
		if ( ! $os ) {
			echo '<p>No orders to show.</p>';
		} else {
			echo '<table><colgroup><col style="width:8%"><col style="width:9%"><col style="width:23%"><col style="width:11%"><col style="width:9%"><col style="width:7%"><col style="width:15%"><col style="width:18%"></colgroup><thead><tr><th>Order no.</th><th>Requested</th><th>Member and contact</th><th>Package</th><th>Price</th><th>Profile</th><th>Status</th><th>Given by and note</th></tr></thead><tbody>' . $rows . '</tbody></table>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '<div class="ft">Order numbers are permanent. Packages given before the "Given by" record started show "Not recorded".</div></div><script>var P={A4:{css:"@page{size:A4 landscape;margin:8mm}",h:690},Letter:{css:"@page{size:Letter landscape;margin:8mm}",h:690}},cur="A4";function fit(){var e=document.getElementById("pg");e.style.zoom="";var h=e.offsetHeight,z=Math.min(1,P[cur].h/h);if(z<1){e.style.zoom=Math.max(z,.45)}}function setP(k){cur=k;document.getElementById("pgsz").textContent=P[k].css;document.getElementById("bA").className=k=="A4"?"on":"";document.getElementById("bL").className=k=="Letter"?"on":"";fit()}window.addEventListener("beforeprint",fit);window.addEventListener("load",fit);</script></body></html>';
		exit;
	}

	public static function act() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		$id = isset( $_REQUEST['oid'] ) ? absint( $_REQUEST['oid'] ) : 0;
		check_admin_referer( 'mrsh_ord' . $id );
		$a   = isset( $_REQUEST['do'] ) ? sanitize_key( $_REQUEST['do'] ) : '';
		$msg = 'Done.';
		if ( $id && self::CPT === get_post_type( $id ) ) {
			$uid  = (int) get_post_meta( $id, '_uid', true );
			$plan = (string) get_post_meta( $id, '_plan', true );
			if ( 'approve' === $a ) {
				$days = isset( $_REQUEST['days'] ) && '' !== $_REQUEST['days'] ? max( 0, min( 3650, absint( $_REQUEST['days'] ) ) ) : ( get_post_meta( $id, '_free', true ) ? 180 : 30 );
				if ( $days ) { update_user_meta( $uid, 'mrt_plan_exp', time() + $days * DAY_IN_SECONDS ); } else { delete_user_meta( $uid, 'mrt_plan_exp' ); }
				update_user_meta( $uid, 'mrt_plan', $plan ); // closes the order through the hook
				update_post_meta( $id, '_paid', 1 );
				delete_user_meta( $uid, 'mrt_plan_req' );
				delete_user_meta( $uid, 'mrsh_pr_held' );
				$u = get_userdata( $uid );
				if ( $u && is_email( $u->user_email ) ) {
					wp_mail( $u->user_email, 'Your ' . $plan . ' package is ready - My Rishta Pakistan', 'Hello ' . ( $u->display_name ?: $u->user_login ) . ",\n\nYour account now has the " . $plan . " package. You can see it in My account.\n\nآپ کے اکاؤنٹ میں اب " . $plan . " پیکج لگ گیا ہے۔ آپ اسے My account میں دیکھ سکتے ہیں۔\n\n--\nMy Rishta Pakistan Support" );
				}
				$msg = $plan . ' package given.';
			} elseif ( 'reject' === $a ) {
				self::close( $id, 'rejected', 'Declined by the team.' );
				delete_user_meta( $uid, 'mrt_plan_req' );
				if ( class_exists( 'MRSH_Attn' ) ) {
					MRSH_Attn::close( 'planreq', $uid );
				}
				$msg = 'Order declined.';
			} elseif ( 'paid' === $a ) {
				update_post_meta( $id, '_paid', 1 );
				$msg = 'Marked as paid.';
			}
		}
		wp_safe_redirect( add_query_arg( array( 'page' => 'mrsh-orders', 'msg' => rawurlencode( $msg ) ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$st = isset( $_GET['st'] ) && 'closed' === $_GET['st'] ? 'closed' : 'open'; // phpcs:ignore WordPress.Security.NonceVerification
		MRSH_Boost::ui_open( 'Package orders', 'Every package request is an order. It closes by itself when the member gets the package, so no upgrade is missed. If packages get a price later, the same orders carry the payment.', 'g-blue', 'M7 4h10l3 4v12H4V8zm0 0h10M9 12h6M9 16h4' );
		if ( isset( $_GET['msg'] ) ) { // phpcs:ignore
			MRSH_Boost::ui_ok( sanitize_text_field( wp_unslash( $_GET['msg'] ) ) ); // phpcs:ignore
		}
		$open = self::open_count();
		$cl   = new WP_Query( array( 'post_type' => self::CPT, 'post_status' => 'publish', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_state', 'meta_value' => 'done' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		echo '<div class="mx-stats">' . MRSH_Boost::ui_stat( $open, 'Open orders', $open ? '#dc2626' : '#16a34a' ) . MRSH_Boost::ui_stat( (int) $cl->found_posts, 'Packages given', '#7c3aed' ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		$base = admin_url( 'admin.php?page=mrsh-orders' );
		echo '<p><a class="button' . ( 'open' === $st ? ' button-primary' : '' ) . '" href="' . esc_url( $base ) . '">Open (' . (int) $open . ')</a> <a class="button' . ( 'closed' === $st ? ' button-primary' : '' ) . '" href="' . esc_url( add_query_arg( 'st', 'closed', $base ) ) . '">Closed</a> ';
		foreach ( array( 'open' => 'Print open orders', 'closed' => 'Print closed orders', 'all' => 'Print all orders' ) as $pk => $pl ) {
			echo '<a class="button" target="_blank" href="' . esc_url( wp_nonce_url( add_query_arg( array( 'action' => 'mrsh_ord_print', 'st' => $pk ), admin_url( 'admin-post.php' ) ), 'mrsh_ord_print' ) ) . '">' . esc_html( $pl ) . '</a> ';
		}
		$pb = wp_nonce_url( add_query_arg( array( 'action' => 'mrsh_ord_print' ), admin_url( 'admin-post.php' ) ), 'mrsh_ord_print' );
		echo '<button type="button" class="button button-primary" id="mrsh-ps" data-base="' . esc_url( $pb ) . '">Print selected (0)</button></p>';
		$args = array( 'post_type' => self::CPT, 'post_status' => 'publish', 'posts_per_page' => 60, 'orderby' => 'ID', 'order' => 'open' === $st ? 'ASC' : 'DESC' );
		if ( 'open' === $st ) {
			$args['meta_key']   = '_state'; // phpcs:ignore WordPress.DB.SlowDBQuery
			$args['meta_value'] = 'open'; // phpcs:ignore WordPress.DB.SlowDBQuery
		} else {
			$args['meta_query'] = array( array( 'key' => '_state', 'value' => 'open', 'compare' => '!=' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		}
		$os = get_posts( $args );
		echo '<div class="mx-card">';
		if ( ! $os ) {
			echo '<p style="margin:0;color:#6b7280">' . ( 'open' === $st ? 'No open orders. Every package request has been dealt with.' : 'No closed orders yet.' ) . '</p></div>';
			echo '</div>';
			return;
		}
		echo '<table class="widefat striped"><thead><tr><th style="width:28px"><input type="checkbox" id="mrsh-pall" title="Select all"></th><th>Order no.</th><th>Date</th><th>Member</th><th>Package</th><th>Price</th><th>Profile</th><th>Status</th><th></th></tr></thead><tbody>';
		foreach ( $os as $o ) {
			$uid  = (int) get_post_meta( $o->ID, '_uid', true );
			$u    = get_userdata( $uid );
			$plan = (string) get_post_meta( $o->ID, '_plan', true );
			$stt  = (string) get_post_meta( $o->ID, '_state', true );
			$pct  = ( $u && class_exists( 'MRSH_Concierge' ) ) ? (int) MRSH_Concierge::profile_pct( $uid )[0] : 0;
			$name = $u ? ( $u->display_name ?: $u->user_login ) : 'Deleted member';
			echo '<tr><td><input type="checkbox" class="mrsh-pc" value="' . (int) $o->ID . '"></td><td><b>' . esc_html( self::number( $o->ID ) ) . '</b><br><a target="_blank" href="' . esc_url( add_query_arg( 'ids', (int) $o->ID, $pb ) ) . '">Print this order</a></td><td>' . esc_html( mysql2date( 'j M, g:i a', $o->post_date ) ) . '</td><td><b>' . esc_html( $name ) . '</b> <span class="description">#' . (int) $uid . '</span>' . ( $u ? '<br><a href="' . esc_url( add_query_arg( array( 'page' => 'mrsh-desk', 'q' => $u->user_email ), admin_url( 'admin.php' ) ) ) . '">Member manager</a>' : '' ) . '</td><td>' . esc_html( $plan ) . '</td><td>' . esc_html( (string) get_post_meta( $o->ID, '_price', true ) ) . ( get_post_meta( $o->ID, '_free', true ) ? '' : ( get_post_meta( $o->ID, '_paid', true ) ? ' <span style="color:#16a34a">paid</span>' : ' <span style="color:#dc2626">not paid</span>' ) ) . '</td><td>' . (int) $pct . '%</td><td>';
			echo esc_html( 'open' === $stt ? 'Open' : ( 'done' === $stt ? 'Given' : ucfirst( $stt ) ) ) . ( get_post_meta( $o->ID, '_closed', true ) ? '<br><span class="description">' . esc_html( wp_date( 'j M, g:i a', (int) get_post_meta( $o->ID, '_closed', true ) ) ) . '</span>' : '' );
			if ( 'open' !== $stt ) {
				$by = (string) get_post_meta( $o->ID, '_by', true );
				if ( 0 === strpos( $by, 'u:' ) ) {
					$bu    = get_userdata( (int) substr( $by, 2 ) );
					$bytxt = 'By ' . ( $bu ? ( $bu->display_name ?: $bu->user_login ) : 'a team member (deleted)' );
				} elseif ( 'auto' === $by ) {
					$bytxt = 'By the package robot (automatic)';
				} else {
					$bytxt = 'Who gave it was not recorded';
				}
				echo '<br><b style="font-size:12px;color:#4f46e5">' . esc_html( $bytxt ) . '</b>';
				$nt = (string) get_post_meta( $o->ID, '_note', true );
				if ( '' !== $nt ) {
					echo '<br><span class="description">' . esc_html( $nt ) . '</span>';
				}
			}
			echo '</td><td>';
			if ( 'open' === $stt ) {
				$n = wp_create_nonce( 'mrsh_ord' . $o->ID );
				foreach ( array( 'approve' => array( 'Give package', 'button-primary' ), 'reject' => array( 'Decline', '' ) ) as $do => $b ) {
					echo '<a class="button ' . esc_attr( $b[1] ) . '" href="' . esc_url( add_query_arg( array( 'action' => 'mrsh_ord', 'do' => $do, 'oid' => $o->ID, '_wpnonce' => $n ), admin_url( 'admin-post.php' ) ) ) . '">' . esc_html( $b[0] ) . '</a> ';
				}
			}
			echo '</td></tr>';
		}
		echo '</tbody></table></div>';
		echo '<script>(function(){var b=document.getElementById("mrsh-ps"),a=document.getElementById("mrsh-pall"),c=[].slice.call(document.querySelectorAll(".mrsh-pc"));function u(){var n=c.filter(function(x){return x.checked}).length;b.textContent="Print selected ("+n+")";b.disabled=!n}function ids(){return c.filter(function(x){return x.checked}).map(function(x){return x.value}).join(",")}if(!b)return;b.addEventListener("click",function(){var i=ids();if(i)window.open(b.getAttribute("data-base")+"&ids="+i,"_blank")});if(a)a.addEventListener("change",function(){c.forEach(function(x){x.checked=a.checked});u()});c.forEach(function(x){x.addEventListener("change",u)});u()})();</script>';
		echo '</div>';
	}
}
MRSH_Orders::init();
