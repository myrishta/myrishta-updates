=== MyRishta SEO Helper ===
Requires at least: 6.2
Requires PHP: 7.4
Stable tag: 3.101.368
License: GPLv2 or later

SEO companion for myrishta.pk, built to work alongside Rank Math.

== Description ==
* Dashboard with live checks, setup checklist and logo.
* Rules: noindex for member profiles, search, parameters, author/date/attachment pages; clean canonicals; robots.txt lines; Organization, WebSite and breadcrumb schema; en-PK hreflang.
* Automatic titles, meta descriptions and image alt text where empty (Rank Math values always win); share image falls back to your logo.
* Search Engines: verification codes for Google, Bing, Yandex, Baidu, Naver, Seznam, Pinterest, Facebook; IndexNow automatic submission; submission requirements checklist.
* Keyword bank of 532 Pakistan phrases (Urdu and Roman Urdu), coverage report, draft page outlines (never published).
* Discover: weekly scan of your own content, visitor site searches, Search Console CSV import.
* Shortcodes: [myrishta_browse], [myrishta_whatsapp].

== Installation ==
1. Plugins > Add New Plugin > Upload Plugin, choose the zip, Install, Activate. Test on a staging copy first.
2. Open MyRishta SEO in the sidebar, then Rules, Search Engines and the Dashboard checks.

== Changelog ==
= 3.0.0 =
* Complete SEO engine for sites without another SEO plugin: canonical, Open Graph, Twitter, Article schema, sitemap rules, per-page SEO fields, HTML sitemap shortcode, import from All in One SEO.
* Hidden-page slugs, 532 phrase keyword bank.
= 2.2.1 =
* Better Rank Math detection; member profile type listing_type.
= 2.2.0 =
* Automatic tags, weekly phrase discovery, advanced SEO options, image alt tools, submission checklist.
= 2.1.0 =
* IndexNow, Discover, draft pages.
= 1.1.0 =
* Keyword bank.
