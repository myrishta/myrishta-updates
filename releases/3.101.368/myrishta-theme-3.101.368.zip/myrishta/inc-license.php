<?php
/**
 * License gate. The plugin and the theme only run on a licensed site.
 * Licensed = the right key was entered (Settings > MyRishta license), or the site is myrishta.pk itself.
 * Only a one-way hash of the key is stored here, never the key.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! class_exists( 'MRSH_License', false ) ) {
	class MRSH_License {
		const HASH   = 'a93fbd2fffbcfdaab2f612e9971839cdadbb014747437c7c90f0e5c02bbaf73a';
		const OPT    = 'mrsh_license';
		const HOSTS  = 'myrishta.pk';
		private static $ok = null;

		public static function norm( $k ) {
			return strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) $k ) );
		}
		public static function key_ok( $k ) {
			$k = self::norm( $k );
			return '' !== $k && hash_equals( self::HASH, hash( 'sha256', 'mrsh-lic|' . $k ) );
		}
		public static function host_ok() {
			$h = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
			$h = preg_replace( '/^www\./', '', $h );
			return self::HOSTS === $h;
		}
		public static function ok() {
			if ( null === self::$ok ) {
				self::$ok = self::host_ok() || self::key_ok( get_option( self::OPT, '' ) );
			}
			return self::$ok;
		}
		public static function init() {
			add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
			add_action( 'admin_post_mrsh_license', array( __CLASS__, 'save' ) );
			if ( ! self::ok() ) {
				add_action( 'admin_notices', array( __CLASS__, 'notice' ) );
			}
		}
		public static function url() {
			return admin_url( 'options-general.php?page=mrsh-license' );
		}
		public static function menu() {
			add_options_page( 'MyRishta license', 'MyRishta license', 'manage_options', 'mrsh-license', array( __CLASS__, 'page' ) );
		}
		public static function notice() {
			if ( current_user_can( 'manage_options' ) ) {
				echo '<div class="notice notice-error"><p><b>My Rishta:</b> this copy is not licensed, so it is switched off. <a href="' . esc_url( self::url() ) . '">Enter the license key</a>.</p></div>';
			}
		}
		public static function save() {
			if ( ! current_user_can( 'manage_options' ) || ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'mrsh_license' ) ) {
				wp_die( 'Not allowed.' );
			}
			$k = isset( $_POST['key'] ) ? self::norm( wp_unslash( $_POST['key'] ) ) : '';
			if ( self::key_ok( $k ) ) {
				update_option( self::OPT, $k, false );
				$r = 'ok';
			} else {
				$r = 'bad';
			}
			wp_safe_redirect( add_query_arg( 'lic', $r, self::url() ) );
			exit;
		}
		public static function page() {
			$ok  = self::ok();
			$msg = isset( $_GET['lic'] ) ? sanitize_key( $_GET['lic'] ) : '';
			echo '<style>.mxl{max-width:640px;margin:24px 0;font-family:system-ui,sans-serif}.mxl .hero{background:linear-gradient(135deg,#0f6b4f,#14916b);color:#fff;border-radius:16px;padding:22px 26px}.mxl .hero h1{color:#fff;margin:0 0 4px;font-size:22px}.mxl .hero p{margin:0;opacity:.9}.mxl .card{background:#fff;border:1px solid #e3e8e5;border-radius:14px;padding:20px 24px;margin-top:16px}.mxl .badge{display:inline-block;border-radius:99px;padding:3px 12px;font-weight:600;font-size:13px}.mxl .b-ok{background:#dff6ea;color:#0b6b43}.mxl .b-no{background:#fde4e4;color:#a12020}.mxl input[type=text]{width:100%;padding:10px 12px;font-size:15px;letter-spacing:.5px}</style>';
			echo '<div class="mxl"><div class="hero"><h1>MyRishta license</h1><p>The plugin and the theme run only with a valid license.</p></div><div class="card">';
			echo '<p>Status: ' . ( $ok ? '<span class="badge b-ok">Licensed</span>' : '<span class="badge b-no">Not licensed - switched off</span>' ) . '</p>';
			if ( 'ok' === $msg ) {
				echo '<p><b>The key was accepted.</b></p>';
			} elseif ( 'bad' === $msg ) {
				echo '<p style="color:#a12020"><b>That key is not valid.</b> Check it and try again.</p>';
			}
			if ( self::host_ok() ) {
				echo '<p>This is the official myrishta.pk site, so it is licensed automatically.</p>';
			} else {
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_license">';
				wp_nonce_field( 'mrsh_license' );
				echo '<p><label for="mrsh-key"><b>License key</b></label></p><p><input id="mrsh-key" type="text" name="key" autocomplete="off" placeholder="Paste the license key"></p><p><button class="button button-primary button-hero">Activate</button></p></form>';
			}
			echo '</div></div>';
		}
	}
	MRSH_License::init();
}
