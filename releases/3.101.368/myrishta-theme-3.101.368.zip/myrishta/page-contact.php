<?php
/* Template Name: Contact */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
mrt_page_hero( 'Contact us', 'Questions, feedback or a problem with a profile? We reply within 48 hours.', 'chat', 'Contact' );
$ci   = mrt_contact_info();
$sent = isset( $_GET['sent'] ) ? sanitize_text_field( wp_unslash( $_GET['sent'] ) ) : ''; // phpcs:ignore
?>
<main class="pg"><div class="wrap"><div class="cgrid">
	<div class="cinfo">
		<?php if ( $ci['phone'] ) : ?><a class="ccard" href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $ci['phone'] ) ); ?>"><span class="ib b1"><?php echo mrt_icon( 'phone' ); // phpcs:ignore ?></span><span><b>Phone</b><small><?php echo esc_html( $ci['phone'] ); ?></small></span></a><?php endif; ?>
		<?php if ( $ci['wa'] ) : ?><a class="ccard" target="_blank" rel="noopener" href="https://wa.me/<?php echo esc_attr( $ci['wa'] ); ?>"><span class="ib b2"><?php echo mrt_icon( 'chat' ); // phpcs:ignore ?></span><span><b>WhatsApp</b><small>Chat with us</small></span></a><?php endif; ?>
		<?php if ( $ci['email'] ) : ?><a class="ccard" href="mailto:<?php echo esc_attr( $ci['email'] ); ?>"><span class="ib b3"><?php echo mrt_icon( 'mail' ); // phpcs:ignore ?></span><span><b>Email</b><small><?php echo esc_html( $ci['email'] ); ?></small></span></a><?php endif; ?>
		<?php if ( $ci['address'] ) : ?><a class="ccard" target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&query=<?php echo rawurlencode( $ci['address'] ); ?>"><span class="ib b4"><?php echo mrt_icon( 'pin' ); // phpcs:ignore ?></span><span><b>Office</b><small><?php echo esc_html( $ci['address'] ); ?></small></span></a><?php endif; ?>
		<div class="note2"><?php echo mrt_icon( 'shield' ); // phpcs:ignore ?><div>To report a fake profile, open it and tap <b>Report</b>. Never send money or ID photos.<span class="bu bl" lang="ur" dir="rtl">جعلی پروفائل رپورٹ کرنے کے لیے اسے کھولیں اور Report دبائیں۔ کبھی رقم یا شناختی کارڈ کی تصویر نہ بھیجیں۔</span></div></div>
	</div>
	<form class="frm cform" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<h2>Send a message</h2>
		<?php
		if ( '1' === $sent ) {
			echo '<div class="okb">Thank you. Your message was sent. We will reply by email.</div>';
		} elseif ( 'bad' === $sent ) {
			echo '<div class="err">Please enter your name, a valid email and a message of at least 10 characters.</div>';
		} elseif ( 'limit' === $sent ) {
			echo '<div class="err">Too many messages from this device. Please try again later.</div>';
		}
		?>
		<input type="hidden" name="action" value="mrt_contact"><input type="hidden" name="t" value="<?php echo (int) time(); ?>">
		<?php wp_nonce_field( 'mrt_contact' ); ?>
		<div style="position:absolute;left:-9999px" aria-hidden="true"><input name="website" tabindex="-1" autocomplete="off"></div>
		<div class="g2"><div><label>Your name</label><input name="name" required autocomplete="name"></div><div><label>Email</label><input type="email" name="email" required autocomplete="email"></div></div>
		<div class="g2"><div><label>Topic</label><select name="topic"><option>Question</option><option>Report a profile</option><option>Problem with my account</option><option>Verification</option><option>Delete my data</option><option>Feedback</option></select></div><div><label>Profile name or ID (optional)</label><input name="ref"></div></div>
		<label>Message</label><textarea name="msg" rows="5" minlength="10" maxlength="2000" required></textarea>
		<button class="btn big"><?php echo mrt_icon( 'mail' ); // phpcs:ignore ?>Send message</button>
	</form>
</div></div></main>
<?php get_footer();
