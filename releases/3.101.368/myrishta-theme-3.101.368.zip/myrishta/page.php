<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
while ( have_posts() ) :
	the_post();
	$words = str_word_count( wp_strip_all_tags( get_the_content() ) );
	$mins  = max( 1, (int) ceil( $words / 200 ) );
	if ( is_front_page() ) {
		echo '<main class="pg"><div class="wrap"><article class="entry card2">';
		the_content();
		echo '</article></div></main>';
		continue;
	}
	if ( '' === trim( wp_strip_all_tags( get_the_content() ) ) && mrt_special_page( get_post_field( 'post_name' ), get_the_title() ) ) {
		continue;
	}
	$k = mrt_guide_kind( get_the_title() );
	mrt_page_hero( get_the_title(), $words > 300 ? $mins . ' min read' : '', $k[1], 'Guides' );
	?>
<main class="pg"><div class="wrap narrow">
	<article class="entry card2"><?php the_content(); ?></article>
	<div class="share"><span>Share this</span>
		<a class="btn line sm" target="_blank" rel="noopener" href="https://wa.me/?text=<?php echo rawurlencode( get_the_title() . ' ' . get_permalink() ); ?>"><?php echo mrt_icon( 'chat' ); // phpcs:ignore ?>WhatsApp</a>
		<button type="button" class="btn line sm" data-share="<?php echo esc_url( get_permalink() ); ?>" data-title="<?php echo esc_attr( get_the_title() ); ?>"><?php echo mrt_icon( 'share' ); // phpcs:ignore ?>Copy link</button>
	</div>
	<?php $cta = mrt_cta(); ?>
	<div class="cta"><div><h2>Find your rishta, free</h2><p>Create a profile in three minutes.</p></div><a class="btn big" href="<?php echo esc_url( $cta[1] ); ?>"><?php echo mrt_icon( $cta[2] ); // phpcs:ignore ?><?php echo esc_html( 'Add profile' === $cta[0] ? 'Create free profile' : 'Update your profile' ); ?></a></div>
</div>
<div class="wrap"><?php mrt_more_guides( get_the_ID() ); ?></div><?php mrt_page_extra( get_post_field( 'post_name' ) ); ?></main>
<?php
endwhile;
get_footer();
