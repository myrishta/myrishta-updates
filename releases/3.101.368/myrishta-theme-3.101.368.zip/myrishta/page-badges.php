<?php
/* Template Name: Badges */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
mrt_page_hero( 'Badges and trust', 'What the badges on a profile mean and how to earn them.', 'shield', 'Badges' );
$cta  = mrt_cta();
$plan = mrt_plans();
$acc  = mrt_link( 'myaccount', '/my-account/' );
?>
<main class="pg"><div class="wrap">
	<div class="bgrid">
		<div class="bcard"><div class="bpv"><span class="pill pv"><?php echo mrt_icon( 'shield' ); // phpcs:ignore ?>Verified by My Rishta</span></div><b>Verified by My Rishta</b><p>Our team checked this member. Look for this badge first.</p><a class="btn sm" href="<?php echo esc_url( $acc ); ?>"><?php echo mrt_icon( 'check' ); // phpcs:ignore ?>Get verified</a></div>
		<div class="bcard"><div class="bpv"><span class="pill ps"><?php echo mrt_icon( 'shield' ); // phpcs:ignore ?>Secure account</span></div><b>Secure account</b><p>The member turned on two-step login, so the account is harder to hijack.</p><a class="btn sm line" href="<?php echo esc_url( $acc ); ?>">Turn on</a></div>
		<?php foreach ( $plan as $pi => $pp ) { if ( 0 === $pi ) { continue; } ?><div class="bcard"><div class="bpv"><span class="pill pp" style="background:<?php echo esc_attr( $pp[3] ? $pp[3] : '#e0791a' ); ?>"><?php echo mrt_icon( 'star' ); // phpcs:ignore ?><?php echo esc_html( $pp[0] ); ?> member</span></div><b><?php echo esc_html( $pp[0] ); ?> badge</b><p><?php echo esc_html( $pp[1] ); ?> &middot; <?php echo esc_html( implode( ', ', array_slice( $pp[2], 0, 2 ) ) ); ?></p><a class="btn sm line" href="<?php echo esc_url( mrt_link( 'memberships', '/memberships/' ) ); ?>">See plans</a></div><?php } ?>
		<div class="bcard"><div class="bpv"><span class="pill"><span class="dot"></span>Online now</span></div><b>Online now</b><p>The member was active in the last few minutes, so replies are likely quick.</p><a class="btn sm line" href="<?php echo esc_url( home_url( '/?post_type=listing_type&s=&online=1' ) ); ?>">See who is online</a></div>
	</div>
	<h2 class="sec">How to get verified</h2>
	<ol class="vsteps">
		<li><b>Complete your profile.</b> Add a clear photo and your details.</li>
		<li><b>Tap Get verified</b> in My account under Trust and membership.</li>
		<li><b>Our team reviews it</b> and adds the badge, usually within a few days.</li>
	</ol>
	<div class="note2"><?php echo mrt_icon( 'shield' ); // phpcs:ignore ?><div>A badge is a help, not a guarantee. Always involve your family, meet in public and never send money. See <a href="<?php echo esc_url( mrt_link( 'contact', '/contact/' ) ); ?>">Contact</a> to report anything wrong.</div></div>
	<?php while ( have_posts() ) : the_post(); if ( trim( wp_strip_all_tags( get_the_content() ) ) ) : ?><article class="entry card2"><?php the_content(); ?></article><?php endif; endwhile; ?>
	<div class="cta"><div><h2>Build trust on your profile</h2><p>Free, and it takes minutes.</p></div><a class="btn big" href="<?php echo esc_url( $cta[1] ); ?>"><?php echo mrt_icon( $cta[2] ); // phpcs:ignore ?><?php echo esc_html( 'Add profile' === $cta[0] ? 'Create free profile' : 'Update your profile' ); ?></a></div>
</div></main>
<?php get_footer();
