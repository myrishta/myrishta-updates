(function(){
var m=document.querySelector("main.acct");if(!m)return;
function en(t){var i=t.indexOf(" — ");return i>0?t.slice(0,i):t}
function enh(sel){
 if(sel.getAttribute("data-ms"))return;sel.setAttribute("data-ms","1");
 var opts=[].slice.call(sel.options).filter(function(o){return o.value!==""});
 var box=document.createElement("div");box.className="ms";
 var f=document.createElement("div");f.className="ms-f";
 var chips=document.createElement("span");chips.className="ms-chips";
 var q=document.createElement("input");q.type="text";q.className="ms-q";q.autocomplete="off";q.setAttribute("aria-label","Search");
 var list=document.createElement("div");list.className="ms-list";list.hidden=true;
 f.appendChild(chips);f.appendChild(q);box.appendChild(f);box.appendChild(list);
 var info=document.createElement("small");info.className="ms-info";box.appendChild(info);
 sel.parentNode.insertBefore(box,sel.nextSibling);sel.style.display="none";
 function sync(){chips.innerHTML="";var n=0;opts.forEach(function(o){if(o.selected){n++;var c=document.createElement("span");c.className="ms-c";c.textContent=en(o.text);c.title=o.text;var x=document.createElement("button");x.type="button";x.setAttribute("aria-label","Remove");x.textContent="×";x.onclick=function(e){e.stopPropagation();o.selected=false;ch();q.focus()};c.appendChild(x);chips.appendChild(c)}});
  q.placeholder=n?"Add more":"Any – type to search";info.textContent=n?n+" selected":"";box.classList.toggle("has",n>0)}
 function ch(){sel.dispatchEvent(new Event("change",{bubbles:true}));sync();render()}
 function render(){var t=q.value.trim().toLowerCase(),out=[],shown=0;list.innerHTML="";
  for(var i=0;i<opts.length&&shown<60;i++){var o=opts[i];if(t&&o.text.toLowerCase().indexOf(t)<0)continue;shown++;
   var d=document.createElement("div");d.className="ms-o"+(o.selected?" on":"");d.setAttribute("data-i",i);d.innerHTML="<i></i><span></span>";d.lastChild.textContent=o.text;list.appendChild(d)}
  if(!shown){list.innerHTML='<div class="ms-no">No match</div>'}else if(shown>=60){var mo=document.createElement("div");mo.className="ms-no";mo.textContent="Keep typing to narrow the list";list.appendChild(mo)}}
 function open(){list.hidden=false;render()}
 function close(){list.hidden=true}
 f.addEventListener("click",function(){q.focus();open()});
 q.addEventListener("focus",open);q.addEventListener("input",function(){open()});
 q.addEventListener("keydown",function(e){
  if(e.key==="Escape"){close();q.blur()}
  else if(e.key==="Enter"){e.preventDefault();var d=list.querySelector(".ms-o");if(d){var o=opts[+d.getAttribute("data-i")];o.selected=!o.selected;q.value="";ch()}}
  else if(e.key==="Backspace"&&!q.value){for(var i=opts.length-1;i>=0;i--){if(opts[i].selected){opts[i].selected=false;ch();break}}}});
 list.addEventListener("mousedown",function(e){e.preventDefault()});
 list.addEventListener("click",function(e){var d=e.target.closest(".ms-o");if(!d)return;var o=opts[+d.getAttribute("data-i")];e.stopPropagation();o.selected=!o.selected;q.value="";ch();q.focus()});
 document.addEventListener("click",function(e){if(!box.contains(e.target))close()});
 sync();
}
[].slice.call(m.querySelectorAll("select[multiple]")).forEach(function(s){try{enh(s)}catch(e){s.style.display=""}});
})();
