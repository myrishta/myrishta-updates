/* My Rishta Urdu mode: English / اردو switch. Small file. The Urdu dictionary (urdu-tr.js) loads only when Urdu is on. */
(function(){
if(window.__mrUrdu)return;window.__mrUrdu=1;
var BASE=window.MRT_UR||'';
var q=location.search.match(/[?&]lang=(\w+)/);
function ck(){var m=document.cookie.match(/(?:^|; )mrt_lang=(\w+)/);return m?m[1]:''}
if(q){document.cookie='mrt_lang='+q[1]+';path=/;max-age=31536000;samesite=lax'}
var dm=false;try{dm=(window.matchMedia&&matchMedia('(display-mode: standalone)').matches)||navigator.standalone===true||/^ur/i.test(navigator.language||'')}catch(e){}
var ur=(q?q[1]:(ck()||(dm?'ur':'')))==='ur';
function sw(){var b=document.createElement('button');b.type='button';b.className='langsw';b.textContent=ur?'English':'اردو';b.setAttribute('aria-label',ur?'Switch to English':'اردو میں دیکھیں');
b.onclick=function(){var nl=ur?'en':'ur';document.cookie='mrt_lang='+nl+';path=/;max-age=31536000;samesite=lax';try{if(window.MRT&&MRT.in){var fd=new FormData();fd.append('action','mrt_lang');fd.append('lang',nl);fd.append('n',MRT.n);navigator.sendBeacon?navigator.sendBeacon(MRT.ajax,fd):fetch(MRT.ajax,{method:'POST',body:fd,credentials:'same-origin'})}}catch(e){}location.href=location.pathname+location.search.replace(/[?&]lang=\w+/,'')+location.hash};
var h=document.querySelector('.hact')||document.querySelector('.site-head .wrap');if(h)h.insertBefore(b,h.firstChild);else document.body.appendChild(b)}
function go(){if(!document.querySelector('.langsw'))sw();if(!ur||!BASE)return;
var s=document.createElement('script');s.src=BASE;
s.onload=function(){if(typeof window.MRTUR!=='function')return;document.documentElement.lang='ur';document.documentElement.dir='rtl';document.documentElement.classList.add('ur');
window.MRTUR();var t;new MutationObserver(function(){clearTimeout(t);t=setTimeout(function(){window.MRTUR()},120)}).observe(document.body,{childList:true,subtree:true})};
document.head.appendChild(s)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',go);else go();
})();
