(function(){
var C=window.MRT||{};
function post(d,cb){var f=new FormData();for(var k in d)f.append(k,d[k]);f.append('n',C.n);
fetch(C.ajax,{method:'POST',credentials:'same-origin',body:f}).then(function(r){return r.json()}).then(cb).catch(function(){cb({ok:false,msg:'Network problem. Try again.'})});}
function toast(m){var t=document.getElementById('mrt-toast');if(!t){t=document.createElement('div');t.id='mrt-toast';t.setAttribute('role','status');document.body.appendChild(t)}
t.textContent=m;t.className='show';clearTimeout(t._t);t._t=setTimeout(function(){t.className=''},3200)}
window.mrtX={C:C,post:post,toast:toast};
document.addEventListener('click',function(e){
var sh=e.target.closest('[data-share]');
if(sh){e.preventDefault();var u=sh.getAttribute('data-share'),t=sh.getAttribute('data-title')||document.title;
if(navigator.share){navigator.share({title:t,url:u}).catch(function(){})}else if(navigator.clipboard){navigator.clipboard.writeText(u).then(function(){toast('Link copied')})}else{prompt('Copy link',u)}return}
var ss=e.target.closest('[data-save]');
if(ss){e.preventDefault();if(!C.in){location.href=C.login;return}post({action:'mrt_x',act:'savesearch',q:location.search},function(r){toast(r.msg)});return}
var b=e.target.closest('[data-act]');if(!b)return;
if(b.getAttribute('data-act')==='delsearch'){e.preventDefault();post({action:'mrt_x',act:'delsearch',i:b.getAttribute('data-i')},function(r){if(r.ok)b.closest('.box').remove();toast(r.msg)});return}
var a=b.getAttribute('data-act'),pid=b.getAttribute('data-pid');
if(a==='gifttray'){var gt=document.getElementById('mrt-gifts');if(gt)gt.hidden=!gt.hidden;return}
if(a==='gift'){post({action:'mrt_act',act:'gift',pid:pid,gift:b.getAttribute('data-gift')},function(r){toast(r.msg);if(r.ok){var g2=document.getElementById('mrt-gifts');if(g2)g2.hidden=true}});return}
if(!C.in){location.href=C.login;e.preventDefault();return}
e.preventDefault();
if(a==='msg'){var box=document.getElementById('mrt-msgbox');if(box){box.hidden=!box.hidden;var ta=box.querySelector('textarea');if(!box.hidden&&ta)ta.focus()}return}
if(a==='sendmsg'){var ta2=document.getElementById('mrt-msgtxt');post({action:'mrt_act',act:'msg',pid:pid,text:ta2.value},function(r){toast(r.msg);if(r.ok){ta2.value='';document.getElementById('mrt-msgbox').hidden=true}});return}
if(a==='vreq'){b.disabled=true;post({action:'mrt_x',act:'vreq'},function(r){toast(r.msg);if(r.ok){var pl=document.createElement('span');pl.className='pill ps';pl.textContent='Verification requested';var nt=document.createElement('p');nt.className='note2';nt.style.margin='10px 0 0';nt.textContent=r.msg;var pp=b.parentNode;pp.replaceChild(pl,b);pp.appendChild(nt)}else{b.disabled=false}});return}
if(a==='report'){var old=document.getElementById('mrt-rep');if(old)old.remove();var md=document.createElement('div');md.id='mrt-rep';md.className='mrt-rep';md.innerHTML='<div class="mrt-rep-in" role="dialog" aria-label="Report this profile"><b>Why are you reporting this profile?</b>'+['Fake or copied profile','Photo is not of this person','Asked me for money','Rude or abusive','Other problem'].map(function(x){return '<button type="button" data-r="'+x+'">'+x+'</button>'}).join('')+'<button type="button" class="x" data-r="">Cancel</button></div>';document.body.appendChild(md);md.addEventListener('click',function(ev){var tg=ev.target.closest?ev.target.closest('button'):null;if(ev.target===md||(tg&&!tg.getAttribute('data-r'))){md.remove();return}if(tg){var rs=tg.getAttribute('data-r');md.remove();post({action:'mrt_x',act:'report',pid:pid,reason:rs},function(x){toast(x.msg)})}});return}
if(a==='block'||a==='hide'||a==='report'){if(a==='block'&&!confirm('Block this member?'))return;
post({action:'mrt_x',act:a,pid:pid},function(r){toast(r.msg);if(r.ok&&a==='hide'){var t=b.closest('.mt');if(t){t.classList.add('gone');setTimeout(function(){t.remove()},350)}}});return}
if(b.disabled)return;b.disabled=true;
post({action:'mrt_act',act:a,pid:pid},function(r){b.disabled=false;toast(r.msg);
if(a==='fav'&&r.ok){b.classList.toggle('on',!!r.state)}
if(r.ok&&(a==='wink'||a==='interest'))b.classList.add('on');
if(r.ok&&(a==='hit'||a==='miss')){var hb=document.querySelector('[data-act=hit]');if(hb){hb.classList.toggle('on',!!r.state);var hn=hb.querySelector('.hitn');if(hn&&r.hits!==undefined)hn.textContent=r.hits}var mb=document.querySelector('[data-act=miss]');if(mb)mb.classList.toggle('on',!r.state)}});
});
/* install prompt: one tap puts the My Rishta icon on the phone and opens as an app */
var dp;var sa0=(window.matchMedia&&matchMedia('(display-mode: standalone)').matches)||navigator.standalone===true;
window.addEventListener('beforeinstallprompt',function(e){e.preventDefault();dp=e});
window.addEventListener('appinstalled',function(){var i=document.getElementById('mrt-install');if(i)i.hidden=true;dp=null;toast('Installed. Look for the My Rishta icon on your home screen.')});
function instHelp(){var old=document.getElementById('mrt-ih');if(old)old.remove();var ios=/iphone|ipad|ipod/i.test(navigator.userAgent);var d=document.createElement('div');d.id='mrt-ih';d.setAttribute('role','dialog');
d.style.cssText='position:fixed;inset:0;z-index:99999;background:rgba(20,10,15,.55);display:flex;align-items:flex-end;justify-content:center';
var st=ios?['Tap the Share button at the bottom of Safari','Choose <b>Add to Home Screen</b>','Tap <b>Add</b>. The My Rishta icon appears on your home screen']:['Tap the <b>three dots &#8942;</b> at the top right of Chrome','Choose <b>Install app</b> or <b>Add to Home screen</b>','Tap <b>Install</b>. The My Rishta icon appears on your home screen'];
var ur=ios?['سفاری میں نیچے Share کا بٹن دبائیں','<b>Add to Home Screen</b> چنیں','<b>Add</b> دبائیں۔ آئیکن ہوم اسکرین پر آ جائے گا']:['کروم میں اوپر دائیں طرف <b>تین نقطے &#8942;</b> دبائیں','<b>Install app</b> یا <b>Add to Home screen</b> چنیں','<b>Install</b> دبائیں۔ آئیکن ہوم اسکرین پر آ جائے گا'];
var h='<div style="background:#fff;width:100%;max-width:480px;border-radius:22px 22px 0 0;padding:22px 20px calc(22px + env(safe-area-inset-bottom,0px));box-shadow:0 -10px 40px rgba(0,0,0,.25);font-family:inherit"><b style="font-size:1.15rem;color:#2b1a22">Install My Rishta on your phone</b><div dir="rtl" style="color:#6b5a62;margin:2px 0 14px">اپنے فون پر مائی رشتہ انسٹال کریں</div><ol style="margin:0 0 16px;padding:0;list-style:none;display:grid;gap:12px">';
for(var i=0;i<3;i++)h+='<li style="display:flex;gap:12px;align-items:flex-start"><span style="flex:none;width:28px;height:28px;border-radius:50%;background:#9b1b4b;color:#fff;display:grid;place-items:center;font-weight:700">'+(i+1)+'</span><span style="line-height:1.45;color:#2b1a22">'+st[i]+'<br><span dir="rtl" style="display:block;text-align:right;color:#6b5a62">'+ur[i]+'</span></span></li>';
h+='</ol><button type="button" id="mrt-ihx" style="width:100%;min-height:50px;border:0;border-radius:14px;background:#9b1b4b;color:#fff;font:inherit;font-weight:700;font-size:1rem;cursor:pointer">OK</button></div>';
d.innerHTML=h;document.body.appendChild(d);d.addEventListener('click',function(e){if(e.target===d||e.target.id==='mrt-ihx')d.remove()})}
(function(){var i=document.getElementById('mrt-install');if(i)i.hidden=!!sa0})();
document.addEventListener('click',function(e){var b=e.target.closest('#mrt-install');if(!b)return;e.preventDefault();
if(dp){var p=dp;dp=null;p.prompt();if(p.userChoice)p.userChoice.then(function(c){if(c&&c.outcome==='accepted')toast('Installing My Rishta. The icon will appear on your home screen.');else instHelp()})}else{instHelp()}});
})();

/* recently viewed: members are saved in the database (server side); visitors without an account keep a short list in this browser */
(function(){var C=(window.mrtX||{}).C||window.MRT||{},post=(window.mrtX||{}).post,toast=(window.mrtX||{}).toast;try{if(C.in)return;var k='mrt_rv',L=JSON.parse(localStorage.getItem(k)||'[]'),m=document.querySelector('meta[name=mrt-profile]');
if(m){var d={u:location.href,n:m.getAttribute('data-n')};L=L.filter(function(x){return x.u!==d.u});L.unshift(d);localStorage.setItem(k,JSON.stringify(L.slice(0,8)))}
var h=document.getElementById('mrt-rv');if(h&&L.length){h.hidden=false;var w=h.querySelector('.row');L.forEach(function(x){var a=document.createElement('a');a.className='chip';a.href=x.u;a.textContent=x.n;w.appendChild(a)})}}catch(e){}})();

/* live chat: new messages appear by themselves; the bottom-bar badge stays current */
(function(){var C=(window.mrtX||{}).C||window.MRT||{},post=(window.mrtX||{}).post,toast=(window.mrtX||{}).toast;var box=document.getElementById('mrt-chat');
function badge(n){var a=document.querySelector('.mbar a:nth-child(4)');if(!a)return;var b=a.querySelector('.nb');if(n>0){if(!b){b=document.createElement('span');b.className='nb';a.appendChild(b)}b.textContent=n}else if(b){b.remove()}}
if(C.in){var ut=function(){if(document.hidden)return;post({action:'mrsh_unread'},function(r){if(r&&r.ok)badge(r.unread)})};setInterval(ut,window.MRT_SLOW?150000:45000)}
if(!box)return;var w=box.getAttribute('data-with'),list=box.querySelector('.cl'),ta=box.querySelector('textarea'),btn=box.querySelector('.send'),last=+box.getAttribute('data-last')||0,t=null,busy=false;
function add(m){if(m.id<=last&&m.id)return;var d=document.createElement('div');d.className='bub'+(m.me?' me':'');d.textContent=m.text;d.title=m.time||'';list.appendChild(d);if(m.id>last)last=m.id}
function bottom(){list.scrollTop=list.scrollHeight}bottom();
function poll(){clearTimeout(t);if(document.hidden){t=setTimeout(poll,15000);return}post({action:'mrsh_chat_poll',with:w,after:last},function(r){if(r&&r.ok){if(r.msgs&&r.msgs.length){r.msgs.forEach(add);bottom()}badge(r.unread)}t=setTimeout(poll,window.MRT_SLOW?12000:4000)})}
t=setTimeout(poll,window.MRT_SLOW?12000:4000);document.addEventListener('visibilitychange',function(){if(!document.hidden)poll()});
function send(){if(!ta||busy)return;var v=ta.value.trim();if(!v)return;busy=true;btn.disabled=true;post({action:'mrsh_chat_send',with:w,text:v},function(r){busy=false;btn.disabled=false;if(r&&r.ok){add(r.msg);ta.value='';ta.style.height='';bottom()}else toast((r&&r.msg)||'Could not send.')})}
if(btn)btn.onclick=send;if(ta){ta.addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send()}});ta.addEventListener('input',function(){ta.style.height='auto';ta.style.height=Math.min(120,ta.scrollHeight)+'px'})}
})();
/* push notifications: turn on from My account */
(function(){var C=window.MRT||{};var bs=document.querySelectorAll('[data-push]');if(!bs.length)return;
function tt(m){var t=document.getElementById('mrt-toast');if(!t){t=document.createElement('div');t.id='mrt-toast';t.setAttribute('role','status');document.body.appendChild(t)}t.textContent=m;t.className='show';clearTimeout(t._t);t._t=setTimeout(function(){t.className=''},4200)}
function pp(d,cb){var f=new FormData();for(var k in d)f.append(k,d[k]);f.append('n',C.n);fetch(C.ajax,{method:'POST',credentials:'same-origin',body:f}).then(function(r){return r.json()}).then(cb).catch(function(){cb({ok:false,msg:'Network problem. Try again.'})})}
function ok(){return 'serviceWorker' in navigator&&'PushManager' in window&&'Notification' in window&&C.vapid}
function u8(s){var p='='.repeat((4-s.length%4)%4),b=(s+p).replace(/-/g,'+').replace(/_/g,'/'),r=atob(b),o=new Uint8Array(r.length);for(var i=0;i<r.length;i++)o[i]=r.charCodeAt(i);return o}
bs.forEach(function(el){if(!ok()){el.disabled=true;el.textContent='Not available on this browser (on iPhone, add the site to the Home Screen first)';return}
if(Notification.permission==='granted'){el.textContent='Notifications are on (tap to refresh)'}
el.onclick=function(){if(Notification.permission==='denied'){tt('Notifications are blocked for this site. Open the browser settings for this site and allow Notifications, then try again.');return}
el.disabled=true;var back=function(){el.disabled=false};
Notification.requestPermission().then(function(p){if(p!=='granted'){back();tt('Notifications are not allowed. Allow them when the browser asks, or in the site settings.');return}
return navigator.serviceWorker.getRegistration().then(function(r){return r||navigator.serviceWorker.register('/mr-sw.js',{scope:'/'})}).then(function(){return Promise.race([navigator.serviceWorker.ready,new Promise(function(_,rej){setTimeout(function(){rej(new Error('sw'))},8000)})])}).then(function(reg){return reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:u8(C.vapid)})}).then(function(sub){pp({action:'mrt_push_sub',sub:JSON.stringify(sub)},function(r){back();tt(r.msg);if(r.ok)el.textContent='Notifications are on'})})}).catch(function(e){back();tt('Could not turn on notifications on this device'+(e&&e.message==='sw'?' (the app helper did not start; reload the page and try again).':'.'))})}})})();
(function(){var t=document.createElement('button');t.className='totop';t.type='button';t.setAttribute('aria-label','Back to top');t.innerHTML='&#8593;';t.hidden=true;document.body.appendChild(t);
t.onclick=function(){window.scrollTo({top:0,behavior:'smooth'})};
window.addEventListener('scroll',function(){t.hidden=window.pageYOffset<600},{passive:true});
if('IntersectionObserver' in window){var io=new IntersectionObserver(function(es){es.forEach(function(x){if(x.isIntersecting){x.target.classList.add('in');io.unobserve(x.target)}})},{rootMargin:'0px 0px -40px 0px'});
document.querySelectorAll('.card,.box,.steps>*,.stories>*').forEach(function(el){el.classList.add('rv');io.observe(el)})}
document.querySelectorAll('.card img').forEach(function(im){if(im.complete)im.classList.add('ld');else im.addEventListener('load',function(){im.classList.add('ld')})});
})();

(function(){var C=window.MRT||{};var bt=document.getElementById('mrt-loc');if(!bt)return;var msg=document.getElementById('mrt-locmsg');
function norm(x){return (x||'').toLowerCase().replace(/[^a-z]/g,'')}
function put(k,v){if(!v)return false;var w=document.querySelector('[data-loc="'+k+'"]');if(!w)return false;var f=w.querySelector('select,input');if(!f)return false;
if(f.tagName==='SELECT'){var n=norm(v),hit=null;for(var i=0;i<f.options.length;i++){var o=norm(f.options[i].text);if(o&&(o===n||o.indexOf(n)>-1||n.indexOf(o)>-1)){hit=i;break}}if(hit===null){if(k==='country'&&f.id!=='loc-country')return false;var op=document.createElement('option');op.text=v;f.add(op);hit=f.options.length-1}f.selectedIndex=hit}else{f.value=v}
f.dispatchEvent(new Event('change',{bubbles:true}));return true}
function apply(c,ci,st){var a=put('country',c),b=put('city',ci);put('state',st);
msg.textContent=(a||b)?'Filled'+(c?': '+c:'')+(ci?', '+ci:'')+'. Please check.':'Found '+[ci,c].filter(Boolean).join(', ')+' but it is not in the list. Choose it by hand.'}
var fin=false,wd=null;function slow(){if(fin)return;fin=true;clearTimeout(wd);msg.textContent='Slow connection? No problem. Just type your country and city below.';var y=document.getElementById('loc-city');if(y&&!y.value){try{y.focus({preventScroll:true})}catch(e){}}}
function done(){if(fin)return;fin=true;clearTimeout(wd)}
function fetchT(u,o,ms){if(!window.AbortController)return fetch(u,o);var ac=new AbortController(),t=setTimeout(function(){ac.abort()},ms);o=o||{};o.signal=ac.signal;return fetch(u,o).then(function(r){clearTimeout(t);return r},function(e){clearTimeout(t);throw e})}
function byIp(){if(fin)return;var fd=new FormData();fd.append('action','mrt_geo');fd.append('n',C.n);fetchT(C.ajax,{method:'POST',body:fd,credentials:'same-origin'},4000).then(function(r){return r.json()}).then(function(d){if(fin)return;if(d&&d.ok){done();apply(d.country,d.city,d.state)}else slow()}).catch(slow)}
bt.addEventListener('click',function(){fin=false;msg.textContent='Detecting... (a few seconds)';clearTimeout(wd);wd=setTimeout(slow,5000);
if(navigator.geolocation){navigator.geolocation.getCurrentPosition(function(p){fetchT('https://api.bigdatacloud.net/data/reverse-geocode-client?localityLanguage=en&latitude='+p.coords.latitude+'&longitude='+p.coords.longitude,null,3500).then(function(r){return r.json()}).then(function(d){if(fin)return;done();apply(d.countryName,d.city||d.locality,d.principalSubdivision)}).catch(byIp)},byIp,{timeout:3500,maximumAge:600000})}else byIp()});
setTimeout(function(){var c=document.querySelector('[data-loc="country"] select,[data-loc="country"] input'),y=document.querySelector('[data-loc="city"] input');if((c&&!c.value)||(y&&!y.value)){bt.click()}},700);
})();
(function(){var f=document.querySelector('form.pf');if(!f)return;
var m=document.getElementById('mrt-fm'),mt=document.getElementById('mrt-fmt');
function upd(){var els=f.querySelectorAll('select,input:not([type=file]):not([type=hidden]):not([type=checkbox]),textarea'),n=0,t=0;
els.forEach(function(e){t++;if(e.value&&e.value.trim())n++;e.classList.toggle('ok',!!(e.value&&e.value.trim()))});
f.querySelectorAll('.dz.has').length&&(n++,t++);var p=t?Math.round(n*100/t):0;
if(m)m.style.width=p+'%';if(mt)mt.textContent=p+'% complete';
var c=document.getElementById('mrt-cnt'),a=document.getElementById('mrt-about');if(c&&a)c.textContent=a.value.length+' / 1500'}
f.addEventListener('input',upd);f.addEventListener('change',upd);
f.querySelectorAll('.drop input').forEach(function(i){i.addEventListener('change',function(){var dz=i.nextElementSibling,fl=i.files&&i.files[0];
if(fl&&fl.type.indexOf('image')===0){dz.style.backgroundImage='url('+URL.createObjectURL(fl)+')';dz.classList.add('has')}else{dz.style.backgroundImage='';dz.classList.remove('has')}upd()})});
upd()})();

(function(){document.querySelectorAll('.drop').forEach(function(d){var i=d.querySelector('input'),dz=d.querySelector('.dz');
['dragenter','dragover'].forEach(function(ev){d.addEventListener(ev,function(e){e.preventDefault();dz.classList.add('over')})});
['dragleave','drop'].forEach(function(ev){d.addEventListener(ev,function(e){e.preventDefault();dz.classList.remove('over')})});
d.addEventListener('drop',function(e){var fl=e.dataTransfer&&e.dataTransfer.files;if(!fl||!fl.length)return;
try{var dt=new DataTransfer();dt.items.add(fl[0]);i.files=dt.files;i.dispatchEvent(new Event('change',{bubbles:true}))}catch(x){}})})
window.addEventListener('dragover',function(e){if(document.querySelector('.drop'))e.preventDefault()});
window.addEventListener('drop',function(e){if(document.querySelector('.drop')&&!e.target.closest('.drop'))e.preventDefault()});
})();

(function(){if(document.getElementById('loc-country'))return;var cw=document.querySelector('[data-loc="country"]'),yw=document.querySelector('[data-loc="city"]');if(!cw&&!yw)return;
var CT={'Pakistan':['Lahore','Karachi','Islamabad','Rawalpindi','Faisalabad','Multan','Peshawar','Quetta','Gujranwala','Sialkot','Hyderabad','Bahawalpur','Sargodha','Sukkur','Larkana','Sheikhupura','Gujrat','Mardan','Abbottabad','Kasur','Okara','Sahiwal','Jhelum','Mirpur','Muzaffarabad','Dera Ghazi Khan','Rahim Yar Khan','Mingora','Chiniot','Kamoke','Shahdara'],
'United Arab Emirates':['Dubai','Abu Dhabi','Sharjah','Ajman','Ras Al Khaimah','Al Ain'],'Saudi Arabia':['Riyadh','Jeddah','Makkah','Madinah','Dammam','Khobar','Tabuk','Taif'],
'United Kingdom':['London','Birmingham','Manchester','Bradford','Glasgow','Leeds','Leicester','Luton','Slough','Oldham'],'United States':['New York','Chicago','Houston','Los Angeles','Dallas','Atlanta','Washington','Boston'],
'Canada':['Toronto','Mississauga','Brampton','Calgary','Vancouver','Montreal','Ottawa'],'Qatar':['Doha'],'Kuwait':['Kuwait City'],'Oman':['Muscat'],'Bahrain':['Manama'],'Australia':['Sydney','Melbourne','Brisbane','Perth'],'Germany':['Berlin','Frankfurt','Munich','Hamburg'],'Norway':['Oslo'],'Malaysia':['Kuala Lumpur'],'India':['Delhi','Mumbai','Hyderabad']};
var CL=['Pakistan','Afghanistan','Australia','Austria','Azerbaijan','Bahrain','Bangladesh','Belgium','Brazil','Canada','China','Denmark','Egypt','France','Germany','Greece','India','Indonesia','Iran','Iraq','Ireland','Italy','Japan','Jordan','Kenya','Kuwait','Lebanon','Malaysia','Maldives','Morocco','Netherlands','New Zealand','Nigeria','Norway','Oman','Palestine','Philippines','Poland','Qatar','Russia','Saudi Arabia','Singapore','South Africa','South Korea','Spain','Sri Lanka','Sweden','Switzerland','Thailand','Turkey','United Arab Emirates','United Kingdom','United States','Other'];
function cityList(c){var o=document.getElementById('mrt-cities');if(!o){o=document.createElement('datalist');o.id='mrt-cities';document.body.appendChild(o)}o.innerHTML='';(CT[c]||[]).forEach(function(x){var e=document.createElement('option');e.value=x;o.appendChild(e)})}
var cs=cw&&cw.querySelector('select,input');
if(cs&&cs.tagName==='INPUT'){var s=document.createElement('select');s.name=cs.name;s.required=cs.required;var cur=cs.value;s.innerHTML='<option value="">Select country</option>';
CL.forEach(function(x){var o=document.createElement('option');o.text=x;if(x===cur)o.selected=true;s.add(o)});
if(cur&&CL.indexOf(cur)<0){var o2=document.createElement('option');o2.text=cur;o2.selected=true;s.add(o2)}
cs.parentNode.replaceChild(s,cs);cs=s}
var yi=yw&&yw.querySelector('input');
if(yi){yi.setAttribute('list','mrt-cities');yi.setAttribute('autocomplete','off');yi.placeholder='Choose from the list or type your city'}
if(cs){cs.addEventListener('change',function(){cityList(cs.value);if(yi&&CT[cs.value]&&yi.value&&CT[cs.value].indexOf(yi.value)<0)yi.select()});cityList(cs.value||'Pakistan')}
})();

/* 0.9.7 helpers */
(function(){var C=(window.mrtX||{}).C||window.MRT||{},post=(window.mrtX||{}).post,toast=(window.mrtX||{}).toast;
// ripple
document.addEventListener('pointerdown',function(e){var b=e.target.closest&&e.target.closest('.btn');if(!b)return;var r=b.getBoundingClientRect(),s=Math.max(r.width,r.height),i=document.createElement('span');i.className='rip';i.style.cssText='width:'+s+'px;height:'+s+'px;left:'+(e.clientX-r.left-s/2)+'px;top:'+(e.clientY-r.top-s/2)+'px';b.appendChild(i);setTimeout(function(){i.remove()},600)});
// active tab into view
var cur=document.querySelector('.tabs a.cur');if(cur&&cur.scrollIntoView){try{cur.parentNode.scrollTo({left:cur.offsetLeft-20,behavior:'auto'})}catch(x){}}
// "/" focuses search
document.addEventListener('keydown',function(e){if(e.key!=='/'||/INPUT|TEXTAREA|SELECT/.test((document.activeElement||{}).tagName))return;var s=document.querySelector('input[name=s],input[type=search]');if(s){e.preventDefault();s.focus()}});
// password show/hide + strength
document.querySelectorAll('input[type=password]').forEach(function(p){if(p.closest('.pwrap'))return;var w=document.createElement('div');w.className='pwrap';p.parentNode.insertBefore(w,p);w.appendChild(p);
var t=document.createElement('button');t.type='button';t.className='pwt';t.textContent='Show';t.onclick=function(){var h=p.type==='password';p.type=h?'text':'password';t.textContent=h?'Hide':'Show'};w.appendChild(t);
if(p.getAttribute('autocomplete')==='new-password'||p.name==='pass'){var m=document.createElement('div');m.className='pws';m.innerHTML='<i></i>';w.parentNode.insertBefore(m,w.nextSibling);
p.addEventListener('input',function(){var v=p.value,sc=0;if(v.length>=8)sc++;if(v.length>=12)sc++;if(/[A-Z]/.test(v)&&/[a-z]/.test(v))sc++;if(/\d/.test(v))sc++;if(/[^A-Za-z0-9]/.test(v))sc++;var i=m.firstChild;i.style.width=(v?Math.max(12,sc*20):0)+'%';i.style.background=sc<3?'#ef4444':sc<4?'#f59e0b':'#16a34a'})}});
// quick replies + Ctrl+Enter
var ta=document.getElementById('mrt-msgtxt');if(ta){var q=document.createElement('div');q.className='qr';['Assalam o Alaikum, I liked your profile.','Could you share more about your family?','My family would like to talk to yours.'].forEach(function(x){var b=document.createElement('button');b.type='button';b.textContent=x.length>28?x.slice(0,26)+'...':x;b.title=x;b.onclick=function(){ta.value=x;ta.focus()};q.appendChild(b)});ta.parentNode.insertBefore(q,ta);
ta.addEventListener('keydown',function(e){if(e.key==='Enter'&&(e.ctrlKey||e.metaKey)){var sb=document.querySelector('[data-act=sendmsg]');if(sb)sb.click()}})}
// profile form: draft saved in the database + unsaved warning
var f=document.querySelector('form.pf');if(f){var dirty=false,saved=false,tm=null;
function snap(){var o={};f.querySelectorAll('input:not([type=file]):not([type=hidden]):not([type=checkbox]):not([type=tel]),select,textarea').forEach(function(e){if(e.name&&e.name!=='pass'&&!/phone|mobile|whatsapp|contact/i.test(e.name+(e.closest('div')&&e.closest('div').textContent.slice(0,30))))o[e.name]=e.value});return o}
function dsave(){clearTimeout(tm);tm=setTimeout(function(){post({action:'mrt_draft',op:'save',data:JSON.stringify(snap())},function(){})},1500)}
if(C.in){post({action:'mrt_draft',op:'get'},function(r){var d=r&&r.data,empty=!f.querySelector('[name=title]').value;
if(d&&empty){var bar=document.createElement('div');bar.className='draftbar';bar.innerHTML='<span>You have an unsaved draft saved to your account.</span><span><button type="button" class="btn line" id="dr-y">Restore</button> <button type="button" class="btn line" id="dr-n">Discard</button></span>';f.parentNode.insertBefore(bar,f);
document.getElementById('dr-y').onclick=function(){Object.keys(d).forEach(function(n){var e=f.querySelector('[name="'+n.replace(/"/g,'')+'"]');if(e){e.value=d[n];e.dispatchEvent(new Event('change',{bubbles:true}))}});bar.remove()};
document.getElementById('dr-n').onclick=function(){post({action:'mrt_draft',op:'clear'},function(){});bar.remove()}}})}
f.addEventListener('input',function(){dirty=true;if(C.in)dsave()});
f.addEventListener('submit',function(){saved=true;clearTimeout(tm)});
window.addEventListener('beforeunload',function(e){if(dirty&&!saved){e.preventDefault();e.returnValue=''}})}
})();

/* phone boxes never keep a non-phone value (browser autofill or form restore) */
(function(){function fix(){document.querySelectorAll('input[data-phone]').forEach(function(i){var v=(i.value||'').trim();if(v&&!/^[0-9+\-\s]{6,20}$/.test(v)){i.value='';i.dispatchEvent(new Event('input',{bubbles:true}))}})}
fix();setTimeout(fix,300);setTimeout(fix,1200);window.addEventListener('pageshow',fix);
document.querySelectorAll('input[data-phone]').forEach(function(i){i.addEventListener('blur',fix)});
var f=document.querySelector('form.pf');if(f)f.addEventListener('submit',fix,true)})();

/* country -> city suggestions from the site's own country list */
(function(){var cs=document.getElementById('loc-country'),dl=document.getElementById('mrt-cities');if(!cs||!dl)return;var C=window.MRT||{},last='';
function load(){var c=cs.value;if(!c||c===last)return;last=c;var fd=new FormData();fd.append('action','mrt_cities');fd.append('n',C.n);fd.append('c',c);
fetch(C.ajax,{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(d){dl.innerHTML='';(d.cities||[]).forEach(function(x){var o=document.createElement('option');o.value=x;dl.appendChild(o)})}).catch(function(){})}
cs.addEventListener('change',load);load()})();

/* app mode (installed PWA) + install sheet + offline bar + haptics + pull to refresh */
(function(){var de=document.documentElement,sa=(window.matchMedia&&matchMedia('(display-mode: standalone)').matches)||navigator.standalone===true;
if(sa)de.classList.add('app');
function ls(k,v){try{if(v===undefined)return localStorage.getItem(k);localStorage.setItem(k,v)}catch(x){return null}}
// active tab in bottom bar
var path=location.pathname.replace(/\/$/,''),q=location.search;
document.querySelectorAll('.mbar a').forEach(function(a){try{var u=new URL(a.href);var p=u.pathname.replace(/\/$/,'');var same=p===path&&(u.search===''||q.indexOf(u.search.replace(/^\?/,''))>-1);if(same&&(p!==''||path==='')){a.classList.add('cur')}}catch(x){}});
// haptics
document.addEventListener('click',function(e){if(navigator.vibrate&&e.target.closest&&e.target.closest('.btn,.qb,.hrt,.mbar a,.tabs a'))navigator.vibrate(8)},true);
// offline bar
var ob=document.createElement('div');ob.className='offbar';ob.textContent='You are offline. Some things may not work.';ob.hidden=navigator.onLine!==false;document.body.appendChild(ob);
function net(){ob.hidden=navigator.onLine}window.addEventListener('online',net);window.addEventListener('offline',net);
// install sheet
var dp=null;window.addEventListener('beforeinstallprompt',function(e){e.preventDefault();dp=e});
var ua=navigator.userAgent,ios=/iphone|ipad|ipod/i.test(ua)&&!window.MSStream,mob=/android|iphone|ipad|ipod/i.test(ua);
if(!sa&&mob){var n=(parseInt(ls('mrt_visits'),10)||0)+1;ls('mrt_visits',String(n));var dis=parseInt(ls('mrt_inst_no'),10)||0;
if(n>=2&&Date.now()-dis>14*864e5){(window.mrtLate||function(k,f){setTimeout(f,15000)})('inst',function(){if(!ios&&!dp)return;var s=document.createElement('div');s.className='instsheet';
s.innerHTML='<b>Get the My Rishta app</b><p>'+(ios?'Tap the Share button, then <b>Add to Home Screen</b>.':'Faster, full screen, one tap from your home screen.')+'</p><div><button type="button" class="btn sm" id="is-go">'+(ios?'Got it':'Install app')+'</button><button type="button" class="btn sm line" id="is-no">Not now</button></div>';
document.body.appendChild(s);setTimeout(function(){s.classList.add('on')},30);
function close(){ls('mrt_inst_no',String(Date.now()));s.classList.remove('on');setTimeout(function(){s.remove()},300)}
s.querySelector('#is-no').onclick=close;s.querySelector('#is-go').onclick=function(){if(dp){dp.prompt();dp=null}close()}})}}
// pull to refresh (installed app only)
if(sa){var y0=0,pull=0,ind=document.createElement('div');ind.className='ptr';ind.innerHTML='&#8635;';document.body.appendChild(ind);
window.addEventListener('touchstart',function(e){y0=window.pageYOffset===0?e.touches[0].clientY:-1},{passive:true});
window.addEventListener('touchmove',function(e){if(y0<0)return;pull=e.touches[0].clientY-y0;if(pull>0){ind.style.transform='translate(-50%,'+Math.min(pull/2,60)+'px) rotate('+pull*3+'deg)';ind.style.opacity=Math.min(pull/90,1)}},{passive:true});
window.addEventListener('touchend',function(){if(y0>=0&&pull>110){ind.classList.add('spin');location.reload()}else{ind.style.transform='';ind.style.opacity=0}y0=0;pull=0},{passive:true})}
})();

/* desktop menu: highlight current link, close account menu on outside click */
(function(){var p=location.pathname.replace(/\/$/,'');document.querySelectorAll('.nav a').forEach(function(a){try{var u=new URL(a.href);var q=u.pathname.replace(/\/$/,'');if(q===p&&p!==''||(q===''&&p==='')){a.classList.add('cur')}else if(q!==''&&p.indexOf(q)===0&&q.length>1){a.classList.add('cur')}}catch(x){}});
var ac=document.querySelector('.acct');if(ac){document.addEventListener('click',function(e){if(!ac.contains(e.target))ac.classList.remove('open');else if(e.target.closest('.acb'))ac.classList.toggle('open')});document.addEventListener('keydown',function(e){if(e.key==='Escape')ac.classList.remove('open')})}})();

/* shrink phone photos before upload so the form never fails on big camera pictures */
(function(){var f=document.querySelector('form.pf');if(!f||!window.HTMLCanvasElement||!window.DataTransfer)return;
function shrink(file,cb){if(!file||file.type.indexOf('image/')!==0||(file.size<700*1024&&/jpe?g|png|webp/.test(file.type))){cb(file);return}
var img=new Image(),url=URL.createObjectURL(file);
img.onload=function(){var M=1600,w=img.naturalWidth,h=img.naturalHeight,r=Math.min(1,M/Math.max(w,h));
var c=document.createElement('canvas');c.width=Math.round(w*r);c.height=Math.round(h*r);c.getContext('2d').drawImage(img,0,0,c.width,c.height);
c.toBlob(function(b){URL.revokeObjectURL(url);if(!b||b.size>=file.size&&/jpe?g/.test(file.type)){cb(file);return}
cb(new File([b],(file.name||'photo').replace(/\.[^.]+$/,'')+'.jpg',{type:'image/jpeg'}))},'image/jpeg',.82)};
img.onerror=function(){URL.revokeObjectURL(url);cb(file)};img.src=url}
f.querySelectorAll('.drop input[type=file]').forEach(function(inp){inp.addEventListener('change',function(){if(inp.__s){inp.__s=0;return}var fl=inp.files&&inp.files[0];if(!fl)return;
var dz=inp.nextElementSibling;if(dz)dz.classList.add('busy');
shrink(fl,function(n){try{if(n!==fl){var dt=new DataTransfer();dt.items.add(n);inp.__s=1;inp.files=dt.files;inp.dispatchEvent(new Event('change',{bubbles:true}))}}catch(x){}if(dz)dz.classList.remove('busy')})},true)});
// clear message + scroll to the first problem
f.addEventListener('invalid',function(e){var t=e.target;t.classList.add('bad');setTimeout(function(){t.scrollIntoView({block:'center',behavior:'smooth'})},50)},true);
f.addEventListener('submit',function(){var b=f.querySelector('button.btn:not([type=button])');if(b){b.disabled=true;b.textContent='Saving...'}});
window.addEventListener('pageshow',function(e){var b=f.querySelector('button.btn:not([type=button])');if(b&&e.persisted){b.disabled=false;b.textContent='Save'}})})();

/* installed app: home opens from the phone's saved copy; if login state changed meanwhile, reload once */
(function(){if(!('serviceWorker' in navigator))return;navigator.serviceWorker.addEventListener('message',function(e){if(e.data&&e.data.mr==='home-changed'&&location.pathname==='/'){location.reload()}})})();

/* slow-network mode: footer button (Auto / Lite on / Lite off), remembered on the phone */
(function(){var b=document.getElementById('mrt-litebtn');if(!b)return;function mode(){try{return localStorage.getItem('mrt_lite')||''}catch(e){return ''}}
function label(){var m=mode(),on=document.documentElement.classList.contains('slownet');b.textContent=m==='on'?'Lite mode: ON (tap to turn off)':m==='off'?'Lite mode: OFF (tap for auto)':(on?'Slow internet detected: Lite mode ON (tap to turn off)':'Slow internet? Turn on Lite mode');b.setAttribute('aria-pressed',on?'true':'false')}
b.onclick=function(){var m=mode(),on=document.documentElement.classList.contains('slownet');if(!window.mrtNet)return;if(m==='on')window.mrtNet('off');else if(m==='off')window.mrtNet('');else window.mrtNet(on?'off':'on');label()};label()})();
(function(){var sel=document.getElementById('loc-country');if(!sel)return;var form=sel.form;
var op=document.createElement('option');op.value='__other';op.text='My country is not in the list (type it) — میرا ملک فہرست میں نہیں (خود لکھیں)';sel.appendChild(op);
var box=document.createElement('input');box.type='text';box.maxLength=40;box.id='loc-country-other';box.placeholder='Type your country / اپنا ملک لکھیں';box.hidden=true;box.style.marginTop='6px';box.setAttribute('autocomplete','off');sel.parentNode.appendChild(box);
sel.addEventListener('change',function(){var o=sel.value==='__other';box.hidden=!o;if(o){box.focus()}});
if(form){form.addEventListener('submit',function(e){if(sel.value!=='__other')return;var v=(box.value||'').replace(/\s+/g,' ').trim();if(!v){e.preventDefault();box.hidden=false;box.focus();return}
v=v.replace(/\b([a-z])/g,function(m){return m.toUpperCase()});var n=document.createElement('option');n.value=v;n.text=v;sel.appendChild(n);sel.value=v})}
})();
