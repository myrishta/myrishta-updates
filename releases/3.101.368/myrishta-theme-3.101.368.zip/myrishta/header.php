<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$logo = mrt_site( 'logo', mrt_opt( 'design', 'logo_url', '' ) );
$name = mrt_site( 'brand', mrt_opt( 'design', 'textlogo', get_bloginfo( 'name' ) ) );
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#f5f5f7">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); echo mrt_sprite(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
<?php if ( mrt_site( 'ann_on', 0 ) && mrt_site( 'ann_text' ) ) : $al = mrt_site( 'ann_link' ); ?><div class="annbar"><?php echo $al ? '<a href="' . esc_url( $al ) . '">' : ''; echo esc_html( mrt_site( 'ann_text' ) ); echo $al ? '</a>' : ''; ?></div><?php endif; ?>
<header class="site-head"><div class="wrap">
	<?php
	$main = trim( preg_replace( '/\s+Pakistan$/i', '', $name ) );
	$tag  = ( $main !== trim( $name ) ) ? 'Pakistan' : (string) mrt_site( 'tagline', '' );
	$wd   = preg_split( '/\s+/', $main, 2 );
	if ( mrt_site( 'css_logo', 1 ) ) : ?>
	<a class="brand cl" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( $name ); ?>">
		<i class="cl-mark" aria-hidden="true"><b></b><b></b></i>
		<span class="cl-txt"><span class="cl-main"><?php echo esc_html( $wd[0] ); ?><?php echo isset( $wd[1] ) ? ' <strong>' . esc_html( $wd[1] ) . '</strong>' : ''; ?></span><?php echo $tag ? '<small class="cl-tag">' . esc_html( $tag ) . '</small>' : ''; ?></span>
	</a>
	<?php else : ?>
	<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
		<?php if ( $logo ) : ?><img src="<?php echo esc_url( $logo ); ?>" alt="<?php echo esc_attr( $name ); ?>" width="42" height="42"><?php endif; ?>
		<span><?php echo esc_html( $name ); ?></span>
	</a>
	<?php endif; ?>
	<nav class="nav" aria-label="Main">
	<?php
	if ( has_nav_menu( 'primary' ) ) {
		wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'items_wrap' => '%3$s', 'walker' => new MRT_Flat_Walker() ) );
	} else {
		echo '<a href="' . esc_url( home_url( '/?post_type=listing_type&s=' ) ) . '">' . mrt_icon( 'search' ) . 'Search</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<a href="' . esc_url( mrt_link( 'memberships', '/memberships/' ) ) . '">' . mrt_icon( 'star' ) . 'Memberships</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<a href="' . esc_url( mrt_link( 'blog', '/blog/' ) ) . '">' . mrt_icon( 'book' ) . 'Blog</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<a href="' . esc_url( mrt_link( 'aboutus', '/about-us/' ) ) . '">' . mrt_icon( 'heart' ) . 'About</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	?>
	</nav>
	<div class="hact">
	<?php
	if ( is_user_logged_in() ) {
		$cu  = wp_get_current_user();
		$ini = function_exists( 'mb_substr' ) ? mb_strtoupper( mb_substr( $cu->display_name, 0, 1 ) ) : strtoupper( substr( $cu->display_name, 0, 1 ) );
		$un  = mrt_unread();
		echo '<div class="acct" tabindex="0"><span class="acb"><i class="ava">' . esc_html( $ini ) . ( $un ? '<b class="nb">' . (int) $un . '</b>' : '' ) . '</i><span class="acn">' . esc_html( $cu->display_name ) . '</span>' . mrt_icon( 'chev' ) . '</span><div class="acm">'; // phpcs:ignore
		$ai = array( 'home' => array( 'My account', 'home' ), 'matches' => array( 'Matches', 'heart' ), 'messages' => array( 'Messages' . ( $un ? ' (' . $un . ')' : '' ), 'chat' ), 'shortlist' => array( 'Shortlist', 'star' ), 'views' => array( 'Viewed me', 'user' ) );
		foreach ( $ai as $tk => $tv ) {
			echo '<a href="' . esc_url( add_query_arg( 'tab', $tk, mrt_login_url() ) ) . '">' . mrt_icon( $tv[1] ) . esc_html( $tv[0] ) . '</a>'; // phpcs:ignore
		}
		echo '<a class="out" href="' . esc_url( wp_logout_url( home_url( '/' ) ) ) . '">' . mrt_icon( 'shield' ) . 'Log out</a></div></div>'; // phpcs:ignore
	} else {
		echo '<a class="btn line" href="' . esc_url( mrt_login_url() ) . '">' . mrt_icon( 'user' ) . 'Login</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	$cta = mrt_cta();
	echo '<a class="btn cta2" href="' . esc_url( $cta[1] ) . '">' . mrt_icon( $cta[2] ) . esc_html( $cta[0] ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
	?>
	</div>
</div></header>
