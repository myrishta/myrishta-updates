<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
while ( have_posts() ) :
	the_post();
	$id     = get_the_ID();
	$age    = get_post_meta( $id, 'daage', true );
	$photos = get_children( array( 'post_parent' => $id, 'post_type' => 'attachment', 'post_mime_type' => 'image', 'numberposts' => 12, 'orderby' => 'menu_order ID', 'order' => 'ASC' ) );
	$share  = 'https://wa.me/?text=' . rawurlencode( get_the_title() . ' ' . get_permalink() );
	?>
<main><meta name="mrt-profile" data-n="<?php echo esc_attr( get_the_title() ); ?>"><div class="wrap">
<?php
$g_  = (string) get_post_meta( $id, 'key4', true );
$ms_ = str_replace( '_', ' ', (string) get_post_meta( $id, 'custom-15', true ) );
$hn  = count( array_filter( (array) get_post_meta( $id, 'mrt_rate', true ) ) );
$gn  = count( (array) get_post_meta( $id, 'mrt_gifts', true ) );
$su  = rawurlencode( get_permalink() );
$st_ = rawurlencode( get_the_title() );
?>
<nav class="crumb2" aria-label="Breadcrumb"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a><?php if ( $g_ ) { echo ' &rsaquo; <a href="' . esc_url( home_url( '/?post_type=listing_type&s=' . rawurlencode( $g_ ) ) ) . '">' . esc_html( $g_ ) . '</a>'; } if ( $ms_ ) { echo ' &rsaquo; <span>' . esc_html( $ms_ ) . '</span>'; } ?></nav>
<div class="prof" id="mrt-print-area">
	<div class="gal">
		<?php
		$big = mrt_photo( $id, 'medium_large', array( 'alt' => get_the_title(), 'decoding' => 'async', 'fetchpriority' => 'high' ) );
		$blur = class_exists( 'MRSH_Manage' ) && ! empty( MRSH_Manage::get()['blurguest'] ) && ! is_user_logged_in();
		$blur = (bool) apply_filters( 'mrt_blur', $blur, $id );
		?>
		<?php
		if ( '' === trim( (string) $big ) ) {
			foreach ( $photos as $ph0 ) {
				$u0 = mrt_att_url( $ph0->ID, 'large' );
				if ( $u0 ) { $big = '<img src="' . esc_url( $u0 ) . '" alt="' . esc_attr( get_the_title() ) . '" decoding="async" referrerpolicy="no-referrer" onerror="this.remove()">'; break; }
			}
		}
		?>
		<div class="main-ph av c<?php echo (int) ( $id % 6 ); ?><?php echo $blur ? ' blur' : ''; ?><?php echo '' === trim( (string) $big ) ? ' nop' : ''; ?>" id="mrt-ph"><?php echo '<span class="pvt">' . mrt_icon( 'shield' ) . '<b>Photo is private</b><button type="button" class="btn sm" data-photoreq="' . (int) $id . '">Request photo</button></span><span class="phb">' . mrt_placeholder() . '</span>' . $big; // phpcs:ignore ?></div>
		<?php if ( $blur ) : ?><p class="ml"><?php if ( is_user_logged_in() ) : ?>This member shows photos only to some members.<?php else : ?><a href="<?php echo esc_url( mrt_login_url() ); ?>">Log in free</a> to see photos clearly.<?php endif; ?></p><?php endif; ?>
		<?php
		$ok = array();
		foreach ( $photos as $ph ) { if ( file_exists( (string) get_attached_file( $ph->ID ) ) || mrt_remote_host() || ( class_exists( 'MRSH_PhotoBak' ) && MRSH_PhotoBak::has( $ph->ID ) ) ) { $ok[] = $ph; } }
		if ( count( $ok ) > 1 && ! $blur ) : ?><div class="thumbs"><?php foreach ( $ok as $ph ) { echo '<a href="' . esc_url( mrt_att_url( $ph->ID, 'large' ) ) . '" class="mrt-lbx">' . '<img src="' . esc_url( mrt_att_url( $ph->ID, 'thumbnail' ) ) . '" loading="lazy" alt="" onerror="this.parentNode.remove()">' . '</a>'; } ?></div><?php endif; ?>
		<?php if ( ! $blur ) : ?>
		<style>.mrt-lb{position:fixed;inset:0;z-index:99999;background:rgba(10,10,14,.92);display:flex;align-items:center;justify-content:center;opacity:0;pointer-events:none;transition:opacity .2s;-webkit-backdrop-filter:blur(6px);backdrop-filter:blur(6px)}
.mrt-lb.on{opacity:1;pointer-events:auto}
.mrt-lb img{max-width:min(94vw,900px);max-height:88vh;border-radius:14px;box-shadow:0 20px 60px rgba(0,0,0,.5);object-fit:contain;background:#111}
.mrt-lb button{position:absolute;border:0;background:rgba(255,255,255,.14);color:#fff;width:46px;height:46px;border-radius:50%;font-size:26px;line-height:1;cursor:pointer;display:flex;align-items:center;justify-content:center}
.mrt-lb button:hover{background:rgba(255,255,255,.28)}
.mrt-lb .x{top:max(14px,env(safe-area-inset-top));right:14px}.mrt-lb .p{left:14px;top:50%;margin-top:-23px}.mrt-lb .n{right:14px;top:50%;margin-top:-23px}
.mrt-lb .c{position:absolute;bottom:max(16px,env(safe-area-inset-bottom));left:50%;transform:translateX(-50%);color:#fff;font:600 13px system-ui;background:rgba(255,255,255,.14);padding:5px 14px;border-radius:999px}
#mrt-ph img,.thumbs a{cursor:zoom-in}#mrt-ph img,.thumbs img,.mrt-lb img{-webkit-user-drag:none;user-select:none;-webkit-touch-callout:none}</style>
		<div class="mrt-lb" id="mrt-lb" role="dialog" aria-modal="true" aria-label="Photo viewer"><button class="x" type="button" aria-label="Close">&times;</button><button class="p" type="button" aria-label="Previous">&#8249;</button><img alt=""><button class="n" type="button" aria-label="Next">&#8250;</button><span class="c"></span></div>
		<script>(function(){
var lb=document.getElementById('mrt-lb');if(!lb)return;document.body.appendChild(lb);var im=lb.querySelector('img'),ct=lb.querySelector('.c'),L=[],i=0;
function build(){L=[].slice.call(document.querySelectorAll('.thumbs a.mrt-lbx')).map(function(a){return a.getAttribute('href')});
 if(!L.length){var m=document.querySelector('#mrt-ph img');if(m&&m.src)L=[m.getAttribute('data-full')||m.src]}}
function show(n){if(!L.length)return;i=(n+L.length)%L.length;im.src=L[i];ct.textContent=(i+1)+' / '+L.length;ct.style.display=L.length>1?'':'none';lb.querySelector('.p').style.display=lb.querySelector('.n').style.display=L.length>1?'':'none'}
function open(n){build();if(!L.length)return;lb.classList.add('on');document.documentElement.style.overflow='hidden';show(n)}
function close(){lb.classList.remove('on');document.documentElement.style.overflow='';im.removeAttribute('src')}
document.addEventListener('click',function(e){
 var a=e.target.closest&&e.target.closest('.thumbs a.mrt-lbx');
 if(a){e.preventDefault();build();open(L.indexOf(a.getAttribute('href')))}
 else if(e.target.closest&&e.target.closest('#mrt-ph')&&e.target.tagName==='IMG'&&!e.target.closest('.blur')){e.preventDefault();build();var k=0;for(var j=0;j<L.length;j++){if(e.target.src.indexOf(L[j].split('/').pop().replace(/-\d+x\d+(\.\w+)$/,'$1').replace(/\.\w+$/,''))>-1){k=j;break}}open(k)}
});
lb.addEventListener('click',function(e){if(e.target.classList.contains('x')||e.target===lb)close();else if(e.target.classList.contains('p'))show(i-1);else if(e.target.classList.contains('n'))show(i+1)});
document.addEventListener('contextmenu',function(e){if(e.target.closest&&e.target.closest('#mrt-ph,.thumbs,#mrt-lb'))e.preventDefault()});
document.addEventListener('dragstart',function(e){if(e.target.tagName==='IMG'&&e.target.closest&&e.target.closest('#mrt-ph,.thumbs,#mrt-lb'))e.preventDefault()});
document.addEventListener('keydown',function(e){if(!lb.classList.contains('on'))return;if(e.key==='Escape')close();else if(e.key==='ArrowLeft')show(i-1);else if(e.key==='ArrowRight')show(i+1)});
var sx=null;lb.addEventListener('touchstart',function(e){sx=e.touches[0].clientX},{passive:true});
lb.addEventListener('touchend',function(e){if(sx===null)return;var d=e.changedTouches[0].clientX-sx;sx=null;if(Math.abs(d)>50)show(d<0?i+1:i-1)});
})();</script>
		<?php endif; ?>
		<div class="safe"><?php echo mrt_icon( 'shield' ); // phpcs:ignore ?>Phone number is private. Never send money.</div>
	</div>
	<div>
		<h1 style="margin:0"><?php the_title(); ?><?php echo $age ? ', ' . esc_html( $age ) : ''; ?></h1>
		<?php echo mrt_badge_pills( get_post() ); // phpcs:ignore ?>
		<?php
		$pm = class_exists( 'MRSH_Match' ) ? MRSH_Match::pct_for_viewer( get_post() ) : null;
		$sn = class_exists( 'MRSH_Mem_Extras' ) ? MRSH_Mem_Extras::seen_label( (int) get_post_field( 'post_author', $id ) ) : '';
		$fv = is_user_logged_in() ? array_map( 'intval', (array) get_user_meta( get_current_user_id(), 'favorite', true ) ) : array();
		if ( $pm ) { echo '<p class="ml"><span class="pct">' . (int) $pm[0] . '% match with you</span> ' . esc_html( implode( ' · ', $pm[1] ) ) . '</p>'; }
		if ( $sn ) { echo '<p class="seen">● ' . esc_html( $sn ) . '</p>'; }
		?>
		<div class="acts2">
			<div class="main">
				<button type="button" class="btn lg" data-act="interest" data-pid="<?php echo (int) $id; ?>"><?php echo mrt_icon( 'heart' ); // phpcs:ignore ?>Send interest</button>
				<button type="button" class="btn lg alt" data-act="msg" data-pid="<?php echo (int) $id; ?>"><?php echo mrt_icon( 'chat' ); // phpcs:ignore ?>Message</button>
			</div>
			<p class="qt">React</p><div class="quick">
				<button type="button" class="qb" data-act="wink" data-pid="<?php echo (int) $id; ?>"><?php echo mrt_icon( 'smile' ); // phpcs:ignore ?><span>Wink</span></button>
				<button type="button" class="qb<?php echo in_array( $id, $fv, true ) ? ' on' : ''; ?>" data-act="fav" data-pid="<?php echo (int) $id; ?>"><?php echo mrt_icon( 'heart' ); // phpcs:ignore ?><span>Shortlist</span></button>
				<button type="button" class="qb" data-act="hit" data-pid="<?php echo (int) $id; ?>"><?php echo mrt_icon( 'heart' ); // phpcs:ignore ?><span>Hit <b class="hitn"><?php echo (int) $hn; ?></b></span></button>
				<button type="button" class="qb" data-act="miss" data-pid="<?php echo (int) $id; ?>"><?php echo mrt_icon( 'smile' ); // phpcs:ignore ?><span>Miss</span></button>
				<button type="button" class="qb" data-act="gifttray"><?php echo mrt_icon( 'star' ); // phpcs:ignore ?><span>Gift<?php echo $gn ? ' (' . (int) $gn . ')' : ''; ?></span></button>
			</div>
			<p class="qt">Share</p><div class="quick">
				<a class="qb" href="<?php echo esc_url( $share ); ?>" rel="noopener" target="_blank"><?php echo mrt_icon( 'share' ); // phpcs:ignore ?><span>WhatsApp</span></a>
				<button type="button" class="qb" data-share="<?php echo esc_url( get_permalink() ); ?>" data-title="<?php echo esc_attr( get_the_title() ); ?>"><?php echo mrt_icon( 'share' ); // phpcs:ignore ?><span>Copy link</span></button>
				<a class="qb" rel="noopener" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $su; // phpcs:ignore ?>"><?php echo mrt_icon( 'share' ); // phpcs:ignore ?><span>Facebook</span></a>
				<a class="qb" rel="noopener" target="_blank" href="https://twitter.com/intent/tweet?url=<?php echo $su; // phpcs:ignore ?>&text=<?php echo $st_; // phpcs:ignore ?>"><?php echo mrt_icon( 'share' ); // phpcs:ignore ?><span>X</span></a>
				<a class="qb" rel="noopener" target="_blank" href="https://pinterest.com/pin/create/button/?url=<?php echo $su; // phpcs:ignore ?>&description=<?php echo $st_; // phpcs:ignore ?>"><?php echo mrt_icon( 'share' ); // phpcs:ignore ?><span>Pinterest</span></a>
				<a class="qb" rel="noopener" target="_blank" href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo $su; // phpcs:ignore ?>"><?php echo mrt_icon( 'share' ); // phpcs:ignore ?><span>LinkedIn</span></a>
			</div>
			<p class="qt">More</p><div class="quick">
				<button type="button" class="qb" onclick="window.print()"><?php echo mrt_icon( 'book' ); // phpcs:ignore ?><span>Print biodata</span></button>
				<button type="button" class="qb dim" data-act="report" data-pid="<?php echo (int) $id; ?>"><?php echo mrt_icon( 'flag' ); // phpcs:ignore ?><span>Report</span></button>
				<button type="button" class="qb dim" data-act="block" data-pid="<?php echo (int) $id; ?>"><?php echo mrt_icon( 'shield' ); // phpcs:ignore ?><span>Block</span></button>
			</div>
			<div class="gifts" id="mrt-gifts" hidden><b>Send a virtual gift</b><div><?php foreach ( array( 'rose' => array( '🌹', 'Rose' ), 'heart' => array( '💖', 'Heart' ), 'cake' => array( '🎂', 'Cake' ), 'dua' => array( '🤲', 'Dua' ), 'star' => array( '⭐', 'Star' ), 'ring' => array( '💍', 'Ring' ) ) as $gk => $gv ) { echo '<button type="button" class="gbtn" data-act="gift" data-gift="' . esc_attr( $gk ) . '" data-pid="' . (int) $id . '"><span>' . $gv[0] . '</span>' . esc_html( $gv[1] ) . '</button>'; } ?></div></div>
		</div>
		<details class="tips"><summary>Safety tips before you meet</summary><ul><li>Involve your family from the first call.</li><li>Never send money, gifts or ID photos to someone you have not met.</li><li>Meet in a public place with a relative.</li><li>Tap Report if anything feels wrong.</li></ul></details>
		<div id="mrt-msgbox" class="box" hidden><label for="mrt-msgtxt"><b>Your message</b></label><textarea id="mrt-msgtxt" rows="3" maxlength="1000" style="width:100%" placeholder="Assalam o Alaikum, ..."></textarea><p class="ml">Links and phone numbers are not allowed here for your safety.</p><button type="button" class="btn" data-act="sendmsg" data-pid="<?php echo (int) $id; ?>">Send</button></div>
		<?php if ( get_the_content() ) : ?><div class="box b1"><h2>About</h2><?php the_content(); ?></div><?php endif; ?>
		<?php
		// Quick facts
		$glance = array();
		foreach ( array( 'country' => 'pin', 'education' => 'cap', 'occupation' => 'work', 'maritalstatus' => 'ring', 'religion' => 'book' ) as $t => $ic ) {
			if ( taxonomy_exists( $t ) ) {
				$n = wp_get_object_terms( $id, $t, array( 'fields' => 'names', 'number' => 1 ) );
				if ( ! is_wp_error( $n ) && $n ) {
					$glance[] = '<span class="gl">' . mrt_icon( $ic ) . esc_html( $n[0] ) . '</span>';
				}
			}
		}
		if ( $glance ) { echo '<div class="glance">' . implode( '', $glance ) . '</div>'; } // phpcs:ignore
		// Phone only after the family approves.
		$ph = class_exists( 'MRSH_Members' ) ? MRSH_Members::phone_of( $id ) : '';
		$me = get_current_user_id();
		if ( $ph && (int) get_post_field( 'post_author', $id ) !== $me ) {
			$ps = ( $me && class_exists( 'MRSH_Members' ) ) ? MRSH_Members::phone_state( $id, $me ) : '';
			echo '<div class="box phone">' . mrt_icon( 'shield' ); // phpcs:ignore
			if ( 'yes' === $ps ) {
				echo ' <b>Phone:</b> <a href="tel:' . esc_attr( preg_replace( '/[^0-9+]/', '', $ph ) ) . '">' . esc_html( $ph ) . '</a> <span class="ml">Shared with you by the family.</span>';
			} elseif ( 'pending' === $ps ) {
				echo ' Phone number requested. Waiting for the family to answer.';
			} elseif ( 'no' === $ps ) {
				echo ' The family did not share the phone number.';
			} else {
				echo ' Phone number is private. <button type="button" class="btn line" data-act="phonereq" data-pid="' . (int) $id . '">Request phone number</button>';
			}
			echo '</div>';
		}
		?>
		<?php
		// Details grouped by the section titles of the profile form
		$open = false;
		$rows = '';
		$flush = function () use ( &$open, &$rows ) {
			if ( $open && '' !== $rows ) { echo $rows . '</dl></div>'; } // phpcs:ignore
			$open = false;
			$rows = '';
		};
		$head = 'Details';
		$fixed = class_exists( 'MRSH_Useful' ) ? MRSH_Useful::by_key( $id ) : null; // old saves can sit under shifted field numbers
		foreach ( mrt_fields() as $f ) {
			if ( 'title' === $f['type'] ) {
				$flush();
				$head = trim( $f['label'] ) ? $f['label'] : 'Details';
				continue;
			}
			if ( mrt_private( $f ) ) {
				continue;
			}
			$val = is_array( $fixed ) ? ( isset( $fixed[ $f['key'] ] ) ? $fixed[ $f['key'] ] : '' ) : get_post_meta( $id, $f['key'], true );
			$tx = class_exists( 'MRSH_Members' ) ? MRSH_Members::tax_for( $f['label'] ) : '';
			$tx = $tx ? $tx : ( 'taxonomy' === $f['type'] ? $f['tax'] : '' );
			if ( 'daage' === $f['key'] ) {
				$tx = ''; // the Age field is a number, never a taxonomy term
			}
			if ( $tx && taxonomy_exists( $tx ) ) {
				$names = wp_get_object_terms( $id, $tx, array( 'fields' => 'names' ) );
				if ( ! is_wp_error( $names ) && $names ) {
					$val = implode( ', ', $names );
				}
			}
			if ( is_array( $val ) ) { $val = implode( ', ', $val ); }
			$val = str_replace( '_', ' ', (string) $val );
			if ( 'daage' === $f['key'] && is_numeric( $val ) ) { $val .= ' years'; }
			if ( '' === trim( (string) $val ) ) { continue; }
			if ( ! $open ) {
				$open = true;
				$rows = '<div class="box b2"><h2>' . esc_html( $head ) . '</h2><dl class="dl">';
			}
			$st = mrt_field_style( $f['label'] );
			$rows .= '<dt><span class="ib ' . esc_attr( $st[1] ) . '">' . mrt_icon( $st[0] ) . '</span>' . esc_html( $f['label'] ) . '</dt><dd>' . esc_html( $val ) . '</dd>';
		}
		$flush();
		?>
		
		<p class="ml">Never send money to anyone you meet here. Meet with your family. <a href="<?php echo esc_url( home_url( '/rishta-safety-tips-avoid-fake-profiles-scams/' ) ); ?>">Safety tips</a></p>
	</div>
</div></div>
<?php
$gn  = class_exists( 'MRSH_Match' ) ? MRSH_Match::gender( $id ) : '';
$want = 'Male' === $gn ? 'Female' : ( 'Female' === $gn ? 'Male' : '' );
$sa  = array( 'post_type' => 'listing_type', 'posts_per_page' => 4, 'post__not_in' => array( $id ), 'no_found_rows' => true );
if ( $want ) { $sa['tax_query'] = array( array( 'taxonomy' => 'dagender', 'field' => 'name', 'terms' => $want ) ); }
$rl = taxonomy_exists( 'religion' ) ? wp_get_object_terms( $id, 'religion', array( 'fields' => 'ids', 'number' => 1 ) ) : array();
if ( $rl && ! is_wp_error( $rl ) ) { $sa['tax_query'][] = array( 'taxonomy' => 'religion', 'field' => 'term_id', 'terms' => $rl ); }
$sq = new WP_Query( $sa );
if ( $sq->have_posts() ) { echo '<div class="wrap"><h2 class="sec">More profiles you may like</h2><div class="grid">'; while ( $sq->have_posts() ) { $sq->the_post(); mrt_card(); } echo '</div></div>'; wp_reset_postdata(); }
?>
<?php do_action( 'mrt_profile_after', $id ); ?>
<div class="stick"><button type="button" class="btn" data-act="interest" data-pid="<?php echo (int) $id; ?>"><?php echo mrt_icon( 'heart' ); // phpcs:ignore ?>Send interest</button><button type="button" class="btn alt" data-act="msg" data-pid="<?php echo (int) $id; ?>"><?php echo mrt_icon( 'chat' ); // phpcs:ignore ?>Message</button></div>
</main>
	<?php
endwhile;
get_footer();
