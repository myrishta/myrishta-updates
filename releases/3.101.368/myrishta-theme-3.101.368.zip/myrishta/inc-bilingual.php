<?php
/**
 * English plus Urdu on every form label, heading, hint, placeholder and list choice.
 * mrt_bilingual( $html ) rewrites finished page HTML: it only touches text that exactly matches a known interface phrase,
 * so words written by members are never changed. Stored values stay English; only what the person reads changes.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Phrases for the Memberships, Blog, Contact pages and the footer. */
function mrt_bi_extra() {
	return array(
			'Not in the list? Choose Other and type it. It will be added for others too.' => 'فہرست میں نہیں؟ "دیگر" چنیں اور خود لکھیں۔ یہ دوسروں کے لیے بھی شامل ہو جائے گا۔',
			'Other (type it)' => 'دیگر (خود لکھیں)',
			'Like our guides? Choose us in Google and our articles show up more often for you.' => 'ہماری گائیڈز پسند ہیں؟ گوگل میں ہمیں چنیں، ہمارے مضامین آپ کو زیادہ نظر آئیں گے۔',
			'Email, username or mobile number' => 'ای میل، یوزر نیم یا موبائل نمبر',
			'Keep me logged in' => 'مجھے لاگ ان رکھیں',
			'I am looking for' => 'میں تلاش کر رہا/رہی ہوں',
			'Bride or groom' => 'دلہن یا دولہا',
			'Bride (Female)' => 'دلہن (خاتون)',
			'Groom (Male)' => 'دولہا (مرد)',
			'Membership' => 'رکنیت',
			'Mobile number' => 'موبائل نمبر',
			'(optional, lets you log in with it)' => '(اختیاری، اس سے لاگ ان ہو سکتا ہے)',
			'Free' => 'مفت',
			'Bronze' => 'برونز',
			'Silver' => 'سلور',
			'Gold' => 'گولڈ',
			'Best value' => 'بہترین قدر',
			'My profile' => 'میری پروفائل',
			'Choose Bronze' => 'برونز منتخب کریں',
			'Choose Silver' => 'سلور منتخب کریں',
			'Choose Gold' => 'گولڈ منتخب کریں',
			'Choose Free' => 'مفت منتخب کریں',
			'Create your profile' => 'اپنی پروفائل بنائیں',
			'Send interest and messages' => 'دلچسپی اور پیغامات بھیجیں',
			'Match suggestions' => 'مماثل رشتوں کی تجاویز',
			'Phone number stays private' => 'فون نمبر نجی رہتا ہے',
			'Everything in Free' => 'فری کی تمام سہولتیں',
			'Everything in Bronze' => 'برونز کی تمام سہولتیں',
			'Everything in Silver' => 'سلور کی تمام سہولتیں',
			'Bronze badge on your profile' => 'آپ کی پروفائل پر برونز بیج',
			'Silver badge' => 'سلور بیج',
			'Gold badge' => 'گولڈ بیج',
			'Priority verification' => 'ترجیحی تصدیق',
			'Shown higher in search' => 'تلاش میں اوپر نظر آئیں',
			'See who viewed you' => 'دیکھیں کس نے آپ کو دیکھا',
			'Featured on the home page' => 'ہوم پیج پر نمایاں',
			'Top of search results' => 'تلاش کے نتائج میں سب سے اوپر',
			'Free profile' => 'مفت پروفائل',
			'For yourself or, with consent, for a son, daughter, brother or sister.' => 'اپنے لیے، یا رضامندی سے بیٹے، بیٹی، بھائی یا بہن کے لیے۔',
			'Smart search' => 'سمارٹ تلاش',
			'Filter by age, city, education, profession, caste and more.' => 'عمر، شہر، تعلیم، پیشہ، ذات اور مزید سے تلاش کریں۔',
			'Match percentage' => 'مماثلت کی شرح',
			'We show how well a profile fits what you are looking for.' => 'ہم بتاتے ہیں کہ پروفائل آپ کی پسند سے کتنی ملتی ہے۔',
			'Safe messaging' => 'محفوظ پیغام رسانی',
			'Message members. Links and phone numbers are blocked for your safety.' => 'ممبران کو پیغام بھیجیں۔ آپ کی حفاظت کے لیے لنک اور فون نمبر بلاک ہیں۔',
			'Private phone number' => 'نجی فون نمبر',
			'Your number is shown only to people you approve.' => 'آپ کا نمبر صرف انہیں نظر آتا ہے جنہیں آپ منظور کریں۔',
			'Verified badge' => 'تصدیق شدہ بیج',
			'Ask our team to verify your profile and earn more trust.' => 'ہماری ٹیم سے اپنی پروفائل کی تصدیق کروائیں اور زیادہ اعتماد حاصل کریں۔',
			'Pay only through our official contact.' => 'ادائیگی صرف ہمارے سرکاری رابطے کے ذریعے کریں۔',
			'Paid badges are arranged by our team after you choose a plan. We never use agents. If someone asks you for money in our name, tap Report on their profile or contact us.' => 'پیڈ بیج پلان منتخب کرنے کے بعد ہماری ٹیم خود لگاتی ہے۔ ہم ایجنٹ استعمال نہیں کرتے۔ اگر کوئی ہمارے نام پر رقم مانگے تو اس کی پروفائل پر Report دبائیں یا ہم سے رابطہ کریں۔',
			'Launch offer' => 'لانچ آفر',
			'Free (launch offer)' => 'مفت (لانچ آفر)',
			'Launch offer: every plan is free, for at least the next 6 months.' => 'لانچ آفر: ہر پلان کم از کم اگلے 6 مہینے مفت ہے۔',
			'No payment is needed. If any paid option is ever introduced, we will announce it on this page first. We never use agents. If someone asks you for money in our name, tap Report on their profile or contact us.' => 'کوئی ادائیگی ضروری نہیں۔ اگر کبھی کوئی پیڈ آپشن شروع ہوا تو ہم پہلے اسی صفحے پر اعلان کریں گے۔ ہم ایجنٹ استعمال نہیں کرتے۔ اگر کوئی ہمارے نام پر رقم مانگے تو اس کی پروفائل پر رپورٹ دبائیں یا ہم سے رابطہ کریں۔',
			'Every plan is free for the next 6 months (launch offer).' => 'اگلے 6 مہینے ہر پلان مفت ہے (لانچ آفر)۔',
			'Free Membership' => 'مفت رکنیت',
			'MyRishta.pk is free for everyone. There are no paid plans, no hidden fees and no money-back guarantees to worry about, because nothing is sold.' => 'MyRishta.pk سب کے لیے مفت ہے۔ کوئی پیڈ پلان، چھپی ہوئی فیس یا رقم واپسی کی فکر نہیں، کیونکہ کچھ بیچا نہیں جاتا۔',
			'What you get for free' => 'مفت میں آپ کو کیا ملتا ہے',
			'Create a profile for yourself or a family member' => 'اپنے یا گھر کے کسی فرد کے لیے پروفائل بنائیں',
			'Search profiles using filters for age, city, education and more' => 'عمر، شہر، تعلیم وغیرہ کے فلٹر سے پروفائلز تلاش کریں',
			'Message other members' => 'دوسرے ممبران کو پیغام بھیجیں',
			'Edit or delete your profile at any time' => 'جب چاہیں پروفائل میں تبدیلی کریں یا حذف کریں',
			'Safety and rishta guides on our blog' => 'ہمارے بلاگ پر حفاظت اور رشتہ گائیڈز',
			'We may show advertisements to cover running costs. Read our' => 'اخراجات پورے کرنے کے لیے ہم اشتہارات دکھا سکتے ہیں۔ پڑھیں:',
			'Privacy Policy' => 'پرائیویسی پالیسی',
			'Terms and Conditions' => 'شرائط و ضوابط',
			'Create your free account' => 'اپنا مفت اکاؤنٹ بنائیں',
			'All' => 'سب',
			'Safety' => 'حفاظت',
			'City guide' => 'شہر کی گائیڈ',
			'Overseas Guide' => 'بیرونِ ملک گائیڈ',
			'Article' => 'مضمون',
			'Guide' => 'گائیڈ',
			'Read more' => 'مزید پڑھیں',
			'Rishta Blog' => 'رشتہ بلاگ',
			'Phone' => 'فون',
			'Office' => 'دفتر',
			'Chat with us' => 'ہم سے بات کریں',
			'Send a message' => 'پیغام بھیجیں',
			'Your name' => 'آپ کا نام',
			'Email' => 'ای میل',
			'Topic' => 'موضوع',
			'Profile name or ID (optional)' => 'پروفائل کا نام یا آئی ڈی (اختیاری)',
			'Message' => 'پیغام',
			'Send message' => 'پیغام بھیجیں',
			'Thank you. Your message was sent. We will reply by email.' => 'شکریہ۔ آپ کا پیغام بھیج دیا گیا۔ ہم ای میل پر جواب دیں گے۔',
			'Please enter your name, a valid email and a message of at least 10 characters.' => 'براہِ کرم اپنا نام، درست ای میل اور کم از کم 10 حروف کا پیغام لکھیں۔',
			'Too many messages from this device. Please try again later.' => 'اس ڈیوائس سے بہت زیادہ پیغامات۔ براہِ کرم بعد میں کوشش کریں۔',
			'Contact' => 'رابطہ',
			'Contact us' => 'ہم سے رابطہ کریں',
			'Information' => 'معلومات',
			'About us' => 'ہمارے بارے میں',
			'How it works' => 'یہ کیسے کام کرتا ہے',
			'FAQ' => 'عمومی سوالات',
			'Blog' => 'بلاگ',
			'Trust and legal' => 'اعتماد اور قانونی',
			'Terms' => 'شرائط',
			'Privacy' => 'پرائیویسی',
			'Safety tips' => 'حفاظتی مشورے',
			'Cookies' => 'کوکیز',
			'Disclaimer' => 'دستبرداری',
			'Badges' => 'بیجز',
			'Report misuse' => 'غلط استعمال کی رپورٹ',
			'Sitemap' => 'سائٹ میپ',
		);
}

require_once __DIR__ . '/inc-bilingual-caste.php';

function mrt_bi_option_extra() {
	return array_merge( mrt_bi_caste_extra(), array(
			'Question' => 'سوال',
			'Report a profile' => 'پروفائل رپورٹ کریں',
			'Problem with my account' => 'میرے اکاؤنٹ کا مسئلہ',
			'Verification' => 'تصدیق',
			'Delete my data' => 'میرا ڈیٹا حذف کریں',
			'Feedback' => 'رائے',
		) );
}

function mrt_bi_labels() {
	static $m = null;
	if ( null === $m ) {
		$m = array();
		foreach ( array_merge( mrt_bi_extra(), mrt_bi_settings_extra(), array(
			'I\'m a' => 'میں ہوں',
			'Looking for a' => 'تلاش',
			'Where are you located?' => 'آپ کہاں رہتے ہیں؟',
			'Your marital status' => 'آپ کی ازدواجی حیثیت',
			'Create a display name for your profile.' => 'پروفائل کا نام',
			'About Me' => 'میرے بارے میں',
			'My Interests' => 'میری دلچسپیاں',
			'Age' => 'عمر',
			'Profile Created by' => 'پروفائل کس نے بنایا',
			'Phone No' => 'فون نمبر',
			'Marital Status' => 'ازدواجی حیثیت',
			'Children' => 'بچے',
			'Children Satus' => 'بچوں کی رہائش',
			'Children\'s Status' => 'بچوں کی رہائش',
			'Religion' => 'مذہب',
			'Sect' => 'مسلک',
			'Caste' => 'ذات / برادری',
			'Nationalty' => 'قومیت',
			'Nationality' => 'قومیت',
			'Education' => 'تعلیم',
			'Occupation' => 'پیشہ / ملازمت',
			'Ethnicity' => 'نسلی گروہ',
			'My Eyes' => 'آنکھوں کا رنگ',
			'My Hair' => 'بالوں کا رنگ',
			'My Body' => 'جسامت',
			'Hair Length' => 'بالوں کی لمبائی',
			'Drinking' => 'شراب نوشی',
			'Smoking' => 'تمباکو نوشی',
			'What do I look like?' => 'میری شکل و صورت',
			'Education and Occupation' => 'تعلیم اور پیشہ',
			'My Habbits' => 'میری عادات',
			'My Habits' => 'میری عادات',
			'Female' => 'خاتون',
			'Male' => 'مرد',
			'Country' => 'ملک',
			'City' => 'شہر',
			'Full Address' => 'مکمل پتہ',
			'My Location' => 'میرا مقام',
			'Sexuality' => 'رجحان',
			'Update your profile' => 'اپنی پروفائل اپ ڈیٹ کریں',
			'Create your free profile' => 'اپنی مفت پروفائل بنائیں',
			'Keep it fresh. Complete profiles get many more replies.' => 'پروفائل تازہ رکھیں۔ مکمل پروفائل پر زیادہ جوابات ملتے ہیں۔',
			'Almost there. Tell us about yourself.' => 'بس تھوڑا باقی ہے۔ اپنے بارے میں بتائیں۔',
			'Join in three easy steps. Free, private and run by a non-profit.' => 'تین آسان مراحل میں شامل ہوں۔ مفت، نجی اور غیر منافع بخش۔',
			'Account' => 'اکاؤنٹ',
			'Details' => 'تفصیلات',
			'Photos' => 'تصاویر',
			'Photo' => 'تصویر',
			'First name (shown on your profile)' => 'پہلا نام (پروفائل پر نظر آئے گا)',
			'First name' => 'پہلا نام',
			'About you' => 'آپ کے بارے میں',
			'Religion and family' => 'مذہب اور خاندان',
			'Education and work' => 'تعلیم اور ملازمت',
			'Where you live' => 'آپ کہاں رہتے ہیں',
			'Contact (never shown to others)' => 'رابطہ (دوسروں کو کبھی نظر نہیں آتا)',
			'More details' => 'مزید تفصیلات',
			'Your story' => 'آپ کی کہانی',
			'Detect my country and city' => 'میرا ملک اور شہر تلاش کریں',
			'We only fill the fields. Check them before saving.' => 'ہم صرف خانے بھرتے ہیں۔ محفوظ کرنے سے پہلے دیکھ لیں۔',
			'City / Town / Village' => 'شہر / قصبہ / گاؤں',
			'Select' => 'منتخب کریں',
			'Select country' => 'ملک منتخب کریں',
			'Choose from the list or type your city or village' => 'فہرست سے چنیں یا اپنا شہر / گاؤں لکھیں',
			'Choose from the list or type your caste' => 'فہرست سے چنیں یا اپنی ذات لکھیں',
			'Not in the list? Type it. It will be added for others too.' => 'فہرست میں نہیں؟ خود لکھ دیں، دوسروں کے لیے بھی شامل ہو جائے گا۔',
			'03XX XXXXXXX (never shown publicly)' => '03XX XXXXXXX (عوام کو کبھی نظر نہیں آتا)',
			'About you and the partner you are looking for (no phone numbers or links)' => 'اپنے اور مطلوبہ رشتے کے بارے میں لکھیں (فون نمبر یا لنک نہیں)',
			'Optional but recommended. JPG, PNG or WebP, up to 6 MB each.' => 'اختیاری مگر بہتر۔ JPG، PNG یا WebP، ہر ایک 6 MB تک۔',
			'Main photo' => 'مرکزی تصویر',
			'Photo 2' => 'تصویر 2',
			'Photo 3' => 'تصویر 3',
			'Drag a photo here or click' => 'تصویر یہاں کھینچیں یا کلک کریں',
			'Save changes' => 'تبدیلیاں محفوظ کریں',
			'Create profile' => 'پروفائل بنائیں',
			'Please fix:' => 'براہِ کرم درست کریں:',
			'Choose your membership' => 'اپنی رکنیت منتخب کریں',
			'Your name' => 'آپ کا نام',
			'Email' => 'ای میل',
			'Password' => 'پاسورڈ',
			'Phone number' => 'فون نمبر',
			'Gender' => 'جنس',
			'Height' => 'قد',
			'Weight' => 'وزن',
			'Complexion' => 'رنگت',
			'Build' => 'جسامت',
			'Mother tongue' => 'مادری زبان',
			'Language' => 'زبان',
			'Languages' => 'زبانیں',
			'Income' => 'آمدنی',
			'Profession' => 'پیشہ',
			'Job' => 'ملازمت',
			'State / Province' => 'صوبہ',
			'State' => 'صوبہ',
			'Province' => 'صوبہ',
			'Area' => 'علاقہ',
			'Address' => 'پتہ',
			'Own house' => 'ذاتی مکان',
			'Father' => 'والد',
			'Mother' => 'والدہ',
			'Siblings' => 'بہن بھائی',
			'Brothers' => 'بھائی',
			'Sisters' => 'بہنیں',
			'Family type' => 'خاندان کی قسم',
			'Family' => 'خاندان',
			'Profile created by' => 'پروفائل کس نے بنایا',
			'Phone no' => 'فون نمبر',
			'Mobile' => 'موبائل',
			'WhatsApp' => 'واٹس ایپ',
			'Interests' => 'دلچسپیاں',
			'Habits' => 'عادات',
			'Looking for' => 'تلاش',
		) ) as $k => $v ) {
			$m[ strtolower( $k ) ] = $v;
		}
	}
	return $m;
}

function mrt_bi_options() {
	static $m = null;
	if ( null === $m ) {
		$m = array();
		foreach ( array_merge( mrt_bi_option_extra(), array(
			'Prefer to not Say' => 'بتانا نہیں چاہتے',
			'Prefer to not say' => 'بتانا نہیں چاہتے',
			'Prefer not to say' => 'بتانا نہیں چاہتے',
			'Divorced' => 'طلاق یافتہ',
			'Married' => 'شادی شدہ',
			'Separated' => 'علیحدہ',
			'Unmarried' => 'غیر شادی شدہ',
			'Widowed' => 'بیوہ / رنڈوا',
			'None' => 'کوئی نہیں',
			'1' => '1',
			'2' => '2',
			'3 or Above' => '3 یا زیادہ',
			'Staying with me' => 'میرے ساتھ',
			'Staying With Mother' => 'والدہ کے ساتھ',
			'Staying With Father' => 'والد کے ساتھ',
			'Staying Separate' => 'علیحدہ رہتے ہیں',
			'Staying With Grandparents' => 'دادا دادی/نانا نانی کے ساتھ',
			'Self' => 'خود',
			'Parents' => 'والدین',
			'Sibling' => 'بہن بھائی',
			'Relative' => 'رشتہ دار',
			'Friend' => 'دوست',
			'Guardian' => 'سرپرست',
			'Muslims-Islam' => 'اسلام (مسلمان)',
			'Christianity' => 'عیسائیت',
			'Hinduism' => 'ہندو مت',
			'Sikhism' => 'سکھ مت',
			'Buddhism' => 'بدھ مت',
			'Judaism' => 'یہودیت',
			'Jainism' => 'جین مت',
			'Zoroastrianism' => 'زرتشت',
			'Others' => 'دیگر',
			'Other' => 'دیگر',
			'Suni' => 'سنی',
			'Sunni' => 'سنی',
			'Barelvi' => 'بریلوی',
			'Deobandi' => 'دیوبندی',
			'Al Hadees' => 'اہلِ حدیث',
			'Shia' => 'شیعہ',
			'Ismaili' => 'اسماعیلی',
			'Sufi' => 'صوفی',
			'Just Muslim' => 'صرف مسلمان',
			'Religious' => 'دیندار',
			'Primary (1-7)' => 'پرائمری (1-7)',
			'Middle (8-10)' => 'مڈل (8-10)',
			'Matric (10)' => 'میٹرک (10)',
			'O-Levels' => 'او لیول',
			'FA,FSe,ICS,ICom,DBA,D.Com.etc' => 'ایف اے، ایف ایس سی، آئی سی ایس، آئی کام',
			'Intermediate (FA / FSc / ICS / ICom)' => 'انٹرمیڈیٹ (ایف اے / ایف ایس سی / آئی سی ایس / آئی کام)',
			'A-Levels' => 'اے لیول',
			'Diploma (DAE / Technical)' => 'ڈپلومہ (ڈی اے ای / ٹیکنیکل)',
			'Certificate / Vocational Training' => 'سرٹیفکیٹ / ہنر مندی',
			'BA/BSC ADE Associate Degree' => 'بی اے / بی ایس سی / اے ڈی ای',
			'Bachelor Degree' => 'بیچلر ڈگری',
			'BA / BSc (2 years)' => 'بی اے / بی ایس سی (2 سال)',
			'BS (4 years)' => 'بی ایس (4 سال)',
			'BBA' => 'بی بی اے',
			'BCom' => 'بی کام',
			'BSc Engineering' => 'بی ایس سی انجینئرنگ',
			'BE / BTech' => 'بی ای / بی ٹیک',
			'MBBS' => 'ایم بی بی ایس',
			'BDS' => 'بی ڈی ایس',
			'Pharm-D' => 'فارم ڈی',
			'DPT (Physiotherapy)' => 'ڈی پی ٹی (فزیوتھراپی)',
			'BSc Nursing' => 'بی ایس سی نرسنگ',
			'LLB' => 'ایل ایل بی',
			'BEd' => 'بی ایڈ',
			'BSc Agriculture' => 'بی ایس سی زراعت',
			'BCS / BSCS / BSIT' => 'بی سی ایس / بی ایس سی ایس / بی ایس آئی ٹی',
			'Master Degree' => 'ماسٹر ڈگری',
			'MA' => 'ایم اے',
			'MSc' => 'ایم ایس سی',
			'MBA' => 'ایم بی اے',
			'MCom' => 'ایم کام',
			'MPhil / MS' => 'ایم فل / ایم ایس',
			'LLM' => 'ایل ایل ایم',
			'MEd' => 'ایم ایڈ',
			'MSc Engineering' => 'ایم ایس سی انجینئرنگ',
			'Doctoral Degree' => 'ڈاکٹریٹ',
			'PhD' => 'پی ایچ ڈی',
			'FCPS / MD' => 'ایف سی پی ایس / ایم ڈی',
			'CA / ACCA / CFA' => 'سی اے / اے سی سی اے / سی ایف اے',
			'Hafiz-e-Quran' => 'حافظِ قرآن',
			'Dars-e-Nizami / Aalim / Mufti' => 'درسِ نظامی / عالم / مفتی',
			'Religious education' => 'دینی تعلیم',
			'No formal education' => 'رسمی تعلیم نہیں',
			'Government Employee' => 'سرکاری ملازم',
			'Private Sector Employee' => 'پرائیویٹ ملازم',
			'Semi-Government / Autonomous Body' => 'نیم سرکاری / خودمختار ادارہ',
			'Doctor' => 'ڈاکٹر',
			'Surgeon' => 'سرجن',
			'Dentist' => 'ڈینٹسٹ',
			'Pharmacist' => 'فارماسسٹ',
			'Nurse' => 'نرس',
			'Medical / Lab Technician' => 'میڈیکل / لیب ٹیکنیشن',
			'Physiotherapist' => 'فزیوتھراپسٹ',
			'Software Engineer / Developer' => 'سافٹ ویئر انجینئر / ڈویلپر',
			'IT Professional' => 'آئی ٹی پروفیشنل',
			'Civil Engineer' => 'سول انجینئر',
			'Electrical Engineer' => 'الیکٹریکل انجینئر',
			'Mechanical Engineer' => 'مکینیکل انجینئر',
			'Other Engineer' => 'دیگر انجینئر',
			'Architect' => 'آرکیٹیکٹ',
			'Teacher' => 'استاد / ٹیچر',
			'Lecturer / Professor' => 'لیکچرار / پروفیسر',
			'Principal / Education Manager' => 'پرنسپل / ایجوکیشن مینیجر',
			'Lawyer / Advocate' => 'وکیل',
			'Judge' => 'جج',
			'Accountant' => 'اکاؤنٹنٹ',
			'Chartered Accountant' => 'چارٹرڈ اکاؤنٹنٹ',
			'Banker' => 'بینکر',
			'Finance Professional' => 'فنانس پروفیشنل',
			'Business Owner' => 'کاروباری',
			'Shopkeeper / Trader' => 'دکاندار / تاجر',
			'Farmer / Landowner' => 'کسان / زمیندار',
			'Army Officer' => 'آرمی آفیسر',
			'Army Soldier / JCO' => 'فوجی / جے سی او',
			'Navy' => 'نیوی',
			'Air Force' => 'ایئر فورس',
			'Police Officer' => 'پولیس آفیسر',
			'Civil Servant (CSS / PMS)' => 'سول سرونٹ (سی ایس ایس / پی ایم ایس)',
			'Pilot' => 'پائلٹ',
			'Cabin Crew' => 'کیبن کریو',
			'Journalist / Media' => 'صحافی / میڈیا',
			'Designer / Artist' => 'ڈیزائنر / آرٹسٹ',
			'Fashion Designer' => 'فیشن ڈیزائنر',
			'Interior Designer' => 'انٹیریئر ڈیزائنر',
			'Photographer' => 'فوٹوگرافر',
			'Chef / Hotel Industry' => 'شیف / ہوٹل انڈسٹری',
			'Driver' => 'ڈرائیور',
			'Electrician / Technician' => 'الیکٹریشن / ٹیکنیشن',
			'Mechanic' => 'مکینک',
			'Tailor' => 'درزی',
			'Beauty / Salon Professional' => 'بیوٹی / سیلون',
			'Marketing / Sales' => 'مارکیٹنگ / سیلز',
			'Manager' => 'مینیجر',
			'Freelancer' => 'فری لانسر',
			'Self Employed' => 'ذاتی کام',
			'Overseas Worker (Gulf)' => 'بیرونِ ملک ملازم (خلیج)',
			'Researcher / Scientist' => 'محقق / سائنسدان',
			'Imam / Religious Scholar' => 'امام / عالمِ دین',
			'Hafiz / Quran Teacher' => 'حافظ / قاری',
			'Social Worker / NGO' => 'سماجی کارکن / این جی او',
			'Student' => 'طالب علم',
			'Housewife / Homemaker' => 'گھریلو خاتون',
			'Retired' => 'ریٹائرڈ',
			'No Job' => 'بے روزگار',
			'Pakistani' => 'پاکستانی',
			'Punjabi' => 'پنجابی',
			'Sindhi' => 'سندھی',
			'Pashtun / Pathan' => 'پشتون / پٹھان',
			'Baloch' => 'بلوچ',
			'Muhajir' => 'مہاجر',
			'Kashmiri' => 'کشمیری',
			'Saraiki' => 'سرائیکی',
			'Hindko' => 'ہندکو',
			'Chitrali' => 'چترالی',
			'Gilgiti / Baltistani' => 'گلگتی / بلتستانی',
			'Hazara' => 'ہزارہ',
			'Brahui' => 'براہوی',
			'Memon' => 'میمن',
			'Bengali' => 'بنگالی',
			'Arab' => 'عرب',
			'Asian' => 'ایشیائی',
			'Indian' => 'ہندوستانی',
			'American' => 'امریکی',
			'European' => 'یورپی',
			'African' => 'افریقی',
			'Persian' => 'ایرانی',
			'Turkish' => 'ترک',
			'Mixed' => 'مخلوط',
			'Amber' => 'عنبری',
			'Black' => 'کالا',
			'Blue' => 'نیلا',
			'Brown' => 'بھورا',
			'Gray' => 'سرمئی',
			'Green' => 'سبز',
			'Hazel' => 'ہیزل',
			'Blond' => 'سنہرا',
			'Red' => 'سرخ',
			'A little plump' => 'تھوڑا بھرا ہوا',
			'Athletic' => 'ورزشی',
			'Average' => 'درمیانہ',
			'Big and lovely' => 'بھرپور',
			'Muscular' => 'مضبوط',
			'Slim' => 'سمارٹ',
			'Bald' => 'گنجا',
			'Long' => 'لمبے',
			'Medium' => 'درمیانے',
			'Shaved Head' => 'منڈھا ہوا سر',
			'Short' => 'چھوٹے',
			'Very Long' => 'بہت لمبے',
			'Never' => 'کبھی نہیں',
			'Often' => 'اکثر',
			'Quit' => 'چھوڑ دیا',
			'Rarely' => 'شاذ و نادر',
			'Socially' => 'کبھی کبھار',
			'Very often' => 'بہت اکثر',
			'Straight' => 'عام',
			'Pakistan' => 'پاکستان',
			'Afghan' => 'افغان',
			'Bangladeshi' => 'بنگلہ دیشی',
			'British' => 'برطانوی',
			'Canadian' => 'کینیڈین',
			'Saudi' => 'سعودی',
			'Emirati' => 'اماراتی',
			'Australian' => 'آسٹریلوی',
			'German' => 'جرمن',
			'Iranian' => 'ایرانی',
			'Qatari' => 'قطری',
			'Kuwaiti' => 'کویتی',
			'Omani' => 'عمانی',
			'Bahraini' => 'بحرینی',
			'Malaysian' => 'ملائیشین',
			'Chinese' => 'چینی',
			'Norwegian' => 'ناروے',
			'Swedish' => 'سویڈش',
			'Danish' => 'ڈنمارک',
			'French' => 'فرانسیسی',
			'Italian' => 'اطالوی',
			'Spanish' => 'ہسپانوی',
			'Dutch' => 'ڈچ',
			'Irish' => 'آئرش',
			'Egyptian' => 'مصری',
			'Jordanian' => 'اردنی',
			'Iraqi' => 'عراقی',
			'Sri Lankan' => 'سری لنکن',
			'Nepalese' => 'نیپالی',
			'Abbasi' => 'عباسی',
			'Abidi' => 'عابدی',
			'Abro' => 'ابڑو',
			'Achakzai' => 'اچکزئی',
			'Afridi' => 'آفریدی',
			'Agha' => 'آغا',
			'Alizai' => 'علیزئی',
			'Alvi' => 'علوی',
			'Ansari' => 'انصاری',
			'Arain' => 'آرائیں',
			'Askari' => 'عسکری',
			'Aulakh' => 'اولکھ',
			'Awan' => 'اعوان',
			'Bajwa' => 'باجوہ',
			'Bangash' => 'بنگش',
			'Baig' => 'بیگ',
			'Bhatti' => 'بھٹی',
			'Bhutto' => 'بھٹو',
			'Bhat' => 'بھٹ',
			'Bokhari' => 'بخاری',
			'Bukhari' => 'بخاری',
			'Bugti' => 'بگٹی',
			'Butt' => 'بٹ',
			'Chaudhry' => 'چوہدری',
			'Cheema' => 'چیمہ',
			'Chishti' => 'چشتی',
			'Dar' => 'ڈار',
			'Dogar' => 'ڈوگر',
			'Durrani' => 'درانی',
			'Farooqi' => 'فاروقی',
			'Gakhar' => 'گکھڑ',
			'Gardezi' => 'گردیزی',
			'Ghumman' => 'گھمن',
			'Gilani' => 'گیلانی',
			'Gill' => 'گل',
			'Gondal' => 'گوندل',
			'Gujjar' => 'گجر',
			'Hashmi' => 'ہاشمی',
			'Hussaini' => 'حسینی',
			'Jadoon' => 'جدون',
			'Jafri' => 'جعفری',
			'Janjua' => 'جنجوعہ',
			'Jatoi' => 'جتوئی',
			'Jatt' => 'جٹ',
			'Junejo' => 'جونیجو',
			'Kakar' => 'کاکڑ',
			'Kamboh' => 'کمبوہ',
			'Kazmi' => 'کاظمی',
			'Khan' => 'خان',
			'Kharal' => 'کھرل',
			'Khattak' => 'خٹک',
			'Khokhar' => 'کھوکھر',
			'Khosa' => 'کھوسہ',
			'Lashari' => 'لاشاری',
			'Leghari' => 'لغاری',
			'Lodhi' => 'لودھی',
			'Lone' => 'لون',
			'Mahar' => 'مہر',
			'Malik' => 'ملک',
			'Marri' => 'مری',
			'Mazari' => 'مزاری',
			'Mehsud' => 'محسود',
			'Mengal' => 'مینگل',
			'Mian' => 'میاں',
			'Minhas' => 'منہاس',
			'Mir' => 'میر',
			'Mirza' => 'مرزا',
			'Mohmand' => 'مہمند',
			'Mughal' => 'مغل',
			'Naqvi' => 'نقوی',
			'Niazi' => 'نیازی',
			'Noon' => 'نون',
			'Orakzai' => 'اورکزئی',
			'Pathan' => 'پٹھان',
			'Pirzada' => 'پیرزادہ',
			'Qazi' => 'قاضی',
			'Qureshi' => 'قریشی',
			'Raisani' => 'رئیسانی',
			'Rajput' => 'راجپوت',
			'Rana' => 'رانا',
			'Randhawa' => 'رندھاوا',
			'Rind' => 'رند',
			'Rizvi' => 'رضوی',
			'Sandhu' => 'سندھو',
			'Shah' => 'شاہ',
			'Sheikh' => 'شیخ',
			'Shinwari' => 'شنواری',
			'Siddiqui' => 'صدیقی',
			'Sial' => 'سیال',
			'Soomro' => 'سومرو',
			'Swati' => 'سواتی',
			'Syed' => 'سید',
			'Sayyid' => 'سید',
			'Talpur' => 'تالپور',
			'Tanoli' => 'تنولی',
			'Tarar' => 'تارڑ',
			'Tareen' => 'ترین',
			'Tiwana' => 'ٹوانہ',
			'Usmani' => 'عثمانی',
			'Virk' => 'ورک',
			'Wani' => 'وانی',
			'Warraich' => 'وڑائچ',
			'Wattoo' => 'واٹو',
			'Wazir' => 'وزیر',
			'Yousafzai' => 'یوسفزئی',
			'Zaidi' => 'زیدی',
			'Zardari' => 'زرداری',
			'Zehri' => 'زہری',
			'Bohra' => 'بوہرہ',
			'Khoja' => 'خوجہ',
			'Balti' => 'بلتی',
			'Burusho' => 'بروشو',
			'Hunzai' => 'ہنزائی',
			'Dehlvi' => 'دہلوی',
			'Bhutta' => 'بھٹہ',
			'Brohi' => 'بروہی',
			'Chandio' => 'چانڈیو',
			'Mallah' => 'ملاح',
			'Magsi' => 'مگسی',
		) ) as $k => $v ) {
			$m[ strtolower( $k ) ] = $v;
		}
	}
	return $m;
}

/** Urdu for an English interface phrase, or ''. */
function mrt_bi_find( $en, $options = false ) {
	$k = strtolower( trim( preg_replace( '/\s+/', ' ', html_entity_decode( $en, ENT_QUOTES, 'UTF-8' ) ) ) );
	if ( preg_match( '/^(\d+) min read$/', $k, $mm ) ) {
		return $mm[1] . ' منٹ کا مطالعہ';
	}
	if ( false !== strpos( $k, 'phone numbers are private. contact only through the website.' ) ) {
		return 'فون نمبر نجی ہیں۔ رابطہ صرف ویب سائٹ کے ذریعے۔';
	}
	$l = mrt_bi_labels();
	if ( $options ) {
		$o = mrt_bi_options();
		return $o[ $k ] ?? ( $l[ $k ] ?? '' );
	}
	return $l[ $k ] ?? '';
}

function mrt_bilingual( $html ) {
	if ( '' === $html || ! preg_match( '/<form|<label|<h[1-3]|<li/i', $html ) ) {
		return $html;
	}
	// Only the page body is changed, never the head (title, meta, scripts).
	$cut  = stripos( $html, '<body' );
	$head = false === $cut ? '' : substr( $html, 0, $cut );
	$html = false === $cut ? $html : substr( $html, $cut );
	// 1. Choices in lists: the value stays English, the words show both.
	$html = preg_replace_callback(
		'#<option([^>]*)>([^<]*)</option>#',
		function ( $m ) {
			$txt = trim( html_entity_decode( $m[2], ENT_QUOTES, 'UTF-8' ) );
			if ( '' === $txt || preg_match( '/\p{Arabic}/u', $txt ) ) {
				return $m[0];
			}
			$ur = mrt_bi_find( $txt, true );
			if ( '' === $ur ) {
				return $m[0];
			}
			$attrs = $m[1];
			if ( false === strpos( $attrs, 'value=' ) ) {
				$attrs .= ' value="' . esc_attr( $txt ) . '"';
			}
			return '<option' . $attrs . '>' . esc_html( $txt . '  —  ' . $ur ) . '</option>';
		},
		$html
	);
	// 2. Placeholders.
	$html = preg_replace_callback(
		'#\splaceholder="([^"]*)"#',
		function ( $m ) {
			$txt = html_entity_decode( $m[1], ENT_QUOTES, 'UTF-8' );
			$ur  = preg_match( '/\p{Arabic}/u', $txt ) ? '' : mrt_bi_find( $txt );
			return ( '' === $ur || strlen( $txt ) > 30 ) ? $m[0] : ' placeholder="' . esc_attr( $txt . ' / ' . $ur ) . '"';
		},
		$html
	);
	// 3. Text between tags (skips scripts, styles, text areas, list choices and anything already in Urdu).
	$parts = preg_split( '#(<script\b.*?</script>|<style\b.*?</style>|<textarea\b.*?</textarea>|<option\b[^>]*>[^<]*(?:</option>)?|<span class="bdg">.*?</span>|<header\b.*?</header>|<nav\b.*?</nav>)#is', $html, -1, PREG_SPLIT_DELIM_CAPTURE );
	foreach ( $parts as $i => $p ) {
		if ( 0 === ( $i & 1 ) && false !== strpos( $p, '>' ) ) {
			$parts[ $i ] = preg_replace_callback(
				'#>([^<>]+)(?=<(?!span class="bu))#',
				function ( $m ) {
					$raw = $m[1];
					$t   = trim( $raw );
					if ( '' === $t || strlen( $t ) > 400 || preg_match( '/\p{Arabic}/u', $t ) ) {
						return $m[0];
					}
					$suffix = '';
					if ( preg_match( '/^(.*?)(\s*[*:])$/u', $t, $sm ) ) {
						$t      = $sm[1];
						$suffix = $sm[2];
					}
					$ur = mrt_bi_find( $t );
					if ( '' === $ur ) {
						return $m[0];
					}
					$lead  = preg_match( '/^\s+/', $raw, $a ) ? $a[0] : '';
					$trail = preg_match( '/\s+$/', $raw, $b ) ? $b[0] : '';
					if ( strlen( $t ) > 38 ) { // long sentences: Urdu on its own line
						return '>' . $lead . $t . $suffix . '<span class="bu bl" lang="ur" dir="rtl">' . esc_html( $ur ) . '</span>' . $trail;
					}
					return '>' . $lead . $t . ' / <span class="bu" lang="ur" dir="rtl">' . esc_html( $ur ) . '</span>' . $suffix . $trail;
				},
				$p
			);
		}
	}
	return $head . implode( '', $parts );
}

/** Whole front-end pages get English plus Urdu. Any problem returns the page untouched. */
function mrt_bilingual_page( $html ) {
	if ( ! is_string( $html ) || false === stripos( $html, '<body' ) ) {
		return $html;
	}
	try {
		$out = mrt_bilingual( $html );
	} catch ( \Throwable $e ) {
		return $html;
	}
	return ( is_string( $out ) && '' !== $out ) ? $out : $html;
}

add_action(
	'template_redirect',
	function () {
		if ( is_admin() || wp_doing_ajax() || is_feed() || is_robots() || is_trackback() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ( function_exists( 'mrt_site' ) && '0' === (string) mrt_site( 'bilingual', 1 ) ) ) {
			return;
		}
		ob_start( 'mrt_bilingual_page' );
	},
	0
);
