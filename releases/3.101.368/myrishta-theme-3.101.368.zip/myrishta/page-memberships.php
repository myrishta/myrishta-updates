<?php
/* Template Name: Memberships */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
mrt_page_hero( 'Membership', 'Simple, honest and free for Pakistani families.', 'star', 'Membership' );
$pl = mrt_plans();
$cta = mrt_cta();
$hotn = mrt_plan_hot();
$is_hot = function ( $i, $p ) use ( $pl, $hotn ) { return '' !== $hotn ? 0 === strcasecmp( $p[0], $hotn ) : ( ( $i === count( $pl ) - 1 && count( $pl ) > 2 ) || 1 === count( $pl ) ); };
?>
<main class="pg"><div class="wrap">
	<div class="plans big<?php echo count( $pl ) < 2 ? ' one' : ''; ?>">
	<?php foreach ( $pl as $i => $p ) : ?>
		<div class="plan<?php echo $is_hot( $i, $p ) ? ' hot' : ''; ?>"<?php echo $p[3] ? ' style="--pc:' . esc_attr( $p[3] ) . '"' : ''; // phpcs:ignore ?>>
			<?php if ( $is_hot( $i, $p ) ) : ?><span class="ribbon"><?php echo 1 === count( $pl ) ? 'For everyone' : ( '' !== $hotn ? 'Most popular' : ( get_option( 'mrsh_plans_free', 0 ) ? 'Launch offer' : 'Best value' ) ); ?></span><?php endif; ?>
			<b><?php echo esc_html( $p[0] ); ?></b><span class="pc"><?php echo esc_html( $p[1] ); ?></span>
			<ul><?php foreach ( $p[2] as $ft ) { echo '<li>' . esc_html( $ft ) . '</li>'; } ?></ul>
			<?php do_action( 'mrt_plan_pay', $p, $i ); ?>
			<a class="btn<?php echo $is_hot( $i, $p ) ? '' : ' line'; ?>" href="<?php echo esc_url( is_user_logged_in() ? add_query_arg( array( 'tab' => 'home', 'plan' => $p[0] ), mrt_link( 'myaccount', '/my-account/' ) ) . '#mrt-plan' : $cta[1] ); ?>"><?php echo esc_html( 0 === $i ? ( 'Add profile' === $cta[0] ? 'Get started free' : 'My profile' ) : 'Choose ' . $p[0] ); ?></a>
		</div>
	<?php endforeach; ?>
	</div>
	<?php $pay = trim( (string) mrt_site( 'payinfo', '' ) ); if ( $pay && count( $pl ) > 1 && ! get_option( 'mrsh_plans_free', 0 ) ) : ?><div class="note2"><?php echo mrt_icon( 'phone' ); // phpcs:ignore ?><div><b>How to pay for a paid plan</b><br><?php echo nl2br( esc_html( $pay ) ); ?><br>Then tell us your name and plan on the <a href="<?php echo esc_url( mrt_link( 'contact', '/contact/' ) ); ?>">Contact page</a>. We assign your badge after we receive it.</div></div><?php endif; ?>
	<h2 class="sec">Everything you get</h2>
	<div class="feats">
		<?php
		$fe = array(
			array( 'user', 'Free profile', 'For yourself or, with consent, for a son, daughter, brother or sister.', 'b1' ),
			array( 'search', 'Smart search', 'Filter by age, city, education, profession, caste and more.', 'b2' ),
			array( 'heart', 'Match percentage', 'We show how well a profile fits what you are looking for.', 'b3' ),
			array( 'chat', 'Safe messaging', 'Message members. Links and phone numbers are blocked for your safety.', 'b4' ),
			array( 'shield', 'Private phone number', 'Your number is shown only to people you approve.', 'b5' ),
			array( 'star', 'Verified badge', 'Ask our team to verify your profile and earn more trust.', 'b6' ),
		);
		foreach ( $fe as $f ) {
			echo '<div class="feat"><span class="ib ' . esc_attr( $f[3] ) . '">' . mrt_icon( $f[0] ) . '</span><b>' . esc_html( $f[1] ) . '</b><p>' . esc_html( $f[2] ) . '</p></div>'; // phpcs:ignore
		}
		?>
	</div>
	<?php if ( get_option( 'mrsh_plans_free', 0 ) ) : ?><div class="note2"><?php echo mrt_icon( 'star' ); // phpcs:ignore ?><div><b>Launch offer: every plan is free, for at least the next 6 months.</b> No payment is needed. If any paid option is ever introduced, we will announce it on this page first. We never use agents. If someone asks you for money in our name, tap Report on their profile or <a href="<?php echo esc_url( mrt_link( 'contact', '/contact/' ) ); ?>">contact us</a>.</div></div><?php else : ?><div class="note2"><?php echo mrt_icon( 'shield' ); // phpcs:ignore ?><div><b>Pay only through our official contact.</b> Paid badges are arranged by our team after you choose a plan. We never use agents. If someone asks you for money in our name, tap Report on their profile or <a href="<?php echo esc_url( mrt_link( 'contact', '/contact/' ) ); ?>">contact us</a>.</div></div><?php endif; ?>
	<?php while ( have_posts() ) : the_post(); if ( trim( wp_strip_all_tags( get_the_content() ) ) ) : ?>
		<article class="entry card2"><?php the_content(); ?></article>
	<?php endif; endwhile; ?>
</div></main>
<?php get_footer();
