<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
$sort = isset( $_GET['sort'] ) ? sanitize_key( $_GET['sort'] ) : ''; // phpcs:ignore
$chips = array();
foreach ( mrt_filters() as $k => $label ) {
	if ( ! empty( $_GET[ $k ] ) ) { // phpcs:ignore
		$slug = sanitize_title( wp_unslash( $_GET[ $k ] ) ); // phpcs:ignore
		$t    = get_term_by( 'slug', $slug, substr( $k, 4 ) );
		$chips[] = array( $label . ': ' . ( $t ? $t->name : $slug ), remove_query_arg( $k ) );
	}
}
if ( ! empty( $_GET['age_min'] ) || ! empty( $_GET['age_max'] ) ) { // phpcs:ignore
	$chips[] = array( 'Age ' . absint( $_GET['age_min'] ?? 18 ) . '-' . absint( $_GET['age_max'] ?? 99 ), remove_query_arg( array( 'age_min', 'age_max' ) ) ); // phpcs:ignore
}
?>
<main><div class="wrap">
	<div class="shead"><h1 style="font-size:1.8rem;margin:0">Find a rishta</h1>
	<?php if ( have_posts() ) : ?><span class="ml"><?php echo esc_html( number_format_i18n( $wp_query->found_posts ) ); ?> profiles</span><?php endif; ?></div>
	<details class="filters" <?php echo $chips ? '' : 'open'; ?>><summary><?php echo mrt_icon( 'search' ); // phpcs:ignore ?>Filters</summary><?php mrt_search_form(); ?></details>
	<?php if ( $chips ) : ?><div class="row act"><?php foreach ( $chips as $c ) { echo '<a class="chip on" href="' . esc_url( $c[1] ) . '">' . esc_html( $c[0] ) . ' ×</a>'; } ?><a class="chip" href="<?php echo esc_url( home_url( '/?post_type=listing_type&s=' ) ); ?>">Clear all</a></div><?php endif; ?>
	<div class="row sortrow"><a class="chip<?php echo ! empty( $_GET['photo'] ) ? ' on' : ''; // phpcs:ignore ?>" href="<?php echo esc_url( ! empty( $_GET['photo'] ) ? remove_query_arg( 'photo' ) : add_query_arg( 'photo', 1 ) ); // phpcs:ignore ?>">With photo</a><a class="chip<?php echo ! empty( $_GET['verified'] ) ? ' on' : ''; // phpcs:ignore ?>" href="<?php echo esc_url( ! empty( $_GET['verified'] ) ? remove_query_arg( 'verified' ) : add_query_arg( 'verified', 1 ) ); // phpcs:ignore ?>">Verified</a><button type="button" class="chip" data-save="1">Save this search</button><span class="ml">&nbsp;Sort:</span>
		<?php foreach ( array( '' => 'Newest', 'pop' => 'Popular', 'young' => 'Youngest', 'old' => 'Oldest' ) as $k => $l ) { echo '<a class="chip' . ( $sort === $k ? ' on' : '' ) . '" href="' . esc_url( $k ? add_query_arg( 'sort', $k ) : remove_query_arg( 'sort' ) ) . '">' . esc_html( $l ) . '</a>'; } ?></div>
	<?php if ( mrt_must_login() ) : ?>
		<div class="note" style="margin-top:20px"><p>Please log in or create a free account to see profiles.</p><a class="btn" href="<?php echo esc_url( mrt_login_url() ); ?>">Login / Register</a></div>
	<?php elseif ( have_posts() ) : ?>
		<div class="grid">
		<?php while ( have_posts() ) : the_post(); ?>
			<?php 'listing_type' === get_post_type() ? mrt_card() : null; ?>
		<?php endwhile; ?>
		</div>
		<div class="pager"><?php echo wp_kses_post( paginate_links( array( 'type' => 'plain', 'prev_text' => '&laquo;', 'next_text' => '&raquo;' ) ) ); ?></div>
	<?php else : ?>
		<div class="note" style="margin-top:20px"><b>No profiles match.</b> Try fewer filters or <a href="<?php echo esc_url( home_url( '/?post_type=listing_type&s=' ) ); ?>">clear all</a>.</div>
	<?php endif; ?>
</div></main>
<?php get_footer();
