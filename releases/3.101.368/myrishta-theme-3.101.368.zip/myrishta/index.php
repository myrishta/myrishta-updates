<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
$ttl = is_home() ? ( get_the_title( (int) get_option( 'page_for_posts' ) ) ? get_the_title( (int) get_option( 'page_for_posts' ) ) : 'Blog' ) : wp_strip_all_tags( get_the_archive_title() );
mrt_page_hero( $ttl, '', 'book', 'Guides' );
?>
<main class="pg"><div class="wrap">
<?php if ( have_posts() ) : ?>
	<div class="gg">
	<?php
	while ( have_posts() ) {
		the_post();
		mrt_guide_card( get_the_ID() );
	}
	?>
	</div>
	<div class="pager"><?php echo wp_kses_post( paginate_links( array( 'type' => 'plain', 'prev_text' => '&laquo;', 'next_text' => '&raquo;' ) ) ); ?></div>
<?php else : ?>
	<div class="note">Nothing found here. <a href="<?php echo esc_url( home_url( '/?post_type=listing_type&s=' ) ); ?>">Search profiles</a></div>
<?php endif; ?>
</div></main>
<?php get_footer();
