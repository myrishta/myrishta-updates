<?php
/* Template Name: About us */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
mrt_page_hero( 'About My Rishta Pakistan', 'A free, non-profit rishta service run from Shahdara, Lahore.', 'heart', 'About us' );
$st = mrt_stats();
$cta = mrt_cta();
?>
<main class="pg"><div class="wrap">
	<div class="kpis">
		<div><b><?php echo (int) $st['profiles']; ?>+</b><span>Profiles</span></div>
		<div><b>Free</b><span>No fee, ever</span></div>
		<div><b>Non-profit</b><span>Registered in Punjab</span></div>
		<div><b>Lahore</b><span>Shahdara office</span></div>
	</div>
	<div class="vals">
		<?php
		foreach ( array(
			array( 'heart', 'Respect', 'Honest, respectful families only.', 'b1' ),
			array( 'shield', 'Privacy', 'We never sell personal information.', 'b2' ),
			array( 'search', 'Safety', 'Safety guides and fast reporting.', 'b3' ),
			array( 'star', 'Free', 'No agents, no hidden charges.', 'b4' ),
		) as $v ) {
			echo '<div class="val"><span class="ib ' . esc_attr( $v[3] ) . '">' . mrt_icon( $v[0] ) . '</span><b>' . esc_html( $v[1] ) . '</b><p>' . esc_html( $v[2] ) . '</p></div>'; // phpcs:ignore
		}
		?>
	</div>
	<?php while ( have_posts() ) : the_post(); ?>
		<article class="entry card2"><?php the_content(); ?></article>
	<?php endwhile; ?>
	<div class="cta"><div><h2>Ready to find your rishta?</h2><p>Join free. It takes three minutes.</p></div><a class="btn big" href="<?php echo esc_url( $cta[1] ); ?>"><?php echo mrt_icon( $cta[2] ); // phpcs:ignore ?><?php echo esc_html( 'Add profile' === $cta[0] ? 'Create free profile' : 'Update your profile' ); ?></a></div>
</div></main>
<?php get_footer();
