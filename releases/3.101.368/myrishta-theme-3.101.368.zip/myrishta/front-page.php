<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( 'page' === get_option( 'show_on_front' ) && is_page() ) {
	require get_template_directory() . '/page.php';
	return;
}
get_header();
$st  = mrt_stats();
$gen = taxonomy_exists( 'dagender' ) ? get_terms( array( 'taxonomy' => 'dagender', 'hide_empty' => false ) ) : array();
$cty = taxonomy_exists( 'country' ) ? get_terms( array( 'taxonomy' => 'country', 'orderby' => 'count', 'order' => 'DESC', 'number' => 60, 'hide_empty' => true ) ) : array();
$rel = taxonomy_exists( 'religion' ) ? get_terms( array( 'taxonomy' => 'religion', 'orderby' => 'count', 'order' => 'DESC', 'number' => 20, 'hide_empty' => true ) ) : array();
$lab = array( 'female' => 'Bride (Female)', 'male' => 'Groom (Male)' );
?>
<section class="hero"><div class="hfx" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i><i></i></div><div class="wrap">
	<span class="pill"><?php echo mrt_icon( 'shield' ); // phpcs:ignore ?>Free for Pakistani families</span>
	<h1><?php echo esc_html( mrt_site( 'hero_title', mrt_opt( 'seo', 'home_title', get_bloginfo( 'name' ) ) ) ); ?></h1>
	<p><?php echo esc_html( mrt_site( 'hero_text', mrt_opt( 'seo', 'home_desc', get_bloginfo( 'description' ) ) ) ); ?></p>
	<p class="hflash" aria-hidden="true"><b>Free to join</b><b>Phone numbers stay private</b><b>Family first, always</b></p>
	<?php if ( mrt_site( 'hero_search', 1 ) ) : ?><form class="hsearch" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" role="search">
		<input type="hidden" name="post_type" value="listing_type"><input type="hidden" name="s" value="">
		<label>I am looking for<select name="tax_dagender"><option value="">Bride or groom</option>
		<?php if ( ! is_wp_error( $gen ) ) { foreach ( $gen as $t ) { $k = strtolower( $t->name ); echo '<option value="' . esc_attr( $t->slug ) . '">' . esc_html( $lab[ $k ] ?? $t->name ) . '</option>'; } } ?>
		</select></label>
		<label>Age<span class="two"><input type="number" name="age_min" min="18" max="80" placeholder="From"><input type="number" name="age_max" min="18" max="80" placeholder="To"></span></label>
		<label>Religion<select name="tax_religion"><option value="">Any</option><?php if ( ! is_wp_error( $rel ) ) { foreach ( $rel as $t ) { if ( in_array( strtolower( trim( $t->name ) ), array( 'tenrikyo', 'animism' ), true ) ) { continue; } $nm = in_array( strtolower( trim( $t->name ) ), array( 'saikh', 'sikh' ), true ) ? 'Sikhism' : $t->name; echo '<option value="' . esc_attr( $t->slug ) . '">' . esc_html( $nm ) . '</option>'; } } ?></select></label>
		<label>City / Country<select name="tax_country"><option value="">Any</option><?php if ( ! is_wp_error( $cty ) ) { foreach ( $cty as $t ) { echo '<option value="' . esc_attr( $t->slug ) . '">' . esc_html( $t->name ) . '</option>'; } } ?></select></label>
		<button class="btn big" type="submit"><?php echo mrt_icon( 'search' ); // phpcs:ignore ?>Search</button>
	</form><?php endif; ?>
	<ul class="trust"><li><?php echo mrt_icon( 'shield' ); // phpcs:ignore ?>Phone numbers stay private</li><li><?php echo mrt_icon( 'smile' ); // phpcs:ignore ?>Verified profiles</li><li><?php echo mrt_icon( 'heart' ); // phpcs:ignore ?>No fees, no agents</li></ul>
	<?php if ( $st['profiles'] && mrt_site( 's_stats', 0 ) ) : ?><div class="stats"><div><b><?php echo esc_html( number_format_i18n( $st['profiles'] ) ); ?></b><span>profiles</span></div><div><b><?php echo esc_html( number_format_i18n( $st['week'] ) ); ?></b><span>new this week</span></div><?php if ( $st['cities'] ) : ?><div><b><?php echo esc_html( number_format_i18n( $st['cities'] ) ); ?></b><span>cities and countries</span></div><?php endif; ?></div><?php endif; ?>
</div></section>

<main>
<?php
$groups = array( 'City' => array( 'country', 'pin' ), 'Education' => array( 'education', 'cap' ), 'Profession' => array( 'occupation', 'work' ), 'Religion' => array( 'religion', 'book' ), 'Marital status' => array( 'maritalstatus', 'ring' ) );
$tabs = array();
foreach ( $groups as $label => $g ) {
	$ch = mrt_chips( $g[0], 12 );
	if ( $ch ) {
		$tabs[ $label ] = array( $ch, $g[1] );
	}
}
if ( $tabs && mrt_site( 's_browse', 0 ) ) {
	echo '<div class="wrap"><section class="browse"><h2 class="sec">Browse profiles by</h2><div class="btabs">';
	$i = 0;
	foreach ( $tabs as $label => $t ) {
		echo '<input type="radio" name="bt" id="bt' . (int) $i . '"' . ( 0 === $i ? ' checked' : '' ) . '><label for="bt' . (int) $i . '">' . esc_html( $label ) . '</label>';
		$i++;
	}
	$i = 0;
	foreach ( $tabs as $label => $t ) {
		echo '<div class="bpanel bp' . (int) $i . '">';
		foreach ( $t[0] as $n => $c ) {
			echo '<a class="tile t' . (int) ( $n % 6 ) . '" href="' . esc_url( $c[1] ) . '"><span class="ti">' . mrt_icon( $t[1] ) . '</span><b>' . esc_html( $c[0] ) . '</b><small>' . (int) $c[2] . ' profiles</small></a>'; // phpcs:ignore
		}
		echo '</div>';
		$i++;
	}
	echo '</div></section></div>';
}

$rvi = mrt_recent_ids();
echo '<div class="wrap" id="mrt-rv"' . ( $rvi ? '' : ' hidden' ) . '><h2 class="sec">Recently viewed</h2><div class="row">';
foreach ( $rvi as $rvid ) {
	if ( 'publish' === get_post_status( $rvid ) ) {
		echo '<a class="chip" href="' . esc_url( get_permalink( $rvid ) ) . '">' . esc_html( get_the_title( $rvid ) ) . '</a>';
	}
}
echo '</div></div>';
$pod = mrt_site( 's_pod', 0 ) ? mrt_pod() : 0; // Profile of the day is off by default (shows one lonely card).
if ( $pod ) {
	echo '<div class="wrap"><h2 class="sec">Profile of the day</h2><div class="grid" style="grid-template-columns:minmax(0,230px)">';
	mrt_card( $pod );
	echo '</div></div>';
}
$rows = array(
	array( 'Featured profiles', array( 'meta_key' => 'featured', 'meta_value' => 'yes' ), 'scroll' ),
	array( 'New brides', array( 'tax_query' => array( array( 'taxonomy' => 'dagender', 'field' => 'name', 'terms' => 'Female' ) ) ), 'grid' ),
	array( 'New grooms', array( 'tax_query' => array( array( 'taxonomy' => 'dagender', 'field' => 'name', 'terms' => 'Male' ) ) ), 'grid' ),
);
foreach ( $rows as $ri => $r ) {
	if ( ! mrt_site( array( 's_featured', 's_brides', 's_grooms' )[ $ri ], 1 ) ) {
		continue;
	}
	$args = array_merge( array( 'post_type' => 'listing_type', 'posts_per_page' => 'scroll' === $r[2] ? 10 : 8, 'no_found_rows' => true ), $r[1] );
	if ( isset( $args['tax_query'] ) && ! taxonomy_exists( 'dagender' ) ) {
		continue;
	}
	$q = new WP_Query( $args );
	if ( ! $q->have_posts() ) {
		continue;
	}
	echo '<div class="wrap"><div class="shead"><h2 class="sec">' . esc_html( $r[0] ) . '</h2><a href="' . esc_url( home_url( '/?post_type=listing_type&s=' ) ) . '">See all</a></div><div class="' . ( 'scroll' === $r[2] ? 'hscroll' : 'grid' ) . '">';
	while ( $q->have_posts() ) {
		$q->the_post();
		mrt_card();
	}
	echo '</div></div>';
	wp_reset_postdata();
}
?>
<?php
$pl_ = mrt_plans();
if ( count( $pl_ ) > 1 && mrt_site( 's_plans', 1 ) ) {
	$hotn = mrt_plan_hot();
	$allfree_ = true;
	foreach ( $pl_ as $p_ ) {
		if ( 0 !== strcasecmp( trim( (string) $p_[1] ), 'free' ) ) {
			$allfree_ = false;
		}
	}
	echo '<div class="wrap"><h2 class="sec">Membership</h2>' . ( $allfree_ ? '<p style="margin:-6px 0 14px;color:#666">Every membership is free right now. Pick the one that suits your family and start today.</p>' : '' ) . '<div class="plans big">';
	foreach ( $pl_ as $i => $p ) {
		$hot = '' !== $hotn ? 0 === strcasecmp( $p[0], $hotn ) : ( count( $pl_ ) > 2 && $i === count( $pl_ ) - 1 );
		echo '<div class="plan' . ( $hot ? ' hot' : '' ) . '"' . ( $p[3] ? ' style="--pc:' . esc_attr( $p[3] ) . '"' : '' ) . '>' . ( $hot ? '<span class="ribbon">' . ( '' !== $hotn ? 'Most popular' : 'Best value' ) . '</span>' : '' ) . '<b>' . esc_html( $p[0] ) . '</b><span class="pc">' . esc_html( $p[1] ) . '</span><ul>';
		foreach ( $p[2] as $ft ) {
			echo '<li>' . esc_html( $ft ) . '</li>';
		}
		echo '</ul><a class="btn' . ( $hot ? '' : ' line' ) . '" href="' . esc_url( mrt_link( 'memberships', '/memberships/' ) ) . '">' . ( 0 === $i ? 'Get started' : 'Choose ' . esc_html( $p[0] ) ) . '</a></div>';
	}
	echo '</div></div>';
}
?>
<?php if ( mrt_site( 's_how', 1 ) ) : ?>
<div class="wrap"><h2 class="sec">How it works</h2>
	<div class="steps">
		<div><span class="ib b1"><?php echo mrt_icon( 'user' ); // phpcs:ignore ?></span><b>1. Create a free profile</b><p>Add your details and a photo. Your phone number is never shown.</p></div>
		<div><span class="ib b2"><?php echo mrt_icon( 'search' ); // phpcs:ignore ?></span><b>2. Find matches</b><p>Search by city, education, profession or let us suggest matches with a compatibility %.</p></div>
		<div><span class="ib b3"><?php echo mrt_icon( 'heart' ); // phpcs:ignore ?></span><b>3. Connect safely</b><p>Send interest or a message. Meet with your family. Never send money.</p></div>
	</div>
</div>
<?php endif;
$stories = mrt_pairs( mrt_site( 'stories' ) );
if ( $stories && mrt_site( 's_stories', 1 ) ) {
	echo '<div class="wrap"><h2 class="sec">Success stories</h2><div class="stories">';
	foreach ( array_slice( $stories, 0, 6 ) as $p ) {
		echo '<blockquote><p>&ldquo;' . esc_html( $p[1] ) . '&rdquo;</p><cite>' . esc_html( $p[0] ) . '</cite></blockquote>';
	}
	echo '</div></div>';
}
$mrt_cities = array( 'Lahore' => 'rishta-lahore', 'Karachi' => 'rishta-karachi', 'Islamabad & Rawalpindi' => 'rishta-islamabad-rawalpindi', 'Faisalabad' => 'rishta-faisalabad', 'Multan' => 'rishta-multan', 'Peshawar & Quetta' => 'rishta-peshawar-quetta' );
$mrt_over   = array( 'UAE and Dubai' => 'rishta-uae-pakistani-families', 'Saudi Arabia' => 'rishta-saudi-arabia-pakistani-families', 'United Kingdom' => 'rishta-uk-pakistani-families', 'USA' => 'rishta-usa-pakistani-families', 'Canada' => 'rishta-canada-pakistani-families' );
if ( class_exists( 'MRSH_Landing' ) ) { foreach ( array( 'Qatar' => 'rishta-qatar-pakistani-families', 'Bahrain' => 'rishta-bahrain-pakistani-families', 'Oman' => 'rishta-oman-pakistani-families', 'Kuwait' => 'rishta-kuwait-pakistani-families' ) as $mrt_l => $mrt_s ) { if ( MRSH_Landing::exists( $mrt_s ) ) { $mrt_over[ $mrt_l ] = $mrt_s; } } }
echo '<div class="wrap"><h2 class="sec">Rishta by city</h2><div class="row">';
foreach ( $mrt_cities as $l => $sl ) { echo '<a class="chip" href="' . esc_url( home_url( '/' . $sl . '/' ) ) . '">' . mrt_icon( 'pin' ) . esc_html( $l ) . '</a>'; } // phpcs:ignore
echo '</div><h2 class="sec">Rishta for overseas Pakistanis</h2><div class="row">';
foreach ( $mrt_over as $l => $sl ) { echo '<a class="chip" href="' . esc_url( home_url( '/' . $sl . '/' ) ) . '">' . mrt_icon( 'pin' ) . esc_html( $l ) . '</a>'; } // phpcs:ignore
echo '</div><h2 class="sec">Safe and honest</h2><div class="feats">';
foreach ( array(
	array( 'shield', 'Verification badges', 'What the green tick means.', '/verification-badges/', 'b1' ),
	array( 'book', 'Rishta safety tips', 'Avoid fake profiles and scams.', '/rishta-safety-tips-avoid-fake-profiles-scams/', 'b3' ),
	array( 'chat', 'Report a profile', 'Tell us about misuse.', '/report-profile-misuse/', 'b5' ),
	array( 'star', 'Free marriage bureau', 'No fees, no agents.', '/free-marriage-bureau-online-pakistan/', 'b4' ),
	array( 'user', 'Public notice', 'About fake accounts.', '/public-notice-fake-accounts/', 'b2' ),
	array( 'phone', 'My Rishta app', 'Install on your phone.', '/?pwa=1', 'b6' ),
) as $f ) { echo '<a class="feat" style="text-decoration:none;color:inherit" href="' . esc_url( home_url( $f[3] ) ) . '"><span class="ib ' . esc_attr( $f[4] ) . '">' . mrt_icon( $f[0] ) . '</span><b>' . esc_html( $f[1] ) . '</b><p>' . esc_html( $f[2] ) . '</p></a>'; } // phpcs:ignore
echo '</div></div>';
$faq = mrt_pairs( mrt_site( 'faq' ) );
if ( $faq && mrt_site( 's_faq', 1 ) ) {
	echo '<div class="wrap"><h2 class="sec">Questions and answers</h2><div class="faq">';
	foreach ( $faq as $p ) {
		echo '<details><summary>' . esc_html( $p[0] ) . '</summary><p>' . esc_html( $p[1] ) . '</p></details>';
	}
	echo '</div></div>';
}
if ( mrt_site( 's_cta', 1 ) ) : ?>
<div class="wrap"><div class="cta"><div><h2>Your rishta may be one profile away</h2><p>Join free. It takes three minutes.</p></div><?php $cta = mrt_cta(); ?><a class="btn big" href="<?php echo esc_url( $cta[1] ); ?>"><?php echo mrt_icon( $cta[2] ); // phpcs:ignore ?><?php echo 'Add profile' === $cta[0] ? 'Create free profile' : 'Update your profile'; ?></a></div></div>
<?php endif; ?>
</main>
<?php get_footer();
