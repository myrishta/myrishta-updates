<?php
/* Template Name: Blog and guides */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
mrt_page_hero( 'Guides and advice', 'How to find a rishta, stay safe and prepare for nikah.', 'book', 'Blog' );
$ids   = mrt_guides();
$pp    = 12;
$pg    = max( 1, isset( $_GET['pg'] ) ? (int) $_GET['pg'] : 1 ); // phpcs:ignore
$pages = max( 1, (int) ceil( count( $ids ) / $pp ) );
$pg    = min( $pg, $pages );
$flt   = isset( $_GET['k'] ) ? sanitize_key( wp_unslash( $_GET['k'] ) ) : ''; // phpcs:ignore
$kinds = array( 'k1' => 'Safety', 'k2' => 'City guide', 'k3' => 'Overseas', 'k4' => 'Guide', 'k5' => 'Article' );
if ( isset( $kinds[ $flt ] ) ) {
	$ids = array_values( array_filter( $ids, function ( $i ) use ( $flt ) {
		$k = mrt_guide_kind( get_the_title( $i ) );
		return $k[2] === $flt;
	} ) );
	$pages = max( 1, (int) ceil( count( $ids ) / $pp ) );
	$pg    = min( $pg, $pages );
}
$base = get_permalink();
?>
<main class="pg"><div class="wrap">
	<div class="row sortrow"><a class="chip<?php echo '' === $flt ? ' on' : ''; ?>" href="<?php echo esc_url( $base ); ?>">All</a>
	<?php foreach ( $kinds as $kk => $kl ) { echo '<a class="chip' . ( $flt === $kk ? ' on' : '' ) . '" href="' . esc_url( add_query_arg( 'k', $kk, $base ) ) . '">' . esc_html( $kl ) . '</a>'; } // phpcs:ignore ?></div>
	<?php if ( $ids ) : ?>
	<div class="gg">
		<?php foreach ( array_slice( $ids, ( $pg - 1 ) * $pp, $pp ) as $i ) { mrt_guide_card( $i ); } ?>
	</div>
	<?php if ( $pages > 1 ) : ?><div class="pager"><?php for ( $x = 1; $x <= $pages; $x++ ) { echo $x === $pg ? '<span class="current">' . (int) $x . '</span>' : '<a href="' . esc_url( add_query_arg( array( 'pg' => $x, 'k' => $flt ), $base ) ) . '">' . (int) $x . '</a>'; } // phpcs:ignore ?></div><?php endif; ?>
	<?php else : ?>
		<div class="note">No guides yet.</div>
	<?php endif; ?>
</div></main>
<?php get_footer();
