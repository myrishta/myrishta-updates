<?php
/* Template Name: My account */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
// The login and account page is personal: never let a page cache (or the phone browser) keep a copy.
if ( ! defined( 'DONOTCACHEPAGE' ) ) {
	define( 'DONOTCACHEPAGE', true );
}
nocache_headers();
do_action( 'litespeed_control_set_nocache', 'my account page' );
get_header();
if ( ! class_exists( 'MRSH_Members' ) ) {
	echo '<main><div class="wrap narrow"><div class="note">This page needs the My Rishta plugin to be active.</div></div></main>';
	get_footer();
	return;
}
// The account styles are printed right here (not a separate file), so page-speed caches can never leave an old copy.
$mrt_css = is_readable( __DIR__ . '/assets/account.css' ) ? (string) file_get_contents( __DIR__ . '/assets/account.css' ) : '';
echo '<style id="mrt-acct-css">' . preg_replace( '/\s+/', ' ', $mrt_css ) . '</style>'; // phpcs:ignore
echo '<main class="acct' . ( is_user_logged_in() ? '' : ' out' ) . '"><div class="wrap narrow">';
if ( is_user_logged_in() && class_exists( 'MRSH_Mobile' ) ) {
	echo MRSH_Mobile::banner(); // phpcs:ignore
}
if ( ! is_user_logged_in() ) {
	?>
	<section class="lg">
	<aside class="lg-side">
		<span class="lg-mark" aria-hidden="true"><i></i><i></i></span>
		<h1>Welcome back</h1>
		<p class="lg-sub">Sign in to see your matches, messages and shortlist.</p>
		<ul class="lg-pts">
			<li><?php echo mrt_icon( 'heart' ); // phpcs:ignore ?><span>Free for every family, always</span></li>
			<li><?php echo mrt_icon( 'shield' ); // phpcs:ignore ?><span>Your phone number stays private</span></li>
			<li><?php echo mrt_icon( 'star' ); // phpcs:ignore ?><span>Real profiles, checked by our team</span></li>
		</ul>
	</aside>
	<div class="lg-card">
		<h2>Log in</h2>
		<p class="lg-hint">Use your email, username or mobile number.</p>
		<?php wp_login_form( array( 'redirect' => get_permalink(), 'label_username' => 'Email, username or mobile number', 'label_password' => 'Password', 'label_remember' => 'Keep me logged in', 'label_log_in' => 'Log in', 'remember' => true ) ); ?>
		<p class="lg-links"><a href="<?php echo esc_url( wp_lostpassword_url() ); ?>">Forgot password?</a></p>
		<?php if ( get_option( 'users_can_register' ) ) : ?>
		<p class="lg-new">New here? <a class="lg-reg" href="<?php echo esc_url( wp_registration_url() ); ?>">Create a free account</a></p>
		<?php endif; ?>
	</div>
	</section>
	<script>
	(function(){var f=document.getElementById('loginform');if(!f)return;var u=f.querySelector('#user_login'),w=f.querySelector('#user_pass');
	if(u){u.setAttribute('placeholder','name@example.com');u.setAttribute('autocomplete','username');u.setAttribute('autocapitalize','none')}
	if(w){w.setAttribute('placeholder','••••••••');w.setAttribute('autocomplete','current-password');
	var b=document.createElement('button');b.type='button';b.className='lg-eye';b.setAttribute('aria-label','Show password');b.textContent='Show';
	w.parentNode.style.position='relative';w.parentNode.appendChild(b);
	b.addEventListener('click',function(){var t=w.type==='password';w.type=t?'text':'password';b.textContent=t?'Hide':'Show'})}})();
	</script>
	<?php
	echo '</div></main>';
	get_footer();
	return;
}
ob_start(); // the page is tidied (icons on box headings) when it is finished
$uid  = get_current_user_id();
$tab  = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'home'; // phpcs:ignore
$mine = class_exists( 'MRSH_Members' ) ? MRSH_Members::my_profile( $uid ) : null;
$un   = class_exists( 'MRSH_Members' ) ? MRSH_Members::unread_count( $uid ) : 0;
$base = get_permalink();
$tabs = array( 'home' => 'Home', 'matches' => 'Matches', 'messages' => 'Messages', 'shortlist' => 'Shortlist', 'winks' => 'Winks', 'requests' => 'Phone requests', 'saved' => 'Saved searches', 'views' => 'Viewed me', 'prefs' => 'Preferences', 'settings' => 'Settings' );
echo '<h1>Assalam o Alaikum, ' . esc_html( wp_get_current_user()->display_name ) . '</h1><nav class="tabs">';
$tic = array( 'home' => 'home', 'matches' => 'heart', 'messages' => 'chat', 'shortlist' => 'star', 'winks' => 'smile', 'requests' => 'shield', 'saved' => 'search', 'views' => 'user', 'prefs' => 'book', 'settings' => 'shield' );
foreach ( $tabs as $k => $l ) {
	echo '<a class="' . ( $tab === $k ? 'cur' : '' ) . '" href="' . esc_url( add_query_arg( 'tab', $k, $base ) ) . '">' . mrt_icon( $tic[ $k ] ?? 'home' ) . '<span>' . esc_html( $l ) . '</span>' . ( 'messages' === $k && $un ? '<b class="tbd">' . (int) $un . '</b>' : '' ) . '</a>'; // phpcs:ignore
}
echo '<a class="out" href="' . esc_url( wp_logout_url( home_url( '/' ) ) ) . '">' . mrt_icon( 'user' ) . 'Log out</a></nav>'; // phpcs:ignore
echo '<script>(function(){var c=document.querySelector("main.acct .tabs a.cur"),t=c&&c.parentNode;if(t&&window.innerWidth<700&&t.scrollWidth>t.clientWidth){t.scrollLeft=c.offsetLeft-(t.clientWidth-c.offsetWidth)/2}})();</script>';
echo '<button type="button" id="mrt-install" class="btn line" hidden>' . mrt_icon( 'home' ) . ' Install this app on your phone <span lang="ur" dir="rtl" style="margin-inline-start:6px">(فون پر ایپ انسٹال کریں)</span></button>'; // phpcs:ignore
if ( ! empty( $_GET['ok'] ) ) { // phpcs:ignore
	echo '<div class="okb">Saved.</div>';
}

function mrt_list_profiles( $rows ) {
	echo '<div class="grid">';
	foreach ( $rows as $r ) {
		$p = is_object( $r ) ? $r : $r['post'];
		mrt_card( $p );
	}
	echo '</div>';
}

if ( 'home' === $tab ) {
	if ( ! $mine ) {
		echo '<div class="box b1"><h2>Create your free profile</h2><p>It takes 3 minutes. Phone numbers are never shown to others.</p><a class="btn" href="' . esc_url( mrt_link( 'add', '/add-listing/' ) ) . '">Create profile</a></div>';
	} else {
		$sc = class_exists( 'MRSH_Members' ) ? MRSH_Members::completeness( $mine ) : array( 0, array() );
		echo '<div class="box b1"><h2>Your profile: ' . esc_html( get_the_title( $mine ) ) . '</h2><p class="ml">Status: ' . esc_html( 'publish' === $mine->post_status ? 'Published' : ( 'pending' === $mine->post_status ? 'Waiting for approval' : ucfirst( $mine->post_status ) ) ) . '</p>';
		echo '<p><a class="btn" href="' . esc_url( add_query_arg( 'edit', $mine->ID, mrt_link( 'add', '/add-listing/' ) ) ) . '">Edit profile</a> <a class="btn line" href="' . esc_url( get_permalink( $mine ) ) . '">View</a> ' . ( ( 'publish' !== $mine->post_status || ! class_exists( 'MRSH_Switch' ) || MRSH_Switch::on( 'pause' ) ) ? '<a class="btn line" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mrt_pause_profile&pid=' . $mine->ID ), 'mrt_pause_profile' ) ) . '">' . ( 'publish' === $mine->post_status ? 'Pause profile' : 'Show profile' ) . '</a>' : '' ) . '</p></div>';
		if ( class_exists( 'MRSH_Mem_More5' ) ) {
			echo '<div style="margin:0 0 16px">';
			MRSH_Mem_More5::strength_card( get_current_user_id() );
			echo '</div>';
		}
		if ( class_exists( 'MRSH_Useful' ) ) {
			MRSH_Useful::nudge( $mine );
		}
		$nm = MRSH_Match::best( $mine, 4 );
		if ( $nm ) {
			echo '<h2>Top matches for you</h2>';
			mrt_list_profiles( $nm );
		}
	}
	$uid_ = get_current_user_id();
	$vf   = (bool) get_user_meta( $uid_, '_mrsh_id_verified', true );
	$vq   = (bool) get_user_meta( $uid_, 'mrt_vreq', true );
	$plq  = (string) get_user_meta( $uid_, 'mrt_plan', true );
	$plr  = (string) get_user_meta( $uid_, 'mrt_plan_req', true );
	echo '<div class="box b3 trust"><h2>Trust and membership</h2><p>' . ( $vf ? '<span class="pill pv">' . mrt_icon( 'shield' ) . 'Verified by My Rishta</span>' : ( $vq ? '<span class="pill ps">Verification requested</span>' : '<button type="button" class="btn" data-act="vreq">' . mrt_icon( 'shield' ) . 'Get verified</button>' ) ) . ' <span class="pill pp">' . mrt_icon( 'star' ) . esc_html( $plq ? $plq : 'Free' ) . ' plan</span>' . ( $plr ? ' <span class="ml">Requested: ' . esc_html( $plr ) . ' (waiting for our team)</span>' : '' ) . '</p><p class="ml">Verification is done by our team on a call. Never send ID photos in messages.</p></div>';
	$pln = mrt_plans();
	if ( count( $pln ) > 1 ) {
		$want = isset( $_GET['plan'] ) ? sanitize_text_field( wp_unslash( $_GET['plan'] ) ) : ''; // phpcs:ignore
		echo '<div class="box b3" id="mrt-plan"><h2>Change membership plan</h2>';
		if ( isset( $_GET['plan'] ) && 'ok' === $_GET['plan'] ) { // phpcs:ignore
			echo '<p class="note2">Done. Free plans change at once. Paid plans start after our team checks your payment.</p>';
		} elseif ( isset( $_GET['plan'] ) && 'cancel' === $_GET['plan'] ) { // phpcs:ignore
			echo '<p class="note2">Your request was cancelled.</p>';
		}
		echo '<p>Your plan now: <b>' . esc_html( $plq ? $plq : $pln[0][0] ) . '</b>' . ( $plr ? ' &nbsp; Waiting: <b>' . esc_html( $plr ) . '</b>' : '' ) . '</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="frm"><input type="hidden" name="action" value="mrt_myplan">' . wp_nonce_field( 'mrt_myplan', '_wpnonce', true, false ) . '<div class="pl-grid" role="radiogroup" aria-label="Plan">';
		$cur_ = $want ? $want : ( $plr ? $plr : ( $plq ? $plq : $pln[0][0] ) );
		foreach ( $pln as $p_ ) {
			echo '<label class="pl-opt"><input type="radio" name="plan" value="' . esc_attr( $p_[0] ) . '"' . checked( $cur_, $p_[0], false ) . '><span class="pl-in"><i class="pl-tk">&#10003;</i><b>' . esc_html( $p_[0] ) . '</b>' . ( strtoupper( trim( (string) $p_[1] ) ) === strtoupper( trim( (string) $p_[0] ) ) || 0 === stripos( (string) $p_[1], (string) $p_[0] ) ? '' : '<small>' . esc_html( $p_[1] ) . '</small>' ) . '</span></label>';
		}
		echo '</div><button class="btn">' . mrt_icon( 'star' ) . 'Request this plan</button></form>';
		if ( $plr ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin-top:8px"><input type="hidden" name="action" value="mrt_myplan">' . wp_nonce_field( 'mrt_myplan', '_wpnonce', true, false ) . '<input type="hidden" name="plan" value=""><button class="btn line sm">Cancel my request</button></form>';
		}
		echo get_option( 'mrsh_plans_free', 0 ) ? '<p class="ml">Every plan is free during our launch offer. No payment is needed.</p></div>' : '<p class="ml">After you pay (Easypaisa, JazzCash or bank) send the screenshot' . ( ( ! class_exists( 'MRSH_Switch' ) || MRSH_Switch::on( 'payproof' ) ) ? ' in <b>Send payment proof</b> below' : ' to our team' ) . '. We then switch your plan on.</p></div>';
	}
	echo '<div class="box"><h2>Notifications</h2><p>Get an alert on this device for new messages and interests, even when the site is closed.</p><button type="button" class="btn" data-push>' . mrt_icon( 'mail' ) . 'Turn on notifications</button></div>'; // phpcs:ignore
	echo '<div class="box b2 sf1"><h2>Safety</h2><p>Never send money to anyone you meet here. Meet with your family. Use Report or Block on any profile.</p></div>';
} elseif ( 'matches' === $tab ) {
	if ( ! $mine || 'publish' !== $mine->post_status ) {
		echo '<p>Create and publish your profile to see matches.</p>';
	} else {
		$mu = MRSH_Match::mutual( $mine );
		if ( $mu ) {
			echo '<h2 class="sec">Match both ways</h2><p class="ml">You fit what they want, and they fit what you want.</p><div class="mtg">';
			foreach ( $mu as $m ) {
				echo mrt_match_tile( $m, true ); // phpcs:ignore
			}
			echo '</div>';
		}
		echo '<h2 class="sec">All suggestions</h2>';
		$all = MRSH_Match::best( $mine, 40, 40 );
		if ( ! $all ) {
			echo '<p>No matches yet. Widen your preferences.</p>';
		} else {
			echo '<div class="mtg">';
			foreach ( $all as $m ) {
				echo mrt_match_tile( $m ); // phpcs:ignore
			}
			echo '</div>';
		}
	}
} elseif ( 'messages' === $tab ) {
	$with = isset( $_GET['with'] ) ? absint( $_GET['with'] ) : 0; // phpcs:ignore
	if ( $with ) {
		$ou = get_userdata( $with );
		echo '<h2>' . esc_html( $ou ? $ou->display_name : 'Member' ) . '</h2>';
		$op   = MRSH_Members::my_profile( $with );
		$last = 0;
		if ( $op ) {
			echo '<p style="display:flex;gap:8px;flex-wrap:wrap"><button type="button" class="qb dim" data-act="report" data-pid="' . (int) $op->ID . '">Report</button><button type="button" class="qb dim" data-act="block" data-pid="' . (int) $op->ID . '">Block</button></p>';
		}
		echo '<div class="chat" id="mrt-chat" data-with="' . (int) $with . '"><div class="cl">';
		foreach ( MRSH_Members::thread( $uid, $with ) as $m ) {
			$last = max( $last, (int) $m->ID );
			echo '<div class="bub' . ( (int) $m->post_author === $uid ? ' me' : '' ) . '">' . esc_html( $m->post_content ) . '</div>';
		}
		echo '</div>';
		if ( $op && 'publish' === $op->post_status ) {
			echo '<div class="cmp"><textarea rows="1" maxlength="1000" placeholder="Write a message (no links or phone numbers)" aria-label="Message"></textarea><button type="button" class="btn send">' . mrt_icon( 'chat' ) . 'Send</button></div><p class="ml">New messages appear here by themselves. <a href="' . esc_url( get_permalink( $op ) ) . '">View profile</a></p>'; // phpcs:ignore
		} else {
			echo '<p class="ml">This member has no live profile right now, so you cannot reply.</p>';
		}
		echo '</div><script>document.getElementById("mrt-chat").setAttribute("data-last",' . (int) $last . ');</script>';
	} else {
		$in = MRSH_Members::inbox( $uid );
		if ( ! $in ) {
			echo '<p>No messages yet.</p>';
		}
		echo '<div class="msgl">';
		foreach ( $in as $other => $c ) {
			$ou = get_userdata( $other );
			$nm   = $ou ? $ou->display_name : 'Member';
			$op_  = MRSH_Members::my_profile( (int) $other );
			$img_ = ( $op_ && 'all' === ( get_user_meta( (int) $other, 'mrt_photo_priv', true ) ?: 'all' ) ) ? mrt_photo( $op_->ID, 'thumbnail', array( 'alt' => '' ) ) : '';
			echo '<a class="mrow' . ( $c['unread'] ? ' un' : '' ) . '" href="' . esc_url( add_query_arg( array( 'tab' => 'messages', 'with' => $other ), $base ) ) . '"><span class="mav">' . ( $img_ ? $img_ : esc_html( function_exists( 'mb_strtoupper' ) ? mb_strtoupper( mb_substr( $nm, 0, 1 ) ) : strtoupper( substr( $nm, 0, 1 ) ) ) ) . '</span><span class="mtx"><span class="mtop"><b>' . esc_html( $nm ) . '</b><span class="ml">' . esc_html( mysql2date( 'j M', $c['date'] ) ) . '</span></span><span class="mbt"><span class="ml">' . esc_html( $c['text'] ) . '</span>' . ( $c['unread'] ? '<span class="mcnt">' . (int) $c['unread'] . '</span>' : '' ) . '</span></span></a>';
		}
		echo '</div>';
	}
} elseif ( 'shortlist' === $tab ) {
	$ids = array_map( 'intval', (array) get_user_meta( $uid, 'favorite', true ) );
	$q   = $ids ? get_posts( array( 'post_type' => 'listing_type', 'post__in' => $ids, 'posts_per_page' => 60, 'orderby' => 'post__in' ) ) : array();
	if ( $q ) {
		echo '<div class="acct-h"><h2>Your shortlist</h2><span class="acct-ct">' . (int) count( $q ) . ' saved</span></div>'; // phpcs:ignore
		mrt_list_profiles( $q );
	} else {
		echo '<div class="acct-empty"><span class="bub">' . mrt_icon( 'star' ) . '</span><b>Your shortlist is empty</b><p>Tap Shortlist on a profile you like. It is saved here so your family can look at it together.</p><a class="btn" href="' . esc_url( home_url( '/?post_type=listing_type&s=' ) ) . '">Browse profiles</a></div>'; // phpcs:ignore
	}
} elseif ( 'winks' === $tab ) {
	$ps = get_posts( array( 'post_type' => 'listing_type', 'author' => $uid, 'post_status' => 'any', 'numberposts' => 1 ) );
	$rows = array();
	if ( $ps ) {
		$w = get_post_meta( $ps[0]->ID, 'winks', true );
		foreach ( array_reverse( (array) $w, true ) as $from => $d ) {
			$fp = MRSH_Members::my_profile( (int) $from );
			if ( $fp && 'publish' === $fp->post_status ) {
				$rows[] = $fp;
			}
		}
		$ints = get_post_meta( $ps[0]->ID, 'mrt_interests', true );
		foreach ( array_reverse( (array) $ints ) as $from ) {
			$fp = MRSH_Members::my_profile( (int) $from );
			if ( $fp && 'publish' === $fp->post_status ) {
				$rows[] = $fp;
			}
		}
	}
	echo $rows ? '<h2>People who showed interest in you</h2>' : '<p>Nobody yet. Complete your profile and add a photo to get more interest.</p>'; // phpcs:ignore
	mrt_list_profiles( array_slice( array_unique( $rows, SORT_REGULAR ), 0, 40 ) );
} elseif ( 'requests' === $tab ) {
	$rows = 0;
	if ( $mine ) {
		$rq = (array) get_post_meta( $mine->ID, 'mrt_phone_req', true );
		echo '<p class="ml">Your phone number is shown only to members you approve.</p>';
		foreach ( $rq as $who => $stt ) {
			$wu = get_userdata( (int) $who );
			$wp = MRSH_Members::my_profile( (int) $who );
			if ( ! $wu ) { continue; }
			$rows++;
			$ok  = wp_nonce_url( admin_url( 'admin-post.php?action=mrt_phone&pid=' . $mine->ID . '&who=' . (int) $who . '&ok=1' ), 'mrt_phone' . $mine->ID . '_' . (int) $who );
			$no  = wp_nonce_url( admin_url( 'admin-post.php?action=mrt_phone&pid=' . $mine->ID . '&who=' . (int) $who . '&ok=0' ), 'mrt_phone' . $mine->ID . '_' . (int) $who );
			echo '<div class="box"><b>' . ( $wp ? '<a href="' . esc_url( get_permalink( $wp ) ) . '">' . esc_html( get_the_title( $wp ) ) . '</a>' : esc_html( $wu->display_name ) ) . '</b> asked for your number. Status: <b>' . esc_html( $stt ) . '</b> ';
			if ( 'pending' === $stt ) { echo '<a class="btn" href="' . esc_url( $ok ) . '">Share</a> <a class="btn line" href="' . esc_url( $no ) . '">Decline</a>'; }
			elseif ( 'yes' === $stt ) { echo '<a class="btn line" href="' . esc_url( $no ) . '">Stop sharing</a>'; }
			echo '</div>';
		}
	}
	if ( ! $rows ) { echo '<p>No requests yet.</p>'; }
} elseif ( 'saved' === $tab ) {
	$sv = array_values( array_filter( (array) get_user_meta( $uid, 'mrt_searches', true ), 'is_array' ) );
	if ( ! $sv ) { echo '<div class="box ssempty"><h2>No saved searches yet</h2><p>On the search page, tap <b>Save this search</b>. We email you when a new profile fits.</p><a class="btn" href="' . esc_url( home_url( '/?post_type=listing_type' ) ) . '">Search profiles</a></div>'; }
	else { echo '<p class="ml" style="margin:0 0 10px">We email you when a new profile fits one of these searches. You can keep up to 10.</p>'; }
	$seen_ss = array();
	foreach ( $sv as $i => $x ) {
		$kk = class_exists( 'MRSH_Useful' ) ? MRSH_Useful::key( $x['q'] ) : $x['q'];
		if ( isset( $seen_ss[ $kk ] ) ) { continue; } // never show the same search twice
		$seen_ss[ $kk ] = 1;
		parse_str( $x['q'], $qa );
		$bits = array();
		foreach ( $qa as $k => $v ) {
			if ( in_array( $k, array( 'post_type', 'paged', 'pwa', 'lang' ), true ) || '' === $v || ! is_string( $v ) ) { continue; }
			$bits[] = '<span class="ssc"><small>' . esc_html( ucfirst( str_replace( array( 'tax_', '_', '-' ), array( '', ' ', ' ' ), $k ) ) ) . '</small>' . esc_html( ucwords( str_replace( '-', ' ', $v ) ) ) . '</span>';
		}
		echo '<div class="box ssrow"><div class="ssb">' . ( $bits ? implode( '', $bits ) : '<span class="ssc">All profiles</span>' ) . '</div><div class="ssa"><span class="ml">Saved ' . esc_html( mysql2date( 'j M Y', $x['d'] ) ) . '</span><a class="btn sm" href="' . esc_url( home_url( '/?' . $x['q'] ) ) . '">View results</a><button type="button" class="btn sm line" data-act="delsearch" data-i="' . (int) $i . '">Remove</button></div></div>';
	}
} elseif ( 'views' === $tab ) {
	$rows = array();
	if ( $mine ) {
		foreach ( array_reverse( array_map( 'intval', array_filter( (array) get_post_meta( $mine->ID, 'mrt_viewers', true ) ) ) ) as $vu ) {
			$vp = MRSH_Members::my_profile( $vu );
			if ( $vp && 'publish' === $vp->post_status ) {
				$rows[] = $vp;
			}
		}
	}
	if ( $rows ) {
		echo '<div class="acct-h"><h2>Recently viewed your profile</h2><span class="acct-ct">' . (int) count( $rows ) . ' people</span></div>'; // phpcs:ignore
		mrt_list_profiles( array_slice( $rows, 0, 40 ) );
	} else {
		echo '<div class="acct-empty"><span class="bub">' . mrt_icon( 'user' ) . '</span><b>No views yet</b><p>When someone opens your profile, they appear here. A clear photo and a complete profile bring more visits.</p><a class="btn" href="' . esc_url( home_url( '/add-listing/' ) ) . '">Improve my profile</a></div>'; // phpcs:ignore
	}
} elseif ( 'settings' === $tab ) {
	if ( class_exists( 'MRSH_Settings' ) ) {
		MRSH_Settings::render();
	}
} elseif ( 'prefs' === $tab ) {
	$pf = MRSH_Match::pref( $uid );
	echo '<form class="frm box b1" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><h2>Who are you looking for?</h2><input type="hidden" name="action" value="mrt_save_pref">';
	wp_nonce_field( 'mrt_save_pref' );
	echo '<div class="g2"><div><label>Age from</label><input type="number" name="age_min" min="18" max="80" value="' . esc_attr( $pf['age_min'] ?? '' ) . '"></div><div><label>Age to</label><input type="number" name="age_max" min="18" max="80" value="' . esc_attr( $pf['age_max'] ?? '' ) . '"></div></div>';
	$map = array( 'religion' => array( 'religion', 'Religion' ), 'sect' => array( 'sect', 'Sect' ), 'caste' => array( 'caste', 'Caste' ), 'marital' => array( 'maritalstatus', 'Marital status' ), 'edu' => array( 'education', 'Education' ), 'country' => array( 'country', 'Country' ) );
	foreach ( $map as $k => $d ) {
		$opts = MRSH_Match::options( $d[0] );
		if ( ! $opts ) {
			continue;
		}
		echo '<label>' . esc_html( $d[1] ) . ' (leave empty for any)</label><select name="pf[' . esc_attr( $k ) . '][]" multiple size="4">';
		foreach ( $opts as $o ) {
			echo '<option' . selected( in_array( $o, (array) ( $pf[ $k ] ?? array() ), true ), true, false ) . '>' . esc_html( $o ) . '</option>';
		}
		echo '</select>';
	}
	echo '<p><label><input type="checkbox" style="width:auto" name="digest" value="1"' . checked( ! isset( $pf['digest'] ) || $pf['digest'], true, false ) . '> Email me new matches once a week</label></p><button class="btn">Save</button></form>';
}
if ( 'home' === $tab ) {
	// Boxes added by other tools (payment proof, selfie check, calendar, invite...) now sit inside the page, in a tidy grid.
	ob_start();
	do_action( 'mrt_account_extra', get_current_user_id() );
	$mrt_x = trim( (string) ob_get_clean() );
	if ( '' !== $mrt_x ) {
		echo '<h2 class="sec">More tools</h2><div class="acx">' . $mrt_x . '</div>'; // phpcs:ignore
	}
}
echo '</div></main>';
echo mrt_account_icons( (string) ob_get_clean() ); // phpcs:ignore
echo '<script>(function(){var m=document.querySelector("main.acct");if(!m)return;function fmt(n){return n>1048576?(n/1048576).toFixed(1)+" MB":Math.round(n/1024)+" KB"}m.addEventListener("change",function(e){var i=e.target;if(!i||i.type!=="file")return;var o=i.parentNode.querySelector(".upl[data-for=\""+(i.name||"f")+"\"]");if(o)o.remove();var f=i.files&&i.files[0];if(!f)return;var d=document.createElement("div");d.className="upl";d.setAttribute("data-for",i.name||"f");var h="";if(f.type.indexOf("image/")===0){var im=document.createElement("img");im.alt="";im.src=URL.createObjectURL(f);d.appendChild(im)}var t=document.createElement("div");t.innerHTML="<b></b><small></small>";t.firstChild.textContent=f.name;t.lastChild.textContent=fmt(f.size)+(f.size>3145728?" - big, it may be refused (limit 3 MB for pictures)":" - ready to send");d.appendChild(t);i.insertAdjacentElement("afterend",d)});["dragover","dragenter"].forEach(function(n){m.addEventListener(n,function(e){if(e.target.type==="file")e.target.classList.add("drag")})});["dragleave","drop"].forEach(function(n){m.addEventListener(n,function(e){if(e.target.type==="file")e.target.classList.remove("drag")})})})();</script>';
if ( is_readable( __DIR__ . '/assets/ms.js' ) ) {
	echo '<script>' . file_get_contents( __DIR__ . '/assets/ms.js' ) . '</script>'; // phpcs:ignore
}
get_footer();
