<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
mrt_page_hero( 'Page not found', 'This page is not here, but your rishta may be one search away.', 'search', 'Not found' );
$cta = mrt_cta();
?>
<main class="pg"><div class="wrap narrow">
	<div class="card2"><?php mrt_search_form( true ); ?></div>
	<div class="feats">
		<a class="feat" style="text-decoration:none;color:inherit" href="<?php echo esc_url( home_url( '/' ) ); ?>"><span class="ib b1"><?php echo mrt_icon( 'home' ); // phpcs:ignore ?></span><b>Home</b><p>Start again from the front page.</p></a>
		<a class="feat" style="text-decoration:none;color:inherit" href="<?php echo esc_url( home_url( '/?post_type=listing_type&s=' ) ); ?>"><span class="ib b2"><?php echo mrt_icon( 'search' ); // phpcs:ignore ?></span><b>Search profiles</b><p>Find a rishta by city, age or education.</p></a>
		<a class="feat" style="text-decoration:none;color:inherit" href="<?php echo esc_url( $cta[1] ); ?>"><span class="ib b3"><?php echo mrt_icon( $cta[2] ); // phpcs:ignore ?></span><b><?php echo esc_html( $cta[0] ); ?></b><p>Free and takes three minutes.</p></a>
		<a class="feat" style="text-decoration:none;color:inherit" href="<?php echo esc_url( mrt_link( 'contact', '/contact/' ) ); ?>"><span class="ib b4"><?php echo mrt_icon( 'chat' ); // phpcs:ignore ?></span><b>Contact us</b><p>Tell us what you were looking for.</p></a>
	</div>
</div></main>
<?php get_footer();
