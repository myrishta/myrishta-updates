<?php
if ( ! function_exists( 'mrsh_upgrade' ) ) {
if ( ! function_exists( 'mrsh_register_meta' ) ) {
if ( ! function_exists( 'mrsh_maybe_flush' ) ) {
/**
 * Plugin Name:       MyRishta Admin
 * Plugin URI:        https://myrishta.pk
 * Description:       Everything that runs myrishta.pk behind the scenes: member tools, safety, mail, SEO (titles, descriptions, canonical, Open Graph, schema, sitemap), noindex rules, search-engine verification and IndexNow. Works on its own or beside another SEO plugin.
 * Version: 3.101.362
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            MyRishta
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       myrishta-seo-helper
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( defined( 'MRSH_FILE' ) ) {
	// A second copy of this plugin is active. Do nothing and tell the admin.
	add_action( 'admin_notices', function () {
		if ( current_user_can( 'manage_options' ) ) {
			echo '<div class="notice notice-error"><p><b>My Rishta:</b> two copies of the plugin are active. Deactivate and delete the older one under Plugins. The website keeps working with the first copy.</p></div>';
		}
	} );
	return;
}

define( 'MRSH_VERSION', '3.101.362' );
define( 'MRSH_FILE', __FILE__ );
define( 'MRSH_DIR', plugin_dir_path( __FILE__ ) );
define( 'MRSH_URL', plugin_dir_url( __FILE__ ) );

require_once MRSH_DIR . 'includes/class-safe.php';
MRSH_Safe::init();

require_once MRSH_DIR . 'includes/class-license.php';
if ( ! MRSH_License::ok() ) {
	return; // Not licensed: everything stays off except the license page.
}

MRSH_Safe::load( 'includes/class-options.php' );
MRSH_Safe::load( 'includes/class-frontend.php' );
MRSH_Safe::load( 'includes/class-keywords.php' );
MRSH_Safe::load( 'includes/class-checks.php' );
MRSH_Safe::load( 'includes/class-meta.php' );
MRSH_Safe::load( 'includes/class-clean.php' );
MRSH_Safe::load( 'includes/class-speed.php' );
MRSH_Safe::load( 'includes/class-tools.php' );
MRSH_Safe::load( 'includes/class-whatsapp.php' );
MRSH_Safe::load( 'includes/class-twofactor.php' );
MRSH_Safe::load( 'includes/class-telegram.php' );
MRSH_Safe::load( 'includes/class-moderation.php' );
MRSH_Safe::load( 'includes/class-autokw.php' );
MRSH_Safe::load( 'includes/class-ai.php' );
MRSH_Safe::load( 'includes/class-smtp.php' );
MRSH_Safe::load( 'includes/class-mailq.php' );
MRSH_Safe::load( 'includes/class-relay.php' );
MRSH_Safe::load( 'includes/class-autoalt.php' );
MRSH_Safe::load( 'includes/class-tablekit.php' );
MRSH_Safe::load( 'includes/class-watermark.php' );
MRSH_Safe::load( 'includes/class-digest.php' );
MRSH_Safe::load( 'includes/class-nudge.php' );
MRSH_Safe::load( 'includes/class-verified.php' );
MRSH_Safe::load( 'includes/class-details.php' );
MRSH_Safe::load( 'includes/class-images.php' );
MRSH_Safe::load( 'includes/class-hub.php' );
MRSH_Safe::load( 'includes/class-report.php' );
MRSH_Safe::load( 'includes/class-data.php' );
MRSH_Safe::load( 'includes/class-home.php' );
MRSH_Safe::load( 'includes/class-easy.php' );
MRSH_Safe::load( 'includes/class-agent.php' );
MRSH_Safe::load( 'includes/class-psi.php' );
MRSH_Safe::load( 'includes/class-fixes.php' );
MRSH_Safe::load( 'includes/class-live.php' );
MRSH_Safe::load( 'includes/class-audit.php' );
MRSH_Safe::load( 'includes/class-pk.php' );
MRSH_Safe::load( 'includes/class-standalone.php' );
MRSH_Safe::load( 'includes/class-indexnow.php' );
MRSH_Safe::load( 'includes/class-browse.php' );
MRSH_Safe::load( 'includes/class-discovery.php' );
MRSH_Safe::load( 'includes/class-autoscan.php' );
MRSH_Safe::load( 'includes/class-backup.php' );
MRSH_Safe::load( 'includes/class-brand.php' );
MRSH_Safe::load( 'includes/class-watchdog.php' );
MRSH_Safe::load( 'includes/class-engage.php' );
MRSH_Safe::load( 'includes/class-bundle.php' );
MRSH_Safe::load( 'includes/class-admin.php' );

/** One-time settings upgrade for this version. */
function mrsh_upgrade() {
	if ( get_option( 'mrsh_ver' ) === MRSH_VERSION ) {
		return;
	}
	$o = get_option( 'mrsh_options', array() );
	if ( is_array( $o ) && $o ) {
		// Homepage title/description: lead with "online rishta" (the main search phrase), only if still on an old default.
		$old_t = array( 'Free Rishta in Pakistan | MyRishta.pk Matrimonial Service', 'Free Rishta Online in Pakistan | MyRishta.pk', 'Online Rishta in Pakistan: Free Rishta Website | MyRishta.pk' );
		if ( isset( $o['meta_title_home'] ) && in_array( $o['meta_title_home'], $old_t, true ) ) {
			$o['meta_title_home'] = 'Online Rishta in Pakistan | Free Rishta Lahore & Islamabad';
		}
		if ( isset( $o['meta_desc_home'] ) && ( 0 === strpos( $o['meta_desc_home'], 'Free rishta website for Pakistani families.' ) || $o['meta_desc_home'] === 'Online rishta in Pakistan, free for every family. Search by city, profession and community, including rishta abroad. Register free and connect safely.' ) ) {
			$o['meta_desc_home'] = 'Online rishta service in Pakistan, free for every family. Find rishta in Lahore, Karachi, Islamabad, Rawalpindi and abroad. Register free, connect safely.';
		}
		if ( empty( $o['noindex_taxonomies'] ) ) {
			$o['noindex_taxonomies'] = 'dagender,dasexuality,dathnicity,daeyes,dahair,dabody,dasmoke,dadrink,features,dahairlength';
		}
		// Profile categories ("listing") redirect to the login page, and tag archives duplicate each other: keep both out of Google and the sitemap.
		$tx = array_filter( array_map( 'trim', explode( ',', (string) $o['noindex_taxonomies'] ) ) );
		$o['noindex_taxonomies'] = implode( ',', array_unique( array_merge( $tx, array( 'listing', 'post_tag' ) ) ) );
		if ( empty( $o['noindex_post_types'] ) || 'listing' === $o['noindex_post_types'] ) {
			$o['noindex_post_types'] = 'listing_type';
		}
		// The theme's profile type is listing_type; a separate "listing" type does not exist here.
		$o['noindex_post_types'] = implode( ',', array_diff( array_map( 'trim', explode( ',', (string) $o['noindex_post_types'] ) ), array( 'listing' ) ) );
		// Earlier versions kept web addresses with the punctuation stripped as codes.
		foreach ( array( 'google', 'bing', 'yandex', 'baidu', 'naver', 'seznam', 'pinterest', 'facebook' ) as $e ) {
			$k = $e . '_verification';
			if ( ! empty( $o[ $k ] ) && ( 0 === strpos( $o[ $k ], 'https' ) || 'txt' === substr( $o[ $k ], -3 ) ) ) {
				$o[ $k ] = '';
			}
		}
		// Smaller uploads by default: compress, 1200 px wide, quality 75 (only if still on the old defaults).
		if ( empty( $o['img_compress'] ) ) {
			$o['img_compress'] = 1;
		}
		if ( ! isset( $o['img_quality'] ) || 82 === (int) $o['img_quality'] ) {
			$o['img_quality'] = 75;
		}
		if ( ! isset( $o['img_max'] ) || 2000 === (int) $o['img_max'] ) {
			$o['img_max'] = 1200;
		}
		// Real /favicon.ico file: the web server answers this address itself, so WordPress never sees it.
		if ( ! file_exists( ABSPATH . 'favicon.ico' ) && is_writable( ABSPATH ) && file_exists( MRSH_DIR . 'assets/favicon.ico' ) ) {
			@copy( MRSH_DIR . 'assets/favicon.ico', ABSPATH . 'favicon.ico' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
		// Organization details for the structured data (name, phone, email).
		if ( empty( $o['org_name'] ) ) {
			$o['org_name'] = 'My Rishta Pakistan';
		}
		if ( empty( $o['org_phone'] ) ) {
			$o['org_phone'] = '+92-42-29292921';
		}
		if ( empty( $o['org_email'] ) ) {
			$o['org_email'] = 'support@myrishta.pk';
		}
		if ( empty( $o['org_same_as'] ) ) {
			$o['org_same_as'] = 'https://www.facebook.com/share/1cJizhDBuk/';
		}
		$o['org_schema'] = 1;
		// AdSense publisher ID (from the owner's AdSense account page) so /ads.txt is served.
		if ( empty( $o['adsense_pub'] ) ) {
			$o['adsense_pub'] = 'pub-1537520006900860';
		}
		// Bing is verified by importing the site from Search Console, so no Bing meta code is needed.
		$o['bing_verified_other'] = 1;
		// Home title: the old default pulled in the long site name and was cut off in Google.
		if ( ! isset( $o['meta_title_home'] ) || false !== strpos( $o['meta_title_home'], '%sitename%' ) || strlen( $o['meta_title_home'] ) > 65 ) {
			$o['meta_title_home'] = 'Free Rishta in Pakistan | MyRishta.pk Matrimonial Service';
		}
		update_option( 'mrsh_options', $o );
	}
	update_option( 'mrsh_ver', MRSH_VERSION, false );
}
}

/** Let the editor, REST API and assistants set per-page SEO fields. */
function mrsh_register_meta() {
	$types = array_merge( array( 'post', 'page' ), array_values( get_post_types( array( 'public' => true, '_builtin' => false ) ) ) );
	foreach ( $types as $type ) {
		foreach ( array( '_mrsh_title', '_mrsh_desc', '_mrsh_focus' ) as $key ) {
			register_post_meta( $type, $key, array(
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => function () {
					return current_user_can( 'edit_posts' );
				},
			) );
		}
		register_post_meta( $type, '_mrsh_noindex', array(
			'type'              => 'string',
			'single'            => true,
			'show_in_rest'      => true,
			'sanitize_callback' => function ( $v ) {
				return $v ? '1' : '';
			},
			'auth_callback'     => function () {
				return current_user_can( 'edit_posts' );
			},
		) );
	}
}
}
add_action( 'init', 'mrsh_register_meta', 20 );

/** Rebuild permalinks once after each plugin update (same as Settings > Permalinks > Save). */
function mrsh_maybe_flush() {
	if ( get_option( 'mrsh_flushed_ver' ) !== MRSH_VERSION ) {
		flush_rewrite_rules( false );
		update_option( 'mrsh_flushed_ver', MRSH_VERSION, false );
	}
}
}
add_action( 'wp_loaded', 'mrsh_maybe_flush', 99 );

if ( ! function_exists( 'mrsh_boot' ) ) {
function mrsh_boot() {
	try {
		mrsh_upgrade();
	} catch ( \Throwable $e ) {
		MRSH_Safe::log_ex( $e, 'upgrade' );
	}
	MRSH_Safe::call( 'MRSH_Frontend', 'init' );
	MRSH_Safe::call( 'MRSH_IndexNow', 'init' );
	MRSH_Safe::call( 'MRSH_Browse', 'init' );
	MRSH_Safe::call( 'MRSH_Meta', 'init' );
	MRSH_Safe::call( 'MRSH_Clean', 'init' );
	MRSH_Safe::call( 'MRSH_Tools', 'early' );
	MRSH_Safe::call( 'MRSH_Speed', 'init' );
	MRSH_Safe::call( 'MRSH_Brand', 'init' );
	MRSH_Safe::call( 'MRSH_Tools', 'init' );
	MRSH_Safe::call( 'MRSH_WhatsApp', 'init' );
	MRSH_Safe::call( 'MRSH_Telegram', 'init' );
	MRSH_Safe::call( 'MRSH_Moderation', 'init' );
	MRSH_Safe::call( 'MRSH_AutoKW', 'init' );
	MRSH_Safe::call( 'MRSH_AI', 'init' );
	MRSH_Safe::call( 'MRSH_Smtp', 'init' );
	MRSH_Safe::call( 'MRSH_Mailq', 'init' );
	MRSH_Safe::call( 'MRSH_Nudge', 'init' );
	MRSH_Safe::call( 'MRSH_TwoFactor', 'init' );
	MRSH_Safe::call( 'MRSH_Verified', 'init' );
	MRSH_Safe::call( 'MRSH_Details', 'init' );
	MRSH_Safe::call( 'MRSH_Images', 'init' );
	MRSH_Safe::call( 'MRSH_Hub', 'init' );
	MRSH_Safe::call( 'MRSH_Report', 'init' );
	MRSH_Safe::call( 'MRSH_Data', 'init' );
	MRSH_Safe::call( 'MRSH_Home', 'init' );
	MRSH_Safe::call( 'MRSH_Easy', 'init' );
	MRSH_Safe::call( 'MRSH_Agent', 'init' );
	MRSH_Safe::call( 'MRSH_PSI', 'init' );
	MRSH_Safe::call( 'MRSH_Fixes', 'init' );
	MRSH_Safe::call( 'MRSH_Live', 'init' );
	MRSH_Safe::call( 'MRSH_Audit', 'init' );
	MRSH_Safe::call( 'MRSH_Standalone', 'init' );
	MRSH_Safe::call( 'MRSH_Discovery', 'init' );
	MRSH_Safe::call( 'MRSH_Backup', 'init' );
	MRSH_Safe::call( 'MRSH_Admin', 'init' );
	MRSH_Safe::finish_scan();
}
}
add_action( 'plugins_loaded', 'mrsh_boot' );

register_deactivation_hook( __FILE__, function () {
	wp_clear_scheduled_hook( 'mrsh_weekly_scan' );
} );

/** After every update, clear the page cache once so visitors never see pages built by the old version. */
add_action( 'admin_init', function () {
	if ( defined( 'MRSH_VERSION' ) && get_option( 'mrsh_cache_ver' ) !== MRSH_VERSION ) {
		update_option( 'mrsh_cache_ver', MRSH_VERSION, false );
		do_action( 'litespeed_purge_all' );
		if ( function_exists( 'wp_cache_flush' ) ) {
			wp_cache_flush();
		}
	}
} );
