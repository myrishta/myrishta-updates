<?php
/**
 * Auto updater for this plugin and the MyRishta theme. No extra plugin is needed.
 *
 * The site reads a small manifest (update.json) from a web address, shows a normal WordPress update for the plugin and the
 * theme, and installs it by itself when "Install updates automatically" is on. Every zip is checked before it is installed:
 * the address must be on the allowed list, the SHA-256 must match, and the Ed25519 signature must match the public key
 * built into this plugin. A stolen link or a changed file therefore cannot install code on the site.
 * Before each install a zip copy of the old version is kept in wp-content/mrsh-updates so it can be restored with one button.
 *
 * Options: mrsh_upd (url, auto), mrsh_upd_state (last check), mrsh_upd_log (last events). Transient: mrsh_upd_man (manifest).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Updater {

	const OPT   = 'mrsh_upd';
	const STATE = 'mrsh_upd_state';
	const LOG   = 'mrsh_upd_log';
	const MAN   = 'mrsh_upd_man';
	const PK    = 'EYiPeVjuIVfA9iB5nAJR/0lwPHDRNASDM2t0v4yDqWQ=';
	const THEME = 'myrishta';
	const SLUG  = 'myrishta-seo-helper';

	public static function o( $k = null ) {
		$o = array_merge( array( 'url' => 'https://raw.githubusercontent.com/myrishta/myrishta-updates/main/update.json', 'auto' => 1, 'keep' => 2 ), (array) get_option( self::OPT, array() ) );
		return null === $k ? $o : ( $o[ $k ] ?? null );
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 32 );
		foreach ( array( 'save', 'check', 'install', 'restore' ) as $a ) {
			add_action( 'admin_post_mrsh_upd_' . $a, array( __CLASS__, $a ) );
		}
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'inject_plugin' ) );
		add_filter( 'pre_set_site_transient_update_themes', array( __CLASS__, 'inject_theme' ) );
		add_filter( 'upgrader_pre_download', array( __CLASS__, 'verify' ), 10, 3 );
		add_filter( 'auto_update_plugin', array( __CLASS__, 'auto_plugin' ), 20, 2 );
		add_filter( 'auto_update_theme', array( __CLASS__, 'auto_theme' ), 20, 2 );
		add_action( 'mrsh_upd_tick', array( __CLASS__, 'tick' ) );
		add_action( 'upgrader_process_complete', array( __CLASS__, 'after' ), 99, 2 );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Auto updates', 'Auto updates', 'manage_options', 'mrsh-upd', array( __CLASS__, 'page' ) );
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( 'mrsh_upd_tick' ) ) {
			wp_schedule_event( time() + 600, 'twicedaily', 'mrsh_upd_tick' );
		}
	}

	/* ---------------------------------------------------------------- helpers */
	private static function plugin_file() {
		return plugin_basename( MRSH_FILE );
	}

	private static function theme_version() {
		$t = wp_get_theme( self::THEME );
		return $t->exists() ? (string) $t->get( 'Version' ) : '';
	}

	private static function host_ok( $url ) {
		$p = wp_parse_url( (string) $url );
		if ( empty( $p['scheme'] ) || 'https' !== $p['scheme'] || empty( $p['host'] ) ) {
			return false;
		}
		$h = strtolower( $p['host'] );
		return in_array( $h, array( 'github.com', 'raw.githubusercontent.com', 'myrishta.pk', 'www.myrishta.pk' ), true ) || ( strlen( $h ) > 22 && '.githubusercontent.com' === substr( $h, -22 ) );
	}

	private static function log( $msg, $ok = true ) {
		$l   = (array) get_option( self::LOG, array() );
		$l[] = array( time(), $ok ? 1 : 0, $msg );
		update_option( self::LOG, array_slice( $l, -25 ), false );
	}

	private static function message( $kind, $ver, $sha ) {
		return 'myrishta-update|' . $kind . '|' . $ver . '|' . $sha;
	}

	/** Read the manifest. Returns array( plugin => array, theme => array ) or WP_Error. Cached for one hour. */
	public static function manifest( $force = false ) {
		if ( ! $force ) {
			$c = get_transient( self::MAN );
			if ( is_array( $c ) ) {
				return $c;
			}
		}
		$url = (string) self::o( 'url' );
		if ( ! self::host_ok( $url ) ) {
			return new WP_Error( 'mrsh_upd', 'The update address must start with https:// and be on GitHub or myrishta.pk.' );
		}
		$r = wp_remote_get( add_query_arg( 't', floor( time() / 300 ), $url ), array( 'timeout' => 15 ) );
		if ( is_wp_error( $r ) ) {
			return new WP_Error( 'mrsh_upd', 'Could not reach the update address: ' . $r->get_error_message() );
		}
		if ( 200 !== (int) wp_remote_retrieve_response_code( $r ) ) {
			return new WP_Error( 'mrsh_upd', 'The update address answered ' . (int) wp_remote_retrieve_response_code( $r ) . '. Check that the file update.json exists there.' );
		}
		$j = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( ! is_array( $j ) ) {
			return new WP_Error( 'mrsh_upd', 'The update file is not valid.' );
		}
		$out = array();
		foreach ( array( 'plugin', 'theme' ) as $k ) {
			$m = $j[ $k ] ?? null;
			if ( ! is_array( $m ) || empty( $m['version'] ) || empty( $m['zip'] ) || empty( $m['sha256'] ) || empty( $m['sig'] ) ) {
				continue;
			}
			if ( ! preg_match( '/^\d+(\.\d+){1,3}$/', (string) $m['version'] ) || ! preg_match( '/^[a-f0-9]{64}$/', (string) $m['sha256'] ) || ! self::host_ok( $m['zip'] ) ) {
				continue;
			}
			$out[ $k ] = array( 'version' => (string) $m['version'], 'zip' => (string) $m['zip'], 'sha256' => (string) $m['sha256'], 'sig' => (string) $m['sig'], 'notes' => isset( $m['notes'] ) ? sanitize_text_field( (string) $m['notes'] ) : '' );
		}
		set_transient( self::MAN, $out, HOUR_IN_SECONDS );
		return $out;
	}

	/** Which updates are waiting. Returns array( plugin => array|null, theme => array|null ). */
	public static function pending( $force = false ) {
		$m = self::manifest( $force );
		if ( is_wp_error( $m ) ) {
			return $m;
		}
		$r = array( 'plugin' => null, 'theme' => null );
		if ( isset( $m['plugin'] ) && version_compare( $m['plugin']['version'], MRSH_VERSION, '>' ) ) {
			$r['plugin'] = $m['plugin'];
		}
		if ( isset( $m['theme'] ) && self::theme_version() && version_compare( $m['theme']['version'], self::theme_version(), '>' ) ) {
			$r['theme'] = $m['theme'];
		}
		return $r;
	}

	/* ---------------------------------------------------------------- WordPress update hooks */
	public static function inject_plugin( $t ) {
		if ( ! is_object( $t ) ) {
			return $t;
		}
		$p = self::pending();
		if ( is_wp_error( $p ) || empty( $p['plugin'] ) ) {
			return $t;
		}
		$f = self::plugin_file();
		$t->response[ $f ] = (object) array(
			'id'          => 'mrsh-updater/' . self::SLUG,
			'slug'        => self::SLUG,
			'plugin'      => $f,
			'new_version' => $p['plugin']['version'],
			'url'         => home_url( '/' ),
			'package'     => $p['plugin']['zip'],
		);
		unset( $t->no_update[ $f ] );
		return $t;
	}

	public static function inject_theme( $t ) {
		if ( ! is_object( $t ) ) {
			return $t;
		}
		$p = self::pending();
		if ( is_wp_error( $p ) || empty( $p['theme'] ) ) {
			return $t;
		}
		$t->response[ self::THEME ] = array( 'theme' => self::THEME, 'new_version' => $p['theme']['version'], 'url' => home_url( '/' ), 'package' => $p['theme']['zip'] );
		unset( $t->no_update[ self::THEME ] );
		return $t;
	}

	public static function auto_plugin( $update, $item ) {
		if ( is_object( $item ) && isset( $item->plugin ) && self::plugin_file() === $item->plugin ) {
			return ! empty( self::o( 'auto' ) );
		}
		return $update;
	}

	public static function auto_theme( $update, $item ) {
		if ( is_object( $item ) && isset( $item->theme ) && self::THEME === $item->theme ) {
			return ! empty( self::o( 'auto' ) );
		}
		return $update;
	}

	/** Every zip that comes from our manifest is downloaded here and checked. Anything that does not pass is refused. */
	public static function verify( $reply, $package, $upgrader = null ) {
		if ( false !== $reply ) {
			return $reply;
		}
		$m = get_transient( self::MAN );
		if ( ! is_array( $m ) ) {
			return $reply;
		}
		$kind = '';
		foreach ( array( 'plugin', 'theme' ) as $k ) {
			if ( isset( $m[ $k ] ) && $m[ $k ]['zip'] === $package ) {
				$kind = $k;
			}
		}
		if ( ! $kind ) {
			return $reply;
		}
		$e = $m[ $kind ];
		if ( ! function_exists( 'download_url' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$tmp = download_url( $package, 300 );
		if ( is_wp_error( $tmp ) ) {
			self::log( 'Download failed: ' . $tmp->get_error_message(), false );
			return $tmp;
		}
		$fail = function ( $why ) use ( $tmp, $kind ) {
			wp_delete_file( $tmp );
			self::log( 'Refused the ' . $kind . ' update: ' . $why, false );
			return new WP_Error( 'mrsh_upd_bad', 'The ' . $kind . ' update was refused: ' . $why );
		};
		if ( ! hash_equals( $e['sha256'], (string) hash_file( 'sha256', $tmp ) ) ) {
			return $fail( 'the file does not match its checksum.' );
		}
		$sig = base64_decode( $e['sig'], true ); // phpcs:ignore
		$pk  = base64_decode( self::PK, true ); // phpcs:ignore
		if ( ! $sig || ! $pk || ! function_exists( 'sodium_crypto_sign_verify_detached' ) || ! sodium_crypto_sign_verify_detached( $sig, self::message( $kind, $e['version'], $e['sha256'] ), $pk ) ) {
			return $fail( 'the signature is not valid.' );
		}
		$top = 'plugin' === $kind ? self::SLUG . '/' : self::THEME . '/';
		if ( ! class_exists( 'ZipArchive' ) ) {
			return $fail( 'the server cannot read zip files.' );
		}
		$z = new ZipArchive();
		if ( true !== $z->open( $tmp ) || $z->numFiles < 3 ) {
			return $fail( 'the zip cannot be opened.' );
		}
		for ( $i = 0; $i < $z->numFiles; $i++ ) {
			$n = (string) $z->getNameIndex( $i );
			if ( 0 !== strpos( $n, $top ) || false !== strpos( $n, '..' ) ) {
				$z->close();
				return $fail( 'the zip has the wrong folder layout.' );
			}
		}
		$z->close();
		self::log( 'Checked the ' . $kind . ' zip ' . $e['version'] . ': checksum and signature are correct.' );
		return $tmp;
	}

	/* ---------------------------------------------------------------- checking and installing */
	public static function tick() {
		$p = self::pending( true );
		self::remember( $p );
		if ( is_wp_error( $p ) || ( empty( $p['plugin'] ) && empty( $p['theme'] ) ) ) {
			return;
		}
		if ( function_exists( 'wp_update_plugins' ) ) {
			wp_update_plugins();
			wp_update_themes();
		}
		if ( ! empty( self::o( 'auto' ) ) ) {
			do_action( 'wp_maybe_auto_update' );
		}
	}

	private static function remember( $p ) {
		$s = array( 'time' => time(), 'ok' => ! is_wp_error( $p ), 'msg' => is_wp_error( $p ) ? $p->get_error_message() : '', 'plugin' => is_wp_error( $p ) || empty( $p['plugin'] ) ? '' : $p['plugin']['version'], 'theme' => is_wp_error( $p ) || empty( $p['theme'] ) ? '' : $p['theme']['version'] );
		update_option( self::STATE, $s, false );
		if ( is_wp_error( $p ) ) {
			self::log( 'Check failed: ' . $p->get_error_message(), false );
		}
	}

	private static function guard( $n ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( $n );
	}

	private static function back( $m ) {
		wp_safe_redirect( add_query_arg( 'msg', rawurlencode( $m ), admin_url( 'admin.php?page=mrsh-upd' ) ) );
		exit;
	}

	public static function save() {
		self::guard( 'mrsh_upd_save' );
		$o        = self::o();
		$u        = isset( $_POST['url'] ) ? esc_url_raw( trim( wp_unslash( $_POST['url'] ) ) ) : ''; // phpcs:ignore
		$o['url'] = self::host_ok( $u ) ? $u : $o['url'];
		$o['auto'] = empty( $_POST['auto'] ) ? 0 : 1; // phpcs:ignore
		$o['keep'] = isset( $_POST['keep'] ) ? max( 0, min( 5, (int) $_POST['keep'] ) ) : 2; // phpcs:ignore
		self::prune( 'plugin', $o['keep'] );
		self::prune( 'theme', $o['keep'] );
		update_option( self::OPT, $o, false );
		delete_transient( self::MAN );
		self::back( self::host_ok( $u ) ? 'Saved.' : 'Saved. The address was not allowed, so the old address was kept (it must start with https:// and be on GitHub or myrishta.pk).' );
	}

	public static function check() {
		self::guard( 'mrsh_upd_check' );
		$p = self::pending( true );
		self::remember( $p );
		if ( is_wp_error( $p ) ) {
			self::back( $p->get_error_message() );
		}
		if ( function_exists( 'wp_update_plugins' ) ) {
			wp_update_plugins();
			wp_update_themes();
		}
		self::back( ( $p['plugin'] || $p['theme'] ) ? 'An update is ready. Press Install now.' : 'You are on the newest version.' );
	}

	/** Zip copy of the folder that is about to be replaced. Keeps the newest two per kind. */
	/** Keep only the newest $keep backup zips of one kind and delete the rest (0 = delete them all). */
	private static function prune( $kind, $keep ) {
		$all = glob( WP_CONTENT_DIR . '/mrsh-updates/' . $kind . '-*.zip' );
		if ( ! $all || count( $all ) <= $keep ) {
			return;
		}
		usort( $all, function ( $a, $b ) { return filemtime( $a ) - filemtime( $b ); } );
		foreach ( array_slice( $all, 0, count( $all ) - $keep ) as $old ) {
			wp_delete_file( $old );
		}
	}

	/** After a finished update of this plugin or theme: apply the "old versions to keep" setting. */
	public static function after( $upgrader, $info ) {
		if ( empty( $info['type'] ) || empty( $info['action'] ) || 'update' !== $info['action'] ) {
			return;
		}
		$keep = (int) self::o( 'keep' );
		if ( 'plugin' === $info['type'] && ! empty( $info['plugins'] ) && in_array( self::SLUG . '/' . self::SLUG . '.php', (array) $info['plugins'], true ) ) {
			self::prune( 'plugin', $keep );
		} elseif ( 'theme' === $info['type'] && ! empty( $info['themes'] ) && in_array( self::THEME, (array) $info['themes'], true ) ) {
			self::prune( 'theme', $keep );
		}
	}

	private static function backup( $kind ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return false;
		}
		$src = 'plugin' === $kind ? WP_PLUGIN_DIR . '/' . self::SLUG : get_theme_root() . '/' . self::THEME;
		if ( ! is_dir( $src ) ) {
			return false;
		}
		$dir = WP_CONTENT_DIR . '/mrsh-updates';
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
			file_put_contents( $dir . '/.htaccess', "Require all denied\nDeny from all\n" ); // phpcs:ignore
			file_put_contents( $dir . '/index.php', "<?php\n// Silence.\n" ); // phpcs:ignore
		}
		$ver  = 'plugin' === $kind ? MRSH_VERSION : self::theme_version();
		$file = $dir . '/' . $kind . '-' . $ver . '-' . time() . '.zip';
		$z    = new ZipArchive();
		if ( true !== $z->open( $file, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
			return false;
		}
		$top = basename( $src );
		$it  = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $src, FilesystemIterator::SKIP_DOTS ) );
		foreach ( $it as $f ) {
			if ( $f->isFile() ) {
				$z->addFile( $f->getPathname(), $top . '/' . substr( $f->getPathname(), strlen( $src ) + 1 ) );
			}
		}
		$z->close();
		self::prune( $kind, max( 1, (int) self::o( 'keep' ) ) ); // the copy just made always stays until the install has finished
		return $file;
	}

	public static function install() {
		self::guard( 'mrsh_upd_install' );
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		require_once ABSPATH . 'wp-admin/includes/misc.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		require_once ABSPATH . 'wp-admin/includes/update.php';
		$p = self::pending( true );
		self::remember( $p );
		if ( is_wp_error( $p ) ) {
			self::back( $p->get_error_message() );
		}
		if ( empty( $p['plugin'] ) && empty( $p['theme'] ) ) {
			self::back( 'You are already on the newest version.' );
		}
		wp_update_plugins();
		wp_update_themes();
		$done = array();
		if ( ! empty( $p['theme'] ) ) {
			self::backup( 'theme' );
			$up = new Theme_Upgrader( new Automatic_Upgrader_Skin() );
			$r  = $up->upgrade( self::THEME );
			if ( true === $r || ( is_array( $r ) && ! is_wp_error( $r ) ) ) {
				$done[] = 'Theme ' . $p['theme']['version'] . ' installed.';
				self::log( 'Theme updated to ' . $p['theme']['version'] . '.' );
			} else {
				$done[] = 'The theme update did not install' . ( is_wp_error( $r ) ? ': ' . $r->get_error_message() : '.' );
				self::log( end( $done ), false );
			}
		}
		if ( ! empty( $p['plugin'] ) ) {
			self::backup( 'plugin' );
			$f  = self::plugin_file();
			$was = is_plugin_active( $f );
			$up = new Plugin_Upgrader( new Automatic_Upgrader_Skin() );
			$r  = $up->upgrade( $f );
			if ( $was && ! is_plugin_active( $f ) ) {
				activate_plugin( $f, '', false, true );
			}
			if ( true === $r || ( is_array( $r ) && ! is_wp_error( $r ) ) ) {
				$done[] = 'Plugin ' . $p['plugin']['version'] . ' installed.';
				self::log( 'Plugin updated to ' . $p['plugin']['version'] . '.' );
			} else {
				$done[] = 'The plugin update did not install' . ( is_wp_error( $r ) ? ': ' . $r->get_error_message() : '.' );
				self::log( end( $done ), false );
			}
		}
		delete_transient( self::MAN );
		self::back( implode( ' ', $done ) );
	}

	public static function restore() {
		self::guard( 'mrsh_upd_restore' );
		require_once ABSPATH . 'wp-admin/includes/file.php';
		$name = isset( $_POST['file'] ) ? basename( sanitize_text_field( wp_unslash( $_POST['file'] ) ) ) : ''; // phpcs:ignore
		$zip  = WP_CONTENT_DIR . '/mrsh-updates/' . $name;
		if ( ! preg_match( '/^(plugin|theme)-[\d.]+-\d+\.zip$/', $name ) || ! is_file( $zip ) ) {
			self::back( 'That saved copy was not found.' );
		}
		$kind = 0 === strpos( $name, 'plugin' ) ? 'plugin' : 'theme';
		$dir  = 'plugin' === $kind ? WP_PLUGIN_DIR . '/' . self::SLUG : get_theme_root() . '/' . self::THEME;
		$hold = WP_CONTENT_DIR . '/mrsh-updates/replaced-' . $kind . '-' . time();
		if ( ! @rename( $dir, $hold ) ) { // phpcs:ignore
			self::back( 'Could not move the current ' . $kind . ' folder, so nothing was changed.' );
		}
		WP_Filesystem();
		$r = unzip_file( $zip, dirname( $dir ) );
		if ( is_wp_error( $r ) || ! is_dir( $dir ) ) {
			if ( is_dir( $dir ) ) {
				global $wp_filesystem;
				$wp_filesystem->delete( $dir, true );
			}
			@rename( $hold, $dir ); // phpcs:ignore
			self::log( 'Restore of ' . $name . ' failed; the current version was put back.', false );
			self::back( 'The restore failed, and the current version was put back.' );
		}
		global $wp_filesystem;
		$wp_filesystem->delete( $hold, true );
		self::log( 'Restored ' . $name . '.' );
		self::back( 'Restored ' . $name . '. Reload the page to see the older version.' );
	}

	/* ---------------------------------------------------------------- page */
	public static function page() {
		if ( ! current_user_can( 'manage_options' ) || ! class_exists( 'MRSH_Boost' ) ) {
			return;
		}
		$o  = self::o();
		$s  = (array) get_option( self::STATE, array() );
		$tv = self::theme_version();
		MRSH_Boost::ui_open( 'Auto updates', 'Updates for this plugin and the theme install by themselves from a safe link. Every file is checked before it is installed, and the old version is kept so you can go back.', 'g-blue', 'M12 3v12m0 0l-4-4m4 4l4-4M5 21h14' );
		if ( ! empty( $_GET['msg'] ) ) { // phpcs:ignore
			MRSH_Boost::ui_ok( sanitize_text_field( rawurldecode( wp_unslash( $_GET['msg'] ) ) ) ); // phpcs:ignore
		}
		$pn = ! empty( $s['plugin'] ) ? $s['plugin'] : '';
		$tn = ! empty( $s['theme'] ) ? $s['theme'] : '';
		echo '<div class="mx-stats">';
		echo MRSH_Boost::ui_stat( MRSH_VERSION, 'Plugin installed', $pn ? '#e11d74' : '#10b981' ); // phpcs:ignore
		echo MRSH_Boost::ui_stat( $tv ? $tv : '-', 'Theme installed', $tn ? '#e11d74' : '#10b981' ); // phpcs:ignore
		echo MRSH_Boost::ui_stat( ( $pn || $tn ) ? 'Update ready' : 'Up to date', $pn ? 'Plugin ' . $pn : ( $tn ? 'Theme ' . $tn : 'Nothing waiting' ), ( $pn || $tn ) ? '#f59e0b' : '#10b981' ); // phpcs:ignore
		echo MRSH_Boost::ui_stat( ! empty( $o['auto'] ) ? 'ON' : 'Off', 'Install by itself', ! empty( $o['auto'] ) ? '#10b981' : '#6b7280' ); // phpcs:ignore
		echo MRSH_Boost::ui_stat( ! empty( $s['time'] ) ? human_time_diff( (int) $s['time'] ) . ' ago' : 'never', 'Last check', '#4a69d6' ); // phpcs:ignore
		echo '</div>';
		if ( ! empty( $s['time'] ) && empty( $s['ok'] ) && ! empty( $s['msg'] ) ) {
			echo '<div class="mx-card" style="border-left:4px solid #e11d74"><p style="margin:0"><strong>The last check did not work.</strong> ' . esc_html( $s['msg'] ) . '</p></div>';
		}
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">1</span><h2>Check and install</h2></div><p class="mx-sub">The site checks twice a day. You can also check now and install with one press. The page tells you if an update is waiting.</p><div style="display:flex;gap:10px;flex-wrap:wrap">';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_upd_check">' . wp_nonce_field( 'mrsh_upd_check', '_wpnonce', true, false ) . '<button class="mx-btn">Check now</button></form>'; // phpcs:ignore
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_upd_install">' . wp_nonce_field( 'mrsh_upd_install', '_wpnonce', true, false ) . '<button class="mx-btn p"' . ( ( $pn || $tn ) ? '' : ' disabled' ) . '>Install now</button></form>'; // phpcs:ignore
		echo '</div></div>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_upd_save">' . wp_nonce_field( 'mrsh_upd_save', '_wpnonce', true, false ); // phpcs:ignore
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">2</span><h2>Settings</h2></div>';
		echo '<div class="mx-f"><label class="mx-sw"><input type="checkbox" name="auto" value="1"' . checked( ! empty( $o['auto'] ), true, false ) . '><span class="tr"></span><span class="lb">Install updates automatically</span></label></div>';
		echo '<div class="mx-f" style="margin-top:14px"><label class="t" for="kp">Old versions to keep after an update</label><select id="kp" name="keep">'; // phpcs:ignore
		foreach ( array( 0 => 'None - delete the old version once the update is done', 1 => 'Keep 1 (the version just replaced)', 2 => 'Keep 2', 3 => 'Keep 3' ) as $n => $lb ) {
			echo '<option value="' . (int) $n . '"' . selected( (int) $o['keep'], $n, false ) . '>' . esc_html( $lb ) . '</option>'; // phpcs:ignore
		}
		echo '</select><p class="mx-sub" style="margin:6px 0 0">Older zips are deleted automatically when a new update arrives. With None there is no Restore button, so keep at least 1 if you want a way back.</p></div>';
		echo '<div class="mx-f" style="margin-top:14px"><label class="t" for="uu">Update address (update.json)</label><input type="url" id="uu" name="url" value="' . esc_attr( $o['url'] ) . '" style="width:100%"><p class="mx-sub" style="margin:6px 0 0">Only https addresses on GitHub or myrishta.pk are accepted. Files must carry the MyRishta signature, otherwise they are refused.</p></div>';
		echo '<p style="margin:16px 0 0"><button class="mx-btn p">Save</button></p></div></form>';
		$files = glob( WP_CONTENT_DIR . '/mrsh-updates/*.zip' );
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">3</span><h2>Go back to an older version</h2></div>';
		if ( $files ) {
			usort( $files, function ( $a, $b ) { return filemtime( $b ) - filemtime( $a ); } );
			echo '<p class="mx-sub">A copy of the old version is saved before every update (the newest two are kept).</p>';
			foreach ( $files as $f ) {
				$n = basename( $f );
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:flex;align-items:center;gap:12px;margin:6px 0;flex-wrap:wrap"><input type="hidden" name="action" value="mrsh_upd_restore"><input type="hidden" name="file" value="' . esc_attr( $n ) . '">' . wp_nonce_field( 'mrsh_upd_restore', '_wpnonce', true, false ) . '<span>' . esc_html( $n ) . ' <small style="color:#6b7280">(' . esc_html( size_format( filesize( $f ) ) ) . ', ' . esc_html( wp_date( 'j M, g:i a', filemtime( $f ) ) ) . ')</small></span><button class="mx-btn">Restore this</button></form>'; // phpcs:ignore
			}
		} else {
			echo '<p class="mx-sub">No saved copy yet. One is made automatically before the first update.</p>';
		}
		echo '</div>';
		$log = array_reverse( (array) get_option( self::LOG, array() ) );
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">4</span><h2>What happened</h2></div>';
		if ( $log ) {
			foreach ( array_slice( $log, 0, 12 ) as $l ) {
				echo '<p style="margin:5px 0"><span style="color:#6b7280">' . esc_html( wp_date( 'j M, g:i a', (int) $l[0] ) ) . '</span> &nbsp;' . ( $l[1] ? '&#9989;' : '&#10060;' ) . ' ' . esc_html( $l[2] ) . '</p>';
			}
		} else {
			echo '<p class="mx-sub">Nothing yet.</p>';
		}
		echo '</div></div>';
	}
}
MRSH_Updater::init();
