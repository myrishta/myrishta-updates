<?php
/**
 * One tab bar on every screen of the plugin, and a short sidebar menu (5 entries instead of about 30).
 * Every page keeps its address; only the sidebar list is shortened.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Tabs {

	/** group => array( label, landing slug, array( slug => tab label ) ) */
	public static function groups() {
		return array(
			'home'    => array( 'Dashboard', 'myrishta-seo', array( 'myrishta-seo' => 'Dashboard', 'mrsh-inbox' => 'Inbox', 'mrsh-today' => 'Today', 'mrsh-search' => 'Search performance', 'mrsh-easy' => 'Easy setup', 'mrsh-problems' => 'Problems', 'mrsh-fresh' => 'New installation', 'mrsh-settings' => 'All settings', 'mrsh-switch' => 'Feature switches', 'mrsh-maint' => 'Maintenance mode', 'mrsh-upd' => 'Auto updates', 'mrsh-guide' => 'Admin guide', 'myrishta-seo-backup' => 'Backup and restore', 'mrsh-fullbackup' => 'Full backup (with pictures)', 'mrsh-delivery' => 'Email delivery', 'mrsh-relay' => 'Email backup senders', 'mrsh-digest' => 'Daily digest' ) ),
			'members' => array( 'Members and matches', 'mrsh-overview', array( 'mrsh-overview' => 'Overview', 'mrsh-queue' => 'Queue', 'mrsh-desk' => 'Member manager', 'mrsh-helpers' => 'Rishta Agencies', 'mrsh-guard' => 'Security and places', 'mrsh-shield' => 'Security Shield', 'mrsh-emtpl' => 'Email templates', 'mrmb' => 'Member boosters', 'mrsh-activity' => 'Activity log', 'mrsh-tickets' => 'Tickets', 'mrsh-profiles' => 'Profiles', 'mrsh-users' => 'Members', 'mrsh-msgs' => 'Messages', 'mrsh-matchdesk' => 'Match Desk', 'mrsh-clean' => 'Quality and safety', 'mrsh-orders' => 'Orders', 'mrsh-nudge' => 'Profile reminders', 'mrsh-photo-safety' => 'Photo safety', 'mrsh-reports' => 'Reports', 'mrsh-founding' => 'Founding members', 'mrsh-bounce' => 'Bounced emails', 'mrsh-fixer' => 'Auto-Fixer', 'mrsh-ai-hub' => 'AI Assistant', 'mrsh-secbot' => 'Security Robot', 'mrsh-matchrep' => 'Matches and report' ) ),
			'design'  => array( 'Design', 'mrsh-themeopts', array( 'mrsh-themeopts' => 'Theme Options', 'mrsh-site' => 'Look and content', 'mrsh-theme' => 'Theme and app', 'mrsh-photos' => 'Photos', 'mrsh-photodiag' => 'Photo diagnosis', 'mrsh-import' => 'Import content' ) ),
			'growth'  => array( 'Growth', 'mrsh-growth', array( 'mrsh-growth' => 'Growth tools', 'mrsh-ideas' => 'More tools', 'mrsh-places' => 'Place stories', 'mrsh-int' => 'Integrations', 'mrsh-social' => 'Social login', 'mrsh-autoads' => 'Auto ads', 'mrsh-gads' => 'Google Ads', 'mrsh-gbp' => 'Google Business Profile', 'mrsh-fix' => 'Broken addresses', 'mrsh-boost' => 'Growth boosters', 'mrsh-more2' => 'Extra features', 'mrsh-proofs' => 'Payment proofs', 'mrsh-checks' => 'Selfie and video checks', 'mrsh-photocheck' => 'Photo check', 'mrsh-logokit' => 'Logo kit', 'mrsh-adlinks' => 'Ad links', 'mrsh-agreement' => 'Agreement', 'mrsh-m3' => 'Redirects and replies' ) ),
			'site'    => array( 'Site settings', 'mrsh-mem', array( 'mrsh-brand' => 'Brand and names', 'mrsh-plans' => 'Membership plans', 'mrsh-pay' => 'Online payment', 'mrsh-mem' => 'Member settings', 'mrsh-keys' => 'Website keys', 'mrsh-mail' => 'Emails', 'mrsh-smtp' => 'Email (SMTP)', 'mrsh-mailq' => 'Email queue', 'mrsh-push' => 'Notifications', 'mrsh-whatsapp' => 'WhatsApp and Telegram', 'mrsh-sms' => 'SMS gateway', 'mrsh-dbtidy' => 'Database tidy', 'mrsh-2fa' => 'Login security', 'myrishta-ads' => 'Ads and app promotion', 'mrads-check' => 'Ads checkup' ) ),
			'seo'     => array( 'SEO and search', 'myrishta-seo-engines', array( 'myrishta-seo-engines' => 'Search engines', 'myrishta-seo-rules' => 'Rules', 'myrishta-seo-keywords' => 'Keywords', 'myrishta-seo-discover' => 'Discover', 'myrishta-seo-coverage' => 'Coverage', 'mrsh-pageopt' => 'Page Optimizer', 'mrsh-autokw' => 'Auto keywords', 'mrsh-ai' => 'AI visibility', 'mrsh-thin' => 'Thin content' ) ),
			'audit'   => array( 'Audit and speed', 'mrsh-audit', array( 'mrsh-audit' => 'Site audit', 'mrsh-psi' => 'PageSpeed', 'mrsh-cwv' => 'Speed agent', 'myrishta-seo-tools' => 'Speed tools', 'mrsh-live' => 'Live users' ) ),
		);
	}


	/** Outline icons (24x24, 1.8 stroke) */
	const S = array(
		'dashboard' => '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
		'inbox' => '<polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
		'today' => '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18M9 16l2 2 4-4"/>',
		'wand' => '<path d="m21.64 3.64-1.28-1.28a1.21 1.21 0 0 0-1.72 0L2.36 18.64a1.21 1.21 0 0 0 0 1.72l1.28 1.28a1.2 1.2 0 0 0 1.72 0L21.64 5.36a1.2 1.2 0 0 0 0-1.72z"/><path d="m14 7 3 3M5 6v4M19 14v4M10 2v2M7 8H3M21 16h-4M11 3H9"/>',
		'alert' => '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3z"/><path d="M12 9v4M12 17h.01"/>',
		'package' => '<path d="m7.5 4.27 9 5.15"/><path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><path d="m3.3 7 8.7 5 8.7-5M12 22V12"/>',
		'settings' => '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
		'toggle' => '<rect x="2" y="6" width="20" height="12" rx="6"/><circle cx="16" cy="12" r="2"/>',
		'book' => '<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
		'download' => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
		'archive' => '<rect x="2" y="3" width="20" height="5" rx="1"/><path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8M10 12h4"/>',
		'send' => '<path d="m22 2-7 20-4-9-9-4z"/><path d="M22 2 11 13"/>',
		'mail' => '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>',
		'users' => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
		'userc' => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="m16 11 2 2 4-4"/>',
		'chart' => '<path d="M3 3v18h18M18 17V9M13 17V5M8 17v-3"/>',
		'queue' => '<path d="m3 17 2 2 4-4M3 7l2 2 4-4M13 6h8M13 12h8M13 18h8"/>',
		'idcard' => '<rect x="2" y="5" width="20" height="14" rx="2"/><circle cx="8" cy="12" r="2"/><path d="M14 10h4M14 14h4"/>',
		'shield' => '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
		'file' => '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M16 13H8M16 17H8M10 9H8"/>',
		'heart' => '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7z"/>',
		'activity' => '<path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2"/>',
		'ticket' => '<path d="M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2z"/><path d="M13 5v2M13 17v2M13 11v2"/>',
		'message' => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
		'sparkles' => '<path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3z"/>',
		'receipt' => '<path d="M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1z"/><path d="M16 8h-6a2 2 0 1 0 0 4h4a2 2 0 1 1 0 4H8M12 17.5v-11"/>',
		'bell' => '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
		'camera' => '<path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3z"/><circle cx="12" cy="13" r="3"/>',
		'image' => '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.09-3.09a2 2 0 0 0-2.82 0L6 21"/>',
		'flag' => '<path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1zM4 22v-7"/>',
		'award' => '<circle cx="12" cy="8" r="6"/><path d="M15.48 12.89 17 22l-5-3-5 3 1.52-9.11"/>',
		'palette' => '<circle cx="13.5" cy="6.5" r=".6"/><circle cx="17.5" cy="10.5" r=".6"/><circle cx="8.5" cy="7.5" r=".6"/><circle cx="6.5" cy="12.5" r=".6"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.93 0 1.5-.75 1.5-1.5 0-.39-.15-.74-.39-1.04-.23-.29-.38-.63-.38-1.02 0-.83.67-1.5 1.5-1.5H16c3.31 0 6-2.69 6-6 0-4.96-4.49-9-10-9z"/>',
		'layout' => '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/>',
		'phone' => '<rect x="5" y="2" width="14" height="20" rx="2"/><path d="M12 18h.01"/>',
		'scan' => '<path d="M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2"/><circle cx="12" cy="12" r="3"/><path d="m16 16-1.9-1.9"/>',
		'import' => '<path d="M12 3v12M7 10l5 5 5-5M5 21h14"/>',
		'trend' => '<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>',
		'wrench' => '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94z"/>',
		'pin' => '<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/>',
		'plug' => '<path d="M12 22v-5M9 8V2M15 8V2M18 8v5a4 4 0 0 1-4 4h-4a4 4 0 0 1-4-4V8z"/>',
		'login' => '<path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4M10 17l5-5-5-5M15 12H3"/>',
		'megaphone' => '<path d="m3 11 18-5v12L3 14v-3z"/><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"/>',
		'zap' => '<path d="M13 2 3 14h9l-1 8 10-12h-9z"/>',
		'search' => '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
		'searchok' => '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3M8 11l2 2 4-4"/>',
		'store' => '<path d="M3 9l1-5h16l1 5M4 9v11h16V9M9 20v-6h6v6"/><path d="M3 9a3 3 0 0 0 6 0 3 3 0 0 0 6 0 3 3 0 0 0 6 0"/>',
		'unlink' => '<path d="m18.84 12.25 1.72-1.71a5 5 0 0 0-7.07-7.07l-1.72 1.71M5.17 11.75l-1.71 1.71a5 5 0 0 0 7.07 7.07l1.71-1.71M8 2v3M2 8h3M16 22v-3M22 16h-3"/>',
		'rocket' => '<path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/>',
		'badge' => '<path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76z"/><path d="m9 12 2 2 4-4"/>',
		'video' => '<path d="m22 8-6 4 6 4V8z"/><rect x="2" y="6" width="14" height="12" rx="2"/>',
		'sign' => '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M9 15l2 2 4-4"/>',
		'redirect' => '<path d="m16 3 5 5-5 5M21 8H9a6 6 0 0 0-6 6v7"/>',
		'gem' => '<path d="M6 3h12l4 6-10 13L2 9z"/><path d="M11 3 8 9l4 13 4-13-3-6M2 9h20"/>',
		'link' => '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
		'tag' => '<path d="M12.59 2.59A2 2 0 0 0 11.17 2H4a2 2 0 0 0-2 2v7.17a2 2 0 0 0 .59 1.42l8.7 8.7a2.43 2.43 0 0 0 3.42 0l6.58-6.58a2.43 2.43 0 0 0 0-3.42z"/><circle cx="7.5" cy="7.5" r=".6"/>',
		'card' => '<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/>',
		'sliders' => '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
		'key' => '<circle cx="7.5" cy="15.5" r="5.5"/><path d="m21 2-9.6 9.6M15.5 7.5l3 3L22 7l-3-3"/>',
		'server' => '<rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><path d="M6 6h.01M6 18h.01"/>',
		'list' => '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
		'whatsapp' => '<path d="M7.9 20A9 9 0 1 0 4 16.1L2 22z"/>',
		'lock' => '<circle cx="12" cy="16" r="1"/><rect x="3" y="10" width="18" height="12" rx="2"/><path d="M7 10V7a5 5 0 0 1 10 0v3"/>',
		'clip' => '<rect x="8" y="2" width="8" height="4" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="m9 14 2 2 4-4"/>',
		'globe' => '<circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20M2 12h20"/>',
		'rules' => '<path d="M3 6h18M7 12h10M10 18h4"/>',
		'hash' => '<path d="M4 9h16M4 15h16M10 3 8 21M16 3l-2 18"/>',
		'compass' => '<circle cx="12" cy="12" r="10"/><path d="m16.24 7.76-2.12 6.36-6.36 2.12 2.12-6.36z"/>',
		'layers' => '<path d="m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z"/><path d="m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65M22 12.65l-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65"/>',
		'bot' => '<path d="M12 8V4H8"/><rect x="4" y="8" width="16" height="12" rx="2"/><path d="M2 14h2M20 14h2M15 13v2M9 13v2"/>',
		'gauge' => '<path d="m12 14 4-4M3.34 19a10 10 0 1 1 17.32 0"/>',
		'radio' => '<circle cx="12" cy="12" r="2"/><path d="M16.24 7.76a6 6 0 0 1 0 8.49m-8.48-.01a6 6 0 0 1 0-8.49m11.31-2.82a10 10 0 0 1 0 14.14m-14.14 0a10 10 0 0 1 0-14.14"/>',
		'star' => '<path d="M11.5 2.3a.5.5 0 0 1 1 0l2.3 5.6 6 .5a.5.5 0 0 1 .3.9l-4.6 3.9 1.4 5.9a.5.5 0 0 1-.7.5L12 16.5l-5.2 3.1a.5.5 0 0 1-.7-.5l1.4-5.9-4.6-3.9a.5.5 0 0 1 .3-.9l6-.5z"/>',
	);

	/** Gradient pairs for the coloured icon tiles. */
	const PALETTE = array(
		array( '#7c3aed', '#c084fc' ), array( '#e11d74', '#fb7185' ), array( '#f59e0b', '#fb923c' ), array( '#10b981', '#2dd4bf' ),
		array( '#0ea5e9', '#6366f1' ), array( '#ef4444', '#f97316' ), array( '#14b8a6', '#22c55e' ), array( '#8b5cf6', '#ec4899' ),
		array( '#3b82f6', '#06b6d4' ), array( '#d946ef', '#f43f5e' ),
	);

	const TAB_ICON = array(
		'myrishta-seo' => 'dashboard',
		'mrsh-inbox' => 'inbox',
		'mrsh-today' => 'today',
		'mrsh-easy' => 'wand',
		'mrsh-problems' => 'alert',
		'mrsh-fresh' => 'package',
		'mrsh-settings' => 'settings',
		'mrsh-switch' => 'toggle',
		'mrsh-guide' => 'book',
		'myrishta-seo-backup' => 'download',
		'mrsh-fullbackup' => 'archive',
		'mrsh-delivery' => 'send',
		'mrsh-relay' => 'send',
		'mrsh-digest' => 'mail',
		'mrsh-overview' => 'chart',
		'mrsh-queue' => 'queue',
		'mrsh-desk' => 'idcard',
		'mrsh-guard' => 'shield',
		'mrsh-shield' => 'shield',
		'mrsh-emtpl' => 'file',
		'mrmb' => 'heart',
		'mrsh-activity' => 'activity',
		'mrsh-tickets' => 'ticket',
		'mrsh-profiles' => 'userc',
		'mrsh-users' => 'users',
		'mrsh-msgs' => 'message',
		'mrsh-matchdesk' => 'heart',
		'mrsh-clean' => 'sparkles',
		'mrsh-orders' => 'receipt',
		'mrsh-nudge' => 'bell',
		'mrsh-photo-safety' => 'camera',
		'mrsh-reports' => 'flag',
		'mrsh-search' => 'trend',
		'mrsh-founding' => 'award',
		'mrsh-themeopts' => 'palette',
		'mrsh-site' => 'layout',
		'mrsh-theme' => 'phone',
		'mrsh-photos' => 'image',
		'mrsh-photodiag' => 'scan',
		'mrsh-import' => 'import',
		'mrsh-growth' => 'trend',
		'mrsh-ideas' => 'wrench',
		'mrsh-places' => 'pin',
		'mrsh-int' => 'plug',
		'mrsh-social' => 'login',
		'mrsh-autoads' => 'zap',
		'mrsh-gads' => 'megaphone',
		'mrsh-gbp' => 'store',
		'mrsh-fix' => 'unlink',
		'mrsh-boost' => 'rocket',
		'mrsh-more2' => 'sparkles',
		'mrsh-proofs' => 'badge',
		'mrsh-checks' => 'video',
		'mrsh-photocheck' => 'camera',
		'mrsh-logokit' => 'gem',
		'mrsh-adlinks' => 'link',
		'mrsh-agreement' => 'sign',
		'mrsh-m3' => 'redirect',
		'mrsh-brand' => 'tag',
		'mrsh-plans' => 'card',
		'mrsh-pay' => 'receipt',
		'mrsh-mem' => 'sliders',
		'mrsh-keys' => 'key',
		'mrsh-cwv' => 'activity',
		'mrsh-maint' => 'settings',
		'mrsh-upd' => 'settings',
		'mrsh-mail' => 'mail',
		'mrsh-smtp' => 'server',
		'mrsh-mailq' => 'list',
		'mrsh-push' => 'bell',
		'mrsh-whatsapp' => 'whatsapp',
		'mrsh-sms' => 'phone',
		'mrsh-dbtidy' => 'settings',
		'mrsh-2fa' => 'lock',
		'myrishta-ads' => 'megaphone',
		'mrads-check' => 'clip',
		'myrishta-seo-engines' => 'globe',
		'myrishta-seo-rules' => 'rules',
		'myrishta-seo-keywords' => 'hash',
		'myrishta-seo-discover' => 'compass',
		'myrishta-seo-coverage' => 'layers',
		'mrsh-autokw' => 'wand',
		'mrsh-pageopt' => 'wand',
		'mrsh-ai' => 'bot',
		'mrsh-thin' => 'file',
		'mrsh-bounce' => 'mail',
		'mrsh-fixer' => 'wand',
		'mrsh-ai-hub' => 'bot',
		'mrsh-secbot' => 'shield',
		'mrsh-matchrep' => 'send',
		'mrsh-audit' => 'searchok',
		'mrsh-psi' => 'zap',
		'myrishta-seo-tools' => 'wrench',
		'mrsh-live' => 'radio',
	);

	const TOP_ICON = array(
		'home' => 'dashboard',
		'members' => 'users',
		'design' => 'palette',
		'growth' => 'trend',
		'site' => 'settings',
		'seo' => 'search',
		'audit' => 'gauge',
	);

	/** Left admin menu icon (white outline, base64 data URI). */
	public static function menu_icon( $k ) {
		$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' . ( self::S[ $k ] ?? self::S['dashboard'] ) . '</svg>';
		return 'data:image/svg+xml;base64,' . base64_encode( $svg ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
	}

	private static function svg( $k, $sz ) {
		return '<svg viewBox="0 0 24 24" width="' . (int) $sz . '" height="' . (int) $sz . '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ( self::S[ $k ] ?? self::S['dashboard'] ) . '</svg>'; // phpcs:ignore
	}

	/** Slug of a screen => small icon. */
	private static function tab_icon( $slug ) {
		return self::svg( self::TAB_ICON[ $slug ] ?? 'dashboard', 17 );
	}

	private static function colors() {
		return array(
			'home' => array( '#7c3aed', '#a855f7' ), 'members' => array( '#e11d74', '#f43f5e' ), 'design' => array( '#f59e0b', '#ef4444' ),
			'growth' => array( '#10b981', '#06b6d4' ), 'site' => array( '#0ea5e9', '#6366f1' ), 'seo' => array( '#6366f1', '#8b5cf6' ), 'audit' => array( '#ef4444', '#f97316' ),
		);
	}

	public static function group_of( $slug ) {
		foreach ( self::groups() as $g => $d ) {
			if ( isset( $d[2][ $slug ] ) ) {
				return $g;
			}
		}
		return '';
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'shorten' ), 9999 );
		add_action( 'admin_menu', array( __CLASS__, 'sort_menu' ), 10001 );
		add_action( 'admin_head', function () {
			echo '<style>#adminmenu li.mrt-hide{display:none!important}</style>';
		} );
		add_action( 'admin_footer', array( __CLASS__, 'menu_fallback' ), 99 );
		add_filter( 'submenu_file', array( __CLASS__, 'highlight' ) );
		add_action( 'in_admin_header', array( __CLASS__, 'bar' ) );
		add_filter( 'admin_body_class', array( __CLASS__, 'body_class' ) );
		add_action( 'admin_head', array( __CLASS__, 'crm_head' ) );
	}

	/** Safety net: if the class-based hiding does not apply (cache, theme or WordPress change), hide the extra entries with script. */
	public static function menu_fallback() {
		$keep = array();
		foreach ( self::groups() as $d ) {
			$keep[] = $d[1];
		}
		$keep[] = 'mrsh-helpers';
		echo '<script>(function(){var k=' . wp_json_encode( $keep ) . ';var m=document.querySelector("#adminmenu a.toplevel_page_myrishta-seo")||document.querySelector("#toplevel_page_myrishta-seo");if(!m)return;var top=document.getElementById("toplevel_page_myrishta-seo");if(!top)return;top.querySelectorAll(".wp-submenu li").forEach(function(li){var a=li.querySelector("a");if(!a)return;var h=a.getAttribute("href")||"";var mm=h.match(/page=([^&]+)/);if(!mm){return;}if(k.indexOf(mm[1])<0&&(mm[1].indexOf("mrsh")===0||mm[1].indexOf("myrishta-seo")===0)){li.style.display="none";}});})();</script>'; // phpcs:ignore
	}

	/** Keep one sidebar entry per group. The other pages are hidden from the sidebar (not removed) and are reached with the tabs. */
	public static function shorten() {
		global $submenu, $menu;
		$c = self::counts();
		$t = (int) ( $c['mrsh-checks'] ?? 0 ) + (int) ( $c['mrsh-proofs'] ?? 0 ) + (int) ( $c['mrsh-users'] ?? 0 ) + (int) ( $c['mrsh-profiles'] ?? 0 ) + (int) ( $c['mrsh-reports'] ?? 0 );
		if ( $t && is_array( $menu ) ) {
			foreach ( $menu as $mi => $m ) {
				if ( isset( $m[2] ) && 'myrishta-seo' === $m[2] ) {
					$menu[ $mi ][0] .= ' <span class="awaiting-mod">' . $t . '</span>'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
					break;
				}
			}
		}
		if ( empty( $submenu['myrishta-seo'] ) ) {
			return;
		}
		$keep = array();
		foreach ( self::groups() as $g => $d ) {
			$keep[ $d[1] ] = $d[0];
		}
		$keep['mrsh-helpers'] = 'Rishta Agencies';
		foreach ( $submenu['myrishta-seo'] as $i => $item ) {
			$slug = $item[2];
			if ( isset( $keep[ $slug ] ) ) {
				$submenu['myrishta-seo'][ $i ][0] = $keep[ $slug ]; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
			} elseif ( 0 !== strpos( $slug, 'http' ) ) {
				// Hidden with a class, not removed: WordPress refuses pages that are not in the menu.
				$submenu['myrishta-seo'][ $i ][4] = 'mrt-hide'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
			}
		}
	}

	/** Sidebar list A to Z (first item stays on top). Runs after every other menu change. */
	public static function sort_menu() {
		global $submenu;
		if ( empty( $submenu['myrishta-seo'] ) || ! is_array( $submenu['myrishta-seo'] ) ) {
			return;
		}
		$items = array_values( $submenu['myrishta-seo'] );
		$first = array_shift( $items );
		usort(
			$items,
			function ( $a, $b ) {
				return strcasecmp( trim( wp_strip_all_tags( (string) $a[0] ) ), trim( wp_strip_all_tags( (string) $b[0] ) ) );
			}
		);
		array_unshift( $items, $first );
		$submenu['myrishta-seo'] = $items; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
	}

	/** Waiting work, by screen slug. Shown as red numbers on the tabs and in the sidebar. */
	public static function counts() {
		static $c = null;
		if ( null !== $c ) {
			return $c;
		}
		$cached = get_transient( 'mrsh_cnt' );
		if ( is_array( $cached ) ) {
			$c = $cached;
			return $c;
		}
		$checks = count( (array) get_option( 'mrsh_checks', array() ) );
		$proofs = count( (array) get_option( 'mrsh_proofs', array() ) );
		$plans  = 0;
		$q      = new WP_User_Query( array( 'meta_query' => array( array( 'key' => 'mrt_plan_req', 'value' => '', 'compare' => '!=' ) ), 'fields' => 'ID', 'number' => 1, 'count_total' => true ) );
		$plans  = (int) $q->get_total();
		$pend   = 0;
		$cnt    = wp_count_posts( 'listing_type' );
		if ( $cnt && isset( $cnt->pending ) ) {
			$pend = (int) $cnt->pending;
		}
		global $wpdb;
		$vq   = new WP_User_Query( array( 'meta_query' => array( array( 'key' => 'mrt_vreq', 'value' => '', 'compare' => '!=' ), array( 'key' => '_mrsh_id_verified', 'compare' => 'NOT EXISTS' ) ), 'fields' => 'ID', 'number' => 1, 'count_total' => true ) );
		$vreq = (int) $vq->get_total();
		$tk   = 0;
		$tl   = 0;
		if ( class_exists( 'MRSH_Tickets' ) ) {
			$t1 = MRSH_Tickets::t1();
			if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $t1 ) ) === $t1 ) { // phpcs:ignore WordPress.DB
				$tk = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $t1 WHERE status IN ('open','progress')" ); // phpcs:ignore WordPress.DB
				$tl = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t1 WHERE status IN ('open','progress') AND due < %d", time() ) ); // phpcs:ignore WordPress.DB
			}
		}
		$mq = 0;
		$mt = $wpdb->prefix . 'mrsh_mailq';
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $mt ) ) === $mt ) { // phpcs:ignore WordPress.DB
			$mq = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $mt WHERE status='failed'" ); // phpcs:ignore WordPress.DB
		}
		$c = array_filter(
			array(
				'mrsh-checks'   => $checks,
				'mrsh-proofs'   => $proofs,
				'mrsh-users'    => $plans,
				'mrsh-plans'    => $plans,
				'mrsh-desk'     => $plans + $pend + $vreq,
				'mrsh-tickets'  => $tk,
				'mrsh-activity' => class_exists( 'MRSH_Act' ) ? MRSH_Act::open_flags() : 0,
				'mrsh-tlate'    => $tl,
				'mrsh-orders'   => class_exists( 'MRSH_Orders' ) ? MRSH_Orders::open_count() : 0,
				'mrsh-mailq'    => $mq,
				'mrsh-inbox'    => class_exists( 'MRSH_Attn' ) ? MRSH_Attn::open_count() : 0,
				'mrsh-profiles' => $pend,
				'mrsh-reports'  => class_exists( 'MRSH_Boost' ) ? MRSH_Boost::report_count() : 0,
				'mrsh-photodiag' => class_exists( 'MRSH_Mem_PhotoDiag' ) ? MRSH_Mem_PhotoDiag::problem_count() : 0,
			)
		);
		set_transient( 'mrsh_cnt', $c, 30 );
		return $c;
	}

	/** Total waiting in one group. */
	public static function group_count( $g ) {
		$n = 0;
		$c = self::counts();
		foreach ( self::groups()[ $g ][2] as $slug => $label ) {
			$n += (int) ( $c[ $slug ] ?? 0 );
		}
		return $n;
	}

	private static function badge( $n ) {
		return $n > 0 ? ' <b class="mrt-n" title="Waiting for you">' . ( $n > 99 ? '99+' : (int) $n ) . '</b>' : '';
	}

	public static function highlight( $file ) {
		$cur = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore
		$g   = self::group_of( $cur );
		return $g ? self::groups()[ $g ][1] : $file;
	}

	private static function icon( $g ) {
		return self::svg( self::TOP_ICON[ $g ] ?? 'dashboard', 20 );
	}

	public static function css() {
		$v = '';
		foreach ( self::colors() as $gk => $cc ) {
			$v .= 'body.mrt-g-' . $gk . '{--g:' . $cc[0] . ';--g2:' . $cc[1] . '}';
		}
		return $v . '
body.mrt-ui{background:#f3f4fa}
body.mrt-ui #wpcontent{padding-left:24px}
body.mrt-ui .wrap{max-width:1280px;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Inter,sans-serif}
body.mrt-ui .wrap>h1,body.mrt-ui .wrap h1.wp-heading-inline{font-size:26px;font-weight:700;letter-spacing:-.02em;color:#1f2937;margin:6px 0 14px;padding:0}
body.mrt-ui .wrap h2{font-size:17px;font-weight:700;color:#1f2937}
.mrt-tabs{position:relative;z-index:2;clear:both;margin:16px 24px 18px 0}
.mrt-tabs .r1{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:12px}
.mrt-tabs .r1 a{display:inline-flex;align-items:center;gap:9px;padding:10px 18px 10px 12px;border-radius:14px;background:#fff;color:#374151;text-decoration:none;font-weight:600;font-size:14px;box-shadow:0 1px 3px rgba(17,24,39,.08),0 0 0 1px rgba(17,24,39,.04);transition:all .18s}
.mrt-tabs .r1 a .ic{width:32px;height:32px;border-radius:10px;display:grid;place-items:center;background:#f1f2f9;color:#6b7280;transition:all .18s}
.mrt-tabs .r1 a:hover{transform:translateY(-2px);box-shadow:0 8px 20px rgba(124,58,237,.16);color:#be185d}
.mrt-tabs .r1 a:hover .ic{background:#fde4f0;color:#be185d}
.mrt-tabs .r1 a.on{background:linear-gradient(135deg,var(--g,#e11d74),var(--g2,#7c3aed));color:#fff;box-shadow:0 8px 22px rgba(17,24,39,.22)}
.mrt-tabs .r1 a.on .ic{background:rgba(255,255,255,.22);color:#fff}
.mrt-tabs .r2{display:flex;gap:6px;flex-wrap:wrap;background:#fff;padding:8px;border-radius:14px;box-shadow:0 1px 3px rgba(17,24,39,.08),0 0 0 1px rgba(17,24,39,.04)}
.mrt-tabs .r2 a{padding:7px 14px;border-radius:10px;text-decoration:none;color:#4b5563;font-size:13px;font-weight:500;transition:all .15s;border:1px solid transparent}
.mrt-tabs .r2 a:hover{background:#f6f0ff;color:#7c3aed;border-color:#e5d9fb}
.mrt-tabs .r2 a.on{background:var(--g,#1f2937);color:#fff;font-weight:600;box-shadow:0 3px 10px rgba(31,41,55,.25)}
.mrt-tabs a:focus{outline:0;box-shadow:0 0 0 3px rgba(124,58,237,.35)}
body.mrt-ui .form-table{background:#fff;border-radius:16px;box-shadow:0 1px 3px rgba(17,24,39,.08),0 0 0 1px rgba(17,24,39,.04);border-collapse:separate;border-spacing:0;overflow:hidden;margin:8px 0 18px;width:100%}
body.mrt-ui .form-table th{padding:16px 20px;width:240px;font-weight:600;color:#374151;border-bottom:1px solid #f0f1f6;vertical-align:top}
body.mrt-ui .form-table td{padding:14px 20px;border-bottom:1px solid #f0f1f6}
body.mrt-ui .form-table tr:last-child th,body.mrt-ui .form-table tr:last-child td{border-bottom:0}
body.mrt-ui .widefat{border:0;border-radius:16px;overflow:hidden;box-shadow:0 1px 3px rgba(17,24,39,.08),0 0 0 1px rgba(17,24,39,.04)}
body.mrt-ui .widefat thead th{background:#f7f7fc;color:#6b7280;font-size:12px;text-transform:uppercase;letter-spacing:.05em;border-bottom:1px solid #eceef6;padding:12px 14px}
body.mrt-ui .widefat td{padding:12px 14px;border-bottom:1px solid #f1f2f8;vertical-align:middle}
body.mrt-ui .widefat.striped>tbody>:nth-child(odd){background:#fff}
body.mrt-ui .widefat tbody tr:hover{background:#faf7ff}
body.mrt-ui input[type=text],body.mrt-ui input[type=number],body.mrt-ui input[type=email],body.mrt-ui input[type=url],body.mrt-ui input[type=password],body.mrt-ui input[type=search],body.mrt-ui select,body.mrt-ui textarea{border:1px solid #d9dbe8;border-radius:10px;padding:8px 12px;min-height:38px;box-shadow:none;background:#fff;transition:border-color .15s,box-shadow .15s}
body.mrt-ui input:focus,body.mrt-ui select:focus,body.mrt-ui textarea:focus{border-color:#a855f7;box-shadow:0 0 0 3px rgba(168,85,247,.18);outline:0}
body.mrt-ui .button,body.mrt-ui .button-secondary{border-radius:10px;border:1px solid #d9dbe8;background:#fff;color:#374151;padding:6px 16px;min-height:36px;line-height:22px;font-weight:600;transition:all .15s}
body.mrt-ui .button:hover{background:#f6f0ff;border-color:#c4a8f7;color:#7c3aed;transform:translateY(-1px)}
body.mrt-ui .button-primary{background:linear-gradient(135deg,var(--g,#e11d74),var(--g2,#7c3aed));border:0;color:#fff;box-shadow:0 4px 12px rgba(17,24,39,.22)}
body.mrt-ui .button-primary:hover{filter:brightness(.93);color:#fff;box-shadow:0 8px 20px rgba(17,24,39,.28)}
body.mrt-ui .button-small{min-height:28px;padding:2px 12px;line-height:20px;font-size:12px}
body.mrt-ui .notice{border-radius:12px;border:0;box-shadow:0 1px 3px rgba(17,24,39,.08);border-left:4px solid #7c3aed;padding:4px 12px}
body.mrt-ui .notice-success{border-left-color:#10b981}body.mrt-ui .notice-error{border-left-color:#ef4444}body.mrt-ui .notice-warning{border-left-color:#f59e0b}
body.mrt-ui .description,body.mrt-ui p.description{color:#6b7280;font-size:12.5px}
body.mrt-ui .mrsh-card,body.mrt-ui .postbox{background:#fff;border:0;border-radius:16px;box-shadow:0 1px 3px rgba(17,24,39,.08),0 0 0 1px rgba(17,24,39,.04)}
body.mrt-ui .mrsh-hero{border-radius:18px}
body.mrt-ui .nav-tab-wrapper{display:none}
body.mrt-ui a{transition:color .15s}
.mrt-sub{display:flex;gap:6px;flex-wrap:wrap;margin:0 0 14px}.mrt-sub a{padding:6px 14px;border-radius:99px;background:#fff;text-decoration:none;color:#4b5563;font-size:13px;box-shadow:0 0 0 1px rgba(17,24,39,.07);transition:all .15s}.mrt-sub a:hover{background:#f6f0ff;color:#7c3aed}.mrt-sub a.on{background:#1f2937;color:#fff}
.mrsh-nav{display:none!important}

/* compact: remove extra space */
body.mrt-ui #wpbody-content{padding-bottom:20px}
body.mrt-ui #wpcontent{padding-left:16px}
body.mrt-ui .wrap{margin:6px 16px 0 0}
body.mrt-ui .wrap>h1{margin:2px 0 8px;font-size:22px}
body.mrt-ui .wrap h2{margin:14px 0 8px}
body.mrt-ui .wrap p{margin:6px 0}
body.mrt-ui .wrap .form-table th{padding:10px 10px 10px 0}body.mrt-ui .wrap .form-table td{padding:8px 10px}
body.mrt-ui .postbox,body.mrt-ui .card{margin-top:10px;padding:0}
body.mrt-ui .notice{margin:8px 0}
body.mrt-ui .wp-list-table td,body.mrt-ui .wp-list-table th{padding:7px 10px}
body.mrt-ui .button,body.mrt-ui .button-primary{border-radius:10px;transition:transform .12s,box-shadow .15s}
body.mrt-ui .button:hover{transform:translateY(-1px);box-shadow:0 4px 12px rgba(16,24,40,.12)}
body.mrt-ui .button:active{transform:scale(.97)}
.mrx a.button{margin:2px}

/* comfortable, Apple-style sizes (replaces the compact block above) */
body.mrt-ui{font-size:14px;line-height:1.5}
body.mrt-ui #wpcontent{padding-left:24px}
body.mrt-ui #wpbody-content{padding-bottom:40px}
body.mrt-ui .wrap{margin:14px 24px 0 0}
body.mrt-ui .wrap>h1,body.mrt-ui .wrap h1.wp-heading-inline{font-size:28px;margin:8px 0 16px}
body.mrt-ui .wrap h2{font-size:18px;margin:24px 0 12px}
body.mrt-ui .wrap p{margin:10px 0;font-size:14px}
body.mrt-ui .wrap .form-table th{padding:18px 20px;font-size:14px}body.mrt-ui .wrap .form-table td{padding:16px 20px;font-size:14px}
body.mrt-ui .postbox,body.mrt-ui .card,body.mrt-ui .mrsh-card{margin-top:16px;padding:6px 8px;border-radius:18px}
body.mrt-ui .notice{margin:14px 0;padding:10px 16px;font-size:14px}
body.mrt-ui .wp-list-table td,body.mrt-ui .wp-list-table th,body.mrt-ui .widefat td{padding:14px 16px;font-size:14px}
body.mrt-ui .widefat thead th{padding:14px 16px;font-size:12px}
body.mrt-ui input[type=text],body.mrt-ui input[type=number],body.mrt-ui input[type=email],body.mrt-ui input[type=url],body.mrt-ui input[type=password],body.mrt-ui input[type=search],body.mrt-ui select{min-height:40px;padding:6px 14px;font-size:14px;border-radius:12px}
body.mrt-ui textarea{padding:10px 14px;font-size:14px;border-radius:12px;line-height:1.5}
body.mrt-ui .button,body.mrt-ui .button-secondary,body.mrt-ui .button-primary{min-height:40px;padding:8px 20px;font-size:14px;line-height:22px;border-radius:12px}
body.mrt-ui .button-small{min-height:34px;padding:5px 15px;font-size:13px;line-height:22px}
body.mrt-ui .description,body.mrt-ui p.description{font-size:13.5px}
.mrt-tabs{margin:18px 24px 22px 0}
.mrt-tabs .r1{gap:12px;margin-bottom:14px}
.mrt-tabs .r1 a{padding:12px 22px 12px 14px;font-size:15px;border-radius:16px}
.mrt-tabs .r1 a .ic{width:36px;height:36px;border-radius:11px}
.mrt-tabs .r2{padding:10px;gap:8px;border-radius:16px}
.mrt-tabs .r2 a{padding:9px 18px;font-size:14px;border-radius:12px}
.mrx a.button{margin:4px}
/* new screens: icons on sub tabs, group colours, section accents */
.mrt-tabs .r2 a{display:inline-flex;align-items:center;gap:7px}
.mrt-tabs .r2 a svg{opacity:.75;flex:none}.mrt-tabs .r2 a.on svg{opacity:1}
.mrt-tabs .r2 a:hover{color:var(--g,#7c3aed);border-color:var(--g,#e5d9fb)}
.mrt-tabs .r1 a:hover{color:var(--g,#be185d)}
body.mrt-ui .wrap h2{border-left:4px solid var(--g,#7c3aed);padding-left:12px;line-height:1.3}
body.mrt-ui .form-table{border-top:3px solid var(--g,#7c3aed)}
body.mrt-ui .widefat thead th{border-top:3px solid var(--g,#7c3aed)}
body.mrt-ui .mrt-sub{margin:4px 0 16px}
body.mrt-ui .mrt-sub a{padding:8px 16px;font-size:14px;font-weight:500}
body.mrt-ui .mrt-sub a.on{background:var(--g,#1f2937);box-shadow:0 3px 10px rgba(31,41,55,.2)}
body.mrt-ui .mrt-sub a:hover{color:var(--g,#7c3aed)}
body.mrt-ui .wp-color-result.button{min-height:32px;padding:0 0 0 34px}
body.mrt-ui .iris-picker{border-radius:12px}
body.mrt-ui code{background:#f1f2f9;border-radius:6px;padding:2px 7px}
body.mrt-ui textarea.code{font-size:13px}
body.mrt-ui input[type=checkbox]:checked{accent-color:var(--g,#7c3aed)}
body.mrt-ui input[type=checkbox],body.mrt-ui input[type=radio]{accent-color:var(--g,#7c3aed)}

/* CRM look: rows as rounded cards, soft fields */
body.mrt-ui .widefat,body.mrt-ui .wp-list-table{border-collapse:separate;border-spacing:0 8px;background:transparent;box-shadow:none;overflow:visible;border:0}
body.mrt-ui .widefat thead th,body.mrt-ui .wp-list-table thead th{background:transparent;border:0;border-top:0;color:#6b7280;font-size:11.5px;letter-spacing:.06em;text-transform:uppercase;padding:6px 16px}
body.mrt-ui .widefat tbody tr,body.mrt-ui .wp-list-table tbody tr{background:#fff;box-shadow:0 1px 3px rgba(17,24,39,.07),0 0 0 1px rgba(17,24,39,.04);transition:box-shadow .15s,transform .15s}
body.mrt-ui .widefat tbody tr:hover,body.mrt-ui .wp-list-table tbody tr:hover{background:#fff;box-shadow:0 6px 18px rgba(17,24,39,.10),0 0 0 1px var(--g,#7c3aed);transform:translateY(-1px)}
body.mrt-ui .widefat tbody td,body.mrt-ui .widefat tbody th,body.mrt-ui .wp-list-table tbody td,body.mrt-ui .wp-list-table tbody th{border:0;background:transparent;padding:14px 16px;vertical-align:middle}
body.mrt-ui .widefat tbody tr>*:first-child,body.mrt-ui .wp-list-table tbody tr>*:first-child{border-radius:14px 0 0 14px}
body.mrt-ui .widefat tbody tr>*:last-child,body.mrt-ui .wp-list-table tbody tr>*:last-child{border-radius:0 14px 14px 0}
body.mrt-ui .widefat.striped>tbody>:nth-child(odd),body.mrt-ui .wp-list-table.striped>tbody>:nth-child(odd){background:#fff}
body.mrt-ui .wp-list-table .check-column{padding-left:16px}
body.mrt-ui .wp-list-table .row-title{font-size:14.5px;font-weight:700;color:#1f2937}
body.mrt-ui .tablenav .actions select,body.mrt-ui .search-box input[type=search]{border-radius:12px}
body.mrt-ui .form-table{border-radius:18px;background:#fff;padding:6px 8px}
body.mrt-ui .form-table input[type=text],body.mrt-ui .form-table input[type=number],body.mrt-ui .form-table input[type=email],body.mrt-ui .form-table input[type=url],body.mrt-ui .form-table input[type=password],body.mrt-ui .form-table select,body.mrt-ui .form-table textarea,body.mrt-ui #poststuff input[type=text],body.mrt-ui #poststuff textarea,body.mrt-ui #poststuff select{background:#f7f8fc;border:1px solid #e3e6f0;border-radius:12px;min-height:42px;padding:8px 14px;max-width:100%}
body.mrt-ui .form-table input:hover,body.mrt-ui .form-table select:hover,body.mrt-ui .form-table textarea:hover{border-color:#c9cde0;background:#fff}
body.mrt-ui .form-table input:focus,body.mrt-ui .form-table select:focus,body.mrt-ui .form-table textarea:focus,body.mrt-ui #poststuff input:focus,body.mrt-ui #poststuff textarea:focus{background:#fff;border-color:var(--g,#7c3aed);box-shadow:0 0 0 4px rgba(124,58,237,.12)}
body.mrt-ui #poststuff .postbox{border-radius:18px;overflow:hidden}
body.mrt-ui #poststuff .postbox .postbox-header{border-bottom:1px solid #f0f1f6;background:#fafbff}
body.mrt-ui #poststuff .postbox .inside{padding:14px 18px}
body.mrt-ui #titlewrap input#title{font-size:20px;font-weight:700;min-height:50px;border-radius:14px}
body.mrt-ui .tablenav .tablenav-pages .button,body.mrt-ui .subsubsub a{border-radius:10px}
body.mrt-ui .subsubsub a.current{color:var(--g,#7c3aed);font-weight:700}
.mrt-n{display:inline-block;min-width:20px;height:20px;line-height:20px;padding:0 6px;border-radius:99px;background:#e11d2e;color:#fff;font-size:11px;font-weight:700;text-align:center;box-sizing:border-box;box-shadow:0 0 0 0 rgba(225,29,46,.55);animation:mrtn 1.8s infinite}
.mrt-tabs .r2 a.on .mrt-n,.mrt-tabs .r1 a.on .mrt-n{background:#fff;color:#e11d2e}
@keyframes mrtn{0%{box-shadow:0 0 0 0 rgba(225,29,46,.5)}70%{box-shadow:0 0 0 8px rgba(225,29,46,0)}100%{box-shadow:0 0 0 0 rgba(225,29,46,0)}}
@media(prefers-reduced-motion:reduce){.mrt-n{animation:none}}
@media(max-width:782px){body.mrt-ui .wp-list-table tbody tr{display:block;margin-bottom:10px;border-radius:14px}body.mrt-ui .wp-list-table tbody tr>*{border-radius:0!important}}
/* 3.101.36: every plugin page gets the same colourful header and soft cards */
body.mrt-ui .wrap>h1:first-child,body.mrt-ui .wrap>h1.wp-heading-inline{position:relative;overflow:hidden;display:block;padding:20px 26px;margin:8px 0 16px;border-radius:22px;color:#fff;font-size:24px;font-weight:700;letter-spacing:-.02em;line-height:1.25;background:linear-gradient(135deg,var(--g,#139a86),var(--g2,#7c3aed));box-shadow:0 14px 30px rgba(60,50,150,.2)}
body.mrt-ui .wrap>h1:first-child:after{content:"";position:absolute;right:-50px;top:-70px;width:200px;height:200px;border-radius:50%;background:rgba(255,255,255,.13)}
body.mrt-ui .wrap>h1 .page-title-action{position:relative;z-index:1;margin-left:12px;border-radius:12px;background:rgba(255,255,255,.22);border:1px solid rgba(255,255,255,.45);color:#fff}
body.mrt-ui .wrap.mx>h1{all:unset}
body.mrt-ui .wrap>h2:first-of-type+p,body.mrt-ui .wrap>h1+p{color:#4b5563}
body.mrt-ui .mrsh-card,body.mrt-ui .wrap>form>.form-table{box-shadow:0 1px 3px rgba(17,24,39,.07),0 0 0 1px rgba(17,24,39,.04)}
@media(max-width:600px){body.mrt-ui .wrap>h1:first-child{padding:16px 18px;font-size:20px;border-radius:18px}}

/* 3.101.226 modern menu: outline icons, sticky bar, tidy tabs */
.mrt-tabs{margin:12px 24px 20px 0}
.mrt-tabs .r1{gap:10px;margin-bottom:10px}
.mrt-tabs .r1 a{padding:9px 18px 9px 10px;border-radius:16px;font-size:14px;font-weight:600;letter-spacing:-.005em;border:1px solid rgba(17,24,39,.06);box-shadow:0 1px 2px rgba(17,24,39,.05)}
.mrt-tabs .r1 a .ic{width:34px;height:34px;border-radius:11px;background:#f3f4fb;color:#6b7280}
.mrt-tabs .r1 a .ic svg{width:19px;height:19px;display:block}
.mrt-tabs .r1 a:hover{transform:translateY(-1px);box-shadow:0 10px 24px -10px rgba(17,24,39,.28);border-color:transparent}
.mrt-tabs .r1 a:hover .ic{background:#fff3f9;color:var(--g,#be185d)}
.mrt-tabs .r1 a.on{border-color:transparent;box-shadow:0 12px 26px -12px rgba(17,24,39,.55)}
.mrt-tabs .r2{display:flex;flex-wrap:wrap;gap:6px;padding:8px;border-radius:18px;background:#fff;border:1px solid rgba(17,24,39,.06);box-shadow:0 1px 2px rgba(17,24,39,.05)}
.mrt-tabs .r2 a{display:inline-flex;align-items:center;gap:8px;padding:8px 14px 8px 11px;border-radius:12px;font-size:13.5px;font-weight:500;color:#4b5563;border:0;background:transparent;line-height:1.2}
.mrt-tabs .r2 a svg{width:17px;height:17px;flex:none;opacity:.7;transition:opacity .15s,transform .15s}
.mrt-tabs .r2 a:hover{background:#f6f5ff;color:var(--g,#7c3aed)}
.mrt-tabs .r2 a:hover svg{opacity:1;transform:scale(1.08)}
.mrt-tabs .r2 a.on{background:linear-gradient(135deg,var(--g,#7c3aed),var(--g2,var(--g,#a855f7)));color:#fff;font-weight:600;box-shadow:0 8px 18px -8px rgba(17,24,39,.5)}
.mrt-tabs .r2 a.on svg{opacity:1;color:#fff}
.mrt-tabs a:focus-visible{outline:0;box-shadow:0 0 0 3px rgba(124,58,237,.4)}
@media (min-width:1100px){.mrt-tabs{position:sticky;top:32px;z-index:60;padding:8px 0 4px;margin-top:4px;background:linear-gradient(#f0f0f1 82%,rgba(240,240,241,0))}}
.mrt-more{display:none;width:100%;margin-top:6px;border:0;border-radius:12px;padding:12px;min-height:44px;background:#fff;font-weight:700;font-size:13.5px;color:var(--g,#7c3aed);box-shadow:0 0 0 1px rgba(17,24,39,.08);cursor:pointer}
@media (max-width:782px){
.mrt-tabs{margin:8px 10px 14px 0}
.mrt-tabs .r1{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;overflow:visible;margin-bottom:8px}
.mrt-tabs .r1 a{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px;padding:10px 4px;min-height:70px;text-align:center;font-size:11.5px;line-height:1.2;white-space:normal;border-radius:14px}
.mrt-tabs .r1 a .ic{width:30px;height:30px;border-radius:10px}.mrt-tabs .r1 a .ic svg{width:17px;height:17px}
.mrt-tabs .r2{flex-wrap:wrap;overflow:hidden;max-height:98px;padding:6px;gap:5px;align-content:flex-start}
.mrt-tabs.open .r2{max-height:none}
.mrt-tabs .r2 a{flex:none;white-space:nowrap;padding:0 11px;font-size:12.5px;height:40px;min-height:0;box-sizing:border-box;align-self:flex-start}
.mrt-more{display:block}
}
/* 3.101.226 phone layout for every plugin page */
@media (max-width:782px){
body.mrt-ui .wrap{margin-right:10px;margin-left:10px}
body.mrt-ui .wrap table.widefat:not(.wp-list-table){display:block;max-width:100%;overflow-x:auto;-webkit-overflow-scrolling:touch;white-space:nowrap}
body.mrt-ui .wrap table.widefat td,body.mrt-ui .wrap table.widefat th{white-space:normal;min-width:90px}
body.mrt-ui .wrap input[type=text],body.mrt-ui .wrap input[type=email],body.mrt-ui .wrap input[type=url],body.mrt-ui .wrap input[type=number],body.mrt-ui .wrap input[type=password],body.mrt-ui .wrap input[type=search],body.mrt-ui .wrap select,body.mrt-ui .wrap textarea{max-width:100%;width:100%;font-size:16px;min-height:44px}
body.mrt-ui .wrap .button,body.mrt-ui .wrap button.button{min-height:44px;padding:8px 16px;line-height:1.5}
body.mrt-ui .wrap pre,body.mrt-ui .wrap code{white-space:pre-wrap;word-break:break-word}
body.mrt-ui .wrap img,body.mrt-ui .wrap iframe{max-width:100%;height:auto}
body.mrt-ui .wrap [style*="display:grid"],body.mrt-ui .wrap [style*="display: grid"]{grid-template-columns:minmax(0,1fr)!important}
body.mrt-ui .wrap [style*="max-width"]{max-width:100%!important}
body.mrt-ui .wrap .card,body.mrt-ui .wrap .postbox{max-width:100%;padding-left:14px;padding-right:14px}
body.mrt-ui .wrap .notice{margin-left:0;margin-right:0}
body.mrt-ui .wrap h2,body.mrt-ui .wrap h3{overflow-wrap:anywhere}
body.mrt-ui .wrap .form-table td input,body.mrt-ui .wrap .form-table td select{margin:2px 0}
}
#adminmenu .wp-menu-image img{opacity:.62;transition:opacity .15s}#adminmenu li:hover .wp-menu-image img,#adminmenu li.current .wp-menu-image img,#adminmenu li.wp-has-current-submenu .wp-menu-image img{opacity:1}
';
	}

	/** Pill tabs, coloured icon tiles, tab finder. Loaded after css() so it wins. */
	public static function css2() {
		return '
.mrt-tabs .r1 a .ic{background:linear-gradient(135deg,var(--g,#7c3aed),var(--g2,#a855f7));color:#fff;box-shadow:0 3px 8px rgba(17,24,39,.18)}
.mrt-tabs .r1 a:hover .ic{background:linear-gradient(135deg,var(--g,#7c3aed),var(--g2,#a855f7));color:#fff;transform:rotate(-6deg) scale(1.06)}
.mrt-tabs .r1 a.on .ic{background:rgba(255,255,255,.25);box-shadow:none}
.mrt-tabs .r2{gap:8px;padding:10px;background:linear-gradient(180deg,#fff,#fafaff);border-radius:18px}
.mrt-tabs .r2 a{display:inline-flex;align-items:center;gap:8px;padding:5px 14px 5px 6px;border-radius:99px;background:#f5f6fb;border:1px solid #eceefa;color:#374151;font-weight:600;font-size:13px}
.mrt-tabs .r2 a .ti{width:24px;height:24px;border-radius:99px;display:grid;place-items:center;color:#fff;background:linear-gradient(135deg,var(--a,#7c3aed),var(--b,#c084fc));box-shadow:0 2px 6px rgba(17,24,39,.2);transition:transform .18s}
.mrt-tabs .r2 a:hover{background:#fff;border-color:var(--a,#c4a8f7);color:#111827;transform:translateY(-1px);box-shadow:0 6px 14px rgba(17,24,39,.1)}
.mrt-tabs .r2 a:hover .ti{transform:rotate(-8deg) scale(1.1)}
.mrt-tabs .r2 a.on{background:linear-gradient(135deg,var(--a,#7c3aed),var(--b,#c084fc));color:#fff;border-color:transparent;box-shadow:0 6px 16px rgba(17,24,39,.25)}
.mrt-tabs .r2 a.on .ti{background:rgba(255,255,255,.28);box-shadow:none}
.mrt-find{margin:0 0 8px}.mrt-find input{width:100%;max-width:340px;border-radius:99px!important;padding-left:16px!important;background:#fff}
@media (prefers-reduced-motion:reduce){.mrt-tabs a,.mrt-tabs .ti,.mrt-tabs .ic{transition:none!important}}
';
	}

	public static function body_class( $c ) {
		$cur = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore
		$g = self::group_of( $cur );
		if ( ! $g && self::crm_screen() ) {
			$g = 'members';
		}
		return $g ? $c . ' mrt-ui mrt-g-' . $g : $c;
	}

	/** Member lists, profile editor and messages get the same card look as the plugin pages. */
	public static function crm_screen() {
		global $pagenow;
		$pt = isset( $_GET['post_type'] ) ? sanitize_key( wp_unslash( $_GET['post_type'] ) ) : ''; // phpcs:ignore
		if ( ! $pt && 'post.php' === $pagenow && isset( $_GET['post'] ) ) { // phpcs:ignore
			$pt = (string) get_post_type( absint( $_GET['post'] ) ); // phpcs:ignore
		}
		return in_array( $pagenow, array( 'users.php', 'user-edit.php', 'profile.php' ), true ) || ( in_array( $pagenow, array( 'edit.php', 'post.php', 'post-new.php' ), true ) && in_array( $pt, array( 'listing_type', 'ppt_message' ), true ) );
	}

	public static function crm_head() {
		if ( self::crm_screen() ) {
			echo '<style>' . self::css() . '</style>'; // phpcs:ignore
		}
	}

	public static function bar() {
		$cur = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore
		$g   = self::group_of( $cur );
		if ( ! $g ) {
			return;
		}
		echo '<style>' . self::css() . self::css2() . '</style><nav class="mrt-tabs" aria-label="My Rishta"><div class="r1">'; // phpcs:ignore
		foreach ( self::groups() as $k => $d ) {
			$gl = $d[1];
			$gq = '';
			if ( self::group_count( $k ) > 0 ) {
				foreach ( $d[2] as $gs => $gn ) {
					if ( (int) ( self::counts()[ $gs ] ?? 0 ) > 0 ) {
						$gl = $gs;
						$gq = '&attn=1';
						break;
					}
				}
			}
			echo '<a class="' . ( $k === $g ? 'on' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=' . $gl . $gq ) ) . '"><span class="ic">' . self::icon( $k ) . '</span>' . esc_html( $d[0] ) . self::badge( self::group_count( $k ) ) . '</a>'; // phpcs:ignore
		}
		echo '</div>';
		$cnt_tabs = count( self::groups()[ $g ][2] );
		if ( $cnt_tabs > 8 ) {
			echo '<div class="mrt-find"><input type="search" placeholder="Find a tab in ' . esc_attr( self::groups()[ $g ][0] ) . '..." aria-label="Find a tab" oninput="var q=this.value.toLowerCase();var t=this.closest(\'.mrt-tabs\');t.classList.toggle(\'open\',q.length>0);t.querySelectorAll(\'.r2 a\').forEach(function(a){a.style.display=a.textContent.toLowerCase().indexOf(q)<0?\'none\':\'\'})"></div>';
		}
		echo '<div class="r2">';
		foreach ( self::groups()[ $g ][2] as $slug => $label ) {
			$pal = self::PALETTE[ abs( crc32( $slug ) ) % count( self::PALETTE ) ];
			echo '<a class="' . ( $slug === $cur ? 'on' : '' ) . '" style="--a:' . esc_attr( $pal[0] ) . ';--b:' . esc_attr( $pal[1] ) . '" href="' . esc_url( admin_url( 'admin.php?page=' . $slug . ( (int) ( self::counts()[ $slug ] ?? 0 ) > 0 ? '&attn=1' : '' ) ) ) . '"><span class="ti">' . self::svg( self::TAB_ICON[ $slug ] ?? 'dashboard', 14 ) . '</span>' . esc_html( $label ) . self::badge( (int) ( self::counts()[ $slug ] ?? 0 ) ) . '</a>'; // phpcs:ignore
		}
		$n = count( self::groups()[ $g ][2] );
		echo '</div><button type="button" class="mrt-more" data-n="' . (int) $n . '" onclick="var t=this.closest(\'.mrt-tabs\');t.classList.toggle(\'open\');this.textContent=t.classList.contains(\'open\')?\'Show fewer tabs\':\'Show all \'+this.dataset.n+\' tabs\'">Show all ' . (int) $n . ' tabs</button></nav>';
		echo '<script>(function(){var t=document.querySelector(".mrt-tabs");if(!t)return;var a=t.querySelector(".r2 a.on");if(a&&window.innerWidth<=782&&a.offsetTop>90){t.classList.add("open");var b=t.querySelector(".mrt-more");if(b)b.textContent="Show fewer tabs"}})()</script>';
	}
}
MRSH_Tabs::init();
