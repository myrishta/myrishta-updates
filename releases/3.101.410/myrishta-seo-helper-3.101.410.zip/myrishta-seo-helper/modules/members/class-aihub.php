<?php
/**
 * AI Assistant hub: one place for the AI key, the daily limit, the on/off switch of every AI job, and the manual "run now" buttons.
 *
 * The site owner brings their own AI account (Claude, OpenAI-compatible or Gemini). Nothing is sent anywhere until the
 * owner saves a key AND turns the assistant on. Email addresses and phone numbers are removed from text before it is sent.
 * Every AI job is off-switchable on its own, has a daily call limit, and never publishes or deletes anything by itself:
 * guides it writes stay drafts until the owner approves them in the Auto-Fixer.
 *
 * The jobs themselves live in class-aijobs.php.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_AIHub {

	const OPT  = 'mrsh_aihub';
	const USE  = 'mrsh_aihub_use';
	const SLUG = 'mrsh-ai-hub';

	public static function o() {
		$o = get_option( self::OPT, array() );
		return array_merge(
			array(
				'on'         => 0,
				'provider'   => 'anthropic',
				'key'        => '',
				'model'      => '',
				'base'       => '',
				'cap'        => 60,
				'reply'      => 1,
				'reply_mode' => 'auto',
				'draft'      => 1,
				'login'      => 1,
				'spell'      => 1,
				'meta'       => 1,
				'prof'       => 1,
				'pool'       => array(),
			),
			is_array( $o ) ? $o : array()
		);
	}

	public static function providers() {
		return array(
			'anthropic' => array( 'Claude (Anthropic)', 'claude-haiku-5-5' ),
			'openai'    => array( 'OpenAI or any OpenAI-compatible service', 'gpt-4o-mini' ),
			'gemini'    => array( 'Google Gemini', 'gemini-2.0-flash' ),
		);
	}

	/** Free services that can be chained: if one is busy or out of free quota, the next one answers. */
	public static function pool_providers() {
		return array(
			'groq'       => array( 'Groq', 'openai', 'https://api.groq.com/openai/v1', 'llama-3.3-70b-versatile', 'console.groq.com/keys' ),
			'gemini'     => array( 'Google Gemini', 'gemini', '', 'gemini-2.0-flash', 'aistudio.google.com/apikey' ),
			'openrouter' => array( 'OpenRouter (free models)', 'openai', 'https://openrouter.ai/api/v1', 'meta-llama/llama-3.3-70b-instruct:free', 'openrouter.ai/keys' ),
			'cerebras'   => array( 'Cerebras', 'openai', 'https://api.cerebras.ai/v1', 'llama-3.3-70b', 'cloud.cerebras.ai' ),
			'mistral'    => array( 'Mistral (free plan)', 'openai', 'https://api.mistral.ai/v1', 'mistral-small-latest', 'console.mistral.ai/api-keys' ),
			'github'     => array( 'GitHub Models', 'openai', 'https://models.github.ai/inference', 'openai/gpt-4o-mini', 'github.com/settings/personal-access-tokens' ),
			'nvidia'     => array( 'NVIDIA NIM', 'openai', 'https://integrate.api.nvidia.com/v1', 'meta/llama-3.1-70b-instruct', 'build.nvidia.com' ),
		);
	}

	/** Every service that has a key, in the order they are tried: the free pool first (Groq on top), the main paid account last. */
	public static function chain() {
		$o = self::o();
		$c = array();
		foreach ( self::pool_providers() as $id => $d ) { // free services first, Groq on top
			$e = $o['pool'][ $id ] ?? array();
			if ( ! empty( $e['key'] ) ) {
				$c[ $id ] = array(
					'label' => $d[0],
					'kind'  => $d[1],
					'key'   => trim( $e['key'] ),
					'model' => ! empty( $e['model'] ) ? trim( $e['model'] ) : $d[3],
					'base'  => $d[2],
				);
			}
		}
		if ( '' !== trim( (string) $o['key'] ) ) { // the main account (Claude) only answers when no free service can
			$p         = $o['provider'];
			$c['main'] = array(
				'label' => self::providers()[ $p ][0] ?? $p,
				'kind'  => 'openai' === $p ? 'openai' : $p,
				'key'   => trim( $o['key'] ),
				'model' => '' !== trim( (string) $o['model'] ) ? trim( $o['model'] ) : ( self::providers()[ $p ][1] ?? '' ),
				'base'  => '' !== trim( (string) $o['base'] ) ? rtrim( trim( $o['base'] ), '/' ) : 'https://api.openai.com/v1',
			);
		}
		return $c;
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 43 );
		foreach ( array( 'save', 'test', 'run' ) as $a ) {
			add_action( 'admin_post_mrsh_aihub_' . $a, array( __CLASS__, $a ) );
		}
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'AI Assistant', 'AI Assistant', 'manage_options', self::SLUG, array( __CLASS__, 'page' ) );
	}

	public static function ready() {
		$o = self::o();
		return ! empty( $o['on'] ) && (bool) self::chain();
	}

	public static function job_on( $job ) {
		$o = self::o();
		return self::ready() && ! empty( $o[ $job ] );
	}

	/* ---------- usage and limits ---------- */

	public static function used_today() {
		$u = get_option( self::USE, array() );
		return is_array( $u ) && ( $u['d'] ?? '' ) === wp_date( 'Y-m-d' ) ? (int) $u['n'] : 0;
	}

	private static function bump() {
		$u = get_option( self::USE, array() );
		$p = is_array( $u ) && ( $u['d'] ?? '' ) === wp_date( 'Y-m-d' ) && is_array( $u['p'] ?? null ) ? $u['p'] : array();
		update_option( self::USE, array( 'd' => wp_date( 'Y-m-d' ), 'n' => self::used_today() + 1, 'p' => $p ), false );
	}

	/** Takes email addresses, phone numbers and long digit strings out of text before it leaves the site. */
	public static function redact( $s ) {
		$s = preg_replace( '/[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}/', '[email]', (string) $s );
		$s = preg_replace( '/\+?\d[\d\s\-().]{7,}\d/', '[number]', $s );
		return $s;
	}

	/**
	 * Ask the AI. Tries every service that has a key, one after the other, until one answers.
	 * A service that is busy or out of free quota is skipped for a while; one that rejects its key is skipped for longer.
	 * Returns the text, or a WP_Error. System text is ours; user text is redacted.
	 */
	public static function ask( $system, $user, $max = 700 ) {
		$o = self::o();
		if ( ! self::ready() ) {
			return new WP_Error( 'off', 'The AI assistant is off or has no key.' );
		}
		if ( self::used_today() >= (int) $o['cap'] ) {
			return new WP_Error( 'cap', 'Daily AI limit reached.' );
		}
		$user = self::redact( $user );
		self::bump();
		$last = new WP_Error( 'empty', 'No AI service answered.' );
		$auth = 0;
		$tried = 0;
		foreach ( self::chain() as $id => $cfg ) {
			if ( get_transient( 'mrsh_ai_skip_' . $id ) ) {
				continue;
			}
			++$tried;
			$r = self::call_one( $cfg, $system, $user, $max );
			if ( is_wp_error( $r ) && 'nomodel' === $r->get_error_code() ) {
				$m = self::discover( $cfg );
				if ( $m && $m !== $cfg['model'] ) {
					$cfg['model'] = $m;
					$r2           = self::call_one( $cfg, $system, $user, $max );
					if ( ! is_wp_error( $r2 ) ) {
						self::save_model( $id, $m );
					}
					$r = $r2;
				}
			}
			self::err( $id, is_wp_error( $r ) ? $r->get_error_message() : '' );
			if ( ! is_wp_error( $r ) ) {
				self::note( $id );
				if ( class_exists( 'MRSH_Fixer' ) ) {
					MRSH_Fixer::ticket_resolve( 'ai_key' );
				}
				return $r;
			}
			$last = $r;
			$c    = $r->get_error_code();
			if ( 'auth' === $c ) {
				++$auth;
				set_transient( 'mrsh_ai_skip_' . $id, 1, 12 * HOUR_IN_SECONDS );
			} elseif ( 'busy' === $c ) {
				set_transient( 'mrsh_ai_skip_' . $id, 1, 20 * MINUTE_IN_SECONDS );
			} elseif ( 'limit' === $c ) {
				set_transient( 'mrsh_ai_skip_' . $id, 1, 6 * HOUR_IN_SECONDS );
			} elseif ( 'nomodel' === $c ) {
				set_transient( 'mrsh_ai_skip_' . $id, 1, 3 * HOUR_IN_SECONDS );
			} elseif ( 'url' === $c ) {
				return $r;
			}
		}
		if ( $tried && $auth === $tried && class_exists( 'MRSH_Fixer' ) ) {
			MRSH_Fixer::ticket( 'ai_key', 'The AI services rejected their keys', 'Open the AI Assistant page and paste a working key for at least one service. Approve this ticket after you fixed it.', 'high', 'needs_approval' );
		}
		if ( ! $tried ) {
			return new WP_Error( 'busy', 'Every AI service is resting after a limit or a rejected key. It tries again automatically.' );
		}
		return $last;
	}

	/** Remember the last problem of each service so the page can show it. */
	private static function err( $id, $msg ) {
		$e = get_option( 'mrsh_aihub_err', array() );
		$e = is_array( $e ) ? $e : array();
		if ( '' === $msg ) {
			unset( $e[ $id ] );
		} else {
			$e[ $id ] = array( time(), mb_substr( $msg, 0, 220 ) );
		}
		update_option( 'mrsh_aihub_err', $e, false );
	}

	private static function save_model( $id, $m ) {
		$o = self::o();
		if ( 'main' === $id ) {
			$o['model'] = $m;
		} elseif ( isset( $o['pool'][ $id ] ) ) {
			$o['pool'][ $id ]['model'] = $m;
		}
		update_option( self::OPT, $o );
	}

	/** Ask the service which models it has and pick a sensible text model, so a renamed or retired model fixes itself. */
	private static function discover( $cfg ) {
		$bad = '/embed|whisper|guard|safeguard|tts|speech|orpheus|playai|canopy|image|vision|audio|live|moderation|rerank|preview|exp\b|thinking|transcri|compound|distil/i';
		if ( 'gemini' === $cfg['kind'] ) {
			$r = wp_remote_get( 'https://generativelanguage.googleapis.com/v1beta/models?pageSize=100', array( 'timeout' => 20, 'headers' => array( 'x-goog-api-key' => $cfg['key'] ) ) );
			$j = is_wp_error( $r ) ? null : json_decode( wp_remote_retrieve_body( $r ), true );
			$c = array();
			foreach ( (array) ( $j['models'] ?? array() ) as $m ) {
				$n = preg_replace( '#^models/#', '', (string) ( $m['name'] ?? '' ) );
				if ( $n && preg_match( '/flash/i', $n ) && ! preg_match( $bad, $n ) && in_array( 'generateContent', (array) ( $m['supportedGenerationMethods'] ?? array() ), true ) ) {
					$c[] = $n;
				}
			}
			usort( $c, static function ( $a, $b ) {
				return strnatcasecmp( $b, $a );
			} );
			return $c ? $c[0] : '';
		}
		if ( 'openai' !== $cfg['kind'] || '' === $cfg['base'] ) {
			return '';
		}
		$r = wp_remote_get( $cfg['base'] . '/models', array( 'timeout' => 20, 'headers' => array( 'Authorization' => 'Bearer ' . $cfg['key'] ) ) );
		$j = is_wp_error( $r ) ? null : json_decode( wp_remote_retrieve_body( $r ), true );
		$ids = array();
		foreach ( (array) ( $j['data'] ?? array() ) as $m ) {
			$n = (string) ( $m['id'] ?? '' );
			if ( $n && ! preg_match( $bad, $n ) ) {
				$ids[] = $n;
			}
		}
		if ( ! $ids ) {
			return '';
		}
		$orp  = false !== strpos( $cfg['base'], 'openrouter' );
		$pool = $orp ? array_values( preg_grep( '/:free$/', $ids ) ) : $ids;
		usort( $pool, static function ( $x, $y ) {
			return strnatcasecmp( $y, $x );
		} );
		foreach ( array( 'llama-3\.3-70b', 'gpt-oss-120b', 'llama-?3\.1-70b', 'gpt-oss-20b', 'gpt-4o-mini', 'mistral-small', 'llama.*70b', 'qwen', 'gemma', 'llama', 'mistral', 'deepseek' ) as $re ) {
			$g = array_values( preg_grep( '/' . $re . '/i', $pool ) );
			if ( $g ) {
				return $g[0];
			}
		}
		return '';
	}

	private static function note( $id ) {
		$u = get_option( self::USE, array() );
		$u = is_array( $u ) ? $u : array();
		if ( ( $u['d'] ?? '' ) !== wp_date( 'Y-m-d' ) ) {
			return;
		}
		$u['p'][ $id ] = (int) ( $u['p'][ $id ] ?? 0 ) + 1;
		update_option( self::USE, $u, false );
	}

	/** One request to one service. Error codes: url, auth, busy (limit or server trouble), http, empty. */
	private static function call_one( $cfg, $system, $user, $max ) {
		$kind  = $cfg['kind'];
		$model = $cfg['model'];
		$key   = $cfg['key'];
		if ( 'anthropic' === $kind ) {
			$url  = 'https://api.anthropic.com/v1/messages';
			$hdr  = array( 'x-api-key' => $key, 'anthropic-version' => '2023-06-01', 'content-type' => 'application/json' );
			$body = array( 'model' => $model, 'max_tokens' => max( (int) $max, 1500 ), 'thinking' => array( 'type' => 'disabled' ), 'system' => $system, 'messages' => array( array( 'role' => 'user', 'content' => $user ) ) ); // answers only: thinking would use up the tokens
		} elseif ( 'gemini' === $kind ) {
			$url  = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode( $model ) . ':generateContent';
			$hdr  = array( 'x-goog-api-key' => $key, 'content-type' => 'application/json' );
			$body = array( 'systemInstruction' => array( 'parts' => array( array( 'text' => $system ) ) ), 'contents' => array( array( 'role' => 'user', 'parts' => array( array( 'text' => $user ) ) ) ), 'generationConfig' => array( 'maxOutputTokens' => (int) $max ) );
		} else {
			$url  = $cfg['base'] . '/chat/completions';
			$hdr  = array( 'Authorization' => 'Bearer ' . $key, 'content-type' => 'application/json' );
			$body = array( 'model' => $model, 'max_tokens' => (int) $max, 'messages' => array( array( 'role' => 'system', 'content' => $system ), array( 'role' => 'user', 'content' => $user ) ) );
			if ( preg_match( '/gpt-oss|o1|o3|deepseek-r1|reasoning/i', $model ) ) {
				$body['max_tokens'] = max( (int) $max, 1500 ); // thinking models spend tokens before the answer
				if ( false !== stripos( $model, 'gpt-oss' ) ) {
					$body['reasoning_effort'] = 'low';
				}
			}
		}
		if ( 0 !== strpos( $url, 'https://' ) ) {
			return new WP_Error( 'url', 'The service address must start with https://' );
		}
		$r = wp_remote_post( $url, array( 'timeout' => 45, 'headers' => $hdr, 'body' => wp_json_encode( $body ) ) );
		if ( is_wp_error( $r ) ) {
			return new WP_Error( 'busy', $cfg['label'] . ': ' . $r->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $r );
		$j    = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( 'anthropic' === $kind && 400 === $code && isset( $body['thinking'] ) && preg_match( '/thinking/i', wp_remote_retrieve_body( $r ) ) ) {
			unset( $body['thinking'] ); // a model that does not accept the switch: ask again without it
			$body['max_tokens'] = max( (int) $body['max_tokens'], 4000 );
			$r = wp_remote_post( $url, array( 'timeout' => 45, 'headers' => $hdr, 'body' => wp_json_encode( $body ) ) );
			if ( is_wp_error( $r ) ) {
				return new WP_Error( 'busy', $cfg['label'] . ': ' . $r->get_error_message() );
			}
			$code = (int) wp_remote_retrieve_response_code( $r );
			$j    = json_decode( wp_remote_retrieve_body( $r ), true );
		}
		if ( 401 === $code || 403 === $code ) {
			return new WP_Error( 'auth', $cfg['label'] . ' rejected the key (HTTP ' . $code . ').' );
		}
		$why = is_array( $j ) ? ( $j['error']['message'] ?? ( is_string( $j['error'] ?? null ) ? $j['error'] : '' ) ) : '';
		if ( ( $code >= 400 && $code < 500 && preg_match( '/credit|billing|balance|depleted|insufficient|quota|exhausted/i', (string) $why ) ) || 402 === $code ) {
			return new WP_Error( 'limit', $cfg['label'] . ' has no free credit or quota left: ' . mb_substr( (string) $why, 0, 140 ) );
		}
		if ( 404 === $code || ( 400 === $code && preg_match( '/model|decommission|not found|deprecat/i', (string) $why ) ) ) {
			return new WP_Error( 'nomodel', $cfg['label'] . ' does not know the model "' . $model . '" (HTTP ' . $code . ').' );
		}
		if ( 429 === $code || $code >= 500 || 402 === $code ) {
			return new WP_Error( 'busy', $cfg['label'] . ' is busy or its free limit is used (HTTP ' . $code . ')' . ( $why ? ': ' . mb_substr( (string) $why, 0, 140 ) : '.' ) );
		}
		if ( $code < 200 || $code >= 300 ) {
			return new WP_Error( 'http', $cfg['label'] . ' answered HTTP ' . $code . ( $why ? ': ' . mb_substr( (string) $why, 0, 160 ) : '' ) );
		}
		if ( 'anthropic' === $kind ) {
			$t = '';
			foreach ( (array) ( $j['content'] ?? array() ) as $b ) {
				$t .= $b['text'] ?? '';
			}
		} elseif ( 'gemini' === $kind ) {
			$t = '';
			foreach ( (array) ( $j['candidates'][0]['content']['parts'] ?? array() ) as $b ) {
				$t .= $b['text'] ?? '';
			}
		} else {
			$t = (string) ( $j['choices'][0]['message']['content'] ?? '' );
		}
		$t = trim( $t );
		if ( '' === $t ) {
			return new WP_Error( 'empty', $cfg['label'] . ' sent an empty answer: ' . mb_substr( preg_replace( '/\s+/', ' ', wp_strip_all_tags( wp_remote_retrieve_body( $r ) ) ), 0, 140 ) );
		}
		return $t;
	}

	/* ---------- handlers ---------- */

	private static function guard( $action ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( $action );
	}

	private static function back( $msg = '' ) {
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . ( $msg ? '&done=' . rawurlencode( $msg ) : '' ) ) );
		exit;
	}

	public static function save() {
		self::guard( 'mrsh_aihub_save' );
		$old = self::o();
		$p   = sanitize_key( wp_unslash( $_POST['provider'] ?? 'anthropic' ) ); // phpcs:ignore
		$key = trim( (string) wp_unslash( $_POST['key'] ?? '' ) ); // phpcs:ignore
		if ( ! empty( $_POST['clearkey'] ) ) { // phpcs:ignore
			$key = '';
		} elseif ( '' === $key ) {
			$key = (string) $old['key'];
		}
		$pool = is_array( $old['pool'] ) ? $old['pool'] : array();
		if ( isset( $_POST['pool_key'] ) ) { // phpcs:ignore
		$pool = array();
		foreach ( self::pool_providers() as $id => $d ) {
			$pk = trim( (string) wp_unslash( $_POST['pool_key'][ $id ] ?? '' ) ); // phpcs:ignore
			if ( ! empty( $_POST['pool_clear'][ $id ] ) ) { // phpcs:ignore
				$pk = '';
			} elseif ( '' === $pk ) {
				$pk = (string) ( $old['pool'][ $id ]['key'] ?? '' );
			}
			if ( '' !== $pk ) {
				$pool[ $id ] = array( 'key' => sanitize_text_field( $pk ), 'model' => sanitize_text_field( wp_unslash( $_POST['pool_model'][ $id ] ?? '' ) ) ); // phpcs:ignore
			}
		}
		}
		$new = array(
			'pool'       => $pool,
			'on'         => empty( $_POST['on'] ) ? 0 : 1, // phpcs:ignore
			'provider'   => isset( self::providers()[ $p ] ) ? $p : 'anthropic',
			'key'        => sanitize_text_field( $key ),
			'model'      => sanitize_text_field( wp_unslash( $_POST['model'] ?? '' ) ), // phpcs:ignore
			'base'       => esc_url_raw( wp_unslash( $_POST['base'] ?? '' ) ), // phpcs:ignore
			'cap'        => max( 5, min( 2000, (int) ( $_POST['cap'] ?? 60 ) ) ), // phpcs:ignore
			'reply'      => empty( $_POST['reply'] ) ? 0 : 1, // phpcs:ignore
			'reply_mode' => 'draft' === ( $_POST['reply_mode'] ?? '' ) ? 'draft' : 'auto', // phpcs:ignore
			'draft'      => empty( $_POST['draft'] ) ? 0 : 1, // phpcs:ignore
			'login'      => empty( $_POST['login'] ) ? 0 : 1, // phpcs:ignore
			'spell'      => empty( $_POST['spell'] ) ? 0 : 1, // phpcs:ignore
			'meta'       => empty( $_POST['meta'] ) ? 0 : 1, // phpcs:ignore
			'prof'       => empty( $_POST['prof'] ) ? 0 : 1, // phpcs:ignore
		);
		update_option( self::OPT, $new, false );
		self::back( 'Settings saved.' );
	}

	public static function test() {
		self::guard( 'mrsh_aihub_test' );
		$r = self::ask( 'Reply with exactly the two words: Connection works.', 'Test', 20 );
		self::back( is_wp_error( $r ) ? 'Test failed: ' . $r->get_error_message() : 'AI answered: ' . mb_substr( $r, 0, 80 ) );
	}

	public static function run() {
		self::guard( 'mrsh_aihub_run' );
		$job = sanitize_key( wp_unslash( $_POST['job'] ?? '' ) ); // phpcs:ignore
		if ( ! class_exists( 'MRSH_AIJobs' ) ) {
			self::back( 'Jobs are not loaded.' );
		}
		self::back( MRSH_AIJobs::run_job( $job, true ) );
	}

	/* ---------- page ---------- */

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$o    = self::o();
		$post = esc_url( admin_url( 'admin-post.php' ) );
		$st   = class_exists( 'MRSH_AIJobs' ) ? MRSH_AIJobs::stats() : array( 'answered' => 0, 'drafts' => 0, 'helped' => 0, 'polish' => 0 );
		MRSH_Admin::open( 'AI Assistant', 'Free AI services (or your own account) help members and write drafts for you. Off until you add a key and switch it on.' );
		if ( ! empty( $_GET['done'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( wp_unslash( $_GET['done'] ) ) . '</p></div>'; // phpcs:ignore
		}
		echo '<div class="mrsh-grid mrsh-grid-4">';
		echo MRSH_Admin::stat( 'Assistant', self::ready() ? 'On' : 'Off', self::chain() ? ( $o['on'] ? count( self::chain() ) . ' service(s) ready' : 'switched off' ) : 'no key saved yet' ); // phpcs:ignore
		echo MRSH_Admin::stat( 'AI calls today', self::used_today() . ' / ' . (int) $o['cap'], 'daily limit protects your bill' ); // phpcs:ignore
		echo MRSH_Admin::stat( 'Members helped', (int) $st['answered'] + (int) $st['helped'], 'answers and login help sent' ); // phpcs:ignore
		echo MRSH_Admin::stat( 'Drafts waiting', (int) $st['drafts'], 'approve in Auto-Fixer' ); // phpcs:ignore
		echo '</div>';

		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Free AI pool (no cost)</h2></div>';
		echo '<p class="mrsh-muted">Add a free key from as many services as you like. They are tried from the top (Groq first). If one is busy or has used its free quota, the next one answers, and your Claude account below is used only when every free service is out. Free plans and model names change over time: if a test fails, change the model name in that row.</p>';
		$use = get_option( self::USE, array() );
		$use = is_array( $use ) && ( $use['d'] ?? '' ) === wp_date( 'Y-m-d' ) ? (array) ( $use['p'] ?? array() ) : array();
		$errs = (array) get_option( 'mrsh_aihub_err', array() );
		echo '<form method="post" action="' . $post . '">';
		wp_nonce_field( 'mrsh_aihub_save' );
		echo '<input type="hidden" name="action" value="mrsh_aihub_save">';
		foreach ( array( 'on', 'provider', 'model', 'base', 'cap', 'reply_mode' ) as $f ) {
			echo '<input type="hidden" name="' . esc_attr( $f ) . '" value="' . esc_attr( $o[ $f ] ) . '">';
		}
		foreach ( array( 'reply', 'draft', 'login', 'spell', 'meta', 'prof' ) as $f ) {
			if ( $o[ $f ] ) {
				echo '<input type="hidden" name="' . esc_attr( $f ) . '" value="1">';
			}
		}
		echo '<table class="mrsh-table"><thead><tr><th>Service</th><th>Status</th><th>Key</th><th>Model</th><th>Today / last problem</th></tr></thead><tbody>';
		foreach ( self::pool_providers() as $id => $d ) {
			$e    = $o['pool'][ $id ] ?? array();
			$has  = ! empty( $e['key'] );
			$rest = $has && get_transient( 'mrsh_ai_skip_' . $id );
			echo '<tr><td><b>' . esc_html( $d[0] ) . '</b><br><span class="mrsh-muted">get a free key: ' . esc_html( $d[4] ) . '</span></td><td>';
			echo MRSH_Admin::badge( ! $has ? 'unknown' : ( $rest ? 'warn' : 'pass' ), ! $has ? 'No key' : ( $rest ? 'Resting' : 'Ready' ) ); // phpcs:ignore
			echo '</td><td><input type="password" name="pool_key[' . esc_attr( $id ) . ']" autocomplete="new-password" data-lpignore="true" placeholder="' . ( $has ? 'saved (leave empty to keep)' : 'paste key' ) . '">';
			if ( $has ) {
				echo ' <label><input type="checkbox" name="pool_clear[' . esc_attr( $id ) . ']" value="1"> remove</label>';
			}
			echo '</td><td><input type="text" name="pool_model[' . esc_attr( $id ) . ']" value="' . esc_attr( $e['model'] ?? '' ) . '" placeholder="' . esc_attr( $d[3] ) . '"></td><td>' . (int) ( $use[ $id ] ?? 0 ) . ' answers' . ( ! empty( $errs[ $id ] ) ? '<br><span class="mrsh-muted">' . esc_html( $errs[ $id ][1] ) . '</span>' : '' ) . '</td></tr>';
		}
		echo '</tbody></table><p><button class="button button-primary">Save free pool</button> ';
		echo '</p></form></div>';

		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Connection and switches</h2></div><form method="post" action="' . $post . '">';
		wp_nonce_field( 'mrsh_aihub_save' );
		echo '<input type="hidden" name="action" value="mrsh_aihub_save">';
		echo '<p><label><input type="checkbox" name="on" value="1"' . checked( $o['on'], 1, false ) . '> <b>Switch the AI assistant on</b></label></p>';
		echo '<p><label>AI service <select name="provider">';
		foreach ( self::providers() as $k => $v ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $o['provider'], $k, false ) . '>' . esc_html( $v[0] ) . '</option>';
		}
		echo '</select></label></p>';
		echo '<p><label>API key <input type="password" name="key" class="regular-text" autocomplete="new-password" data-lpignore="true" placeholder="' . ( '' !== trim( (string) $o['key'] ) ? 'saved (leave empty to keep it)' : 'paste your key' ) . '"></label> ';
		if ( '' !== trim( (string) $o['key'] ) ) {
			echo '<label><input type="checkbox" name="clearkey" value="1"> remove saved key</label>';
		}
		echo '</p><p><label>Model <input type="text" name="model" class="regular-text" value="' . esc_attr( $o['model'] ) . '" placeholder="empty = ' . esc_attr( self::providers()[ $o['provider'] ][1] ?? '' ) . '"></label></p>';
		echo '<p><label>Service address (only for OpenAI-compatible) <input type="url" name="base" class="regular-text" value="' . esc_attr( $o['base'] ) . '" placeholder="https://api.openai.com/v1"></label></p>';
		echo '<p><label>Daily limit <input type="number" name="cap" min="5" max="2000" value="' . (int) $o['cap'] . '" style="width:80px"> AI calls per day</label></p>';
		echo '<hr><p><b>What the assistant may do</b></p>';
		echo '<p><label><input type="checkbox" name="reply" value="1"' . checked( $o['reply'], 1, false ) . '> Answer support tickets</label> &nbsp; <label>mode <select name="reply_mode"><option value="auto"' . selected( $o['reply_mode'], 'auto', false ) . '>send simple answers by itself (login, profile, photo, verification)</option><option value="draft"' . selected( $o['reply_mode'], 'draft', false ) . '>write drafts only, I send them</option></select></label></p>';
		echo '<p class="description">Payments, reports, fraud, threats, refunds and account deletion are never answered by itself. The AI writes a private draft for you instead.</p>';
		echo '<p><label><input type="checkbox" name="draft" value="1"' . checked( $o['draft'], 1, false ) . '> Write one new guide draft per day (stays a draft until you approve it)</label></p>';
		echo '<p><label><input type="checkbox" name="login" value="1"' . checked( $o['login'], 1, false ) . '> Help members who fail to log in (works even without an AI key)</label></p>';
		echo '<p><label><input type="checkbox" name="spell" value="1"' . checked( $o['spell'], 1, false ) . '> Spelling hints and an "Improve my text" button while members type</label></p>';
		echo '<p><label><input type="checkbox" name="meta" value="1"' . checked( $o['meta'], 1, false ) . '> Write the search-result description for pages that have none</label></p>';
		echo '<p><label><input type="checkbox" name="prof" value="1"' . checked( $o['prof'], 1, false ) . '> Check new profile texts for contact details, scams or rude words (only warns you in the Inbox, never hides anything)</label></p>';
		echo '<button class="button button-primary">Save settings</button></form>';
		echo '<div class="mrsh-actions" style="margin-top:12px">';
		MRSH_Admin::post_button( 'mrsh_aihub_test', 'Test the AI connection', false );
		echo '</div></div>';

		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Run a job now</h2></div><p class="mrsh-muted">The robot runs these by itself every hour. Use the buttons when you do not want to wait.</p><div class="mrsh-actions">';
		foreach ( array( 'reply' => 'Answer waiting tickets', 'draft' => 'Write today\'s guide draft', 'login' => 'Help members with login trouble', 'meta' => 'Write missing descriptions', 'prof' => 'Check new profile texts' ) as $j => $label ) {
			echo '<form method="post" action="' . $post . '" class="mrsh-inline">';
			wp_nonce_field( 'mrsh_aihub_run' );
			echo '<input type="hidden" name="action" value="mrsh_aihub_run"><input type="hidden" name="job" value="' . esc_attr( $j ) . '"><button class="button">' . esc_html( $label ) . '</button></form>';
		}
		echo '</div></div>';

		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Already automatic, no AI needed</h2></div><ul class="mrsh-checklist">';
		foreach ( array(
			'Keywords: every page gets its best phrase automatically (SEO and search > Auto keywords).',
			'Photos: every upload becomes a small clean WebP and the GPS data is removed (Settings > Photo Optimizer).',
			'Picture descriptions: missing alt text is filled in automatically.',
			'Profile reminders: members with unfinished profiles get a polite nudge (Members and matches > Profile reminders).',
			'Site health: the Auto-Fixer robot checks the site every hour.',
		) as $line ) {
			echo '<li>' . esc_html( $line ) . '</li>';
		}
		echo '</ul></div>';

		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Privacy and cost</h2></div><ul class="mrsh-checklist">';
		foreach ( array(
			'Text goes to the AI service you chose, with email addresses and phone numbers removed first. Mention this in your privacy policy.',
			'Free services cost nothing; if you add a paid account, the daily limit above stops a surprise bill.',
			'The AI never sees passwords, never publishes anything, and never deletes anything.',
			'Every answer sent to a member says it was written by an automated assistant, and a person can still be reached by replying.',
		) as $line ) {
			echo '<li>' . esc_html( $line ) . '</li>';
		}
		echo '</ul></div>';
		MRSH_Admin::close();
	}
}
MRSH_AIHub::init();
