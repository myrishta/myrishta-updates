<?php
/**
 * Package orders. Every package request becomes an order (open). When the member gets the package (robot, ticket or
 * by hand) the order closes by itself. Nothing can be missed: an order stays open until the plan is really on the
 * account. Prices are stored on the order, so paid packages work later without changes.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Orders {

	const CPT = 'mrsh_order';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ), 5 );
		add_action( 'added_user_meta', array( __CLASS__, 'on_meta' ), 10, 4 );
		add_action( 'updated_user_meta', array( __CLASS__, 'on_meta' ), 10, 4 );
		add_action( 'mrsh_tk_poll', array( __CLASS__, 'sweep' ), 55 );
		add_action( 'admin_post_mrsh_ord', array( __CLASS__, 'act' ) );
	}

	public static function register() {
		register_post_type( self::CPT, array( 'label' => 'Package orders', 'public' => false, 'show_ui' => false, 'show_in_rest' => false, 'supports' => array( 'title' ), 'rewrite' => false, 'query_var' => false ) );
	}

	private static function plan_row( $name ) {
		if ( ! function_exists( 'mrt_plans' ) ) {
			return null;
		}
		foreach ( mrt_plans() as $i => $p ) {
			if ( 0 === strcasecmp( trim( $p[0] ), trim( (string) $name ) ) ) {
				return array( $i, $p );
			}
		}
		return null;
	}

	/** The open order of this member for this plan, or 0. */
	public static function find_open( $uid, $plan ) {
		$q = get_posts( array( 'post_type' => self::CPT, 'post_status' => 'publish', 'numberposts' => 1, 'fields' => 'ids', 'no_found_rows' => true, 'meta_query' => array( 'relation' => 'AND', array( 'key' => '_uid', 'value' => (int) $uid ), array( 'key' => '_plan', 'value' => $plan ), array( 'key' => '_state', 'value' => 'open' ) ) ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		return $q ? (int) $q[0] : 0;
	}

	/** Make an order for a package request (once per open request). */
	public static function open( $uid, $plan, $src = 'request' ) {
		$uid  = (int) $uid;
		$plan = trim( (string) $plan );
		$row  = self::plan_row( $plan );
		if ( ! $uid || '' === $plan || ! $row || 0 === (int) $row[0] || ! post_type_exists( self::CPT ) ) {
			return 0; // Free is what everybody already has
		}
		$u = get_userdata( $uid );
		if ( ! $u || 0 === strcasecmp( (string) get_user_meta( $uid, 'mrt_plan', true ), $row[1][0] ) ) {
			return 0;
		}
		$ex = self::find_open( $uid, $row[1][0] );
		if ( $ex ) {
			return $ex;
		}
		$price = (string) $row[1][1];
		$free  = (bool) get_option( 'mrsh_plans_free', 0 ) || (bool) preg_match( '/^(free|0|rs\.?\s*0)\b/i', trim( $price ) );
		$amt   = $free ? 0 : (int) preg_replace( '/\D/', '', $price );
		$id    = wp_insert_post( array( 'post_type' => self::CPT, 'post_status' => 'publish', 'post_title' => $row[1][0] . ' package for ' . ( $u->display_name ?: $u->user_login ) ) );
		if ( ! $id || is_wp_error( $id ) ) {
			return 0;
		}
		update_post_meta( $id, '_uid', $uid );
		update_post_meta( $id, '_plan', $row[1][0] );
		update_post_meta( $id, '_price', $price );
		update_post_meta( $id, '_amount', $amt );
		update_post_meta( $id, '_free', $free ? 1 : 0 );
		update_post_meta( $id, '_paid', $free ? 1 : 0 ); // a free order needs no payment
		update_post_meta( $id, '_src', sanitize_key( $src ) );
		update_post_meta( $id, '_state', 'open' );
		delete_transient( 'mrsh_cnt' );
		return (int) $id;
	}

	public static function close( $id, $state, $note = '' ) {
		update_post_meta( $id, '_state', $state );
		update_post_meta( $id, '_closed', time() );
		if ( ! get_post_meta( $id, '_by', true ) ) {
			// Who closed it: the team member who is logged in, otherwise the package robot / safety net.
			$me = get_current_user_id();
			update_post_meta( $id, '_by', ( $me && current_user_can( 'manage_options' ) && $me !== (int) get_post_meta( $id, '_uid', true ) ) ? 'u:' . $me : 'auto' );
		}
		if ( $note ) {
			update_post_meta( $id, '_note', sanitize_text_field( $note ) );
		}
		delete_transient( 'mrsh_cnt' );
	}

	/** A request creates an order; the plan landing on the account closes it. */
	public static function on_meta( $mid, $uid, $key, $val ) {
		if ( 'mrt_plan_req' === $key && '' !== trim( (string) $val ) ) {
			self::open( $uid, (string) $val, 'request' );
		} elseif ( 'mrt_plan' === $key && '' !== trim( (string) $val ) ) {
			$id = self::find_open( $uid, (string) $val );
			if ( $id ) {
				self::close( $id, 'done', 'Package is on the account.' );
				if ( class_exists( 'MRSH_Attn' ) ) {
					MRSH_Attn::close( 'planreq', (int) $uid );
				}
			}
		}
	}

	/** Safety net, every few minutes: close what is done, and put a free request back in front of the robot when its mark has gone. */
	public static function sweep() {
		if ( get_transient( 'mrsh_ord_run' ) ) {
			return;
		}
		set_transient( 'mrsh_ord_run', 1, 10 * MINUTE_IN_SECONDS );
		$os = get_posts( array( 'post_type' => self::CPT, 'post_status' => 'publish', 'numberposts' => 40, 'orderby' => 'ID', 'order' => 'ASC', 'meta_key' => '_state', 'meta_value' => 'open' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		foreach ( $os as $o ) {
			$uid  = (int) get_post_meta( $o->ID, '_uid', true );
			$plan = (string) get_post_meta( $o->ID, '_plan', true );
			if ( ! get_userdata( $uid ) ) {
				self::close( $o->ID, 'cancelled', 'Member no longer exists.' );
				continue;
			}
			if ( 0 === strcasecmp( (string) get_user_meta( $uid, 'mrt_plan', true ), $plan ) ) {
				self::close( $o->ID, 'done', 'Package is on the account.' );
				continue;
			}
			if ( get_post_meta( $o->ID, '_free', true ) && '' === trim( (string) get_user_meta( $uid, 'mrt_plan_req', true ) ) && ( time() - strtotime( $o->post_date_gmt . ' UTC' ) ) > 15 * MINUTE_IN_SECONDS ) {
				update_user_meta( $uid, 'mrt_plan_req', $plan ); // the package robot looks at it again (it gives the package or tells the member what is missing)
			}
		}
	}

	/** Declined from the member manager: close that member's open orders as declined. */
	public static function reject_user( $uid ) {
		$q = get_posts( array( 'post_type' => self::CPT, 'post_status' => 'publish', 'numberposts' => 20, 'fields' => 'ids', 'meta_query' => array( array( 'key' => '_uid', 'value' => (int) $uid ), array( 'key' => '_state', 'value' => 'open' ) ) ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		foreach ( $q as $id ) {
			self::close( $id, 'rejected', 'Declined by the team.' );
		}
	}

	public static function open_count() {
		$q = new WP_Query( array( 'post_type' => self::CPT, 'post_status' => 'publish', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_state', 'meta_value' => 'open', 'no_found_rows' => false ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		return (int) $q->found_posts;
	}

	public static function act() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		$id = isset( $_REQUEST['oid'] ) ? absint( $_REQUEST['oid'] ) : 0;
		check_admin_referer( 'mrsh_ord' . $id );
		$a   = isset( $_REQUEST['do'] ) ? sanitize_key( $_REQUEST['do'] ) : '';
		$msg = 'Done.';
		if ( $id && self::CPT === get_post_type( $id ) ) {
			$uid  = (int) get_post_meta( $id, '_uid', true );
			$plan = (string) get_post_meta( $id, '_plan', true );
			if ( 'approve' === $a ) {
				$days = isset( $_REQUEST['days'] ) && '' !== $_REQUEST['days'] ? max( 0, min( 3650, absint( $_REQUEST['days'] ) ) ) : ( get_post_meta( $id, '_free', true ) ? 180 : 30 );
				if ( $days ) { update_user_meta( $uid, 'mrt_plan_exp', time() + $days * DAY_IN_SECONDS ); } else { delete_user_meta( $uid, 'mrt_plan_exp' ); }
				update_user_meta( $uid, 'mrt_plan', $plan ); // closes the order through the hook
				update_post_meta( $id, '_paid', 1 );
				delete_user_meta( $uid, 'mrt_plan_req' );
				delete_user_meta( $uid, 'mrsh_pr_held' );
				$u = get_userdata( $uid );
				if ( $u && is_email( $u->user_email ) ) {
					wp_mail( $u->user_email, 'Your ' . $plan . ' package is ready - My Rishta Pakistan', 'Hello ' . ( $u->display_name ?: $u->user_login ) . ",\n\nYour account now has the " . $plan . " package. You can see it in My account.\n\nآپ کے اکاؤنٹ میں اب " . $plan . " پیکج لگ گیا ہے۔ آپ اسے My account میں دیکھ سکتے ہیں۔\n\n--\nMy Rishta Pakistan Support" );
				}
				$msg = $plan . ' package given.';
			} elseif ( 'reject' === $a ) {
				self::close( $id, 'rejected', 'Declined by the team.' );
				delete_user_meta( $uid, 'mrt_plan_req' );
				if ( class_exists( 'MRSH_Attn' ) ) {
					MRSH_Attn::close( 'planreq', $uid );
				}
				$msg = 'Order declined.';
			} elseif ( 'paid' === $a ) {
				update_post_meta( $id, '_paid', 1 );
				$msg = 'Marked as paid.';
			}
		}
		wp_safe_redirect( add_query_arg( array( 'page' => 'mrsh-orders', 'msg' => rawurlencode( $msg ) ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$st = isset( $_GET['st'] ) && 'closed' === $_GET['st'] ? 'closed' : 'open'; // phpcs:ignore WordPress.Security.NonceVerification
		MRSH_Boost::ui_open( 'Package orders', 'Every package request is an order. It closes by itself when the member gets the package, so no upgrade is missed. If packages get a price later, the same orders carry the payment.', 'g-blue', 'M7 4h10l3 4v12H4V8zm0 0h10M9 12h6M9 16h4' );
		if ( isset( $_GET['msg'] ) ) { // phpcs:ignore
			MRSH_Boost::ui_ok( sanitize_text_field( wp_unslash( $_GET['msg'] ) ) ); // phpcs:ignore
		}
		$open = self::open_count();
		$cl   = new WP_Query( array( 'post_type' => self::CPT, 'post_status' => 'publish', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_state', 'meta_value' => 'done' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		echo '<div class="mx-stats">' . MRSH_Boost::ui_stat( $open, 'Open orders', $open ? '#dc2626' : '#16a34a' ) . MRSH_Boost::ui_stat( (int) $cl->found_posts, 'Packages given', '#7c3aed' ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		$base = admin_url( 'admin.php?page=mrsh-orders' );
		echo '<p><a class="button' . ( 'open' === $st ? ' button-primary' : '' ) . '" href="' . esc_url( $base ) . '">Open (' . (int) $open . ')</a> <a class="button' . ( 'closed' === $st ? ' button-primary' : '' ) . '" href="' . esc_url( add_query_arg( 'st', 'closed', $base ) ) . '">Closed</a></p>';
		$args = array( 'post_type' => self::CPT, 'post_status' => 'publish', 'posts_per_page' => 60, 'orderby' => 'ID', 'order' => 'open' === $st ? 'ASC' : 'DESC' );
		if ( 'open' === $st ) {
			$args['meta_key']   = '_state'; // phpcs:ignore WordPress.DB.SlowDBQuery
			$args['meta_value'] = 'open'; // phpcs:ignore WordPress.DB.SlowDBQuery
		} else {
			$args['meta_query'] = array( array( 'key' => '_state', 'value' => 'open', 'compare' => '!=' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		}
		$os = get_posts( $args );
		echo '<div class="mx-card">';
		if ( ! $os ) {
			echo '<p style="margin:0;color:#6b7280">' . ( 'open' === $st ? 'No open orders. Every package request has been dealt with.' : 'No closed orders yet.' ) . '</p></div>';
			echo '</div>';
			return;
		}
		echo '<table class="widefat striped"><thead><tr><th>Date</th><th>Member</th><th>Package</th><th>Price</th><th>Profile</th><th>Status</th><th></th></tr></thead><tbody>';
		foreach ( $os as $o ) {
			$uid  = (int) get_post_meta( $o->ID, '_uid', true );
			$u    = get_userdata( $uid );
			$plan = (string) get_post_meta( $o->ID, '_plan', true );
			$stt  = (string) get_post_meta( $o->ID, '_state', true );
			$pct  = ( $u && class_exists( 'MRSH_Concierge' ) ) ? (int) MRSH_Concierge::profile_pct( $uid )[0] : 0;
			$name = $u ? ( $u->display_name ?: $u->user_login ) : 'Deleted member';
			echo '<tr><td>' . esc_html( mysql2date( 'j M, g:i a', $o->post_date ) ) . '</td><td><b>' . esc_html( $name ) . '</b> <span class="description">#' . (int) $uid . '</span>' . ( $u ? '<br><a href="' . esc_url( add_query_arg( array( 'page' => 'mrsh-desk', 'q' => $u->user_email ), admin_url( 'admin.php' ) ) ) . '">Member manager</a>' : '' ) . '</td><td>' . esc_html( $plan ) . '</td><td>' . esc_html( (string) get_post_meta( $o->ID, '_price', true ) ) . ( get_post_meta( $o->ID, '_free', true ) ? '' : ( get_post_meta( $o->ID, '_paid', true ) ? ' <span style="color:#16a34a">paid</span>' : ' <span style="color:#dc2626">not paid</span>' ) ) . '</td><td>' . (int) $pct . '%</td><td>';
			echo esc_html( 'open' === $stt ? 'Open' : ( 'done' === $stt ? 'Given' : ucfirst( $stt ) ) ) . ( get_post_meta( $o->ID, '_closed', true ) ? '<br><span class="description">' . esc_html( wp_date( 'j M, g:i a', (int) get_post_meta( $o->ID, '_closed', true ) ) ) . '</span>' : '' );
			if ( 'open' !== $stt ) {
				$by = (string) get_post_meta( $o->ID, '_by', true );
				if ( 0 === strpos( $by, 'u:' ) ) {
					$bu    = get_userdata( (int) substr( $by, 2 ) );
					$bytxt = 'By ' . ( $bu ? ( $bu->display_name ?: $bu->user_login ) : 'a team member (deleted)' );
				} elseif ( 'auto' === $by ) {
					$bytxt = 'By the package robot (automatic)';
				} else {
					$bytxt = 'Who gave it was not recorded';
				}
				echo '<br><b style="font-size:12px;color:#4f46e5">' . esc_html( $bytxt ) . '</b>';
				$nt = (string) get_post_meta( $o->ID, '_note', true );
				if ( '' !== $nt ) {
					echo '<br><span class="description">' . esc_html( $nt ) . '</span>';
				}
			}
			echo '</td><td>';
			if ( 'open' === $stt ) {
				$n = wp_create_nonce( 'mrsh_ord' . $o->ID );
				foreach ( array( 'approve' => array( 'Give package', 'button-primary' ), 'reject' => array( 'Decline', '' ) ) as $do => $b ) {
					echo '<a class="button ' . esc_attr( $b[1] ) . '" href="' . esc_url( add_query_arg( array( 'action' => 'mrsh_ord', 'do' => $do, 'oid' => $o->ID, '_wpnonce' => $n ), admin_url( 'admin-post.php' ) ) ) . '">' . esc_html( $b[0] ) . '</a> ';
				}
			}
			echo '</td></tr>';
		}
		echo '</tbody></table></div>';
		echo '</div>';
	}
}
MRSH_Orders::init();
