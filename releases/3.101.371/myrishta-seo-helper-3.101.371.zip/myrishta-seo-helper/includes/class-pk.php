<?php
/**
 * Pakistani look: a green welcome strip with an Urdu greeting, ornament lines under section
 * headings and an original skyline banner (domes and minarets) with a short Urdu line.
 * All artwork is drawn here as small inline SVG, so there are no extra image downloads.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_PK {

	const STAR = '<svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="#fff" d="M15.5 3.2a9 9 0 1 0 0 17.6 7.2 7.2 0 1 1 0-17.6z"/><path fill="#fff" d="M19 8.2l.9 1.9 2.1.3-1.5 1.5.4 2.1-1.9-1-1.9 1 .4-2.1-1.5-1.5 2.1-.3z"/></svg>';

	public static function css() {
		$orn = rawurlencode( '<svg xmlns="http://www.w3.org/2000/svg" width="120" height="14" viewBox="0 0 120 14"><g fill="none" stroke="#c9a24b" stroke-width="1.2"><path d="M0 7h46M74 7h46"/></g><path fill="#01411C" d="M60 1l5 6-5 6-5-6z"/><path fill="#c9a24b" d="M48 7l3-3 3 3-3 3zM66 7l3-3 3 3-3 3z"/></svg>' );
		return '<style id="mrsh-pk">'
			. 'html body .btn-primary,html body button.btn-primary,html body .btn-block.btn-primary,html body .bg-primary:not(.button-featured):not(.button-featured-new):not(.menu-add){background-color:#01411c!important;border-color:#c9a24b!important;color:#fff!important}'
			. 'html body .custom-control-input:checked~.custom-control-label:before,html body .custom-control-input:checked~.custom-control-label::before{background-color:#01411c!important;border-color:#01411c!important}'
			. 'html body .badge-primary,html body .btn-info{background-color:#01411c!important}'
			. '.mrsh-cr{display:inline-flex;flex:0 0 32px;width:32px;height:32px;margin-right:8px;border-radius:50%;background:#01411c;color:#f1deaa;font:19px/32px Arial,sans-serif;align-items:center;justify-content:center}'
			. '.btn-primary,.btn-ppt,.btn-ppt2.btn-primary,.btn.btn-primary,.py-5.bg-primary.text-light{background-color:#01411c!important;border-color:#c9a24b!important;color:#fff!important}'
			. '.btn-primary:hover,.btn-ppt:hover{background-color:#0a5a32!important}'
			. '.py-5.bg-primary.text-light{border-radius:16px!important;border:2px solid #c9a24b!important;background-image:linear-gradient(135deg,#01411c,#0a5a32)!important}'
			. '.py-5.bg-primary.text-light .btn-system{background:#c9a24b!important;color:#1b2a12!important;border:0!important;border-radius:999px;font-weight:700}'
			. '.btn-system.btn-rounded-25{border-color:#01411c!important;color:#01411c!important}'
			. '@media(max-width:991px){'
			. '.ppt-page-body .card-page .card-body{padding:2px 8px!important}'
			. '.ppt-page-body .card-body h1,.ppt-page-body .card-body h2{font-size:26px;line-height:1.3;color:#01411c;margin:6px 0 14px;padding-bottom:10px;background:url(data:image/svg+xml;utf8,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20width%3D%2790%27%20height%3D%273%27%3E%3Crect%20width%3D%2790%27%20height%3D%273%27%20fill%3D%27%23c9a24b%27%2F%3E%3C%2Fsvg%3E) left bottom no-repeat}'
			. '.ppt-page-body .card-body h3,.ppt-page-body .card-body h4,.ppt-page-body .card-body h5,.ppt-page-body .card-body h6{font-size:19px;color:#01411c;margin:22px 0 8px}'
			. '.ppt-page-body .card-body p,.ppt-page-body .card-body li{font-size:16px;line-height:1.75;margin-bottom:12px}'
			. '.ppt-page-body .card-body ul,.ppt-page-body .card-body ol{padding-left:22px}'
			. '.ppt-page-body .card-body a{color:#01411c;text-decoration:underline;text-decoration-color:#c9a24b}'
			. 'header.navbar-light .logo-lg{padding-top:10px!important;padding-bottom:10px!important}'
			. 'header .textlogo{font-size:19px!important;line-height:1.2!important;font-weight:700;letter-spacing:.3px;color:#01411c!important;display:flex;align-items:center;gap:8px}'
			. ''
			. 'header .navbar-brand-dark{display:none!important}'
			. 'header a.btn[aria-label="Change language"]{display:none!important}'
			. 'header .menu-toggle{margin-left:0!important;color:#01411c;background:#f3efe2;border-radius:12px;padding:8px}'
			. '.hero1 .bg-image:after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(1,40,18,.78),rgba(1,65,28,.55))}'
			. '.hero1 h1{color:#fff!important;font-size:26px!important;line-height:1.3;text-shadow:0 2px 8px rgba(0,0,0,.35)}'
			. '.hero1 .lead{color:#f1deaa!important;font-size:16px}'
			. '.hero1 .h1buttonbox{margin-top:18px!important;gap:10px}'
			. '.hero1 .h1buttonbox a{flex:1;border-radius:999px;display:flex;align-items:center;justify-content:center;line-height:1.2;min-height:48px;padding:0 10px;font-size:15px;font-weight:600;border:0;box-shadow:0 4px 14px rgba(0,0,0,.25)}'
			. '.hero1 .h1buttonbox a:first-child{background:#c9a24b;color:#1b2a12}'
			. '.hero1 .h1buttonbox a:last-child{background:#fff;color:#01411c}'
			. '.show-mobile figure{background:linear-gradient(110deg,#e6ece7 30%,#f7faf7 50%,#e6ece7 70%);background-size:200% 100%;animation:mrshsk 1.4s linear infinite}'
			. '@keyframes mrshsk{to{background-position:-200% 0}}'
			. '.show-mobile figure{border-radius:12px;overflow:hidden}'
			. '.elementor-widget-container h2{font-size:24px;line-height:1.3}'
			. '#mobile-bottom-bar{left:10px!important;right:10px!important;width:auto!important;bottom:calc(8px + env(safe-area-inset-bottom))!important;height:68px!important;background:rgba(255,255,255,.97)!important;border:0;border-radius:24px;box-shadow:0 8px 28px rgba(1,40,18,.28),0 0 0 1px rgba(201,162,75,.45)!important}'
			. '#mobile-bottom-bar .suha-footer-nav ul{padding:0 6px!important}'
			. '#mobile-bottom-bar li{flex:1;text-align:center}'
			. '#mobile-bottom-bar li a.mrsh-on{color:#01411c!important}'
			. '#mobile-bottom-bar li a.mrsh-on:not(.menu-add):before{content:"";display:block;width:26px;height:3px;border-radius:3px;background:#c9a24b;margin:-6px auto 4px}'
			. '#mobile-bottom-bar li a{color:#4b5a50!important;font-size:11px!important;font-weight:600;text-align:center;line-height:1.2}'
			. '#mobile-bottom-bar li a i{display:block;font-size:20px;margin-bottom:3px;color:#01411c}'
			. '#mobile-bottom-bar li a:active,#mobile-bottom-bar li a:hover{color:#01411c!important}'
			. '#mobile-bottom-bar .menu-add{background:#01411c!important;border:4px solid #c9a24b;box-shadow:0 6px 16px rgba(1,65,28,.45)}'
			. '#mobile-bottom-bar .menu-add{display:flex!important;align-items:center;justify-content:center}'
			. '#mobile-bottom-bar .menu-add i{color:#fff!important;margin:0!important;font-size:22px;line-height:1}'
			. '}'
			. '.mrsh-pk-strip{display:flex;align-items:center;justify-content:center;gap:8px;flex-wrap:wrap;padding:7px 12px;background:#01411c;color:#fff;font-size:12.5px;line-height:1.4;text-align:center;border-bottom:3px solid #c9a24b}'
			. '.mrsh-pk-strip span[lang=ur]{font-size:14px}'
			. '.mrsh-pk-sky{position:relative;margin:0;padding:34px 16px 0;background:linear-gradient(180deg,#01411c 0%,#0a5a32 100%);color:#fff;text-align:center;overflow:hidden}'
			. '.mrsh-pk-sky h3{margin:0 0 6px;color:#fff;font-size:20px;font-weight:600}'
			. '.mrsh-pk-sky p{margin:0 auto 6px;max-width:760px;color:rgba(255,255,255,.92);font-size:14px}'
			. '.mrsh-pk-sky .ur{font-size:18px;line-height:2;color:#f1deaa}'
			. '.mrsh-pk-sky .cities{font-size:12.5px;letter-spacing:.02em;color:rgba(255,255,255,.85)}'
			. '.mrsh-pk-sky::after{content:"";display:block;height:14px;background:#06301d;margin:-1px -16px 0}.mrsh-pk-sky svg{display:block;width:100%;max-width:820px;height:auto;margin:14px auto 0}'
			. 'h2[data-ppt-title]::after{content:"";display:block;width:120px;height:14px;margin:10px 0 0;background:url("data:image/svg+xml,' . $orn . '") left center/contain no-repeat}'
			. '.text-center h2[data-ppt-title]::after,h2.text-center[data-ppt-title]::after{margin-left:auto;margin-right:auto;background-position:center}'
			. '.text-light h2[data-ppt-title]::after,h2.text-light[data-ppt-title]::after{display:none}'
			. self::button_icons()
			. '</style>';
	}

	/** Small line icons on the main buttons, drawn with CSS masks so they take the button text colour. */
	private static function button_icons() {
		$svg = function ( $inner ) {
			return 'url("data:image/svg+xml,' . rawurlencode( '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="#000" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">' . $inner . '</svg>' ) . '")';
		};
		$add    = $svg( '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/>' );
		$search = $svg( '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>' );
		$heart  = $svg( '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 0 0 0-7.8z"/>' );
		$css = '.mrsh-bi{display:inline-block;width:1.1em;height:1.1em;margin-right:.5em;vertical-align:-.17em;background:currentColor;-webkit-mask:var(--mi) center/contain no-repeat;mask:var(--mi) center/contain no-repeat;flex:0 0 auto}'
			. '.mrsh-bi[data-mi="add"]{--mi:' . $add . '}.mrsh-bi[data-mi="search"]{--mi:' . $search . '}.mrsh-bi[data-mi="heart"]{--mi:' . $heart . '}';

		// Featured ribbon in the site colours, and one consistent icon set for the mobile app bar.
		$bar = array(
			'fa-house'        => '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
			'fa-search'       => '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
			'fa-users-crown'  => '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
			'fa-sparkles'     => '<path d="M3 8l4 4 5-7 5 7 4-4-2 11H5z"/>',
		);
		$css .= 'html body .button-featured,html body .button-featured-new{background:linear-gradient(135deg,#01411c,#0a5a32)!important;color:#f1deaa!important;border-bottom:2px solid #c9a24b}html body .button-featured::after,html body .button-featured-new::after{display:none!important}';
		$css .= '@media(max-width:991px){';
		foreach ( $bar as $cls => $inner ) {
			$css .= '#mobile-bottom-bar li a i.' . $cls . '{font-size:0!important;width:24px;height:24px;display:block;margin:0 auto 3px!important;background:#01411c!important;-webkit-mask:' . $svg( $inner ) . ' center/contain no-repeat;mask:' . $svg( $inner ) . ' center/contain no-repeat}#mobile-bottom-bar li a i.' . $cls . '::before{content:none!important;display:none!important}';
		}
		$css .= '#mobile-bottom-bar li a:not(.mrsh-on) i{opacity:.7}#mobile-bottom-bar li a.mrsh-on i{opacity:1}}';

		// Hero: our own artwork (green, gold star lattice, crescent) instead of the stock photo.
		$tile = rawurlencode( '<svg xmlns="http://www.w3.org/2000/svg" width="90" height="90" viewBox="0 0 90 90"><g fill="none" stroke="#c9a24b" stroke-opacity=".28" stroke-width="1.2"><path d="M45 8l8 14 15-4-4 15 14 8-14 8 4 15-15-4-8 14-8-14-15 4 4-15-14-8 14-8-4-15 15 4z"/><circle cx="45" cy="45" r="9"/></g></svg>' );
		$moon = rawurlencode( '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200"><path fill="#f1deaa" fill-opacity=".16" d="M120 20a80 80 0 1 0 0 160 62 62 0 1 1 0-160z"/><path fill="#c9a24b" fill-opacity=".30" d="M150 70l8 17 19 3-14 13 4 19-17-9-17 9 4-19-14-13 19-3z"/></svg>' );
		$art = esc_url( MRSH_URL . 'assets/hero-art.svg?v=' . MRSH_VERSION );
		$css .= 'html body .hero1 .bg-image{background-image:url("' . $art . '"),url("data:image/svg+xml,' . $tile . '"),linear-gradient(135deg,#012a12 0%,#01411c 55%,#0a5a32 100%)!important;background-repeat:no-repeat,repeat,no-repeat!important;background-position:right 4% center,0 0,0 0!important;background-size:min(46%,460px) auto,90px 90px,cover!important}'
			. '@media(min-width:992px){html body .hero1 .bg-image:after{display:none!important}}'
			. '@media(max-width:991px){html body .hero1{padding-bottom:190px!important}html body .hero1 .bg-image{background-position:center bottom 10px,0 0,0 0!important;background-size:min(64%,290px) auto,90px 90px,cover!important}html body .hero1 .bg-image:after{background:linear-gradient(180deg,rgba(1,42,18,.72) 0%,rgba(1,42,18,.25) 55%,rgba(1,42,18,0) 100%)!important}}'
			. 'html body .hero1 h1{color:#fff!important;text-shadow:0 2px 8px rgba(0,0,0,.35)}html body .hero1 .lead{color:#f1deaa!important}'
			. '@media(min-width:992px){html body .hero1 .h1buttonbox a:first-child{background:#c9a24b!important;color:#1b2a12!important;border:0;border-radius:999px}html body .hero1 .h1buttonbox a:last-child{background:#fff!important;color:#01411c!important;border:0;border-radius:999px}}';

		// Menu, top bar, footer and tab links: a script tags each link with an icon name, CSS draws it.
		$more = array(
			'home'    => '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
			'info'    => '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.01"/>',
			'mail'    => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
			'search'  => '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
			'blog'    => '<path d="M4 4h12a4 4 0 0 1 4 4v12H8a4 4 0 0 1-4-4z"/><path d="M8 9h8M8 13h6"/>',
			'user'    => '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
			'logout'  => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/>',
			'shield'  => '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>',
			'file'    => '<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M8 13h8M8 17h6"/>',
			'image'   => '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-9 9"/>',
			'heart'   => '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 0 0 0-7.8z"/>',
			'help'    => '<circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 1 1 3.5 2.3c-.7.4-1 .9-1 1.7M12 17v.01"/>',
		);
		$css .= 'a[data-mi]::before{content:"";display:inline-block;width:1em;height:1em;margin-right:.4em;vertical-align:-.14em;background:currentColor;-webkit-mask:var(--mi) center/contain no-repeat;mask:var(--mi) center/contain no-repeat}';
		foreach ( $more as $k => $inner ) {
			$css .= 'a[data-mi="' . $k . '"]{--mi:' . $svg( $inner ) . '}';
		}
		return $css;
	}

	/** Tags links with an icon name by their address or text. Skips links that already have an icon or are big buttons. */
	private static function icon_script() {
		return '<script id="mrsh-mi">document.addEventListener("DOMContentLoaded",function(){var R=[["logout",/logout|log out|sign out|wp-login/],["user",/my-account|my account|profile|dashboard/],["home",/^home$/],["info",/about|how it works|info|bio/],["mail",/contact|message|email|inbox|mailto:/],["search",/^search|find/],["blog",/blog|guide|article|news/],["shield",/privacy|safety|disclaimer/],["file",/terms|condition|policy/],["image",/photo|gallery|picture/],["heart",/favou?rite|like|interest|shortlist/],["help",/faq|help|support/]];'
			. 'var B=[[".h1buttonbox a:first-child,header a.btn-secondary.rounded-pill","add"],[".h1buttonbox a:last-child","search"],["a.btn-system.btn-lg.btn-block","heart"]];B.forEach(function(x){document.querySelectorAll(x[0]).forEach(function(a){if(a.querySelector(".mrsh-bi"))return;var i=document.createElement("span");i.className="mrsh-bi";i.setAttribute("data-mi",x[1]);i.setAttribute("aria-hidden","true");a.insertBefore(i,a.firstChild)})});var L=document.querySelectorAll("header a,footer a,a.opacity-8,.mrsh-org a,.nav-tabs a,.nav-pills a,[role=tab]");'
			. 'for(var i=0;i<L.length;i++){var a=L[i];if(a.dataset.mi||a.querySelector("i,svg,img")||/\bbtn\b|menu-add|dropdown-toggle|icon-|navbar-brand|textlogo|logo/.test(a.className||""))continue;'
			. 'var t=(a.textContent||"").trim().toLowerCase();if(!t||t.length>26)continue;var h=((a.getAttribute("href")||"").split("?")[0]).toLowerCase();var s=t+" "+h;'
			. 'for(var j=0;j<R.length;j++){if(R[j][1].test(R[j][0]==="home"||R[j][0]==="search"?t:s)){a.setAttribute("data-mi",R[j][0]);break}}}});</script>';
	}

	/** Puts our own private-photo placeholder over the stock one in the uploads folder (original kept as .orig). */
	public static function swap_locked_file() {
		if ( get_option( 'mrsh_locked_ver' ) === MRSH_VERSION ) {
			return;
		}
		$up  = wp_upload_dir();
		$f   = trailingslashit( $up['basedir'] ) . '2026/01/Locked.png.webp';
		$src = MRSH_DIR . 'assets/img/profile-locked.webp';
		if ( is_file( $f ) && is_file( $src ) && is_writable( $f ) ) {
			if ( ! is_file( $f . '.orig' ) ) {
				@copy( $f, $f . '.orig' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			}
			if ( @copy( $src, $f ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors
				update_option( 'mrsh_locked_ver', MRSH_VERSION, true );
				do_action( 'litespeed_purge_all' );
			}
		}
	}

	/** Replace the blurry stretched favicon with the sharp site icon (Google, browser tab and phone home screen). */
	private static function site_icons( $html ) {
		$u    = MRSH_URL . 'assets/icon-';
		$v    = '?v=' . MRSH_VERSION;
		$tags = '<link rel="icon" type="image/png" sizes="48x48" href="' . esc_url( $u . '48.png' . $v ) . '">'
			. '<link rel="icon" type="image/png" sizes="96x96" href="' . esc_url( $u . '96.png' . $v ) . '">'
			. '<link rel="icon" type="image/png" sizes="32x32" href="' . esc_url( $u . '32.png' . $v ) . '">'
			. '<link rel="icon" type="image/png" sizes="192x192" href="' . esc_url( $u . '192.png' . $v ) . '">'
			. '<link rel="apple-touch-icon" sizes="180x180" href="' . esc_url( $u . '180.png' . $v ) . '">';
		$out  = preg_replace( '/<link\b[^>]*\brel=["\'](?:shortcut )?icon["\'][^>]*>|<link\b[^>]*\brel=["\']apple-touch-icon["\'][^>]*>/i', '', $html );
		$out  = null === $out ? $html : $out;
		$o2   = preg_replace( '/<\/head>/i', $tags . '</head>', $out, 1 );
		return null === $o2 ? $out : $o2;
	}

	/** Topic picture (1200x630 WebP) for a guide, chosen by its address. Returns array(url, alt, title) or null. */
	public static function topic_image( $slug ) {
		$map = array(
			'saudi'         => array( 'saudi', 'Pakistani rishta in Saudi Arabia: guide for families abroad' ),
			'doctor'        => array( 'profession', 'Doctor, engineer and army officer rishta in Pakistan' ),
			'jahez'         => array( 'jahez', 'Jahez, bari and salami in Pakistani weddings' ),
			'nikah-reg'     => array( 'nikah', 'Nikah registration, nikahnama and haq mehr in Pakistan' ),
			'bahawalpur'    => array( 'cities', 'Rishta in Bahawalpur and Sargodha' ),
			'rishta-chahiye' => array( 'chahiye', 'Rishta chahiye: free online rishta service in Pakistan' ),
			'pakistan-rishta' => array( 'home', 'Free Pakistani rishta and matrimonial service' ),
		);
		foreach ( $map as $needle => $v ) {
			if ( false !== strpos( (string) $slug, $needle ) ) {
				return array( MRSH_URL . 'assets/og/' . $v[0] . '.webp?v=' . MRSH_VERSION, $v[1] );
			}
		}
		return null;
	}

	/** Shows the topic picture at the top of a guide (sized, lazy-safe, with alt text) so Google can index it. */
	public static function topic_figure( $content ) {
		if ( is_admin() || ! is_singular( array( 'post', 'page' ) ) || ! in_the_loop() || ! is_main_query() || has_post_thumbnail() ) {
			return $content;
		}
		$t = self::topic_image( get_post_field( 'post_name', get_the_ID() ) );
		if ( ! $t || false !== strpos( $content, 'mrsh-topic' ) ) {
			return $content;
		}
		return '<figure class="mrsh-topic" style="margin:0 0 22px"><img src="' . esc_url( $t[0] ) . '" alt="' . esc_attr( $t[1] ) . '" width="1200" height="630" decoding="async" fetchpriority="high" style="width:100%;height:auto;border-radius:14px;display:block"></figure>' . $content;
	}

	public static function strip() {
		return '<div class="mrsh-pk-strip" role="note">' . self::STAR . '<span lang="ur" dir="rtl">السلام علیکم! پاکستان کی اپنی مفت رشتہ سروس</span><span>&middot; Pakistan&rsquo;s own free rishta service</span></div>';
	}

	public static function skyline_svg() {
		$g = '#06301d';
		$d = '#0c4a2a';
		return '<svg viewBox="0 0 800 120" preserveAspectRatio="xMidYMax meet" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg">'
			. '<g fill="' . $d . '"><path d="M30 120V84l12-14 12 14v36z"/><path d="M746 120V84l12-14 12 14v36z"/><path d="M170 120V78a30 30 0 0 1 60 0v42z"/><path d="M570 120V78a30 30 0 0 1 60 0v42z"/></g>'
			. '<g fill="' . $g . '">'
			. '<rect x="0" y="108" width="800" height="12"/>'
			. '<path d="M300 108V86a50 50 0 0 1 20-40h160a50 50 0 0 1 20 40v22z" opacity=".55"/>'
			. '<path d="M338 108V78a62 62 0 0 1 124 0v30z"/>'
			. '<rect x="394" y="8" width="12" height="28"/><path d="M388 36h24l-12-6z"/>'
			. '<path d="M236 108V76a38 38 0 0 1 76 0v32z"/><path d="M488 108V76a38 38 0 0 1 76 0v32z"/>'
			. '<rect x="92" y="34" width="12" height="74"/><path d="M88 34h20l-10-14z"/><rect x="96" y="14" width="4" height="8"/>'
			. '<rect x="696" y="34" width="12" height="74"/><path d="M692 34h20l-10-14z"/><rect x="700" y="14" width="4" height="8"/>'
			. '<rect x="140" y="58" width="9" height="50"/><path d="M137 58h15l-7.500-10z"/>'
			. '<rect x="651" y="58" width="9" height="50"/><path d="M648 58h15l-7.500-10z"/>'
			. '</g>'
			. '<g fill="#c9a24b"><path d="M400 8a6 6 0 1 0 4 10 4.800 4.800 0 1 1-4-10z"/><circle cx="98" cy="16" r="2.500"/><circle cx="702" cy="16" r="2.500"/></g>'
			. '</svg>';
	}

	public static function banner() {
		return '<section class="mrsh-pk-sky" aria-label="Rishta across Pakistan"><h3>Rishta from Karachi to Khyber</h3>'
			. '<p class="ur" lang="ur" dir="rtl">کراچی سے خیبر تک، لاہور سے کوئٹہ تک &mdash; اپنے پسند کا رشتہ یہاں ملتا ہے</p>'
			. '<p>Free for every Pakistani family, at home and abroad. Run by a non-profit in Lahore.</p>'
			. '<p class="cities">Lahore &middot; Karachi &middot; Islamabad &middot; Rawalpindi &middot; Faisalabad &middot; Multan &middot; Peshawar &middot; Quetta &middot; Sialkot &middot; Gujranwala</p>'
			. self::skyline_svg() . '</section>';
	}

	/** Helpful text for two short pages (contact and top listings), placed above the theme footer. */
	public static function page_text( $html ) {
		if ( false !== strpos( $html, 'mrsh-text' ) ) {
			return $html;
		}
		$blk = '';
		if ( is_page( 'contact' ) ) {
			$blk = '<h2>How we can help</h2><p>My Rishta Pakistan is a non-profit organization in ' . esc_html( self::addr_short() ) . '. We run MyRishta.pk, a free rishta service for Pakistani families in Pakistan and abroad. Write to us about your profile, a problem with your account, a suspicious profile you want to report, or an idea to improve the service.</p>'
				. '<h3>What to include in your message</h3><ul><li>Your name and the email address you registered with.</li><li>The name or link of the profile you are writing about.</li><li>A short description of the question or problem.</li></ul>'
				. '<p>Please do not send your CNIC, bank or card details or passwords by message or email. A rishta service has no need for them. You can reach us on ' . esc_html( MRSH_Options::org()['phone'] ) . ' or at ' . esc_html( MRSH_Options::org()['email'] ) . '.</p>'
				. '<p>Before you write, you may find the answer in our <a href="' . esc_url( home_url( '/faq/' ) ) . '">FAQ</a>, in <a href="' . esc_url( home_url( '/how-it-works/' ) ) . '">how it works</a>, or in our <a href="' . esc_url( home_url( '/rishta-safety-tips-avoid-fake-profiles-scams/' ) ) . '">rishta safety tips</a>.</p>';

			$blk .= '<h3>Help with common problems</h3>'
				. '<p><b>My profile is waiting for approval.</b> New profiles and changed photos are checked by our team before other families see them. This protects members from fake or copied profiles. Check that your photo is clear and shows only you, and that your text has no phone number or social media link. Our <a href="' . esc_url( home_url( '/profile-guidelines/' ) ) . '">profile guidelines</a> list what to write and what to avoid.</p>'
				. '<p><b>My photo was not accepted.</b> Photos with several people, filters that hide the face, pictures of celebrities or pictures taken from other websites are not accepted. A simple, well-lit photo of yourself works best. You can also choose who can see your photos in your account settings.</p>'
				. '<p><b>I do not receive emails from the site.</b> Look in your spam or promotions folder and mark the message as not spam. Check that the email address in your account settings is spelled correctly. If the problem continues, write to us from that email address so we can check.</p>'
				. '<p><b>I want fewer notifications.</b> In your account you can switch on quiet hours, so you receive no email or app alerts at night, and you can choose how you would like to be reached.</p>'
				. '<p><b>Someone asked me for money or bank details.</b> Do not send anything. Press Report on their profile and read the <a href="' . esc_url( home_url( '/rishta-scam-warning-signs/' ) ) . '">rishta scam warning signs</a>. Reports like this are treated as urgent.</p>'
				. '<p><b>I found my match here.</b> Alhamdulillah, congratulations. You can <a href="' . esc_url( home_url( '/share-your-story/' ) ) . '">share your success story</a> if you wish, so other families can take hope. We never publish your name or photo without your permission.</p>'
				. '<h3>Common questions</h3>'
				. '<p><b>Is the service really free?</b> Yes. There are no joining fees and no agents. Read <a href="' . esc_url( home_url( '/our-story/' ) ) . '">our story</a> to see why.</p>'
				. '<p><b>Do you arrange meetings or marriages?</b> No. We provide a place for families to find each other. Families decide, meet and agree for themselves. Please read the <a href="' . esc_url( home_url( '/safe-meeting-guide/' ) ) . '">safe meeting guide</a> before any meeting.</p>'
				. '<p><b>Want to delete your account or data?</b> Follow the steps on the <a href="' . esc_url( home_url( '/data-deletion/' ) ) . '">delete your data</a> page.</p>'
				. '<h3>Who reads your message</h3>'
				. '<p>Messages sent to us are read by the small volunteer team that runs this non-profit service. We use what you write only to help with your question, and we do not share it with other members or sell it. Read our <a href="' . esc_url( home_url( '/privacy-policy/' ) ) . '">privacy policy</a> to see how your data is kept.</p>'
				. '<h3>Writing in Urdu or English</h3>'
				. '<p>You can write to us in Urdu, English or Roman Urdu. Please keep your message short and clear, and say which profile or page you mean, so that we can help you the first time.</p>';
		} elseif ( is_page( 'top-listings' ) ) {
			$blk = '<h2>About top profiles</h2><p>This page shows profiles that the site highlights so families can find active members quickly. Every profile is written by the member or their family. Being shown here is not a guarantee that the details have been verified, so please check the facts yourself.</p>'
				. '<h3>How to use this page</h3><ol><li>Open a profile and read it fully, including education, work and family details.</li><li>Look for a clear, recent photo and realistic expectations.</li><li>Contact the family politely through the site and ask for a short call or a family meeting.</li><li>Verify job, education and family background through relatives or friends before you decide.</li></ol>'
				. '<p>Read our <a href="' . esc_url( home_url( '/rishta-safety-tips-avoid-fake-profiles-scams/' ) ) . '">rishta safety tips</a> and the <a href="' . esc_url( home_url( '/warning-signs-in-rishta-proposal-what-to-check/' ) ) . '">warning signs in a proposal</a> before sharing personal details. MyRishta.pk is free; you can <a href="' . esc_url( home_url( '/registration/' ) ) . '">create a profile</a> and appear in search too.</p>';
		}
		if ( '' === $blk ) {
			return $html;
		}
		$sec = '<section class="mrsh-text" style="max-width:860px;margin:0 auto;padding:28px 16px;line-height:1.7">' . $blk . '</section>';
		$pos = false;
		$uf  = strpos( $html, 'Useful Links' );
		if ( false !== $uf ) {
			$pos = strripos( substr( $html, 0, $uf ), '<section' );
		}
		if ( false === $pos ) {
			$pos = strripos( $html, '</main>' );
		}
		return false === $pos ? $html : substr( $html, 0, $pos ) . $sec . substr( $html, $pos );
	}

	/** Organization details block, link list and corrected footer wording on every page. */
	/** Point theme links straight at the live pages instead of old addresses that only redirect. */
	public static function direct_links( $html ) {
		$home = preg_quote( untrailingslashit( home_url() ), '#' );
		$map  = array(
			'privacy'         => '/privacy-policy/',
			'terms'           => '/terms-and-conditions/',
			'registration'    => '/add-listing/',
		);
		foreach ( $map as $from => $to ) {
			$r = preg_replace( '#(href=["\'])(?:' . $home . ')?/' . $from . '/(["\'])#i', '$1' . untrailingslashit( home_url() ) . $to . '$2', $html );
			if ( null !== $r ) {
				$html = $r;
			}
		}
		return $html;
	}

	public static function org_footer( $html ) {
		if ( false !== strpos( $html, '<section class="mrsh-org"' ) || false === stripos( $html, '</main>' ) ) {
			return $html;
		}
		$h = function ( $path ) {
			return esc_url( home_url( $path ) );
		};
		$year = gmdate( 'Y' );
		$css  = '<style>.mrsh-org{background:#06301d;color:#e8efe9;padding:34px 16px 28px;font-size:14px;line-height:1.7}.mrsh-org a{color:#f1deaa;text-decoration:none}.mrsh-org a:hover{text-decoration:underline}.mrsh-org-in{max-width:1180px;margin:0 auto;display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:22px 28px}.mrsh-org h2{margin:0 0 8px!important;color:#fff!important;font-size:16px!important;line-height:1.3!important;font-weight:600!important}.mrsh-org p,.mrsh-org li{font-size:14px!important}.mrsh-org ul{list-style:none;margin:0;padding:0}.mrsh-org p{margin:0 0 6px}.mrsh-org-bar{max-width:1180px;margin:22px auto 0;padding-top:14px;border-top:1px solid rgba(255,255,255,.18);font-size:12.5px;color:#c8d6cc}@media(max-width:991px){.mrsh-org{padding-bottom:96px}}</style>';
		$blk  = '<section class="mrsh-org" aria-label="About the organization"><div class="mrsh-org-in">'
			. '<div><h2>My Rishta Pakistan</h2><p>A non-profit organization in Punjab, Pakistan. We run MyRishta.pk, a free rishta service for Pakistani families at home and abroad.</p></div>'
			. '<div><h2>Contact</h2><p>' . esc_html( MRSH_Options::org()['line'] ) . ', Pakistan</p><p>Phone: <a href="tel:' . esc_attr( MRSH_Options::org()['tel'] ) . '">' . esc_html( MRSH_Options::org()['phone'] ) . '</a></p><p>Email: <a href="mailto:' . esc_attr( MRSH_Options::org()['email'] ) . '">' . esc_html( MRSH_Options::org()['email'] ) . '</a></p></div>'
			. '<div><h2>Information</h2><ul><li><a href="' . $h( '/about-us/' ) . '">About Us</a></li><li><a href="' . $h( '/how-it-works/' ) . '">How it works</a></li><li><a href="' . $h( '/faq/' ) . '">FAQ</a></li><li><a href="' . $h( '/blog/' ) . '">Blog</a></li><li><a href="' . $h( '/contact/' ) . '">Contact</a></li><li><a href="' . $h( '/sitemap/' ) . '">Sitemap</a></li></ul></div>'
			. '<div><h2>Trust and legal</h2><ul><li><a href="' . $h( '/privacy-policy/' ) . '">Privacy Policy</a></li><li><a href="' . $h( '/terms-and-conditions/' ) . '">Terms and Conditions</a></li><li><a href="' . $h( '/cookie-policy/' ) . '">Cookie Policy</a></li><li><a href="' . $h( '/disclaimer/' ) . '">Disclaimer</a></li><li><a href="' . $h( '/rishta-safety-tips-avoid-fake-profiles-scams/' ) . '">Rishta safety tips</a></li></ul></div>'
			. '</div><div class="mrsh-org-bar">&copy; ' . $year . ' My Rishta Pakistan, Lahore. A non-profit organization. MyRishta.pk is free to use; advertising helps cover the running costs.</div></section>';
		$fb   = 'https://www.facebook.com/share/1cJizhDBuk/';
		$blk  = str_replace( '</ul></div></div><div class="mrsh-org-bar">', '</ul></div></div><div class="mrsh-org-bar">', $blk );
		$blk  = str_replace( '<p>Email: ', '<p>Facebook: <a href="' . esc_url( $fb ) . '" rel="noopener" target="_blank">My Rishta Pakistan</a></p><p>Email: ', $blk );
		$html = preg_replace( '/(<a[^>]*?)href="#"([^>]*class="icon-facebook")/', '$1href="' . esc_url( $fb ) . '"$2', $html );
		$html = preg_replace( '/(<a[^>]*?)href="#"([^>]*class="icon-facebook"[^>]*?)rel="nofollow"/', '$1href="' . esc_url( $fb ) . '"$2rel="noopener"', $html );
		$css .= '<style>.ppt-icons-social li:has(>a[href="#"]){display:none}</style>';
		$pos  = strripos( $html, '</main>' );
		$out  = substr( $html, 0, $pos ) . $css . $blk . substr( $html, $pos );
		$out  = preg_replace( '/MyRishta free for all Pakistani\.?\s*(?=<)/', 'Free rishta service for Pakistani families, run by a non-profit in Lahore.', $out ); // tolerant of a trailing full stop or space (3.101.226)
		$out  = str_replace( 'Service For You', 'Services', $out );
		$out  = str_replace( '</main>', '</main><script>(function(){var tz={"Asia/Karachi":"Pakistan","Asia/Dubai":"United Arab Emirates","Asia/Riyadh":"Saudi Arabia","Asia/Qatar":"Qatar","Asia/Kuwait":"Kuwait","Asia/Muscat":"Oman","Asia/Bahrain":"Bahrain","Asia/Dhaka":"Bangladesh","Asia/Kolkata":"India","Asia/Calcutta":"India","Asia/Baku":"Azerbaijan","Asia/Shanghai":"China","Europe/London":"United Kingdom","America/Toronto":"Canada","America/Vancouver":"Canada","America/Edmonton":"Canada","America/Halifax":"Canada","America/New_York":"United States","America/Chicago":"United States","America/Denver":"United States","America/Los_Angeles":"United States"};
function pick(){var z="";try{z=Intl.DateTimeFormat().resolvedOptions().timeZone}catch(e){}return tz[z]||"Pakistan"}
function fix(s){if(s.getAttribute("data-mrsh-loc"))return;s.setAttribute("data-mrsh-loc","1");var o=[].slice.call(s.options),pk=o.filter(function(x){return/^pakistan$/i.test(x.text.trim())})[0];if(!pk)return;s.insertBefore(pk,s.options[0]);if(s.selectedIndex<=0||s.options[s.selectedIndex].text.trim()==="Azerbaijan"){var w=pick(),t=[].slice.call(s.options).filter(function(x){return x.text.trim()===w})[0]||pk;s.value=t.value;var n=0,iv=setInterval(function(){var c=document.getElementById("category_subs");n++;if((c&&c.options.length>1)||n>25){clearInterval(iv);return}try{if(typeof UpdateCategoryList==="function")UpdateCategoryList()}catch(e){}},400)}}
function scan(){var s=document.getElementById("parent_country_list");if(s)fix(s)}
new MutationObserver(scan).observe(document.documentElement,{childList:true,subtree:true});scan()})();</script>', $out );
		$out  = str_replace( "<div class='textlogo navbar-brand-light img-fluid'>", "<div class='textlogo navbar-brand-light img-fluid'><span class=\"mrsh-cr\" aria-hidden=\"true\">&#9790;</span>", $out );
		$out  = str_replace( '</main>', '</main><script>(function(){var p=location.pathname.replace(/\\/$/,"");document.querySelectorAll("#mobile-bottom-bar li a").forEach(function(a){var h=a.pathname.replace(/\\/$/,"");if(h===p&&(a.search===""||a.search==="?s=")===(location.search===""||location.search==="?s=")&&(a.search!=="?s="||location.search.indexOf("s=")===0))a.classList.add("mrsh-on")})})()</script>', $out );
		$o2   = preg_replace( '/&copy;\s*\d{4}\s*My Rishta\s*All rights reserved\.?|\x{00A9}\s*\d{4}\s*My Rishta\s*All rights reserved\.?/u', '&copy; ' . $year . ' My Rishta Pakistan. All rights reserved.', $out );
		return null === $o2 ? $out : $o2;
	}

	/**
	 * Poppins is served from this site (four small files) instead of Google Fonts, and the theme is told
	 * the font sheet is already there (it checks for #ppt-google-fonts) so it does not fetch Google's
	 * 20 KB all-weights sheet. The theme also re-adds a Font Awesome sheet that the merged stylesheet
	 * already contains; that duplicate (88 KB) is skipped when the merged sheet is in use.
	 */
	private static function fonts_fix( $html ) {
		$b   = MRSH_URL . 'assets/fonts/poppins-latin-';
		$v   = '?v=' . MRSH_VERSION;
		$ff  = '';
		foreach ( array( 400, 500, 600, 700 ) as $w ) {
			$ff .= '@font-face{font-family:Poppins;font-style:normal;font-weight:' . $w . ';font-display:swap;src:url(' . $b . $w . '-normal.woff2' . $v . ') format("woff2");unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}';
		}
		$out = '<link rel="preload" as="font" type="font/woff2" href="' . esc_url( $b . '400-normal.woff2' . $v ) . '" crossorigin>';
		$out .= '<style id="ppt-google-fonts">' . $ff . 'body,html{font-family:Poppins,sans-serif!important}</style>';
		// Microsoft Clarity is started by the Tag Manager container; stop its script from ever being added.
		$out .= '<script data-no-optimize="1" data-cfasync="false">(function(){var b=/clarity\\.ms/;function c(n){return n&&n.tagName==="SCRIPT"&&b.test(n.src||"");}["appendChild","insertBefore"].forEach(function(m){var o=Node.prototype[m];Node.prototype[m]=function(n){if(c(n))return n;return o.apply(this,arguments);};});})();</script>';
		if ( false !== strpos( $html, '/mrsh-css/' ) ) {
			$out .= '<script data-no-optimize="1" data-cfasync="false">(function(){function P(j){if(!j||!j.fn||!j.fn.append||j.fn.append.__m)return;var a=j.fn.append;j.fn.append=function(){var x=arguments[0];if(typeof x==="string"&&x.indexOf("css/_fontawesome.css")>-1)return this;return a.apply(this,arguments);};j.fn.append.__m=1;}var v=window.jQuery;if(v){P(v);return;}try{Object.defineProperty(window,"jQuery",{configurable:true,enumerable:true,get:function(){return v;},set:function(n){v=n;P(n);}});}catch(e){}})();</script>';
		}
		return $out;
	}

	/**
	 * When the office details are changed in the plugin settings, swap the original address, phone and
	 * email everywhere they were typed by hand (pages, posts, the theme footer), so one change updates the whole site.
	 */
	public static function sync_org( $html ) {
		$g = MRSH_Options::org();
		$old_phone = '+92-42292929';
		$rep = array();
		$cur_short = trim( $g['street'] . ( '' !== $g['street'] && '' !== $g['city'] ? ', ' : '' ) . $g['city'] );
		if ( $g['line'] !== 'Shahdara, Lahore 54000' ) {
			$rep['Shahdara, Lahore 54000']   = $g['line'];
			$rep['Shahdara, Lahore (54000)'] = self::addr_short();
			$rep['Shahdara, Lahore']         = $cur_short;
		}
		if ( $g['phone'] !== $old_phone ) {
			$rep[ $old_phone ]     = $g['phone'];
			$rep['tel:+9242292929'] = 'tel:' . $g['tel'];
			$rep['+92 42 292929']  = $g['phone'];
		}
		if ( $g['email'] !== 'support@myrishta.pk' ) {
			$rep['support@myrishta.pk'] = $g['email'];
		}
		if ( ! $rep ) {
			return $html;
		}
		return str_replace( array_keys( $rep ), array_values( $rep ), $html );
	}

	/** "Shahdara, Lahore (54000)" style text for sentences. */
	public static function addr_short() {
		$g = MRSH_Options::org();
		$t = trim( $g['street'] . ( '' !== $g['street'] && '' !== $g['city'] ? ', ' : '' ) . $g['city'] );
		return $t . ( '' !== $g['postal'] ? ' (' . $g['postal'] . ')' : '' );
	}

	public static function sc_address() {
		return esc_html( MRSH_Options::org()['line'] );
	}

	public static function sc_phone() {
		$g = MRSH_Options::org();
		return '<a href="tel:' . esc_attr( $g['tel'] ) . '">' . esc_html( $g['phone'] ) . '</a>';
	}

	public static function sc_email() {
		$e = MRSH_Options::org()['email'];
		return '<a href="mailto:' . esc_attr( $e ) . '">' . esc_html( $e ) . '</a>';
	}

	public static function filter( $html ) {
		if ( false !== strpos( $html, 'mrsh-pk-strip' ) ) {
			return $html;
		}
		$html = self::sync_org( $html );
		$out = preg_replace( '/<\/head>/i', self::fonts_fix( $html ) . self::css() . self::icon_script() . '</head>', $html, 1 );
		$out = null === $out ? $html : $out;
		$out = self::site_icons( $out );
		// Private-photo placeholder: new picture, version in the address so phones fetch it fresh.
		$out = str_replace( 'Locked.png.webp', 'Locked.png.webp?v=' . MRSH_VERSION, $out );
		$out = str_replace( 'MyRishta-Cupple-e1719957865999.webp', 'MyRishta-Cupple-e1719957865999.webp?v=' . MRSH_VERSION, $out );
		$o2  = preg_replace( '/(<body\b[^>]*>)/i', '$1' . self::strip(), $out, 1 );
		$out = null === $o2 ? $out : $o2;
		if ( is_front_page() || is_page( array( 'about-us', 'how-it-works', 'faq' ) ) ) {
			// Sit just above the theme footer section; fall back to the end of the main area.
			$pos = false;
			$uf  = strpos( $out, 'Useful Links' );
			if ( false !== $uf ) {
				$pos = strripos( substr( $out, 0, $uf ), '<section' );
			}
			if ( false === $pos ) {
				$pos = strripos( $out, '</main>' );
			}
			if ( false !== $pos ) {
				$out = substr( $out, 0, $pos ) . self::banner() . substr( $out, $pos );
			}
		}
		return $out;
	}
}
