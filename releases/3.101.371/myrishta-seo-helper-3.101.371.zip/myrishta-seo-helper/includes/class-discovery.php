<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Finds new phrases from data the site owner really has: visitor searches on the site,
 * a Search Console export, the site's own content, and (when the Keyword phrases robot is ON) Google's free
 * search suggestions. Unsafe or off-topic suggestions are never added.
 */
class MRSH_Discovery {

	const OPT        = 'mrsh_custom_keywords';
	const SEARCH_LOG = 'mrsh_search_log';

	public static function init() {
		add_action( 'template_redirect', array( __CLASS__, 'log_search' ), 20 );
		add_action( 'mrsh_weekly_scan', array( __CLASS__, 'run_scan' ) );
		add_action( 'mrsh_google_kw', array( __CLASS__, 'google_scan' ) );
		add_action( 'init', array( __CLASS__, 'google_arm' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
	}

	/* ---------------- Custom phrases ---------------- */

	/** Weekly automatic scan of the site's own content. */
	public static function schedule() {
		$on   = ! empty( MRSH_Options::get()['auto_discover'] );
		$next = wp_next_scheduled( 'mrsh_weekly_scan' );
		if ( $on && ! $next ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'weekly', 'mrsh_weekly_scan' );
		} elseif ( ! $on && $next ) {
			wp_unschedule_event( $next, 'mrsh_weekly_scan' );
		}
	}

	public static function run_scan() {
		if ( empty( MRSH_Options::get()['auto_discover'] ) ) {
			return 0;
		}
		$terms = array();
		foreach ( array_slice( self::content_candidates( self::site_posts() ), 0, 20 ) as $c ) {
			$terms[] = $c['term'];
		}
		$added = self::add( $terms );
		update_option( 'mrsh_last_scan', array( 'time' => time(), 'added' => $added ), false );
		return $added;
	}

	public static function custom_rows() {
		$rows = get_option( self::OPT, array() );
		return is_array( $rows ) ? $rows : array();
	}

	public static function add( $terms, $use = 'Review and assign a page', $list = 'Discovered' ) {
		$cur  = self::custom_rows();
		$max  = 1000;
		$have = array();
		foreach ( MRSH_Keywords::all() as $r ) {
			$max = max( $max, (int) $r['n'] );
			foreach ( MRSH_Keywords::variants( $r ) as $v ) {
				$have[ $v ] = true;
			}
		}
		$added = 0;
		foreach ( (array) $terms as $t ) {
			$t   = trim( preg_replace( '/\s+/u', ' ', sanitize_text_field( (string) $t ) ) );
			$key = mb_strtolower( $t );
			if ( mb_strlen( $t ) < 3 || mb_strlen( $t ) > 80 || isset( $have[ $key ] ) ) {
				continue;
			}
			$urdu  = (bool) preg_match( '/\p{Arabic}/u', $t );
			$cur[] = array(
				'n'         => ++$max,
				'list'      => $list,
				'group'     => $list,
				'urdu'      => $urdu ? $t : '',
				'roman'     => $urdu ? '' : $key,
				'treatment' => 'Target',
				'use'       => $use,
				'priority'  => 'Medium',
			);
			$have[ $key ] = true;
			$added++;
		}
		if ( $added ) {
			update_option( self::OPT, $cur, false );
			MRSH_Keywords::flush();
		}
		return $added;
	}

	public static function remove( $n ) {
		$cur = array();
		foreach ( self::custom_rows() as $r ) {
			if ( (int) $r['n'] !== (int) $n ) {
				$cur[] = $r;
			}
		}
		update_option( self::OPT, $cur, false );
		MRSH_Keywords::flush();
	}

	/* ---------------- Source 1: visitor searches ---------------- */

	/** Stores the search words only: no IP address, user or time per visit. Site admins are skipped. */
	public static function log_search() {
		if ( is_admin() || ! is_search() || is_paged() || current_user_can( 'manage_options' ) ) {
			return;
		}
		$term = mb_strtolower( trim( preg_replace( '/\s+/u', ' ', (string) get_search_query( false ) ) ) );
		if ( mb_strlen( $term ) < 3 || mb_strlen( $term ) > 60 || 'mrsh-check' === $term ) {
			return;
		}
		// Drop anything that looks personal: emails, links, phone-like numbers.
		if ( false !== strpos( $term, '@' ) || false !== strpos( $term, 'http' ) || preg_match( '/\d{6,}/', $term ) ) {
			return;
		}
		$log = get_option( self::SEARCH_LOG, array() );
		$log = is_array( $log ) ? $log : array();
		if ( isset( $log[ $term ] ) ) {
			$log[ $term ]['count']++;
			$log[ $term ]['last'] = time();
		} else {
			if ( count( $log ) >= 500 ) {
				uasort(
					$log,
					function ( $a, $b ) {
						return $a['count'] - $b['count'] ?: $a['last'] - $b['last'];
					}
				);
				array_shift( $log );
			}
			$log[ $term ] = array( 'count' => 1, 'last' => time() );
		}
		update_option( self::SEARCH_LOG, $log, false );
	}

	public static function search_rows() {
		$log = get_option( self::SEARCH_LOG, array() );
		$log = is_array( $log ) ? $log : array();
		$out = array();
		foreach ( $log as $term => $d ) {
			$out[] = array( 'term' => (string) $term, 'count' => (int) $d['count'], 'last' => (int) $d['last'] );
		}
		usort(
			$out,
			function ( $a, $b ) {
				return $b['count'] - $a['count'];
			}
		);
		return $out;
	}

	/* ---------------- Source 2: Search Console export ---------------- */

	/** Parse the "Queries" CSV from Search Console > Performance > Export. */
	public static function parse_csv( $text ) {
		$text  = preg_replace( '/^\xEF\xBB\xBF/', '', (string) $text );
		$lines = preg_split( '/\R/', $text );
		if ( ! $lines || '' === trim( $lines[0] ) ) {
			return array();
		}
		$delim = ',';
		foreach ( array( "\t", ';' ) as $d ) {
			if ( substr_count( $lines[0], $d ) > substr_count( $lines[0], $delim ) ) {
				$delim = $d;
			}
		}
		$header = str_getcsv( array_shift( $lines ), $delim );
		$col    = array( 'clicks' => null, 'impressions' => null, 'position' => null );
		foreach ( $header as $i => $h ) {
			$h = mb_strtolower( trim( $h ) );
			foreach ( $col as $k => $v ) {
				if ( null === $v && false !== strpos( $h, $k ) ) {
					$col[ $k ] = $i;
				}
			}
		}
		$out = array();
		foreach ( $lines as $line ) {
			if ( '' === trim( $line ) ) {
				continue;
			}
			$f = str_getcsv( $line, $delim );
			$q = trim( isset( $f[0] ) ? $f[0] : '' );
			if ( '' === $q || mb_strlen( $q ) > 80 ) {
				continue;
			}
			$num   = function ( $i, $dec ) use ( $f ) {
				if ( null === $i || ! isset( $f[ $i ] ) ) {
					return null;
				}
				return (float) str_replace( $dec ? ',' : ',', $dec ? '.' : '', (string) $f[ $i ] );
			};
			$out[] = array(
				'term'        => $q,
				'clicks'      => $num( $col['clicks'], false ),
				'impressions' => $num( $col['impressions'], false ),
				'position'    => $num( $col['position'], true ),
			);
			if ( count( $out ) >= 300 ) {
				break;
			}
		}
		return $out;
	}

	/* ---------------- Source 4: Google search suggestions (free, no key) ---------------- */

	const GK = 'mrsh_google_kw_state';

	private static $g_base  = array( 'rishta', 'rishta online', 'free rishta', 'rishta website', 'rishta service', 'rishta for marriage', 'rishta proposal', 'rishta chahiye', 'rishta needed', 'rishta agency', 'larki ka rishta', 'larke ka rishta', 'shadi', 'marriage bureau', 'matrimonial', 'pakistani matrimonial', 'nikah', 'proposal for marriage', 'doctor rishta', 'engineer rishta', 'foreign rishta', 'rishta abroad', 'rishta in', 'rishta for', 'رشتہ', 'رشتے', 'رشتہ چاہیے', 'آن لائن رشتہ', 'شادی کے لیے رشتہ' );
	private static $g_where = array( 'lahore', 'karachi', 'islamabad', 'rawalpindi', 'faisalabad', 'multan', 'peshawar', 'quetta', 'sialkot', 'gujranwala', 'hyderabad', 'bahawalpur', 'sargodha', 'sukkur', 'dubai', 'abu dhabi', 'sharjah', 'riyadh', 'jeddah', 'dammam', 'doha', 'kuwait', 'oman', 'bahrain', 'uk', 'usa', 'canada', 'saudi arabia', 'uae', 'qatar' );
	private static $g_bad   = array( 'sex', 'porn', 'xxx', 'nude', 'naked', 'hot ', 'sexy', 'call girl', 'escort', 'dating', 'girlfriend', 'boyfriend', 'affair', 'whatsapp', 'phone number', 'contact number', 'mobile number', 'number', 'no.', 'cnic', 'free sim', 'fake', 'hack', 'divorce', 'second wife', 'temporary', 'mutah', 'contract marriage', 'paid', 'price', 'rate', 'fee', 'سیکس', 'نمبر', 'واٹس', 'گرل', 'دوستی' );

	public static function google_state() {
		$s = get_option( self::GK, array() );
		return array_merge( array( 'off' => 0, 'last' => 0, 'seen' => 0, 'added' => 0, 'total' => 0, 'msg' => '', 'recent' => array() ), is_array( $s ) ? $s : array() );
	}

	public static function google_on() {
		return ! class_exists( 'MRSH_Autopilot' ) || ( MRSH_Autopilot::on() && MRSH_Autopilot::can( 'keywords' ) );
	}

	public static function google_arm() {
		$next = wp_next_scheduled( 'mrsh_google_kw' );
		if ( self::google_on() && ! $next ) {
			wp_schedule_event( time() + 2 * HOUR_IN_SECONDS, 'daily', 'mrsh_google_kw' );
		} elseif ( ! self::google_on() && $next ) {
			wp_unschedule_event( $next, 'mrsh_google_kw' );
		}
	}

	/** One free suggestion call. Returns a list of phrases, or false when Google does not answer. */
	private static function g_fetch( $q, $hl ) {
		$r = wp_remote_get( add_query_arg( array( 'client' => 'firefox', 'hl' => $hl, 'gl' => 'pk', 'q' => $q ), 'https://suggestqueries.google.com/complete/search' ), array( 'timeout' => 8, 'user-agent' => 'Mozilla/5.0 (compatible; MyRishtaKeywordScan)' ) );
		if ( is_wp_error( $r ) || 200 !== (int) wp_remote_retrieve_response_code( $r ) ) {
			return false;
		}
		$j = json_decode( wp_remote_retrieve_body( $r ), true );
		return is_array( $j ) && isset( $j[1] ) && is_array( $j[1] ) ? $j[1] : array();
	}

	private static function g_ok( $t ) {
		$t = trim( preg_replace( '/\s+/u', ' ', (string) $t ) );
		$l = mb_strtolower( $t ) . ' ';
		$w = count( explode( ' ', $t ) );
		if ( $w < 2 || $w > 6 || mb_strlen( $t ) > 70 || preg_match( '/\d/u', $t ) ) {
			return false;
		}
		foreach ( self::$g_bad as $b ) {
			if ( false !== mb_strpos( $l, $b ) ) {
				return false;
			}
		}
		foreach ( self::$seeds as $sd ) {
			if ( false !== mb_strpos( $l, $sd ) ) {
				return true;
			}
		}
		return false;
	}

	/** Reads Google's free suggestions for a rotating set of rishta words and adds the good, safe ones to the bank. */
	public static function google_scan( $budget = 25 ) {
		$st    = self::google_state();
		$queue = array();
		foreach ( self::$g_base as $b ) {
			$queue[] = $b;
		}
		foreach ( self::$g_where as $w ) {
			$queue[] = 'rishta in ' . $w;
			$queue[] = 'pakistani rishta ' . $w;
		}
		$n   = count( $queue );
		$off = (int) ( $st['off'] ?? 0 ) % $n;
		$set = array();
		$ask = 0;
		$bad = 0;
		for ( $i = 0; $i < $n && $ask < 14; $i++ ) {
			$q   = $queue[ ( $off + $i ) % $n ];
			$ur  = (bool) preg_match( '/\p{Arabic}/u', $q );
			$res = self::g_fetch( $q, $ur ? 'ur' : 'en' );
			$ask++;
			if ( false === $res ) {
				if ( ++$bad >= 3 ) {
					break;
				}
				continue;
			}
			foreach ( $res as $t ) {
				if ( self::g_ok( $t ) ) {
					$set[ mb_strtolower( trim( $t ) ) ] = trim( $t );
				}
			}
			usleep( 250000 );
		}
		$set   = array_slice( $set, 0, max( 1, (int) $budget ), true );
		$added = self::add( array_values( $set ), 'Google suggestion: apply to a matching page', 'Google suggestions' );
		$st['off']   = ( $off + $ask ) % $n;
		$st['last']  = time();
		$st['seen']  = count( $set );
		$st['added'] = $added;
		$st['total'] = (int) $st['total'] + $added;
		$st['msg']   = $bad >= 3 ? 'Google did not answer just now. The robot will try again tomorrow.' : $ask . ' searches read, ' . count( $set ) . ' suitable phrases seen, ' . $added . ' new ones added.';
		if ( $added ) {
			$st['recent'] = array_slice( array_merge( array_values( $set ), (array) $st['recent'] ), 0, 30 );
		}
		update_option( self::GK, $st, false );
		if ( $added && class_exists( 'MRSH_Autopilot' ) ) {
			MRSH_Autopilot::log( 'Keywords', 'Read Google suggestions and added ' . $added . ' new rishta phrases.' );
		}
		if ( $added && class_exists( 'MRSH_AutoKW' ) ) {
			MRSH_AutoKW::run(); // apply the new phrases to matching pages straight away
		}
		return $st['msg'];
	}

	/* ---------------- Source 3: the site's own content ---------------- */

	private static $seeds = array( 'rishta', 'rishte', 'rishtay', 'shadi', 'shaadi', 'nikah', 'nikkah', 'larki', 'larka', 'dulhan', 'dulha', 'bahu', 'mangni', 'jahez', 'walima', 'rukhsati', 'رشتہ', 'شادی', 'نکاح', 'لڑکی', 'لڑکا', 'دلہن', 'دولہا' );
	private static $stop  = array( 'the', 'a', 'an', 'in', 'on', 'of', 'for', 'to', 'and', 'or', 'is', 'are', 'with', 'your', 'you', 'our', 'we', 'at', 'by', 'from', 'this', 'that', 'it', 'as', 'be', 'can', 'how', 'what', 'ka', 'ki', 'ke', 'ko', 'se', 'mein', 'main', 'hai', 'hain', 'aur', 'ya' );

	/** Two and three word phrases around rishta-related words that appear on 2+ pages and are not in the bank. */
	public static function content_candidates( $posts ) {
		$bank = array();
		foreach ( MRSH_Keywords::all() as $r ) {
			foreach ( MRSH_Keywords::variants( $r ) as $v ) {
				$bank[ $v ] = true;
			}
		}
		$count = array();
		foreach ( $posts as $p ) {
			$words = preg_split( '/[^\p{L}\p{N}]+/u', mb_strtolower( wp_strip_all_tags( $p->post_title . ' ' . $p->post_content ) ), -1, PREG_SPLIT_NO_EMPTY );
			$seen  = array();
			$n     = count( $words );
			for ( $i = 0; $i < $n; $i++ ) {
				for ( $len = 2; $len <= 3 && $i + $len <= $n; $len++ ) {
					$gram = array_slice( $words, $i, $len );
					if ( in_array( $gram[0], self::$stop, true ) || in_array( $gram[ $len - 1 ], self::$stop, true ) || ! array_intersect( $gram, self::$seeds ) ) {
						continue;
					}
					$phrase = implode( ' ', $gram );
					if ( mb_strlen( $phrase ) < 5 || isset( $bank[ $phrase ] ) ) {
						continue;
					}
					$seen[ $phrase ] = true;
				}
			}
			foreach ( $seen as $phrase => $_ ) {
				$count[ $phrase ] = isset( $count[ $phrase ] ) ? $count[ $phrase ] + 1 : 1;
			}
		}
		$out = array();
		foreach ( $count as $phrase => $c ) {
			if ( $c >= 2 ) {
				$out[] = array( 'term' => $phrase, 'pages' => $c );
			}
		}
		usort(
			$out,
			function ( $a, $b ) {
				return $b['pages'] - $a['pages'];
			}
		);
		return array_slice( $out, 0, 30 );
	}

	public static function site_posts() {
		$o     = MRSH_Options::get();
		$skip  = array_merge( array( 'attachment' ), MRSH_Options::to_list( $o['noindex_post_types'] ) );
		$types = array_values( array_diff( array_keys( get_post_types( array( 'public' => true ) ) ), $skip ) );
		return get_posts( array( 'post_type' => $types, 'post_status' => 'publish', 'numberposts' => 300, 'suppress_filters' => true ) );
	}
}
