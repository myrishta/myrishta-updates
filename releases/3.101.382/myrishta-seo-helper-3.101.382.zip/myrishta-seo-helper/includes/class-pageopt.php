<?php
/**
 * Page Optimizer. Scores every published page and post from its own content (no site requests), lists what to
 * improve, and fixes the safe things by itself once a day: empty alt text on pictures that are in a page, and the
 * automatic focus phrase. Thin pages (not enough original text, the main AdSense worry) are only flagged: real
 * words must be written by a person, so nothing is ever invented. Buttons: Scan, Scan and fix, Fix one page, Ignore.
 * Options: mrsh_pageopt {on, last, msg, fixed, rows}. Post meta: _mrsh_po_ignore.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_PageOpt {

	const OPT  = 'mrsh_pageopt';
	const HOOK = 'mrsh_pageopt_run';

	public static function get() {
		$d = array( 'on' => 1, 'last' => 0, 'msg' => '', 'fixed' => 0, 'rows' => array() );
		$s = get_option( self::OPT, array() );
		return is_array( $s ) ? array_merge( $d, $s ) : $d;
	}

	public static function init() {
		add_action( self::HOOK, array( __CLASS__, 'daily' ) );
		add_action( 'init', array( __CLASS__, 'arm' ) );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 24 );
		foreach ( array( 'scan', 'fixall', 'fixone', 'ignore', 'toggle' ) as $a ) {
			add_action( 'admin_post_mrsh_po_' . $a, array( __CLASS__, 'act_' . $a ) );
		}
	}

	public static function arm() {
		$on   = ! empty( self::get()['on'] );
		$next = wp_next_scheduled( self::HOOK );
		if ( $on && ! $next ) {
			wp_schedule_event( time() + 1800, 'daily', self::HOOK );
		} elseif ( ! $on && $next ) {
			wp_clear_scheduled_hook( self::HOOK );
		}
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Page Optimizer', 'Page Optimizer', 'manage_options', 'mrsh-pageopt', array( __CLASS__, 'page' ) );
	}

	/* ---------- scoring (pure) ---------- */

	/** Plain text of a page as a visitor reads it. */
	private static function text_of( $post ) {
		$c = (string) $post->post_content;
		$c = strip_shortcodes( $c );
		$t = wp_strip_all_tags( preg_replace( '/<(script|style)\b.*?<\/\1>/is', ' ', $c ) );
		return trim( preg_replace( '/\s+/u', ' ', html_entity_decode( $t, ENT_QUOTES, 'UTF-8' ) ) );
	}

	private static function words( $text ) {
		if ( '' === $text ) {
			return 0;
		}
		return preg_match_all( '/[\p{L}\p{N}\x{0600}-\x{06FF}][\p{L}\p{N}\x{0600}-\x{06FF}\'’-]*/u', $text );
	}

	/** Returns array( score 0-100, issues[ array(sev, key, msg, fix) ], words ). */
	public static function score_of( $post ) {
		$iss   = array();
		$score = 100;
		$add   = function ( $pts, $sev, $key, $msg, $fix = '' ) use ( &$iss, &$score ) {
			$score -= $pts;
			$iss[]  = array( 'sev' => $sev, 'key' => $key, 'msg' => $msg, 'fix' => $fix );
		};
		$text  = self::text_of( $post );
		$words = self::words( $text );
		$is_pg = 'page' === $post->post_type;
		$need  = $is_pg ? 300 : 400;
		if ( $words < 150 ) {
			$add( 30, 'bad', 'thin', 'Very little text (' . $words . ' words). Google and AdSense want real, original writing: aim for ' . $need . '+ words.' );
		} elseif ( $words < $need ) {
			$add( 18, 'warn', 'thin', 'Short page (' . $words . ' words). Add useful, original text to reach about ' . $need . ' words.' );
		}
		$title = trim( (string) get_post_meta( $post->ID, '_mrsh_title', true ) );
		$title = '' !== $title ? $title : trim( wp_strip_all_tags( get_the_title( $post ) ) );
		$tl    = mb_strlen( $title );
		if ( $tl < 15 ) {
			$add( 8, 'warn', 'title', 'Title is very short (' . $tl . ' characters). Say what the page is about.' );
		} elseif ( $tl > 70 ) {
			$add( 5, 'warn', 'title', 'Title is long (' . $tl . ' characters) and will be cut in search results. Keep it under about 60.' );
		}
		$desc = trim( (string) get_post_meta( $post->ID, '_mrsh_desc', true ) );
		if ( '' === $desc ) {
			$dl = $words ? min( 155, mb_strlen( $text ) ) : 0;
			if ( $dl < 70 ) {
				$add( 8, 'warn', 'desc', 'Not enough opening text to make a good search-result description. Write one in the page SEO box.' );
			}
		} elseif ( mb_strlen( $desc ) < 70 || mb_strlen( $desc ) > 165 ) {
			$add( 4, 'warn', 'desc', 'The description you wrote is ' . mb_strlen( $desc ) . ' characters. Best is 70 to 160.' );
		}
		$c = (string) $post->post_content;
		if ( $words > 300 && ! preg_match( '/<h[2-4]\b|wp:heading/i', $c ) ) {
			$add( 6, 'warn', 'head', 'No sub-headings. Break the text into sections with headings so it is easy to read.' );
		}
		$noalt = 0;
		if ( preg_match_all( '/<img\b[^>]*>/i', $c, $im ) ) {
			foreach ( $im[0] as $tag ) {
				if ( ! preg_match( '/\balt\s*=\s*"[^"]+"/i', $tag ) ) {
					$noalt++;
				}
			}
		}
		if ( $noalt ) {
			$add( min( 10, 3 + $noalt * 2 ), 'warn', 'alt', $noalt . ' picture(s) have no alt text (needed for accessibility and image search).', 'alt' );
		}
		$links = preg_match_all( '/<a\b[^>]*href=["\'](?:https?:\/\/(?:www\.)?myrishta\.pk)?\/[^"\']*["\']/i', $c );
		if ( $words > 150 && $links < 2 ) {
			$add( 6, 'info', 'links', 'Only ' . (int) $links . ' link(s) to other pages of the site. Link to 2 or more related pages.' );
		}
		$focus = trim( (string) get_post_meta( $post->ID, '_mrsh_focus', true ) );
		if ( '' === $focus ) {
			$add( 5, 'info', 'focus', 'No focus phrase yet.', 'focus' );
		}
		if ( ! has_post_thumbnail( $post ) && ! preg_match( '/<img\b/i', $c ) ) {
			$add( 4, 'info', 'img', 'No picture. A page with a picture looks better when shared on Facebook and WhatsApp.' );
		}
		return array( max( 0, $score ), $iss, $words );
	}

	/* ---------- scanning and fixing ---------- */

	private static function ids() {
		return get_posts( array( 'post_type' => array( 'page', 'post' ), 'post_status' => 'publish', 'posts_per_page' => 400, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'ASC', 'no_found_rows' => true ) );
	}

	/** Re-scores all pages. With $fix, safe fixes are applied first. Returns a short message. */
	public static function run( $fix = false ) {
		$fixed = 0;
		if ( $fix ) {
			if ( class_exists( 'MRSH_AutoKW' ) ) {
				MRSH_AutoKW::run();
			}
		}
		$rows = array();
		foreach ( self::ids() as $id ) {
			$p = get_post( $id );
			if ( ! $p ) {
				continue;
			}
			if ( $fix && ! get_post_meta( $id, '_mrsh_po_ignore', true ) ) {
				$fixed += self::fix_alt( $p );
			}
			list( $sc, $iss, $w ) = self::score_of( $p );
			$rows[ $id ] = array( 's' => $sc, 'w' => $w, 'i' => $iss );
		}
		$s          = self::get();
		$s['rows']  = $rows;
		$s['last']  = time();
		$s['fixed'] = $fix ? $fixed : (int) $s['fixed'];
		$avg        = $rows ? (int) round( array_sum( wp_list_pluck( $rows, 's' ) ) / count( $rows ) ) : 0;
		$s['msg']   = count( $rows ) . ' pages checked, average score ' . $avg . '.' . ( $fix ? ' ' . $fixed . ' picture label(s) fixed.' : '' );
		update_option( self::OPT, $s, false );
		return $s['msg'];
	}

	/** Gives alt text to pictures that belong to the media library (wp-image-N). Page text is never rewritten. */
	private static function fix_alt( $post ) {
		$n = 0;
		if ( preg_match_all( '/<img\b[^>]*wp-image-(\d+)[^>]*>/i', (string) $post->post_content, $m ) && class_exists( 'MRSH_AutoAlt' ) ) {
			foreach ( array_unique( $m[1] ) as $aid ) {
				$aid = (int) $aid;
				if ( wp_attachment_is_image( $aid ) && '' === trim( (string) get_post_meta( $aid, '_wp_attachment_image_alt', true ) ) ) {
					$alt = MRSH_AutoAlt::make( $aid );
					if ( MRSH_AutoAlt::is_junk( $alt ) ) {
						$alt = wp_strip_all_tags( get_the_title( $post ) );
					}
					update_post_meta( $aid, '_wp_attachment_image_alt', sanitize_text_field( $alt ) );
					$n++;
				}
			}
		}
		return $n;
	}

	public static function daily() {
		if ( ! empty( self::get()['on'] ) ) {
			self::run( true );
		}
	}

	/* ---------- actions ---------- */

	private static function guard( $n ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( $n );
	}

	private static function back( $m ) {
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-pageopt&msg=' . rawurlencode( $m ) ) );
		exit;
	}

	public static function act_scan() {
		self::guard( 'mrsh_po_scan' );
		self::back( self::run( false ) );
	}

	public static function act_fixall() {
		self::guard( 'mrsh_po_fixall' );
		self::back( self::run( true ) );
	}

	public static function act_fixone() {
		self::guard( 'mrsh_po_fixone' );
		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		$p  = $id ? get_post( $id ) : null;
		$m  = 'Page not found.';
		if ( $p ) {
			$a = self::fix_alt( $p );
			if ( class_exists( 'MRSH_AutoKW' ) && '' === trim( (string) get_post_meta( $id, '_mrsh_focus', true ) ) ) {
				MRSH_AutoKW::run();
			}
			self::run( false );
			$m = 'Fixed what is safe to fix on "' . get_the_title( $p ) . '" (' . $a . ' picture label(s)).';
		}
		self::back( $m );
	}

	public static function act_ignore() {
		self::guard( 'mrsh_po_ignore' );
		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		if ( $id ) {
			if ( get_post_meta( $id, '_mrsh_po_ignore', true ) ) {
				delete_post_meta( $id, '_mrsh_po_ignore' );
			} else {
				update_post_meta( $id, '_mrsh_po_ignore', 1 );
			}
		}
		self::back( 'Saved.' );
	}

	public static function act_toggle() {
		self::guard( 'mrsh_po_toggle' );
		$s       = self::get();
		$s['on'] = empty( $s['on'] ) ? 1 : 0;
		update_option( self::OPT, $s, false );
		self::arm();
		self::back( $s['on'] ? 'Daily robot is ON.' : 'Daily robot is OFF.' );
	}

	/* ---------- screen ---------- */

	private static function btn( $action, $label, $cls = 'mx-btn', $extra = '' ) {
		$ap = esc_url( admin_url( 'admin-post.php' ) );
		return '<form method="post" action="' . $ap . '" style="display:inline-block;margin:0 8px 8px 0"><input type="hidden" name="action" value="mrsh_po_' . esc_attr( $action ) . '">' . $extra . wp_nonce_field( 'mrsh_po_' . $action, '_wpnonce', true, false ) . '<button class="' . esc_attr( $cls ) . '">' . esc_html( $label ) . '</button></form>';
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s = self::get();
		if ( ! $s['rows'] ) {
			self::run( false );
			$s = self::get();
		}
		$rows = $s['rows'];
		uasort( $rows, function ( $a, $b ) {
			return $a['s'] <=> $b['s'];
		} );
		$n    = count( $rows );
		$avg  = $n ? (int) round( array_sum( wp_list_pluck( $rows, 's' ) ) / $n ) : 0;
		$low  = 0;
		$thin = 0;
		foreach ( $rows as $r ) {
			$low  += $r['s'] < 70 ? 1 : 0;
			foreach ( $r['i'] as $i ) {
				$thin += 'thin' === $i['key'] ? 1 : 0;
			}
		}
		MRSH_Boost::ui_open( 'Page Optimizer', 'Scores every page, shows what to improve, and fixes the safe things by itself every day.', 'g-gold', 'M12 2l2.9 6.9L22 10l-5.5 4.8L18 22l-6-3.6L6 22l1.5-7.2L2 10l7.1-1.1z' );
		if ( isset( $_GET['msg'] ) ) {
			MRSH_Boost::ui_ok( sanitize_text_field( wp_unslash( $_GET['msg'] ) ) );
		}
		echo '<div class="mx-grid" style="margin-bottom:18px">' . MRSH_Boost::ui_stat( $n, 'Pages checked', '#4a69d6' ) . MRSH_Boost::ui_stat( $avg, 'Average score', $avg >= 80 ? '#10b981' : '#f59e0b' ) . MRSH_Boost::ui_stat( $low, 'Need work (under 70)', '#e11d48' ) . MRSH_Boost::ui_stat( $thin, 'Too little text', '#7c3aed' ) . MRSH_Boost::ui_stat( (int) $s['fixed'], 'Fixed last run', '#10b981' ) . '</div>';
		echo '<div class="mx-card">';
		echo self::btn( 'scan', 'Scan all pages' ) . self::btn( 'fixall', 'Scan and fix safe issues', 'mx-btn p' ) . self::btn( 'toggle', ! empty( $s['on'] ) ? 'Daily robot: ON (press to turn off)' : 'Daily robot: OFF (press to turn on)' );
		echo '<p style="margin:6px 0 0;color:#6b7280;font-size:13px">' . ( $s['last'] ? 'Last scan ' . esc_html( wp_date( 'j M Y H:i', $s['last'] ) ) . '. ' . esc_html( $s['msg'] ) : 'Not scanned yet.' ) . ' The robot only fills empty picture labels and the automatic focus phrase. Pages with too little text are never filled in for you: real, original writing is what Google and AdSense look for.</p></div>';
		echo '<div class="mx-card"><table class="widefat striped" style="border:0"><thead><tr><th style="width:70px">Score</th><th>Page</th><th style="width:70px">Words</th><th>What to improve</th><th style="width:210px"></th></tr></thead><tbody>';
		foreach ( $rows as $id => $r ) {
			$ig  = (bool) get_post_meta( $id, '_mrsh_po_ignore', true );
			$cls = $r['s'] >= 80 ? 'ok' : ( $r['s'] >= 60 ? 'warn' : 'bad' );
			echo '<tr' . ( $ig ? ' style="opacity:.5"' : '' ) . '><td><span class="mx-pill ' . esc_attr( $cls ) . '">' . (int) $r['s'] . '</span></td>';
			echo '<td><a href="' . esc_url( get_edit_post_link( $id ) ) . '"><b>' . esc_html( get_the_title( $id ) ) . '</b></a><br><a href="' . esc_url( get_permalink( $id ) ) . '" target="_blank" rel="noopener" style="font-size:12px;color:#6b7280">View page</a></td>';
			echo '<td>' . (int) $r['w'] . '</td><td>';
			if ( ! $r['i'] ) {
				echo '<span class="mx-pill ok">All good</span>';
			}
			foreach ( $r['i'] as $i ) {
				echo '<div style="margin:0 0 4px"><span class="mx-pill ' . ( 'bad' === $i['sev'] ? 'bad' : ( 'warn' === $i['sev'] ? 'warn' : '' ) ) . '">' . esc_html( ucfirst( $i['key'] ) ) . '</span> ' . esc_html( $i['msg'] ) . '</div>';
			}
			echo '</td><td>' . self::btn( 'fixone', 'Fix', 'mx-btn s', '<input type="hidden" name="id" value="' . (int) $id . '">' ) . self::btn( 'ignore', $ig ? 'Stop ignoring' : 'Ignore', 'mx-btn s', '<input type="hidden" name="id" value="' . (int) $id . '">' ) . '<a class="mx-btn s" href="' . esc_url( get_edit_post_link( $id ) ) . '" style="margin-bottom:8px">Edit</a></td></tr>';
		}
		echo '</tbody></table></div></div>';
	}
}

MRSH_PageOpt::init();
