<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Video guides (3.101.412): short "how to" videos for members. The owner pastes a Google Drive (or YouTube) link for each
 * topic in the admin; the public page [mrsh_video_guides] shows one card per topic with plain steps in English and Urdu.
 * The video loads only when a card is tapped, so the page stays light on slow mobile data.
 */
class MRSH_Guides {

	const OPT = 'mrsh_guides';

	const ICON_JS = <<<'JS'
(function(){var M=window.MRSH_VI||{};var L=M.links||{},T=M.t||{};var ks=Object.keys(L);if(!ks.length||document.querySelector('.vg'))return;
var css='.mvi-i{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;margin-left:8px;border-radius:50%;background:#8e1a3f;color:#fff;font-size:11px;line-height:1;vertical-align:middle;cursor:pointer;border:0;padding:0;box-shadow:0 1px 4px rgba(0,0,0,.3)}.mvi-c{display:inline-flex;align-items:center;gap:8px;margin:0 0 12px;padding:7px 14px 7px 8px;border-radius:30px;background:#8e1a3f;color:#fff;font:600 14px/1.2 system-ui,sans-serif;border:0;cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,.2)}.mvi-c b{display:inline-flex;align-items:center;justify-content:center;width:26px;height:26px;border-radius:50%;background:#fff;color:#8e1a3f;font-size:11px}#mvi-box{position:fixed;inset:0;background:rgba(0,0,0,.78);display:none;align-items:center;justify-content:center;z-index:2147483000;padding:12px}#mvi-box.on{display:flex}#mvi-box .in{width:min(900px,100%);position:relative}#mvi-box iframe{width:100%;aspect-ratio:9/16;max-height:86vh;border:0;border-radius:12px;background:#000;display:block;margin:0 auto}#mvi-box .x{position:absolute;top:-14px;right:-4px;width:36px;height:36px;border-radius:50%;border:0;background:#fff;font-size:22px;cursor:pointer}@media(min-width:700px){#mvi-box iframe{aspect-ratio:16/9;max-height:80vh}}';
var st=document.createElement('style');st.textContent=css;document.head.appendChild(st);
var box=document.createElement('div');box.id='mvi-box';box.innerHTML='<div class="in"><button type="button" class="x" aria-label="Close">&times;</button><iframe allow="autoplay; fullscreen" allowfullscreen title="Video guide"></iframe></div>';document.body.appendChild(box);
var fr=box.querySelector('iframe');function close(){box.classList.remove('on');fr.removeAttribute('src')}
box.querySelector('.x').onclick=close;box.onclick=function(e){if(e.target===box)close()};document.addEventListener('keydown',function(e){if(e.key==='Escape')close()});
function open(k){fr.src=L[k];box.classList.add('on')}
function icon(k){var b=document.createElement('button');b.type='button';b.className='mvi-i';b.title='Watch video / ویڈیو دیکھیں';b.setAttribute('aria-label','Watch video: '+(T[k]||''));b.innerHTML='&#9654;';b.onclick=function(e){e.preventDefault();e.stopPropagation();open(k)};return b}
function chip(k){var b=document.createElement('button');b.type='button';b.className='mvi-c';b.innerHTML='<b>&#9654;</b><span></span>';b.querySelector('span').textContent='Watch: '+(T[k]||'How to')+' / ویڈیو';b.onclick=function(e){e.preventDefault();open(k)};return b}
var path=location.pathname,done={};
function put(k,sel,mode){if(!L[k])return;var el=document.querySelector(sel);if(!el||done[k+sel])return;done[k+sel]=1;
 if(mode==='after')el.parentNode.insertBefore(icon(k),el.nextSibling);else if(mode==='before')el.parentNode.insertBefore(chip(k),el);else if(mode==='inside')el.insertBefore(chip(k),el.firstChild)}
put('forgot','a[href*="action=lostpassword"]','after');
put('forgot','#lostpasswordform','before');
put('login','#loginform','before');
put('signup','#mrt-su','before');
put('password','#mrsh-pw','before');
put('chat','.mgr','before');
if(/\/memberships\//.test(path))put('plan','main h1','before');
if(/\/add-listing\//.test(path)&&document.querySelector('form:not(#mrt-su) input[name=action][value*="mrt_"]'))put('profile','main h1,.fhero','before');
if(/listing_type|\/find|\/search/.test(location.search+path))put('search','main form','before');
})();
JS;


	public static function init() {
		add_shortcode( 'mrsh_video_guides', array( __CLASS__, 'shortcode' ) );
		add_action( 'wp_footer', array( __CLASS__, 'icons' ), 60 );
		add_action( 'login_footer', array( __CLASS__, 'icons' ), 60 );
		add_action( 'init', array( __CLASS__, 'auto_page' ), 30 );
		if ( is_admin() ) {
			add_action( 'admin_menu', array( __CLASS__, 'menu' ), 45 );
			add_action( 'admin_post_mrsh_guides_save', array( __CLASS__, 'save' ) );
			add_action( 'admin_post_mrsh_guides_page', array( __CLASS__, 'make_page' ) );
		}
	}

	/** Makes the public page once, by itself, so nothing has to be set up by hand. */
	public static function auto_page() {
		if ( get_option( 'mrsh_guides_page' ) || wp_doing_ajax() ) {
			return;
		}
		update_option( 'mrsh_guides_page', 1, false );
		if ( ! self::page_url() ) {
			wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => 'Video Guides', 'post_name' => 'video-guides', 'post_content' => '[mrsh_video_guides]' ) );
		}
	}

	/** key => array( English title, Urdu title, English steps, Urdu steps ). */
	public static function topics() {
		return array(
			'signup'   => array( 'How to sign up', 'سائن اپ کیسے کریں', array( 'Tap Create free profile.', 'Enter your name, email or mobile and a password of 6 or more characters.', 'Accept the terms and press Create account.' ), 'مفت پروفائل بنائیں دبائیں۔ نام، ای میل یا موبائل اور کم از کم ۶ حروف کا پاس ورڈ لکھیں۔ شرائط مان کر اکاؤنٹ بنائیں۔' ),
			'login'    => array( 'How to log in', 'لاگ اِن کیسے کریں', array( 'Tap Log in.', 'Type your email or mobile number and your password.', 'If you forgot it, tap Forgot password and we email you a link.' ), 'لاگ اِن دبائیں۔ ای میل یا موبائل نمبر اور پاس ورڈ لکھیں۔ بھول جائیں تو پاس ورڈ بھول گئے دبائیں۔' ),
			'profile'  => array( 'How to add your profile', 'پروفائل کیسے بنائیں', array( 'Open Add profile.', 'Fill in your details, family and what you look for.', 'Add a clear photo and press Publish.' ), 'پروفائل بنائیں کھولیں۔ اپنی تفصیل، خاندان اور مطلوبہ رشتہ لکھیں۔ صاف تصویر لگا کر شائع کریں۔' ),
			'photo'    => array( 'How to add or change photos', 'تصویر کیسے لگائیں یا بدلیں', array( 'Open My account, then Edit profile.', 'Tap the photo box and choose a picture.', 'Save. You can keep photos private.' ), 'میرا اکاؤنٹ میں پروفائل میں ترمیم کھولیں۔ تصویر کے خانے پر ٹیپ کر کے تصویر چنیں۔ محفوظ کریں۔' ),
			'search'   => array( 'How to search for a rishta', 'رشتہ تلاش کیسے کریں', array( 'Tap Search.', 'Choose age, city, education and other filters.', 'Open a profile to see all details.' ), 'تلاش دبائیں۔ عمر، شہر اور تعلیم چنیں۔ پروفائل کھول کر پوری تفصیل دیکھیں۔' ),
			'interest' => array( 'How to send an interest', 'دلچسپی کیسے بھیجیں', array( 'Open a profile you like.', 'Tap Send interest.', 'You get a notice when they reply.' ), 'پسند آنے والا پروفائل کھولیں۔ دلچسپی بھیجیں دبائیں۔ جواب آنے پر آپ کو اطلاع ملے گی۔' ),
			'chat'     => array( 'How to use the messenger', 'پیغام رسانی کیسے کریں', array( 'Open My account, then Messages.', 'Pick a person and type, or tap a Quick Q&A button.', 'Two ticks mean your message was read.' ), 'میرا اکاؤنٹ میں پیغامات کھولیں۔ کسی کو چن کر لکھیں یا تیار جملہ دبائیں۔ دو ٹک کا مطلب پیغام پڑھ لیا گیا۔' ),
			'password' => array( 'How to change your password', 'پاس ورڈ کیسے بدلیں', array( 'Open My account, then Settings.', 'Type your current password and the new one twice.', 'Press Change password.' ), 'میرا اکاؤنٹ میں سیٹنگز کھولیں۔ پرانا اور دو بار نیا پاس ورڈ لکھیں۔ پاس ورڈ بدلیں دبائیں۔' ),
			'forgot'   => array( 'Forgot your password?', 'پاس ورڈ بھول گئے؟', array( 'On the login page tap Forgot password.', 'Enter your email.', 'Open the email and choose a new password.' ), 'لاگ اِن صفحے پر پاس ورڈ بھول گئے دبائیں۔ ای میل لکھیں۔ ای میل میں لنک کھول کر نیا پاس ورڈ بنائیں۔' ),
			'verify'   => array( 'How to verify your email', 'ای میل کی تصدیق کیسے کریں', array( 'Open the email we sent you.', 'Tap the verify button inside it.', 'Check the Spam folder if you cannot see it.' ), 'ہماری بھیجی ہوئی ای میل کھولیں۔ اس میں تصدیق کا بٹن دبائیں۔ نظر نہ آئے تو اسپام فولڈر دیکھیں۔' ),
			'plan'     => array( 'How to request a package', 'پیکج کی درخواست کیسے کریں', array( 'Open Free Membership.', 'Choose a plan and press Request.', 'We will contact you and switch it on.' ), 'مفت رکنیت کھولیں۔ پلان چن کر درخواست دبائیں۔ ہم رابطہ کر کے فعال کر دیں گے۔' ),
			'phone'    => array( 'How to ask for a phone number', 'فون نمبر کی درخواست کیسے کریں', array( 'Open the profile.', 'Tap Request phone number.', 'The number is shown only if they approve.' ), 'پروفائل کھولیں۔ فون نمبر کی درخواست دبائیں۔ نمبر صرف منظوری کے بعد دکھایا جاتا ہے۔' ),
			'safe'     => array( 'Stay safe: rishta tips', 'محفوظ رہیں', array( 'Never send money or CNIC copies.', 'Meet with family in a public place.', 'Tap Report if anything feels wrong.' ), 'کبھی رقم یا شناختی کارڈ کی کاپی نہ بھیجیں۔ خاندان کے ساتھ عوامی جگہ پر ملیں۔ کچھ غلط لگے تو رپورٹ کریں۔' ),
			'app'      => array( 'How to install the app on your phone', 'ایپ فون پر کیسے لگائیں', array( 'Open myrishta.pk in Chrome.', 'Tap the three dots, then Add to Home screen.', 'Open the new icon like any app.' ), 'کروم میں myrishta.pk کھولیں۔ تین نقطوں پر ٹیپ کر کے ہوم اسکرین پر شامل کریں۔ نئے آئیکن سے ایپ کھولیں۔' ),
		);
	}

	/** Small play icons next to the matching links and forms (Forgot password, Log in, Sign up...). They open the video in a pop-up. */
	public static function icons() {
		if ( is_admin() ) {
			return;
		}
		$t = array();
		$l = array();
		foreach ( self::topics() as $k => $x ) {
			$e = self::embed( self::links()[ $k ] ?? '' );
			if ( $e ) {
				$l[ $k ] = $e;
				$t[ $k ] = $x[0];
			}
		}
		if ( ! $l ) {
			return;
		}
		echo '<script data-no-optimize="1" data-cfasync="false">window.MRSH_VI=' . wp_json_encode( array( 'links' => $l, 't' => $t ) ) . ';' . self::ICON_JS . '</script>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	public static function links() {
		$o = get_option( self::OPT, array() );
		return is_array( $o ) ? $o : array();
	}

	/** Turn a pasted Google Drive or YouTube link into a safe embed address ('' when it is not one of those). */
	public static function embed( $url ) {
		$url = trim( (string) $url );
		if ( preg_match( '~^https://drive\.google\.com/(?:file/d/|open\?id=|uc\?(?:[^#]*&)?id=)([A-Za-z0-9_-]{10,})~', $url, $m ) ) {
			return 'https://drive.google.com/file/d/' . $m[1] . '/preview';
		}
		if ( preg_match( '~^https://(?:www\.)?(?:youtube\.com/(?:watch\?(?:[^#]*&)?v=|shorts/|embed/)|youtu\.be/)([A-Za-z0-9_-]{11})~', $url, $m ) ) {
			return 'https://www.youtube-nocookie.com/embed/' . $m[1] . '?rel=0';
		}
		return '';
	}

	public static function shortcode() {
		$links = self::links();
		$out   = '<style>.vg{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:14px;margin:16px 0}.vg .vc{background:#fff;border:1px solid #e5e7eb;border-radius:14px;padding:16px;display:flex;flex-direction:column;gap:8px;box-shadow:0 1px 3px rgba(0,0,0,.05)}.vg h3{margin:0;font-size:1.05rem}.vg .ur{direction:rtl;font-size:1.05rem;color:#8e1a3f;font-weight:700;margin:0}.vg ol{margin:0;padding-left:20px;font-size:.92rem;color:#374151}.vg .ud{direction:rtl;font-size:.92rem;color:#374151;margin:0}.vg button.play{margin-top:auto;border:0;border-radius:10px;background:#8e1a3f;color:#fff;padding:11px 14px;font-size:1rem;font-weight:700;cursor:pointer}.vg .soon{margin-top:auto;font-size:.85rem;color:#6b7280;background:#f3f4f6;border-radius:10px;padding:9px 12px;text-align:center}#vg-box{position:fixed;inset:0;background:rgba(0,0,0,.75);display:none;align-items:center;justify-content:center;z-index:99999;padding:12px}#vg-box.on{display:flex}#vg-box .in{width:min(900px,100%);background:#000;border-radius:12px;position:relative}#vg-box iframe{width:100%;aspect-ratio:16/9;border:0;display:block;border-radius:12px}#vg-box .x{position:absolute;top:-14px;right:-6px;width:36px;height:36px;border-radius:50%;border:0;background:#fff;font-size:20px;cursor:pointer}</style>';
		$out  .= '<p class="vgi">Short videos that show every step. Tap <b>Watch video</b>. / مختصر ویڈیوز جو ہر قدم دکھاتی ہیں۔ <b>ویڈیو دیکھیں</b> دبائیں۔</p><div class="vg">';
		foreach ( self::topics() as $k => $t ) {
			$emb  = self::embed( $links[ $k ] ?? '' );
			$out .= '<div class="vc" id="vg-' . esc_attr( $k ) . '"><h3>' . esc_html( $t[0] ) . '</h3><p class="ur">' . esc_html( $t[1] ) . '</p><ol>';
			foreach ( $t[2] as $s ) {
				$out .= '<li>' . esc_html( $s ) . '</li>';
			}
			$out .= '</ol><p class="ud">' . esc_html( $t[3] ) . '</p>';
			$out .= $emb ? '<button type="button" class="play" data-src="' . esc_url( $emb ) . '" onclick="var f=document.querySelector(\'#vg-box iframe\');f.src=this.getAttribute(\'data-src\');document.getElementById(\'vg-box\').className=\'on\'">&#9654; Watch video / ویڈیو دیکھیں</button>' : '<div class="soon">Video coming soon / ویڈیو جلد آ رہی ہے</div>';
			$out .= '</div>';
		}
		$out .= '</div><div id="vg-box" role="dialog" aria-modal="true" onclick="if(event.target===this){this.className=\'\';this.querySelector(\'iframe\').removeAttribute(\'src\')}"><div class="in"><button type="button" class="x" aria-label="Close" onclick="var b=document.getElementById(\'vg-box\');b.className=\'\';b.querySelector(\'iframe\').removeAttribute(\'src\')">&times;</button><iframe allow="autoplay; fullscreen" allowfullscreen title="Video guide"></iframe></div></div>';
		$out .= '<script data-no-optimize="1" data-cfasync="false">(function(){var b=document.getElementById("vg-box");if(!b)return;var f=b.querySelector("iframe");function c(){b.classList.remove("on");f.removeAttribute("src")}document.querySelectorAll(".vg .play").forEach(function(p){p.addEventListener("click",function(){f.src=p.getAttribute("data-src");b.classList.add("on")})});b.querySelector(".x").addEventListener("click",c);b.addEventListener("click",function(e){if(e.target===b)c()});document.addEventListener("keydown",function(e){if(e.key==="Escape")c()});if(location.hash){var t=document.querySelector(location.hash);if(t&&t.classList.contains("vc")){t.scrollIntoView();var p=t.querySelector(".play");if(p)p.click()}}})();</script>';
		return $out;
	}

	/* ---------------------------------------------------------------- admin */
	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Video guides', 'Video guides', 'manage_options', 'mrsh-guides', array( __CLASS__, 'page' ) );
	}

	private static function guard( $a ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( $a );
	}

	private static function back( $msg ) {
		wp_safe_redirect( add_query_arg( array( 'page' => 'mrsh-guides', 'msg' => rawurlencode( $msg ) ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public static function save() {
		self::guard( 'mrsh_guides_save' );
		$in = isset( $_POST['g'] ) && is_array( $_POST['g'] ) ? wp_unslash( $_POST['g'] ) : array(); // phpcs:ignore WordPress.Security
		$o  = array();
		$bad = 0;
		foreach ( self::topics() as $k => $t ) {
			$u = isset( $in[ $k ] ) ? esc_url_raw( trim( (string) $in[ $k ] ) ) : '';
			if ( '' === $u ) {
				continue;
			}
			if ( '' === self::embed( $u ) ) {
				$bad++;
				continue;
			}
			$o[ $k ] = $u;
		}
		update_option( self::OPT, $o, false );
		self::back( count( $o ) . ' video link' . ( 1 === count( $o ) ? '' : 's' ) . ' saved.' . ( $bad ? ' ' . $bad . ' link(s) were not a Google Drive or YouTube link and were skipped.' : '' ) );
	}

	public static function page_url() {
		$p = get_page_by_path( 'video-guides' );
		return $p ? get_permalink( $p ) : '';
	}

	public static function make_page() {
		self::guard( 'mrsh_guides_page' );
		if ( ! self::page_url() ) {
			wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => 'Video Guides', 'post_name' => 'video-guides', 'post_content' => '[mrsh_video_guides]' ) );
		}
		self::back( 'The Video Guides page is ready.' );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$links = self::links();
		$url   = self::page_url();
		$n     = count( $links );
		MRSH_Boost::ui_open( 'Video guides', 'Short how-to videos for members. Paste a Google Drive or YouTube link for each topic. Members see them on one page, with the steps in English and Urdu.', 'g-green', 'M17 10.5V7a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-3.5l4 4v-11z' );
		if ( isset( $_GET['msg'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			MRSH_Boost::ui_ok( rawurldecode( (string) wp_unslash( $_GET['msg'] ) ) ); // phpcs:ignore
		}
		echo '<div class="mx-stats">' . MRSH_Boost::ui_stat( $n, 'Videos added', '#10b981' ) . MRSH_Boost::ui_stat( count( self::topics() ) - $n, 'Still to record', '#f59e0b' ) . MRSH_Boost::ui_stat( $url ? 'Live' : 'Not made', 'Public page', $url ? '#0ea5e9' : '#6b7280' ) . '</div>'; // phpcs:ignore
		echo '<div class="mx-card"><h2>1. Public page</h2>';
		if ( $url ) {
			echo '<p class="mx-sub">Members open it here: <a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $url ) . '</a>. Add it to the menu in Appearance, Menus if it is not there.</p>';
		} else {
			echo '<p class="mx-sub">The page does not exist yet. One button makes it.</p>';
			MRSH_Admin::post_button( 'mrsh_guides_page', 'Create the Video Guides page', true );
		}
		echo '</div>';
		echo '<div class="mx-card"><h2>2. Video links</h2><p class="mx-sub"><b>How:</b> record your phone screen for 30 to 60 seconds per topic, upload it to Google Drive, then right-click it, Share, set to <b>Anyone with the link</b>, copy the link and paste it below. Leave a box empty and members see "Video coming soon".</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_guides_save">';
		wp_nonce_field( 'mrsh_guides_save' );
		echo '<table class="widefat striped"><thead><tr><th>Topic</th><th>Google Drive or YouTube link</th><th></th></tr></thead><tbody>';
		foreach ( self::topics() as $k => $t ) {
			$v = $links[ $k ] ?? '';
			echo '<tr><td><b>' . esc_html( $t[0] ) . '</b><br><span style="color:#8e1a3f;direction:rtl">' . esc_html( $t[1] ) . '</span></td><td><input type="url" name="g[' . esc_attr( $k ) . ']" value="' . esc_attr( $v ) . '" placeholder="https://drive.google.com/file/d/..." style="width:100%"></td><td>' . ( $v ? '<span style="color:#059669">&#10003; added</span>' : '<span style="color:#9ca3af">empty</span>' ) . '</td></tr>';
		}
		echo '</tbody></table><p><button class="button button-primary button-large">Save all links</button></p></form></div></div>';
	}
}
