<?php
/**
 * reCAPTCHA v2 ("I'm not a robot") on the forms visitors use (3.101.111). Uses the keys saved in Website keys.
 * If Google cannot be reached the check lets the visitor through, so a Google outage never locks anyone out.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Captcha {

	private static $done = false;

	public static function keys() {
		$k = class_exists( 'MRSH_Keys' ) ? MRSH_Keys::get() : array();
		return array( trim( (string) ( $k['captcha_site'] ?? '' ) ), trim( (string) ( $k['captcha_secret'] ?? '' ) ) );
	}

	public static function on() {
		$k = self::keys();
		if ( '' === $k[0] || '' === $k[1] ) {
			return false;
		}
		// A key that is not 40 characters starting with 6L can never be accepted by Google, so enforcing it would lock every member out.
		if ( ! preg_match( '/^6L[A-Za-z0-9_\-]{38}$/', $k[0] ) || ! preg_match( '/^6L[A-Za-z0-9_\-]{38}$/', $k[1] ) ) {
			return false;
		}
		$o = get_option( 'mrsh_master', array() );
		return ! ( is_array( $o ) && isset( $o['captcha'] ) && ! $o['captcha'] );
	}

	/** Prints the box. Safe to call more than once on a page. */
	/** True when keys are saved but look wrong, so the robot check is switched off until they are fixed. */
	public static function keys_bad() {
		$k = self::keys();
		return ( '' !== $k[0] || '' !== $k[1] ) && ( ! preg_match( '/^6L[A-Za-z0-9_\-]{38}$/', $k[0] ) || ! preg_match( '/^6L[A-Za-z0-9_\-]{38}$/', $k[1] ) );
	}

	public static function widget() {
		if ( ! self::on() ) {
			return;
		}
		$k = self::keys();
		echo '<div class="g-recaptcha" data-sitekey="' . esc_attr( $k[0] ) . '" style="margin:12px 0"></div>';
		if ( ! self::$done ) {
			self::$done = true;
			echo '<script src="https://www.google.com/recaptcha/api.js" async defer></script>';
			echo '<script>document.addEventListener("submit",function(e){var f=e.target,w=f&&f.querySelector?f.querySelector(".g-recaptcha"):null;if(!w||typeof grecaptcha==="undefined"||!grecaptcha.getResponse){return;}var all=document.querySelectorAll(".g-recaptcha"),i=Array.prototype.indexOf.call(all,w),r="";try{r=grecaptcha.getResponse(i);}catch(x){return;}if(r){return;}e.preventDefault();var m=f.querySelector(".mrsh-cap-msg");if(!m){m=document.createElement("div");m.className="mrsh-cap-msg";m.setAttribute("role","alert");m.style.cssText="margin:8px 0;padding:10px 12px;border-radius:10px;background:#fef2f2;border:1px solid #fca5a5;color:#7f1d1d;font-weight:600";w.parentNode.insertBefore(m,w);}m.textContent="Please tick \\u201cI\\u2019m not a robot\\u201d first, then press the button again.";w.scrollIntoView({block:"center",behavior:"smooth"});},true);</script>';
		}
	}

	/** True when the visitor passed (or the check is off / Google is unreachable). */
	private static $memo = null;

	public static function ok() {
		if ( ! self::on() ) {
			return true;
		}
		// Google accepts a ticked-box token only once. Login runs several checks in one request, so the answer is kept (3.101.226).
		if ( null === self::$memo ) {
			self::$memo = self::verify();
		}
		return self::$memo;
	}

	private static function verify() {
		$resp = isset( $_POST['g-recaptcha-response'] ) ? sanitize_text_field( wp_unslash( $_POST['g-recaptcha-response'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		if ( '' === $resp ) {
			return false;
		}
		$k = self::keys();
		$r = wp_remote_post( 'https://www.google.com/recaptcha/api/siteverify', array( 'timeout' => 8, 'body' => array( 'secret' => $k[1], 'response' => $resp, 'remoteip' => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '' ) ) );
		if ( is_wp_error( $r ) ) {
			return true;
		}
		$j = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( ! is_array( $j ) ) {
			return true;
		}
		if ( empty( $j['success'] ) ) {
			self::$why = isset( $j['error-codes'] ) && is_array( $j['error-codes'] ) ? implode( ', ', array_map( 'sanitize_text_field', $j['error-codes'] ) ) : '';
			// Diagnostic for the owner (no secrets): why Google refused, token size, and whether the secret key itself is accepted.
			$probe = wp_remote_post( 'https://www.google.com/recaptcha/api/siteverify', array( 'timeout' => 6, 'body' => array( 'secret' => $k[1], 'response' => 'probe' ) ) );
			$pj    = is_wp_error( $probe ) ? array() : (array) json_decode( wp_remote_retrieve_body( $probe ), true );
			update_option( 'mrsh_cap_diag', array(
				't'        => time(),
				'why'      => self::$why,
				'tok_len'  => strlen( $resp ),
				'fields'   => isset( $_POST['g-recaptcha-response'] ) && is_array( $_POST['g-recaptcha-response'] ) ? 'array' : 'string', // phpcs:ignore WordPress.Security.NonceVerification
				'secret_ok'=> ! empty( $pj['error-codes'] ) && ! in_array( 'invalid-input-secret', (array) $pj['error-codes'], true ) && ! in_array( 'missing-input-secret', (array) $pj['error-codes'], true ),
				'probe'    => isset( $pj['error-codes'] ) ? implode( ',', (array) $pj['error-codes'] ) : 'none',
				'host'     => (string) ( $j['hostname'] ?? '' ),
				'site_len' => strlen( $k[0] ),
				'sec_len'  => strlen( $k[1] ),
				'site_pre' => substr( $k[0], 0, 4 ),
			), false );
			return false;
		}
		return true;
	}

	/** A plain message for the visitor, with Google's code only when it points to a set-up problem. */
	public static function msg() {
		$w = self::$why;
		if ( '' === $w ) {
			return '<strong>Error</strong>: please tick &ldquo;I&rsquo;m not a robot&rdquo; and try again.';
		}
		if ( false !== strpos( $w, 'secret' ) || false !== strpos( $w, 'bad-request' ) ) {
			return '<strong>Error</strong>: the robot check is not set up correctly. Please tell the site owner. (' . esc_html( $w ) . ')';
		}
		return '<strong>Error</strong>: the &ldquo;I&rsquo;m not a robot&rdquo; tick expired or was already used. Please tick it again, then press the button. (' . esc_html( $w ) . ')';
	}

	/** Google's reason for a refusal (for example invalid-input-secret = the secret key saved is wrong). */
	public static $why = '';

	public static function init() {
		add_action( 'register_form', array( __CLASS__, 'widget' ) );
		add_filter( 'registration_errors', function ( $errors ) {
			if ( ! self::ok() ) {
				$errors->add( 'mrsh_captcha', self::msg() );
			}
			return $errors;
		} );
		add_action( 'login_form', array( __CLASS__, 'widget' ) );
		// The theme's own login box (wp_login_form) never fires login_form, so the box was missing there and every login failed (3.101.226).
		add_filter( 'login_form_middle', function ( $html ) {
			ob_start();
			self::widget();
			return $html . ob_get_clean();
		} );
		add_filter( 'wp_authenticate_user', function ( $user ) {
			if ( is_wp_error( $user ) || empty( $GLOBALS['pagenow'] ) || 'wp-login.php' !== $GLOBALS['pagenow'] || empty( $_POST['log'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
				return $user;
			}
			if ( ! self::ok() ) {
				return new WP_Error( 'mrsh_captcha', self::msg() );
			}
			return $user;
		} );
	}
}
add_action( 'admin_notices', function () {
	if ( current_user_can( 'manage_options' ) && MRSH_Captcha::keys_bad() ) {
		echo '<div class="notice notice-warning"><p><b>Robot check is switched off.</b> The reCAPTCHA secret key saved on the site is not 40 characters long, so Google would refuse every login. Open <a href="' . esc_url( admin_url( 'admin.php?page=mrsh-keys' ) ) . '">Website keys</a>, copy the <b>Secret key</b> again from google.com/recaptcha/admin and save it. The check turns on by itself when the key is right.</p></div>';
	}
} );
MRSH_Captcha::init();
