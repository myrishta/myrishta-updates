<?php
/**
 * Website keys: reCAPTCHA, Google login, Google Maps, PageSpeed, Vision and Translate. Kept in one place that you can change at any time.
 * First time: the current values are copied from the DA10 settings (option "core_admin_values"). After that, the values saved
 * here win, also while DA10 is still active (they are applied whenever those settings are read), so changing a key here is enough.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Keys {

	const OPT = 'mrsh_keys';

	/** field => array( label, secret?, help ) */
	public static function fields() {
		return array(
			'captcha_site'   => array( 'reCAPTCHA site key', false, 'Public key shown on the login and register forms.' ),
			'captcha_secret' => array( 'reCAPTCHA secret key', true, 'Private key. Keep it secret.' ),
			'google_id'      => array( 'Google login: Client ID', false, 'Google Cloud > APIs & Services > Credentials > OAuth client.' ),
			'google_secret'  => array( 'Google login: Client secret', true, 'Private key. Keep it secret.' ),
			'maps_key'       => array( 'Google Maps API key', false, 'Restrict it to your website address in Google Cloud.' ),
			'psi_key'        => array( 'Google PageSpeed API key', true, 'Used by the speed check, so it does not hit the shared free limit. Restrict it to the PageSpeed Insights API.' ),
			'vision_key'     => array( 'Google Vision API key', true, 'Used to check new profile photos (stolen or fake pictures). Restrict it to the Cloud Vision API.' ),
			'translate_key'  => array( 'Google Translate API key', true, 'Used by chat translation when the translation provider is set to Google. Restrict it to the Cloud Translation API.' ),
		);
	}

	public static function init() {
		add_filter( 'option_core_admin_values', array( __CLASS__, 'apply' ), 20 );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 26 );
		add_action( 'admin_post_mrsh_keys_save', array( __CLASS__, 'save' ) );
		add_action( 'wp_ajax_mrsh_keys_test', array( __CLASS__, 'test' ) );
	}

	/** Saved values. On first use they are imported from the old theme settings. */
	public static function get() {
		$v = get_option( self::OPT, null );
		if ( ! is_array( $v ) ) {
			$v   = array_fill_keys( array_keys( self::fields() ), '' );
			remove_filter( 'option_core_admin_values', array( __CLASS__, 'apply' ), 20 );
			$old = get_option( 'core_admin_values' );
			add_filter( 'option_core_admin_values', array( __CLASS__, 'apply' ), 20 );
			if ( is_array( $old ) ) {
				$v['captcha_site']   = isset( $old['captcha']['sitekey'] ) ? (string) $old['captcha']['sitekey'] : '';
				$v['captcha_secret'] = isset( $old['captcha']['secretkey'] ) ? (string) $old['captcha']['secretkey'] : '';
				$v['google_id']      = isset( $old['social_google_key1'] ) ? (string) $old['social_google_key1'] : '';
				$v['google_secret']  = isset( $old['social_google_key2'] ) ? (string) $old['social_google_key2'] : '';
				$v['maps_key']       = isset( $old['maps']['apikey'] ) ? (string) $old['maps']['apikey'] : '';
				update_option( self::OPT, $v, false );
			}
		}
		return $v;
	}

	/** Use the keys saved here wherever the old settings are read. */
	public static function apply( $val ) {
		if ( ! is_array( $val ) ) {
			return $val;
		}
		$v = get_option( self::OPT, null );
		if ( ! is_array( $v ) ) {
			return $val;
		}
		$map = array(
			'captcha_site'   => array( 'captcha', 'sitekey' ),
			'captcha_secret' => array( 'captcha', 'secretkey' ),
			'maps_key'       => array( 'maps', 'apikey' ),
		);
		foreach ( $map as $k => $path ) {
			if ( ! empty( $v[ $k ] ) ) {
				if ( ! isset( $val[ $path[0] ] ) || ! is_array( $val[ $path[0] ] ) ) {
					$val[ $path[0] ] = array();
				}
				$val[ $path[0] ][ $path[1] ] = $v[ $k ];
			}
		}
		if ( ! empty( $v['google_id'] ) ) {
			$val['social_google_key1'] = $v['google_id'];
		}
		if ( ! empty( $v['google_secret'] ) ) {
			$val['social_google_key2'] = $v['google_secret'];
		}
		return $val;
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Website keys', 'Website keys', 'manage_options', 'mrsh-keys', array( __CLASS__, 'page' ) );
	}

	private static function mask( $s ) {
		$s = (string) $s;
		return '' === $s ? 'not set' : 'saved (ends ' . esc_html( substr( $s, -4 ) ) . ')';
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_keys_save' );
		$cur  = self::get();
		$meta = self::meta();
		$warn = array();
		foreach ( self::fields() as $k => $f ) {
			$new = isset( $_POST['k'][ $k ] ) ? trim( (string) wp_unslash( $_POST['k'][ $k ] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			$new = preg_replace( '/[^A-Za-z0-9_\-\.\:\/~]/', '', $new );
			if ( '' !== $new ) {
				$cur[ $k ] = $new;            // a new value replaces the old one
				$meta['t'][ $k ] = time();
				self::log( $meta, $k, 'changed' );
				if ( ! self::format_ok( $k, $new ) ) {
					$warn[] = $f[0];
				}
			} elseif ( ! empty( $_POST['clear'][ $k ] ) ) {
				$cur[ $k ] = '';              // tick "remove" to clear a key
				unset( $meta['t'][ $k ] );
				self::log( $meta, $k, 'removed' );
			}                                   // blank without the tick keeps what is saved
		}
		update_option( self::OPT, $cur, false );
		update_option( self::OPT . '_meta', $meta, false );
		$url = admin_url( 'admin.php?page=mrsh-keys&saved=1' );
		if ( $warn ) {
			$url = add_query_arg( 'odd', rawurlencode( implode( ', ', $warn ) ), $url );
		}
		wp_safe_redirect( $url );
		exit;
	}

	/** Key history: when each key was last changed and a short log (no key values are ever stored here). */
	private static function meta() {
		$m = get_option( self::OPT . '_meta', array() );
		return array( 't' => (array) ( $m['t'] ?? array() ), 'log' => (array) ( $m['log'] ?? array() ) );
	}

	private static function log( &$meta, $k, $what ) {
		$meta['log'][] = array( time(), get_current_user_id(), $k, $what );
		$meta['log']   = array_slice( $meta['log'], -40 );
	}

	/** Typical shape of each key. A key that does not look right is still saved, with a warning. */
	public static function format_ok( $k, $v ) {
		switch ( $k ) {
			case 'captcha_site':
			case 'captcha_secret':
				return (bool) preg_match( '/^6L[A-Za-z0-9_\-]{38}$/', $v );
			case 'google_id':
				return (bool) preg_match( '/^[0-9]+-[A-Za-z0-9_]+\.apps\.googleusercontent\.com$/', $v );
			case 'google_secret':
				return (bool) preg_match( '/^GOCSPX-[A-Za-z0-9_\-]{20,}$/', $v );
			case 'maps_key':
			case 'psi_key':
			case 'vision_key':
			case 'translate_key':
				return (bool) preg_match( '/^AIza[A-Za-z0-9_\-]{35}$/', $v );
		}
		return true;
	}

	/** Live checks run from the page buttons. Only your own keys are used, only against Google. */
	public static function test() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'msg' => 'Not allowed.' ), 403 );
		}
		check_ajax_referer( 'mrsh_keys_test', 'n' );
		$what = isset( $_POST['what'] ) ? sanitize_key( wp_unslash( $_POST['what'] ) ) : '';
		$v    = self::get();
		if ( 'captcha' === $what ) {
			if ( empty( $v['captcha_secret'] ) ) {
				wp_send_json_success( array( 'ok' => false, 'msg' => 'No secret key is saved yet.' ) );
			}
			$r = wp_remote_post( 'https://www.google.com/recaptcha/api/siteverify', array( 'timeout' => 10, 'body' => array( 'secret' => $v['captcha_secret'], 'response' => 'mrsh-key-test' ) ) );
			if ( is_wp_error( $r ) ) {
				wp_send_json_success( array( 'ok' => false, 'msg' => 'Could not reach Google just now. Try again.' ) );
			}
			$j = json_decode( wp_remote_retrieve_body( $r ), true );
			$e = (array) ( $j['error-codes'] ?? array() );
			if ( in_array( 'invalid-input-secret', $e, true ) || in_array( 'missing-input-secret', $e, true ) ) {
				wp_send_json_success( array( 'ok' => false, 'msg' => 'Google does NOT accept this secret key. Check it was copied fully and belongs to the same site key.' ) );
			}
			wp_send_json_success( array( 'ok' => true, 'msg' => 'Google accepts the secret key.' ) );
		}
		if ( 'captcha_live' === $what ) {
			$h = wp_remote_retrieve_body( wp_remote_get( wp_login_url(), array( 'timeout' => 10 ) ) );
			$ok = '' !== (string) ( $v['captcha_site'] ?? '' ) && false !== strpos( (string) $h, (string) $v['captcha_site'] );
			wp_send_json_success( array( 'ok' => $ok, 'msg' => $ok ? 'The site key is shown on your login page.' : 'The site key was not found on the login page. Clear the cache and check again.' ) );
		}
		if ( 'google' === $what ) {
			if ( empty( $v['google_id'] ) || ! class_exists( 'MRSH_Mem_Social' ) ) {
				wp_send_json_success( array( 'ok' => false, 'msg' => 'No Client ID is saved yet.' ) );
			}
			$u = add_query_arg( array( 'client_id' => $v['google_id'], 'redirect_uri' => MRSH_Mem_Social::cb( 'google' ), 'response_type' => 'code', 'scope' => 'openid' ), 'https://accounts.google.com/o/oauth2/v2/auth' );
			$r = wp_remote_get( $u, array( 'timeout' => 12, 'redirection' => 0 ) );
			if ( is_wp_error( $r ) ) {
				wp_send_json_success( array( 'ok' => false, 'msg' => 'Could not reach Google just now. Try again.' ) );
			}
			$b = strtolower( (string) wp_remote_retrieve_body( $r ) );
			if ( false !== strpos( $b, 'invalid_client' ) || false !== strpos( $b, 'client_id' ) && 400 === (int) wp_remote_retrieve_response_code( $r ) && false === strpos( $b, 'redirect_uri' ) ) {
				wp_send_json_success( array( 'ok' => false, 'msg' => 'Google says this Client ID does not exist. Check it.' ) );
			}
			if ( false !== strpos( $b, 'redirect_uri_mismatch' ) ) {
				wp_send_json_success( array( 'ok' => false, 'msg' => 'The Client ID is real, but the redirect address is not added in Google Cloud yet. Copy it from "Values to paste into Google" below.' ) );
			}
			wp_send_json_success( array( 'ok' => true, 'msg' => 'Google accepts the Client ID and the redirect address.' ) );
		}
		wp_send_json_error( array( 'msg' => 'Unknown check.' ) );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$v    = self::get();
		$meta = self::meta();
		$ap   = esc_url( admin_url( 'admin-post.php' ) );
		$set  = 0;
		foreach ( self::fields() as $k => $f ) {
			if ( ! empty( $v[ $k ] ) ) {
				$set++;
			}
		}
		$old = 0;
		foreach ( $meta['t'] as $t ) {
			$old = max( $old, (int) floor( ( time() - (int) $t ) / DAY_IN_SECONDS ) );
		}
		$groups = array(
			'captcha' => array( 'reCAPTCHA', 'Stops bots on the login and register forms.', array( 'captcha_site', 'captcha_secret' ), 'shield' ),
			'google'  => array( 'Google login', 'Lets members sign in with their Google account.', array( 'google_id', 'google_secret' ), 'user' ),
			'maps'    => array( 'Google Maps', 'City and location pictures.', array( 'maps_key' ), 'pin' ),
			'psi'     => array( 'Google PageSpeed', 'Speed and Core Web Vitals checks inside the plugin.', array( 'psi_key' ), 'bolt' ),
			'vision'  => array( 'Google Vision', 'Checks new profile photos against pictures found elsewhere on the web.', array( 'vision_key' ), 'eye' ),
			'translate' => array( 'Google Translate', 'Translates chat messages between members.', array( 'translate_key' ), 'globe' ),
		);
		$links = array(
			'captcha'   => array( 'Open reCAPTCHA admin', 'https://www.google.com/recaptcha/admin' ),
			'google'    => array( 'Open Google Cloud credentials', 'https://console.cloud.google.com/apis/credentials' ),
			'maps'      => array( 'Get a Maps key', 'https://console.cloud.google.com/google/maps-apis/credentials' ),
			'psi'       => array( 'Enable PageSpeed API, then create key', 'https://console.cloud.google.com/apis/library/pagespeedonline.googleapis.com' ),
			'vision'    => array( 'Enable Vision API, then create key', 'https://console.cloud.google.com/apis/library/vision.googleapis.com' ),
			'translate' => array( 'Enable Translation API, then create key', 'https://console.cloud.google.com/apis/library/translate.googleapis.com' ),
		);
		$hints = array(
			'captcha_site'   => 'Starts with 6L, 40 characters.',
			'captcha_secret' => 'Starts with 6L, 40 characters.',
			'google_id'      => 'Ends with .apps.googleusercontent.com',
			'google_secret'  => 'Starts with GOCSPX-',
			'maps_key'       => 'Starts with AIza, 39 characters.',
			'psi_key'        => 'Starts with AIza, 39 characters.',
			'vision_key'     => 'Starts with AIza, 39 characters.',
			'translate_key'  => 'Starts with AIza, 39 characters.',
		);
		echo '<style>.kz{max-width:1040px}.kz *{box-sizing:border-box}.kz-hero{background:linear-gradient(135deg,#0ea5e9,#6366f1);color:#fff;border-radius:16px;padding:20px 24px;margin:14px 0 16px}.kz-hero h1{color:#fff;margin:0;padding:0;font-size:24px}.kz-hero p{margin:4px 0 0;opacity:.9}.kz-g{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;margin:0 0 14px}.kz-t{background:#fff;border:1px solid #e4e7f1;border-radius:12px;padding:12px 14px}.kz-t b{display:block;font-size:24px;line-height:1.1;color:#4338ca}.kz-t span{font-size:12px;color:#646970}.kz-c{background:#fff;border:1px solid #e4e7f1;border-radius:16px;padding:18px 20px;margin:0 0 14px;box-shadow:0 1px 2px rgba(17,24,39,.04)}.kz-c h2{margin:0 0 2px;font-size:16px;padding:0;display:flex;align-items:center;gap:8px;flex-wrap:wrap}.kz-c .d{margin:0 0 12px;color:#646970}.kz-f{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:14px}.kz-fld label.l{display:block;font-weight:600;margin:0 0 4px}.kz-in{display:flex;gap:6px}.kz-in input[type=text],.kz-in input[type=password]{flex:1;min-width:0;border-radius:10px;padding:9px 12px}.kz-in button{border-radius:10px}.kz-fld small{display:block;color:#646970;margin:4px 0 0}.kz-fld .st{font-size:12px;margin-top:4px;display:block;min-height:16px}.kz-pill{display:inline-block;font-size:11px;font-weight:700;border-radius:99px;padding:2px 10px}.kz-pill.on{background:#eaf6f0;color:#0b5a3f}.kz-pill.off{background:#f1f2f4;color:#646970}.kz-pill.warn{background:#fff4e5;color:#9a5b00}.kz-bad{color:#b42318}.kz-ok{color:#0b5a3f}.kz-row{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:10px 0 0}.kz-res{font-size:13px}.kz-cp{display:flex;gap:10px;align-items:center;background:#fafbfd;border:1px solid #eceef6;border-radius:10px;padding:8px 10px;margin:0 0 8px}.kz-cp b{min-width:190px;font-size:13px}.kz-cp code{flex:1;min-width:0;overflow-wrap:anywhere;background:none;padding:0}.kz-save{position:sticky;bottom:0;z-index:5;display:flex;gap:10px;align-items:center;flex-wrap:wrap;background:rgba(255,255,255,.96);border:1px solid #dcdcde;border-radius:12px;padding:12px 16px;margin:0 0 14px;box-shadow:0 -4px 14px rgba(0,0,0,.06)}.kz-save span{flex:1;color:#646970}.kz-tb{width:100%;border-collapse:collapse}.kz-tb td,.kz-tb th{text-align:left;padding:7px 8px;border-top:1px solid #f0f0f1;font-size:13px}</style>';
		echo '<div class="wrap kz"><div class="kz-hero"><h1>Website keys</h1><p>reCAPTCHA, Google login, Maps, PageSpeed, Vision and Translate keys, with links to the Google tools, in one safe place. Keys are never shown in full.</p></div>';
		if ( ! empty( $_GET['saved'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="notice notice-success is-dismissible"><p>Saved. If your site uses a cache, clear it so visitors get the new keys.</p></div>';
		}
		if ( ! empty( $_GET['odd'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="notice notice-warning is-dismissible"><p>Saved, but this does not look like the usual shape for: <b>' . esc_html( sanitize_text_field( rawurldecode( wp_unslash( $_GET['odd'] ) ) ) ) . '</b>. Check you copied the whole key. Use the Test buttons below.</p></div>'; // phpcs:ignore WordPress.Security.NonceVerification
		}
		$when = $old ? ( $old . ' days' ) : 'not tracked yet';
		echo '<div class="kz-g"><div class="kz-t"><b>' . (int) $set . ' of ' . count( self::fields() ) . '</b><span>Keys saved</span></div><div class="kz-t"><b>' . esc_html( $when ) . '</b><span>Oldest key you changed here</span></div><div class="kz-t"><b>' . ( $old > 180 ? 'Rotate' : 'OK' ) . '</b><span>' . ( $old > 180 ? 'A key is older than 6 months' : 'Rotation status' ) . '</span></div></div>';
		echo '<form method="post" action="' . $ap . '" id="kz-form"><input type="hidden" name="action" value="mrsh_keys_save">';
		wp_nonce_field( 'mrsh_keys_save' );
		foreach ( $groups as $gk => $g ) {
			$all = true;
			foreach ( $g[2] as $k ) {
				$all = $all && ! empty( $v[ $k ] );
			}
			echo '<div class="kz-c"><h2>' . esc_html( $g[0] ) . ' <span class="kz-pill ' . ( $all ? 'on' : 'off' ) . '">' . ( $all ? 'ready' : 'needs a key' ) . '</span></h2><p class="d">' . esc_html( $g[1] ) . '</p><div class="kz-f">';
			foreach ( $g[2] as $k ) {
				$f   = self::fields()[ $k ];
				$ts  = (int) ( $meta['t'][ $k ] ?? 0 );
				$age = $ts ? human_time_diff( $ts ) . ' ago' : ( ! empty( $v[ $k ] ) ? 'age unknown' : '' );
				echo '<div class="kz-fld"><label class="l" for="k_' . esc_attr( $k ) . '">' . esc_html( $f[0] ) . '</label><div class="kz-in"><input type="' . ( $f[1] ? 'password' : 'text' ) . '" id="k_' . esc_attr( $k ) . '" name="k[' . esc_attr( $k ) . ']" data-k="' . esc_attr( $k ) . '" autocomplete="off" spellcheck="false" placeholder="' . esc_attr( self::mask( $v[ $k ] ?? '' ) ) . '">';
				if ( $f[1] ) {
					echo '<button type="button" class="button kz-eye" data-t="#k_' . esc_attr( $k ) . '" title="Show or hide what you are typing">Show</button>';
				}
				echo '</div><span class="st" data-st="' . esc_attr( $k ) . '"></span><small>' . esc_html( $f[2] ) . ' ' . esc_html( $hints[ $k ] ) . ( $age ? ' Last changed: ' . esc_html( $age ) . '.' : '' ) . '</small><label style="display:block;margin-top:4px"><input type="checkbox" name="clear[' . esc_attr( $k ) . ']" value="1"> remove this key</label></div>';
			}
			echo '</div><div class="kz-row">';
			if ( 'captcha' === $gk ) {
				echo '<button type="button" class="button" data-test="captcha">Test secret key</button><button type="button" class="button" data-test="captcha_live">Check it is on the login page</button>';
				if ( class_exists( 'MRSH_Captcha' ) ) {
					$sw  = MRSH_Captcha::switch_on();
					$act = MRSH_Captcha::on();
					echo '<button type="submit" class="button ' . ( $sw ? '' : 'button-primary' ) . '" formnovalidate formaction="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_cap_toggle' ), 'mrsh_cap_toggle' ) ) . '" style="font-weight:700">' . ( $sw ? 'Switch robot check OFF (bypass)' : 'Switch robot check ON' ) . '</button>';
					echo '<span class="kz-pill ' . ( $act ? 'on' : 'off' ) . '" style="margin-left:8px">' . ( $act ? 'Robot check is ON' : 'Robot check is OFF' . ( ! $sw ? ' (by your switch)' : ' (keys look wrong)' ) ) . '</span>';
					if ( isset( $_GET['cap'] ) ) { // phpcs:ignore
						echo '<span style="margin-left:8px;font-weight:700">' . ( 'off' === $_GET['cap'] ? 'Switched OFF. Login works without the box.' : 'Switched ON.' ) . '</span>'; // phpcs:ignore
					}
				}
			} elseif ( 'google' === $gk ) {
				echo '<button type="button" class="button" data-test="google">Test Client ID with Google</button>';
			} elseif ( 'maps' === $gk ) {
				echo '<button type="button" class="button" id="kz-maps">Test in this browser</button>';
			}
			if ( isset( $links[ $gk ] ) ) {
				echo '<a class="button" href="' . esc_url( $links[ $gk ][1] ) . '" target="_blank" rel="noopener">' . esc_html( $links[ $gk ][0] ) . ' &#8599;</a>';
			}
			echo '<span class="kz-res" data-res="' . esc_attr( $gk ) . '"></span></div></div>';
		}
		echo '<div class="kz-save"><span>Leave a box empty to keep the saved key.</span><button class="button button-primary button-large">Save keys</button></div></form>';
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		$cbk  = class_exists( 'MRSH_Mem_Social' ) ? MRSH_Mem_Social::cb( 'google' ) : home_url( '/?mrsh_social=google_cb' );
		$copy = array(
			'Google login: authorised JavaScript origin' => untrailingslashit( home_url() ),
			'Google login: authorised redirect URI'      => $cbk,
			'Maps key: website restriction (1)'          => 'https://' . $host . '/*',
			'Maps key: website restriction (2)'          => 'https://*.' . preg_replace( '/^www\./', '', $host ) . '/*',
			'reCAPTCHA: domain'                          => preg_replace( '/^www\./', '', $host ),
		);
		echo '<div class="kz-c"><h2>Values to paste into Google</h2><p class="d">Copy these into Google Cloud and the reCAPTCHA admin when you create or fix a key.</p>';
		foreach ( $copy as $l => $val ) {
			echo '<div class="kz-cp"><b>' . esc_html( $l ) . '</b><code>' . esc_html( $val ) . '</code><button type="button" class="button kz-copy">Copy</button></div>';
		}
		echo '</div>';
		$useful = array(
			'Search and growth' => array(
				array( 'Search Console', 'https://search.google.com/search-console', 'Indexing, clicks, errors, sitemaps.' ),
				array( 'Google Analytics', 'https://analytics.google.com/', 'Visitors and where they come from.' ),
				array( 'Google Trends', 'https://trends.google.com/', 'What people search for in Pakistan.' ),
				array( 'Looker Studio', 'https://lookerstudio.google.com/', 'Free reports from Search Console and Analytics.' ),
				array( 'Tag Manager', 'https://tagmanager.google.com/', 'Add tracking tags without code.' ),
			),
			'Check your pages'  => array(
				array( 'PageSpeed Insights', 'https://pagespeed.web.dev/', 'Speed and Core Web Vitals.' ),
				array( 'Rich Results Test', 'https://search.google.com/test/rich-results', 'Checks structured data.' ),
				array( 'Safe Browsing status', 'https://transparencyreport.google.com/safe-browsing/search', 'Shows if Google flags the site as unsafe.' ),
			),
			'Business and ads'  => array(
				array( 'Business Profile', 'https://business.google.com/', 'Your Lahore office on Google Maps.' ),
				array( 'Google Ads', 'https://ads.google.com/', 'Campaigns and billing.' ),
				array( 'AdSense', 'https://www.google.com/adsense/', 'Site ads application.' ),
			),
			'Keys and AI'       => array(
				array( 'Cloud API library', 'https://console.cloud.google.com/apis/library', 'Switch on any Google API.' ),
				array( 'Cloud credentials', 'https://console.cloud.google.com/apis/credentials', 'Create, restrict and delete keys.' ),
				array( 'Gemini API key (free tier)', 'https://aistudio.google.com/apikey', 'For the free AI pool.' ),
			),
		);
		echo '<div class="kz-c"><h2>Useful Google links</h2><p class="d">One tap to the Google tools this site depends on. They open in a new tab.</p><div class="kz-f">';
		foreach ( $useful as $gt => $ls ) {
			echo '<div><b>' . esc_html( $gt ) . '</b><ul style="margin:6px 0 0;padding-left:0;list-style:none">';
			foreach ( $ls as $l ) {
				echo '<li style="margin:0 0 8px"><a href="' . esc_url( $l[1] ) . '" target="_blank" rel="noopener"><b>' . esc_html( $l[0] ) . '</b> &#8599;</a><br><span style="color:#646970;font-size:12.5px">' . esc_html( $l[2] ) . '</span></li>';
			}
			echo '</ul></div>';
		}
		echo '</div></div>';
		echo '<div class="kz-c"><h2>Change history</h2><p class="d">Who changed which key and when. Key values are never stored here.</p>';
		$log = array_reverse( $meta['log'] );
		if ( ! $log ) {
			echo '<p>No changes recorded yet. The next save starts the history.</p>';
		} else {
			echo '<table class="kz-tb"><tr><th>When</th><th>Who</th><th>Key</th><th>What</th></tr>';
			foreach ( array_slice( $log, 0, 15 ) as $l ) {
				$u  = get_userdata( (int) $l[1] );
				$fl = self::fields()[ $l[2] ][0] ?? $l[2];
				echo '<tr><td>' . esc_html( wp_date( 'j M Y, g:i a', (int) $l[0] ) ) . '</td><td>' . esc_html( $u ? $u->user_login : 'unknown' ) . '</td><td>' . esc_html( $fl ) . '</td><td>' . esc_html( $l[3] ) . '</td></tr>';
			}
			echo '</table>';
		}
		echo '</div>';
		echo '<div class="kz-c"><h2>Safe key habits</h2><ol><li>Never paste a secret key into a chat, email or screenshot. If you did, make a new one and replace it here.</li><li>Rotate keys about every six months.</li><li>Restrict every key to your website address in Google Cloud.</li><li>After changing a key: save, test, open the login page, then delete the old key in Google.</li></ol></div>';
		echo '<script>window.MRSH_KZ=' . wp_json_encode( array( 'ajax' => admin_url( 'admin-ajax.php' ), 'n' => wp_create_nonce( 'mrsh_keys_test' ), 'maps' => (string) ( $v['maps_key'] ?? '' ) ) ) . ';</script>';
		echo '<script>';
		echo <<<'JS'
(function(){
var K=window.MRSH_KZ||{},F={captcha_site:/^6L[A-Za-z0-9_\-]{38}$/,captcha_secret:/^6L[A-Za-z0-9_\-]{38}$/,google_id:/^[0-9]+-[A-Za-z0-9_]+\.apps\.googleusercontent\.com$/,google_secret:/^GOCSPX-[A-Za-z0-9_\-]{20,}$/,maps_key:/^AIza[A-Za-z0-9_\-]{35}$/,psi_key:/^AIza[A-Za-z0-9_\-]{35}$/,vision_key:/^AIza[A-Za-z0-9_\-]{35}$/,translate_key:/^AIza[A-Za-z0-9_\-]{35}$/};
function q(s,r){return(r||document).querySelector(s)}function qa(s,r){return[].slice.call((r||document).querySelectorAll(s))}
qa('input[data-k]').forEach(function(i){var st=q('[data-st="'+i.dataset.k+'"]');i.addEventListener('input',function(){var v=i.value.trim();if(!v){st.textContent='';return}var ok=F[i.dataset.k].test(v);st.className='st '+(ok?'kz-ok':'kz-bad');st.textContent=ok?'Looks right.':'This does not look like the usual shape. Check you copied all of it.'})});
qa('.kz-eye').forEach(function(b){b.onclick=function(){var i=q(b.dataset.t);i.type=i.type==='password'?'text':'password';b.textContent=i.type==='password'?'Show':'Hide'}});
function cp(t,b){var d=function(){var o=b.textContent;b.textContent='Copied';setTimeout(function(){b.textContent=o},1400)};if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t).then(d,d)}else{var a=document.createElement('textarea');a.value=t;document.body.appendChild(a);a.select();try{document.execCommand('copy')}catch(e){}a.remove();d()}}
qa('.kz-copy').forEach(function(b){b.onclick=function(){cp(b.parentNode.querySelector('code').textContent,b)}});
function show(g,ok,msg){var r=q('[data-res="'+g+'"]');r.className='kz-res '+(ok?'kz-ok':'kz-bad');r.textContent=(ok?'\u2713 ':'\u2717 ')+msg}
qa('[data-test]').forEach(function(b){b.onclick=function(){var w=b.dataset.test,g=w.indexOf('captcha')===0?'captcha':'google';b.disabled=true;var f=new FormData();f.append('action','mrsh_keys_test');f.append('n',K.n);f.append('what',w);
 fetch(K.ajax,{method:'POST',body:f,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(r){b.disabled=false;if(r&&r.success)show(g,r.data.ok,r.data.msg);else show(g,false,(r&&r.data&&r.data.msg)||'The check failed.')}).catch(function(){b.disabled=false;show(g,false,'The check could not run.')})}});
var mb=q('#kz-maps');if(mb)mb.onclick=function(){if(!K.maps){show('maps',false,'No Maps key is saved yet.');return}mb.disabled=true;var done=false;window.gm_authFailure=function(){done=true;mb.disabled=false;show('maps',false,'Google refused the key. Check the website restriction and that Maps JavaScript API is enabled.')};
 window.__kzmap=function(){if(done)return;done=true;mb.disabled=false;show('maps',true,'The key loaded Google Maps in this browser.')};var s=document.createElement('script');s.src='https://maps.googleapis.com/maps/api/js?key='+encodeURIComponent(K.maps)+'&callback=__kzmap';s.onerror=function(){done=true;mb.disabled=false;show('maps',false,'Google Maps could not be loaded.')};document.head.appendChild(s);setTimeout(function(){if(!done){mb.disabled=false;show('maps',false,'No answer from Google. Try again.')}},9000)};
})();
JS;
		echo '</script></div>';
	}
}
MRSH_Keys::init();
