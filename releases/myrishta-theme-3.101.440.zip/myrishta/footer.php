<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$name  = mrt_site( 'brand', mrt_opt( 'design', 'textlogo', get_bloginfo( 'name' ) ) );
$about = mrt_site( 'about', mrt_opt( 'newfooter', 'desc', get_bloginfo( 'description' ) ) );
$soc   = array( 'fb' => 'Facebook', 'ig' => 'Instagram', 'yt' => 'YouTube', 'tt' => 'TikTok', 'x' => 'X' );
$wa    = preg_replace( '/\D/', '', (string) mrt_site( 'whatsapp' ) );
?>
<footer class="site-foot"><div class="wrap">
	<div class="cols">
		<div><strong><?php echo esc_html( $name ); ?></strong><p><?php echo esc_html( $about ); ?></p>
		<div class="soc"><?php foreach ( $soc as $k => $l ) { if ( mrt_site( $k ) ) { echo '<a href="' . esc_url( mrt_site( $k ) ) . '" target="_blank" rel="noopener">' . esc_html( $l ) . '</a>'; } } ?></div></div>
		<ul>
			<li><b>Information</b></li>
			<li><a href="<?php echo esc_url( mrt_link( 'aboutus', '/about-us/' ) ); ?>">About us</a></li>
			<li><a href="<?php echo esc_url( mrt_link( 'how', '/how-it-works/' ) ); ?>">How it works</a></li>
			<?php if ( get_page_by_path( 'video-guides' ) ) : ?><li><a href="<?php echo esc_url( home_url( '/video-guides/' ) ); ?>">Video guides</a></li><?php endif; ?>
			<?php if ( get_page_by_path( 'our-work' ) ) : ?><li><a href="<?php echo esc_url( home_url( '/our-work/' ) ); ?>">Our work</a></li><?php endif; ?>
			<li><a href="<?php echo esc_url( mrt_link( 'faq', '/faq/' ) ); ?>">FAQ</a></li>
			<li><a href="<?php echo esc_url( mrt_link( 'contact', '/contact/' ) ); ?>">Contact</a></li>
			<li><a href="<?php echo esc_url( home_url( '/blog/' ) ); ?>">Blog</a></li>
		</ul>
		<ul>
			<li><b>Trust and legal</b></li>
			<li><a href="<?php echo esc_url( mrt_link( 'terms', '/terms/' ) ); ?>">Terms</a></li>
			<li><a href="<?php echo esc_url( mrt_link( 'privacy', '/privacy/' ) ); ?>">Privacy</a></li>
			<li><a href="<?php echo esc_url( home_url( '/rishta-safety-tips-avoid-fake-profiles-scams/' ) ); ?>">Safety tips</a></li>
			<li><a href="<?php echo esc_url( home_url( '/cookie-policy/' ) ); ?>">Cookies</a></li>
			<li><a href="<?php echo esc_url( home_url( '/disclaimer/' ) ); ?>">Disclaimer</a></li>
			<li><a href="<?php echo esc_url( home_url( '/badges/' ) ); ?>">Badges</a></li>
			<li><a href="<?php echo esc_url( home_url( '/report-profile-misuse/' ) ); ?>">Report misuse</a></li>
			<li><a href="<?php echo esc_url( home_url( '/sitemap_index.xml' ) ); ?>">Sitemap</a></li>
		</ul>
		<ul>
			<li><b>Contact</b></li>
			<?php $gn_ = (array) get_option( 'mrsh_gbp', array() ); $gn_ = trim( (string) ( $gn_['name'] ?? '' ) ); if ( '' !== $gn_ && 0 !== strcasecmp( $gn_, get_bloginfo( 'name' ) ) ) : ?><li><?php echo esc_html( $gn_ ); ?></li><?php endif; ?>
			<?php if ( mrt_site( 'phone' ) ) : ?><li><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', mrt_site( 'phone' ) ) ); ?>"><?php echo esc_html( mrt_site( 'phone' ) ); ?></a></li><?php endif; ?>
			<?php if ( $wa ) : ?><li><a href="https://wa.me/<?php echo esc_attr( $wa ); ?>" rel="noopener">WhatsApp</a></li><?php endif; ?>
			<?php if ( mrt_site( 'email' ) ) : ?><li><a href="mailto:<?php echo esc_attr( mrt_site( 'email' ) ); ?>"><?php echo esc_html( mrt_site( 'email' ) ); ?></a></li><?php endif; ?>
			<?php if ( mrt_site( 'address' ) ) : ?><li><?php echo esc_html( mrt_site( 'address' ) ); ?></li><?php endif; ?>
			<?php
			$g_ = (array) get_option( 'mrsh_gbp', array() );
			if ( ! mrt_site( 'phone' ) && ! empty( $g_['phone'] ) ) : ?><li><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $g_['phone'] ) ); ?>"><?php echo esc_html( $g_['phone'] ); ?></a></li><?php endif; ?>
			<?php if ( ! mrt_site( 'email' ) && ! empty( $g_['email'] ) ) : ?><li><a href="mailto:<?php echo esc_attr( $g_['email'] ); ?>"><?php echo esc_html( $g_['email'] ); ?></a></li><?php endif; ?>
			<?php if ( ! mrt_site( 'phone' ) && ! mrt_site( 'email' ) && empty( $g_['phone'] ) && empty( $g_['email'] ) && ! $wa ) : ?><li><a href="<?php echo esc_url( mrt_link( 'contact', '/contact/' ) ); ?>">Send us a message</a></li><?php endif; ?>
		</ul>
	</div>
	<form class="newsl" id="newsl" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<b>Rishta tips by email</b><input type="hidden" name="action" value="mrt_news"><?php wp_nonce_field( 'mrt_news' ); ?>
		<span style="position:absolute;left:-9999px" aria-hidden="true"><input name="website" tabindex="-1" autocomplete="off"></span>
		<input type="email" name="email" required placeholder="Your email" autocomplete="email"><button class="btn sm"><?php echo mrt_icon( 'mail' ); // phpcs:ignore ?>Join</button>
		<?php if ( isset( $_GET['news'] ) ) { echo '<small>' . ( '1' === $_GET['news'] ? 'Thank you, you are on the list.' : 'Please check your email address.' ) . '</small>'; } // phpcs:ignore ?>
		<small>By joining you accept our <a href="<?php echo esc_url( mrt_link( 'privacy', '/privacy/' ) ); ?>">Privacy Policy</a>.</small>
	</form>
	<?php if ( mrt_site( 'footer_note' ) ) : ?><p class="fnote"><?php echo esc_html( mrt_site( 'footer_note' ) ); ?></p><?php endif; ?>
	<p>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ); ?></p>
<p class="litebar"><button type="button" id="mrt-litebtn" class="litebtn">Slow internet? Turn on Lite mode</button></p></div></footer>
<nav class="mbar" aria-label="Mobile">
	<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo mrt_icon( 'home' ); // phpcs:ignore ?>Home</a>
	<a href="<?php echo esc_url( home_url( '/?post_type=listing_type&s=' ) ); ?>"><?php echo mrt_icon( 'search' ); // phpcs:ignore ?>Search</a>
	<?php $cta = mrt_cta(); ?><a href="<?php echo esc_url( $cta[1] ); ?>"><?php echo mrt_icon( $cta[2] ); // phpcs:ignore ?><?php echo 'Add profile' === $cta[0] ? 'Add' : 'Update'; ?></a>
	<a href="<?php echo esc_url( mrt_login_url() ); ?>"><?php echo mrt_icon( 'user' ); // phpcs:ignore ?><?php echo is_user_logged_in() ? 'Account' : 'Login'; ?><?php echo mrt_unread() ? '<span class="nb">' . (int) mrt_unread() . '</span>' : ''; // phpcs:ignore ?></a>
	<a href="<?php echo esc_url( add_query_arg( 'tab', 'matches', mrt_login_url() ) ); ?>"><?php echo mrt_icon( 'heart' ); // phpcs:ignore ?>Matches</a>
</nav>
<?php if ( is_user_logged_in() && mrt_unread() ) : ?>
<div class="npop" id="npop" hidden><b>New message</b><span>You have <?php echo (int) mrt_unread(); ?> unread.</span><a class="btn sm" href="<?php echo esc_url( add_query_arg( 'tab', 'messages', mrt_login_url() ) ); ?>">Read</a><button type="button" class="btn sm line" id="npx">Close</button></div>
<script>(function(){try{var p=document.getElementById('npop');if(!p||sessionStorage.getItem('mrtnp'))return;(window.mrtLate||function(k,f){setTimeout(f,8000)})('np',function(){p.hidden=false});document.getElementById('npx').onclick=function(){p.hidden=true;sessionStorage.setItem('mrtnp',1)}}catch(e){}})();</script>
<?php endif; ?>
<?php wp_footer(); ?>
</body>
</html>
