<?php
/* Template Name: Add or edit profile */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
get_header();
if ( ! class_exists( 'MRSH_Members' ) ) {
	echo '<main><div class="wrap narrow"><div class="note">This page needs the My Rishta plugin to be active.</div></div></main>';
	get_footer();
	return;
}
if ( file_exists( __DIR__ . '/inc-bilingual.php' ) ) {
	require_once __DIR__ . '/inc-bilingual.php';
}
ob_start(); // English plus Urdu is added to the finished page
echo '<main><div class="wrap' . ( is_user_logged_in() ? ' narrow' : '' ) . '">';
if ( ! is_user_logged_in() ) {
	$msg   = get_transient( 'mrt_su_' . md5( mrt_ip() ) ); // phpcs:ignore
	$plans = mrt_plans();
	echo '<div class="su"><div class="su-main">';
	echo '<div class="fhero"><h1>Create your free profile</h1><p>Join in three easy steps. Free, private and run by a non-profit.</p><ol class="steps3"><li class="on"><i>1</i>Account</li><li><i>2</i>Details</li><li><i>3</i>Photos</li></ol></div>';
	echo '<div class="box su-card">';
	if ( class_exists( 'MRSH_Mem_Social' ) && ( ! class_exists( 'MRSH_Switch' ) || MRSH_Switch::on( 'social' ) ) ) {
		echo '<div class="su-g">' . MRSH_Mem_Social::buttons_html( '' ) . '</div><div class="su-or"><span>or sign up with email</span></div>'; // phpcs:ignore
	}
	echo '<form id="mrt-su" class="frm" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	if ( $msg || ! empty( $_GET['su'] ) ) { // phpcs:ignore
		echo '<div class="err">' . esc_html( $msg ? $msg : 'Please check the form.' ) . '</div>';
	}
	echo '<input type="hidden" name="action" value="mrt_signup"><input type="hidden" name="t" value="' . (int) time() . '"><input type="hidden" name="plan" id="mrt-plan" value="' . esc_attr( $plans[0][0] ) . '">';
	wp_nonce_field( 'mrt_signup' );
	echo '<div style="position:absolute;left:-9999px" aria-hidden="true"><input name="website" tabindex="-1" autocomplete="off"></div>';
	echo '<div class="g2"><div><label>Your name</label><input name="name" required autocomplete="name" placeholder="Full name"></div><div><label>Email</label><input type="email" name="email" required autocomplete="email" placeholder="you@example.com"></div></div>';
	echo '<div class="g2"><div><label>Mobile number <small class="ml">(optional, lets you log in with it)</small></label><input type="tel" name="mobile" inputmode="tel" autocomplete="tel" placeholder="0300 1234567"></div><div><label>Password <small class="ml">(6 or more characters)</small></label><input type="password" name="pass" minlength="6" required autocomplete="new-password"></div></div>';
	if ( count( $plans ) > 1 ) {
		echo '<label>Membership</label><div class="su-plans">';
		foreach ( $plans as $i => $pl ) {
			echo '<label class="su-plan"' . ( ! empty( $pl[3] ) ? ' style="--pc:' . esc_attr( $pl[3] ) . '"' : '' ) . '><input type="radio" name="plan_pick" value="' . esc_attr( $pl[0] ) . '"' . ( 0 === $i ? ' checked' : '' ) . '><span><b>' . esc_html( $pl[0] ) . '</b>' . ( strcasecmp( trim( $pl[0] ), trim( $pl[1] ) ) ? '<em>' . esc_html( $pl[1] ) . '</em>' : '<em>Free</em>' ) . '</span></label>';
		}
		echo '</div><div class="su-feats">';
		foreach ( $plans as $i => $pl ) {
			echo '<ul data-plan="' . esc_attr( $pl[0] ) . '"' . ( 0 === $i ? '' : ' hidden' ) . '>';
			foreach ( $pl[2] as $ft ) {
				echo '<li>' . esc_html( $ft ) . '</li>';
			}
			echo '</ul>';
		}
		echo '</div>';
	}
	echo '<p class="su-terms"><label><input type="checkbox" style="width:auto" name="terms" value="1" required> I agree to the <a href="' . esc_url( home_url( '/terms/' ) ) . '">terms</a> and privacy policy.</label></p><button class="btn lg su-go">Create account and continue</button>';
	echo '<p class="ml su-log">Already a member? <a href="' . esc_url( wp_login_url( get_permalink() ) ) . '">Log in</a></p></form></div></div>';
	echo '<aside class="su-side"><div class="box"><h3>Why families join</h3><ul class="su-why"><li><b>Free and private</b><span>Run by a non-profit. Your phone number is never shown.</span></li><li><b>Family first</b><span>Add a guardian, and meet only in safe public places.</span></li><li><b>Verified profiles</b><span>Selfie and email checks help keep fake profiles out.</span></li><li><b>Three easy steps</b><span>Account, details, photos. It takes about 3 minutes.</span></li></ul></div></aside></div>';
	echo '<script>document.querySelectorAll("input[name=plan_pick]").forEach(function(r){r.addEventListener("change",function(){document.getElementById("mrt-plan").value=r.value;document.querySelectorAll(".su-feats ul").forEach(function(u){u.hidden=u.getAttribute("data-plan")!==r.value})})})</script>';
	echo '</div></main>';
	echo function_exists( 'mrt_bilingual' ) ? mrt_bilingual( (string) ob_get_clean() ) : ob_get_clean(); // phpcs:ignore
	get_footer();
	return;
}
$uid  = get_current_user_id();
$edit = isset( $_GET['edit'] ) ? absint( $_GET['edit'] ) : 0; // phpcs:ignore
$mine = MRSH_Members::my_profile( $uid );
$post = $edit ? get_post( $edit ) : null;
if ( $post && ( 'listing_type' !== $post->post_type || ( (int) $post->post_author !== $uid && ! current_user_can( 'manage_options' ) ) ) ) {
	$post = null;
	$edit = 0;
}
if ( ! $post && $mine ) {
	$post = $mine;
	$edit = $mine->ID;
}
$old = get_transient( 'mrt_form_' . $uid );
$old = ( $old && ! empty( $_GET['bad'] ) ) ? $old : array(); // phpcs:ignore
echo '<div class="fhero"><h1>' . ( $edit ? 'Update your profile' : 'Create your free profile' ) . '</h1><p>' . ( $edit ? 'Keep it fresh. Complete profiles get many more replies.' : 'Almost there. Tell us about yourself.' ) . '</p><ol class="steps3"><li class="done"><i>&#10003;</i>Account</li><li class="on"><i>2</i>Details</li><li><i>3</i>Photos</li></ol><div class="meter"><i id="mrt-fm" style="width:0"></i></div><small id="mrt-fmt" class="ml"></small></div>';
if ( ! empty( $_GET['e'] ) ) { // phpcs:ignore
	echo '<div class="err">' . esc_html( sanitize_text_field( wp_unslash( $_GET['e'] ) ) ) . '</div>'; // phpcs:ignore
}
if ( ! empty( $old['err'] ) ) {
	echo '<div class="err"><b>Please fix:</b><br>' . implode( '<br>', array_map( 'esc_html', $old['err'] ) ) . '</div>';
}
$g = function ( $key, $dflt = '' ) use ( $old, $post ) {
	if ( isset( $old['f'][ $key ] ) ) {
		return $old['f'][ $key ];
	}
	return $post ? (string) get_post_meta( $post->ID, $key, true ) : $dflt;
};
echo '<form class="frm pf" method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrt_save_profile"><input type="hidden" name="pid" value="' . (int) $edit . '">';
wp_nonce_field( 'mrt_save_profile' );
echo '<label>First name (shown on your profile)</label><input name="title" maxlength="60" required value="' . esc_attr( $old['title'] ?? ( $post ? $post->post_title : '' ) ) . '">';
$fields = MRSH_Members::form_fields();
$secs = array(
	'basic'  => array( 'About you', 'user', '/gender|age|marital|height|weight|complexion|build|mother tongue|language|created|profile for|looking/i' ),
	'faith'  => array( 'Religion and family', 'heart', '/religion|sect|caste|family|father|mother|sibling|brother|sister|own house|home/i' ),
	'work'   => array( 'Education and work', 'book', '/educat|occupation|profession|job|income|salary|degree|employ/i' ),
	'where'  => array( 'Where you live', 'search', '/\\b(country|city|town|state|province|area|address|location)\\b|national|residen/i' ),
	'priv'   => array( 'Contact (never shown to others)', 'shield', '/phone|mobile|contact|whatsapp/i' ),
	'more'   => array( 'More details', 'star', '/./' ),
);
$groups = array_fill_keys( array_keys( $secs ), array() );
foreach ( $fields as $f ) {
	foreach ( array( 'priv', 'where', 'work', 'faith', 'basic', 'more' ) as $sk ) {
		if ( 'priv' === $sk ? $f['priv'] : preg_match( $secs[ $sk ][2], $f['label'] . ' ' . $f['key'] ) ) {
			$groups[ $sk ][] = $f;
			continue 2;
		}
	}
}
foreach ( $secs as $sk => $sd ) {
	if ( ! $groups[ $sk ] && ! ( 'where' === $sk && taxonomy_exists( 'country' ) ) ) {
		continue;
	}
	echo '<section class="fsec"><h2><span class="ib">' . mrt_icon( $sd[1] ) . '</span>' . esc_html( $sd[0] ) . '</h2>'; // phpcs:ignore
	if ( 'where' === $sk ) {
		echo '<p class="locbar"><button type="button" class="btn line" id="mrt-loc">' . mrt_icon( 'search' ) . 'Detect my country and city</button> <span class="ml" id="mrt-locmsg">We only fill the fields. Check them before saving.</span></p>'; // phpcs:ignore
	}
	echo '<div class="g2">';
	if ( 'where' === $sk && taxonomy_exists( 'country' ) ) {
		$lc  = MRSH_Members::loc_of( $post ? $post->ID : 0 );
		$lc0 = isset( $old['loc_country'] ) ? $old['loc_country'] : $lc[0];
		$lc1 = isset( $old['loc_city'] ) ? $old['loc_city'] : $lc[1];
		$top = get_terms( array( 'taxonomy' => 'country', 'parent' => 0, 'hide_empty' => false, 'orderby' => 'name', 'number' => 300 ) );
		$top = is_wp_error( $top ) ? array() : $top;
		usort( $top, function ( $a, $b ) {
			return ( 'Pakistan' === $b->name ) - ( 'Pakistan' === $a->name );
		} );
		echo '<div data-loc="country"><label>Country <small>(required)</small></label><select name="loc_country" id="loc-country" required><option value="">Select country</option>';
		$seen = false;
		foreach ( $top as $t ) {
			$seen = $seen || $t->name === $lc0;
			echo '<option' . selected( $lc0, $t->name, false ) . '>' . esc_html( $t->name ) . '</option>';
		}
		if ( $lc0 && ! $seen ) {
			echo '<option selected>' . esc_html( $lc0 ) . '</option>';
		}
		echo '</select></div><div data-loc="city"><label>City / Town / Village <small>(required)</small></label><input name="loc_city" id="loc-city" required list="mrt-cities" autocomplete="off" maxlength="40" placeholder="Choose from the list or type your city or village" value="' . esc_attr( $lc1 ) . '"><datalist id="mrt-cities"></datalist></div>';
	}
	foreach ( $groups[ $sk ] as $f ) {
		if ( taxonomy_exists( 'country' ) && preg_match( '/^\\s*(country|city)\\s*$/i', $f['label'] ) ) {
			continue;
		}
		$val = $g( $f['key'] );
		if ( '' === $val && $post && ! $f['priv'] ) {
			$val = MRSH_Match::val( $post->ID, MRSH_Members::tax_for( $f['label'] ), $f['key'] );
		}
		if ( $f['priv'] && ! preg_match( '/^[0-9+\-\s]{6,20}$/', trim( (string) $val ) ) ) {
			$val = ''; // never show a non-phone value (old data) in a phone box
		}
		if ( '' === $val && $f['priv'] && ! $edit && is_user_logged_in() ) { // the number they signed up with
			$mm = (string) get_user_meta( get_current_user_id(), 'mrt_mobile', true );
				$mm = (string) apply_filters( 'mrt_prefill_phone', $mm, get_current_user_id() );
			if ( preg_match( '/^[0-9+\-\s]{6,20}$/', trim( $mm ) ) ) {
				$val = trim( $mm );
			}
		}
		$nm = 'f[' . esc_attr( $f['key'] ) . ']';
		$lk = preg_match( '/country/i', $f['label'] ) ? 'country' : ( preg_match( '/\b(city|town)\b/i', $f['label'] ) ? 'city' : ( preg_match( '/state|province/i', $f['label'] ) ? 'state' : '' ) );
		echo '<div' . ( $lk ? ' data-loc="' . $lk . '"' : '' ) . '><label>' . esc_html( $f['label'] ) . ( $f['req'] ? ' *' : '' ) . '</label>';
		if ( MRSH_Members::is_caste( $f ) ) {
			echo '<input name="' . $nm . '" list="mrt-castes" maxlength="40" autocomplete="off" placeholder="Choose from the list or type your caste" value="' . esc_attr( $val ) . '"' . ( $f['req'] ? ' required' : '' ) . '><datalist id="mrt-castes">'; // phpcs:ignore
			foreach ( $f['opts'] as $o ) {
				echo '<option value="' . esc_attr( $o ) . '">';
			}
			echo '</datalist>';
			if ( $f['opts'] ) { // a real drop-down on every device; "Other" opens the box to type a new caste
				echo '<select class="mrt-cpick" aria-label="Caste"' . ( $f['req'] ? ' required' : '' ) . '><option value="">Select</option>';
				$hit = false;
				foreach ( $f['opts'] as $o ) {
					$is = ( '' !== $val && 0 === strcasecmp( $val, $o ) );
					$hit = $hit || $is;
					echo '<option' . ( $is ? ' selected' : '' ) . '>' . esc_html( $o ) . '</option>';
				}
				echo '<option value="__other"' . ( '' !== $val && ! $hit ? ' selected' : '' ) . '>Other (type it)</option></select>';
				echo '<script>(function(){var w=document.currentScript.parentNode,R=false,s=w.querySelector(".mrt-cpick"),i=w.querySelector("input[list]");if(!s||!i)return;R=i.required;i.required=false;function sync(){if(s.value==="__other"){i.required=R;i.style.display="";i.value=i.dataset.o||"";i.focus()}else{i.required=false;i.dataset.o="";i.style.display="none";i.value=s.value}}s.addEventListener("change",sync);if(s.value!=="__other"){i.style.display="none";if(s.value)i.value=s.value}else{i.required=R}})();</script>';
			}
			echo '<small class="ml">Not in the list? Choose Other and type it. It will be added for others too.</small>';
		} elseif ( $f['opts'] && ! $f['priv'] ) {
			echo '<select name="' . $nm . '"' . ( $f['req'] && ! ( $edit && $f['priv'] ) ? ' required' : '' ) . '><option value="">Select</option>'; // phpcs:ignore
			foreach ( $f['opts'] as $o ) {
				echo '<option' . selected( $val, $o, false ) . '>' . esc_html( $o ) . '</option>';
			}
			echo '</select>';
		} elseif ( $f['num'] && ! $f['priv'] ) {
			echo '<select name="' . $nm . '"' . ( $f['req'] ? ' required' : '' ) . '><option value="">Select</option>';
			for ( $a = 18; $a <= 80; $a++ ) {
				echo '<option' . ( (string) $a === trim( (string) $val ) ? ' selected' : '' ) . '>' . (int) $a . '</option>';
			}
			echo '</select>';
		} else {
			echo '<input name="' . $nm . '" value="' . esc_attr( $val ) . '"' . ( $f['num'] ? ' type="number" min="18" max="80"' : ( $f['priv'] ? ' type="tel" inputmode="tel" autocomplete="tel" data-phone="1" pattern="[0-9+\-\s]{6,20}" title="Phone number, for example 0300 1234567" placeholder="03XX XXXXXXX (never shown publicly)"' : '' ) ) . ( $f['req'] && ! ( $edit && $f['priv'] ) ? ' required' : '' ) . '>'; // phpcs:ignore
		}
		echo '</div>';
	}
	echo '</div></section>';
}
echo '<section class="fsec"><h2><span class="ib">' . mrt_icon( 'chat' ) . '</span>Your story</h2><label>About you and the partner you are looking for (no phone numbers or links)</label><textarea name="about" id="mrt-about" rows="5" maxlength="1500" required>' . esc_textarea( $old['about'] ?? ( $post ? $post->post_content : '' ) ) . '</textarea><small class="ml" id="mrt-cnt"></small></section>';
echo '<section class="fsec"><h2><span class="ib">' . mrt_icon( 'user' ) . '</span>Photos</h2><p class="ml">Optional but recommended. JPG, PNG or WebP, up to 6 MB each.</p><div class="drops">';
foreach ( array( 'photo' => 'Main photo', 'photo2' => 'Photo 2', 'photo3' => 'Photo 3' ) as $pn => $pl2 ) {
	echo '<label class="drop"><input type="file" name="' . esc_attr( $pn ) . '" accept="image/*"><span class="dz"><b>+</b>' . esc_html( $pl2 ) . '<small>Drag a photo here or click</small></span></label>';
}
echo '</div></section>';
echo '<p><label><input type="checkbox" style="width:auto" name="terms" value="1" required> I agree to the <a href="' . esc_url( home_url( '/terms/' ) ) . '">terms</a> and confirm this information is true.<span class="bu bl" lang="ur" dir="rtl">میں شرائط سے متفق ہوں اور تصدیق کرتا ہوں کہ دی گئی معلومات درست ہیں۔</span></label></p><button class="btn">' . ( $edit ? 'Save changes' : 'Create profile' ) . '</button></form>';
// Profile Helper (speak, check, save): sits in front of the form; the form below stays the real save path.
$ph_on  = class_exists( 'MRSH_Helper' ) ? MRSH_Helper::mount( $edit ) : false;
if ( $edit && ! $ph_on && class_exists( 'MRSH_Helper' ) && MRSH_Helper::cta() ) { // member already has a profile: offer the voice helper on top of the edit form
	echo '<script>(function(){var f=document.querySelector("form.pf");if(!f)return;var d=document.createElement("div");d.style.cssText="margin:0 0 14px";d.innerHTML=' . wp_json_encode( MRSH_Helper::cta( 'btn' ) ) . ';f.parentNode.insertBefore(d,f)})();</script>';
}
$run_wz = ! $ph_on || ! empty( MRSH_Helper::get()['wiz'] ); // the old step wizard stays as the fallback behind a switch
if ( ! $edit && $run_wz ) { // step-by-step builder for new profiles; the full form stays available
	echo '<script>var MRT_AJAX=' . wp_json_encode( admin_url( 'admin-ajax.php' ) ) . ';' . "\n" . <<<'MRTWIZ'
function mrtWiz(){try{
var f=document.querySelector("form.pf");if(!f)return;
var secs=[].slice.call(f.querySelectorAll(":scope > .fsec"));if(secs.length<2)return;
var tl=f.querySelector(":scope > label"),ti=f.querySelector(":scope > input[name=title]");
var first=document.createElement("section");first.className="fsec";
if(tl&&ti){first.innerHTML="<h2>Your name</h2>";f.insertBefore(first,tl);first.appendChild(tl);first.appendChild(ti)}else{first=null}
var steps=first?[first].concat(secs):secs,n=steps.length,cur=0,wiz=true,KEY="mrt_pf_draft";
var tail=[];var p=f.querySelector(":scope > p");if(p)tail.push(p);var sb=f.querySelector(":scope > button.btn");if(sb)tail.push(sb);
var st=document.createElement("style");st.textContent=".pw-bar{background:#eef0f5;border-radius:99px;height:10px;overflow:hidden;margin:0 0 6px}.pw-bar i{display:block;height:100%;background:linear-gradient(90deg,#e11d74,#7c3aed);width:0;transition:width .25s}.pw-lbl{display:flex;justify-content:space-between;font-size:.9rem;color:#555;margin:0 0 14px;gap:8px;flex-wrap:wrap}.pw-nav{display:flex;gap:10px;align-items:center;margin:16px 0;flex-wrap:wrap}.pw-nav .btn[disabled]{visibility:hidden}.pw-full{background:none;border:0;color:#7c3aed;text-decoration:underline;cursor:pointer;font-size:.9rem;padding:0}";
document.head.appendChild(st);
var head=document.createElement("div");head.innerHTML='<div class="pw-bar"><i></i></div><div class="pw-lbl"><b class="pw-t"></b><button type="button" class="pw-full">Use the full form / مکمل فارم</button></div>';
f.insertBefore(head,f.firstChild);
var nav=document.createElement("div");nav.className="pw-nav";nav.innerHTML='<button type="button" class="btn line pw-b">Back / پیچھے</button><button type="button" class="btn pw-n">Next / اگلا</button>';
if(tail.length){f.insertBefore(nav,tail[0])}else{f.appendChild(nav)}
var bar=head.querySelector("i"),tt=head.querySelector(".pw-t"),bb=nav.querySelector(".pw-b"),nb=nav.querySelector(".pw-n");
function ping(){try{var d=new FormData();d.append("action","mrsh_pf_step");d.append("s",cur+1);d.append("n",n);navigator.sendBeacon?navigator.sendBeacon(MRT_AJAX,d):0}catch(e){}}
function show(i,noping){cur=Math.max(0,Math.min(n-1,i));steps.forEach(function(s,k){s.style.display=wiz&&k!==cur?"none":""});
var last=cur===n-1;tail.forEach(function(t){t.style.display=wiz&&!last?"none":""});
nb.style.display=wiz&&!last?"":"none";bb.disabled=cur===0;
var pc=Math.round((cur+1)/n*100);bar.style.width=pc+"%";tt.textContent="Step "+(cur+1)+" of "+n+" · "+pc+"%";
if(wiz){window.scrollTo({top:Math.max(0,head.getBoundingClientRect().top+window.pageYOffset-80),behavior:"smooth"})}
save();if(!noping)ping()}
function ok(){var els=steps[cur].querySelectorAll("input,select,textarea");for(var k=0;k<els.length;k++){var e=els[k];if(e.offsetParent===null&&e.type!=="hidden"&&e.style.display==="none")continue;if(!e.checkValidity()){e.reportValidity();return false}}return true}
nb.addEventListener("click",function(){if(ok())show(cur+1)});
bb.addEventListener("click",function(){show(cur-1)});
head.querySelector(".pw-full").addEventListener("click",function(){wiz=false;nav.style.display="none";head.style.display="none";show(cur,true);steps.forEach(function(s){s.style.display=""});tail.forEach(function(t){t.style.display=""})});
f.addEventListener("keydown",function(e){if(wiz&&e.key==="Enter"&&cur<n-1&&e.target.tagName!=="TEXTAREA"&&e.target.tagName!=="BUTTON"){e.preventDefault();nb.click()}});
function save(){try{var o={s:cur,v:{}};[].forEach.call(f.elements,function(e){if(!e.name||e.type==="file"||e.type==="hidden"||e.type==="password"||e.name==="terms"||e.name==="pid")return;if((e.type==="checkbox"||e.type==="radio")&&!e.checked)return;o.v[e.name]=e.value});localStorage.setItem(KEY,JSON.stringify(o))}catch(e){}}
f.addEventListener("change",save);f.addEventListener("input",function(){clearTimeout(window.__pw);window.__pw=setTimeout(save,400)});
f.addEventListener("submit",function(){try{localStorage.removeItem(KEY)}catch(e){}});
var start=0;try{var d=JSON.parse(localStorage.getItem(KEY)||"null");if(d&&d.v){Object.keys(d.v).forEach(function(k){var e=f.elements[k];if(e&&!e.value&&e.type!=="file"&&e.type!=="checkbox"&&e.type!=="radio"){e.value=d.v[k];e.dispatchEvent(new Event("change",{bubbles:true}))}});start=Math.min(n-1,d.s|0)}}catch(e){}
show(start);
}catch(e){}}
if(!window.MRSH_PH_ON||!document.getElementById("mrsh-ph-root")||!document.getElementById("mrsh-ph-root").firstChild){mrtWiz()}else{window.addEventListener("mrsh-ph-close",mrtWiz,{once:true})}
MRTWIZ
	. "\n</script>";
}
echo '</div></main>';
echo function_exists( 'mrt_bilingual' ) ? mrt_bilingual( (string) ob_get_clean() ) : ob_get_clean(); // phpcs:ignore
get_footer();
