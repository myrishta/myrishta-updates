<?php
/** Member messenger screen: conversation list on the left, chat on the right (one at a time on a phone). */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function mrt_msg_avatar( $other ) {
	$ou = get_userdata( (int) $other );
	$nm = $ou ? $ou->display_name : 'Member';
	$op = MRSH_Members::my_profile( (int) $other );
	$im = ( $op && 'all' === ( get_user_meta( (int) $other, 'mrt_photo_priv', true ) ?: 'all' ) ) ? mrt_photo( $op->ID, 'thumbnail', array( 'alt' => '' ) ) : '';
	$ch = function_exists( 'mb_strtoupper' ) ? mb_strtoupper( mb_substr( $nm, 0, 1 ) ) : strtoupper( substr( $nm, 0, 1 ) );
	return '<span class="mav">' . ( $im ? $im : esc_html( $ch ) ) . '</span>';
}

function mrt_msg_short( $date ) {
	$d = substr( (string) $date, 0, 10 );
	if ( wp_date( 'Y-m-d' ) === $d ) {
		return mysql2date( 'H:i', $date );
	}
	if ( wp_date( 'Y-m-d', time() - DAY_IN_SECONDS ) === $d ) {
		return 'Yesterday';
	}
	return mysql2date( 'j M', $date );
}

/** Ready-made questions and replies for the chat. Tabs: label => list of texts. Change with the filter mrt_quick_qa. */
function mrt_quick_qa() {
	return apply_filters( 'mrt_quick_qa', array(
		'Introduce' => array(
			'Assalam o Alaikum, I liked your profile and wanted to say hello.',
			'Thank you for your interest in my profile.',
			'Walaikum assalam. Thank you for reaching out.',
			'May I ask who is writing, you or your parents?',
			'I am writing on behalf of my son or daughter. May I ask a few questions?',
			'Shall we first exchange a little about ourselves and our families?',
		),
		'Family' => array(
			'Could you tell me a little about your family?',
			'What do your parents do?',
			'How many brothers and sisters do you have, and are they married?',
			'Do you live with your parents, or on your own?',
			'Which city is your family from, and where do they live now?',
			'We are a simple, respectful family and want a sincere match.',
		),
		'Work and education' => array(
			'What are your education and your current work?',
			'Are you working now, and do you plan to continue after marriage?',
			'Do you live in Pakistan, or abroad? Do you plan to move?',
			'I work full time and would like a partner who understands that.',
			'I am still studying. I will finish my degree soon, Insha Allah.',
		),
		'Expectations' => array(
			'What are you looking for in a life partner?',
			'How important are religious practice and values to you?',
			'Are you comfortable living with the family after marriage?',
			'Where would you like to settle after marriage?',
			'We do not expect or give any dowry. We want a simple wedding.',
			'What are your hobbies and interests?',
		),
		'Next steps' => array(
			'Would it be possible for our families to meet?',
			'When would your family like to take this forward?',
			'My family would like to meet yours. Please suggest a good time.',
			'Please give me a few days to think and talk with my family.',
			'Insha Allah, I will discuss with my family and reply soon.',
			'Let us keep talking and involve our families for the next step.',
			'I prefer to continue with the families involved.',
		),
		'Polite no' => array(
			'Thank you for your time, but I do not feel this is the right match. Best wishes.',
			'I am sorry, I cannot continue this conversation. JazakAllah.',
			'Thank you for your interest. We are looking for something different at this time.',
			'May Allah bless you with a good match. Thank you for understanding.',
		),
		'Roman Urdu' => array(
			'Assalam o Alaikum, aap ka profile pasand aaya.',
			'Aap ke ghar mein kaun kaun hai?',
			'Aap ki taleem aur job kya hai?',
			'Aap ko kis qisam ka rishta chahiye?',
			'Aap shadi ke baad kahan rehna pasand karenge?',
			'Hum na jahez lete hain na dete hain, saada shadi chahte hain.',
			'Hamare ghar wale aap ke ghar walon se milna chahte hain.',
			'Main apne ghar walon se mashwara kar ke jawab doonga/doongi.',
			'Shukriya, lekin main is rishte ko aage nahi barha sakta/sakti. Allah aap ko khush rakhe.',
		),
	) );
}

function mrt_messenger( $uid, $with, $base ) {
	$in    = MRSH_Members::inbox( $uid );
	$un    = 0;
	foreach ( $in as $c ) {
		$un += (int) $c['unread'];
	}
	$list = add_query_arg( 'tab', 'messages', $base );
	echo '<div class="mgr' . ( $with ? ' has-chat' : '' ) . '">';
	/* ---- left: conversations ---- */
	echo '<aside class="mgl"><div class="mgs"><input type="search" id="mgq" placeholder="Search conversations" aria-label="Search conversations" autocomplete="off"></div>';
	echo '<div class="mgf"><button type="button" class="on" data-f="all">All</button><button type="button" data-f="un">Unread' . ( $un ? ' (' . (int) $un . ')' : '' ) . '</button></div>';
	echo '<div class="msgl">';
	if ( ! $in ) {
		echo '<p class="ml mgnone">No conversations yet. Open a profile and press Message to start one.</p>';
	}
	foreach ( $in as $other => $c ) {
		$ou = get_userdata( $other );
		$nm = $ou ? $ou->display_name : 'Member';
		echo '<a class="mrow' . ( $c['unread'] ? ' un' : '' ) . ( (int) $other === (int) $with ? ' on' : '' ) . '" data-n="' . esc_attr( strtolower( $nm . ' ' . $c['text'] ) ) . '" href="' . esc_url( add_query_arg( array( 'tab' => 'messages', 'with' => $other ), $base ) ) . '">' . mrt_msg_avatar( $other ) . '<span class="mtx"><span class="mtop"><b>' . esc_html( $nm ) . '</b><span class="ml">' . esc_html( mrt_msg_short( $c['date'] ) ) . '</span></span><span class="mbt"><span class="ml">' . esc_html( $c['text'] ) . '</span>' . ( $c['unread'] ? '<span class="mcnt">' . (int) $c['unread'] . '</span>' : '' ) . '</span></span></a>';
	}
	echo '</div></aside>';
	/* ---- right: the chat ---- */
	echo '<section class="mgc">';
	if ( ! $with ) {
		echo '<div class="mge"><span class="mgi">' . mrt_icon( 'chat' ) . '</span><b>Your messages</b><p>Choose a conversation on the left to read and reply.</p></div></section></div>';
		return;
	}
	$ou   = get_userdata( $with );
	$nm   = $ou ? $ou->display_name : 'Member';
	$op   = MRSH_Members::my_profile( $with );
	$last = 0;
	$pres = class_exists( 'MRSH_Mem_Chat' ) ? MRSH_Mem_Chat::presence( $with ) : '';
	echo '<div class="chat" id="mrt-chat" data-with="' . (int) $with . '" data-last="0">';
	echo '<div class="mgh"><a class="mgb" href="' . esc_url( $list ) . '" aria-label="Back to conversations">' . '&#8592;' . '</a>' . mrt_msg_avatar( $with ) . '<div class="mgn">' . ( $op ? '<a href="' . esc_url( get_permalink( $op ) ) . '"><b>' . esc_html( $nm ) . '</b></a>' : '<b>' . esc_html( $nm ) . '</b>' ) . ( $pres ? '<small>' . esc_html( $pres ) . '</small>' : '' ) . '</div>';
	if ( $op ) {
		echo '<div class="mgm"><button type="button" class="qb dim" data-act="report" data-pid="' . (int) $op->ID . '">Report</button><button type="button" class="qb dim" data-act="block" data-pid="' . (int) $op->ID . '">Block</button></div>';
	}
	echo '</div><div class="cl">';
	$prev = '';
	foreach ( MRSH_Members::thread( $uid, $with ) as $m ) {
		$last = max( $last, (int) $m->ID );
		$day  = substr( (string) $m->post_date, 0, 10 );
		if ( $day !== $prev ) {
			echo '<div class="dsep"><span>' . esc_html( class_exists( 'MRSH_Mem_Chat' ) ? MRSH_Mem_Chat::day_label( $m->post_date ) : mysql2date( 'j M Y', $m->post_date ) ) . '</span></div>';
			$prev = $day;
		}
		$me = (int) $m->post_author === (int) $uid;
		$rd = $me && 'read' === get_post_meta( $m->ID, 'msg_status', true );
		echo '<div class="bub' . ( $me ? ' me' : '' ) . '" data-id="' . (int) $m->ID . '"><span class="tx">' . esc_html( $m->post_content ) . '</span><span class="tm">' . esc_html( mysql2date( 'H:i', $m->post_date ) ) . ( $me ? '<i class="tk' . ( $rd ? ' rd' : '' ) . '">' . ( $rd ? '&#10003;&#10003;' : '&#10003;' ) . '</i>' : '' ) . '</span></div>';
	}
	echo '</div>';
	if ( $op && 'publish' === $op->post_status ) {
		$q = array(
			'Assalam o Alaikum',
			'JazakAllah khair',
			'Thank you for your interest in my profile.',
			'Please share some details about your family.',
			'Can our families speak?',
			'Thank you, but I do not think it is a match. Best wishes.',
		);
		echo '<div class="qrow" aria-label="Quick replies">';
		foreach ( $q as $t ) {
			echo '<button type="button" class="chip" data-t="' . esc_attr( $t ) . '">' . esc_html( mb_strlen( $t ) > 30 ? mb_substr( $t, 0, 28 ) . '...' : $t ) . '</button>';
		}
		echo '</div><div class="qap" hidden><div class="qat">';
		$k = 0;
		foreach ( mrt_quick_qa() as $tab => $items ) {
			echo '<button type="button" class="' . ( 0 === $k++ ? 'on' : '' ) . '" data-g="' . esc_attr( sanitize_key( $tab ) ) . '">' . esc_html( $tab ) . '</button>';
		}
		echo '<span class="qah">Tap one to add it to your message</span></div><div class="qal">';
		foreach ( mrt_quick_qa() as $tab => $items ) {
			foreach ( $items as $t ) {
				echo '<button type="button" data-g="' . esc_attr( sanitize_key( $tab ) ) . '" data-t="' . esc_attr( $t ) . '">' . esc_html( $t ) . '</button>';
			}
		}
		echo '</div></div><div class="cmp"><button type="button" class="emo" aria-label="Emoji" aria-expanded="false">&#128522;</button><button type="button" class="qab" aria-label="Quick questions and answers" aria-expanded="false" title="Quick Q&amp;A">&#9889;</button><div class="emp" hidden></div>' . ( class_exists( 'MRSH_Helper' ) ? MRSH_Helper::chat_mic() : '' ) . '<textarea rows="1" maxlength="1000" placeholder="Write a message" aria-label="Message"></textarea><button type="button" class="btn send">' . mrt_icon( 'chat' ) . 'Send</button></div><p class="ml">For your safety, links and phone numbers cannot be sent here.</p>';
	} else {
		echo '<p class="ml">This member has no live profile right now, so you cannot reply.</p>';
	}
	echo '</div><script>document.getElementById("mrt-chat").setAttribute("data-last",' . (int) $last . ');(function(){var c=document.getElementById("mrt-chat");if(!c||c.dataset.own)return;c.dataset.own=1;var A=' . wp_json_encode( admin_url( 'admin-ajax.php' ) ) . ',N=' . wp_json_encode( wp_create_nonce( 'mrt' ) ) . ',W=c.getAttribute("data-with"),busy=false;
function ta(){return c.querySelector(".cmp textarea")}
function toast(m){var t=document.getElementById("mrt-toast");if(!t){t=document.createElement("div");t.id="mrt-toast";t.setAttribute("role","status");document.body.appendChild(t)}t.textContent=m;t.className="show";clearTimeout(t._t);t._t=setTimeout(function(){t.className=""},3200)}
function fill(t){var x=ta();if(!x)return;x.value=x.value?x.value.replace(/\\s+$/,"")+" "+t:t;x.dispatchEvent(new Event("input",{bubbles:true}));try{x.focus()}catch(r){}}
function add(m){var l=c.querySelector(".cl");if(!l||!m||(m.id&&[].some.call(l.querySelectorAll(".bub"),function(q){return q.getAttribute("data-id")==m.id})))return;var d=document.createElement("div");d.className="bub me";d.setAttribute("data-id",m.id||"");var a=document.createElement("span");a.className="tx";a.textContent=m.text||"";var b=document.createElement("span");b.className="tm";b.textContent=(m.time||"")+" \u2713";d.appendChild(a);d.appendChild(b);l.appendChild(d);l.scrollTop=l.scrollHeight;c.setAttribute("data-last",Math.max(+c.getAttribute("data-last")||0,+m.id||0))}
var lastT=0;function send(){var x=ta();if(!x||busy||Date.now()-lastT<1200)return;lastT=Date.now();var v=x.value.trim();if(!v)return;busy=true;var bt=c.querySelector(".send");if(bt)bt.disabled=true;var f=new FormData();f.append("action","mrsh_chat_send");f.append("n",N);f.append("with",W);f.append("text",v);
fetch(A,{method:"POST",credentials:"same-origin",body:f}).then(function(r){return r.json()}).then(function(r){busy=false;if(bt)bt.disabled=false;if(r&&r.ok){add(r.msg);x.value="";x.style.height=""}else toast((r&&r.msg)||"Could not send.")}).catch(function(){busy=false;if(bt)bt.disabled=false;toast("Network problem. Try again.")})}
c.addEventListener("click",function(e){var b=e.target.closest&&e.target.closest(".qrow .chip");if(b){e.preventDefault();fill(b.getAttribute("data-t")||b.textContent);return}var s=e.target.closest&&e.target.closest(".cmp .send");if(s){e.preventDefault();e.stopPropagation();send()}},true);
c.addEventListener("keydown",function(e){if(e.target&&e.target.tagName==="TEXTAREA"&&e.target.closest(".cmp")&&e.key==="Enter"&&!e.shiftKey&&!e.isComposing&&window.innerWidth>700){e.preventDefault();e.stopPropagation();send()}},true)})();(function(){var m=document.querySelector(".mgr.has-chat");if(m&&window.matchMedia("(max-width:820px)").matches){document.body.appendChild(m);document.documentElement.classList.add("mgr-open")}})();</script></section></div>';
}
