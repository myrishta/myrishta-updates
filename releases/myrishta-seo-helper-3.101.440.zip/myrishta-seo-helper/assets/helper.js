/* MyRishta Profile Helper: speak, check, save. Vanilla JS, no libraries, no third-party requests.
   Nothing is written to the profile until the member has seen the Check screen; saving submits the REAL form
   (admin-post mrt_save_profile) with its own nonce, so every server rule still applies. */
(function () {
  'use strict';
  var P = window.MRSH_PH;
  var root = document.getElementById('mrsh-ph-root');
  if (!P || !root) { return; }
  var S = P.str, SW = P.sw;
  var FORM = document.querySelector('form.pf');
  if (!FORM) { return; }

  /* ---------- tiny helpers ---------- */
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function $(sel, el) { return (el || root).querySelector(sel); }
  function $$(sel, el) { return [].slice.call((el || root).querySelectorAll(sel)); }
  function tr(t, o) { return String(t).replace(/\{(\w+)\}/g, function (m, k) { return o && o[k] != null ? o[k] : m; }); }
  var DIG = { '۰': 0, '۱': 1, '۲': 2, '۳': 3, '۴': 4, '۵': 5, '۶': 6, '۷': 7, '۸': 8, '۹': 9, '٠': 0, '١': 1, '٢': 2, '٣': 3, '٤': 4, '٥': 5, '٦': 6, '٧': 7, '٨': 8, '٩': 9 };
  function latin(s) { return String(s || '').replace(/[۰-۹٠-٩]/g, function (c) { return DIG[c]; }); }
  function norm(s) {
    return latin(s).toLowerCase().replace(/[ً-ٰٟۖ-ۭ]/g, '').replace(/[ؤئ]/g, function (c) { return c === 'ؤ' ? 'و' : 'ی'; }).replace(/ي/g, 'ی').replace(/ك/g, 'ک').replace(/ە/g, 'ہ')
      .replace(/[.,;:!?؟،۔"'()\-]/g, ' ').replace(/\s+/g, ' ').trim();
  }
  function post(action, data, cb, files) {
    var fd = new FormData();
    fd.append('action', action); fd.append('n', P.nonce);
    Object.keys(data || {}).forEach(function (k) { fd.append(k, data[k]); });
    if (files) { Object.keys(files).forEach(function (k) { fd.append(k, files[k], 'clip'); }); }
    fetch(P.ajax, { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(function (r) { return r.json(); }).then(function (j) { cb(j || { ok: false }); })
      .catch(function () { cb({ ok: false, err: 'net' }); });
  }
  function track(s) {
    try {
      var fd = new FormData();
      fd.append('action', 'mrsh_ph_step'); fd.append('n', P.nonce); fd.append('s', s); fd.append('m', st.mode || ''); fd.append('from', P.from || '');
      fetch(P.ajax, { method: 'POST', body: fd, credentials: 'same-origin', keepalive: true });
      if (window.MRT && P.ajax) { var d = new FormData(); d.append('action', 'mrsh_pf_step'); d.append('s', Math.min(20, (ORDER.indexOf(s) + 1) || 1)); d.append('n', ORDER.length); if (navigator.sendBeacon) { navigator.sendBeacon(P.ajax, d); } }
    } catch (e) { /* counters only */ }
  }

  /* ---------- fields ---------- */
  var FD = {};
  P.fields.forEach(function (f) { FD[f.key] = f; });
  var K = { who: 'custom-13', gender: 'key4', age: 'daage', mar: 'custom-15', kids: 'custom-16', kst: 'custom-17', rel: 'custom-18', sect: 'custom-19', caste: 'custom-20', nat: 'custom-21', edu: 'custom-2322', job: 'custom-24' };
  var phoneKey = (P.fields.filter(function (f) { return f.priv; })[0] || {}).key || '';
  var LBL = { who: 'پروفائل بنانے والا', 'key4': 'جنس', daage: 'عمر', 'custom-15': 'ازدواجی حیثیت', 'custom-16': 'بچے', 'custom-17': 'بچوں کی رہائش', 'custom-18': 'مذہب', 'custom-19': 'مسلک', 'custom-20': 'ذات', 'custom-21': 'قومیت', 'custom-2322': 'تعلیم', 'custom-24': 'کام', loc: 'شہر اور ملک', title: 'عنوان', about: 'اپنے بارے میں', phone: 'فون نمبر' };
  var QT = { 'custom-13': 'یہ پروفائل کون بنا رہا ہے؟', 'key4': 'رشتہ لڑکے کا ہے یا لڑکی کا؟', daage: 'عمر کتنی ہے؟', 'custom-15': 'ازدواجی حیثیت کیا ہے؟', 'custom-16': 'کیا بچے ہیں؟', 'custom-17': 'بچے کس کے ساتھ رہتے ہیں؟', 'custom-18': 'مذہب کیا ہے؟', 'custom-19': 'مسلک کیا ہے؟', 'custom-20': 'ذات یا برادری کیا ہے؟', 'custom-21': 'قومیت کیا ہے؟', 'custom-2322': 'تعلیم کیا ہے؟', 'custom-24': 'کام یا پیشہ کیا ہے؟', loc: 'کس شہر میں رہتے ہیں؟' };
  var QE = { daage: '۲۸', 'custom-15': 'غیر شادی شدہ', 'custom-18': 'مسلمان', 'custom-19': 'سنی', 'custom-2322': 'ایم بی اے', 'custom-24': 'بینک میں کام کرتا ہوں', loc: 'لاہور' };
  var UR = { 'Self': 'خود', 'Parents': 'والدین', 'Sibling': 'بھائی / بہن', 'Relative': 'رشتہ دار', 'Friend': 'دوست', 'Guardian': 'سرپرست', 'Male': 'لڑکا', 'Female': 'لڑکی', 'Unmarried': 'غیر شادی شدہ', 'Married': 'شادی شدہ', 'Divorced': 'طلاق یافتہ', 'Widowed': 'بیوہ / رنڈوا', 'Separated': 'علیحدہ', 'Prefer to not Say': 'بتانا نہیں چاہتے', 'Prefer to not say': 'بتانا نہیں چاہتے', 'None': 'کوئی نہیں', '1': '1', '2': '2', '3 or Above': '3 یا زیادہ', 'Staying with me': 'میرے ساتھ', 'Staying With Mother': 'والدہ کے ساتھ', 'Staying With Father': 'والد کے ساتھ', 'Staying Separate': 'علیحدہ رہتے ہیں', 'Staying With Grandparents': 'دادا دادی / نانا نانی کے ساتھ', 'Muslims-Islam': 'اسلام (مسلمان)', 'Christianity': 'عیسائیت', 'Hinduism': 'ہندو مت', 'Sikhism': 'سکھ مت', 'Others': 'دیگر', 'Other': 'دیگر', 'Suni': 'سنی', 'Barelvi': 'بریلوی', 'Deobandi': 'دیوبندی', 'Al Hadees': 'اہلِ حدیث', 'Shia': 'شیعہ', 'Ismaili': 'اسماعیلی', 'Sufi': 'صوفی', 'Just Muslim': 'صرف مسلمان', 'Religious': 'دیندار' };
  function ur(key, v) { var f = FD[key]; return (f && f.ur && f.ur[v]) || UR[v] || ''; }
  function shown(key, v) { if (v == null || v === '') { return ''; } var u = ur(key, v); return u ? u + (u === v ? '' : ' · ' + v) : v; }

  /* Urdu, Roman Urdu and English words for the short tap lists. Matching is local, so most answers cost no AI call. */
  var SYN = {
    'custom-13': { 'Self': ['خود', 'میں', 'self', 'myself', 'khud', 'main', 'mein'], 'Parents': ['والدین', 'والد', 'والدہ', 'ماں', 'باپ', 'امی', 'ابو', 'parents', 'parent', 'walidain', 'mother', 'father', 'ammi', 'abbu'], 'Sibling': ['بھائی بہن', 'بھائی', 'بہن', 'sibling', 'brother', 'sister', 'bhai', 'behn', 'behen', 'bahen'], 'Relative': ['رشتہ دار', 'رشتے دار', 'relative', 'rishtedar', 'rishtadar'], 'Friend': ['دوست', 'friend', 'dost'], 'Guardian': ['سرپرست', 'guardian', 'sarparast'] },
    'key4': { 'Male': ['لڑکا', 'لڑکے', 'بیٹا', 'بیٹے', 'مرد', 'male', 'boy', 'son', 'larka', 'ladka', 'beta'], 'Female': ['لڑکی', 'بیٹی', 'خاتون', 'عورت', 'female', 'girl', 'daughter', 'larki', 'ladki', 'beti'] },
    'custom-15': { 'Unmarried': ['غیر شادی شدہ', 'غیرشادی شدہ', 'کنوارا', 'کنواری', 'سنگل', 'unmarried', 'single', 'never married', 'shadi nahi', 'shaadi nahi', 'kunwara', 'kunwari', 'ghair shadi shuda'], 'Married': ['شادی شدہ', 'married', 'shadi shuda', 'shaadi shuda'], 'Divorced': ['طلاق یافتہ', 'طلاق', 'divorced', 'divorcee', 'talaq'], 'Widowed': ['بیوہ', 'رنڈوا', 'widow', 'widowed', 'widower', 'bewa', 'randwa'], 'Separated': ['علیحدہ', 'separated', 'alag'] },
    'custom-16': { 'None': ['کوئی نہیں', 'نہیں', 'none', 'no', 'nahi', 'zero', 'صفر'], '1': ['ایک', '1', 'one', 'aik', 'ek'], '2': ['دو', '2', 'two', 'do'], '3 or Above': ['تین', 'چار', '3', '4', 'three', 'teen', 'char', 'more', 'زیادہ'] },
    'custom-17': { 'Staying with me': ['میرے ساتھ', 'with me', 'mere sath', 'mere saath'], 'Staying With Mother': ['والدہ', 'ماں', 'امی', 'mother', 'mom', 'ammi', 'walida'], 'Staying With Father': ['والد', 'باپ', 'ابو', 'father', 'dad', 'abbu', 'walid'], 'Staying Separate': ['علیحدہ', 'الگ', 'separate', 'alag'], 'Staying With Grandparents': ['دادا', 'نانا', 'دادی', 'نانی', 'grandparents', 'grandmother', 'grandfather', 'dada', 'nana', 'dadi', 'nani'] },
    'custom-18': { 'Muslims-Islam': ['مسلمان', 'مسلم', 'اسلام', 'muslim', 'muslims', 'islam', 'musalman'], 'Christianity': ['عیسائی', 'کرسچن', 'christian', 'christianity', 'isai'], 'Hinduism': ['ہندو', 'hindu'], 'Sikhism': ['سکھ', 'sikh'], 'Others': ['دیگر', 'other', 'others'] },
    'custom-19': { 'Suni': ['سنی', 'sunni', 'suni'], 'Barelvi': ['بریلوی', 'barelvi', 'bralvi'], 'Deobandi': ['دیوبندی', 'deobandi'], 'Al Hadees': ['اہل حدیث', 'اہلحدیث', 'اہل حدیث', 'al hadees', 'ahle hadith', 'ahl e hadith', 'salafi'], 'Shia': ['شیعہ', 'شیعہ', 'shia', 'shiite', 'shi a'], 'Ismaili': ['اسماعیلی', 'ismaili'], 'Sufi': ['صوفی', 'sufi'], 'Just Muslim': ['صرف مسلمان', 'just muslim'], 'Religious': ['دیندار', 'religious'], 'Prefer to not Say': ['بتانا نہیں', 'نہیں بتانا', 'prefer not'], 'Other': ['دیگر', 'other'] }
  };
  var SECT_IS_MUSLIM = { 'Suni': 1, 'Barelvi': 1, 'Deobandi': 1, 'Al Hadees': 1, 'Shia': 1, 'Ismaili': 1, 'Sufi': 1, 'Just Muslim': 1 };

  function hasWord(t, w) { w = norm(w); if (!w) { return false; } return (' ' + t + ' ').indexOf(' ' + w + ' ') > -1; }
  /** One allowed option for this field from the words said, or null. The longest matching phrase wins ("unmarried" beats "married"). */
  function localMatch(key, text) {
    var f = FD[key]; if (!f || !f.opts.length) { return null; }
    var t = norm(text), best = null, bl = 0;
    var tbl = SYN[key] || {};
    f.opts.forEach(function (o) {
      var words = (tbl[o] || []).concat([o]); if (f.ur && f.ur[o]) { words.push(f.ur[o]); }
      words.forEach(function (w) { var n = norm(w); if (n.length > bl && hasWord(t, w)) { bl = n.length; best = o; } });
    });
    return best;
  }

  /* ---------- state ---------- */
  var ORDER = ['start', 'who', 'gender', 'mode', 'speak', 'heard', 'check', 'gap', 'ques', 'about', 'photo', 'save', 'done'];
  var st = { screen: 'start', mode: '', v: {}, ok: {}, unsure: {}, title: '', city: '', country: '', about: '', phone: '', transcript: '', q: { list: [], i: 0 }, gaps: [], photo: null, busy: false, hands: false, first: true, age_blocked: false, aboutAI: false };
  var seenMic = false;

  function el(k) { return FORM.elements[k]; }
  function readForm() {
    P.fields.forEach(function (f) {
      var e = el('f[' + f.key + ']'); var v = e && e.value ? String(e.value).trim() : '';
      if (f.priv) { st.phone = v; } else if (v) { st.v[f.key] = v; st.ok[f.key] = 1; }
    });
    var t = el('title'); if (t && t.value) { st.title = t.value; }
    var a = el('about'); if (a && a.value) { st.about = a.value; }
    var c = el('loc_country'); if (c && c.value) { st.country = c.value; }
    var ci = el('loc_city'); if (ci && ci.value) { st.city = ci.value; }
  }
  function fire(e) { if (e) { try { e.dispatchEvent(new Event('input', { bubbles: true })); e.dispatchEvent(new Event('change', { bubbles: true })); } catch (x) { /* old browser */ } } }
  function setEl(e, v) { if (!e) { return; } if (e.tagName === 'SELECT') { var has = [].some.call(e.options, function (o) { return o.value === v || o.text === v; }); if (!has) { var op = document.createElement('option'); op.text = v; op.value = v; e.appendChild(op); } e.value = v; } else { e.value = v; } fire(e); }
  function writeForm() {
    P.fields.forEach(function (f) {
      if (f.priv) { var pe = el('f[' + f.key + ']'); if (pe && st.phone) { setEl(pe, st.phone); } return; }
      var e = el('f[' + f.key + ']'); var v = st.v[f.key];
      if (!e) { return; }
      if (v != null && v !== '') {
        setEl(e, v);
        if (f.caste) { var sel = e.parentNode.querySelector('.mrt-cpick'); if (sel) { var hit = [].some.call(sel.options, function (o) { return o.value === v; }); sel.value = hit ? v : '__other'; fire(sel); if (!hit) { e.value = v; } } }
      }
    });
    if (st.title) { setEl(el('title'), st.title); }
    if (st.about) { setEl(el('about'), st.about); }
    if (st.country) { setEl(el('loc_country'), st.country); }
    if (st.city) { setEl(el('loc_city'), st.city); }
    var tm = el('terms'); if (tm) { tm.checked = true; }
  }

  /* ---------- screens ---------- */
  function noun() { if (st.v[K.who] === 'Self') { return S.speak_self; } return st.v[K.gender] === 'Male' ? S.speak_boy : (st.v[K.gender] === 'Female' ? S.speak_girl : S.speak_self); }
  function prog() { var n = Math.max(0, ORDER.indexOf(st.screen)); return Math.round(Math.min(100, n / (ORDER.length - 1) * 100)); }
  function shell(inner, o) {
    o = o || {};
    root.innerHTML = '<div class="ph" role="dialog" aria-live="polite"><div class="ph-top"><div class="ph-bar"><i style="width:' + prog() + '%"></i></div>' +
      (o.back ? '<button type="button" class="ph-link" data-a="back">' + esc(S.back) + ' ›</button>' : '<span></span>') +
      '<button type="button" class="ph-link" data-a="full">' + esc(S.full_form) + '</button></div><div class="ph-body">' + inner + '</div></div>';
    document.documentElement.classList.add('ph-open');
    var b = $('.ph-body'); if (b) { b.scrollTop = 0; }
    if (P.preview) { var pv = document.createElement('div'); pv.className = 'ph-prev'; pv.textContent = 'Preview: nothing is saved'; $('.ph').appendChild(pv); }
  }
  function btn(a, label, cls, extra) { return '<button type="button" class="ph-btn ' + (cls || '') + '" data-a="' + a + '"' + (extra || '') + '>' + label + '</button>'; }
  function chips(key, sel) {
    var f = FD[key]; if (!f) { return ''; }
    return '<div class="ph-chips">' + f.opts.map(function (o) { return '<button type="button" class="ph-chip' + (sel === o ? ' on' : '') + '" data-pick="' + esc(key) + '" data-v="' + esc(o) + '">' + esc(shown(key, o)) + '</button>'; }).join('') + '</div>';
  }
  function go(s) { st.screen = s; track(s); (SCR[s] || SCR.start)(); }
  var SCR = {};

  SCR.start = function () {
    shell('<div class="ph-hero"><div class="ph-mic big">' + MIC + '</div><h1>' + esc(S.start_t) + '</h1><p>' + esc(S.start_s) + '</p></div>' +
      btn('start', esc(S.start_go), 'pri') + '<p class="ph-note"><a href="#" data-a="full">' + esc(S.full_form) + '</a></p>' + (seenMic ? '' : '<p class="ph-note">' + esc(S.mic_note) + '</p>'));
  };
  SCR.who = function () {
    shell('<h2>' + esc(S.who_q) + '</h2>' + chips(K.who, st.v[K.who]), { back: 1 });
  };
  SCR.gender = function () {
    shell('<h2>' + esc(S.boygirl_q) + '</h2><div class="ph-chips two"><button type="button" class="ph-chip big' + (st.v[K.gender] === 'Male' ? ' on' : '') + '" data-pick="' + K.gender + '" data-v="Male">' + esc(S.boy) + '</button><button type="button" class="ph-chip big' + (st.v[K.gender] === 'Female' ? ' on' : '') + '" data-pick="' + K.gender + '" data-v="Female">' + esc(S.girl) + '</button></div>', { back: 1 });
  };
  SCR.mode = function () {
    var h = '<h2>' + esc(S.way_q) + '</h2><div class="ph-stack">';
    if (SW.speak) { h += btn('m-speak', MICI + esc(S.way_speak), 'pri'); }
    if (SW.ques) { h += btn('m-ques', esc(S.way_ques), 'sec'); }
    if (SW.type) { h += btn('m-type', esc(S.way_type), 'sec'); }
    shell(h + '</div>', { back: 1 });
  };

  /* --- speaking (browser recognition first, server clip second, typing always) --- */
  var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  var rec = null, tmr = null, secs = 0, recog = null, recDone = null;
  function stopAll() {
    clearInterval(tmr); tmr = null;
    if (recog) { try { recog.onend = null; recog.stop(); } catch (e) { /* already stopped */ } recog = null; }
    if (rec && rec.state !== 'inactive') { try { rec.stop(); } catch (e) { /* stopped */ } }
    if (window.speechSynthesis) { try { window.speechSynthesis.cancel(); } catch (e) { /* none */ } }
  }
  function listen(o) {
    /* o: continuous, max, onText(text), onDone(text), onFail(code) */
    var text = '', stopped = false, fails = 0;
    function finish() { if (stopped) { return; } stopped = true; clearInterval(tmr); try { if (recog) { recog.onend = null; recog.stop(); } } catch (e) { /* ok */ } recog = null; o.onDone(text.trim()); }
    function useRecorder() {
      if (!SW.stt || !navigator.mediaDevices || !window.MediaRecorder) { o.onFail('mic'); return; }
      navigator.mediaDevices.getUserMedia({ audio: true }).then(function (stream) {
        var mt = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg'].filter(function (t) { return window.MediaRecorder.isTypeSupported && window.MediaRecorder.isTypeSupported(t); })[0] || '';
        var chunks = []; rec = mt ? new MediaRecorder(stream, { mimeType: mt }) : new MediaRecorder(stream);
        rec.ondataavailable = function (e) { if (e.data && e.data.size) { chunks.push(e.data); } };
        rec.onstop = function () {
          stream.getTracks().forEach(function (t) { t.stop(); });
          var blob = new Blob(chunks, { type: rec.mimeType || mt || 'audio/webm' });
          if (blob.size > 2 * 1048576) { o.onFail('big'); return; }
          if (blob.size < 800) { o.onDone(''); return; }
          post('mrsh_ph_stt', {}, function (j) { if (j.ok) { text = j.text || ''; o.onText(text); finish(); } else { o.onFail('stt'); } if (recDone) { recDone(); } }, { audio: blob });
        };
        rec.start();
        o.onMode && o.onMode('rec');
      }).catch(function () { o.onFail('mic'); });
    }
    function stopIt() { if (rec && rec.state === 'recording') { rec.stop(); } else { finish(); } }
    if (!SR) { useRecorder(); return { stop: stopIt }; }
    function begin() {
      recog = new SR(); recog.lang = 'ur-PK'; recog.interimResults = true; recog.continuous = !!o.continuous; recog.maxAlternatives = 1;
      var base = text;
      recog.onresult = function (ev) {
        var fin = '', itm = '';
        for (var i = 0; i < ev.results.length; i++) { var r = ev.results[i]; if (r.isFinal) { fin += r[0].transcript + ' '; } else { itm += r[0].transcript; } }
        text = (base + ' ' + fin).trim(); o.onText((text + ' ' + itm).trim());
        if (!o.continuous && fin) { finish(); }
      };
      recog.onerror = function (e) {
        var c = e && e.error;
        if (c === 'not-allowed' || c === 'service-not-allowed' || c === 'language-not-supported') { try { recog.onend = null; if (recog.abort) { recog.abort(); } } catch (x) { /* ok */ } recog = null; useRecorder(); }
        else if (c === 'network' || c === 'audio-capture') { fails++; }
      };
      recog.onend = function () { if (stopped) { return; } if (!o.continuous) { finish(); return; } if (fails > 3) { o.onFail('mic'); return; } try { base = text; begin(); } catch (e) { finish(); } };
      try { recog.start(); } catch (e) { useRecorder(); }
    }
    begin();
    return { stop: stopIt };
  }
  var ctl = null;
  SCR.speak = function () {
    var typed = st.mode === 'type';
    shell('<h2>' + esc(noun()) + '</h2><p class="ph-hint">' + esc(S.speak_hint) + '</p>' +
      (typed ? '' : '<div class="ph-micwrap"><button type="button" class="ph-mic" data-a="mic" aria-label="mic">' + MIC + '</button><div class="ph-st" id="ph-st">' + esc(S.start_go) + '</div><div class="ph-t" id="ph-t"></div></div>') +
      '<textarea id="ph-tx" class="ph-tx" rows="5" maxlength="4000" placeholder="' + esc(S.type_ph) + '" dir="auto">' + esc(st.transcript) + '</textarea>' +
      '<div class="ph-row">' + btn('finish', esc(S.finish), 'pri') + (typed ? '' : btn('restart', esc(S.restart), 'sec')) + '</div>' + (seenMic || typed ? '' : '<p class="ph-note">' + esc(S.mic_note) + '</p>'), { back: 1 });
    if (!typed) { micToggle(true); }
  };
  function micToggle(on) {
    var b = $('.ph-mic[data-a=mic]'), s = $('#ph-st'), t = $('#ph-t'), tx = $('#ph-tx');
    if (ctl) { ctl.stop(); ctl = null; }
    clearInterval(tmr); secs = 0;
    if (!on) { if (b) { b.classList.remove('live'); } if (s) { s.textContent = S.start_go; } return; }
    seenMic = true;
    if (b) { b.classList.add('live'); } if (s) { s.textContent = S.listening; }
    var base = tx ? tx.value : '';
    tmr = setInterval(function () { secs++; if (t) { t.textContent = secs + 's'; } if (secs >= 60) { micToggle(false); } if (secs >= 90) { stopAll(); } }, 1000);
    ctl = listen({
      continuous: true,
      onText: function (x) { if (tx) { tx.value = (base + ' ' + x).trim(); } if (s) { s.textContent = S.listening; } },
      onDone: function (x) { if (b) { b.classList.remove('live'); } if (s) { s.textContent = x ? S.heard : S.e_nohear; } clearInterval(tmr); },
      onFail: function (c) { micToggle(false); if (s) { s.textContent = c === 'stt' ? S.e_noai : S.e_mic; } if (b) { b.classList.remove('live'); } }
    });
  }

  /* --- sending what was said --- */
  function confMap() { var o = {}; Object.keys(st.v).forEach(function (k) { if (st.ok[k]) { o[k] = st.v[k]; } }); return o; }
  function applyResult(j, text) {
    var f = j.fields || {};
    Object.keys(f).forEach(function (k) { if (!FD[k] || FD[k].priv) { return; } st.v[k] = f[k]; st.ok[k] = 1; if ((j.unsure || []).indexOf(k) > -1) { st.unsure[k] = 1; } else { delete st.unsure[k]; } });
    if (j.location) { if (j.location.country) { st.country = j.location.country; } if (j.location.city) { st.city = j.location.city; } }
    if ((j.unsure || []).indexOf('loc_country') > -1) { st.unsure.loc = 1; }
    if (j.about_draft && !st.about) { st.about = j.about_draft; st.aboutAI = true; }
    // the short tap lists are also tried locally for anything the AI left out
    [K.mar, K.rel, K.sect, K.kids, K.kst].forEach(function (k) { if (!st.v[k] && FD[k] && text) { var m = localMatch(k, text); if (m && (k === K.rel || k === K.sect || k === K.mar)) { st.v[k] = m; st.ok[k] = 1; st.unsure[k] = 1; } } });
    if (st.v[K.sect] && SECT_IS_MUSLIM[st.v[K.sect]] && !st.v[K.rel] && FD[K.rel]) { st.v[K.rel] = 'Muslims-Islam'; st.ok[K.rel] = 1; }
    if (st.city && !st.country) { st.country = 'Pakistan'; }
    if (st.city) { st.ok.loc = 1; }
  }
    function ageBlock() { st.age_blocked = true; shell('<div class="ph-msg bad">' + esc(S.e_age) + '</div>' + btn('full', esc(S.full_form), 'sec')); }
  function busy(on, msg) { var b = $('.ph-body'); if (!b) { return; } var o = $('.ph-busy'); if (on && !o) { b.insertAdjacentHTML('beforeend', '<div class="ph-busy"><i></i><span>' + esc(msg || S.listening) + '</span></div>'); } if (!on && o) { o.remove(); } }
  function sendFree() {
    if (rec && rec.state === 'recording') { busy(true, S.heard); recDone = function () { recDone = null; busy(false); sendFree(); }; micToggle(false); return; }
    var tx = $('#ph-tx'); var text = tx ? tx.value.trim() : st.transcript; st.transcript = text;
    micToggle(false); stopAll();
    if (text.replace(/\b(?:h+m+|u+h+|u+m+|e+r+m*|a+h+)\b|ہم+|آں|ام+/giu, '').replace(/[^\p{L}]/gu, '').length < 3) { var s = $('#ph-st'); if (s) { s.textContent = S.e_nohear; } else { var bd = $('.ph-body'); if (bd && !$('.ph-msg')) { bd.insertAdjacentHTML('afterbegin', '<div class="ph-msg bad">' + esc(S.e_nohear) + '</div>'); } } return; }
    if (localUnder(text)) { ageBlock(); return; }
    busy(true, S.heard);
    track('heard');
    post('mrsh_ph_extract', { text: text, mode: 'free', conf: JSON.stringify(confMap()) }, function (j) {
      busy(false);
      if (j.blocked === 'age') { ageBlock(); return; }
      if (!j.ok) { var b = $('.ph-body'); if (b) { b.insertAdjacentHTML('afterbegin', '<div class="ph-msg bad">' + esc(S.e_noai) + '</div>'); } if (SW.ques) { setTimeout(function () { startQues(); }, 1600); } return; }
      if (j.heard === false) { var s2 = $('#ph-st'); if (s2) { s2.textContent = S.e_nohear; } return; }
      applyResult(j, text); st.transcript = ''; go('check');
    });
  }
  function localUnder(text) { var t = latin(text), m, re = /(?:^|\D)(\d{1,2})\s*(?:years?|yrs?|saal|sal|سال|برس)/gi; while ((m = re.exec(t))) { var n = +m[1]; if (n >= 5 && n < P.minage) { return true; } } return false; }

  /* --- questions mode --- */
  function nextList() {
    var order = [K.age, K.mar, K.kids, K.kst, K.rel, K.sect, K.caste, K.nat, K.edu, K.job, 'loc'];
    return order.filter(function (k) { return k === 'loc' ? !(st.city && st.country && st.ok.loc) : (FD[k] && !st.ok[k] && (k !== K.kids || st.v[K.mar] && st.v[K.mar] !== 'Unmarried') && (k !== K.kst || (st.v[K.kids] && st.v[K.kids] !== 'None' && st.v[K.kids] !== 'Prefer to not say'))); });
  }
  function startQues() { st.mode = 'ques'; st.q = { list: nextList(), i: 0 }; st.q.total = st.q.list.length; if (!st.q.list.length) { go('check'); return; } go('ques'); }
  var heardAns = null;
  SCR.ques = function () {
    var q = st.q, k = q.list[q.i]; if (!k) { go('check'); return; }
    var f = FD[k], hasUr = voiceUr(), cur = k === 'loc' ? st.city : st.v[k];
    var body = '<div class="ph-qn">' + esc(tr(S.q_n, { n: q.i + 1, t: q.total })) + '</div><h2>' + esc(QT[k] || (f && f.label) || '') + '</h2>';
    if (QE[k]) { body += '<p class="ph-hint">' + esc(S.q_eg) + ' ' + esc(QE[k]) + '</p>'; }
    if (hasUr) { body += '<button type="button" class="ph-btn ghost" data-a="say">' + esc(S.q_listen) + '</button>'; }
    body += answerWidget(k, cur);
    body += '<div class="ph-heard" id="ph-hd" hidden></div><div class="ph-row">' + btn('qback', esc(S.back), 'sec') + btn('qskip', esc(S.skip), 'ghost') + '</div>';
    if (SW.hands) { body += '<label class="ph-hf"><input type="checkbox" data-a="hf"' + (st.hands ? ' checked' : '') + '> ' + esc(S.hands) + '</label>'; }
    shell(body, {}); if (st.hands) { sayQ(); }
  };
  function answerWidget(k, cur) {
    var f = FD[k], h = '';
    if (k === 'loc') {
      return '<input class="ph-in" id="ph-city" list="mrt-cities" maxlength="40" placeholder="' + esc(QT.loc) + '" value="' + esc(st.city) + '" dir="auto">' + micBtn() + btn('qok', esc(S.next), 'pri');
    }
    if (f && f.num) { var o = ''; for (var a = P.minage; a <= 80; a++) { o += '<option' + (String(cur) === String(a) ? ' selected' : '') + '>' + a + '</option>'; } return micBtn() + '<select class="ph-in" id="ph-age" dir="ltr"><option value="">—</option>' + o + '</select>' + btn('qok', esc(S.next), 'pri'); }
    if (k === K.nat && P.natdef) { return '<button type="button" class="ph-chip big on" data-pick="' + k + '" data-v="' + esc(P.natdef) + '">' + esc(P.natdef === 'Pakistani' ? 'پاکستانی' : 'پاکستان') + '</button><select class="ph-in" id="ph-sel"><option value="">—</option>' + f.opts.map(function (o) { return '<option value="' + esc(o) + '">' + esc(shown(k, o)) + '</option>'; }).join('') + '</select>' + btn('qok', esc(S.next), 'pri'); }
    if (f && f.opts.length && f.opts.length <= 12) { return micBtn() + chips(k, cur); }
    if (f && f.caste) { return micBtn() + '<input class="ph-in" id="ph-free" list="ph-dl" maxlength="40" placeholder="' + esc(QT[k]) + '" value="' + esc(cur || '') + '" dir="auto"><datalist id="ph-dl">' + f.opts.slice(0, 400).map(function (o) { return '<option value="' + esc(o) + '">'; }).join('') + '</datalist>' + btn('qok', esc(S.next), 'pri'); }
    if (f) { return micBtn() + '<select class="ph-in" id="ph-sel"><option value="">—</option>' + f.opts.map(function (o) { return '<option value="' + esc(o) + '"' + (cur === o ? ' selected' : '') + '>' + esc(shown(k, o)) + '</option>'; }).join('') + '</select>' + btn('qok', esc(S.next), 'pri'); }
    return h;
  }
  function micBtn() { return SW.speak || SR ? '<button type="button" class="ph-btn mic" data-a="qmic">' + MICI + esc(S.q_answer) + '</button>' : ''; }
  function voiceUr() { try { return !!(window.speechSynthesis && window.speechSynthesis.getVoices().some(function (v) { return /^ur/i.test(v.lang); })); } catch (e) { return false; } }
  function sayQ() {
    var k = st.q.list[st.q.i]; if (!voiceUr()) { if (st.hands) { qListen(); } return; }
    try { window.speechSynthesis.cancel(); var u = new SpeechSynthesisUtterance(QT[k] || ''); u.lang = 'ur-PK'; var v = window.speechSynthesis.getVoices().filter(function (x) { return /^ur/i.test(x.lang); })[0]; if (v) { u.voice = v; } u.onend = function () { if (st.hands) { qListen(); } }; window.speechSynthesis.speak(u); } catch (e) { /* no voice */ }
  }
  function setAns(k, v) {
    if (k === 'loc') { st.city = v.city != null ? v.city : st.city; st.country = v.country || st.country || 'Pakistan'; st.ok.loc = 1; return; }
    st.v[k] = v; st.ok[k] = 1; delete st.unsure[k];
    if (k === K.mar && v === 'Unmarried') { delete st.v[K.kids]; delete st.v[K.kst]; delete st.ok[K.kids]; delete st.ok[K.kst]; }
    if (k === K.sect && SECT_IS_MUSLIM[v] && !st.v[K.rel] && FD[K.rel]) { st.v[K.rel] = 'Muslims-Islam'; st.ok[K.rel] = 1; }
  }
  function qNext() { var done = st.q.list.slice(0, st.q.i + 1); st.q.list = done.concat(nextList().filter(function (k) { return done.indexOf(k) < 0; })); st.q.total = st.q.list.length; st.q.i++; if (st.q.i >= st.q.list.length) { go('check'); } else { SCR.ques(); track('ques'); } }
  function qListen() {
    var k = st.q.list[st.q.i], hd = $('#ph-hd'); if (!k) { return; }
    var b = $('[data-a=qmic]'); if (b) { b.classList.add('live'); }
    if (ctl) { ctl.stop(); }
    ctl = listen({ continuous: false,
      onText: function (x) { if (hd) { hd.hidden = false; hd.textContent = S.heard + ' ' + x; } },
      onDone: function (x) { if (b) { b.classList.remove('live'); } answerSpoken(k, x); },
      onFail: function (c) { if (b) { b.classList.remove('live'); } if (hd) { hd.hidden = false; hd.textContent = c === 'stt' ? S.e_noai : S.e_mic; } } });
  }
  function answerSpoken(k, text) {
    var hd = $('#ph-hd'); if (!text) { if (hd) { hd.hidden = false; hd.textContent = S.e_nohear; } return; }
    if (localUnder(text)) { ageBlock(); return; }
    var f = FD[k], val = null;
    if (k === 'loc') { val = { city: text.replace(/[^\p{L} ]/gu, '').trim() }; }
    else if (f && f.num) { var m = latin(text).match(/\d{2}/); if (m) { var n = +m[0]; if (n < P.minage) { ageBlock(); return; } if (n <= 80) { val = String(n); } } }
    else if (f && f.opts.length && f.opts.length <= 12) { val = localMatch(k, text); }
    if (val != null) { return confirmHeard(k, val, text); }
    // nothing matched locally: one AI call for this field only
    busy(true, S.heard);
    post('mrsh_ph_extract', { text: text, mode: 'field', field: k, conf: JSON.stringify(confMap()) }, function (j) {
      busy(false);
      if (j.blocked === 'age') { ageBlock(); return; }
      if (j.ok && j.fields && j.fields[k]) { return confirmHeard(k, j.fields[k], text); }
      if (j.ok && k === 'loc' && j.location && j.location.city) { return confirmHeard(k, { city: j.location.city, country: j.location.country }, text); }
      if (hd) { hd.hidden = false; hd.textContent = j.ok ? S.e_nohear : S.e_noai; }
    });
  }
  function confirmHeard(k, val, text) {
    var hd = $('#ph-hd'); if (!hd) { return; }
    var label = k === 'loc' ? val.city : shown(k, val);
    hd.hidden = false; hd.innerHTML = esc(S.heard) + ' <b>' + esc(label) + '</b><div class="ph-row">' + btn('yes', esc(S.q_right), 'pri') + btn('no', esc(S.q_wrong), 'sec') + '</div>';
    heardAns = { k: k, v: val };
    if (st.hands) { clearTimeout(window.__phh); window.__phh = setTimeout(function () { if (heardAns && st.hands) { setAns(heardAns.k, heardAns.v); heardAns = null; qNext(); } }, 2000); }
  }

  /* --- check --- */
  function rowList() {
    var r = [];
    function add(key, label, val, req) { r.push({ key: key, label: label, val: val, req: req }); }
    add('who', LBL.who, st.v[K.who] ? shown(K.who, st.v[K.who]) : '', false);
    if (FD[K.gender]) { add(K.gender, LBL.key4, st.v[K.gender] ? (UR[st.v[K.gender]] || st.v[K.gender]) : '', true); }
    if (FD[K.age]) { add(K.age, LBL.daage, st.v[K.age] || '', FD[K.age].req); }
    add('loc', LBL.loc, st.city ? [st.city, st.country || 'Pakistan'].join(' · ') : '', true);
    [K.mar, K.kids, K.kst, K.rel, K.sect, K.caste, K.nat, K.edu, K.job].forEach(function (k) {
      if (!FD[k]) { return; }
      if (k === K.kids && !(st.v[K.mar] && st.v[K.mar] !== 'Unmarried')) { return; }
      if (k === K.kst && !(st.v[K.kids] && !/^(None|Prefer)/i.test(st.v[K.kids]))) { return; }
      add(k, LBL[k] || FD[k].label, st.v[k] ? shown(k, st.v[k]) : '', FD[k].req);
    });
    // any other required field of this site that the helper does not know by name
    P.fields.forEach(function (f) { if (f.req && !f.priv && ![K.who, K.gender, K.age, K.mar, K.kids, K.kst, K.rel, K.sect, K.caste, K.nat, K.edu, K.job].some(function (x) { return x === f.key; })) { add(f.key, f.label, st.v[f.key] ? shown(f.key, st.v[f.key]) : '', true); } });
    add('title', LBL.title, st.title, true);
    if (phoneKey) { add('phone', LBL.phone, st.phone, true); }
    return r;
  }
  function suggestTitle() {
    if (st.title) { return; }
    var p = [st.v[K.job] && st.v[K.job] !== 'Other' ? st.v[K.job] : '', st.v[K.age] || '', st.city || ''].filter(Boolean);
    if (p.length) { st.title = p.join(', ').slice(0, 60); }
  }
  SCR.check = function () {
    suggestTitle();
    var rows = rowList(), miss = 0;
    var h = '<h2>' + esc(S.check_t) + '</h2><p class="ph-hint">' + esc(S.check_s) + '</p><div class="ph-rows">';
    rows.forEach(function (r) {
      var bad = r.req && !r.val, sure = !!st.unsure[r.key] || (r.key === 'loc' && st.unsure.loc);
      if (bad && r.key !== 'phone' && r.key !== 'title') { miss++; }
      h += '<button type="button" class="ph-row2 ' + (bad ? 'red' : (sure ? 'amb' : 'grn')) + '" data-edit="' + esc(r.key) + '"><span class="l">' + esc(r.label) + '</span><span class="v">' + (r.val ? esc(r.val) : '—') + '</span><span class="b">' + esc(bad ? S.b_need : (sure ? S.b_sure : S.b_ok)) + '</span></button>';
    });
    h += '</div><div class="ph-edit" id="ph-edit"></div>' + btn('after', esc(S.next), 'pri') + (SW.ai ? '' : '');
    shell(h, {});
    st.gaps = rows.filter(function (r) { return r.req && !r.val && r.key !== 'phone' && r.key !== 'title' && r.key !== 'who'; }).map(function (r) { return r.key; });
  };
  function openEdit(key) {
    var box = $('#ph-edit'); if (!box) { return; }
    var f = FD[key], h = '';
    if (key === 'who') { h = chips(K.who, st.v[K.who]); }
    else if (key === 'loc') { h = '<select class="ph-in" id="ed-co">' + countryOpts() + '</select><input class="ph-in" id="ed-ci" list="mrt-cities" maxlength="40" value="' + esc(st.city) + '" dir="auto" placeholder="' + esc(QT.loc) + '">' + btn('ed-save', esc(S.about_ok), 'pri'); }
    else if (key === 'title') { h = '<input class="ph-in" id="ed-t" maxlength="60" value="' + esc(st.title) + '" dir="auto">' + btn('ed-save', esc(S.about_ok), 'pri'); }
    else if (key === 'phone') { h = '<label class="ph-note">' + esc(S.phone_q) + '</label><input class="ph-in" id="ed-p" type="tel" inputmode="tel" autocomplete="tel" pattern="[0-9+\\-\\s]{7,20}" value="' + esc(st.phone) + '" dir="ltr" placeholder="03XX XXXXXXX">' + btn('ed-save', esc(S.about_ok), 'pri'); }
    else if (f && f.num) { h = '<select class="ph-in" id="ed-v" dir="ltr"><option value="">—</option>' + range(P.minage, 80, st.v[key]) + '</select>' + btn('ed-save', esc(S.about_ok), 'pri'); }
    else if (f && f.opts.length && f.opts.length <= 12) { h = micBtn() + chips(key, st.v[key]); }
    else if (f && f.caste) { h = '<input class="ph-in" id="ed-v" list="ph-dl" maxlength="40" value="' + esc(st.v[key] || '') + '" dir="auto"><datalist id="ph-dl">' + f.opts.slice(0, 400).map(function (o) { return '<option value="' + esc(o) + '">'; }).join('') + '</datalist>' + btn('ed-save', esc(S.about_ok), 'pri'); }
    else if (f) { h = '<select class="ph-in" id="ed-v"><option value="">—</option>' + f.opts.map(function (o) { return '<option value="' + esc(o) + '"' + (st.v[key] === o ? ' selected' : '') + '>' + esc(shown(key, o)) + '</option>'; }).join('') + '</select>' + btn('ed-save', esc(S.about_ok), 'pri'); }
    st.q = { list: [key], i: 0, total: 1 };
    box.innerHTML = h + '<div class="ph-heard" id="ph-hd" hidden></div>'; box.dataset.key = key; box.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
  function range(a, b, cur) { var o = ''; for (var i = a; i <= b; i++) { o += '<option' + (String(cur) === String(i) ? ' selected' : '') + '>' + i + '</option>'; } return o; }
  function countryOpts() { var e = el('loc_country'), o = ''; if (e) { [].forEach.call(e.options, function (x) { if (x.value) { o += '<option' + (x.value === st.country ? ' selected' : '') + '>' + esc(x.value) + '</option>'; } }); } return o || '<option>Pakistan</option>'; }

  /* --- a gap: asked only for required fields that are still empty, from the stored question (no AI call) --- */
  SCR.gap = function () {
    var k = st.gaps[0]; if (!k) { go('about'); return; }
    var f = FD[k], cur = k === 'loc' ? '' : st.v[k];
    var body = '<div class="ph-msg">' + esc(S.gap_t) + '</div><h2>' + esc(QT[k === 'loc' ? 'loc' : k] || (f && f.label) || LBL[k] || '') + '</h2>' + answerWidget(k === 'loc' ? 'loc' : k, cur) + '<div class="ph-heard" id="ph-hd" hidden></div><div class="ph-row">' + btn('gskip', esc(S.skip), 'ghost') + '</div>';
    st.q = { list: [k], i: 0, total: 1 }; shell(body, {}); track('gap');
  };

  /* --- about me --- */
  SCR.about = function () {
    var body = '<h2>' + esc(S.about_t) + '</h2><textarea id="ph-ab" class="ph-tx" rows="6" maxlength="1500" dir="auto" placeholder="' + esc(S.type_ph) + '">' + esc(st.about) + '</textarea><div class="ph-row">' + btn('ab-ok', esc(S.about_ok), 'pri') + (SW.ai ? btn('ab-redo', esc(S.about_redo), 'sec') : '') + '</div>' + (SW.ai && !st.about ? '<p class="ph-note" id="ph-abn"></p>' : '');
    shell(body, {}); if (!st.about && SW.ai) { draftAbout(); }
  };
  function draftAbout() {
    var n = $('#ph-abn'); busy(true, S.heard); var facts = {};
    Object.keys(st.v).forEach(function (k) { if (FD[k] && st.ok[k] && !FD[k].priv) { facts[FD[k].label] = st.v[k]; } });
    if (st.city) { facts.City = st.city; }
    post('mrsh_ph_extract', { text: Object.keys(facts).map(function (k) { return k + ': ' + facts[k]; }).join('\n') || 'profile', mode: 'about', conf: JSON.stringify(facts) }, function (j) {
      busy(false); var tx = $('#ph-ab'); if (j.ok && j.about_draft && tx) { tx.value = j.about_draft; st.aboutAI = true; } else if (n) { n.textContent = S.e_noai; }
    });
  }

  /* --- photo --- */
  SCR.photo = function () {
    shell('<h2>' + esc(S.photo_t) + '</h2><div class="ph-stack"><label class="ph-btn pri">' + esc(S.photo_cam) + '<input type="file" accept="image/*" capture="environment" id="ph-cam" hidden></label><label class="ph-btn sec">' + esc(S.photo_gal) + '<input type="file" accept="image/*" id="ph-gal" hidden></label></div><div class="ph-pv" id="ph-pv">' + (st.photo ? esc(st.photo.name) : '') + '</div>' + (SW.photo_wait ? '' : '<p class="ph-note">' + esc(S.photo_later) + '</p>') + btn('photo-next', esc(S.next), 'pri'), {});
    function got(e) { var f = e.target.files && e.target.files[0]; if (f) { st.photo = f; var pv = $('#ph-pv'); if (pv) { pv.innerHTML = '<img alt="" src="' + URL.createObjectURL(f) + '">'; } } }
    $('#ph-cam').onchange = got; $('#ph-gal').onchange = got;
  };

  /* --- save --- */
  function strength() {
    var pts = 0, tips = [];
    if (st.photo || FORM.querySelector('.drop img, .thumb img')) { pts += 30; } else { tips.push('تصویر شامل کریں'); }
    if ((st.about || '').trim().length >= 40) { pts += 20; } else { tips.push('اپنے بارے میں چند جملے لکھیں'); }
    var req = P.fields.filter(function (f) { return f.req && !f.priv; }), have = req.filter(function (f) { return st.v[f.key]; }).length;
    pts += Math.round(50 * (req.length ? have / req.length : 1)); if (have < req.length) { tips.push('باقی ضروری تفصیلات مکمل کریں'); }
    return { pts: Math.min(100, pts), tips: tips.slice(0, 3) };
  }
  SCR.save = function () {
    var s = strength();
    shell('<h2>' + esc(S.save_go) + '</h2><div class="ph-meter"><div class="ph-ring" style="--p:' + s.pts + '"><b>' + s.pts + '%</b></div><div><div class="ph-note">' + esc(S.strength) + '</div>' + s.tips.map(function (t) { return '<div class="ph-tip">• ' + esc(t) + '</div>'; }).join('') + '</div></div>' +
      '<label class="ph-terms"><input type="checkbox" id="ph-terms"> <span>' + esc(S.save_terms) + ' (<a href="' + esc(P.terms) + '" target="_blank" rel="noopener">شرائط</a> · <a href="' + esc(P.privacy) + '" target="_blank" rel="noopener">پرائیویسی</a>)</span></label><div class="ph-msg bad" id="ph-err" hidden></div>' + btn('submit', esc(S.save_go), 'pri', ' id="ph-sub"'), {});
  };
  var finalUrl = '';
  function submit() {
    var t = $('#ph-terms'), err = $('#ph-err');
    if (!t || !t.checked) { if (err) { err.hidden = false; err.textContent = S.save_terms; } return; }
    if (st.busy) { return; } st.busy = true;
    var miss = rowList().filter(function (r) { return r.req && !r.val; });
    if (miss.length) { st.busy = false; if (err) { err.hidden = false; err.textContent = S.b_need + ': ' + miss.map(function (m) { return m.label; }).join('، '); } return; }
    if (P.preview) { st.busy = false; go('done'); return; }
    writeForm();
    if (st.photo) { try { var dt = new DataTransfer(); dt.items.add(st.photo); var pe = el('photo'); if (pe) { pe.files = dt.files; fire(pe); } } catch (e) { /* the old form still works */ } }
    var fd = new FormData(FORM); var b = $('#ph-sub'); if (b) { b.disabled = true; }
    busy(true, S.save_go);
    fetch(FORM.action, { method: 'POST', body: fd, credentials: 'same-origin', redirect: 'follow' }).then(function (r) {
      busy(false); st.busy = false;
      var u = r.url || ''; var bad = /[?&](bad|e)=/.test(u) || /add-listing/.test(u) || /wp-login/.test(u);
      if (bad) { try { localStorage.removeItem('mrt_pf_draft'); } catch (e) { /* ok */ } window.location.href = u || window.location.href; return; }
      finalUrl = u; try { localStorage.removeItem('mrt_pf_draft'); } catch (e) { /* ok */ }
      go('done');
    }).catch(function () { busy(false); st.busy = false; if (b) { b.disabled = false; } if (err) { err.hidden = false; err.textContent = S.e_noai; } });
  }
  SCR.done = function () {
    shell('<div class="ph-hero"><div class="ph-ok">&#10003;</div><h1>' + esc(S.done_t) + '</h1></div>' + (SW.push ? btn('push', esc(S.done_push), 'sec') : '') + '<div id="ph-pm" class="ph-note"></div>' + (finalUrl ? '<a class="ph-btn pri" href="' + esc(finalUrl) + '">پروفائل دیکھیں</a>' : '') + (P.preview ? '<p class="ph-note">Preview: nothing was saved.</p>' : ''));
    try { localStorage.removeItem('mrt_pf_draft'); } catch (e) { /* ok */ }
  };
  function pushOn() {
    var C = window.MRT || {}, pm = $('#ph-pm');
    if (!('serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window && C.vapid)) { if (pm) { pm.textContent = 'This browser cannot show alerts. / یہ براؤزر اطلاعات نہیں دکھا سکتا۔'; } return; }
    function u8(s) { var p = '='.repeat((4 - s.length % 4) % 4), b = (s + p).replace(/-/g, '+').replace(/_/g, '/'), r = atob(b), o = new Uint8Array(r.length); for (var i = 0; i < r.length; i++) { o[i] = r.charCodeAt(i); } return o; }
    Notification.requestPermission().then(function (p) { if (p !== 'granted') { return; } return navigator.serviceWorker.getRegistration().then(function (r) { return r || navigator.serviceWorker.register('/mr-sw.js', { scope: '/' }); }).then(function () { return navigator.serviceWorker.ready; }).then(function (reg) { return reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: u8(C.vapid) }); }).then(function (sub) { var fd = new FormData(); fd.append('action', 'mrt_push_sub'); fd.append('n', C.n); fd.append('sub', JSON.stringify(sub)); return fetch(P.ajax, { method: 'POST', body: fd, credentials: 'same-origin' }); }).then(function () { if (pm) { pm.textContent = '✓'; } }); }).catch(function () { if (pm) { pm.textContent = '—'; } });
  }

  /* ---------- clicks ---------- */
  var MIC = '<svg viewBox="0 0 24 24" width="34" height="34" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v4"/></svg>';
  var MICI = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-4px;margin-inline-end:6px"><rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v4"/></svg>';
  function closeHelper() { stopAll(); root.innerHTML = ''; document.documentElement.classList.remove('ph-open'); track('full'); window.dispatchEvent(new Event('mrsh-ph-close')); }
  var back = { who: 'start', gender: 'who', mode: 'gender', speak: 'mode', ques: 'mode' };
  root.addEventListener('click', function (e) {
    var t = e.target.closest('[data-a],[data-pick],[data-edit]'); if (!t) { return; }
    if (t.dataset.pick) {
      var k = t.dataset.pick, v = t.dataset.v;
      if (st.screen === 'check') { setAns(k, v); SCR.check(); return; }
      if (st.screen === 'gap') { setAns(k, v); st.gaps.shift(); return st.gaps.length ? SCR.gap() : go('about'); }
      if (st.screen === 'ques') { setAns(k, v); return qNext(); }
      setAns(k, v); if (k === K.who) { go('gender'); } else if (k === K.gender) { go('mode'); } return;
    }
    if (t.dataset.edit) { return openEdit(t.dataset.edit); }
    var a = t.dataset.a; e.preventDefault();
    switch (a) {
      case 'full': return closeHelper();
      case 'start': return go('who');
      case 'back': stopAll(); return go(back[st.screen] || 'start');
      case 'm-speak': st.mode = 'speak'; return go('speak');
      case 'm-type': st.mode = 'type'; return go('speak');
      case 'm-ques': return startQues();
      case 'mic': return micToggle(!t.classList.contains('live'));
      case 'restart': var tx = $('#ph-tx'); if (tx) { tx.value = ''; } return micToggle(true);
      case 'finish': return sendFree();
      case 'say': return sayQ();
      case 'qmic': return qListen();
      case 'hf': st.hands = t.checked; if (st.hands) { sayQ(); } return;
      case 'yes': if (heardAns) { setAns(heardAns.k, heardAns.v); heardAns = null; } if (st.screen === 'check') { return SCR.check(); } if (st.screen === 'gap') { st.gaps.shift(); return st.gaps.length ? SCR.gap() : go('about'); } return qNext();
      case 'no': heardAns = null; var h = $('#ph-hd'); if (h) { h.hidden = true; } clearTimeout(window.__phh); return;
      case 'qback': stopAll(); if (st.q.i > 0) { st.q.i--; return SCR.ques(); } return go('mode');
      case 'qskip': return qNext();
      case 'gskip': st.gaps.shift(); return st.gaps.length ? SCR.gap() : go('about');
      case 'qok': var k2 = st.q.list[st.q.i], val = null, f2 = FD[k2], i1 = $('#ph-city'), ia = $('#ph-age'), ifr = $('#ph-free'), is = $('#ph-sel');
        if (k2 === 'loc' && i1 && i1.value.trim()) { val = { city: i1.value.trim() }; } else if (ia && ia.value) { val = ia.value; } else if (ifr && ifr.value.trim()) { val = ifr.value.trim(); } else if (is && is.value) { val = is.value; }
        if (val == null) { return; } if (f2 && f2.num && +val < P.minage) { return ageBlock(); } setAns(k2, val);
        if (st.screen === 'gap') { st.gaps.shift(); return st.gaps.length ? SCR.gap() : go('about'); } return qNext();
      case 'ed-save': var box = $('#ph-edit'), key = box && box.dataset.key; if (!key) { return; }
        if (key === 'loc') { var c = $('#ed-co'), ci = $('#ed-ci'); st.country = c ? c.value : st.country; st.city = ci ? ci.value.trim() : st.city; st.ok.loc = 1; delete st.unsure.loc; }
        else if (key === 'title') { st.title = ($('#ed-t').value || '').trim(); }
        else if (key === 'phone') { st.phone = ($('#ed-p').value || '').trim(); }
        else { var ev = $('#ed-v'); if (ev && ev.value.trim()) { setAns(key, ev.value.trim()); } }
        return SCR.check();
      case 'after': return go(st.gaps.length ? 'gap' : 'about');
      case 'ab-ok': var ab = $('#ph-ab'); st.about = ab ? ab.value.trim() : ''; if (st.about.length < 20) { var n = $('#ph-abn'); if (n) { n.textContent = '20+'; } return; } return go('photo');
      case 'ab-redo': var ab2 = $('#ph-ab'); if (ab2) { ab2.value = ''; } st.about = ''; return draftAbout();
      case 'photo-next': return go('save');
      case 'submit': return submit();
      case 'push': return pushOn();
    }
  });
  root.addEventListener('input', function (e) { if (e.target.id === 'ph-tx') { st.transcript = e.target.value; } });
  // typing a city fills the type-ahead list the form already loads
  root.addEventListener('focusin', function (e) { if (e.target.id === 'ph-city' || e.target.id === 'ed-ci') { var ce = el('loc_country'); if (ce && st.country) { ce.value = st.country; fire(ce); } } });

  /* ---------- start ---------- */
  readForm();
  if (window.speechSynthesis) { try { window.speechSynthesis.getVoices(); window.speechSynthesis.onvoiceschanged = function () {}; } catch (e) { /* none */ } }
  if (P.edit) { // a member who already has a profile: straight to the Check screen at the missing item
    st.mode = 'edit'; go('check');
  } else if (!(window.sessionStorage && sessionStorage.getItem('mrsh_ph_skip'))) {
    go('start');
  }
})();
