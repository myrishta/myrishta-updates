document.addEventListener('change', function (e) {
	if (!e.target.classList || !e.target.classList.contains('mrsh-all')) { return; }
	var table = e.target.closest('table');
	table.querySelectorAll('tbody input[type=checkbox]').forEach(function (c) { c.checked = e.target.checked; });
});
(function () {
	var table = document.getElementById('mrsh-table');
	if (!table) { return; }
	var q = document.getElementById('mrsh-q');
	var g = document.getElementById('mrsh-f-group');
	var t = document.getElementById('mrsh-f-treat');
	var p = document.getElementById('mrsh-f-pri');
	var count = document.getElementById('mrsh-count');
	var rows = Array.prototype.slice.call(table.querySelectorAll('tbody tr'));

	function apply() {
		var text = q.value.toLowerCase();
		var shown = 0;
		rows.forEach(function (tr) {
			var ok = (!g.value || tr.dataset.group === g.value) &&
				(!t.value || tr.dataset.treat === t.value) &&
				(!p.value || tr.dataset.pri === p.value) &&
				(!text || tr.textContent.toLowerCase().indexOf(text) !== -1);
			tr.style.display = ok ? '' : 'none';
			if (ok) { shown++; }
		});
		count.textContent = 'Showing ' + shown + ' of ' + rows.length;
	}

	[q, g, t, p].forEach(function (el) { el.addEventListener('input', apply); el.addEventListener('change', apply); });
	apply();
})();

/* icons on buttons: pick by the words on the button */
(function(){function go(){var map=[[/download|export|backup file/i,"backup"],[/restore|upload|import/i,"upload"],[/save|apply|update|enable/i,"save"],[/run|check|scan|test|audit/i,"play"],[/refresh|reload|re-?crawl|again|sync/i,"refresh"],[/submit|send|ping|notify/i,"send"],[/copy/i,"copy"],[/delete|remove|clear|reset/i,"trash"],[/generate|create|add|new/i,"spark"]];var b=document.querySelectorAll(".mrsh-wrap .button,.mrsh-wrap button.button-primary,.mrsh-wrap input[type=submit]");for(var i=0;i<b.length;i++){var e=b[i];if(e.tagName==="INPUT"||e.getAttribute("data-i")||e.querySelector(".dashicons,svg,img"))continue;var t=(e.textContent||"").trim();if(!t||t.length>40)continue;for(var j=0;j<map.length;j++){if(map[j][0].test(t)){e.setAttribute("data-i",map[j][1]);break}}}}if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",go);else go();})();
