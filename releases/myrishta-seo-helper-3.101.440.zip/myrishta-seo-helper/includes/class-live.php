<?php
/**
 * Live users: counts visitors who are on the site right now, in a way that works with page
 * caching (a tiny script sends a heartbeat). Shows the number on the WordPress dashboard and
 * on SEO > Live Users, with today's visitors, today's peak and the pages being read.
 * No personal data is stored: only a random id per browser tab session, the page path and
 * the device type, kept for a few minutes.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Live {

	const OPT    = 'mrsh_live';
	const DAY    = 'mrsh_live_day';
	const WINDOW = 300; // seconds a visitor counts as "online" after the last heartbeat.

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'wp_footer', array( __CLASS__, 'beacon' ), 99 );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 20 );
		add_action( 'wp_dashboard_setup', array( __CLASS__, 'widget' ) );
		add_action( 'wp_ajax_mrsh_live_stats', array( __CLASS__, 'ajax' ) );
		add_shortcode( 'mrsh_live', array( __CLASS__, 'shortcode' ) );
	}

	public static function routes() {
		register_rest_route( 'mrsh/v1', '/live', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'ping' ),
			'permission_callback' => '__return_true',
		) );
		register_rest_route( 'mrsh/v1', '/live-count', array(
			'methods'             => 'GET',
			'callback'            => function () {
				nocache_headers();
				return array( 'online' => self::count() );
			},
			'permission_callback' => '__return_true',
		) );
	}

	public static function is_bot( $ua ) {
		return '' === $ua || (bool) preg_match( '/bot|crawl|spider|slurp|lighthouse|pagespeed|headless|gtmetrix|pingdom|uptime|monitor|curl|wget|python|facebookexternalhit|preview/i', $ua );
	}

	/** Heartbeat from the visitor's browser. */
	public static function ping( $req ) {
		nocache_headers();
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';
		if ( self::is_bot( $ua ) ) {
			return array( 'ok' => 0 );
		}
		$id = (string) $req->get_param( 'i' );
		if ( ! preg_match( '/^[a-z0-9]{8,40}$/i', $id ) ) {
			return array( 'ok' => 0 );
		}
		$path = (string) $req->get_param( 'p' );
		$path = '/' . ltrim( substr( preg_replace( '/[^\x20-\x7E]/', '', $path ), 0, 120 ), '/' );
		$dev  = preg_match( '/Mobile|Android|iPhone|iPad/i', $ua ) ? 'm' : 'd';
		$now  = time();
		$rows = self::rows( $now );
		$key  = substr( md5( $id ), 0, 12 );
		$rows[ $key ] = array( 't' => $now, 'p' => $path, 'd' => $dev );
		if ( count( $rows ) > 800 ) {
			uasort( $rows, function ( $a, $b ) {
				return $b['t'] <=> $a['t'];
			} );
			$rows = array_slice( $rows, 0, 800, true );
		}
		update_option( self::OPT, $rows, false );
		// Today's unique visitors and peak.
		$today = gmdate( 'Y-m-d', $now + 5 * HOUR_IN_SECONDS ); // Pakistan time (UTC+5).
		$day   = get_option( self::DAY, array() );
		if ( ! is_array( $day ) || ( isset( $day['d'] ) ? $day['d'] : '' ) !== $today ) {
			$day = array( 'd' => $today, 'ids' => array(), 'peak' => 0, 'pv' => 0 );
		}
		if ( count( $day['ids'] ) < 20000 && ! isset( $day['ids'][ $key ] ) ) {
			$day['ids'][ $key ] = 1;
		}
		$day['pv'] = (int) $day['pv'] + 1;
		$day['peak'] = max( (int) $day['peak'], count( $rows ) );
		update_option( self::DAY, $day, false );
		return array( 'ok' => 1 );
	}

	/** Current visitors (drops anything older than the window). */
	public static function rows( $now = 0 ) {
		$now  = $now ? $now : time();
		$rows = get_option( self::OPT, array() );
		if ( ! is_array( $rows ) ) {
			return array();
		}
		foreach ( $rows as $k => $r ) {
			if ( ! isset( $r['t'] ) || $now - (int) $r['t'] > self::WINDOW ) {
				unset( $rows[ $k ] );
			}
		}
		return $rows;
	}

	public static function count() {
		return count( self::rows() );
	}

	public static function stats() {
		$rows  = self::rows();
		$pages = array();
		$m     = 0;
		foreach ( $rows as $r ) {
			$pages[ $r['p'] ] = isset( $pages[ $r['p'] ] ) ? $pages[ $r['p'] ] + 1 : 1;
			if ( 'm' === $r['d'] ) {
				$m++;
			}
		}
		arsort( $pages );
		$day = get_option( self::DAY, array() );
		$day = is_array( $day ) ? $day : array();
		return array(
			'online'  => count( $rows ),
			'mobile'  => $m,
			'desktop' => count( $rows ) - $m,
			'pages'   => array_slice( $pages, 0, 15, true ),
			'today'   => isset( $day['ids'] ) ? count( $day['ids'] ) : 0,
			'views'   => isset( $day['pv'] ) ? (int) $day['pv'] : 0,
			'peak'    => isset( $day['peak'] ) ? (int) $day['peak'] : 0,
		);
	}

	public static function ajax() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error();
		}
		wp_send_json_success( self::stats() );
	}

	/** Tiny heartbeat script for visitors (not for logged-in admins). */
	public static function beacon() {
		if ( is_admin() || is_user_logged_in() && current_user_can( 'manage_options' ) ) {
			return;
		}
		$url = esc_url_raw( rest_url( 'mrsh/v1/live' ) );
		echo '<script data-no-optimize="1" data-cfasync="false">(function(){var id;try{id=sessionStorage.getItem("mrsh_v");if(!id){id=Math.random().toString(36).slice(2,12)+Date.now().toString(36);sessionStorage.setItem("mrsh_v",id);}}catch(e){id=Math.random().toString(36).slice(2,12)+Date.now().toString(36);}function p(){if(document.hidden)return;try{fetch(' . wp_json_encode( $url ) . ',{method:"POST",keepalive:true,headers:{"Content-Type":"application/json"},body:JSON.stringify({i:id,p:location.pathname})}).catch(function(){});}catch(e){}}function s(){setTimeout(p,2000);setInterval(p,60000);document.addEventListener("visibilitychange",function(){if(!document.hidden)p();});}if(document.readyState==="complete")s();else window.addEventListener("load",s);})();</script>' . "\n";
	}

	public static function shortcode() {
		$id = 'mrsh-live-' . wp_rand( 100, 99999 );
		return '<span id="' . esc_attr( $id ) . '" class="mrsh-live">&nbsp;</span><script>(function(){fetch(' . wp_json_encode( esc_url_raw( rest_url( 'mrsh/v1/live-count' ) ) ) . ').then(function(r){return r.json()}).then(function(d){var e=document.getElementById("' . esc_js( $id ) . '");if(e)e.textContent=d.online+" online now";}).catch(function(){});})();</script>';
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'MyRishta SEO: Live Users', 'Live Users', 'manage_options', 'mrsh-live', array( __CLASS__, 'page' ) );
	}

	public static function widget() {
		if ( current_user_can( 'manage_options' ) ) {
			wp_add_dashboard_widget( 'mrsh_live_widget', 'Live users', array( __CLASS__, 'widget_body' ) );
		}
	}

	private static function panel_js( $prefix ) {
		return '<script>(function(){function g(i){return document.getElementById("' . $prefix . '"+i)}function u(){fetch(' . wp_json_encode( admin_url( 'admin-ajax.php?action=mrsh_live_stats' ) ) . ',{credentials:"same-origin"}).then(function(r){return r.json()}).then(function(j){if(!j.success)return;var d=j.data;["online","mobile","desktop","today","views","peak"].forEach(function(k){var e=g(k);if(e)e.textContent=d[k];});var t=g("pages");if(t){var h="";Object.keys(d.pages).forEach(function(p){h+="<tr><td>"+p.replace(/[<>&]/g,"")+"</td><td>"+d.pages[p]+"</td></tr>";});t.innerHTML=h||"<tr><td colspan=2>No visitors right now</td></tr>";}}).catch(function(){});}setInterval(u,10000);})();</script>';
	}

	public static function widget_body() {
		$s = self::stats();
		echo '<p style="font-size:34px;margin:0;font-weight:600;line-height:1.1"><span id="mrshw-online">' . (int) $s['online'] . '</span> <span style="font-size:14px;font-weight:400">online now</span></p>';
		echo '<p style="margin:6px 0 0">Today: <b id="mrshw-today">' . (int) $s['today'] . '</b> visitors &middot; peak <b id="mrshw-peak">' . (int) $s['peak'] . '</b> &middot; <a href="' . esc_url( admin_url( 'admin.php?page=mrsh-live' ) ) . '">details</a></p>';
		echo '<span id="mrshw-mobile" hidden></span><span id="mrshw-desktop" hidden></span><span id="mrshw-views" hidden></span>';
		echo self::panel_js( 'mrshw-' ); // phpcs:ignore WordPress.Security.EscapeOutput
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s = self::stats();
		MRSH_Admin::open( 'Live Users', 'Visitors on the site in the last 5 minutes. Updates by itself every 10 seconds. Search-engine bots, speed tests and logged-in admins are not counted. Only a random id, the page and the device type are kept, for a few minutes.' );
		echo '<div class="mrsh-tiles">';
		$box = function ( $id, $label, $val, $tone = '' ) {
			echo '<div class="mrsh-tile' . ( $tone ? ' is-' . esc_attr( $tone ) : '' ) . '"><span class="mrsh-tile-value" id="mrshl-' . esc_attr( $id ) . '">' . (int) $val . '</span><span class="mrsh-tile-label">' . esc_html( $label ) . '</span></div>';
		};
		$box( 'online', 'Online now', $s['online'], 'live' );
		$box( 'mobile', 'On mobile', $s['mobile'] );
		$box( 'desktop', 'On desktop', $s['desktop'] );
		$box( 'today', 'Visitors today', $s['today'] );
		$box( 'views', 'Page views today', $s['views'] );
		$box( 'peak', 'Peak online today', $s['peak'] );
		echo '</div><div class="mrsh-card"><div class="mrsh-card-head"><h2>Pages being read now</h2></div><table class="widefat striped" style="max-width:700px"><thead><tr><th>Page</th><th>Visitors</th></tr></thead><tbody id="mrshl-pages">';
		if ( empty( $s['pages'] ) ) {
			echo '<tr><td colspan="2">No visitors right now</td></tr>';
		}
		foreach ( $s['pages'] as $p => $n ) {
			echo '<tr><td>' . esc_html( $p ) . '</td><td>' . (int) $n . '</td></tr>';
		}
		echo '</tbody></table><p class="mrsh-muted" style="margin-top:14px">Show it on the site: add the shortcode <code>[mrsh_live]</code> to any page or widget. Times use Pakistan time (UTC+5).</p>';
		echo '</div>' . self::panel_js( 'mrshl-' ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo '</div>';
	}
}
