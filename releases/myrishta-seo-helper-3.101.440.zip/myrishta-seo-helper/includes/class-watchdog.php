<?php
/**
 * Watchdog: daily self-check of the live site. Detects regressions, purges stale caches, reports in the admin.
 * It never edits content or code.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class MRSH_Watchdog {
	const HOOK = 'mrsh_watchdog_run';
	const OPT  = 'mrsh_watchdog_last';

	public static function init() {
		add_action( self::HOOK, array( __CLASS__, 'run' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
		add_action( 'admin_post_mrsh_watchdog_now', array( __CLASS__, 'now' ) );
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + 600, 'daily', self::HOOK );
		}
	}

	public static function now() {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'No access' ); }
		check_admin_referer( 'mrsh_watchdog_now' );
		self::run();
		wp_safe_redirect( admin_url( 'index.php' ) );
		exit;
	}

	private static function get( $path ) {
		$url = home_url( $path );
		$url = add_query_arg( 'mrwd', wp_rand( 1000, 999999 ), $url );
		return wp_remote_get( $url, array( 'timeout' => 20, 'redirection' => 3, 'user-agent' => 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) MyRishtaWatchdog' ) );
	}

	/** Returns an array of problem strings for one page. */
	private static function check_page( $path, $form ) {
		$bad = array();
		$r   = self::get( $path );
		if ( is_wp_error( $r ) ) { return array( $path . ': ' . $r->get_error_message() ); }
		$code = (int) wp_remote_retrieve_response_code( $r );
		if ( 200 !== $code ) { return array( $path . ': HTTP ' . $code ); }
		$h = wp_remote_retrieve_body( $r );
		if ( 1 !== preg_match_all( '#<h1[\s>]#i', $h ) ) { $bad[] = $path . ': not exactly one H1'; }
		if ( ! preg_match( '#<title>\s*\S#i', $h ) ) { $bad[] = $path . ': empty title'; }
		if ( false === stripos( $h, 'name="description"' ) && false === stripos( $h, "name='description'" ) ) { $bad[] = $path . ': no meta description'; }
		if ( false === stripos( $h, 'rel="canonical"' ) && false === stripos( $h, "rel='canonical'" ) ) { $bad[] = $path . ': no canonical'; }
		if ( $form ) {
			// Visible text only. The old spellings also live inside scripts (the Urdu translation list needs them to find the old labels), which is not a problem.
			$vis = preg_replace( '#<(script|style)\b.*?</\1>#is', '', $h );
			$vis = is_string( $vis ) ? $vis : $h;
			foreach ( array( 'Nationalty', 'Habbits', 'Children Satus', '>Suni<', 'Bralvi', 'Satying' ) as $typo ) {
				if ( false !== strpos( $vis, $typo ) ) { $bad[] = $path . ': old typo still shown (' . trim( $typo, '<>' ) . ')'; }
			}
			if ( false === strpos( $h, '__mrEasy' ) && false === strpos( base64_encode( $h ), base64_encode( '__mrEasy' ) ) ) {
				// scripts may be inlined as data URIs, so also look inside them.
				$found = false;
				if ( preg_match_all( '#data:text/javascript;base64,([A-Za-z0-9+/=]+)#', $h, $m ) ) {
					foreach ( $m[1] as $b ) { if ( false !== strpos( (string) base64_decode( $b ), '__mrEasy' ) ) { $found = true; break; } }
				}
				if ( ! $found ) { $bad[] = $path . ': profile form helper script missing'; }
			}
			// A typo-fixer must never alter script text: scripts containing broken replacement output.
			if ( preg_match( '#<script[^>]*>[^<]*Children\'s Status\'s#i', $h ) ) { $bad[] = $path . ': script text was altered'; }
		}
		return $bad;
	}

	public static function run() {
		$bad = array();
		$n   = 0;
		$pages = array( '/' => 0, '/contact/' => 0, '/blog/' => 0, '/add-listing/' => 1, '/how-it-works/' => 0, '/rishta-lahore/' => 0, '/privacy-policy/' => 0 );
		// A "Coming Soon" or maintenance screen shown to visitors would make every check fail. Say that once and skip the rest.
		$probe = self::get( '/' );
		if ( ! is_wp_error( $probe ) ) {
			$pb = wp_remote_retrieve_body( $probe );
			if ( false !== stripos( $pb, 'hsr-coming-soon' ) || preg_match( '#<title>\s*(Coming Soon|Under Maintenance|Maintenance)\s*</title>#i', $pb ) ) {
				$res = array( 'time' => time(), 'checks' => 0, 'problems' => array(), 'purged' => false, 'skipped' => 'Visitors see a "Coming Soon" page (Hostinger Tools), so the page checks were skipped. This is normal for a test site. Turn Coming Soon off in Hostinger > Settings before launch.' );
				update_option( self::OPT, $res, false );
				return $res;
			}
		}
		foreach ( $pages as $p => $form ) { $n++; $bad = array_merge( $bad, self::check_page( $p, (bool) $form ) ); }
		$r = self::get( '/ads.txt' );
		$n++;
		if ( is_wp_error( $r ) || 200 !== (int) wp_remote_retrieve_response_code( $r ) || false === strpos( wp_remote_retrieve_body( $r ), 'pub-1537520006900860' ) ) { $bad[] = '/ads.txt: missing or wrong'; }
		$r = self::get( '/robots.txt' );
		$n++;
		if ( is_wp_error( $r ) || false === stripos( wp_remote_retrieve_body( $r ), 'sitemap' ) ) { $bad[] = '/robots.txt: no sitemap line'; }

		$purged = false;
		if ( $bad ) {
			// First fix safe to automate: stale page cache. Then re-check once.
			do_action( 'litespeed_purge_all' );
			$purged = true;
			sleep( 8 );
			$bad2 = array();
			foreach ( $pages as $p => $form ) { $bad2 = array_merge( $bad2, self::check_page( $p, (bool) $form ) ); }
			$bad = $bad2;
		}
		$res = array( 'time' => time(), 'checks' => $n, 'problems' => array_values( $bad ), 'purged' => $purged );
		$prev = get_option( self::OPT );
		update_option( self::OPT, $res, false );
		if ( $bad && ( empty( $prev['problems'] ) || $prev['problems'] !== $res['problems'] ) ) {
			wp_mail( get_option( 'admin_email' ), 'MyRishta watchdog: ' . count( $bad ) . ' problem(s)', "Found after cache purge:\n\n- " . implode( "\n- ", $bad ) . "\n\nThese need a plugin or content fix." );
		}
		return $res;
	}

	public static function box() {
		$r = get_option( self::OPT );
		echo '<div style="margin:0 0 12px;padding:10px 12px;border-radius:8px;background:' . ( $r && ! empty( $r['skipped'] ) ? '#fff7e0' : ( $r && empty( $r['problems'] ) ? '#ecf8ef' : ( $r ? '#fdecec' : '#f3f4f6' ) ) ) . '">';
		if ( ! $r ) {
			echo '<strong>Watchdog:</strong> first check runs soon.';
		} elseif ( ! empty( $r['skipped'] ) ) {
			echo '<strong>Watchdog:</strong> ' . esc_html( $r['skipped'] ) . ' (' . esc_html( human_time_diff( (int) $r['time'] ) ) . ' ago)';
		} elseif ( empty( $r['problems'] ) ) {
			echo '<strong>Watchdog:</strong> all ' . (int) $r['checks'] . ' checks passed, ' . esc_html( human_time_diff( (int) $r['time'] ) ) . ' ago.' . ( ! empty( $r['purged'] ) ? ' (cache was refreshed)' : '' );
		} else {
			echo '<strong>Watchdog: ' . count( $r['problems'] ) . ' problem(s)</strong> found ' . esc_html( human_time_diff( (int) $r['time'] ) ) . ' ago:<ul style="margin:6px 0 0 18px;list-style:disc">';
			foreach ( $r['problems'] as $p ) { echo '<li>' . esc_html( $p ) . '</li>'; }
			echo '</ul>';
		}
		$u = wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_watchdog_now' ), 'mrsh_watchdog_now' );
		echo '<p style="margin:8px 0 0"><a class="button button-small" href="' . esc_url( $u ) . '">Check now</a></p></div>';
	}
}
MRSH_Watchdog::init();

/**
 * Phones opening the home page are sent to the app at /app/. Search bots, desktops, deep links
 * and anyone coming back from the app (or using ?web=1) stay on the website.
 */
class MRSH_AppRedirect {
	public static function init() {
		add_action( 'wp_head', array( __CLASS__, 'out' ), 1 );
		add_action( 'admin_post_mrsh_app_toggle', array( __CLASS__, 'toggle' ) );
		// The My Rishta App plugin has its own redirect. This switch is the single control for both.
		add_action( 'wp', array( __CLASS__, 'take_over' ) );
	}

	public static function take_over() {
		if ( function_exists( 'mrapp_mobile_redirect' ) ) { remove_action( 'wp_head', 'mrapp_mobile_redirect', 1 ); }
	}

	public static function on() { return '1' === (string) get_option( 'mrsh_app_redirect', '0' ); }

	public static function toggle() {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'No access' ); }
		check_admin_referer( 'mrsh_app_toggle' );
		update_option( 'mrsh_app_redirect', self::on() ? '0' : '1', false );
		wp_safe_redirect( admin_url( 'index.php' ) );
		exit;
	}

	public static function box() {
		$u = wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_app_toggle' ), 'mrsh_app_toggle' );
		echo '<p style="margin:0 0 12px">Phone visitors sent to the app: <strong>' . ( self::on() ? 'on' : 'off' ) . '</strong> <a class="button button-small" href="' . esc_url( $u ) . '">' . ( self::on() ? 'Turn off' : 'Turn on' ) . '</a></p>';
	}
	public static function out() {
		if ( ! self::on() || is_admin() || ! is_front_page() || is_user_logged_in() && current_user_can( 'edit_posts' ) ) { return; }
		echo '<script id="mrsh-app-go">(function(){try{var u=navigator.userAgent||"";'
			. 'if(/bot|crawl|spider|slurp|bing|google|facebookexternalhit|whatsapp|telegram|lighthouse|pagespeed|ahrefs|semrush|yandex|duckduck|preview/i.test(u))return;'
			. 'if(!/Android|iPhone|iPod|Mobile/i.test(u)||/iPad|Tablet/i.test(u))return;'
			. 'var l=location;if(l.search&&/(^|[?&])(web=1|s=|utm_)/.test(l.search))return;'
			. 'if(document.referrer&&document.referrer.indexOf(l.origin+"/app")===0)return;'
			. 'if(!localStorage.getItem("mr_seen")){localStorage.setItem("mr_seen","1");return;}'
			. 'if(sessionStorage.getItem("mr_web"))return;sessionStorage.setItem("mr_web","1");'
			. 'l.replace("/app/")}catch(e){}})();</script>' . "\n";
	}
}
MRSH_AppRedirect::init();

/** Safe response headers, and /llms.txt for AI assistants. */
class MRSH_Extras {
	public static function init() {
		add_action( 'send_headers', array( __CLASS__, 'headers' ) );
		add_action( 'template_redirect', array( __CLASS__, 'llms' ), 0 );
	}
	public static function headers() {
		if ( is_admin() || headers_sent() ) { return; }
		if ( isset( $_GET['c'] ) && is_string( $_GET['c'] ) && preg_match( '/^[A-Za-z]{3}$/', $_GET['c'] ) ) { header( 'X-Robots-Tag: noindex, follow' ); }
		header( 'X-Frame-Options: SAMEORIGIN' );
		header( 'Referrer-Policy: strict-origin-when-cross-origin' );
	}
	public static function llms() {
		$path = (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH );
		// Duplicate guides are merged into one address (old address -> kept address).
		$moves = array( '/second-marriage-rishta-pakistan-guide/' => '/second-marriage-guide-pakistan/' );
		if ( isset( $moves[ $path ] ) ) { wp_safe_redirect( home_url( $moves[ $path ] ), 301 ); exit; }
		if ( '/llms-full.txt' === $path ) {
			self::llms_full();
		}
		if ( '/llms.txt' !== $path ) { return; }
		status_header( 200 );
		header( 'Content-Type: text/plain; charset=utf-8' );
		$u = home_url();
		echo "# My Rishta Pakistan\n\n"
			. "> A free, non-profit Pakistani rishta (marriage proposal) service run from Shahdara, Lahore. Families can create a free profile, browse proposals and contact each other directly. No membership fees.\n\n"
			. "## Key pages\n"
			. "- [Home]($u/)\n"
			. "- [Create a free profile]($u/add-listing/)\n"
			. "- [How it works]($u/how-it-works/)\n"
			. "- [Free marriage bureau online in Pakistan]($u/free-marriage-bureau-online-pakistan/)\n"
			. "- [How to find a rishta online safely]($u/how-to-find-rishta-online-pakistan/)\n"
			. "- [Marriage proposals in Pakistan guide]($u/marriage-proposals-pakistan-guide/)\n"
			. "- [Rishta safety tips]($u/rishta-safety-tips-avoid-fake-profiles-scams/)\n"
			. "- [Rishta in Lahore]($u/rishta-lahore/)\n"
			. "- [Rishta for overseas Pakistanis]($u/rishta-overseas-pakistanis/)\n"
			. "- [Report a profile or misuse]($u/report-profile-misuse/)\n"
			. "- [Contact]($u/contact/)\n"
			. "- [Everything in one file]($u/llms-full.txt)\n\n"
			. "## Notes\n"
			. "- Member profiles are private to members and are not indexed.\n"
			. "- Languages: English and Urdu.\n";
		exit;
	}
	/** Plain-text list of every public page and guide with its short description, for AI tools. Rebuilt every 12 hours. */
	private static function llms_full() {
		$txt = get_transient( 'mrsh_llms_full' );
		if ( ! is_string( $txt ) || '' === $txt ) {
			$skip = array( 'cart', 'login', 'my-account', 'profile-details', 'memberships', 'sitemap', 'checkout', 'register', 'lost-password' );
			$txt  = "# My Rishta Pakistan: all public pages\n\n> A free, non-profit Pakistani rishta (marriage proposal) service run from Shahdara, Lahore. No membership fees. Member profiles are private and are not listed here.\n\n";
			foreach ( array( 'page' => 'Pages', 'post' => 'Guides and news' ) as $type => $label ) {
				$q = new WP_Query( array( 'post_type' => $type, 'post_status' => 'publish', 'posts_per_page' => 300, 'orderby' => 'title', 'order' => 'ASC', 'no_found_rows' => true, 'has_password' => false ) );
				$txt .= "## $label\n";
				foreach ( $q->posts as $p ) {
					if ( in_array( $p->post_name, $skip, true ) || get_post_meta( $p->ID, '_mrsh_noindex', true ) ) {
						continue;
					}
					$d    = trim( (string) get_post_meta( $p->ID, '_mrsh_desc', true ) );
					$txt .= '- [' . wp_strip_all_tags( get_the_title( $p ) ) . '](' . get_permalink( $p ) . ')' . ( '' !== $d ? ': ' . wp_strip_all_tags( $d ) : '' ) . "\n";
				}
				$txt .= "\n";
			}
			set_transient( 'mrsh_llms_full', $txt, 12 * HOUR_IN_SECONDS );
		}
		status_header( 200 );
		header( 'Content-Type: text/plain; charset=utf-8' );
		echo $txt; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

}
MRSH_Extras::init();
