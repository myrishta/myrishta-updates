<?php
/**
 * Verification badges on member profiles.
 *  - "Verified": the My Rishta team checked this member's ID by hand (admin ticks a box on the user).
 *  - "Secure account": the member switched on two-step login (email code or authenticator app).
 * Two-step login proves the member controls the account. It does NOT prove who they are,
 * so it gets a different, plainly worded badge.
 * The badge is added in the browser from a tiny public list of profile IDs, so it works with page caching.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Verified {

	const TEAM      = '_mrsh_id_verified';   // timestamp when the team verified the member.
	const TRANSIENT = 'mrsh_verified_map';
	const POST_TYPE = 'listing_type';

	public static function init() {
		add_action( 'show_user_profile', array( __CLASS__, 'field' ) );
		add_action( 'edit_user_profile', array( __CLASS__, 'field' ) );
		add_action( 'personal_options_update', array( __CLASS__, 'save' ) );
		add_action( 'edit_user_profile_update', array( __CLASS__, 'save' ) );
		add_filter( 'manage_users_columns', array( __CLASS__, 'column' ) );
		add_filter( 'manage_users_custom_column', array( __CLASS__, 'column_value' ), 10, 3 );
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'wp_head', array( __CLASS__, 'css' ), 99 );
		add_action( 'wp_footer', array( __CLASS__, 'script' ), 98 );
	}

	/* ---------- admin: tick the box ---------- */

	public static function field( $user ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$ts = (int) get_user_meta( $user->ID, self::TEAM, true );
		wp_nonce_field( 'mrsh_verified_' . $user->ID, 'mrsh_verified_nonce' );
		echo '<h2>Verification</h2><table class="form-table"><tr><th>Verified by team</th><td><label><input type="checkbox" name="mrsh_id_verified" value="1"' . checked( (bool) $ts, true, false ) . '> The My Rishta team checked this member&#8217;s ID by hand</label>';
		if ( $ts ) {
			echo '<p class="description">Verified on ' . esc_html( wp_date( 'j F Y', $ts ) ) . '.</p>';
		}
		echo '<p class="description">Shows a green &ldquo;Verified&rdquo; badge on this member&#8217;s profile. Do not tick it unless you have checked the ID yourself. Delete any copy of the ID once you are done.</p></td></tr></table>';
	}

	public static function save( $user_id ) {
		if ( ! current_user_can( 'manage_options' ) || empty( $_POST['mrsh_verified_nonce'] ) ) {
			return;
		}
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['mrsh_verified_nonce'] ) ), 'mrsh_verified_' . $user_id ) ) {
			return;
		}
		if ( ! empty( $_POST['mrsh_id_verified'] ) ) {
			if ( ! get_user_meta( $user_id, self::TEAM, true ) ) {
				update_user_meta( $user_id, self::TEAM, time() );
			}
		} else {
			delete_user_meta( $user_id, self::TEAM );
		}
		delete_transient( self::TRANSIENT );
	}

	public static function column( $cols ) {
		$cols['mrsh_verified'] = 'Verified';
		return $cols;
	}

	public static function column_value( $out, $col, $user_id ) {
		if ( 'mrsh_verified' !== $col ) {
			return $out;
		}
		if ( get_user_meta( $user_id, self::TEAM, true ) ) {
			return '<strong style="color:#01411c">Verified</strong>';
		}
		return self::has_two_step( $user_id ) ? 'Secure account' : '&mdash;';
	}

	/* ---------- who has which badge ---------- */

	private static function has_two_step( $user_id ) {
		if ( ! class_exists( 'MRSH_TwoFactor' ) ) {
			return false;
		}
		$chosen = get_user_meta( $user_id, MRSH_TwoFactor::M_METHOD, true );
		if ( 'app' !== $chosen && 'email' !== $chosen && 'whatsapp' !== $chosen ) {
			return false; // only members who chose it themselves.
		}
		return (bool) MRSH_TwoFactor::method_for( $user_id );
	}

	/** array( 'v' => [profile ids], 's' => [profile ids] ). Public, no personal data. */
	public static function map() {
		$cached = get_transient( self::TRANSIENT );
		if ( is_array( $cached ) ) {
			return $cached;
		}
		$team = array_map( 'intval', get_users( array( 'meta_key' => self::TEAM, 'fields' => 'ID', 'number' => 1000 ) ) );
		$sec  = array();
		if ( class_exists( 'MRSH_TwoFactor' ) ) {
			$cand = get_users( array( 'meta_key' => MRSH_TwoFactor::M_METHOD, 'meta_value' => array( 'app', 'email', 'whatsapp' ), 'meta_compare' => 'IN', 'fields' => 'ID', 'number' => 1000 ) );
			foreach ( $cand as $id ) {
				if ( self::has_two_step( (int) $id ) ) {
					$sec[] = (int) $id;
				}
			}
		}
		$out = array( 'v' => array(), 's' => array() );
		$all = array_values( array_unique( array_merge( $team, $sec ) ) );
		if ( $all ) {
			$posts = get_posts( array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'publish',
				'author__in'     => $all,
				'posts_per_page' => 2000,
				'no_found_rows'  => true,
			) );
			foreach ( $posts as $p ) {
				$a = (int) $p->post_author;
				if ( in_array( $a, $team, true ) ) {
					$out['v'][] = (int) $p->ID;
				} elseif ( in_array( $a, $sec, true ) ) {
					$out['s'][] = (int) $p->ID;
				}
			}
		}
		set_transient( self::TRANSIENT, $out, 10 * MINUTE_IN_SECONDS );
		return $out;
	}

	public static function routes() {
		register_rest_route( 'mrsh/v1', '/verified', array(
			'methods'             => 'GET',
			'permission_callback' => '__return_true',
			'callback'            => function () {
				$r = new WP_REST_Response( self::map() );
				$r->header( 'Cache-Control', 'public, max-age=300' );
				return $r;
			},
		) );
	}

	/* ---------- front end ---------- */

	private static function wanted() {
		return ! is_admin() && ( is_singular( self::POST_TYPE ) || is_front_page() || is_search() || is_archive() || is_page() || is_home() );
	}

	public static function css() {
		if ( ! self::wanted() ) {
			return;
		}
		echo '<style id="mrsh-vb-css">.mrsh-vb{display:inline-block;margin:6px;padding:3px 10px;border-radius:999px;font:600 11px/1.5 Poppins,system-ui,sans-serif;white-space:nowrap;position:relative;z-index:3}.mrsh-vb-v{background:#01411c;color:#f1deaa;border:1px solid #c9a24b}.mrsh-vb-s{background:#fff;color:#01411c;border:1px solid #0d6a3b}.mrsh-vb-single{margin:4px 0 10px 0}.mrsh-vb-card{margin:2px 0 8px 0;font-size:10.5px;padding:2px 9px}</style>' . "\n";
	}

	public static function script() {
		if ( ! self::wanted() ) {
			return;
		}
		$url = esc_url_raw( rest_url( 'mrsh/v1/verified' ) );
		echo '<script id="mrsh-vb-js">(function(){var d=document;if(!window.fetch)return;fetch(' . wp_json_encode( $url ) . ').then(function(r){return r.json()}).then(function(m){var all={};(m.s||[]).forEach(function(i){all[i]="s"});(m.v||[]).forEach(function(i){all[i]="v"});if(!Object.keys(all).length)return;function mk(t){var s=d.createElement("span");s.className="mrsh-vb "+(t==="v"?"mrsh-vb-v":"mrsh-vb-s");s.textContent=t==="v"?"✔ Verified":"✓ Secure account";s.title=t==="v"?"The My Rishta team checked this member’s ID":"This member uses two-step login";return s}d.querySelectorAll("[data-pid]").forEach(function(c){var t=all[c.getAttribute("data-pid")];if(!t||!c.parentElement)return;var ns=c.parentElement.querySelectorAll(".fs-6.text-600,.show-mobile .lh-20");ns.forEach(function(n){if(n.nextElementSibling&&n.nextElementSibling.classList.contains("mrsh-vb"))return;var x=mk(t);x.className+=" mrsh-vb-card";n.insertAdjacentElement("afterend",x)})});var id=(d.body.className.match(/postid-(\d+)/)||[])[1];if(id&&/single-listing_type/.test(d.body.className)&&all[id]&&!d.querySelector(".mrsh-vb-single")){var h=d.querySelector("h1.fs-lg")||d.querySelector("h1");if(h){var b=mk(all[id]);b.className+=" mrsh-vb-single";h.insertAdjacentElement("afterend",b)}}}).catch(function(){})})();</script>' . "\n";
	}
}
