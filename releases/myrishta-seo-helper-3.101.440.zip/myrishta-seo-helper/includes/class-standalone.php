<?php
/**
 * Standalone SEO engine. Active only when no other SEO plugin (All in One SEO,
 * Rank Math, Yoast) is running, so tags are never printed twice.
 * Prints canonical, Open Graph / Twitter tags and Article schema, controls the
 * WordPress sitemap, adds per-page SEO fields and an HTML sitemap shortcode.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Standalone {

	public static function init() {
		// Sitemap rules apply whichever sitemap WordPress is serving.
		add_filter( 'wp_sitemaps_post_types', array( __CLASS__, 'sitemap_post_types' ) );
		// Plain XML without the XSLT viewer: search engines do not need it and browsers are removing XSLT support.
		add_filter( 'wp_sitemaps_stylesheet_url', '__return_false' );
		add_filter( 'wp_sitemaps_stylesheet_index_url', '__return_false' );
		add_filter( 'wp_sitemaps_taxonomies', array( __CLASS__, 'sitemap_taxonomies' ) );
		add_filter( 'wp_sitemaps_add_provider', array( __CLASS__, 'sitemap_providers' ), 10, 2 );
		add_filter( 'wp_sitemaps_posts_query_args', array( __CLASS__, 'sitemap_query' ), 10, 2 );
		add_shortcode( 'myrishta_sitemap', array( __CLASS__, 'html_sitemap' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_metabox' ) );
		add_action( 'save_post', array( __CLASS__, 'save_metabox' ), 10, 2 );
		add_action( 'init', array( __CLASS__, 'legacy_sitemap_redirect' ), 1 );
		add_action( 'wp_loaded', array( __CLASS__, 'refresh_rewrites' ) );
		add_action( 'init', array( __CLASS__, 'drop_core_canonical' ) );
		add_action( 'wp_head', array( __CLASS__, 'canonical_tag' ), 4 );
		add_action( 'wp_head', array( __CLASS__, 'social_tags' ), 6 );
		add_action( 'wp_head', array( __CLASS__, 'article_schema' ), 33 );
		add_action( 'wp_head', array( __CLASS__, 'webpage_schema' ), 34 );
	}

	/** Rebuild permalinks once after another SEO plugin is removed, so /wp-sitemap.xml works at once. */
	public static function refresh_rewrites() {
		$want = MRSH_Frontend::has_seo_plugin() ? '' : 'core-sitemap';
		if ( (string) get_option( 'mrsh_rewrite_state', '' ) !== $want ) {
			update_option( 'mrsh_rewrite_state', $want, false );
			if ( '' !== $want ) {
				flush_rewrite_rules( false );
			}
		}
	}

	public static function active() {
		return ! empty( MRSH_Options::get()['standalone'] ) && ! MRSH_Frontend::has_seo_plugin();
	}

	/* ---------------- Canonical ---------------- */

	public static function drop_core_canonical() {
		if ( self::active() && ! empty( MRSH_Options::get()['canonical_tags'] ) ) {
			remove_action( 'wp_head', 'rel_canonical' );
		}
	}

	public static function canonical_url() {
		$url = '';
		if ( is_front_page() || is_home() ) {
			$url = home_url( '/' );
		} elseif ( is_singular() ) {
			$url = (string) get_permalink( get_queried_object_id() );
			// Two pages about the same search: the shorter one points to the fuller one, so Google ranks one page.
			$slug = (string) get_post_field( 'post_name', get_queried_object_id() );
			$map  = self::dupes();
			if ( isset( $map[ $slug ] ) ) {
				$tp = get_page_by_path( $map[ $slug ] );
				if ( $tp && 'publish' === $tp->post_status ) {
					$url = (string) get_permalink( $tp );
				}
			}
		} elseif ( is_category() || is_tag() || is_tax() ) {
			$t   = get_queried_object();
			$url = $t ? (string) get_term_link( $t ) : '';
		} elseif ( is_post_type_archive() ) {
			$url = (string) get_post_type_archive_link( get_query_var( 'post_type' ) );
		} elseif ( is_author() ) {
			$url = (string) get_author_posts_url( get_queried_object_id() );
		}
		if ( '' === $url || is_wp_error( $url ) ) {
			return '';
		}
		$paged = (int) get_query_var( 'paged' );
		if ( $paged > 1 ) {
			$url = get_pagenum_link( $paged );
		}
		return MRSH_Frontend::canonical( $url );
	}

	/** Duplicate page slug => the page that should rank. Extra lines can be added in the option mrsh_canon_map ("slug=target" per line). */
	public static function dupes() {
		$map = array( 'rishta-lahore' => 'rishta-in-lahore', 'rishta-for-overseas-pakistanis' => 'rishta-overseas-pakistanis' );
		foreach ( preg_split( '/\r\n|\r|\n/', (string) get_option( 'mrsh_canon_map', '' ) ) as $l ) {
			$p = array_map( 'trim', explode( '=', $l ) );
			if ( 2 === count( $p ) && $p[0] && $p[1] && $p[0] !== $p[1] ) {
				$map[ sanitize_title( $p[0] ) ] = sanitize_title( $p[1] );
			}
		}
		return $map;
	}

	public static function canonical_tag() {
		if ( ! self::active() || empty( MRSH_Options::get()['canonical_tags'] ) || is_404() || is_search() ) {
			return;
		}
		$u = self::canonical_url();
		if ( '' !== $u ) {
			echo '<link rel="canonical" href="' . esc_url( $u ) . '">' . "\n";
		}
	}

	/* ---------------- Open Graph and Twitter ---------------- */

	public static function image_for_current() {
		if ( is_singular() ) {
			$id = (int) get_post_thumbnail_id( get_queried_object_id() );
			if ( $id ) {
				$src = wp_get_attachment_image_src( $id, 'large' );
				if ( $src ) {
					return array( $src[0], (int) $src[1], (int) $src[2] );
				}
			}
		}
		if ( is_singular() && class_exists( 'MRSH_PK' ) && defined( 'MRSH_URL' ) ) {
			$t = MRSH_PK::topic_image( get_post_field( 'post_name', get_queried_object_id() ) );
			if ( $t ) {
				return array( $t[0], 1200, 630 );
			}
		}
		$u = MRSH_Frontend::social_image();
		return '' !== $u ? array( $u, 0, 0 ) : null;
	}

	public static function social_tags() {
		if ( ! self::active() || empty( MRSH_Options::get()['og_tags'] ) || is_404() || MRSH_Frontend::should_noindex() ) {
			return;
		}
		$title = wp_get_document_title();
		$desc  = MRSH_Meta::current_description();
		$url   = self::canonical_url();
		$img   = self::image_for_current();
		$type  = ( is_singular( 'post' ) ) ? 'article' : 'website';
		$m     = array(
			array( 'property', 'og:locale', get_locale() ),
			array( 'property', 'og:type', $type ),
			array( 'property', 'og:title', $title ),
			array( 'property', 'og:description', $desc ),
			array( 'property', 'og:url', $url ),
			array( 'property', 'og:site_name', get_bloginfo( 'name' ) ),
		);
		if ( $img ) {
			$m[] = array( 'property', 'og:image', $img[0] );
			if ( $img[1] && $img[2] ) {
				$m[] = array( 'property', 'og:image:width', (string) $img[1] );
				$m[] = array( 'property', 'og:image:height', (string) $img[2] );
			}
		}
		if ( 'article' === $type ) {
			$m[] = array( 'property', 'article:published_time', get_the_date( 'c', get_queried_object_id() ) );
			$m[] = array( 'property', 'article:modified_time', get_the_modified_date( 'c', get_queried_object_id() ) );
		}
		$m[] = array( 'name', 'twitter:card', $img && $img[1] >= 600 ? 'summary_large_image' : 'summary' );
		$m[] = array( 'name', 'twitter:title', $title );
		if ( '' !== $desc ) {
			$m[] = array( 'name', 'twitter:description', $desc );
		}
		if ( $img ) {
			$m[] = array( 'name', 'twitter:image', $img[0] );
		}
		foreach ( $m as $row ) {
			if ( '' === (string) $row[2] ) {
				continue;
			}
			echo '<meta ' . esc_attr( $row[0] ) . '="' . esc_attr( $row[1] ) . '" content="' . esc_attr( $row[2] ) . '">' . "\n";
		}
	}

	/* ---------------- Article schema ---------------- */

	public static function article_schema() {
		if ( ! self::active() || empty( MRSH_Options::get()['article_schema'] ) || ! is_singular( 'post' ) || MRSH_Frontend::should_noindex() ) {
			return;
		}
		$post = get_queried_object();
		$o    = MRSH_Options::get();
		$img  = self::image_for_current();
		$logo = '' !== $o['org_logo'] ? $o['org_logo'] : MRSH_Frontend::site_logo();
		$data = array(
			'@context'         => 'https://schema.org',
			'@type'            => 'Article',
			'headline'         => mb_substr( get_the_title( $post ), 0, 110 ),
			'datePublished'    => get_the_date( 'c', $post ),
			'dateModified'     => get_the_modified_date( 'c', $post ),
			'mainEntityOfPage' => self::canonical_url(),
			'inLanguage'       => MRSH_Frontend::content_lang(),
			'author'           => array( '@type' => 'Organization', 'name' => '' !== $o['org_name'] ? $o['org_name'] : get_bloginfo( 'name' ) ),
			'publisher'        => array( '@type' => 'Organization', 'name' => '' !== $o['org_name'] ? $o['org_name'] : get_bloginfo( 'name' ) ),
		);
		$ds = class_exists( 'MRSH_Meta' ) ? trim( (string) MRSH_Meta::current_description() ) : '';
		if ( '' !== $ds ) {
			$data['description'] = $ds;
		}
		if ( $logo ) {
			$data['publisher']['logo'] = array( '@type' => 'ImageObject', 'url' => $logo );
		}
		if ( $img ) {
			$data['image'] = array( $img[0] );
		}
		$data = apply_filters( 'mrsh_article_schema', $data, $post );
		echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/* ---------------- WebPage / CollectionPage schema (pages and archives) ---------------- */

	public static function webpage_schema() {
		if ( ! self::active() || is_front_page() || is_singular( 'post' ) || MRSH_Frontend::should_noindex() ) {
			return;
		}
		if ( ! ( is_page() || is_home() || is_category() ) ) {
			return;
		}
		$o     = MRSH_Options::get();
		$name  = '' !== $o['org_name'] ? $o['org_name'] : get_bloginfo( 'name' );
		$logo  = '' !== $o['org_logo'] ? $o['org_logo'] : MRSH_Frontend::site_logo();
		$title = is_page() ? get_the_title( get_queried_object_id() ) : ( is_category() ? single_cat_title( '', false ) : get_the_title( (int) get_option( 'page_for_posts' ) ) );
		$title = html_entity_decode( (string) $title, ENT_QUOTES, 'UTF-8' );
		$data  = array(
			'@context'   => 'https://schema.org',
			'@type'      => ( is_page() && ! is_page( array( 'blog', 'sitemap' ) ) ) ? 'WebPage' : 'CollectionPage',
			'name'       => $title,
			'url'        => self::canonical_url(),
			'inLanguage' => MRSH_Frontend::content_lang(),
			'isPartOf'   => array( '@type' => 'WebSite', 'name' => $name, 'url' => home_url( '/' ) ),
			'publisher'  => array( '@type' => 'Organization', 'name' => $name ),
		);
		if ( $logo ) {
			$data['publisher']['logo'] = array( '@type' => 'ImageObject', 'url' => $logo );
		}
		$ds = class_exists( 'MRSH_Meta' ) ? trim( (string) MRSH_Meta::current_description() ) : '';
		if ( '' !== $ds ) {
			$data['description'] = $ds;
		}
		$img = self::image_for_current();
		if ( $img ) {
			$data['primaryImageOfPage'] = array( '@type' => 'ImageObject', 'url' => $img[0] );
			$data['image']              = $img[0];
		}
		if ( is_page() ) {
			$data['datePublished'] = get_the_date( 'c', get_queried_object_id() );
			$data['dateModified']  = get_the_modified_date( 'c', get_queried_object_id() );
		}
		echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/* ---------------- Sitemap ---------------- */

	public static function sitemap_post_types( $types ) {
		foreach ( MRSH_Options::to_list( MRSH_Options::get()['noindex_post_types'] ) as $t ) {
			unset( $types[ $t ] );
		}
		unset( $types['attachment'] );
		return $types;
	}

	public static function sitemap_taxonomies( $taxes ) {
		foreach ( MRSH_Options::to_list( MRSH_Options::get()['noindex_taxonomies'] ) as $t ) {
			unset( $taxes[ $t ] );
		}
		unset( $taxes['post_format'], $taxes['country'] ); // country pages redirect visitors to the login page, so keep them out of the sitemap.
		return $taxes;
	}

	public static function sitemap_providers( $provider, $name ) {
		return ( 'users' === $name && ! empty( MRSH_Options::get()['noindex_author'] ) ) ? false : $provider;
	}

	/** IDs of pages that are noindex by slug or by the per-page checkbox. */
	public static function noindex_ids() {
		static $ids = null;
		if ( null !== $ids ) {
			return $ids;
		}
		$ids = array();
		foreach ( MRSH_Options::to_list( MRSH_Options::get()['noindex_slugs'] ) as $slug ) {
			$p = get_page_by_path( $slug, OBJECT, array( 'page', 'post' ) );
			if ( $p ) {
				$ids[] = (int) $p->ID;
			}
		}
		$flagged = get_posts( array( 'post_type' => 'any', 'post_status' => 'publish', 'posts_per_page' => 500, 'fields' => 'ids', 'no_found_rows' => true, 'meta_key' => '_mrsh_noindex', 'meta_value' => '1' ) );
		return $ids = array_values( array_unique( array_merge( $ids, array_map( 'intval', $flagged ) ) ) );
	}

	public static function sitemap_query( $args, $post_type ) {
		$ex = self::noindex_ids();
		if ( $ex ) {
			$args['post__not_in'] = array_merge( isset( $args['post__not_in'] ) ? (array) $args['post__not_in'] : array(), $ex );
		}
		return $args;
	}

	public static function legacy_sitemap_redirect() {
		if ( '0' === (string) get_option( 'mrsh_redirects', '1' ) || ! self::active() || empty( MRSH_Options::get()['sitemap_redirect'] ) || empty( $_SERVER['REQUEST_URI'] ) ) {
			return;
		}
		$path = strtok( (string) wp_unslash( $_SERVER['REQUEST_URI'] ), '?' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$base = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		$rel  = '/' . ltrim( substr( $path, strlen( $base ) ), '/' );
		if ( in_array( $rel, array( '/sitemap.xml', '/sitemap_index.xml', '/sitemap-index.xml' ), true ) ) {
			wp_safe_redirect( home_url( '/wp-sitemap.xml' ), 301 );
			exit;
		}
	}

	/** [myrishta_sitemap]: a plain list of every indexable page and post. */
	public static function html_sitemap() {
		$ex  = self::noindex_ids();
		$out = '<div class="mrsh-sitemap">';
		foreach ( array( 'page' => 'Pages', 'post' => 'Articles' ) as $type => $label ) {
			$items = get_posts( array( 'post_type' => $type, 'post_status' => 'publish', 'posts_per_page' => 500, 'orderby' => 'title', 'order' => 'ASC', 'post__not_in' => $ex ?: array( 0 ), 'no_found_rows' => true ) );
			if ( ! $items ) {
				continue;
			}
			$out .= '<h2>' . esc_html( $label ) . '</h2><ul>';
			foreach ( $items as $p ) {
				$out .= '<li><a href="' . esc_url( get_permalink( $p ) ) . '">' . esc_html( get_the_title( $p ) ) . '</a></li>';
			}
			$out .= '</ul>';
		}
		return $out . '</div>';
	}

	/* ---------------- Per-page fields ---------------- */

	public static function add_metabox() {
		foreach ( array_diff( array_keys( get_post_types( array( 'public' => true ) ) ), array( 'attachment' ) ) as $type ) {
			add_meta_box( 'mrsh_seo', 'MyRishta SEO', array( __CLASS__, 'render_metabox' ), $type, 'normal', 'high' );
		}
	}

	public static function render_metabox( $post ) {
		wp_nonce_field( 'mrsh_seo_box', 'mrsh_seo_nonce' );
		$t = (string) get_post_meta( $post->ID, '_mrsh_title', true );
		$d = (string) get_post_meta( $post->ID, '_mrsh_desc', true );
		$f = (string) get_post_meta( $post->ID, '_mrsh_focus', true );
		$n = (string) get_post_meta( $post->ID, '_mrsh_noindex', true );
		echo '<p><label><strong>SEO title</strong> <span class="description">(about 60 characters; empty uses the template)</span><br><input type="text" class="widefat" name="mrsh_title" id="mrsh_title" value="' . esc_attr( $t ) . '" maxlength="120"></label></p>';
		echo '<p><label><strong>Meta description</strong> <span class="description">(about 150 characters; empty uses the excerpt)</span><br><textarea class="widefat" rows="3" name="mrsh_desc" id="mrsh_desc" maxlength="320">' . esc_textarea( $d ) . '</textarea></label></p>';
		echo '<p><label><strong>Focus phrase</strong> <span class="description">(one phrase from your keyword bank)</span><br><input type="text" class="widefat" name="mrsh_focus" value="' . esc_attr( $f ) . '"></label></p>';
		echo '<p><label><input type="checkbox" name="mrsh_noindex" value="1" ' . checked( '1', $n, false ) . '> Hide this page from search engines and the sitemap</label></p>';
		if ( '' !== $f ) {
			$body = mb_strtolower( wp_strip_all_tags( $post->post_title . ' ' . $post->post_content ) );
			echo '<p class="description">Focus phrase ' . ( false !== mb_strpos( $body, mb_strtolower( $f ) ) ? 'appears' : 'does not appear' ) . ' in the saved content.</p>';
		}
		echo '<script>(function(){function c(i,m){var e=document.getElementById(i);if(!e)return;var s=document.createElement("small");s.style.display="block";e.parentNode.appendChild(s);function u(){s.textContent=e.value.length+" characters (aim for under "+m+")";s.style.color=e.value.length>m?"#b32d2e":"#646970"}e.addEventListener("input",u);u()}c("mrsh_title",60);c("mrsh_desc",155)})();</script>';
	}

	public static function save_metabox( $post_id, $post ) {
		if ( empty( $_POST['mrsh_seo_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['mrsh_seo_nonce'] ) ), 'mrsh_seo_box' ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$map = array( 'mrsh_title' => '_mrsh_title', 'mrsh_desc' => '_mrsh_desc', 'mrsh_focus' => '_mrsh_focus' );
		foreach ( $map as $field => $key ) {
			$v = isset( $_POST[ $field ] ) ? sanitize_text_field( wp_unslash( $_POST[ $field ] ) ) : '';
			if ( '' === $v ) {
				delete_post_meta( $post_id, $key );
			} else {
				update_post_meta( $post_id, $key, $v );
			}
		}
		if ( ! empty( $_POST['mrsh_noindex'] ) ) {
			update_post_meta( $post_id, '_mrsh_noindex', '1' );
		} else {
			delete_post_meta( $post_id, '_mrsh_noindex' );
		}
	}

	/* ---------------- Import from All in One SEO ---------------- */

	/** Copies custom titles, descriptions, focus phrases and noindex flags. Template values (with #tokens) are skipped. */
	public static function import_aioseo() {
		global $wpdb;
		$table = $wpdb->prefix . 'aioseo_posts';
		if ( $table !== $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			return -1;
		}
		$rows = $wpdb->get_results( "SELECT post_id, title, description, keyphrases, robots_default, robots_noindex FROM {$table}" ); // phpcs:ignore WordPress.DB
		$n    = 0;
		foreach ( (array) $rows as $r ) {
			$id   = (int) $r->post_id;
			$did  = false;
			$vals = array( '_mrsh_title' => (string) $r->title, '_mrsh_desc' => (string) $r->description );
			foreach ( $vals as $key => $v ) {
				$v = trim( wp_strip_all_tags( $v ) );
				if ( '' !== $v && false === strpos( $v, '#' ) && '' === (string) get_post_meta( $id, $key, true ) ) {
					update_post_meta( $id, $key, sanitize_text_field( $v ) );
					$did = true;
				}
			}
			$kp = json_decode( (string) $r->keyphrases, true );
			if ( ! empty( $kp['focus']['keyphrase'] ) && '' === (string) get_post_meta( $id, '_mrsh_focus', true ) ) {
				update_post_meta( $id, '_mrsh_focus', sanitize_text_field( $kp['focus']['keyphrase'] ) );
				$did = true;
			}
			if ( empty( $r->robots_default ) && ! empty( $r->robots_noindex ) ) {
				update_post_meta( $id, '_mrsh_noindex', '1' );
				$did = true;
			}
			if ( $did ) {
				$n++;
			}
		}
		return $n;
	}
}
