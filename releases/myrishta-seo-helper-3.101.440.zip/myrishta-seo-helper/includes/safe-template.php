<?php
/**
 * Runs the real theme template inside a guard. If a part of the page fails, the visitor still gets the rest of the page
 * and the problem goes to the admin's Problems page.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$mrsh_real = isset( $GLOBALS['mrsh_tpl'] ) ? $GLOBALS['mrsh_tpl'] : '';
if ( ! $mrsh_real || ! is_readable( $mrsh_real ) ) {
	return;
}
$mrsh_lvl = ob_get_level();
ob_start();
try {
	include $mrsh_real;
} catch ( \Throwable $mrsh_e ) {
	if ( class_exists( 'MRSH_Safe', false ) ) {
		MRSH_Safe::log_ex( $mrsh_e, 'page template' );
	}
	// Close any buffers the failed part opened, keep what was drawn so far, then finish the page.
	while ( ob_get_level() > $mrsh_lvl + 1 ) {
		ob_end_flush();
	}
	try {
		if ( function_exists( 'get_footer' ) && ! did_action( 'wp_footer' ) ) {
			echo '</div></main>';
			get_footer();
		}
	} catch ( \Throwable $mrsh_e2 ) { // phpcs:ignore
	}
}
while ( ob_get_level() > $mrsh_lvl ) {
	ob_end_flush();
}
