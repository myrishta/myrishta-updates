<?php
/**
 * Sends all site email through a real mailbox (SMTP) instead of the host's basic mail function (3.101.107).
 * Hostinger: host smtp.hostinger.com, port 465 (SSL), user = the full mailbox address, password = that mailbox's password.
 * The password may also be set in wp-config.php as define( 'MRSH_SMTP_PASS', '...' ); and then it is never stored in the database.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Smtp {
	const OPT = 'mrsh_smtp';

	public static function get() {
		$d = array( 'on' => 0, 'host' => 'smtp.hostinger.com', 'port' => 465, 'enc' => 'ssl', 'user' => 'noreply@myrishta.pk', 'pass' => '', 'name' => 'My Rishta Pakistan' );
		$o = get_option( self::OPT, array() );
		$o = is_array( $o ) ? array_merge( $d, $o ) : $d;
		if ( defined( 'MRSH_SMTP_PASS' ) && MRSH_SMTP_PASS ) {
			$o['pass'] = MRSH_SMTP_PASS;
		}
		return $o;
	}

	public static function init() {
		add_action( 'phpmailer_init', array( __CLASS__, 'configure' ), 20 );
		if ( is_admin() ) {
			add_action( 'admin_menu', array( __CLASS__, 'menu' ), 26 );
			add_action( 'admin_post_mrsh_smtp_save', array( __CLASS__, 'act_save' ) );
			add_action( 'admin_post_mrsh_smtp_test', array( __CLASS__, 'act_test' ) );
			add_action( 'admin_post_mrsh_smtp_conn', array( __CLASS__, 'act_conn' ) );
		}
	}

	public static function configure( $m ) {
		$s = self::get();
		if ( empty( $s['on'] ) || '' === $s['host'] || '' === $s['user'] || '' === $s['pass'] ) {
			return;
		}
		$m->isSMTP();
		$m->Host       = $s['host'];
		$m->Port       = (int) $s['port'];
		$m->SMTPAuth   = true;
		$m->Username   = $s['user'];
		$m->Password   = $s['pass'];
		$m->SMTPSecure = in_array( $s['enc'], array( 'ssl', 'tls' ), true ) ? $s['enc'] : '';
		$m->SMTPAutoTLS = ( 'tls' === $s['enc'] );
		$m->Timeout    = 10;
		// The host only accepts mail "from" the mailbox you log in with.
		$m->Sender = $s['user'];
		try {
			$m->setFrom( $s['user'], $s['name'], false );
		} catch ( \Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement
		}
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Email (SMTP)', 'Email (SMTP)', 'manage_options', 'mrsh-smtp', array( __CLASS__, 'page' ) );
	}

	private static function back( $m ) {
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-smtp&msg=' . rawurlencode( $m ) ) );
		exit;
	}

	private static function guard( $a ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_smtp_' . $a );
	}

	public static function act_save() {
		self::guard( 'save' );
		$in  = isset( $_POST['s'] ) && is_array( $_POST['s'] ) ? wp_unslash( $_POST['s'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$old = get_option( self::OPT, array() );
		$old = is_array( $old ) ? $old : array();
		$pass = isset( $in['pass'] ) ? (string) $in['pass'] : '';
		$n   = array(
			'on'   => empty( $in['on'] ) ? 0 : 1,
			'host' => sanitize_text_field( $in['host'] ?? 'smtp.hostinger.com' ),
			'port' => max( 1, min( 65535, (int) ( $in['port'] ?? 465 ) ) ),
			'enc'  => in_array( $in['enc'] ?? 'ssl', array( 'ssl', 'tls', '' ), true ) ? $in['enc'] : 'ssl',
			'user' => sanitize_email( $in['user'] ?? '' ),
			'pass' => '' !== $pass ? $pass : ( $old['pass'] ?? '' ), // empty box keeps the saved password
			'name' => sanitize_text_field( $in['name'] ?? 'My Rishta Pakistan' ),
		);
		update_option( self::OPT, $n, false );
		self::back( $n['on'] ? 'Saved. Email now goes through ' . $n['host'] . '. Send a test below.' : 'Saved. SMTP is OFF.' );
	}

	public static function act_conn() {
		self::guard( 'conn' );
		$s   = self::get();
		$out = array();
		foreach ( array( 465 => 'ssl://', 587 => '', 2525 => '' ) as $port => $pre ) {
			$t0  = microtime( true );
			$en  = 0;
			$es  = '';
			$fp  = @fsockopen( $pre . $s['host'], $port, $en, $es, 6 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			$ms  = (int) ( ( microtime( true ) - $t0 ) * 1000 );
			$out[] = $port . ': ' . ( $fp ? 'reachable (' . $ms . ' ms)' : 'BLOCKED (' . ( '' !== $es ? $es : 'timeout' ) . ')' );
			if ( $fp ) {
				fclose( $fp );
			}
		}
		self::back( 'Connection check to ' . $s['host'] . ' - ' . implode( ' | ', $out ) );
	}

	public static function act_test() {
		self::guard( 'test' );
		$u   = wp_get_current_user();
		$err = '';
		$cap = static function ( $e ) use ( &$err ) {
			$err = is_wp_error( $e ) ? $e->get_error_message() : 'failed';
		};
		add_action( 'wp_mail_failed', $cap );
		$log = array();
		$dbg = static function ( $m ) use ( &$log ) {
			$m->SMTPDebug   = 2;
			$m->Debugoutput = static function ( $str ) use ( &$log ) {
				$str = trim( (string) $str );
				if ( preg_match( '/^(CLIENT -> SERVER: [A-Za-z0-9+\/=]{8,}$|.*AUTH (PLAIN|LOGIN) )/', $str ) ) {
					$str = 'CLIENT -> SERVER: (login data hidden)';
				}
				$log[] = $str;
			};
		};
		add_action( 'phpmailer_init', $dbg, 99 );
		$ok = wp_mail( $u->user_email, 'My Rishta email test', "This test email was sent through the site's mail settings.\n\nIf you can read it, member emails will work too." );
		remove_action( 'wp_mail_failed', $cap );
		remove_action( 'phpmailer_init', $dbg, 99 );
		$tail = '';
		if ( ! $ok ) {
			$keep = array_filter( $log, static function ( $l ) {
				return (bool) preg_match( '/SERVER -> CLIENT: (2|3|4|5)\d\d|STARTTLS|AUTH|CLIENT -> SERVER: (EHLO|STARTTLS|AUTH)|SMTP ERROR|Connection/i', $l );
			} );
			$tail = ' || ' . implode( ' / ', array_slice( array_values( $keep ), -8 ) );
		}
		self::back( $ok ? 'Test email sent to ' . $u->user_email . '. Check the inbox (and spam).' : 'Test failed: ' . $err . $tail );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s  = self::get();
		$ap = esc_url( admin_url( 'admin-post.php' ) );
		$f  = static function ( $a ) {
			return '<input type="hidden" name="action" value="mrsh_smtp_' . $a . '">' . wp_nonce_field( 'mrsh_smtp_' . $a, '_wpnonce', true, false );
		};
		echo '<div class="wrap"><h1>Email (SMTP)</h1><p>Sends all site email (member reminders, welcome emails, alerts) through a real mailbox, so it reaches inboxes and is not blocked by the host.</p>';
		if ( isset( $_GET['msg'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			echo '<div class="notice notice-info is-dismissible"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['msg'] ) ) ) . '</p></div>';
		}
		echo '<form method="post" action="' . $ap . '">' . $f( 'save' ) . '<table class="form-table">';
		echo '<tr><th>Use SMTP</th><td><label><input type="checkbox" name="s[on]" value="1"' . checked( $s['on'], 1, false ) . '> On</label></td></tr>';
		echo '<tr><th>Server</th><td><input type="text" name="s[host]" value="' . esc_attr( $s['host'] ) . '" class="regular-text"> Port <input type="number" name="s[port]" value="' . (int) $s['port'] . '" style="width:80px"> <select name="s[enc]"><option value="ssl"' . selected( $s['enc'], 'ssl', false ) . '>SSL (465)</option><option value="tls"' . selected( $s['enc'], 'tls', false ) . '>TLS (587)</option><option value=""' . selected( $s['enc'], '', false ) . '>None</option></select><p class="description">Hostinger: smtp.hostinger.com, port 465 with SSL.</p></td></tr>';
		echo '<tr><th>Mailbox (user name)</th><td><input type="email" name="s[user]" value="' . esc_attr( $s['user'] ) . '" class="regular-text"><p class="description">The full address, for example noreply@myrishta.pk. All email is sent from this address.</p></td></tr>';
		echo '<tr><th>Mailbox password</th><td><input type="password" name="s[pass]" value="" autocomplete="new-password" class="regular-text" placeholder="' . ( '' !== $s['pass'] ? '(saved, leave empty to keep)' : '' ) . '"><p class="description">The password you set for that mailbox in Hostinger. Safer option: put <code>define( \'MRSH_SMTP_PASS\', \'your password\' );</code> in wp-config.php.</p></td></tr>';
		echo '<tr><th>Sender name</th><td><input type="text" name="s[name]" value="' . esc_attr( $s['name'] ) . '" class="regular-text"></td></tr>';
		echo '</table><p><button class="button button-primary">Save</button></p></form>';
		echo '<form method="post" action="' . $ap . '">' . $f( 'test' ) . '<button class="button">Send a test email to me</button></form> <form method="post" action="' . $ap . '" style="margin-top:8px">' . $f( 'conn' ) . '<button class="button">Check connection (ports 465 / 587 / 2525)</button></form></div>';
	}
}
