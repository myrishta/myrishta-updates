<?php
/**
 * Easy Setup: one-click presets (Easy / Maximum) and a single "paste anything" box
 * that fills the right search-engine verification field automatically.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Easy {

	/** Safe, recommended switches. */
	public static function easy_set() {
		return array(
			'noindex_search' => 1, 'strip_canonical' => 1, 'robots_txt' => 1, 'pk_hreflang' => 1,
			'auto_discover' => 1, 'auto_meta' => 1, 'standalone' => 1, 'og_tags' => 1, 'canonical_tags' => 1,
			'article_schema' => 1, 'sitemap_redirect' => 1, 'website_schema' => 1, 'breadcrumb_schema' => 1,
			'noindex_author' => 1, 'noindex_date' => 1, 'noindex_attachment' => 1,
			'speed_emojis' => 1, 'speed_embeds' => 1, 'speed_fonts' => 1, 'speed_images' => 1,
			'speed_dimensions' => 1, 'speed_unhide' => 1, 'speed_webp' => 1, 'speed_delay_ga' => 1, 'speed_hero' => 1, 'speed_dashicons' => 1, 'speed_heartbeat' => 1, 'fix_access' => 1,
			'dedupe_head' => 1, 'clean_words' => 1, 'clean_generator' => 1, 'clean_shortlink' => 1, 'clean_rsd' => 1,
		);
	}

	/** Everything in Easy plus organization data, search-engine pinging and image compression. */
	public static function max_set() {
		return array_merge( self::easy_set(), array(
			'org_schema'       => 1,
			'img_compress'     => 1,
			'speed_preconnect' => 1,
			'trim_description' => 1,
		) );
	}

	public static function apply( $name ) {
		$cur = MRSH_Options::get();
		$set = 'maximum' === $name ? self::max_set() : self::easy_set();
		foreach ( $set as $k => $v ) {
			$cur[ $k ] = $v;
		}
		if ( 'maximum' === $name ) {
			if ( '' === $cur['org_name'] ) {
				$cur['org_name'] = 'My Rishta Pakistan';
			}
			if ( '' === $cur['org_phone'] ) {
				$cur['org_phone'] = '+92-42-29292921';
			}
			if ( '' === $cur['org_email'] ) {
				$cur['org_email'] = 'support@myrishta.pk';
			}
			if ( ! MRSH_IndexNow::valid_key( $cur['indexnow_key'] ) ) {
				$cur['indexnow_key'] = MRSH_IndexNow::new_key();
			}
			$cur['indexnow_enabled'] = 1;
		}
		update_option( MRSH_Options::KEY, $cur );
		if ( class_exists( 'MRSH_Tools' ) && method_exists( 'MRSH_Tools', 'purge_all' ) ) {
			MRSH_Tools::purge_all();
		}
		return count( $set );
	}

	/**
	 * Read pasted text and return [ option_key => code ] pairs plus unknown meta tags.
	 * Understands full <meta> tags, "google-site-verification=CODE" DNS text, and bare name=code lines.
	 */
	public static function parse( $text ) {
		$map   = MRSH_Frontend::verification_map(); // option key => meta name
		$flip  = array_flip( $map );
		$found = array();
		$other = array();
		$pairs = array();
		if ( preg_match_all( '/<meta\s[^>]*>/i', $text, $tags ) ) {
			foreach ( $tags[0] as $t ) {
				if ( preg_match( '/(?:name|property)\s*=\s*["\']([^"\']+)["\']/i', $t, $n ) && preg_match( '/content\s*=\s*["\']([^"\']+)["\']/i', $t, $c ) ) {
					$pairs[] = array( trim( $n[1] ), trim( $c[1] ) );
				}
			}
			$text = preg_replace( '/<meta\s[^>]*>/i', '', $text );
		}
		foreach ( preg_split( '/\r\n|\r|\n/', $text ) as $line ) {
			$line = trim( $line );
			if ( preg_match( '/^([A-Za-z0-9_.:\-]{3,60})\s*[=:]\s*(\S+)$/', $line, $m ) ) {
				$pairs[] = array( $m[1], $m[2] );
			}
		}
		foreach ( $pairs as $p ) {
			list( $name, $val ) = $p;
			$code = MRSH_Options::extract_code( $val );
			if ( false === $code || '' === $code ) {
				continue;
			}
			if ( isset( $flip[ $name ] ) ) {
				$found[ $flip[ $name ] ] = $code;
			} elseif ( 'msvalidate.01' === $name ) {
				$found['bing_verification'] = $code;
			} else {
				$other[ $name ] = $code;
			}
		}
		return array( $found, $other );
	}

	public static function save_codes( $found, $other ) {
		$cur = MRSH_Options::get();
		foreach ( $found as $k => $v ) {
			$cur[ $k ] = $v;
		}
		if ( $other ) {
			$lines = MRSH_Options::lines( $cur['verify_custom'] );
			foreach ( $other as $n => $v ) {
				$lines[] = $n . '=' . $v;
			}
			$cur['verify_custom'] = implode( "\n", array_slice( array_unique( $lines ), 0, 20 ) );
		}
		update_option( MRSH_Options::KEY, $cur );
	}

	/* ---------- admin ---------- */

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 20 );
		add_action( 'admin_post_mrsh_easy', array( __CLASS__, 'handle' ) );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'MyRishta SEO: Easy Setup', 'Easy Setup', 'manage_options', 'mrsh-easy', array( __CLASS__, 'page' ) );
	}

	public static function handle() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_easy' );
		$do  = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
		$msg = '';
		if ( 'easy' === $do || 'maximum' === $do ) {
			$n   = self::apply( $do );
			$msg = ucfirst( $do ) . ' settings applied (' . $n . ' switches). Caches were cleared.';
		} elseif ( 'paste' === $do ) {
			$text = isset( $_POST['paste'] ) ? wp_unslash( $_POST['paste'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			list( $found, $other ) = self::parse( (string) $text );
			if ( $found || $other ) {
				self::save_codes( $found, $other );
				$names = array_map( function ( $k ) {
					return ucfirst( str_replace( '_verification', '', $k ) );
				}, array_keys( $found ) );
				$msg   = 'Saved: ' . ( $names ? implode( ', ', $names ) : 'none' ) . ( $other ? ' and ' . count( $other ) . ' other tag(s)' : '' ) . '. Now open your homepage in a private window and use Test my verification.';
			} else {
				$msg = 'Nothing recognised. Paste the whole meta tag from the search engine, or a line like google-site-verification=CODE.';
			}
		}
		set_transient( 'mrsh_easy_msg', $msg, 60 );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-easy' ) );
		exit;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$msg = get_transient( 'mrsh_easy_msg' );
		if ( $msg ) {
			delete_transient( 'mrsh_easy_msg' );
			echo '<div class="notice notice-success"><p>' . esc_html( $msg ) . '</p></div>';
		}
		$o = MRSH_Options::get();
		MRSH_Admin::open( 'Easy Setup', 'Two one-click presets, and one box that sorts search-engine codes for you.' );
		$btn = function ( $do, $label, $text ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline-block;vertical-align:top;margin:0 16px 16px 0;max-width:420px;background:#fff;border:1px solid #ccd0d4;padding:14px 16px"><input type="hidden" name="action" value="mrsh_easy"><input type="hidden" name="do" value="' . esc_attr( $do ) . '">';
			wp_nonce_field( 'mrsh_easy' );
			echo '<h2 style="margin-top:0">' . esc_html( $label ) . '</h2><p>' . esc_html( $text ) . '</p><p><button class="button button-primary">Apply ' . esc_html( strtolower( $label ) ) . '</button></p></form>';
		};
		$btn( 'easy', 'Easy', 'Turns on the safe, recommended SEO and speed options: clean titles and canonical links, social tags, schema, noindex for login and thin pages, font and image fixes. Does not touch caching.' );
		$btn( 'maximum', 'Maximum', 'Everything in Easy, plus organization details in the structured data (name, phone, email filled only if empty), image compression, preconnect hints, shorter meta descriptions and instant search-engine pinging (IndexNow). Does not turn on the page cache or script deferral, which can clash with LiteSpeed or the theme.' );

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="background:#fff;border:1px solid #ccd0d4;padding:14px 16px;max-width:860px"><input type="hidden" name="action" value="mrsh_easy"><input type="hidden" name="do" value="paste">';
		wp_nonce_field( 'mrsh_easy' );
		echo '<h2 style="margin-top:0">Paste a verification code</h2><p>Paste the full tag or line from Google, Bing, Yandex, Pinterest and others. You can paste several at once. The plugin finds the right field.</p>';
		echo '<textarea name="paste" rows="5" style="width:100%" placeholder="&lt;meta name=&quot;google-site-verification&quot; content=&quot;...&quot; /&gt;&#10;google-site-verification=...&#10;msvalidate.01=..." autocomplete="off"></textarea><p><button class="button button-primary">Save codes</button> <a class="button" href="' . esc_url( admin_url( 'admin.php?page=myrishta-seo-engines' ) ) . '">Open Search Engines page</a></p></form>';

		$have = array();
		foreach ( array_keys( MRSH_Frontend::verification_map() ) as $k ) {
			if ( '' !== $o[ $k ] ) {
				$have[] = ucfirst( str_replace( '_verification', '', $k ) );
			}
		}
		echo '<p>Saved codes: <strong>' . esc_html( $have ? implode( ', ', $have ) : 'none yet' ) . '</strong></p>';
		MRSH_Agent::panel();
		MRSH_Fixes::auto_panel();
		echo '</div>';
	}
}
