<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** First impression: a "Find your match" card, trust points, how-it-works and app promo on the home page; Urdu + English on the main menu; a friendlier sign-in screen. Display only. */
class MRSH_Home {

	public static function init() {
		if ( 'myrishta' === get_option( 'template' ) ) {
			return; // The My Rishta theme has its own home page, menu and footer.
		}
		add_action( 'wp_footer', array( __CLASS__, 'out' ), 50 );
		add_action( 'login_footer', array( __CLASS__, 'out' ), 50 );
		add_action( 'wp_footer', array( __CLASS__, 'profile_urdu' ), 52 );
		add_action( 'wp_footer', array( __CLASS__, 'helper' ), 53 );
		add_action( 'wp_footer', array( __CLASS__, 'covers' ), 54 );
		add_action( 'wp_head', array( __CLASS__, 'soft_css' ), 99 );
		add_action( 'wp_footer', array( __CLASS__, 'soft_js' ), 55 );
	}

	/** Urdu next to the labels and common values on a profile page. Display only. */
	public static function profile_urdu() {
		if ( is_admin() || ! is_singular( 'listing_type' ) ) {
			return;
		}
		echo '<script>' . <<<'MRPROF'
(function(){
 var D={"About Me":"میرے بارے میں","Education":"تعلیم","Education & Work":"تعلیم اور کام","Caste":"ذات / برادری","Status":"حیثیت","Job":"ملازمت","Sector":"شعبہ","City":"شہر","Country":"ملک","Religion":"مذہب","Sect":"مسلک","Age":"عمر","Height":"قد","Occupation":"پیشہ","Nationality":"قومیت","Marital Status":"ازدواجی حیثیت","Children":"بچے","Ethnicity":"نسلی گروہ","Study":"زیر تعلیم","Send Message":"پیغام بھیجیں","Send Wink":"مسکراہٹ بھیجیں","Details":"تفصیلات","Gifts":"تحفے","Share this link via":"شیئر کریں","Or copy link":"یا لنک کاپی کریں","Copy":"کاپی","Recommended For You":"آپ کے لیے تجویز کردہ","Male Unmarried":"مرد · غیر شادی شدہ","Female Unmarried":"خاتون · غیر شادی شدہ","Male Divorced":"مرد · طلاق یافتہ","Female Divorced":"خاتون · طلاق یافتہ","Male Widowed":"مرد · رنڈوا","Female Widowed":"خاتون · بیوہ","Employed":"ملازم","Unemployed":"بے روزگار","Self Employed":"اپنا کاروبار","Student":"طالب علم","Private":"نجی","Government":"سرکاری","Lahore":"لاہور","Karachi":"کراچی","Islamabad":"اسلام آباد","Rawalpindi":"راولپنڈی","Faisalabad":"فیصل آباد","Multan":"ملتان","Peshawar":"پشاور","Quetta":"کوئٹہ","Pakistan":"پاکستان","Rajput":"راجپوت","Arain":"آرائیں","Jatt":"جٹ","Sheikh":"شیخ","Syed":"سید","Mughal":"مغل","Ansari":"انصاری","Qureshi":"قریشی","Malik":"ملک","Gujjar":"گجر","Awan":"اعوان","Pathan":"پٹھان","Baloch":"بلوچ","Muslim":"مسلمان","Suni":"سنی","Sunni":"سنی","Shia":"شیعہ","Single":"غیر شادی شدہ","Unmarried":"غیر شادی شدہ","Divorced":"طلاق یافتہ","Widowed":"رنڈوا / بیوہ","Matric":"میٹرک","Intermediate":"انٹرمیڈیٹ","Bachelors":"بیچلرز","Masters":"ماسٹرز","Male":"مرد","Female":"خاتون"};
 var css='.mrp{font-family:"Noto Nastaliq Urdu","Jameel Noori Nastaleeq",serif;color:#8a6414;font-size:.85em;font-weight:500;margin-inline-start:6px}.mrp.b{display:block;margin:2px 0 0}';
 var st=document.createElement('style');st.textContent=css;document.head.appendChild(st);
 function run(){
  var w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,null),n,L=[];
  while(n=w.nextNode()){var p=n.parentElement;if(!p||/SCRIPT|STYLE|NOSCRIPT|TEXTAREA|INPUT|SELECT|OPTION/.test(p.tagName)||p.closest('.mrp,#wpadminbar'))continue;
   var t=n.nodeValue.replace(/\s+/g,' ').trim();if(!t||!D.hasOwnProperty(t)||p.__mrp)continue;
   if(/[؀-ۿ]/.test(p.textContent))continue;L.push([n,p,t]);}
  L.forEach(function(x){var p=x[1];p.__mrp=1;var s=document.createElement('small');s.className='mrp'+(/^(Send Message|Send Wink)$/.test(x[2])?' b':'');s.textContent=(s.className.indexOf(' b')>0?'':'· ')+D[x[2]];x[0].parentNode.insertBefore(s,x[0].nextSibling);});
 }
 run();var k=0,t=setInterval(function(){run();if(++k>10)clearInterval(t)},900);
})();
MRPROF
		. "</script>\n"; // phpcs:ignore
	}

	/** Floating help button with ready answers in English and Urdu (automatic, not AI). */
	public static function helper() {
		if ( is_admin() ) {
			return;
		}
		echo '<script>' . <<<'MRHELP'
(function(){
 if(window.__mrHelp||/add-listing|wp-login|\/app\/|\/listing\//.test(location.pathname))return;window.__mrHelp=1;
 var Q=[
 ["How do I create a profile?","پروفائل کیسے بنائیں؟","Tap Add Profile, fill a few details (about 3 minutes) and save. You can create it for yourself, a son, daughter or relative. It is free.","«پروفائل بنائیں» دبائیں، چند تفصیلات بھریں (تقریباً 3 منٹ) اور محفوظ کریں۔ اپنے لیے یا بیٹے، بیٹی یا رشتہ دار کے لیے بنا سکتے ہیں۔ بالکل مفت ہے۔","/add-listing/","Add Profile · پروفائل بنائیں"],
 ["Is it really free?","کیا واقعی مفت ہے؟","Yes. MyRishta.pk is run by a non-profit in Lahore. There is no fee to join, browse or message. Never pay anyone who asks for money.","جی ہاں۔ مائی رشتہ لاہور کی غیر منافع بخش تنظیم چلاتی ہے۔ رجسٹر کرنے، دیکھنے یا پیغام بھیجنے کی کوئی فیس نہیں۔ پیسے مانگنے والے کو کبھی رقم نہ دیں۔","",""],
 ["Is my phone number private?","کیا میرا نمبر خفیہ ہے؟","Yes. Your phone number is not shown on your public profile. Share it only when both families agree.","جی ہاں۔ آپ کا نمبر عوامی پروفائل پر نظر نہیں آتا۔ صرف تب شیئر کریں جب دونوں خاندان راضی ہوں۔","",""],
 ["How do I stay safe?","محفوظ کیسے رہوں؟","Never send money. Meet in public with family. Use Report this profile on anything suspicious.","کبھی پیسے نہ بھیجیں۔ خاندان کے ساتھ عوامی جگہ ملیں۔ مشکوک پروفائل پر «Report this profile» استعمال کریں۔","/rishta-safety-tips-avoid-fake-profiles-scams/","Safety tips · حفاظتی ہدایات"],
 ["Find a rishta","رشتہ تلاش کریں","Search by city, age, caste and more. You can browse without an account.","شہر، عمر، ذات وغیرہ سے تلاش کریں۔ اکاؤنٹ کے بغیر بھی دیکھ سکتے ہیں۔","/female-rishta-proposals/","Browse · پروفائلز دیکھیں"],
 ["Install the app","ایپ انسٹال کریں","Open the app and tap Add to Home Screen. It works like a normal app.","ایپ کھولیں اور «Add to Home Screen» دبائیں۔ یہ عام ایپ کی طرح چلتی ہے۔","/app/","Open app · ایپ کھولیں"],
 ["Contact us","رابطہ کریں","Email support@myrishta.pk or use the Contact page.","support@myrishta.pk پر ای میل کریں یا رابطہ صفحہ استعمال کریں۔","/contact/","Contact · رابطہ"]];
 var css='#mrhb{position:fixed;right:14px;bottom:92px;z-index:99990;width:54px;height:54px;border-radius:50%;border:2px solid #d4a94c;background:linear-gradient(135deg,#0a5a32,#063d1d);color:#f7e4a3;font-size:26px;box-shadow:0 8px 22px rgba(0,0,0,.3);cursor:pointer}'+
 '#mrhp{position:fixed;right:12px;bottom:158px;z-index:99991;width:min(360px,calc(100vw - 24px));max-height:70vh;overflow:auto;background:#fff;border-radius:20px;box-shadow:0 18px 50px rgba(0,0,0,.3);display:none;font-family:inherit;color:#0f172a}'+
 '#mrhp.on{display:block}#mrhp .h{background:#063d1d;color:#fff;padding:14px 16px;border-radius:20px 20px 0 0;font-weight:700}#mrhp .h small{display:block;color:#f1deaa;font-weight:400;font-size:12px}'+
 '#mrhp .b{padding:12px}#mrhp .q{display:block;width:100%;text-align:left;margin:0 0 8px;padding:11px 12px;border:1px solid #e7dfc8;border-radius:12px;background:#faf7ec;font-size:14px;cursor:pointer;color:#063d1d;font-weight:600}'+
 '#mrhp .a{background:#f1f5f1;border-radius:12px;padding:12px;margin:0 0 10px;font-size:14px;line-height:1.5}#mrhp .a .u{display:block;margin-top:8px;font-size:17px;line-height:1.9;color:#7a5a12;direction:rtl;text-align:right}'+
 '#mrhp .a a{display:inline-block;margin-top:8px;background:#d4a94c;color:#1c1503;border-radius:999px;padding:8px 14px;font-weight:700;text-decoration:none;font-size:13px}#mrhp .n{font-size:11px;color:#64748b;padding:0 14px 12px}'+
 '@media(min-width:992px){#mrhb{bottom:24px}#mrhp{bottom:90px}}';
 var s=document.createElement('style');s.textContent=css;document.head.appendChild(s);
 var bt=document.createElement('button');bt.id='mrhb';bt.type='button';bt.setAttribute('aria-label','Help · مدد');bt.innerHTML='🤖';
 var pn=document.createElement('div');pn.id='mrhp';
 function esc(t){return t.replace(/[&<>]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;'}[c]})}
 function home(){var h='<div class="h">Help · مدد<small>Quick answers in English and Urdu · انگریزی اور اردو میں</small></div><div class="b">';
  Q.forEach(function(q,i){h+='<button class="q" data-i="'+i+'" type="button">'+esc(q[0])+' · '+esc(q[1])+'</button>'});
  pn.innerHTML=h+'</div><div class="n">Automatic help assistant, not a person or AI. Need a person? Use the Contact page. · خودکار مددگار</div>';}
 pn.addEventListener('click',function(e){var q=e.target.closest('.q');if(q){var x=Q[+q.getAttribute('data-i')];
  pn.innerHTML='<div class="h">'+esc(x[0])+'<small>'+esc(x[1])+'</small></div><div class="b"><div class="a">'+esc(x[2])+'<span class="u">'+esc(x[3])+'</span>'+(x[4]?'<a href="'+x[4]+'">'+esc(x[5])+'</a>':'')+'</div><button class="q" id="mrhback" type="button">← Back · واپس</button></div>';}
  if(e.target.id==='mrhback')home();});
 bt.onclick=function(){pn.classList.toggle('on');if(pn.classList.contains('on'))home();};
 document.body.appendChild(pn);document.body.appendChild(bt);
})();
MRHELP
		. "</script>\n"; // phpcs:ignore
	}

	/** Topic pictures where a post has no photo (instead of the grey placeholder). Display only. */
	public static function covers() {
		if ( is_admin() ) {
			return;
		}
		echo '<script>' . <<<'MRCOV'
(function(){
 var esc=function(t){return String(t).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})};

 var IC={
  shield:'<path d="M0-48 40-32V4C40 30 18 46 0 54-18 46-40 30-40 4V-32z"/><path d="M-16 4l12 12 24-26"/>',
  check:'<rect x="-34" y="-46" width="68" height="92" rx="8"/><path d="M-20-22l8 8 14-16M-20 4l8 8 14-16M-20 30h40"/>',
  doc:'<path d="M-32-46h44l24 24V46h-68z"/><path d="M-18-6h36M-18 10h36M-18 26h24"/>',
  globe:'<circle r="44"/><ellipse rx="18" ry="44"/><path d="M-44 0h88M-38-24h76M-38 24h76"/>',
  city:'<path d="M-44 46V0h26v-30h30V10h32V46z"/><path d="M-30 14h8M-30 28h8M-2-14h8M-2 0h8M-2 14h8M22 24h8"/>',
  chat:'<path d="M-44-34h88V18H-8L-30 40V18h-14z"/><path d="M-28-14h56M-28 2h36"/>',
  heart:'<path d="M0 44C-60 4-44-44 0-20 44-44 60 4 0 44z"/>',
  rings:'<circle cx="-22" r="34"/><circle cx="22" r="34"/>',
  card:'<rect x="-46" y="-30" width="92" height="60" rx="8"/><path d="M-46-10h92M-34 14h28"/>',
  moon:'<path d="M14-46A46 46 0 1 0 14 46 36 36 0 1 1 14-46z"/><path d="M26-8l5 11 12 2-9 8 2 12-10-6-10 6 2-12-9-8 12-2z"/>'};
 function pick(t){t=t.toLowerCase();
  if(/[\u0600-\u06FF]/.test(t))return'moon';
  if(/safe|scam|fake|fraud|warning|genuine/.test(t))return'shield';
  if(/checklist|questions|ask/.test(t))return'check';
  if(/biodata|bio data|format|template|nikah regist|nikahnama|document/.test(t))return'doc';
  if(/uk|usa|canada|saudi|uae|dubai|overseas|abroad|australia/.test(t))return'globe';
  if(/lahore|karachi|islamabad|rawalpindi|faisalabad|multan|peshawar|quetta|city|bahawalpur|sargodha/.test(t))return'city';
  if(/meeting|proposal|reply|say no|talk|etiquette/.test(t))return'chat';
  if(/second marriage|divorc|widow|pehli|doosri/.test(t))return'heart';
  if(/rani|widow|orphan|loan|chhat|support|card|programme|wage|jahez|bari|salami/.test(t))return'card';
  return'rings'}
 var st=document.createElement('style');st.textContent='@media(max-width:767px){.row.d-md-flex.flex-md-row-reverse>.col-3{flex:0 0 36%;max-width:36%}}';document.head.appendChild(st);
 function wrap(t,n,max){var w=t.split(/\s+/),L=[],c='';w.forEach(function(x){if((c+' '+x).trim().length>n&&c){L.push(c);c=x}else c=(c+' '+x).trim()});if(c)L.push(c);if(L.length>max){L=L.slice(0,max);L[max-1]=L[max-1].replace(/[\s,.:;]+\S*$/,'')+'…'}return L}
 function svg(title,small){
  var rtl=/[؀-ۿ]/.test(title),lines=wrap(title,rtl?22:26,3),y=small?0:0;
  var ic=IC[pick(title)];var ring='<g transform="translate('+(small?'200 140':(rtl?'110 150':'600 150'))+') scale('+(small?1.5:1.35)+')" fill="none" stroke="#d4a94c" stroke-width="5" stroke-linecap="round" stroke-linejoin="round">'+ic+'</g>';
  var tx='';if(!small){tx='<g font-family="Poppins,Segoe UI,Tahoma,Arial,sans-serif" fill="#fff" font-weight="700" font-size="'+(rtl?30:29)+'" text-anchor="'+(rtl?'end':'start')+'" direction="'+(rtl?'rtl':'ltr')+'">';
   lines.forEach(function(l,i){tx+='<text x="'+(rtl?'560':'40')+'" y="'+(150+i*42)+'">'+esc(l)+'</text>'});
   tx+='</g><text x="'+(rtl?'560':'40')+'" y="60" font-family="Poppins,Segoe UI,Arial,sans-serif" font-size="15" font-weight="700" fill="#d4a94c" letter-spacing="2" text-anchor="'+(rtl?'end':'start')+'">MY RISHTA PAKISTAN</text>';}
  var s='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 '+(small?'400 300':'700 300')+'"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#063d1d"/><stop offset="1" stop-color="#0d6b38"/></linearGradient></defs><rect width="100%" height="100%" fill="url(#g)"/><path d="M0 285h'+(small?400:700)+'" stroke="#d4a94c" stroke-width="6"/>'+ring+tx+(small?'<path transform="translate(200 238)" fill="#d4a94c" d="M-4-12a12 12 0 1 0 0 24 9 9 0 1 1 0-24z"/>':'')+'</svg>';
  return 'data:image/svg+xml;charset=utf-8,'+encodeURIComponent(s)}
 function run(){[].forEach.call(document.querySelectorAll('img[src*="nophoto"]'),function(i){
  if(i.__mrc)return;i.__mrc=1;var w=i.getBoundingClientRect().width||i.width||300,t=(i.getAttribute('alt')||'').replace(/&#8217;/g,"’").trim();
  i.removeAttribute('srcset');i.src=svg(t||'My Rishta Pakistan',w<150||!t);i.style.objectFit='cover';if(w<150){i.style.aspectRatio='4/3'}else{i.style.aspectRatio='7/3'}});}
 run();var k=0,t=setInterval(function(){run();if(++k>12)clearInterval(t)},800);
})();
MRCOV
		. "</script>\n"; // phpcs:ignore
	}

	/** Soft, rounded panels in the site colours (business-suite look). Display only. */
	public static function soft_css() {
		if ( is_admin() ) {
			return;
		}
		echo '<style id="mrsh-soft">' . <<<'MRSOFT'
:root{--mr-g:#0a5a32;--mr-gd:#063d1d;--mr-gold:#d4a94c;--mr-line:#ece5d0;--mr-soft:0 6px 24px rgba(6,61,29,.08)}
body{background:#f7f4ec}
.card,.card-add-block,.card-body,.widget,.sidebar .card{border-radius:18px!important}
.card,.card-add-block{border:1px solid var(--mr-line)!important;box-shadow:var(--mr-soft)!important;background:#fff}
.card-add-block{padding:0!important;border:0!important;box-shadow:none!important;background:transparent!important}
.card .card-header,.card-header{background:transparent!important;border-bottom:1px solid var(--mr-line)!important}
.btn-secondary,.bg-secondary{background:linear-gradient(135deg,#d4a94c,#b8892f)!important;border-color:transparent!important;color:#1c1503!important}
.btn-secondary:hover{filter:brightness(1.05)}
.title-number{background:linear-gradient(135deg,#0a5a32,#063d1d)!important;color:#f1deaa!important;box-shadow:0 4px 12px rgba(6,61,29,.25)}
.btn,.btn-lg{border-radius:12px!important;font-weight:600;transition:transform .15s ease,box-shadow .15s ease}
.btn:active{transform:scale(.97)}
.btn-primary{background:linear-gradient(135deg,#0a5a32,#063d1d)!important;border-color:transparent!important;color:#fff!important;box-shadow:0 6px 16px rgba(6,61,29,.2)}
.btn-system{background:#fff!important;border:1px solid var(--mr-line)!important;color:#0b3a1d!important;box-shadow:0 2px 8px rgba(6,61,29,.06)}
.form-control,select.form-control,textarea.form-control{border-radius:12px!important;border:1px solid #e3dcc6!important;background:#fcfbf7!important;transition:border-color .15s,box-shadow .15s}
.form-control:focus{border-color:#14703a!important;box-shadow:0 0 0 4px rgba(20,112,58,.12)!important;background:#fff!important;outline:0}
.custom-control-label{cursor:pointer}
.dropdown-menu,.modal-content{border-radius:16px!important;border:1px solid var(--mr-line)!important;box-shadow:0 18px 50px rgba(6,61,29,.18)!important}
.list-info-pop-wrap figure,.ppt-lazy.rounded,img.rounded{border-radius:14px}
hr,.block-header__divider{border-color:var(--mr-line)!important;opacity:.9}
.border.bg-white,.bg-white.border,.border.bg-light{border-radius:16px!important;border-color:var(--mr-line)!important;overflow:hidden}
.mrsh-org .mrsh-org-in{width:100%!important;max-width:1140px!important;margin-left:auto!important;margin-right:auto!important;padding-left:15px!important;padding-right:15px!important;box-sizing:border-box}
@media(max-width:1199px){.mrsh-org .mrsh-org-in{max-width:960px!important}}@media(max-width:991px){.mrsh-org .mrsh-org-in{max-width:720px!important}}@media(max-width:767px){.mrsh-org .mrsh-org-in{max-width:none!important}}
@media(min-width:1400px){.mrsh-org .mrsh-org-in{max-width:1300px!important}}
.footer-txt-dark .textlogo,.footer-txt-dark .textlogo *{white-space:nowrap!important;font-size:clamp(18px,2vw,32px)!important;line-height:1.2!important}
.footer-txt-dark .container{padding-top:22px!important;padding-bottom:6px!important}
.footer-txt-dark p{line-height:1.55!important;margin-bottom:8px!important}
.footer-txt-dark .mb-4{margin-bottom:8px!important}.footer-txt-dark .mb-3{margin-bottom:8px!important}.footer-txt-dark .mt-4{margin-top:10px!important}
.footer-txt-dark .fs-5{margin-bottom:6px!important;font-size:18px}
.footer-txt-dark a small.mru{display:inline!important;margin-left:6px;font-size:.8em}
.footer-txt-dark li,.footer-txt-dark .col-6 a,.footer-txt-dark .col-6 div{line-height:1.6}
.footer-txt-dark .footer-newsletter .form-control{height:42px!important}
.mrsh-org{padding-top:22px!important;padding-bottom:16px!important}
.mrsh-pk-sky{padding-top:22px!important}
/* profile page: tidy the Details list and the gaps around it */
.single-listing_type .elementor-section.elementor-top-section{padding-top:18px!important;padding-bottom:18px!important}
.single-listing_type .ppt-show-hide .card-body{padding:4px 0!important}
.single-listing_type .ppt-show-hide ._content{padding:6px 14px!important}
.single-listing_type .ppt-show-hide .card-header{padding-top:12px!important;padding-bottom:12px!important}
.single-listing_type .ppt-single-datafields nav ul{margin:0!important;padding:0!important}
.single-listing_type .ppt-single-datafields nav ul li{display:flex!important;align-items:baseline;gap:10px;padding:7px 0!important;margin:0!important;line-height:1.4!important;border-bottom:1px solid #f1ebd8}
.single-listing_type .ppt-single-datafields nav ul li:last-child{border-bottom:0}
.single-listing_type .ppt-single-datafields nav ul li>span:first-child{flex:0 0 44%;max-width:44%}
.single-listing_type .ppt-single-datafields nav ul li>span:first-child small.mrp{display:block;font-size:11px;margin:0}
.single-listing_type .ppt-single-datafields nav ul li>span+span{flex:1;min-width:0;font-weight:400}
.single-listing_type .ppt-single-datafields nav ul li.mrsh-empty{display:none!important}
.single-listing_type .card-body.py-4{padding-top:12px!important;padding-bottom:12px!important}
.single-listing_type .ppt-show-hide.mb-4,.single-listing_type .mb-4{margin-bottom:14px!important}
@media(min-width:992px){.single-listing_type .mrsh-wide .ppt-single-datafields nav ul{display:grid!important;grid-template-columns:1fr 1fr;column-gap:36px}}
.single-listing_type #advertising_footer{display:none!important}
.single-breadcrumbs .list-list{display:flex!important;flex-flow:row wrap!important;align-items:flex-start;gap:4px 14px}.single-breadcrumbs .list-list>span{display:inline-block!important;width:auto!important;float:none!important;vertical-align:top}
@media(max-width:767px){form select.form-control,form input.form-control,form textarea.form-control,form select{font-size:16px!important;min-height:48px}form select.form-control{padding-right:2.2rem}}
/* smooth polish */
html{-webkit-text-size-adjust:100%;scroll-padding-top:96px}
body{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;text-rendering:optimizeLegibility}
a,button,.btn,.form-control,select,.cardbox,.card,.mrh-card,.mrh-row select{transition:color .2s ease,background-color .2s ease,border-color .2s ease,box-shadow .28s cubic-bezier(.2,.8,.2,1),transform .28s cubic-bezier(.2,.8,.2,1),opacity .2s ease}
.btn,button.btn-system,.btn-system,a.btn-secondary.rounded-pill{border-radius:14px}
.btn:hover,.btn-system:hover,a.btn-secondary.rounded-pill:hover{transform:translateY(-1px);box-shadow:0 8px 22px rgba(6,61,29,.16)}
.btn:active,.btn-system:active,a.btn-secondary.rounded-pill:active{transform:scale(.98);box-shadow:0 2px 8px rgba(6,61,29,.12)}
.card,.mrh-card,.cardbox,.list-info-pop-wrap,.ppt-modal-item{border-radius:18px}
.card,.mrh-card{box-shadow:0 1px 2px rgba(15,23,42,.04),0 10px 30px rgba(15,23,42,.06)!important;border-color:rgba(15,23,42,.06)!important}
.card:hover,.mrh-card:hover{box-shadow:0 2px 4px rgba(15,23,42,.05),0 16px 40px rgba(15,23,42,.09)!important}
header,.navbar{background-color:rgba(255,255,255,.82)!important;-webkit-backdrop-filter:saturate(1.8) blur(18px);backdrop-filter:saturate(1.8) blur(18px)}
:focus-visible{outline:3px solid rgba(20,112,58,.38);outline-offset:2px;border-radius:10px}
::selection{background:rgba(212,169,76,.32)}
img,video{max-width:100%}
@media (prefers-reduced-motion:reduce){*,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important;scroll-behavior:auto!important}}
MRSOFT
		. "</style>\n"; // phpcs:ignore
		if ( is_front_page() ) {
			// Hide at once what the page script hides later, and keep room for the pills it adds, so nothing jumps while loading.
			echo '<style id="mrsh-cls">.elementor-element-625d3191,.elementor-element-65721fe4{display:none!important}.hero1 .h1buttonbox:not(:has(+ .mr-chips))::after{content:"";display:block;height:100px}.elementor-widget-container:has(> [data-ppt-blockid="listings100"]):not(:has(> .mrh-top))::before{content:"";display:block;height:610px}@media(max-width:389px){.elementor-widget-container:has(> [data-ppt-blockid="listings100"]):not(:has(> .mrh-top))::before{height:670px}}@media(min-width:601px){.elementor-widget-container:has(> [data-ppt-blockid="listings100"]):not(:has(> .mrh-top))::before{height:465px}}@media(min-width:992px){.elementor-widget-container:has(> [data-ppt-blockid="listings100"]):not(:has(> .mrh-top))::before{height:415px}}</style>' . "\n"; // phpcs:ignore
		}
	}

	public static function soft_js() {
		if ( is_admin() ) {
			return;
		}
		echo '<script>' . <<<'MRSOFTJS'
(function(){
 function soft(){[].forEach.call(document.querySelectorAll('div,section,article,aside'),function(e){
  if(e.__ms)return;var r=e.getBoundingClientRect();if(r.width<160||r.height<44||r.width>1180)return;
  var c=getComputedStyle(e);if(c.borderTopWidth==='0px'&&c.boxShadow==='none')return;
  var rad=parseFloat(c.borderTopLeftRadius)||0;if(rad>=12)return;if(/rgb\(\s*(0|1|2|3|4|5|6|7|8|9)\d?,/.test(c.backgroundColor)&&false)return;
  if(c.backgroundColor==='rgba(0, 0, 0, 0)'&&c.boxShadow==='none')return;
  e.__ms=1;e.style.borderRadius='16px';if(c.borderTopWidth!=='0px'&&/^rgb\((2[0-4]\d|1[5-9]\d)/.test(c.borderTopColor))e.style.borderColor='#ece5d0';
  if(c.overflow==='visible')e.style.overflow='hidden';});}
 soft();var k=0,t=setInterval(function(){soft();if(++k>8)clearInterval(t)},1000);
 (function(){var d=document.querySelector('.ppt-single-datafields nav ul');if(!d)return;
  var li=[].slice.call(d.children);
  li.forEach(function(x,i){var n=li[i+1];if(x.classList.contains('title')&&!x.querySelector('span+span')&&(!n||n.classList.contains('title')))x.classList.add('mrsh-empty')});
  var age=d.querySelector('.li-data-daage span+span');if(age&&/dagender/.test((age.innerHTML||''))){var m=(document.body.innerText||'').match(/\b(?:Male|Female)\s*,\s*(\d{2})\b/);if(m)age.textContent=m[1]}
 })();
(function(){
 if(innerWidth<992)return;
 var ws=[].slice.call(document.querySelectorAll('.elementor-widget')),dw=null,aw=null;
 ws.forEach(function(w){var h=w.querySelector('.card-header');var t=(h&&h.textContent||'').trim();
  if(!dw&&/^Details/.test(t)&&w.querySelector('.ppt-single-datafields'))dw=w;});
 ws.forEach(function(w){if(aw||w===dw)return;var h=w.querySelector('.card-header,h3,h4,.card-header *');var t=(w.textContent||'').trim();
  if(/^About Me/.test(t)&&w.querySelectorAll('.elementor-widget').length===0)aw=w;});
 if(!dw||!aw||dw.__mv)return;dw.__mv=1;
 aw.parentNode.insertBefore(dw,aw.nextSibling);dw.classList.add('mrsh-wide');
 var b=dw.querySelector('.ppt-show-hide');if(b&&!b.classList.contains('show')){var h=b.querySelector('.card-header');if(h)h.click();setTimeout(function(){if(!b.classList.contains('show'))b.className+=' show'},300);}
})();
})();
MRSOFTJS
		. "</script>\n"; // phpcs:ignore
	}

	public static function out() {
		if ( is_admin() ) {
			return;
		}
		$on_home = function_exists( 'is_front_page' ) && ( is_front_page() || is_home() );
		$top     = $on_home ? <<<'MRTOP'
<style>
.mrh{font-family:inherit;color:#0f172a}
.mrh *{box-sizing:border-box}
.mrh-wrap{max-width:1140px;margin:0 auto;padding:0 16px}
.mrh-find{margin-top:-46px;position:relative;z-index:5}
.mrh-card{background:#fff;border-radius:20px;box-shadow:0 14px 40px rgba(6,61,29,.22);padding:20px;border:1px solid #e7dfc8}
.mrh-card h2{margin:0 0 4px;font-size:22px;color:#063d1d}
.mrh-card p.s{margin:0 0 14px;color:#475569;font-size:14px}
.mrh-tog{display:flex;gap:10px;margin-bottom:12px}
.mrh-tog button{flex:1;padding:14px 10px;border-radius:14px;border:2px solid #14532d;background:#fff;color:#14532d;font-weight:700;font-size:16px;cursor:pointer}
.mrh-tog button.on{background:#14532d;color:#fff}
.mrh-row{display:flex;gap:10px;flex-wrap:wrap}
.mrh-row select{flex:1 1 180px;padding:14px;border-radius:14px;border:1.5px solid #cbd5e1;font-size:16px;background:#fff}
.mrh-go{flex:1 1 100%;padding:16px;border:0;border-radius:14px;background:linear-gradient(135deg,#d4a94c,#b8892f);color:#1c1503;font-weight:800;font-size:17px;cursor:pointer}
.mrh-trust{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin:22px 0}
.mrh-trust div{background:#f6f3ea;border-radius:16px;padding:14px;display:flex;gap:10px;align-items:flex-start;font-size:14px;line-height:1.35}
.mrh-trust svg{flex:0 0 26px;width:26px;height:26px;color:#14532d}
.mrh-trust b{display:block;font-size:15px;color:#063d1d}
.mrh h3.t{font-size:26px;margin:34px 0 6px;color:#063d1d}
.mrh .u{display:block;font-size:18px;color:#7a5b12;margin-bottom:10px}
.mrh-steps{display:grid;gap:12px;margin:12px 0 8px}
.mrh-steps div{display:flex;gap:14px;align-items:flex-start;background:#fff;border:1px solid #e7dfc8;border-radius:16px;padding:16px}
.mrh-steps i{flex:0 0 38px;height:38px;border-radius:50%;background:#14532d;color:#fff;display:flex;align-items:center;justify-content:center;font-style:normal;font-weight:800}
.mrh-steps b{display:block;color:#063d1d;font-size:16px}
.mrh-app{margin:30px 0;background:linear-gradient(135deg,#063d1d,#0f5a2d);border-radius:22px;color:#fff;padding:24px;display:flex;gap:20px;align-items:center;flex-wrap:wrap}
.mrh-app h3{margin:0 0 6px;font-size:24px;color:#fff}
.mrh-app p{margin:0 0 14px;color:#dbe9df;font-size:15px}
.mrh-app a.b{display:inline-block;background:#d4a94c;color:#1c1503;font-weight:800;padding:14px 22px;border-radius:14px;text-decoration:none}
.mrh-app ul{margin:0;padding:0;list-style:none;display:grid;gap:6px;font-size:14px;color:#e6f1ea}
.mrh-safe{margin:10px 0 36px;border:2px dashed #d4a94c;border-radius:18px;padding:16px 18px;background:#fffbea;font-size:15px}
.mrh-safe a{color:#14532d;font-weight:700}
@media(min-width:768px){.mrh-trust{grid-template-columns:repeat(4,1fr)}.mrh-steps{grid-template-columns:repeat(3,1fr)}.mrh-card{padding:28px}.mrh-row select{flex:1 1 0}.mrh-go{flex:0 0 220px}.mrh-app{padding:32px 40px}.mrh-app>div:first-child{flex:1 1 380px}}
</style>
<div class="mrh mrh-top"><div class="mrh-wrap mrh-find"><div class="mrh-card">
<h2>Find your match<small style="display:block;font-size:19px;color:#7a5b12;margin-top:2px">اپنا رشتہ تلاش کریں</small></h2>
<p class="s">Free to browse. Your phone number stays private.</p>
<div class="mrh-tog"><button type="button" data-g="female" class="on">Bride · دلہن</button><button type="button" data-g="male">Groom · دولہا</button></div>
<div class="mrh-row"><select id="mrh-where" aria-label="City or country">
<option value="">Anywhere · کہیں بھی</option><option value="rishta-lahore">Lahore · لاہور</option><option value="rishta-karachi">Karachi · کراچی</option><option value="rishta-islamabad-rawalpindi">Islamabad / Rawalpindi · اسلام آباد / راولپنڈی</option><option value="rishta-faisalabad-multan-punjab">Faisalabad / Multan / Punjab · پنجاب</option><option value="rishta-peshawar-quetta">Peshawar / Quetta · پشاور / کوئٹہ</option><option value="rishta-overseas-pakistanis">Overseas Pakistanis · بیرونِ ملک</option></select>
<button type="button" class="mrh-go" id="mrh-go">Show proposals · رشتے دیکھیں</button></div></div>
<div class="mrh-trust">
<div><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/></svg><span><b>100% Free</b>No fee, ever. Non-profit from Lahore.</span></div>
<div><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/></svg><span><b>Phone stays private</b>Only you can see your number.</span></div>
<div><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M8 12l3 3 5-6"/></svg><span><b>Verified badges</b>Look for the green verified tick.</span></div>
<div><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 21s-7-4.5-7-10a4 4 0 017-2.5A4 4 0 0119 11c0 5.5-7 10-7 10z"/></svg><span><b>Family friendly</b>Create a profile for a son, daughter or relative.</span></div>
</div></div></div>
MRTOP
		: '';
		$bot     = $on_home ? <<<'MRBOT'
<div class="mrh mrh-bottom"><div class="mrh-wrap">
<h3 class="t">How it works <span class="u">یہ کیسے کام کرتا ہے</span></h3>
<div class="mrh-steps">
<div><i>1</i><span><b>Create a free profile · مفت پروفائل بنائیں</b>Add a few details in under 3 minutes, for yourself or a family member.</span></div>
<div><i>2</i><span><b>Browse and match · رشتے دیکھیں</b>See suggested matches by age, study, caste, job and city.</span></div>
<div><i>3</i><span><b>Connect safely · محفوظ رابطہ</b>Send a message. Share contact details only when both families agree.</span></div>
</div>
<div class="mrh-app"><div><h3>Get the My Rishta App</h3><p>Fast, tiny and made for your phone. Swipe through profiles, save favourites and get matches.</p><a class="b" href="/app/">Open the app · ایپ کھولیں</a></div>
<ul><li>✓ Loads in a blink, even on slow internet</li><li>✓ Add to your home screen like a real app</li><li>✓ Swipe, save, share, print a biodata</li></ul></div>
<div class="mrh-safe"><b>Stay safe.</b> Never send money to anyone. We are free and never ask for payment. <a href="/public-notice-fake-accounts/">Read the notice</a> · <a href="/rishta-safety-tips-avoid-fake-profiles-scams/">Safety tips</a> · Use <b>Report this profile</b> on any profile.</div>
</div></div>
MRBOT
		: '';
		$n = wp_count_posts( 'listing_type' ); $n = $n ? (int) $n->publish : 0; $n = $n >= 50 ? (int) ( floor( $n / 50 ) * 50 ) : 0;
		echo '<script>window.MR_N={profiles:' . $n . '};var TOP=' . wp_json_encode( $top ) . ',BOT=' . wp_json_encode( $bot ) . ';' . <<<'MRJS'
(function(){
 var UI={"Add Profile": "پروفائل بنائیں", "Start Search": "تلاش کریں", "Featured Profiles": "نمایاں پروفائلز", "Home": "ہوم", "Search": "تلاش", "Contact": "رابطہ", "Blog": "بلاگ", "Sign In": "لاگ اِن", "Register": "رجسٹر", "About Us": "ہمارے بارے میں", "View More": "مزید دیکھیں", "My Account": "میرا اکاؤنٹ", "Meet someone new today": "آج کسی نئے سے ملیں", "FEATURED": "نمایاں", "NEW": "نیا", "How it works": "یہ کیسے کام کرتا ہے", "FAQ": "سوالات", "Privacy Policy": "پرائیویسی پالیسی", "Terms": "شرائط", "Terms and Conditions": "شرائط و ضوابط", "Success Stories": "کامیاب کہانیاں", "Latest Profiles": "تازہ پروفائلز", "Female Proposals": "خواتین کے رشتے", "Male Proposals": "مردوں کے رشتے", "Pakistan Rishta": "پاکستان رشتہ", "Services": "سروسز", "Service For You": "آپ کے لیے سروس", "My Rishta Providing free service for all Pakistan": "پورے پاکستان کے لیے مفت سروس"};
 function tx(){
  var w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,{acceptNode:function(n){var p=n.parentElement;if(!p||/^(SCRIPT|STYLE|TEXTAREA|OPTION|SELECT|NOSCRIPT|INPUT)$/.test(p.tagName)||p.closest('form,.mrh,#wpadminbar'))return NodeFilter.FILTER_REJECT;return NodeFilter.FILTER_ACCEPT}}),n,list=[];
  while((n=w.nextNode())){var k=n.nodeValue.replace(/\s+/g,' ').trim();if(UI[k]&&!n.__mr)list.push([n,k]);}
  list.forEach(function(x){var nd=x[0],p=nd.parentElement;nd.__mr=1;
   if(p.closest('h1,h2,h3,h4,h5,p')&&!p.closest('a,button')){nd.nodeValue=nd.nodeValue.replace(x[1],x[1]+' · '+UI[x[1]]);return;}
   var s=document.createElement('small');s.className='mru';s.textContent=UI[x[1]];nd.parentNode.insertBefore(s,nd.nextSibling);});
 }
 function block(){
  if(document.querySelector('.mrh-top'))return true;
  var h=[].slice.call(document.querySelectorAll('h1,h2,h3,h4')).filter(function(e){return /Featured Profiles/i.test(e.textContent)&&!e.closest('.mrh')})[0];if(!h)return false;
  var sec=h.closest('section,.elementor-section,.elementor-top-section')||h.parentElement;
  sec.insertAdjacentHTML('beforebegin',TOP);sec.insertAdjacentHTML('afterend',BOT);
  var g='female',t=document.querySelector('.mrh-tog');
  t.addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;[].forEach.call(t.children,function(x){x.classList.remove('on')});b.classList.add('on');g=b.getAttribute('data-g');});
  document.getElementById('mrh-go').addEventListener('click',function(){var v=document.getElementById('mrh-where').value;location.href='/'+(v||g+'-rishta-proposals')+'/';});
  return true;
 }
 var n=0,t=setInterval(function(){var ok=block();tx();if(ok&&++n>8||n>30)clearInterval(t);if(!ok)n+=0.34;},700);
 tx();

 (function(){var st=document.createElement('style');st.textContent='.mru{display:block;font-size:.72em;font-weight:600;opacity:.92;line-height:1.25;margin-top:1px;font-family:inherit}#mobile-bottom-bar .mru{font-size:10px}';document.head.appendChild(st);})();
 // ---- Login screen ----
 (function(){
  var u=document.querySelector('input[name=log]'),p=document.querySelector('input[name=pwd]');if(!u||!p||document.getElementById('mr-login'))return;
  var form=u.closest('form'),card=form.closest('div[class*=card],div[class*=login],body>div')||form.parentElement;
  var s=document.createElement('style');s.textContent=
   '#mr-login{text-align:center;margin:4px 0 16px}#mr-login h1{margin:0;font-size:26px;color:#063d1d;line-height:1.25}#mr-login p{margin:6px 0 0;color:#475569;font-size:15px}#mr-login .ur{display:block;font-size:20px;color:#7a5b12;margin-top:2px}'+
   'input[name=log],input[name=pwd]{height:54px!important;font-size:17px!important;border-radius:14px!important}'+
   'input[name=wp-submit],form button[type=submit],form input[type=submit]{height:54px!important;font-size:17px!important;font-weight:800!important;border-radius:14px!important;background:#14532d!important;border-color:#14532d!important;color:#fff!important}'+
   '#mr-ltrust{display:flex;gap:8px;flex-wrap:wrap;justify-content:center;margin:14px 0 4px;font-size:13px;color:#14532d}#mr-ltrust span{background:#f1f7f3;border-radius:999px;padding:6px 12px;font-weight:600}';
  document.head.appendChild(s);
  var h=document.createElement('div');h.id='mr-login';h.innerHTML='<img src="/app/mark.svg" width="64" height="64" alt="My Rishta" style="display:block;margin:0 auto 8px"><h1>Welcome back<span class="ur">خوش آمدید</span></h1><p>Sign in to see your messages and matches.<br>اپنے پیغامات اور رشتے دیکھنے کے لیے لاگ اِن کریں۔</p>';
  var first=[].slice.call(document.querySelectorAll('h1,h2,h3,.fs-md')).filter(function(e){return /^\s*Sign In/i.test(e.textContent)})[0];
  if(first){first.style.display='none';first.insertAdjacentElement('beforebegin',h);}else{form.insertAdjacentElement('beforebegin',h);}
  u.placeholder='Email · ای میل';p.placeholder='Password · پاس ورڈ';u.setAttribute('autocomplete','username');p.setAttribute('autocomplete','current-password');u.setAttribute('inputmode','email');
  [].forEach.call(document.querySelectorAll('a,button,input[type=submit]'),function(e){var t=(e.value||e.textContent).replace(/\s+/g,' ').trim(),m={'Lost password?':'Lost password? · پاس ورڈ بھول گئے؟','Sign Up':'Sign Up · نیا اکاؤنٹ','Login with Google':'Login with Google · گوگل سے لاگ اِن','SIGN IN':'SIGN IN · لاگ اِن','Sign in':'Sign in · لاگ اِن','Or Continue with Email':'Or continue with email · یا ای میل سے'};if(m[t]){if(e.tagName==='INPUT')e.value=m[t];else if(e.children.length===0)e.textContent=m[t];}});
  var tr=document.createElement('div');tr.id='mr-ltrust';tr.innerHTML='<span>100% Free · مفت</span><span>Private · محفوظ</span><span>Non-profit · غیر منافع بخش</span>';
  form.insertAdjacentElement('afterend',tr);
 })();
})();
(function(){
 if(!document.querySelector('.hero1'))return;
 var css='#advertising_footer{margin-bottom:0!important;padding-bottom:0!important}#advertising_footer .py-4{padding-top:8px!important;padding-bottom:8px!important}#advertising_footer:has(ins[data-ad-status="unfilled"]){display:none!important}'+
 'img[src*="MyRishta-Cupple"]{max-height:330px;width:auto!important;max-width:100%;height:auto!important;object-fit:contain;margin:0 auto;display:block}@media(max-width:767px){img[src*="MyRishta-Cupple"]{max-height:230px}}.row.y-middle:has(img[src*="MyRishta-Cupple"]) h2{font-size:clamp(20px,2.6vw,28px)!important;line-height:1.3}'+
 '.hero1 .h1buttonbox a{flex-wrap:wrap;align-content:center}.hero1 .h1buttonbox a small{flex-basis:100%;text-align:center;line-height:1.1}'+
 '.mrh .mrh-wrap{width:100%;max-width:none;padding-left:15px;padding-right:15px}@media(min-width:576px){.mrh .mrh-wrap{max-width:540px}}@media(min-width:768px){.mrh .mrh-wrap{max-width:720px}}@media(min-width:992px){.mrh .mrh-wrap{max-width:960px}}@media(min-width:1200px){.mrh .mrh-wrap{max-width:1140px}}@media(min-width:1400px){.mrh .mrh-wrap{max-width:1300px}}'+
 'section.section-60{padding-top:28px!important;padding-bottom:28px!important}section.section-40{padding-top:20px!important;padding-bottom:20px!important}.container.py-4.pt-5{padding-top:24px!important}.mrh-top{margin-bottom:0!important}'+
 'a.btn-secondary.rounded-pill[href*="add-listing"] small{color:#3a2a05!important}header,.navbar{backdrop-filter:saturate(1.4) blur(8px)}html{scroll-behavior:smooth}::selection{background:#d4a94c;color:#1c1503}a,button{-webkit-tap-highlight-color:transparent}img{image-rendering:auto}'+
 '.list-info-pop-wrap .buttons-wrap{right:10px!important;left:auto!important}.list-info-pop-wrap .button-featured{margin-right:0!important}"'+
 '"a.btn-secondary.rounded-pill[href*="add-listing"]{background:linear-gradient(135deg,#d4a94c,#b8892f)!important;border:0!important;color:#1c1503!important;font-weight:700;box-shadow:0 6px 16px rgba(184,137,47,.35)}"'+
 '".hero1 .container{padding-left:16px;padding-right:16px}'+
 '.mrh-top+*,.mrh-top~section{margin-top:0!important}.d-md-flex.mobile-mt-4{margin-top:10px!important}section.py-5,section.py-6,.py-6{padding-top:28px!important;padding-bottom:28px!important}.mrh{margin-top:14px!important;margin-bottom:14px!important}'+
 '.list-info-pop-wrap figure{border-radius:18px!important;box-shadow:0 6px 22px rgba(6,61,29,.14)!important;transition:transform .25s ease,box-shadow .25s ease}'+
 '.list-info-pop-wrap:hover figure{transform:translateY(-4px);box-shadow:0 14px 30px rgba(6,61,29,.22)!important}'+
 '.list-info-pop-wrap .button-featured{background:linear-gradient(135deg,#d4a94c,#b8892f)!important;color:#1c1503!important;border-radius:999px!important;font-weight:800;letter-spacing:.02em}'+
 '.mr-av{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;background:radial-gradient(circle at 50% 35%,#14703a 0,#0a4a25 55%,#063d1d 100%);color:#d4a94c;z-index:0}'+
 '.mr-av b{width:92px;height:92px;border-radius:50%;border:3px solid #d4a94c;display:flex;align-items:center;justify-content:center;font-size:44px;font-weight:800;background:rgba(255,255,255,.06)}'+
 '.mr-av span{font-size:13px;color:#e9dcae;display:flex;gap:6px;align-items:center}'+
 '.mr-lock .bg-image{display:none!important}'+
 '.mr-rv{opacity:0;transform:translateY(18px);transition:opacity .6s ease,transform .6s ease}.mr-rv.in{opacity:1;transform:none}'+
 '.mr-chips{display:flex;flex-wrap:wrap;gap:8px;margin-top:18px}.mr-chips span{background:rgba(255,255,255,.14);border:1px solid rgba(255,255,255,.28);color:#fff;border-radius:999px;padding:7px 14px;font-size:13px;font-weight:600;backdrop-filter:blur(4px)}'+
 '.hero1 .h1buttonbox a{box-shadow:0 8px 22px rgba(0,0,0,.28);transition:transform .2s}.hero1 .h1buttonbox a:active{transform:scale(.97)}'+
 '@media(prefers-reduced-motion:reduce){.mr-rv{opacity:1;transform:none;transition:none}.list-info-pop-wrap figure{transition:none}}';
 var s=document.createElement('style');s.textContent=css;document.head.appendChild(s);
 function fix(){
  [].forEach.call(document.querySelectorAll('.list-info-pop-wrap'),function(c){
   if(c.__mr)return;c.__mr=1;
   var bg=c.querySelector('.bg-image'),u=bg&&(bg.getAttribute('data-mrsh-bg')||bg.getAttribute('style')||'');
   if(u&&/Locked/i.test(u)||!bg){var box=c.querySelector('.bg-light');if(!box)return;c.classList.add('mr-lock');
    var nm=(c.querySelector('.text-600')||{}).textContent||'?';nm=nm.trim();var d=document.createElement('div');d.className='mr-av';
    d.innerHTML='<b>'+(nm.charAt(0)||'?').toUpperCase().replace(/[<>&]/g,'')+'</b><span>🔒 Photo is private · تصویر نجی ہے</span>';box.appendChild(d);}
  });
 }
 var chips=function(){
  var b=document.querySelector('.hero1 .h1buttonbox');if(!b||document.querySelector('.mr-chips'))return;
  var n=(window.MR_N&&window.MR_N.profiles)||0,h='';
  if(n>0)h+='<span>'+n+'+ profiles · پروفائلز</span>';
  h+='<span>100% Free · مفت</span><span>Phone private · نمبر خفیہ</span>';
  var d=document.createElement('div');d.className='mr-chips';d.innerHTML=h;b.insertAdjacentElement('afterend',d);
 };
 function reveal(){
  if(!('IntersectionObserver' in window))return;
  var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target);}})},{threshold:.12});
  [].forEach.call(document.querySelectorAll('.mrh-card,.mrh-trust div,.mrh-steps div,.mrh-app,.mrh-safe,.list-info-pop-wrap'),function(e){if(e.__rv)return;e.__rv=1;e.classList.add('mr-rv');io.observe(e);});
 }
 var al=function(){var h=document.querySelector('.hero1 .container');if(h){h.style.setProperty('padding-left','15px','important');h.style.setProperty('padding-right','15px','important')}var f=[].slice.call(document.querySelectorAll('h2')).filter(function(e){return /Featured Profiles/.test(e.textContent)})[0];var c=f&&f.closest('.container');if(c){c.style.setProperty('padding-left','15px','important');c.style.setProperty('padding-right','15px','important')}};al();setTimeout(al,1500);
 var dd=function(){var hs=[].slice.call(document.querySelectorAll('h2')).filter(function(e){return /Featured Profiles/.test(e.textContent)});for(var i=1;i<hs.length;i++){var sec=hs[i].closest('.elementor-top-section')||hs[i].closest('section');if(sec)sec.style.setProperty('display','none','important')}};var cc=function(){[].slice.call(document.querySelectorAll('h1,h2,h3,h4,div,p')).forEach(function(e){if(e.children.length<3&&/^\s*Create your free account today!?\s*$/.test(e.textContent)){var sec=e.closest('.elementor-top-section')||e.closest('section');if(sec)sec.style.setProperty('display','none','important')}})};dd();cc();setTimeout(cc,1200);setTimeout(cc,3000);setTimeout(dd,1200);setTimeout(dd,3000);
 var ad=function(){var s=document.getElementById('advertising_footer');if(!s)return;var i=s.querySelector('ins');if(!i||i.getAttribute('data-ad-status')==='unfilled'||!i.querySelector('iframe'))s.style.setProperty('display','none','important')};setTimeout(ad,6000);setTimeout(ad,10000);
 var hb=function(){[].forEach.call(document.querySelectorAll('a[href*="add-listing"].btn-secondary'),function(a){a.style.setProperty('background','linear-gradient(135deg,#d4a94c,#b8892f)','important');a.style.setProperty('border','0','important');a.style.setProperty('color','#1c1503','important');a.style.setProperty('box-shadow','0 6px 16px rgba(184,137,47,.35)','important')})};hb();
 var k=0,t=setInterval(hb,1500);setTimeout(function(){clearInterval(t)},9000);var k=0,t2=setInterval(function(){fix();chips();reveal();if(++k>14)clearInterval(t2)},800);fix();chips();
})();
MRJS
		. "</script>\n"; // phpcs:ignore
	}
}
