<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Database tidy: finds clutter left behind by plugins that were removed, expired temporary data and orphan rows.
 * Options of a removed plugin are backed up to a private file first and can be put back with one button.
 * Nothing that belongs to an active plugin, to this plugin or to the theme is ever touched.
 */
class MRSH_DbTidy {

	const DIR = 'mrsh-tidy';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 44 );
		foreach ( array( 'opts', 'trans', 'orph', 'restore' ) as $a ) {
			add_action( 'admin_post_mrsh_tidy_' . $a, array( __CLASS__, 'act_' . $a ) );
		}
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Database tidy', 'Database tidy', 'manage_options', 'mrsh-dbtidy', array( __CLASS__, 'page' ) );
	}

	/** Leftover groups: label => array( option-name regex, folder of the plugin that owns them ). */
	private static function groups() {
		return array(
			'WooCommerce'          => array( '/^(woocommerce_|wc_|_transient_wc_|_transient_timeout_wc_)/', 'woocommerce' ),
			'Yoast SEO'            => array( '/^(wpseo|yoast|_yoast)/', 'wordpress-seo' ),
			'SEOPress'             => array( '/^seopress_/', 'wp-seopress' ),
			'All in One SEO'       => array( '/^(aioseo_|widget_aioseo)/', 'all-in-one-seo-pack' ),
			'MonsterInsights'      => array( '/^(monsterinsights_|widget_monsterinsights)/', 'google-analytics-for-wordpress' ),
			'OptinMonster'         => array( '/^(optin_monster|optinmonster|omapi_|widget_optin)/', 'optinmonster' ),
			'Elementor'            => array( '/^_?elementor_/', 'elementor' ),
			'WPForms'              => array( '/^(_?wpforms|widget_wpforms|_wpforms_transient)/', 'wpforms-lite' ),
			'Image Optimizer'      => array( '/^image_optimizer_/', 'image-optimization' ),
			'The SEO Framework'    => array( '/^the_seo_framework/', 'autodescription' ),
			'SEO Fury'             => array( '/^seo_fury/', 'seo-fury' ),
			'Google XML Sitemaps'  => array( '/^sm_options$/', 'google-sitemap-generator' ),
		);
	}

	private static function plugin_active( $folder ) {
		foreach ( (array) get_option( 'active_plugins', array() ) as $p ) {
			if ( 0 === strpos( (string) $p, $folder . '/' ) ) {
				return true;
			}
		}
		return false;
	}

	/** group => list of option rows that are safe to remove. */
	public static function scan_options() {
		global $wpdb;
		$rows = $wpdb->get_results( "SELECT option_name, LENGTH(option_value) AS n FROM {$wpdb->options}" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$out  = array();
		foreach ( self::groups() as $label => $g ) {
			if ( self::plugin_active( $g[1] ) ) {
				continue;
			}
			foreach ( (array) $rows as $r ) {
				if ( preg_match( $g[0], $r->option_name ) ) {
					$out[ $label ][] = array( 'name' => $r->option_name, 'size' => (int) $r->n );
				}
			}
		}
		return $out;
	}

	public static function count_expired() {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE %s AND CAST(option_value AS UNSIGNED) < %d", $wpdb->esc_like( '_transient_timeout_' ) . '%', time() ) ); // phpcs:ignore WordPress.DB
	}

	public static function count_orphans() {
		global $wpdb;
		$a = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->postmeta} pm LEFT JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE p.ID IS NULL" ); // phpcs:ignore WordPress.DB
		$b = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->usermeta} um LEFT JOIN {$wpdb->users} u ON u.ID = um.user_id WHERE u.ID IS NULL" ); // phpcs:ignore WordPress.DB
		$c = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->commentmeta} cm LEFT JOIN {$wpdb->comments} c ON c.comment_ID = cm.comment_id WHERE c.comment_ID IS NULL" ); // phpcs:ignore WordPress.DB
		return array( $a, $b, $c );
	}

	private static function dir() {
		$u = wp_upload_dir();
		$d = trailingslashit( $u['basedir'] ) . self::DIR;
		if ( ! is_dir( $d ) ) {
			wp_mkdir_p( $d );
			file_put_contents( $d . '/.htaccess', "Require all denied\nDeny from all\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			file_put_contents( $d . '/index.php', "<?php\n// Silence.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		}
		return $d;
	}

	private static function backups() {
		$f = glob( self::dir() . '/tidy-*.json' );
		if ( ! $f ) {
			return array();
		}
		rsort( $f );
		return $f;
	}

	/* ---------- actions ---------- */

	private static function guard( $a ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_tidy_' . $a );
	}

	private static function back( $msg ) {
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-dbtidy&msg=' . rawurlencode( $msg ) ) );
		exit;
	}

	public static function act_opts() {
		self::guard( 'opts' );
		$all = self::scan_options();
		$bk  = array();
		foreach ( $all as $label => $list ) {
			foreach ( $list as $r ) {
				$v = get_option( $r['name'], null );
				if ( null === $v ) {
					continue;
				}
				global $wpdb;
				$al  = $wpdb->get_var( $wpdb->prepare( "SELECT autoload FROM {$wpdb->options} WHERE option_name = %s", $r['name'] ) ); // phpcs:ignore WordPress.DB
				$bk[] = array( 'n' => $r['name'], 'v' => $v, 'a' => $al );
			}
		}
		if ( ! $bk ) {
			self::back( 'Nothing to remove.' );
		}
		$file = self::dir() . '/tidy-' . gmdate( 'Ymd-His' ) . '-' . wp_generate_password( 6, false ) . '.json';
		if ( false === file_put_contents( $file, wp_json_encode( $bk ) ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
			self::back( 'Could not write the backup, so nothing was removed.' );
		}
		$n = 0;
		foreach ( $bk as $r ) {
			if ( delete_option( $r['n'] ) ) {
				$n++;
			}
		}
		self::back( 'Removed ' . $n . ' leftover settings. A backup was saved, use Put back if anything looks wrong.' );
	}

	public static function act_trans() {
		self::guard( 'trans' );
		global $wpdb;
		$names = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s AND CAST(option_value AS UNSIGNED) < %d LIMIT 5000", $wpdb->esc_like( '_transient_timeout_' ) . '%', time() ) ); // phpcs:ignore WordPress.DB
		$n     = 0;
		foreach ( (array) $names as $name ) {
			if ( delete_transient( substr( $name, strlen( '_transient_timeout_' ) ) ) ) {
				$n++;
			}
		}
		self::back( 'Cleared ' . $n . ' expired temporary items.' );
	}

	public static function act_orph() {
		self::guard( 'orph' );
		global $wpdb;
		$a = (int) $wpdb->query( "DELETE pm FROM {$wpdb->postmeta} pm LEFT JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE p.ID IS NULL" ); // phpcs:ignore WordPress.DB
		$b = (int) $wpdb->query( "DELETE um FROM {$wpdb->usermeta} um LEFT JOIN {$wpdb->users} u ON u.ID = um.user_id WHERE u.ID IS NULL" ); // phpcs:ignore WordPress.DB
		$c = (int) $wpdb->query( "DELETE cm FROM {$wpdb->commentmeta} cm LEFT JOIN {$wpdb->comments} c ON c.comment_ID = cm.comment_id WHERE c.comment_ID IS NULL" ); // phpcs:ignore WordPress.DB
		self::back( 'Removed ' . ( $a + $b + $c ) . ' orphan rows (no owner left).' );
	}

	public static function act_restore() {
		self::guard( 'restore' );
		$f = self::backups();
		if ( ! $f ) {
			self::back( 'No backup found.' );
		}
		$j = json_decode( (string) file_get_contents( $f[0] ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$n = 0;
		foreach ( (array) $j as $r ) {
			if ( isset( $r['n'] ) && false === get_option( $r['n'], false ) ) {
				add_option( $r['n'], $r['v'], '', 'yes' === ( $r['a'] ?? '' ) || 'on' === ( $r['a'] ?? '' ) || 'auto' === ( $r['a'] ?? '' ) ? 'yes' : 'no' );
				$n++;
			}
		}
		self::back( 'Put back ' . $n . ' settings from the last backup.' );
	}

	/* ---------- page ---------- */

	private static function btn( $action, $label, $primary ) {
		MRSH_Admin::post_button( $action, $label, $primary );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$opts  = self::scan_options();
		$nopt  = 0;
		$bytes = 0;
		foreach ( $opts as $list ) {
			foreach ( $list as $r ) {
				$nopt++;
				$bytes += $r['size'];
			}
		}
		$exp = self::count_expired();
		list( $o1, $o2, $o3 ) = self::count_orphans();
		$orph = $o1 + $o2 + $o3;
		$bk   = self::backups();
		MRSH_Boost::ui_open( 'Database tidy', 'Clears clutter left by plugins you removed, expired temporary data and rows with no owner. Safe: settings are backed up first and can be put back.', 'g-blue', 'M12 3C7 3 3 4.8 3 7v10c0 2.2 4 4 9 4s9-1.8 9-4V7c0-2.2-4-4-9-4zm0 2c4.4 0 7 1.4 7 2s-2.6 2-7 2-7-1.4-7-2 2.6-2 7-2zm7 12c0 .6-2.6 2-7 2s-7-1.4-7-2v-2.3C7 15.5 9.3 16 12 16s5-.5 7-1.3V17z' );
		if ( isset( $_GET['msg'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			MRSH_Boost::ui_ok( rawurldecode( (string) wp_unslash( $_GET['msg'] ) ) ); // phpcs:ignore
		}
		echo '<div class="mx-stats">' . MRSH_Boost::ui_stat( $nopt, 'Leftover settings', '#7c3aed' ) . MRSH_Boost::ui_stat( size_format( $bytes ), 'Space they use', '#0ea5e9' ) . MRSH_Boost::ui_stat( $exp, 'Expired temp items', '#f59e0b' ) . MRSH_Boost::ui_stat( $orph, 'Orphan rows', '#e11d48' ) . '</div>'; // phpcs:ignore
		echo '<div class="mx-card"><h2>1. Settings of removed plugins</h2>';
		if ( $opts ) {
			echo '<p class="mx-sub">These belong to plugins that are not active on the site any more. They are saved to a private backup before they are removed.</p><table class="widefat striped"><thead><tr><th>Left behind by</th><th>Settings</th><th>Size</th></tr></thead><tbody>';
			foreach ( $opts as $label => $list ) {
				echo '<tr><td><b>' . esc_html( $label ) . '</b></td><td>' . (int) count( $list ) . '</td><td>' . esc_html( size_format( array_sum( wp_list_pluck( $list, 'size' ) ) ) ) . '</td></tr>';
			}
			echo '</tbody></table><p>';
			self::btn( 'mrsh_tidy_opts', 'Back up and remove', true );
			echo '</p>';
		} else {
			echo '<p class="mx-sub">Nothing left behind. All clean.</p>';
		}
		if ( $bk ) {
			echo '<p class="mx-sub">Last backup: ' . esc_html( wp_date( 'j M Y H:i', filemtime( $bk[0] ) ) ) . ' (' . esc_html( size_format( filesize( $bk[0] ) ) ) . '). </p>';
			self::btn( 'mrsh_tidy_restore', 'Put back the last backup', false );
		}
		echo '</div>';
		echo '<div class="mx-card"><h2>2. Expired temporary data</h2><p class="mx-sub">Short-lived items that finished their time and were never cleared. WordPress rebuilds anything it still needs.</p>';
		self::btn( 'mrsh_tidy_trans', 'Clear expired items (' . (int) $exp . ')', true );
		echo '</div>';
		echo '<div class="mx-card"><h2>3. Orphan rows</h2><p class="mx-sub">Details of profiles, members or comments that no longer exist: ' . (int) $o1 . ' profile rows, ' . (int) $o2 . ' member rows, ' . (int) $o3 . ' comment rows. They belong to nobody, so removing them is safe.</p>';
		self::btn( 'mrsh_tidy_orph', 'Remove orphan rows (' . (int) $orph . ')', true );
		echo '</div></div>';
	}
}
