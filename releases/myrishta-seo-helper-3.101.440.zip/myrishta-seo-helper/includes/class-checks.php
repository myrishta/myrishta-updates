<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Live checks: fetch the site's own public URLs and report what search engines will see. */
class MRSH_Checks {

	const CACHE = 'mrsh_checks';

	public static function has_noindex( $headers, $body ) {
		if ( is_string( $headers ) && false !== stripos( $headers, 'noindex' ) ) {
			return true;
		}
		$body = (string) $body;
		if ( preg_match( '/<meta[^>]+name=["\']robots["\'][^>]*content=["\'][^"\']*noindex/i', $body ) ) {
			return true;
		}
		return (bool) preg_match( '/<meta[^>]+content=["\'][^"\']*noindex[^"\']*["\'][^>]*name=["\']robots["\']/i', $body );
	}

	public static function canonical_of( $body ) {
		if ( preg_match( '/<link[^>]+rel=["\']canonical["\'][^>]*href=["\']([^"\']+)["\']/i', (string) $body, $m ) ) {
			return $m[1];
		}
		if ( preg_match( '/<link[^>]+href=["\']([^"\']+)["\'][^>]*rel=["\']canonical["\']/i', (string) $body, $m ) ) {
			return $m[1];
		}
		return '';
	}

	private static function fetch( $url, $redirects = 3 ) {
		$r = wp_remote_get(
			$url,
			array(
				'timeout'    => 8,
				'redirection' => $redirects,
				'user-agent' => 'MyRishtaSEOHelper/' . MRSH_VERSION,
			)
		);
		if ( is_wp_error( $r ) ) {
			return array( 'ok' => false, 'error' => $r->get_error_message() );
		}
		$h = wp_remote_retrieve_header( $r, 'x-robots-tag' );
		return array(
			'ok'      => true,
			'code'    => (int) wp_remote_retrieve_response_code( $r ),
			'location' => (string) wp_remote_retrieve_header( $r, 'location' ),
			'body'    => (string) wp_remote_retrieve_body( $r ),
			'headers' => is_array( $h ) ? implode( ' ', $h ) : (string) $h,
		);
	}

	private static function row( $label, $status, $detail ) {
		return array( 'label' => $label, 'status' => $status, 'detail' => $detail );
	}

	public static function run() {
		$o    = MRSH_Options::get();
		$rows = array();

		// 1. robots.txt
		$r = self::fetch( home_url( '/robots.txt' ) );
		if ( ! $r['ok'] ) {
			$rows[] = self::row( 'robots.txt', 'unknown', 'Could not fetch: ' . $r['error'] );
		} elseif ( 200 !== $r['code'] ) {
			$rows[] = self::row( 'robots.txt', 'fail', 'HTTP ' . $r['code'] );
		} else {
			$missing = array();
			foreach ( preg_split( '/\R/', (string) $o['robots_disallow'] ) as $p ) {
				$p = trim( $p );
				if ( '' !== $p && false === strpos( $r['body'], 'Disallow: ' . $p ) ) {
					$missing[] = $p;
				}
			}
			$has_map = false !== stripos( $r['body'], 'Sitemap:' );
			if ( $missing ) {
				$rows[] = self::row( 'robots.txt', 'warn', 'Loads, but missing: ' . implode( ', ', $missing ) . '. A real robots.txt file on the server may be overriding this plugin.' );
			} elseif ( ! $has_map ) {
				$rows[] = self::row( 'robots.txt', 'warn', 'Loads, but has no Sitemap line. Set the sitemap URL under Rules.' );
			} else {
				$rows[] = self::row( 'robots.txt', 'pass', 'Loads with your Disallow rules and a Sitemap line.' );
			}
		}

		// 2. Sitemap
		$sm_url  = '' !== $o['sitemap_url'] ? $o['sitemap_url'] : MRSH_Frontend::default_sitemap();
		$r       = self::fetch( $sm_url );
		if ( ! $r['ok'] ) {
			$rows[] = self::row( 'Sitemap', 'unknown', 'Could not fetch ' . $sm_url );
		} elseif ( 200 === $r['code'] && ( false !== strpos( $r['body'], '<sitemapindex' ) || false !== strpos( $r['body'], '<urlset' ) ) ) {
			$bad = array();
			foreach ( MRSH_Options::to_list( $o['noindex_post_types'] ) as $pt ) {
				if ( false !== strpos( $r['body'], '/' . $pt . '-sitemap' ) || false !== strpos( $r['body'], 'wp-sitemap-posts-' . $pt ) ) {
					$bad[] = $pt;
				}
			}
			$rows[] = self::row( 'Sitemap', 'pass', $sm_url . ' loads as a valid sitemap.' );
			if ( $bad ) {
				$rows[] = self::row( 'Sitemap lists noindex pages', 'fail', 'The sitemap includes ' . implode( ', ', $bad ) . ' pages, which are set to noindex. In Rank Math > Sitemap Settings turn those post types off, otherwise Search Console reports errors.' );
			}
		} else {
			$rows[] = self::row( 'Sitemap', 'fail', $sm_url . ' returned HTTP ' . $r['code'] . ' or is not a sitemap. Turn on the sitemap in your SEO plugin.' );
		}

		// 3. Homepage
		$r = self::fetch( home_url( '/' ) );
		if ( ! $r['ok'] ) {
			$rows[] = self::row( 'Homepage indexable', 'unknown', 'Could not fetch the homepage.' );
		} elseif ( self::has_noindex( $r['headers'], $r['body'] ) ) {
			$rows[] = self::row( 'Homepage indexable', 'fail', 'The homepage carries a noindex directive. Search engines will drop it.' );
		} else {
			preg_match_all( '/<meta[^>]+name=["\'](google-site-verification|msvalidate\.01|yandex-verification|baidu-site-verification|naver-site-verification|seznam-wmt)["\'][^>]+content=["\']([^"\']+)["\']/i', $r['body'], $vm, PREG_SET_ORDER );
			$vals = array();
			foreach ( $vm as $m ) {
				$vals[ $m[2] ][] = $m[1];
			}
			foreach ( $vals as $names ) {
				if ( count( $names ) > 2 ) {
					$rows[] = self::row( 'Verification codes', 'fail', 'The same code is used for ' . implode( ', ', $names ) . '. Each search engine gives its own code; clear the wrong ones.' );
					break;
				}
			}
			$h1 = preg_match_all( '/<h1[\s>]/i', $r['body'] );
			$rows[] = 1 === $h1 ? self::row( 'Homepage heading', 'pass', 'Exactly one H1 heading.' ) : self::row( 'Homepage heading', 'warn', $h1 ? $h1 . ' H1 headings found. Use one H1 and H2 for sections (set the heading level in Elementor).' : 'No H1 heading found. Add one in Elementor containing your main phrase, for example Free Rishta in Pakistan.' );
			$has_desc = (bool) preg_match( '/<meta[^>]+name=["\']description["\']/i', $r['body'] );
			$rows[]   = $has_desc ? self::row( 'Homepage indexable', 'pass', 'No noindex, and a meta description is present.' ) : self::row( 'Homepage indexable', 'warn', 'No noindex, but no meta description found. Set one in your SEO plugin.' );
		}

		// 4. Search results noindex
		$r = self::fetch( home_url( '/?s=mrsh-check' ), 0 );
		if ( ! $r['ok'] ) {
			$rows[] = self::row( 'Search results noindexed', 'unknown', 'Could not fetch a test search URL.' );
		} elseif ( $r['code'] >= 300 && $r['code'] < 400 && '' !== $r['location'] ) {
			$rows[] = self::row( 'Search results noindexed', 'pass', '/?s= redirects away (to the sign-in page), so no search result page can be indexed.' );
		} elseif ( self::has_noindex( $r['headers'], $r['body'] ) ) {
			$rows[] = self::row( 'Search results noindexed', 'pass', '/?s= pages return noindex.' );
		} else {
			$rows[] = self::row( 'Search results noindexed', 'fail', '/?s= pages are indexable. Check the Rules page and any caching plugin.' );
		}

		// 5. Canonical on a parameter URL
		$r = self::fetch( home_url( '/?sort=pop' ) );
		if ( $r['ok'] ) {
			$canon = self::canonical_of( $r['body'] );
			if ( '' === $canon ) {
				$rows[] = self::row( 'Clean canonical', 'warn', 'No canonical tag found on a /?sort= URL.' );
			} elseif ( false !== strpos( $canon, 'sort=' ) ) {
				$rows[] = self::row( 'Clean canonical', 'fail', 'Canonical still contains the parameter: ' . $canon );
			} else {
				$rows[] = self::row( 'Clean canonical', 'pass', 'Parameter removed: ' . $canon );
			}
		} else {
			$rows[] = self::row( 'Clean canonical', 'unknown', 'Could not fetch a test URL.' );
		}

		// 6. A member profile
		$types = MRSH_Options::to_list( $o['noindex_post_types'] );
		$post  = $types ? get_posts( array( 'post_type' => $types, 'post_status' => 'publish', 'numberposts' => 1 ) ) : array();
		if ( ! $post ) {
			$rows[] = self::row( 'Member profile noindexed', 'unknown', 'No published profile found for the configured post type.' );
		} else {
			$r = self::fetch( get_permalink( $post[0] ) );
			if ( ! $r['ok'] ) {
				$rows[] = self::row( 'Member profile noindexed', 'unknown', 'Could not fetch a profile page.' );
			} elseif ( self::has_noindex( $r['headers'], $r['body'] ) ) {
				$rows[] = self::row( 'Member profile noindexed', 'pass', 'Profile pages return noindex.' );
			} else {
				$rows[] = self::row( 'Member profile noindexed', 'fail', 'A profile page is indexable. Check the post type slug under Rules.' );
			}
		}

		$result = array( 'time' => time(), 'rows' => $rows );
		set_transient( self::CACHE, $result, DAY_IN_SECONDS * 2 );
		return $result;
	}

	/** Compare what the homepage prints with what is saved. */
	public static function verify_report() {
		$o    = MRSH_Options::get();
		$rows = array();
		$r    = self::fetch( home_url( '/' ) );
		if ( ! $r['ok'] || 200 !== $r['code'] ) {
			return array( self::row( 'Homepage', 'unknown', 'Could not read the homepage, so the tags could not be tested.' ) );
		}
		preg_match_all( '/<meta\b[^>]*>/i', $r['body'], $tags );
		$found = array();
		foreach ( $tags[0] as $tg ) {
			if ( preg_match( '/\bname\s*=\s*["\']([^"\']+)["\']/i', $tg, $n ) && preg_match( '/content\s*=\s*["\']([^"\']*)["\']/i', $tg, $c ) ) {
				$found[ strtolower( $n[1] ) ][] = $c[1];
			}
		}
		$labels = array(
			'google_verification' => 'Google', 'bing_verification' => 'Bing', 'yandex_verification' => 'Yandex', 'baidu_verification' => 'Baidu',
			'naver_verification' => 'Naver', 'seznam_verification' => 'Seznam', 'pinterest_verification' => 'Pinterest', 'facebook_verification' => 'Facebook', 'ahrefs_verification' => 'Ahrefs',
		);
		$all = array();
		foreach ( MRSH_Frontend::verification_map() as $key => $name ) {
			$vals = isset( $found[ strtolower( $name ) ] ) ? $found[ strtolower( $name ) ] : array();
			foreach ( $vals as $v ) {
				$all[ $v ][] = $labels[ $key ];
			}
			$label = $labels[ $key ];
			if ( '' === $o[ $key ] && ! $vals ) {
				continue;
			}
			if ( '' !== $o[ $key ] && ! in_array( $o[ $key ], $vals, true ) ) {
				$rows[] = self::row( $label, 'fail', 'Saved here but not on the homepage. Purge your cache, or the page is built before the plugin output.' . ( $vals ? ' Another code is printed instead: ' . $vals[0] : '' ) );
			} elseif ( '' === $o[ $key ] && $vals ) {
				$rows[] = self::row( $label, 'warn', 'Printed by another plugin or the theme (' . $vals[0] . '). Fine if it is the right code for ' . $label . '.' );
			} elseif ( count( $vals ) > 1 ) {
				$rows[] = self::row( $label, 'warn', 'Printed ' . count( $vals ) . ' times. Turn on Remove duplicate tags or remove it from your SEO plugin.' );
			} else {
				$rows[] = self::row( $label, 'pass', 'Found on the homepage.' );
			}
		}
		foreach ( $all as $v => $who ) {
			if ( count( $who ) > 1 ) {
				$rows[] = self::row( 'Same code reused', 'fail', 'The identical value "' . $v . '" is used for ' . implode( ', ', $who ) . '. Each engine has its own code.' );
			}
		}
		foreach ( MRSH_Options::lines( $o['verify_files'] ) as $l ) {
			$parts = explode( '|', $l, 2 );
			if ( 2 !== count( $parts ) ) {
				continue;
			}
			$f = self::fetch( home_url( '/' . trim( $parts[0] ) ) );
			if ( $f['ok'] && 200 === $f['code'] && trim( $f['body'] ) === trim( $parts[1] ) ) {
				$rows[] = self::row( 'File ' . trim( $parts[0] ), 'pass', 'Reachable with the exact content.' );
			} else {
				$rows[] = self::row( 'File ' . trim( $parts[0] ), 'fail', 'Not reachable or different content. Purge the cache and make sure nothing redirects it.' );
			}
		}
		if ( ! $rows ) {
			$rows[] = self::row( 'Verification', 'unknown', 'No codes saved and none found on the homepage yet.' );
		}
		return $rows;
	}

	public static function last() {
		$c = get_transient( self::CACHE );
		return is_array( $c ) ? $c : null;
	}
}
