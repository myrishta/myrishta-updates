<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Backup & Restore: one JSON file holding every MyRishta SEO setting, the keyword bank
 * and the per-page SEO fields (title, description, focus keyword, noindex).
 * Pages are matched by type + slug, so a backup restores onto a fresh install.
 */
class MRSH_Backup {

	const META = array( '_mrsh_title', '_mrsh_desc', '_mrsh_focus', '_mrsh_noindex' );
	const OPTS = array( 'mrsh_options', 'mrsh_custom_keywords', 'mrsh_autoupdate', 'mrsh_ai', 'mrsh_nudge', 'mrsh_2fa_settings', 'mrsh_img_opts', 'mrsh_live', 'mrsh_mod_settings', 'mrsh_agent', 'mrsh_autokw', 'mrsh_app_redirect' );

	public static function init() {
		if ( ! is_admin() ) {
			return;
		}
		add_action( 'admin_post_mrsh_backup_download', array( __CLASS__, 'download' ) );
		add_action( 'admin_post_mrsh_backup_restore', array( __CLASS__, 'restore' ) );
	}

	private static function guard( $action ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( $action );
	}

	private static function notice( $msg, $type = 'success' ) {
		set_transient( 'mrsh_notice_' . get_current_user_id(), array( $msg, $type ), 60 );
	}

	/** Build the backup array. */
	public static function build() {
		global $wpdb;
		$out = array(
			'format'   => 'myrishta-seo-backup',
			'version'  => MRSH_VERSION,
			'created'  => gmdate( 'c' ),
			'site'     => home_url(),
			'options'  => array(),
			'pagemeta' => array(),
		);
		foreach ( self::OPTS as $key ) {
			$val = get_option( $key, null );
			if ( null !== $val ) {
				$out['options'][ $key ] = $val;
			}
		}
		// Every per-page field this plugin saves (_mrsh_title, _mrsh_desc, _mrsh_focus, _mrsh_noindex and any added later).
		$like = $wpdb->esc_like( '_mrsh_' ) . '%';
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT p.post_type, p.post_name, m.meta_key, m.meta_value FROM {$wpdb->postmeta} m INNER JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE m.meta_key LIKE %s AND p.post_status <> 'trash' AND p.post_name <> ''", $like ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		foreach ( (array) $rows as $r ) {
			$out['pagemeta'][] = array( $r->post_type, $r->post_name, $r->meta_key, $r->meta_value );
		}
		return $out;
	}

	public static function download() {
		self::guard( 'mrsh_backup_download' );
		$name = 'myrishta-seo-backup-' . gmdate( 'Y-m-d' ) . '.json';
		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $name . '"' );
		echo wp_json_encode( self::build(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	public static function restore() {
		self::guard( 'mrsh_backup_restore' );
		$back = function () {
			MRSH_Admin::back( 'myrishta-seo-backup' );
		};
		$raw = '';
		$pasted = isset( $_POST['mrsh_backup_text'] ) ? trim( (string) wp_unslash( $_POST['mrsh_backup_text'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( '' !== $pasted ) {
			$raw = $pasted;
		} else {
			$err = isset( $_FILES['mrsh_backup']['error'] ) ? (int) $_FILES['mrsh_backup']['error'] : 4; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			if ( UPLOAD_ERR_NO_FILE === $err || empty( $_FILES['mrsh_backup']['tmp_name'] ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
				self::notice( 'No file arrived. Choose the backup file, or paste its text into the box below it. (If you did choose a file, the server may be blocking uploads; pasting always works.)', 'error' );
				$back();
			}
			if ( UPLOAD_ERR_OK !== $err ) {
				self::notice( 'The upload failed (error ' . $err . '). The server limit may be too small. Paste the file text into the box instead.', 'error' );
				$back();
			}
			if ( (int) $_FILES['mrsh_backup']['size'] > 20 * MB_IN_BYTES ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
				self::notice( 'That file is too large to be a MyRishta SEO backup.', 'error' );
				$back();
			}
			$raw = (string) file_get_contents( $_FILES['mrsh_backup']['tmp_name'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput,WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		}
		$raw  = preg_replace( '/^\xEF\xBB\xBF/', '', trim( $raw ) );
		$data = json_decode( $raw, true );
		if ( ! is_array( $data ) ) {
			self::notice( 'The file could not be read as JSON (' . json_last_error_msg() . '). Download the backup again and try once more.', 'error' );
			$back();
		}
		if ( ( $data['format'] ?? '' ) !== 'myrishta-seo-backup' ) {
			self::notice( 'That is not a MyRishta SEO backup file.', 'error' );
			$back();
		}

		$clean = function ( $v ) use ( &$clean ) {
			if ( is_array( $v ) ) {
				return array_map( $clean, $v );
			}
			return is_string( $v ) ? sanitize_textarea_field( $v ) : ( is_numeric( $v ) ? $v : ( is_bool( $v ) ? (int) $v : '' ) );
		};

		$n_opts = 0;
		$n_keys = 0;
		foreach ( (array) ( $data['options'] ?? array() ) as $key => $val ) {
			if ( ! in_array( $key, self::OPTS, true ) ) {
				continue;
			}
			if ( 'mrsh_options' === $key ) {
				$val = array_intersect_key( (array) $clean( $val ), MRSH_Options::defaults() );
				$val = array_merge( MRSH_Options::get(), $val );
			} else {
				$val = $clean( $val );
			}
			update_option( $key, $val );
			if ( 'mrsh_options' === $key ) {
				// Clear the option cache so the new values are used straight away.
				wp_cache_delete( $key, 'options' );
				wp_cache_delete( 'alloptions', 'options' );
				$n_keys = count( $val );
			}
			++$n_opts;
		}

		$n_meta = 0;
		$miss   = 0;
		$ids    = array();
		foreach ( (array) ( $data['pagemeta'] ?? array() ) as $row ) {
			if ( ! is_array( $row ) || 4 !== count( $row ) || ! preg_match( '/^_mrsh_[a-z0-9_]+$/', (string) $row[2] ) || ! post_type_exists( (string) $row[0] ) ) {
				continue;
			}
			$k = $row[0] . '|' . $row[1];
			if ( ! isset( $ids[ $k ] ) ) {
				$p          = get_page_by_path( sanitize_title( (string) $row[1] ), OBJECT, (string) $row[0] );
				$ids[ $k ]  = $p ? (int) $p->ID : 0;
			}
			if ( ! $ids[ $k ] ) {
				++$miss;
				continue;
			}
			update_post_meta( $ids[ $k ], $row[2], sanitize_textarea_field( (string) $row[3] ) );
			++$n_meta;
		}

		// Re-apply rewrite rules and clear caches so the restored settings take effect now.
		delete_option( 'mrsh_flushed_ver' );
		do_action( 'litespeed_purge_all' );
		self::notice( sprintf( 'Restored %d setting groups (%d main settings) and SEO fields for %d pages.%s', $n_opts, $n_keys, $n_meta, $miss ? ' ' . $miss . ' fields were skipped because that page does not exist on this site yet; restore again after the pages are created.' : '' ) );
		$back();
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		MRSH_Admin::open( 'Backup & Restore', 'Save every MyRishta SEO setting in one file, and restore it on a fresh install.' );

		$dl = wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_backup_download' ), 'mrsh_backup_download' );
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>1. Download a backup</h2></div>';
		echo '<p class="mrsh-muted">The file holds your organization details, verification codes, speed and cleanup options, redirects, robots rules, keyword bank, and each page\'s SEO title, description, focus keyword and noindex choice. It holds no passwords. Keep it somewhere safe, for example your email or Google Drive.</p>';
		echo '<p><a class="button button-primary" href="' . esc_url( $dl ) . '">Download backup file</a></p></div>';

		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>2. Restore from a backup</h2></div>';
		echo '<p class="mrsh-muted">After installing the plugin on a new site, upload the file here. Settings are restored straight away. Page SEO fields are matched by page address, so create or import your pages first, then restore.</p>';
		echo '<form method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="mrsh_backup_restore">';
		wp_nonce_field( 'mrsh_backup_restore' );
		echo '<p><input type="file" name="mrsh_backup" accept=".json,application/json"></p>';
		echo '<p class="mrsh-muted">If the upload does not work on your host, open the file in Notepad, copy everything and paste it here instead:</p>';
		echo '<p><textarea name="mrsh_backup_text" rows="5" style="width:100%;max-width:720px" placeholder="Paste the backup text here (optional)"></textarea></p>';
		echo '<p><button type="submit" class="button button-primary">Restore backup</button></p></form></div>';

		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>3. Create the pages for the newer features</h2></div>';
		echo '<p class="mrsh-muted">After an upgrade these pages are created for you once: My biodata, Quick start checklist, My report history, Blocked profiles, Trusted contact, Recover my account, Scam alerts, City groups and Site statistics. Press the button to create any that are missing. Pages that already exist are never changed.</p>';
		echo '<p><a class="button button-primary" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_make_pages' ), 'mrsh_make_pages' ) ) . '">Create missing pages</a></p></div>';

		MRSH_Admin::close();
	}
}
