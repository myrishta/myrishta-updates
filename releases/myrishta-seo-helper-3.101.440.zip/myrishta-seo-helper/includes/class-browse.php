<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** [myrishta_browse] puts your phrases on the site as real, crawlable internal links. */
class MRSH_Browse {

	const CACHE = 'mrsh_titles';

	public static function init() {
		add_shortcode( 'myrishta_browse', array( __CLASS__, 'shortcode' ) );
		add_shortcode( 'myrishta_whatsapp', array( __CLASS__, 'whatsapp' ) );
	}

	/** Lowercase page title => permalink, for published indexable content. */
	private static function title_map() {
		$map = get_transient( self::CACHE );
		if ( is_array( $map ) ) {
			return $map;
		}
		$o     = MRSH_Options::get();
		$skip  = array_merge( array( 'attachment' ), MRSH_Options::to_list( $o['noindex_post_types'] ) );
		$types = array_values( array_diff( array_keys( get_post_types( array( 'public' => true ) ) ), $skip ) );
		$map   = array();
		foreach ( get_posts( array( 'post_type' => $types, 'post_status' => 'publish', 'numberposts' => 300, 'suppress_filters' => true ) ) as $p ) {
			$map[ mb_strtolower( $p->post_title ) ] = get_permalink( $p );
		}
		set_transient( self::CACHE, $map, 6 * HOUR_IN_SECONDS );
		return $map;
	}

	/** A page whose title contains the phrase, else the site search for it. */
	public static function target_for( $row, $map ) {
		foreach ( MRSH_Keywords::variants( $row ) as $v ) {
			foreach ( $map as $title => $url ) {
				if ( false !== mb_stripos( $title, $v ) ) {
					return array( $url, false );
				}
			}
		}
		return array( add_query_arg( 's', rawurlencode( MRSH_Keywords::label( $row ) ), home_url( '/' ) ), true );
	}

	/** [myrishta_whatsapp label="Share on WhatsApp"]: share link for the current page. */
	public static function whatsapp( $atts ) {
		$a    = shortcode_atts( array( 'label' => 'Share on WhatsApp' ), $atts, 'myrishta_whatsapp' );
		$post = get_post();
		if ( ! $post ) {
			return '';
		}
		$text = get_the_title( $post ) . ' ' . get_permalink( $post );
		return '<a class="mrsh-wa" rel="noopener noreferrer" target="_blank" href="' . esc_url( 'https://wa.me/?text=' . rawurlencode( $text ) ) . '">' . esc_html( $a['label'] ) . '</a>';
	}

	public static function shortcode( $atts ) {
		$a = shortcode_atts(
			array(
				'group'    => '',
				'priority' => '',
				'limit'    => 12,
				'title'    => '',
			),
			$atts,
			'myrishta_browse'
		);
		$rank = array( 'High' => 0, 'Medium' => 1, 'Low' => 2 );
		$rows = array();
		foreach ( MRSH_Keywords::all() as $r ) {
			if ( 'Target' !== $r['treatment'] ) {
				continue;
			}
			if ( '' !== $a['group'] && 0 !== strcasecmp( $a['group'], $r['group'] ) ) {
				continue;
			}
			if ( '' !== $a['priority'] && 0 !== strcasecmp( $a['priority'], $r['priority'] ) ) {
				continue;
			}
			$rows[] = $r;
		}
		usort(
			$rows,
			function ( $x, $y ) use ( $rank ) {
				return $rank[ $x['priority'] ] - $rank[ $y['priority'] ];
			}
		);
		$rows = array_slice( $rows, 0, max( 1, (int) $a['limit'] ) );
		if ( ! $rows ) {
			return '';
		}
		wp_register_style( 'mrsh-browse', false, array(), MRSH_VERSION );
		wp_enqueue_style( 'mrsh-browse' );
		wp_add_inline_style( 'mrsh-browse', '.mrsh-browse ul{list-style:none;margin:0;padding:0;display:flex;flex-wrap:wrap;gap:8px}.mrsh-browse a{display:inline-block;padding:6px 14px;border:1px solid currentColor;border-radius:999px;text-decoration:none;font-size:.9em}.mrsh-browse .mrsh-ur{margin-inline-start:6px}' );

		$map  = self::title_map();
		$html = '<nav class="mrsh-browse" aria-label="' . esc_attr( '' !== $a['title'] ? $a['title'] : 'Browse rishta by topic' ) . '">';
		if ( '' !== $a['title'] ) {
			$html .= '<h3>' . esc_html( $a['title'] ) . '</h3>';
		}
		$html .= '<ul>';
		foreach ( $rows as $r ) {
			list( $url, $is_search ) = self::target_for( $r, $map );
			$text                    = esc_html( '' !== $r['roman'] ? $r['roman'] : $r['urdu'] );
			if ( '' !== $r['roman'] && '' !== $r['urdu'] ) {
				$text .= '<span class="mrsh-ur" dir="rtl" lang="ur">' . esc_html( $r['urdu'] ) . '</span>';
			}
			$html .= '<li><a href="' . esc_url( $url ) . '"' . ( $is_search ? ' rel="nofollow"' : '' ) . '>' . $text . '</a></li>';
		}
		return $html . '</ul></nav>';
	}
}
