<?php
/**
 * Telegram login codes. The site owner creates a free bot with @BotFather and pastes its token once.
 * A member links their own Telegram by tapping a one-time link (t.me/<bot>?start=<token>); Telegram then tells
 * this site (webhook) which chat belongs to that member. The code is used for two-step login (see MRSH_TwoFactor).
 * No phone number is needed and nothing is sent to anyone who has not linked their own account.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Telegram {

	const OPT = 'mrsh_tg_settings';

	public static function settings() {
		$d = array(
			'enabled' => 0,
			'token'   => '', // encrypted.
			'bot'     => '', // bot username without @.
			'secret'  => '', // webhook secret header.
			'hook_ok' => 0,
		);
		$s = get_option( self::OPT, array() );
		return is_array( $s ) ? array_merge( $d, $s ) : $d;
	}

	public static function token() {
		$s = self::settings();
		return '' === $s['token'] ? '' : (string) MRSH_TwoFactor::dec( $s['token'] );
	}

	/** On only when switched on, the bot is known and Telegram has been told where to send updates. */
	public static function enabled() {
		$s = self::settings();
		return ! empty( $s['enabled'] ) && ! empty( $s['hook_ok'] ) && '' !== $s['bot'] && '' !== self::token();
	}

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'admin_post_mrsh_tg_settings', array( __CLASS__, 'save_settings' ) );
		add_action( 'admin_post_mrsh_tg_off', array( __CLASS__, 'disconnect' ) );
		add_action( 'mrsh_wa_page_extra', array( __CLASS__, 'section' ) );
	}

	/* ---------- Telegram API ---------- */

	/** @return array|WP_Error Decoded "result" of a Bot API call. */
	public static function api( $method, $args = array(), $token = '' ) {
		$token = '' !== $token ? $token : self::token();
		if ( '' === $token || ! preg_match( '/^\d{5,}:[A-Za-z0-9_-]{20,}$/', $token ) ) {
			return new WP_Error( 'mrsh_tg_token', 'The bot token does not look right. Copy it again from @BotFather.' );
		}
		$r = wp_remote_post( 'https://api.telegram.org/bot' . $token . '/' . $method, array( 'timeout' => 15, 'body' => $args ) );
		if ( is_wp_error( $r ) ) {
			return new WP_Error( 'mrsh_tg_http', 'Could not reach Telegram: ' . $r->get_error_message() );
		}
		$j = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( ! is_array( $j ) || empty( $j['ok'] ) ) {
			return new WP_Error( 'mrsh_tg_api', 'Telegram answered: ' . ( is_array( $j ) && ! empty( $j['description'] ) ? $j['description'] : (int) wp_remote_retrieve_response_code( $r ) ) );
		}
		return isset( $j['result'] ) && is_array( $j['result'] ) ? $j['result'] : array();
	}

	/** Sends a login code to a linked chat. True, or a WP_Error. */
	public static function send( $chat_id, $code, $minutes = 10 ) {
		if ( ! self::enabled() ) {
			return new WP_Error( 'mrsh_tg_off', 'Telegram codes are switched off.' );
		}
		$chat_id = preg_replace( '/[^\d-]/', '', (string) $chat_id );
		if ( '' === $chat_id ) {
			return new WP_Error( 'mrsh_tg_chat', 'No Telegram account is linked.' );
		}
		$text = sprintf( "Your %s login code is %s\nIt works for %d minutes. Never share this code with anyone.", wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ), $code, (int) $minutes );
		$r    = self::api( 'sendMessage', array( 'chat_id' => $chat_id, 'text' => $text ) );
		return is_wp_error( $r ) ? $r : true;
	}

	public static function mask( $chat_id ) {
		$d = preg_replace( '/\D/', '', (string) $chat_id );
		return strlen( $d ) > 4 ? str_repeat( '•', strlen( $d ) - 4 ) . substr( $d, -4 ) : '••••';
	}

	/* ---------- linking a member ---------- */

	/** One-time link a logged-in member opens in Telegram. Valid 15 minutes, works once. */
	public static function link_for( $uid ) {
		$s = self::settings();
		if ( ! self::enabled() ) {
			return '';
		}
		$t = bin2hex( random_bytes( 8 ) );
		set_transient( 'mrsh_tgl_' . $t, (int) $uid, 15 * MINUTE_IN_SECONDS );
		update_user_meta( $uid, MRSH_TwoFactor::M_TGP, array( 't' => $t, 'exp' => time() + 15 * MINUTE_IN_SECONDS ) );
		return 'https://t.me/' . rawurlencode( $s['bot'] ) . '?start=' . $t;
	}

	public static function routes() {
		register_rest_route( 'mrsh/v1', '/tg', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'webhook' ),
			'permission_callback' => '__return_true',
		) );
	}

	public static function webhook( $req ) {
		$s   = self::settings();
		$hdr = (string) $req->get_header( 'x_telegram_bot_api_secret_token' );
		if ( '' === $s['secret'] || ! hash_equals( $s['secret'], $hdr ) ) {
			return new WP_REST_Response( array( 'ok' => false ), 403 );
		}
		$u    = $req->get_json_params();
		$msg  = is_array( $u ) && isset( $u['message'] ) && is_array( $u['message'] ) ? $u['message'] : array();
		$chat = isset( $msg['chat']['id'] ) ? (string) $msg['chat']['id'] : '';
		$text = isset( $msg['text'] ) ? trim( (string) $msg['text'] ) : '';
		if ( '' === $chat || ! empty( $msg['chat']['type'] ) && 'private' !== $msg['chat']['type'] ) {
			return new WP_REST_Response( array( 'ok' => true ), 200 );
		}
		$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		if ( preg_match( '#^/start(?:@\w+)?\s+([a-f0-9]{16})$#', $text, $m ) ) {
			$uid = (int) get_transient( 'mrsh_tgl_' . $m[1] );
			delete_transient( 'mrsh_tgl_' . $m[1] ); // single use.
			if ( $uid && get_userdata( $uid ) ) {
				update_user_meta( $uid, MRSH_TwoFactor::M_TG, $chat );
				delete_user_meta( $uid, MRSH_TwoFactor::M_TGP );
				self::api( 'sendMessage', array( 'chat_id' => $chat, 'text' => 'Linked. Go back to ' . $site . ' and press "I have tapped Start" to finish. Your login codes will arrive here.' ) );
			} else {
				self::api( 'sendMessage', array( 'chat_id' => $chat, 'text' => 'This link has expired or was already used. Open ' . $site . ', choose Telegram again and tap the new link.' ) );
			}
		} elseif ( '/start' === $text ) {
			self::api( 'sendMessage', array( 'chat_id' => $chat, 'text' => 'To link this chat, log in to ' . $site . ', open your two-step login settings, choose Telegram and tap the link shown there.' ) );
		}
		return new WP_REST_Response( array( 'ok' => true ), 200 );
	}

	/* ---------- admin section (shown under the WhatsApp page) ---------- */

	public static function section() {
		$s = self::settings();
		echo '<hr><h2>Telegram codes</h2><p>Free and no phone number needed. Members link their own Telegram once and get their login code there.</p>';
		echo '<ol><li>In Telegram open <strong>@BotFather</strong>, send <code>/newbot</code>, choose a name and a username ending in <code>bot</code>.</li><li>Copy the <strong>token</strong> BotFather gives you and paste it below.</li><li>Press <strong>Save and connect</strong>. The site checks the token and tells Telegram where to send updates.</li></ol>';
		if ( self::enabled() ) {
			echo '<p style="padding:10px;background:#eef7ee;border-left:4px solid #2a8f4a"><strong>Connected to @' . esc_html( $s['bot'] ) . '.</strong> Members can now choose "Code by Telegram" in their two-step login settings.</p>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_tg_settings">';
		wp_nonce_field( 'mrsh_tg_settings' );
		echo '<p><label>Bot token<br><input type="password" name="tg_token" value="" class="regular-text" autocomplete="new-password" placeholder="' . ( '' !== $s['token'] ? 'Saved. Leave empty to keep it.' : '123456789:AA...' ) . '"></label></p>';
		echo '<p><button class="button button-primary">Save and connect</button></p></form>';
		if ( '' !== $s['token'] ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_tg_off">';
			wp_nonce_field( 'mrsh_tg_off' );
			echo '<p><button class="button" onclick="return confirm(\'Switch Telegram codes off? Members who use them will get email codes instead.\')">Disconnect Telegram</button></p></form>';
		}
	}

	public static function save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_tg_settings' );
		$s   = self::settings();
		$tok = isset( $_POST['tg_token'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['tg_token'] ) ) ) : '';
		$tok = '' !== $tok ? $tok : self::token();
		$me  = self::api( 'getMe', array(), $tok );
		if ( is_wp_error( $me ) ) {
			self::done( $me->get_error_message() );
		}
		if ( empty( $me['username'] ) ) {
			self::done( 'Telegram did not return a bot name. Check the token.' );
		}
		$secret = '' !== $s['secret'] ? $s['secret'] : bin2hex( random_bytes( 24 ) );
		$hook   = self::api( 'setWebhook', array(
			'url'             => rest_url( 'mrsh/v1/tg' ),
			'secret_token'    => $secret,
			'allowed_updates' => wp_json_encode( array( 'message' ) ),
		), $tok );
		if ( is_wp_error( $hook ) ) {
			self::done( $hook->get_error_message() );
		}
		$s['token']   = MRSH_TwoFactor::enc( $tok );
		$s['bot']     = sanitize_text_field( $me['username'] );
		$s['secret']  = $secret;
		$s['hook_ok'] = 1;
		$s['enabled'] = 1;
		update_option( self::OPT, $s, false );
		self::done( 'Connected to @' . $s['bot'] . '. Members can now choose Telegram codes.' );
	}

	public static function disconnect() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_tg_off' );
		if ( '' !== self::token() ) {
			self::api( 'deleteWebhook' );
		}
		update_option( self::OPT, array(), false );
		self::done( 'Telegram codes are switched off.' );
	}

	private static function done( $msg ) {
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-whatsapp&msg=' . rawurlencode( $msg ) ) );
		exit;
	}
}
