<?php
/**
 * Share tags: when a visitor taps a WhatsApp, Telegram, Facebook or X share button, any myrishta.pk link inside the shared
 * message gets utm_source, utm_medium=share and utm_campaign=member_share added. Analytics then shows who came from shares
 * instead of counting them as Direct. Links that already carry utm_ are left alone. Front end only; nothing is stored.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_ShareUTM {

	public static function init() {
		add_action( 'wp_footer', array( __CLASS__, 'js' ), 98 );
	}

	public static function js() {
		if ( is_admin() || is_feed() || is_customize_preview() ) {
			return;
		}
		echo "<script id=\"mrsh-share-utm\">(function(){var M={'wa.me':'whatsapp','api.whatsapp.com':'whatsapp','t.me':'telegram','www.facebook.com':'facebook','facebook.com':'facebook','twitter.com':'x','x.com':'x'};"
			. "document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a[href]');if(!a)return;var u;try{u=new URL(a.href)}catch(x){return}var s=M[u.hostname];if(!s)return;var ch=false;"
			. "['text','url','u'].forEach(function(k){var v=u.searchParams.get(k);if(!v)return;"
			. "var n=v.replace(/https?:\\/\\/(?:www\\.)?myrishta\\.pk[^\\s\"'<>]*/g,function(m){var t='',p=m.match(/[.,;:!?)]+\$/);if(p){t=p[0];m=m.slice(0,-t.length)}if(/[?&]utm_/.test(m))return m+t;var h='',i=m.indexOf('#');if(i>-1){h=m.slice(i);m=m.slice(0,i)}return m+(m.indexOf('?')>-1?'&':'?')+'utm_source='+s+'&utm_medium=share&utm_campaign=member_share'+h+t});"
			. "if(n!==v){u.searchParams.set(k,n);ch=true}});if(ch)a.href=u.toString()},true)})();</script>\n";
	}
}

MRSH_ShareUTM::init();
