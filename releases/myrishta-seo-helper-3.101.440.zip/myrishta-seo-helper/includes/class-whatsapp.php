<?php
/**
 * WhatsApp verification codes. The site owner picks ANY company (Meta WhatsApp Cloud API, Twilio, Vonage,
 * UltraMsg, or a custom HTTP gateway for any other provider) and enters its keys once. The code is then
 * used for two-step login (see MRSH_TwoFactor). No company is built in as the only choice.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_WhatsApp {

	const OPT = 'mrsh_wa_settings';

	/** Provider list: id => label, note and the fields the owner fills in. */
	public static function providers() {
		return array(
			'meta'     => array(
				'label'  => 'Meta WhatsApp Cloud API (official, direct from Meta)',
				'note'   => 'Create an "Authentication" message template in Meta Business Manager (it contains the code) for sign-in codes. For reminders and signed letters create the five "Utility" templates listed under Reminder templates (texts are on the Reminder templates help below) and enter their names. Enter exact names and the language.',
				'fields' => array(
					'meta_token'    => array( 'Permanent access token', 'password' ),
					'meta_phone_id' => array( 'Phone number ID', 'text' ),
					'meta_template' => array( 'Template name', 'text' ),
					'meta_lang'     => array( 'Template language (for example en_US)', 'text' ),
					'meta_t_profile' => array( 'Reminder template: no profile yet (variables: name, days left, link)', 'text' ),
					'meta_t_pay'     => array( 'Reminder template: letter not paid (name, reference, days left, link)', 'text' ),
					'meta_t_expired' => array( 'Template: letter expired (name, reference)', 'text' ),
					'meta_t_signed'  => array( 'Template: signed letter ready (name, reference, link)', 'text' ),
					'meta_t_removed' => array( 'Template: account removed (name)', 'text' ),
				),
			),
			'twilio'   => array(
				'label'  => 'Twilio WhatsApp',
				'note'   => 'Use your Twilio Account SID, Auth Token and your approved WhatsApp sender number (or the Twilio sandbox number for testing). Reminders and signed-letter messages are sent through this company too. WhatsApp only lets a business start a chat with an approved template, so for members who have not messaged you first, ask Twilio to approve your reminder text as a template.',
				'fields' => array(
					'twilio_sid'   => array( 'Account SID', 'text' ),
					'twilio_token' => array( 'Auth token', 'password' ),
					'twilio_from'  => array( 'WhatsApp sender number (+14155238886)', 'text' ),
				),
			),
			'vonage'   => array(
				'label'  => 'Vonage (Messages API)',
				'note'   => 'Use the API key and secret from your Vonage dashboard and your WhatsApp sender number.',
				'fields' => array(
					'vonage_key'    => array( 'API key', 'text' ),
					'vonage_secret' => array( 'API secret', 'password' ),
					'vonage_from'   => array( 'WhatsApp sender number', 'text' ),
				),
			),
			'ultramsg' => array(
				'label'  => 'UltraMsg',
				'note'   => 'Use your UltraMsg instance ID and token.',
				'fields' => array(
					'ultramsg_instance' => array( 'Instance ID (instance1234)', 'text' ),
					'ultramsg_token'    => array( 'Token', 'password' ),
				),
			),
			'custom'   => array(
				'label'  => 'Any other company (custom HTTP gateway: MSG91, Infobip, WATI, Gupshup, your own, and so on)',
				'note'   => 'Copy the "send message" request from your provider\'s documentation. Placeholders: {phone} (digits with country code, no plus), {phone_plus} (with plus), {code} and {message}.',
				'fields' => array(
					'custom_url'     => array( 'Request URL', 'text' ),
					'custom_headers' => array( 'Headers, one per line (Authorization: Bearer KEY)', 'textarea' ),
					'custom_body'    => array( 'Body (JSON or form), for example {"to":"{phone}","text":"{message}"}', 'textarea' ),
					'custom_format'  => array( 'Body format (json or form)', 'text' ),
				),
			),
		);
	}

	public static function settings() {
		$d = array(
			'enabled'  => 0,
			'force'    => 0,
			'sent_ok'  => 0,
			'provider' => 'meta',
			'cc'       => '92',
			'message'  => 'Your {site} verification code is {code}. It works for {minutes} minutes. Never share this code with anyone.',
		);
		foreach ( self::providers() as $p ) {
			foreach ( $p['fields'] as $k => $f ) {
				$d[ $k ] = '';
			}
		}
		$d['meta_lang']     = 'en_US';
		$d['meta_t_profile'] = 'mrsh_profile_reminder';
		$d['meta_t_pay']     = 'mrsh_payment_reminder';
		$d['meta_t_expired'] = 'mrsh_letter_expired';
		$d['meta_t_signed']  = 'mrsh_letter_signed';
		$d['meta_t_removed'] = 'mrsh_account_removed';
		$d['custom_format'] = 'json';
		$s = get_option( self::OPT, array() );
		return is_array( $s ) ? array_merge( $d, $s ) : $d;
	}

	public static function enabled() {
		$s = self::settings();
		return ! empty( $s['enabled'] );
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 21 );
		add_action( 'admin_post_mrsh_wa_settings', array( __CLASS__, 'save_settings' ) );
		add_action( 'admin_post_mrsh_wa_test', array( __CLASS__, 'test' ) );
		add_action( 'template_redirect', array( __CLASS__, 'gate' ), 1 );
		add_action( 'admin_init', array( __CLASS__, 'gate_admin' ), 1 );
	}

	/* ---------- mobile verification for members (replaces the theme's SMS verification) ---------- */

	const V_PEND = '_mrsh_wa_vpend';

	private static function must_verify( $uid ) {
		$s = self::settings();
		if ( empty( $s['enabled'] ) || empty( $s['force'] ) || empty( $s['sent_ok'] ) || ! $uid ) {
			return false; // never lock anyone out until the company has sent at least one message successfully.
		}
		if ( user_can( $uid, 'edit_posts' ) || user_can( $uid, 'manage_options' ) ) {
			return false; // team accounts are never blocked.
		}
		return ! get_user_meta( $uid, MRSH_TwoFactor::M_WA, true );
	}

	public static function verify_url() {
		return home_url( '/?mrsh_wa_verify=1' );
	}

	public static function gate() {
		if ( is_admin() || ! is_user_logged_in() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || wp_doing_cron() ) {
			return;
		}
		if ( isset( $_GET['mrsh_wa_verify'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			if ( self::must_verify( get_current_user_id() ) || ( self::enabled() && ! get_user_meta( get_current_user_id(), MRSH_TwoFactor::M_WA, true ) ) ) {
				self::verify_page();
			}
			wp_safe_redirect( home_url( '/' ) );
			exit;
		}
		if ( ! self::must_verify( get_current_user_id() ) ) {
			return;
		}
		$path = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore
		if ( preg_match( '#/(wp-login\.php|logout|app/)#', $path ) || isset( $_GET['action'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		wp_safe_redirect( self::verify_url() );
		exit;
	}

	/** Members who open wp-admin (profile screen) are sent to the same page. */
	public static function gate_admin() {
		if ( ! is_user_logged_in() || wp_doing_ajax() || wp_doing_cron() || ! self::must_verify( get_current_user_id() ) ) {
			return;
		}
		global $pagenow;
		if ( in_array( $pagenow, array( 'admin-post.php', 'admin-ajax.php' ), true ) ) {
			return;
		}
		wp_safe_redirect( self::verify_url() );
		exit;
	}

	private static function verify_page() {
		$uid  = get_current_user_id();
		$msg  = '';
		$vp   = get_user_meta( $uid, self::V_PEND, true );
		$step = ( is_array( $vp ) && ! empty( $vp['exp'] ) && $vp['exp'] > time() ) ? 'code' : 'phone';
		if ( 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) {
			check_admin_referer( 'mrsh_wa_verify' );
			$do = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
			if ( 'send' === $do ) {
				$num = self::normalize( sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) ) );
				$lim = 'mrsh_wa_vlim_' . $uid;
				if ( ! $num ) {
					$msg = 'Type your mobile number, for example 0300 1234567.';
				} elseif ( (int) get_transient( $lim ) >= 4 ) {
					$msg = 'Too many codes requested. Please wait 10 minutes.';
				} else {
					$code = (string) random_int( 100000, 999999 );
					$r    = self::send( $num, $code, 10 );
					set_transient( $lim, (int) get_transient( $lim ) + 1, 10 * MINUTE_IN_SECONDS );
					if ( true === $r ) {
						update_user_meta( $uid, self::V_PEND, array( 'phone' => $num, 'hash' => hash_hmac( 'sha256', $code, wp_salt( 'auth' ) ), 'exp' => time() + 10 * MINUTE_IN_SECONDS, 'tries' => 0 ) );
						$step = 'code';
						$vp   = get_user_meta( $uid, self::V_PEND, true );
						$msg  = 'We sent a code to your WhatsApp. Type it below.';
					} else {
						$msg = 'We could not send the code. Please check the number and try again.';
					}
				}
			} elseif ( 'check' === $do && is_array( $vp ) ) {
				$code = preg_replace( '/\D/', '', (string) wp_unslash( $_POST['code'] ?? '' ) );
				if ( (int) $vp['tries'] < 5 && $vp['exp'] > time() && hash_equals( $vp['hash'], hash_hmac( 'sha256', $code, wp_salt( 'auth' ) ) ) ) {
					update_user_meta( $uid, MRSH_TwoFactor::M_WA, $vp['phone'] );
					delete_user_meta( $uid, self::V_PEND );
					wp_safe_redirect( home_url( '/my-account/' ) );
					exit;
				}
				$vp['tries'] = (int) $vp['tries'] + 1;
				update_user_meta( $uid, self::V_PEND, $vp );
				$msg = 'That code is not correct. Please try again.';
			} elseif ( 'again' === $do ) {
				delete_user_meta( $uid, self::V_PEND );
				$step = 'phone';
			}
		}
		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		$name = esc_html( get_bloginfo( 'name' ) );
		echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Verify your mobile number | ' . $name . '</title>';
		echo '<style>body{margin:0;background:#f5f0e1;font-family:system-ui,Segoe UI,Roboto,sans-serif;color:#1f3a2a}.b{max-width:420px;margin:8vh auto;padding:0 16px}.c{background:#fff;border:1px solid #e7dfc8;border-radius:18px;padding:22px;box-shadow:0 8px 24px rgba(6,61,29,.1)}h1{font-size:20px;margin:0 0 6px;color:#0b3a1d}p{line-height:1.5;font-size:15px}input[type=text]{width:100%;box-sizing:border-box;font-size:18px;padding:12px;border:1px solid #d9cfb0;border-radius:12px}button{width:100%;margin-top:12px;font-size:16px;font-weight:700;padding:13px;border:0;border-radius:12px;background:#0f6b3a;color:#fff;cursor:pointer}.l{background:none;color:#0f6b3a;font-weight:600;font-size:14px}.m{background:#fff7e0;border-left:4px solid #c9a24b;padding:8px 10px;margin:10px 0;font-size:14px}</style></head><body><div class="b"><div class="c">';
		echo '<h1>Verify your mobile number</h1><p lang="ur" dir="rtl" style="margin:0 0 8px;color:#8a6414">اپنا موبائل نمبر تصدیق کریں</p>';
		if ( $msg ) {
			echo '<div class="m">' . esc_html( $msg ) . '</div>';
		}
		echo '<form method="post" action="' . esc_url( self::verify_url() ) . '">';
		wp_nonce_field( 'mrsh_wa_verify' );
		if ( 'code' === $step && is_array( $vp ) ) {
			echo '<p>We sent a 6-digit code to ' . esc_html( self::mask( $vp['phone'] ) ) . ' on WhatsApp.</p><input type="text" name="code" inputmode="numeric" autocomplete="one-time-code" maxlength="6" autofocus required><button name="do" value="check">Verify</button><button class="l" name="do" value="again" formnovalidate>Use a different number</button>';
		} else {
			echo '<p>This keeps profiles safe and real. We send a code to your WhatsApp. Your number is never shown to other members.</p><input type="text" name="phone" inputmode="tel" placeholder="0300 1234567" autofocus required><button name="do" value="send">Send code on WhatsApp</button>';
		}
		echo '</form><p style="margin:14px 0 0;font-size:13px"><a href="' . esc_url( wp_logout_url( home_url( '/' ) ) ) . '">Log out</a></p></div></div></body></html>';
		exit;
	}

	/* ---------- phone numbers ---------- */

	/** Any way of writing a number becomes digits with the country code (no plus). Returns '' when it does not look right. */
	public static function normalize( $raw, $cc = '' ) {
		$cc = preg_replace( '/\D/', '', (string) ( '' !== $cc ? $cc : self::settings()['cc'] ) );
		$n  = trim( (string) $raw );
		$plus = ( 0 === strpos( $n, '+' ) ) || ( 0 === strpos( preg_replace( '/\s/', '', $n ), '00' ) );
		$d  = preg_replace( '/\D/', '', $n );
		if ( 0 === strpos( $d, '00' ) ) {
			$d = substr( $d, 2 );
		} elseif ( ! $plus && 0 === strpos( $d, '0' ) ) {
			$d = $cc . substr( $d, 1 );
		} elseif ( ! $plus && $cc && strlen( $d ) <= 10 ) {
			$d = $cc . $d;
		}
		return preg_match( '/^[1-9]\d{7,14}$/', $d ) ? $d : '';
	}

	public static function mask( $digits ) {
		$digits = (string) $digits;
		return strlen( $digits ) > 6 ? '+' . substr( $digits, 0, 2 ) . str_repeat( '*', strlen( $digits ) - 5 ) . substr( $digits, -3 ) : '***';
	}

	/* ---------- sending ---------- */

	public static function message_for( $code, $minutes ) {
		return str_replace(
			array( '{site}', '{code}', '{minutes}' ),
			array( wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ), $code, (int) $minutes ),
			(string) self::settings()['message']
		);
	}

	/**
	 * Sends a free-text WhatsApp message (reminders, signed letters) through the company set up here;
	 * falls back to the Zapier / Make webhook (option mrsh_agr_wa_hook). Never fatal.
	 */
	public static function push( $digits, $text, $type = 'message', $extra = array(), $tpl = null ) {
		$digits = preg_replace( '/\D/', '', (string) $digits );
		if ( ! preg_match( '/^[1-9]\d{7,14}$/', $digits ) ) {
			return false;
		}
		$s   = self::settings();
		$ok  = false;
		$err = '';
		if ( 'meta' === $s['provider'] && is_array( $tpl ) && '' !== trim( (string) $s['meta_token'] ) && '' !== trim( (string) $s['meta_phone_id'] ) && '' !== trim( (string) ( $s[ 'meta_t_' . $tpl[0] ] ?? '' ) ) ) {
			$vars = array();
			foreach ( (array) $tpl[1] as $v ) {
				$vars[] = array( 'type' => 'text', 'text' => mb_substr( trim( preg_replace( '/\s+/', ' ', (string) $v ) ), 0, 500 ) ?: '-' );
			}
			$r = wp_remote_post( 'https://graph.facebook.com/v21.0/' . rawurlencode( trim( $s['meta_phone_id'] ) ) . '/messages', array(
				'timeout' => 15,
				'headers' => array( 'Content-Type' => 'application/json', 'Authorization' => 'Bearer ' . trim( $s['meta_token'] ) ),
				'body'    => wp_json_encode( array(
					'messaging_product' => 'whatsapp',
					'to'                => $digits,
					'type'              => 'template',
					'template'          => array( 'name' => trim( $s[ 'meta_t_' . $tpl[0] ] ), 'language' => array( 'code' => trim( $s['meta_lang'] ) ?: 'en_US' ), 'components' => array( array( 'type' => 'body', 'parameters' => $vars ) ) ),
				) ),
			) );
			if ( is_wp_error( $r ) ) {
				$err = $r->get_error_message();
			} else {
				$http = (int) wp_remote_retrieve_response_code( $r );
				$ok   = $http >= 200 && $http < 300;
				$err  = $ok ? '' : $http . ': ' . mb_substr( wp_strip_all_tags( wp_remote_retrieve_body( $r ) ), 0, 250 );
			}
			update_option( 'mrsh_wa_last_push', array( 'time' => time(), 'ok' => $ok, 'err' => $err, 'to' => self::mask( $digits ) ), false );
		} elseif ( 'meta' !== $s['provider'] ) {
			$req = self::build_request( $s, $digits, '', $text );
			if ( ! is_wp_error( $req ) ) {
				$r = wp_remote_request( $req['url'], array( 'timeout' => 15, 'headers' => $req['headers'], 'body' => $req['body'], 'method' => $req['method'] ) );
				if ( is_wp_error( $r ) ) {
					$err = $r->get_error_message();
				} else {
					$http = (int) wp_remote_retrieve_response_code( $r );
					$ok   = $http >= 200 && $http < 300;
					$err  = $ok ? '' : $http . ': ' . mb_substr( wp_strip_all_tags( wp_remote_retrieve_body( $r ) ), 0, 200 );
				}
				update_option( 'mrsh_wa_last_push', array( 'time' => time(), 'ok' => $ok, 'err' => $err, 'to' => self::mask( $digits ) ), false );
			}
		}
		if ( ! $ok ) {
			$hook = trim( (string) get_option( 'mrsh_agr_wa_hook' ) );
			if ( $hook ) {
				$r  = wp_remote_post( $hook, array( 'timeout' => 8, 'headers' => array( 'Content-Type' => 'application/json' ), 'body' => wp_json_encode( array_merge( array( 'type' => $type, 'phone' => $digits, 'message' => $text ), $extra ) ) ) );
				$ok = ! is_wp_error( $r ) && (int) wp_remote_retrieve_response_code( $r ) < 300;
			}
		}
		return $ok;
	}

	/** Sends one code. Returns true or a WP_Error that explains what the company answered. */
	public static function send( $digits, $code, $minutes = 10 ) {
		$s = self::settings();
		if ( empty( $s['enabled'] ) ) {
			return new WP_Error( 'mrsh_wa_off', 'WhatsApp codes are switched off.' );
		}
		$digits = preg_replace( '/\D/', '', (string) $digits );
		if ( ! preg_match( '/^[1-9]\d{7,14}$/', $digits ) ) {
			return new WP_Error( 'mrsh_wa_num', 'That phone number does not look right.' );
		}
		$msg  = self::message_for( $code, $minutes );
		$req  = self::build_request( $s, $digits, $code, $msg );
		if ( is_wp_error( $req ) ) {
			return $req;
		}
		$args = array( 'timeout' => 15, 'headers' => $req['headers'], 'body' => $req['body'], 'method' => $req['method'] );
		$r    = wp_remote_request( $req['url'], $args );
		if ( is_wp_error( $r ) ) {
			return new WP_Error( 'mrsh_wa_http', 'Could not reach the provider: ' . $r->get_error_message() );
		}
		$http = (int) wp_remote_retrieve_response_code( $r );
		if ( $http < 200 || $http > 299 ) {
			return new WP_Error( 'mrsh_wa_http', 'The provider answered ' . $http . ': ' . mb_substr( wp_strip_all_tags( wp_remote_retrieve_body( $r ) ), 0, 300 ) );
		}
		if ( empty( $s['sent_ok'] ) ) {
			$s['sent_ok'] = 1;
			update_option( self::OPT, $s, false );
		}
		return true;
	}

	/** Pure: builds url, headers and body for the chosen provider (easy to test). */
	public static function build_request( $s, $digits, $code, $msg ) {
		$json = array( 'Content-Type' => 'application/json' );
		switch ( $s['provider'] ) {
			case 'meta':
				if ( '' === trim( $s['meta_token'] ) || '' === trim( $s['meta_phone_id'] ) || '' === trim( $s['meta_template'] ) ) {
					return new WP_Error( 'mrsh_wa_cfg', 'Fill in the Meta token, phone number ID and template name.' );
				}
				return array(
					'method'  => 'POST',
					'url'     => 'https://graph.facebook.com/v21.0/' . rawurlencode( trim( $s['meta_phone_id'] ) ) . '/messages',
					'headers' => $json + array( 'Authorization' => 'Bearer ' . trim( $s['meta_token'] ) ),
					'body'    => wp_json_encode( array(
						'messaging_product' => 'whatsapp',
						'to'                => $digits,
						'type'              => 'template',
						'template'          => array(
							'name'       => trim( $s['meta_template'] ),
							'language'   => array( 'code' => trim( $s['meta_lang'] ) ?: 'en_US' ),
							'components' => array(
								array( 'type' => 'body', 'parameters' => array( array( 'type' => 'text', 'text' => $code ) ) ),
								array( 'type' => 'button', 'sub_type' => 'url', 'index' => '0', 'parameters' => array( array( 'type' => 'text', 'text' => $code ) ) ),
							),
						),
					) ),
				);
			case 'twilio':
				if ( '' === trim( $s['twilio_sid'] ) || '' === trim( $s['twilio_token'] ) || '' === trim( $s['twilio_from'] ) ) {
					return new WP_Error( 'mrsh_wa_cfg', 'Fill in the Twilio SID, token and sender number.' );
				}
				return array(
					'method'  => 'POST',
					'url'     => 'https://api.twilio.com/2010-04-01/Accounts/' . rawurlencode( trim( $s['twilio_sid'] ) ) . '/Messages.json',
					'headers' => array( 'Authorization' => 'Basic ' . base64_encode( trim( $s['twilio_sid'] ) . ':' . trim( $s['twilio_token'] ) ) ),
					'body'    => array( 'From' => 'whatsapp:+' . preg_replace( '/\D/', '', $s['twilio_from'] ), 'To' => 'whatsapp:+' . $digits, 'Body' => $msg ),
				);
			case 'vonage':
				if ( '' === trim( $s['vonage_key'] ) || '' === trim( $s['vonage_secret'] ) || '' === trim( $s['vonage_from'] ) ) {
					return new WP_Error( 'mrsh_wa_cfg', 'Fill in the Vonage key, secret and sender number.' );
				}
				return array(
					'method'  => 'POST',
					'url'     => 'https://api.nexmo.com/v1/messages',
					'headers' => $json + array( 'Authorization' => 'Basic ' . base64_encode( trim( $s['vonage_key'] ) . ':' . trim( $s['vonage_secret'] ) ) ),
					'body'    => wp_json_encode( array( 'from' => preg_replace( '/\D/', '', $s['vonage_from'] ), 'to' => $digits, 'channel' => 'whatsapp', 'message_type' => 'text', 'text' => $msg ) ),
				);
			case 'ultramsg':
				if ( '' === trim( $s['ultramsg_instance'] ) || '' === trim( $s['ultramsg_token'] ) ) {
					return new WP_Error( 'mrsh_wa_cfg', 'Fill in the UltraMsg instance ID and token.' );
				}
				return array(
					'method'  => 'POST',
					'url'     => 'https://api.ultramsg.com/' . rawurlencode( trim( $s['ultramsg_instance'] ) ) . '/messages/chat',
					'headers' => array(),
					'body'    => array( 'token' => trim( $s['ultramsg_token'] ), 'to' => '+' . $digits, 'body' => $msg ),
				);
			case 'custom':
				$url = trim( (string) $s['custom_url'] );
				if ( ! preg_match( '#^https://#i', $url ) ) {
					return new WP_Error( 'mrsh_wa_cfg', 'The request URL must start with https://.' );
				}
				$is_json = 'form' !== strtolower( trim( (string) $s['custom_format'] ) );
				$sub     = function ( $text ) use ( $digits, $code, $msg, $is_json ) {
					$vals = array( '{phone}' => $digits, '{phone_plus}' => '+' . $digits, '{code}' => $code, '{message}' => $msg );
					if ( $is_json ) {
						foreach ( $vals as $k => $v ) {
							$vals[ $k ] = substr( wp_json_encode( (string) $v ), 1, -1 ); // JSON-safe text, without the outer quotes.
						}
					} else {
						foreach ( $vals as $k => $v ) {
							$vals[ $k ] = rawurlencode( (string) $v );
						}
					}
					return str_replace( array_keys( $vals ), array_values( $vals ), $text );
				};
				$headers = array();
				foreach ( preg_split( '/\R/', (string) $s['custom_headers'] ) as $line ) {
					if ( false !== strpos( $line, ':' ) ) {
						list( $k, $v ) = array_map( 'trim', explode( ':', $line, 2 ) );
						if ( '' !== $k ) {
							$headers[ $k ] = $v;
						}
					}
				}
				if ( ! isset( $headers['Content-Type'] ) ) {
					$headers['Content-Type'] = $is_json ? 'application/json' : 'application/x-www-form-urlencoded';
				}
				return array( 'method' => 'POST', 'url' => $sub( $url ), 'headers' => $headers, 'body' => $sub( (string) $s['custom_body'] ) );
		}
		return new WP_Error( 'mrsh_wa_cfg', 'Choose a WhatsApp company first.' );
	}

	/* ---------- admin ---------- */

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'WhatsApp & Telegram Codes', 'WhatsApp & Telegram', 'manage_options', 'mrsh-whatsapp', array( __CLASS__, 'page' ) );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s = self::settings();
		MRSH_Admin::open( 'WhatsApp Codes', 'Choose the company that sends your WhatsApp messages and enter its keys. Members can use a WhatsApp code as their second step at login, and the site sends payment reminders, no-profile reminders and signed letters the same way.' );
		if ( isset( $_GET['msg'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="notice notice-info"><p>' . esc_html( rawurldecode( (string) wp_unslash( $_GET['msg'] ) ) ) . '</p></div>'; // phpcs:ignore
		}
		$prov  = self::providers();
		$lp    = get_option( 'mrsh_wa_last_push' );
		$ready = false;
		foreach ( $prov[ $s['provider'] ]['fields'] as $k => $f ) {
			if ( 'password' === $f[1] || false !== strpos( $k, 'phone_id' ) || false !== strpos( $k, 'sid' ) || false !== strpos( $k, 'instance' ) || false !== strpos( $k, 'url' ) ) {
				if ( '' !== trim( (string) $s[ $k ] ) ) {
					$ready = true;
				}
			}
		}
		?>
<style>
.mwa{max-width:980px;margin:18px 0 40px;font-size:14px}
.mwa *{box-sizing:border-box}
.mwa .chips{display:flex;gap:10px;flex-wrap:wrap;margin:0 0 18px}
.mwa .chip{background:#fff;border-radius:14px;padding:12px 16px;box-shadow:0 1px 3px rgba(17,24,39,.08),0 0 0 1px rgba(17,24,39,.04);min-width:170px}
.mwa .chip small{display:block;color:#6b7280;text-transform:uppercase;letter-spacing:.06em;font-size:11px}
.mwa .chip b{font-size:15px}
.mwa .ok{color:#047857}.mwa .no{color:#b91c1c}.mwa .wn{color:#b45309}
.mwa .card{background:#fff;border-radius:20px;padding:22px 26px;margin:0 0 16px;box-shadow:0 1px 3px rgba(17,24,39,.07),0 0 0 1px rgba(17,24,39,.04)}
.mwa .hd{display:flex;align-items:center;gap:12px;margin:0 0 6px}
.mwa .hd h2{margin:0;font-size:17px}
.mwa .n{width:30px;height:30px;border-radius:10px;background:linear-gradient(135deg,#25d366,#0b8f4d);color:#fff;display:grid;place-items:center;font-weight:700}
.mwa .sub{margin:0 0 16px;color:#6b7280;line-height:1.55;max-width:760px}
.mwa label.f{display:block;font-weight:600;margin:0 0 14px}
.mwa label.f span{display:block;font-weight:400;color:#6b7280;font-size:12.5px;margin-top:3px}
.mwa input[type=text],.mwa input[type=password],.mwa select,.mwa textarea{width:100%;max-width:520px;border:1px solid #d6dae1;border-radius:12px;padding:10px 14px;font-size:14px;background:#f8fafc;margin-top:6px}
.mwa textarea{max-width:760px}
.mwa input:focus,.mwa select:focus,.mwa textarea:focus{outline:0;border-color:#0b8f4d;box-shadow:0 0 0 3px rgba(37,211,102,.18);background:#fff}
.mwa .grid2{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:0 24px}
.mwa .box{background:#f3faf6;border:1px solid #cdeedd;border-radius:14px;padding:14px 18px;margin:12px 0 4px}
.mwa .box p.note{margin:0 0 12px;color:#14532d;line-height:1.55}
.mwa .sw{display:flex;gap:12px;align-items:flex-start;padding:12px 14px;border:1px solid #e5e7eb;border-radius:14px;margin:0 0 10px;cursor:pointer}
.mwa .sw input{margin-top:4px;width:18px;height:18px;accent-color:#0b8f4d}
.mwa .sw b{display:block}.mwa .sw span{color:#6b7280;font-size:13px}
.mwa .tpl{border:1px solid #e5e7eb;border-radius:14px;padding:12px 14px;margin:0 0 10px;background:#fafafa}
.mwa .tpl .t{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:6px}
.mwa .tpl code{background:#e8f7ee;color:#14532d;padding:3px 8px;border-radius:8px;font-size:13px}
.mwa .tpl p{margin:0;line-height:1.55;color:#374151;white-space:pre-wrap}
.mwa .btn{border:0;border-radius:12px;padding:10px 20px;font-weight:700;cursor:pointer;background:#fff;color:#111827;box-shadow:0 0 0 1px #d6dae1}
.mwa .btn.p{background:linear-gradient(135deg,#25d366,#0b8f4d);color:#fff;box-shadow:none}
.mwa .btn.s{padding:6px 12px;font-size:12.5px}
.mwa .bar{position:sticky;bottom:0;background:rgba(255,255,255,.92);backdrop-filter:blur(6px);padding:12px 0;display:flex;gap:10px;align-items:center}
.mwa .steps{margin:0 0 0 18px;color:#374151;line-height:1.7}
</style>
<div class="mwa">
	<div class="chips">
		<div class="chip"><small>WhatsApp codes</small><b class="<?php echo ! empty( $s['enabled'] ) ? 'ok' : 'no'; ?>"><?php echo ! empty( $s['enabled'] ) ? 'ON' : 'OFF'; ?></b></div>
		<div class="chip"><small>Company</small><b><?php echo esc_html( preg_replace( '/ \(.*$/', '', $prov[ $s['provider'] ]['label'] ) ); ?></b></div>
		<div class="chip"><small>Keys</small><b class="<?php echo $ready ? 'ok' : 'wn'; ?>"><?php echo $ready ? 'Saved' : 'Not entered yet'; ?></b></div>
		<div class="chip"><small>Last automatic message</small><b class="<?php echo $lp ? ( $lp['ok'] ? 'ok' : 'no' ) : ''; ?>"><?php echo $lp ? esc_html( ( $lp['ok'] ? 'Sent ' : 'Failed ' ) . wp_date( 'j M H:i', (int) $lp['time'] ) ) : 'None yet'; ?></b></div>
	</div>
	<?php if ( $lp && ! $lp['ok'] && $lp['err'] ) : ?><div class="card" style="border-left:5px solid #dc2626"><b class="no">Last error from the company:</b> <?php echo esc_html( $lp['err'] ); ?></div><?php endif; ?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="mrsh_wa_settings">
		<?php wp_nonce_field( 'mrsh_wa_settings' ); ?>

		<div class="card">
			<div class="hd"><span class="n">1</span><h2>Choose your company</h2></div>
			<p class="sub">Meta is the official WhatsApp service. The others are companies that send WhatsApp messages for you.</p>
			<label class="f">Company
				<select name="provider" id="mrsh-wa-prov">
				<?php foreach ( $prov as $id => $p ) : ?>
					<option value="<?php echo esc_attr( $id ); ?>"<?php selected( $s['provider'], $id ); ?>><?php echo esc_html( $p['label'] ); ?></option>
				<?php endforeach; ?>
				</select>
			</label>
			<?php foreach ( $prov as $id => $p ) : ?>
				<div class="box mrsh-wa-box" data-p="<?php echo esc_attr( $id ); ?>">
					<p class="note"><?php echo esc_html( $p['note'] ); ?></p>
					<div class="grid2">
					<?php foreach ( $p['fields'] as $k => $f ) : ?>
						<label class="f"><?php echo esc_html( $f[0] ); ?>
						<?php if ( 'textarea' === $f[1] ) : ?>
							<textarea name="<?php echo esc_attr( $k ); ?>" rows="4" class="code"><?php echo esc_textarea( $s[ $k ] ); ?></textarea>
						<?php elseif ( 'password' === $f[1] ) : ?>
							<input type="password" name="<?php echo esc_attr( $k ); ?>" value="" autocomplete="new-password" placeholder="<?php echo '' !== $s[ $k ] ? 'Saved. Leave empty to keep it.' : ''; ?>">
						<?php else : ?>
							<input type="text" name="<?php echo esc_attr( $k ); ?>" value="<?php echo esc_attr( $s[ $k ] ); ?>">
						<?php endif; ?>
						</label>
					<?php endforeach; ?>
					</div>
				</div>
			<?php endforeach; ?>
		</div>

		<div class="card">
			<div class="hd"><span class="n">2</span><h2>Settings</h2></div>
			<p class="sub">Phone numbers stay private: only the member sees theirs, partly hidden.</p>
			<label class="sw"><input type="checkbox" name="enabled" value="1"<?php checked( ! empty( $s['enabled'] ) ); ?>><div><b>Turn on WhatsApp codes</b><span>Members can choose WhatsApp as their second step when they log in.</span></div></label>
			<label class="sw"><input type="checkbox" name="force" value="1"<?php checked( ! empty( $s['force'] ) ); ?>><div><b>Require every member to verify their mobile number</b><span>By a WhatsApp code before using their account. Replaces the theme's "Force SMS verification".</span></div></label>
			<div class="grid2">
				<label class="f">Default country code<input type="text" name="cc" value="<?php echo esc_attr( $s['cc'] ); ?>" style="max-width:120px"><span>92 = Pakistan. Numbers typed like 0300... become +92300...</span></label>
			</div>
			<label class="f">Message text (used where the company allows free text)<textarea name="message" rows="3"><?php echo esc_textarea( $s['message'] ); ?></textarea><span>Placeholders: {site}, {code}, {minutes}.</span></label>
		</div>

		<div class="card">
			<div class="hd"><span class="n">3</span><h2>Reminder templates for Meta</h2></div>
			<p class="sub">Only needed with the Meta option. In Meta Business Manager open <b>WhatsApp Manager, Message templates, Create template</b>. Category <b>Utility</b>, the language saved above. Paste the name and the text exactly, give any sample for each {{number}}, and wait for <b>Approved</b>.</p>
			<?php
			foreach ( array(
				array( 'mrsh_profile_reminder', 'Assalam o Alaikum {{1}}, you registered on My Rishta Pakistan but have not created your profile yet. It is free and takes about 3 minutes. Your account will be removed in {{2}} day(s) without a profile. Create it here: {{3}} Thank you.' ),
				array( 'mrsh_payment_reminder', 'Assalam o Alaikum {{1}}, your agreement letter {{2}} is not authenticated yet. It becomes valid only after payment and our stamp. {{3}} day(s) are left before the reference is cancelled. Open your letter: {{4}} Thank you.' ),
				array( 'mrsh_letter_expired', 'Assalam o Alaikum {{1}}, your agreement letter {{2}} has expired and is not authenticated. Please contact us if you still need it. Thank you.' ),
				array( 'mrsh_letter_signed', 'Assalam o Alaikum {{1}}, your agreement letter {{2}} is now stamped and digitally signed. Open or save the PDF here: {{3}} Thank you.' ),
				array( 'mrsh_account_removed', 'Assalam o Alaikum {{1}}, your account on My Rishta Pakistan was removed because no profile was created in 14 days. Thank you.' ),
			) as $t ) :
				?>
				<div class="tpl"><div class="t"><code><?php echo esc_html( $t[0] ); ?></code><button type="button" class="btn s" data-copy="<?php echo esc_attr( $t[1] ); ?>">Copy text</button></div><p><?php echo esc_html( $t[1] ); ?></p></div>
			<?php endforeach; ?>
		</div>

		<div class="bar"><button class="btn p">Save settings</button><span style="color:#6b7280">Keys are stored on your site only.</span></div>
	</form>

	<div class="card" style="margin-top:8px">
		<div class="hd"><span class="n">4</span><h2>Send a test</h2></div>
		<p class="sub">Save first, then send a test code to your own WhatsApp number.</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
			<input type="hidden" name="action" value="mrsh_wa_test">
			<?php wp_nonce_field( 'mrsh_wa_test' ); ?>
			<input type="text" name="phone" placeholder="0300 1234567" style="max-width:260px;border:1px solid #d6dae1;border-radius:12px;padding:10px 14px"> <button class="btn p">Send test code</button>
		</form>
	</div>
	<?php do_action( 'mrsh_wa_page_extra' ); ?>
</div>
<script>
(function(){
var s=document.getElementById("mrsh-wa-prov");
function f(){document.querySelectorAll(".mrsh-wa-box").forEach(function(b){b.style.display=b.getAttribute("data-p")===s.value?"block":"none"})}
s.addEventListener("change",f);f();
document.querySelectorAll("[data-copy]").forEach(function(b){b.addEventListener("click",function(){var t=b.getAttribute("data-copy");function done(){b.textContent="Copied";setTimeout(function(){b.textContent="Copy text"},1500)}if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t).then(done,function(){})}else{var a=document.createElement("textarea");a.value=t;document.body.appendChild(a);a.select();try{document.execCommand("copy");done()}catch(e){}a.remove()}})});
})();
</script>
		<?php
		echo '</div>';
	}

	public static function save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_wa_settings' );
		$old = self::settings();
		$new = $old;
		$new['enabled']  = empty( $_POST['enabled'] ) ? 0 : 1;
		$new['force']    = empty( $_POST['force'] ) ? 0 : 1;
		$prov            = isset( $_POST['provider'] ) ? sanitize_key( wp_unslash( $_POST['provider'] ) ) : 'meta';
		$new['provider'] = isset( self::providers()[ $prov ] ) ? $prov : 'meta';
		$new['cc']       = preg_replace( '/\D/', '', (string) wp_unslash( $_POST['cc'] ?? '92' ) ) ?: '92';
		$new['message']  = sanitize_textarea_field( wp_unslash( $_POST['message'] ?? $old['message'] ) );
		if ( false === strpos( $new['message'], '{code}' ) ) {
			$new['message'] = $old['message'];
		}
		foreach ( self::providers() as $p ) {
			foreach ( $p['fields'] as $k => $f ) {
				if ( ! isset( $_POST[ $k ] ) ) {
					continue;
				}
				$v = 'textarea' === $f[1] ? sanitize_textarea_field( wp_unslash( $_POST[ $k ] ) ) : sanitize_text_field( wp_unslash( $_POST[ $k ] ) );
				if ( 'password' === $f[1] && '' === $v ) {
					continue; // keep the saved secret.
				}
				if ( 'custom_body' === $k ) {
					$v = wp_strip_all_tags( wp_unslash( $_POST[ $k ] ), false ); // keep braces and quotes exactly.
				}
				$new[ $k ] = $v;
			}
		}
		update_option( self::OPT, $new, false );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-whatsapp&msg=' . rawurlencode( 'Saved.' ) ) );
		exit;
	}

	public static function test() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_wa_test' );
		$n = self::normalize( sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) ) );
		if ( '' === $n ) {
			$msg = 'That phone number does not look right.';
		} else {
			$r   = self::send( $n, (string) random_int( 100000, 999999 ), 10 );
			$msg = true === $r ? 'The company accepted the message. Check your WhatsApp.' : $r->get_error_message();
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-whatsapp&msg=' . rawurlencode( $msg ) ) );
		exit;
	}
}
