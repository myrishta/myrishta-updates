<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Social Hub (3.101.417): connect Telegram, Bluesky, Facebook and Instagram from the admin, write a post once,
 * and let the site publish it on every connected network at the time you choose. Free: it uses each network's own
 * official API and the WordPress scheduler, so there is no monthly tool and no extra plugin.
 * Facebook and Instagram use the "Connect with Facebook" login button (a Meta developer app of your own is needed once).
 */
class MRSH_Social {

	const OPT  = 'mrsh_sochub';
	const CRON = 'mrsh_social_tick';
	const GRAPH = 'https://graph.facebook.com/v21.0/';

	public static function init() {
		add_filter( 'cron_schedules', array( __CLASS__, 'schedules' ) );
		add_action( self::CRON, array( __CLASS__, 'tick' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
		if ( is_admin() ) {
			add_action( 'admin_menu', array( __CLASS__, 'menu' ), 47 );
			foreach ( array( 'save', 'fbconnect', 'fbcb', 'fbpage', 'disconnect', 'test', 'add', 'now', 'del', 'fill', 'retry' ) as $a ) {
				add_action( 'admin_post_mrsh_soc_' . $a, array( __CLASS__, 'act_' . $a ) );
			}
		}
	}

	public static function schedules( $s ) {
		$s['mrsh_15min'] = array( 'interval' => 900, 'display' => 'Every 15 minutes' );
		return $s;
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::CRON ) ) {
			wp_schedule_event( time() + 300, 'mrsh_15min', self::CRON );
		}
	}

	public static function o() {
		$o = get_option( self::OPT, array() );
		$o = is_array( $o ) ? $o : array();
		return $o + array(
			'on' => 1, 'mail' => 1, 'time' => '18:00', 'tg_token' => '', 'tg_chat' => '', 'bs_handle' => '', 'bs_pass' => '',
			'fb_app' => '', 'fb_secret' => '', 'pages' => array(), 'page' => '', 'queue' => array(), 'n' => 0,
		);
	}

	private static function put( $o ) {
		update_option( self::OPT, $o, false );
	}

	/** Which networks are ready to post. */
	public static function nets( $o = null ) {
		$o   = $o ? $o : self::o();
		$out = array();
		if ( $o['tg_token'] && $o['tg_chat'] ) {
			$out['telegram'] = 'Telegram';
		}
		if ( $o['bs_handle'] && $o['bs_pass'] ) {
			$out['bluesky'] = 'Bluesky';
		}
		$p = self::cur_page( $o );
		if ( $p ) {
			$out['facebook'] = 'Facebook';
			if ( ! empty( $p['ig'] ) ) {
				$out['instagram'] = 'Instagram';
			}
		}
		return $out;
	}

	private static function cur_page( $o ) {
		foreach ( (array) $o['pages'] as $p ) {
			if ( (string) $p['id'] === (string) $o['page'] ) {
				return $p;
			}
		}
		return $o['pages'] ? reset( $o['pages'] ) : null;
	}

	/* ------------------------------------------------------------ publishing */
	public static function tick() {
		$o = self::o();
		if ( empty( $o['on'] ) ) {
			return;
		}
		$changed = false;
		foreach ( $o['queue'] as $i => $q ) {
			if ( 'queued' === $q['status'] && (int) $q['ts'] <= time() ) {
				$o['queue'][ $i ] = self::publish( $q, $o );
				$changed          = true;
				if ( 'failed' === $o['queue'][ $i ]['status'] ) {
					self::alert( $o['queue'][ $i ], $o );
				}
			}
		}
		if ( $changed ) {
			$o['queue'] = array_slice( $o['queue'], -80 );
			self::put( $o );
		}
	}

	private static function alert( $q, $o ) {
		if ( class_exists( 'MRSH_Fixer' ) ) {
			MRSH_Fixer::ticket( 'social-' . $q['id'], 'A social post could not be sent', $q['log'] . ' Open Social Hub, check the connection and press Try again.', 'med', 'needs_approval', admin_url( 'admin.php?page=mrsh-sochub' ) );
		}
		if ( ! empty( $o['mail'] ) ) {
			wp_mail( get_option( 'admin_email' ), '[MyRishta] A social post did not go out', "Assalam o Alaikum,\n\n" . $q['log'] . "\n\nOpen Social Hub and press Try again: " . admin_url( 'admin.php?page=mrsh-sochub' ) . "\n" );
		}
	}

	public static function publish( $q, $o ) {
		$log = array();
		$ok  = 0;
		foreach ( (array) $q['nets'] as $n ) {
			if ( ! empty( $q['done'][ $n ] ) ) {
				++$ok;
				continue;
			}
			$r = self::send( $n, $q, $o );
			if ( true === $r ) {
				$q['done'][ $n ] = 1;
				$log[]           = $n . ': sent';
				++$ok;
			} else {
				$log[] = $n . ': ' . $r;
			}
		}
		$q['status'] = $ok === count( (array) $q['nets'] ) ? 'sent' : 'failed';
		$q['log']    = implode( '; ', $log );
		if ( 'sent' === $q['status'] && class_exists( 'MRSH_Fixer' ) ) {
			MRSH_Fixer::ticket_resolve( 'social-' . $q['id'] );
		}
		return $q;
	}

	private static function body( $q ) {
		return trim( $q['text'] . ( $q['link'] ? "\n\n" . $q['link'] : '' ) );
	}

	private static function send( $net, $q, $o ) {
		$fn = 'send_' . $net;
		return method_exists( __CLASS__, $fn ) ? self::$fn( $q, $o ) : 'not supported';
	}

	private static function err( $r, $key = 'error' ) {
		if ( is_wp_error( $r ) ) {
			return $r->get_error_message();
		}
		$b = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( is_array( $b ) && isset( $b[ $key ] ) ) {
			$e = $b[ $key ];
			return is_array( $e ) ? ( $e['message'] ?? wp_json_encode( $e ) ) : (string) $e;
		}
		return 'HTTP ' . wp_remote_retrieve_response_code( $r );
	}

	private static function send_telegram( $q, $o ) {
		$base = 'https://api.telegram.org/bot' . rawurlencode( $o['tg_token'] ) . '/';
		$text = self::body( $q );
		if ( $q['image'] ) {
			$r = wp_remote_post( $base . 'sendPhoto', array( 'timeout' => 30, 'body' => array( 'chat_id' => $o['tg_chat'], 'photo' => $q['image'], 'caption' => mb_substr( $text, 0, 1000 ) ) ) );
		} else {
			$r = wp_remote_post( $base . 'sendMessage', array( 'timeout' => 30, 'body' => array( 'chat_id' => $o['tg_chat'], 'text' => $text ) ) );
		}
		$b = is_wp_error( $r ) ? null : json_decode( wp_remote_retrieve_body( $r ), true );
		return ( is_array( $b ) && ! empty( $b['ok'] ) ) ? true : ( is_array( $b ) && isset( $b['description'] ) ? $b['description'] : self::err( $r ) );
	}

	private static function bs_session( $o ) {
		$r = wp_remote_post( 'https://bsky.social/xrpc/com.atproto.server.createSession', array( 'timeout' => 30, 'headers' => array( 'Content-Type' => 'application/json' ), 'body' => wp_json_encode( array( 'identifier' => $o['bs_handle'], 'password' => $o['bs_pass'] ) ) ) );
		$b = is_wp_error( $r ) ? null : json_decode( wp_remote_retrieve_body( $r ), true );
		if ( is_array( $b ) && ! empty( $b['accessJwt'] ) ) {
			return $b;
		}
		return is_array( $b ) && isset( $b['message'] ) ? (string) $b['message'] : self::err( $r, 'message' );
	}

	/** Link facets must use UTF-8 byte positions. */
	public static function bs_record( $text, $link, $blob = null ) {
		$full = $text;
		$rec  = array( '$type' => 'app.bsky.feed.post', 'text' => '', 'createdAt' => gmdate( 'c' ), 'langs' => array( 'ur', 'en' ) );
		if ( $link ) {
			$full = trim( $text . "\n\n" . $link );
			$pos  = strlen( $full ) - strlen( $link );
			$rec['facets'] = array( array( 'index' => array( 'byteStart' => $pos, 'byteEnd' => strlen( $full ) ), 'features' => array( array( '$type' => 'app.bsky.richtext.facet#link', 'uri' => $link ) ) ) );
		}
		$rec['text'] = $full;
		if ( $blob ) {
			$rec['embed'] = array( '$type' => 'app.bsky.embed.images', 'images' => array( array( 'alt' => mb_substr( $text, 0, 100 ), 'image' => $blob ) ) );
		}
		return $rec;
	}

	private static function send_bluesky( $q, $o ) {
		$s = self::bs_session( $o );
		if ( ! is_array( $s ) ) {
			return $s;
		}
		$h    = array( 'Authorization' => 'Bearer ' . $s['accessJwt'] );
		$blob = null;
		if ( $q['image'] ) {
			$img = wp_remote_get( $q['image'], array( 'timeout' => 30 ) );
			if ( ! is_wp_error( $img ) && 200 === (int) wp_remote_retrieve_response_code( $img ) ) {
				$up = wp_remote_post( 'https://bsky.social/xrpc/com.atproto.repo.uploadBlob', array( 'timeout' => 40, 'headers' => $h + array( 'Content-Type' => wp_remote_retrieve_header( $img, 'content-type' ) ?: 'image/jpeg' ), 'body' => wp_remote_retrieve_body( $img ) ) );
				$ub = is_wp_error( $up ) ? null : json_decode( wp_remote_retrieve_body( $up ), true );
				$blob = is_array( $ub ) && isset( $ub['blob'] ) ? $ub['blob'] : null;
			}
		}
		$rec = self::bs_record( $q['text'], $q['link'], $blob );
		$r   = wp_remote_post( 'https://bsky.social/xrpc/com.atproto.repo.createRecord', array( 'timeout' => 30, 'headers' => $h + array( 'Content-Type' => 'application/json' ), 'body' => wp_json_encode( array( 'repo' => $s['did'], 'collection' => 'app.bsky.feed.post', 'record' => $rec ) ) ) );
		$b   = is_wp_error( $r ) ? null : json_decode( wp_remote_retrieve_body( $r ), true );
		return ( is_array( $b ) && isset( $b['uri'] ) ) ? true : ( is_array( $b ) && isset( $b['message'] ) ? $b['message'] : self::err( $r, 'message' ) );
	}

	private static function send_facebook( $q, $o ) {
		$p = self::cur_page( $o );
		if ( ! $p ) {
			return 'no Facebook page connected';
		}
		$args = array( 'access_token' => $p['token'] );
		if ( $q['image'] ) {
			$args['url']     = self::jpeg_url( $q['image'] );
			$args['caption'] = self::body( $q );
			$r               = wp_remote_post( self::GRAPH . rawurlencode( $p['id'] ) . '/photos', array( 'timeout' => 40, 'body' => $args ) );
		} else {
			$args['message'] = $q['text'];
			if ( $q['link'] ) {
				$args['link'] = $q['link'];
			}
			$r = wp_remote_post( self::GRAPH . rawurlencode( $p['id'] ) . '/feed', array( 'timeout' => 40, 'body' => $args ) );
		}
		$b = is_wp_error( $r ) ? null : json_decode( wp_remote_retrieve_body( $r ), true );
		return ( is_array( $b ) && ( isset( $b['id'] ) || isset( $b['post_id'] ) ) ) ? true : self::err( $r );
	}

	private static function send_instagram( $q, $o ) {
		$p = self::cur_page( $o );
		if ( ! $p || empty( $p['ig'] ) ) {
			return 'no Instagram account linked to the page';
		}
		if ( ! $q['image'] ) {
			return 'Instagram needs an image';
		}
		$cap = self::body( $q );
		$r   = wp_remote_post( self::GRAPH . rawurlencode( $p['ig'] ) . '/media', array( 'timeout' => 40, 'body' => array( 'image_url' => self::jpeg_url( $q['image'] ), 'caption' => $cap, 'access_token' => $p['token'] ) ) );
		$b   = is_wp_error( $r ) ? null : json_decode( wp_remote_retrieve_body( $r ), true );
		if ( ! is_array( $b ) || empty( $b['id'] ) ) {
			return self::err( $r );
		}
		sleep( 4 );
		$r2 = wp_remote_post( self::GRAPH . rawurlencode( $p['ig'] ) . '/media_publish', array( 'timeout' => 40, 'body' => array( 'creation_id' => $b['id'], 'access_token' => $p['token'] ) ) );
		$b2 = is_wp_error( $r2 ) ? null : json_decode( wp_remote_retrieve_body( $r2 ), true );
		return ( is_array( $b2 ) && ! empty( $b2['id'] ) ) ? true : self::err( $r2 );
	}

	/** Instagram refuses WebP. If the picture is WebP (WordPress may store it that way), save a JPEG copy and use that. */
	public static function jpeg_url( $url ) {
		if ( ! preg_match( '/\.webp(\?|$)/i', $url ) ) {
			return $url;
		}
		$id = attachment_url_to_postid( $url );
		$f  = $id ? get_attached_file( $id ) : '';
		if ( ! $f || ! file_exists( $f ) ) {
			return $url;
		}
		$dest = preg_replace( '/\.webp$/i', '-ig.jpg', $f );
		if ( ! file_exists( $dest ) ) {
			$ed = wp_get_image_editor( $f );
			if ( is_wp_error( $ed ) ) {
				return $url;
			}
			$ed->set_quality( 90 );
			$s = $ed->save( $dest, 'image/jpeg' );
			if ( is_wp_error( $s ) ) {
				return $url;
			}
		}
		return preg_replace( '/\.webp(\?.*)?$/i', '-ig.jpg', $url );
	}

	/* --------------------------------------------------------------- actions */
	private static function guard( $a ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( $a );
	}

	private static function back( $m ) {
		wp_safe_redirect( add_query_arg( array( 'page' => 'mrsh-sochub', 'msg' => rawurlencode( $m ) ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public static function act_save() {
		self::guard( 'mrsh_soc_save' );
		$o = self::o();
		foreach ( array( 'tg_token', 'tg_chat', 'bs_handle', 'bs_pass', 'fb_app', 'fb_secret' ) as $k ) {
			if ( isset( $_POST[ $k ] ) ) {
				$o[ $k ] = trim( sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) );
			}
		}
		$o['on']   = empty( $_POST['on'] ) ? 0 : 1;
		$o['mail'] = empty( $_POST['mail'] ) ? 0 : 1;
		if ( isset( $_POST['time'] ) && preg_match( '/^\d{2}:\d{2}$/', (string) $_POST['time'] ) ) {
			$o['time'] = (string) $_POST['time'];
		}
		self::put( $o );
		self::back( 'Saved.' );
	}

	public static function redirect_uri() {
		return admin_url( 'admin-post.php?action=mrsh_soc_fbcb' );
	}

	public static function act_fbconnect() {
		self::guard( 'mrsh_soc_fbconnect' );
		$o = self::o();
		if ( ! $o['fb_app'] || ! $o['fb_secret'] ) {
			self::back( 'First save your Meta App ID and App Secret in the Facebook card.' );
		}
		$u = 'https://www.facebook.com/v21.0/dialog/oauth?' . http_build_query( array(
			'client_id'    => $o['fb_app'],
			'redirect_uri' => self::redirect_uri(),
			'state'        => wp_create_nonce( 'mrsh_soc_fbstate' ),
			'scope'        => 'pages_show_list,pages_manage_posts,pages_read_engagement,instagram_basic,instagram_content_publish,business_management',
		) );
		wp_redirect( $u ); // phpcs:ignore WordPress.Security.SafeRedirect
		exit;
	}

	public static function act_fbcb() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		if ( empty( $_GET['state'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['state'] ) ), 'mrsh_soc_fbstate' ) ) {
			self::back( 'Facebook sign-in expired. Press Connect with Facebook again.' );
		}
		if ( empty( $_GET['code'] ) ) {
			self::back( 'Facebook sign-in was cancelled.' );
		}
		$o = self::o();
		$t = self::fb_get( 'oauth/access_token', array( 'client_id' => $o['fb_app'], 'client_secret' => $o['fb_secret'], 'redirect_uri' => self::redirect_uri(), 'code' => sanitize_text_field( wp_unslash( $_GET['code'] ) ) ) );
		if ( empty( $t['access_token'] ) ) {
			self::back( 'Facebook said: ' . ( $t['error']['message'] ?? 'no token' ) );
		}
		$l = self::fb_get( 'oauth/access_token', array( 'grant_type' => 'fb_exchange_token', 'client_id' => $o['fb_app'], 'client_secret' => $o['fb_secret'], 'fb_exchange_token' => $t['access_token'] ) );
		$tok = ! empty( $l['access_token'] ) ? $l['access_token'] : $t['access_token'];
		$a   = self::fb_get( 'me/accounts', array( 'access_token' => $tok, 'fields' => 'id,name,access_token,instagram_business_account{id,username}', 'limit' => 25 ) );
		if ( empty( $a['data'] ) ) {
			self::back( 'No Facebook page was shared. Connect again and tick your page.' );
		}
		$pages = array();
		foreach ( $a['data'] as $p ) {
			$pages[] = array( 'id' => $p['id'], 'name' => $p['name'], 'token' => $p['access_token'], 'ig' => $p['instagram_business_account']['id'] ?? '', 'igname' => $p['instagram_business_account']['username'] ?? '' );
		}
		$o['pages'] = $pages;
		if ( ! $o['page'] || ! self::cur_page( $o ) ) {
			$o['page'] = $pages[0]['id'];
		}
		self::put( $o );
		self::back( 'Facebook connected: ' . $pages[0]['name'] . '.' );
	}

	private static function fb_get( $path, $args ) {
		$r = wp_remote_get( self::GRAPH . $path . '?' . http_build_query( $args ), array( 'timeout' => 30 ) );
		$b = is_wp_error( $r ) ? array() : json_decode( wp_remote_retrieve_body( $r ), true );
		return is_array( $b ) ? $b : array();
	}

	public static function act_fbpage() {
		self::guard( 'mrsh_soc_fbpage' );
		$o         = self::o();
		$o['page'] = isset( $_POST['page'] ) ? sanitize_text_field( wp_unslash( $_POST['page'] ) ) : '';
		self::put( $o );
		self::back( 'Page chosen.' );
	}

	public static function act_disconnect() {
		self::guard( 'mrsh_soc_disconnect' );
		$o  = self::o();
		$n  = isset( $_POST['net'] ) ? sanitize_key( wp_unslash( $_POST['net'] ) ) : '';
		if ( 'telegram' === $n ) {
			$o['tg_token'] = '';
			$o['tg_chat']  = '';
		} elseif ( 'bluesky' === $n ) {
			$o['bs_handle'] = '';
			$o['bs_pass']   = '';
		} elseif ( 'facebook' === $n ) {
			$o['pages'] = array();
			$o['page']  = '';
		}
		self::put( $o );
		self::back( 'Disconnected.' );
	}

	public static function act_test() {
		self::guard( 'mrsh_soc_test' );
		$o = self::o();
		$n = isset( $_POST['net'] ) ? sanitize_key( wp_unslash( $_POST['net'] ) ) : '';
		if ( 'telegram' === $n ) {
			$r = wp_remote_get( 'https://api.telegram.org/bot' . rawurlencode( $o['tg_token'] ) . '/getMe', array( 'timeout' => 20 ) );
			$b = is_wp_error( $r ) ? null : json_decode( wp_remote_retrieve_body( $r ), true );
			$m = ( is_array( $b ) && ! empty( $b['ok'] ) ) ? 'Telegram works: bot @' . $b['result']['username'] : 'Telegram problem: ' . ( $b['description'] ?? 'no answer' );
		} elseif ( 'bluesky' === $n ) {
			$s = self::bs_session( $o );
			$m = is_array( $s ) ? 'Bluesky works: ' . $s['handle'] : 'Bluesky problem: ' . $s;
		} else {
			$p = self::cur_page( $o );
			$b = $p ? self::fb_get( 'me', array( 'access_token' => $p['token'], 'fields' => 'id,name' ) ) : array();
			$m = ! empty( $b['id'] ) ? 'Facebook works: ' . $b['name'] : 'Facebook problem: ' . ( $b['error']['message'] ?? 'not connected' );
		}
		self::back( $m );
	}

	private static function item_from_post() {
		$nets = isset( $_POST['nets'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['nets'] ) ) : array(); // phpcs:ignore
		return array(
			'text'  => isset( $_POST['text'] ) ? sanitize_textarea_field( wp_unslash( $_POST['text'] ) ) : '',
			'link'  => isset( $_POST['link'] ) ? esc_url_raw( wp_unslash( $_POST['link'] ) ) : '',
			'image' => isset( $_POST['image'] ) ? esc_url_raw( wp_unslash( $_POST['image'] ) ) : '',
			'nets'  => array_values( array_intersect( $nets, array_keys( self::nets() ) ) ),
		);
	}

	private static function new_item( $o, $f, $ts ) {
		++$o['n'];
		return array( 'o' => $o, 'q' => $f + array( 'id' => time() . $o['n'], 'ts' => $ts, 'status' => 'queued', 'log' => '', 'done' => array() ) );
	}

	public static function act_add() {
		self::guard( 'mrsh_soc_add' );
		$f = self::item_from_post();
		if ( ! $f['text'] || ! $f['nets'] ) {
			self::back( 'Write the post and tick at least one connected network.' );
		}
		$ts = ! empty( $_POST['when'] ) ? strtotime( sanitize_text_field( wp_unslash( $_POST['when'] ) ) . ' ' . wp_timezone_string() ) : time();
		$ts = $ts ? $ts : time();
		$o  = self::o();
		$x  = self::new_item( $o, $f, $ts );
		$x['o']['queue'][] = $x['q'];
		self::put( $x['o'] );
		if ( $ts <= time() + 60 ) {
			self::tick();
		}
		self::back( 'Added to the queue.' );
	}

	public static function act_now() {
		self::guard( 'mrsh_soc_now' );
		$id = isset( $_POST['id'] ) ? sanitize_text_field( wp_unslash( $_POST['id'] ) ) : '';
		$o  = self::o();
		foreach ( $o['queue'] as $i => $q ) {
			if ( (string) $q['id'] === $id ) {
				$q['status'] = 'queued';
				$q['ts']     = time() - 1;
				$o['queue'][ $i ] = $q;
			}
		}
		self::put( $o );
		self::tick();
		self::back( 'Sent. See the result in the queue below.' );
	}

	public static function act_retry() {
		self::act_now();
	}

	public static function act_del() {
		self::guard( 'mrsh_soc_del' );
		$id = isset( $_POST['id'] ) ? sanitize_text_field( wp_unslash( $_POST['id'] ) ) : '';
		$o  = self::o();
		foreach ( $o['queue'] as $i => $q ) {
			if ( (string) $q['id'] === $id ) {
				unset( $o['queue'][ $i ] );
				if ( class_exists( 'MRSH_Fixer' ) ) {
					MRSH_Fixer::ticket_resolve( 'social-' . $id );
				}
			}
		}
		$o['queue'] = array_values( $o['queue'] );
		self::put( $o );
		self::back( 'Removed.' );
	}

	/** Fill the next 7 evenings from the same rotating topics the YouTube helper uses (Urdu text and the page link). */
	public static function act_fill() {
		self::guard( 'mrsh_soc_fill' );
		$o    = self::o();
		$nets = array_keys( self::nets( $o ) );
		if ( ! $nets || ! class_exists( 'MRSH_YtPost' ) ) {
			self::back( 'Connect a network first.' );
		}
		$tp  = MRSH_YtPost::topics();
		$img = isset( $_POST['image'] ) ? esc_url_raw( wp_unslash( $_POST['image'] ) ) : '';
		for ( $d = 0; $d < 7; $d++ ) {
			$t  = $tp[ ( (int) $o['n'] + $d ) % count( $tp ) ];
			$ts = strtotime( wp_date( 'Y-m-d', time() + ( $d + 1 ) * DAY_IN_SECONDS ) . ' ' . $o['time'] . ' ' . wp_timezone_string() );
			$use = $nets;
			if ( ! $img ) {
				$use = array_values( array_diff( $nets, array( 'instagram' ) ) );
			}
			if ( ! $use ) {
				continue;
			}
			$x           = self::new_item( $o, array( 'text' => $t[3], 'link' => add_query_arg( array( 'utm_source' => 'social', 'utm_medium' => 'social', 'utm_campaign' => 'daily_post' ), $t[2] ), 'image' => $img, 'nets' => $use ), $ts );
			$o           = $x['o'];
			$o['queue'][] = $x['q'];
		}
		self::put( $o );
		self::back( 'Added the next 7 evenings to the queue.' );
	}

	/* ----------------------------------------------------------------- admin */
	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Social Hub', 'Social Hub', 'manage_options', 'mrsh-sochub', array( __CLASS__, 'page' ) );
	}

	private static function card( $title, $badge, $ok, $inner ) {
		echo '<div class="mx-card"><h2 style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">' . esc_html( $title ) . ' <span class="mx-badge" style="background:' . ( $ok ? '#10b981' : '#9ca3af' ) . ';color:#fff;border-radius:999px;padding:2px 10px;font-size:12px">' . esc_html( $badge ) . '</span></h2>' . $inner . '</div>'; // phpcs:ignore
	}

	private static function form( $action, $fields, $btn = 'Save', $extra = '' ) {
		ob_start();
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="' . esc_attr( $action ) . '">';
		wp_nonce_field( $action );
		echo $fields . '<p style="display:flex;gap:8px;flex-wrap:wrap"><button class="button button-primary">' . esc_html( $btn ) . '</button>' . $extra . '</p></form>'; // phpcs:ignore
		return ob_get_clean();
	}

	private static function mini( $action, $label, $net = '', $id = '', $primary = false ) {
		ob_start();
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="mrsh-inline"><input type="hidden" name="action" value="' . esc_attr( $action ) . '">';
		wp_nonce_field( $action );
		if ( $net ) {
			echo '<input type="hidden" name="net" value="' . esc_attr( $net ) . '">';
		}
		if ( $id ) {
			echo '<input type="hidden" name="id" value="' . esc_attr( $id ) . '">';
		}
		echo '<button class="button ' . ( $primary ? 'button-primary' : '' ) . '">' . esc_html( $label ) . '</button></form>';
		return ob_get_clean();
	}

	private static function inp( $k, $label, $v, $type = 'text', $ph = '' ) {
		return '<p><label><b>' . esc_html( $label ) . '</b><br><input type="' . esc_attr( $type ) . '" name="' . esc_attr( $k ) . '" value="' . esc_attr( $v ) . '" placeholder="' . esc_attr( $ph ) . '" class="regular-text" style="width:100%;max-width:520px" autocomplete="off" data-lpignore="true"></label></p>';
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		wp_enqueue_media();
		$o    = self::o();
		$nets = self::nets( $o );
		$sent = 0;
		$wait = 0;
		$bad  = 0;
		foreach ( $o['queue'] as $q ) {
			if ( 'sent' === $q['status'] ) {
				++$sent;
			} elseif ( 'queued' === $q['status'] ) {
				++$wait;
			} else {
				++$bad;
			}
		}
		MRSH_Boost::ui_open( 'Social Hub', 'Connect your accounts once. Write a post once. The site publishes it on every connected network at the time you choose.', 'g-blue', 'M18 16.1c-.8 0-1.5.3-2 .8l-7.100-4.200c.1-.2.1-.5.1-.7s0-.5-.1-.7L16 7.200c.5.5 1.200.8 2 .8 1.700 0 3-1.300 3-3s-1.300-3-3-3-3 1.300-3 3c0 .2 0 .5.1.700L8 9.900C7.500 9.400 6.800 9.100 6 9.100c-1.700 0-3 1.300-3 3s1.300 3 3 3c.8 0 1.500-.3 2-.8l7.200 4.200c-.1.200-.1.400-.1.700 0 1.600 1.300 2.900 2.900 2.900s2.900-1.300 2.900-2.900-1.300-2.900-2.900-2.900z' );
		if ( isset( $_GET['msg'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			MRSH_Boost::ui_ok( rawurldecode( (string) wp_unslash( $_GET['msg'] ) ) ); // phpcs:ignore
		}
		echo '<div class="mx-stats">' . MRSH_Boost::ui_stat( count( $nets ), 'Networks connected', '#0ea5e9' ) . MRSH_Boost::ui_stat( $wait, 'Waiting in queue', '#f59e0b' ) . MRSH_Boost::ui_stat( $sent, 'Posts sent', '#10b981' ) . MRSH_Boost::ui_stat( $bad, 'Need attention', $bad ? '#ef4444' : '#6b7280' ) . '</div>'; // phpcs:ignore

		// Facebook and Instagram.
		$p   = self::cur_page( $o );
		$in  = self::form( 'mrsh_soc_save', self::inp( 'fb_app', 'Meta App ID', $o['fb_app'] ) . self::inp( 'fb_secret', 'Meta App Secret', $o['fb_secret'], 'password' ) . '<p class="mx-sub">In your Meta developer app (Facebook Login for Business), add this address under Valid OAuth Redirect URIs: <input type="text" readonly onclick="this.select()" value="' . esc_attr( self::redirect_uri() ) . '" style="width:100%;max-width:640px"></p>', 'Save app details' );
		$in .= '<p style="display:flex;gap:8px;flex-wrap:wrap">' . self::mini( 'mrsh_soc_fbconnect', $p ? 'Connect again with Facebook' : 'Connect with Facebook', '', '', true );
		if ( $p ) {
			$in .= self::mini( 'mrsh_soc_test', 'Test', 'facebook' ) . self::mini( 'mrsh_soc_disconnect', 'Disconnect', 'facebook' );
		}
		$in .= '</p>';
		if ( $p ) {
			$in .= '<p>Page: <b>' . esc_html( $p['name'] ) . '</b>' . ( ! empty( $p['ig'] ) ? ' &middot; Instagram: <b>@' . esc_html( $p['igname'] ) . '</b>' : ' &middot; no Instagram account is linked to this page' ) . '</p>';
			if ( count( $o['pages'] ) > 1 ) {
				$sel = '<p><select name="page">';
				foreach ( $o['pages'] as $pg ) {
					$sel .= '<option value="' . esc_attr( $pg['id'] ) . '" ' . selected( (string) $o['page'], (string) $pg['id'], false ) . '>' . esc_html( $pg['name'] ) . '</option>';
				}
				$in .= self::form( 'mrsh_soc_fbpage', $sel . '</select></p>', 'Use this page' );
			}
		}
		self::card( 'Facebook and Instagram', $p ? 'Connected' : 'Not connected', (bool) $p, $in );

		// Telegram.
		$t = self::form( 'mrsh_soc_save', self::inp( 'tg_token', 'Bot token (from @BotFather)', $o['tg_token'], 'password' ) . self::inp( 'tg_chat', 'Channel (for example @myrishta) or chat id', $o['tg_chat'] ) . '<p class="mx-sub">Make your bot an administrator of the channel so it can post.</p>', 'Save Telegram' );
		$tc = isset( $nets['telegram'] );
		$t .= '<p style="display:flex;gap:8px">' . ( $tc ? self::mini( 'mrsh_soc_test', 'Test', 'telegram' ) . self::mini( 'mrsh_soc_disconnect', 'Disconnect', 'telegram' ) : '' ) . '</p>';
		self::card( 'Telegram channel', $tc ? 'Connected' : 'Not connected', $tc, $t );

		// Bluesky.
		$b = self::form( 'mrsh_soc_save', self::inp( 'bs_handle', 'Handle', $o['bs_handle'], 'text', 'myrishta.bsky.social' ) . self::inp( 'bs_pass', 'App password (Bluesky Settings, App passwords)', $o['bs_pass'], 'password' ), 'Save Bluesky' );
		$bc = isset( $nets['bluesky'] );
		$b .= '<p style="display:flex;gap:8px">' . ( $bc ? self::mini( 'mrsh_soc_test', 'Test', 'bluesky' ) . self::mini( 'mrsh_soc_disconnect', 'Disconnect', 'bluesky' ) : '' ) . '</p>';
		self::card( 'Bluesky', $bc ? 'Connected' : 'Not connected', $bc, $b );

		// Composer.
		$c = '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_soc_add">';
		echo ''; // keep structure readable.
		ob_start();
		wp_nonce_field( 'mrsh_soc_add' );
		$c .= ob_get_clean();
		$c .= '<p><textarea name="text" rows="5" style="width:100%;font-size:15px;line-height:1.6" placeholder="Write the post (Urdu or English)"></textarea></p>' . self::inp( 'link', 'Link (optional)', '', 'url', home_url( '/' ) ) . '<p><label><b>Picture (needed for Instagram)</b><br><input type="url" id="mrsh-soc-img" name="image" class="regular-text" style="width:100%;max-width:520px" placeholder="https://..."></label> <button type="button" class="button" id="mrsh-soc-pick">Choose from media library</button></p>';
		$c .= '<p><label><b>When</b><br><input type="datetime-local" name="when"></label> <span class="mx-sub">Leave empty to send now.</span></p><p><b>Post on:</b> ';
		if ( $nets ) {
			foreach ( $nets as $k => $l ) {
				$c .= '<label style="margin-right:14px"><input type="checkbox" name="nets[]" value="' . esc_attr( $k ) . '" checked> ' . esc_html( $l ) . '</label>';
			}
		} else {
			$c .= '<span class="mx-sub">Connect a network above first.</span>';
		}
		$c .= '</p><p style="display:flex;gap:8px;flex-wrap:wrap"><button class="button button-primary button-large">Add post</button></p></form>';
		$c .= '<script>(function(){var b=document.getElementById("mrsh-soc-pick");if(!b||!window.wp||!wp.media)return;b.onclick=function(){var f=wp.media({title:"Choose a picture",multiple:false,library:{type:"image"}});f.on("select",function(){var a=f.state().get("selection").first().toJSON();document.getElementById("mrsh-soc-img").value=a.url});f.open()}})();</script>';
		self::card( 'Write a post', 'Composer', true, $c );

		// Auto-fill and settings.
		$s  = self::form( 'mrsh_soc_fill', self::inp( 'image', 'Picture for these posts (optional, needed for Instagram)', '', 'url', 'https://...' ) . '<p class="mx-sub">Writes the next 7 evenings from the rotating topics (safety, sign-up, search, cities and more), in Urdu, with the right page link.</p>', 'Fill the next 7 evenings' );
		$s .= '<hr>' . self::form( 'mrsh_soc_save', '<p><label><input type="checkbox" name="on" value="1" ' . checked( $o['on'], 1, false ) . '> Publish queued posts automatically</label></p><p><label><input type="checkbox" name="mail" value="1" ' . checked( $o['mail'], 1, false ) . '> Email me if a post fails (' . esc_html( get_option( 'admin_email' ) ) . ')</label></p><p><label>Usual posting time <input type="time" name="time" value="' . esc_attr( $o['time'] ) . '"></label></p>', 'Save settings' );
		self::card( 'Automatic queue', $o['on'] ? 'On' : 'Off', (bool) $o['on'], $s );

		// Queue.
		echo '<div class="mx-card"><h2>Queue</h2>';
		if ( $o['queue'] ) {
			echo '<div style="overflow-x:auto"><table class="widefat striped"><thead><tr><th>When</th><th>Post</th><th>Networks</th><th>Status</th><th></th></tr></thead><tbody>';
			$rows = $o['queue'];
			usort( $rows, function ( $a, $b2 ) { return $a['ts'] <=> $b2['ts']; } );
			foreach ( $rows as $q ) {
				$col = 'sent' === $q['status'] ? '#10b981' : ( 'failed' === $q['status'] ? '#ef4444' : '#f59e0b' );
				echo '<tr><td style="white-space:nowrap">' . esc_html( wp_date( 'j M, H:i', (int) $q['ts'] ) ) . '</td><td>' . esc_html( wp_trim_words( $q['text'], 14 ) ) . '</td><td>' . esc_html( implode( ', ', (array) $q['nets'] ) ) . '</td><td><span style="color:' . esc_attr( $col ) . ';font-weight:600">' . esc_html( ucfirst( $q['status'] ) ) . '</span>' . ( $q['log'] ? '<br><small>' . esc_html( $q['log'] ) . '</small>' : '' ) . '</td><td style="white-space:nowrap">' . ( 'sent' !== $q['status'] ? self::mini( 'mrsh_soc_now', 'failed' === $q['status'] ? 'Try again' : 'Send now', '', $q['id'] ) : '' ) . self::mini( 'mrsh_soc_del', 'Remove', '', $q['id'] ) . '</td></tr>'; // phpcs:ignore
			}
			echo '</tbody></table></div>';
		} else {
			echo '<p class="mx-sub">Nothing in the queue yet.</p>';
		}
		echo '</div></div>';
	}
}
