<?php
/**
 * AI visibility: makes guides easy for AI assistants (ChatGPT, Claude, Perplexity, Google AI) to read, quote and credit.
 * Everything is plain server HTML or text. Nothing is invented: the summary is the page's own description.
 */
defined( 'ABSPATH' ) || exit;

class MRSH_AI {
	const OPT = 'mrsh_ai';

	private static $bots = array( 'GPTBot', 'OAI-SearchBot', 'ChatGPT-User', 'ClaudeBot', 'Claude-User', 'Claude-SearchBot', 'anthropic-ai', 'PerplexityBot', 'Perplexity-User', 'Google-Extended', 'Applebot-Extended', 'CCBot', 'cohere-ai', 'MistralAI-User', 'Amazonbot', 'Bytespider' );
	/** Crawlers that answer people's questions and show your link (worth welcoming). The rest collect text to train models. */
	private static $assist = array( 'OAI-SearchBot', 'ChatGPT-User', 'Claude-User', 'Claude-SearchBot', 'PerplexityBot', 'Perplexity-User', 'MistralAI-User' );

	public static function get() {
		$o = get_option( self::OPT, array() );
		return wp_parse_args( is_array( $o ) ? $o : array(), array( 'on' => 1, 'box' => 1, 'bots' => 1, 'by' => 1, 'off' => array() ) );
	}

	public static function init() {
		add_filter( 'robots_txt', array( __CLASS__, 'robots' ), 30, 2 );
		add_action( 'wp_head', array( __CLASS__, 'head' ), 7 );
		add_filter( 'the_content', array( __CLASS__, 'box' ), 8 );
		add_filter( 'mrsh_article_schema', array( __CLASS__, 'schema' ), 10, 2 );
		add_action( 'wp_head', array( __CLASS__, 'css' ), 40 );
		if ( is_admin() ) {
			add_action( 'admin_menu', array( __CLASS__, 'menu' ), 24 );
			add_action( 'admin_post_mrsh_ai_save', array( __CLASS__, 'save' ) );
			add_action( 'admin_post_mrsh_ai_toggle', array( __CLASS__, 'toggle' ) );
		}
	}

	/** Name each AI crawler and welcome it. Robots rules that already exist are left alone. */
	public static function robots( $out, $public ) {
		$s = self::get();
		if ( ! $public || empty( $s['on'] ) || empty( $s['bots'] ) ) {
			return $out;
		}
		$add = "# AI assistants are welcome to read and quote our public guides. Member profiles stay private.\n";
		foreach ( self::$bots as $b ) {
			if ( false === stripos( $out, 'User-agent: ' . $b ) ) {
				if ( in_array( $b, (array) $s['off'], true ) ) {
					$add .= 'User-agent: ' . $b . "\nDisallow: /\n\n";
				} else {
					$add .= 'User-agent: ' . $b . "\nAllow: /\nDisallow: /my-account/\nDisallow: /wp-admin/\nDisallow: /listing/\n\n";
				}
			}
		}
		$add .= '# LLMs: ' . home_url( '/llms.txt' ) . "\n";
		if ( preg_match( '/^Sitemap:/mi', $out, $m, PREG_OFFSET_CAPTURE ) ) {
			return rtrim( substr( $out, 0, $m[0][1] ) ) . "\n\n" . $add . "\n" . substr( $out, $m[0][1] );
		}
		return rtrim( $out ) . "\n\n" . $add;
	}

	public static function head() {
		$s = self::get();
		if ( empty( $s['on'] ) ) {
			return;
		}
		echo '<link rel="alternate" type="text/plain" title="LLMs.txt" href="' . esc_url( home_url( '/llms.txt' ) ) . '">' . "\n";
	}

	private static function desc( $post ) {
		$d = class_exists( 'MRSH_Meta' ) ? trim( (string) MRSH_Meta::current_description() ) : '';
		return $d;
	}

	/** Visible summary and a clear "who and when" line at the top of each guide. */
	public static function box( $html ) {
		$s = self::get();
		if ( empty( $s['on'] ) || ! is_singular( 'post' ) || ! in_the_loop() || ! is_main_query() || false !== strpos( $html, 'mrsh-ai' ) ) {
			return $html;
		}
		$post = get_queried_object();
		if ( ! $post || get_post_meta( $post->ID, '_mrsh_ai_off', true ) ) {
			return $html;
		}
		$out = '';
		if ( ! empty( $s['by'] ) ) {
			$out .= '<p class="mrsh-ai mrsh-by">By <a href="' . esc_url( home_url( '/about-us/' ) ) . '">My Rishta Pakistan</a> &middot; Updated <time datetime="' . esc_attr( get_the_modified_date( 'c', $post ) ) . '">' . esc_html( get_the_modified_date( 'j F Y', $post ) ) . '</time></p>';
		}
		$d = self::desc( $post );
		if ( ! empty( $s['box'] ) && '' !== $d && str_word_count( wp_strip_all_tags( $html ) ) > 250 ) {
			$out .= '<div class="mrsh-ai mrsh-qa"><strong>Quick answer</strong><p>' . esc_html( $d ) . '</p></div>';
		}
		return $out . $html;
	}

	/** Richer Article data: size, section and which parts an assistant can read aloud. */
	public static function schema( $data, $post ) {
		$s = self::get();
		if ( empty( $s['on'] ) || ! is_array( $data ) ) {
			return $data;
		}
		$data['wordCount'] = str_word_count( wp_strip_all_tags( (string) $post->post_content ) );
		$cats              = get_the_category( $post->ID );
		if ( $cats ) {
			$data['articleSection'] = $cats[0]->name;
		}
		$data['isAccessibleForFree'] = true;
		$data['speakable']           = array( '@type' => 'SpeakableSpecification', 'cssSelector' => array( '.mrsh-qa', 'h1' ) );
		return $data;
	}

	public static function css() {
		if ( ! is_singular( 'post' ) || empty( self::get()['on'] ) ) {
			return;
		}
		echo '<style id="mrsh-ai-css">.mrsh-by{font-size:14px;color:#50575e;margin:0 0 12px}.mrsh-qa{border-left:4px solid #0f7a55;background:#f3faf6;padding:12px 16px;margin:0 0 18px;border-radius:0 8px 8px 0}.mrsh-qa p{margin:4px 0 0}</style>' . "\n";
	}

	/* ---------- admin ---------- */

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'AI visibility', 'AI visibility', 'manage_options', 'mrsh-ai', array( __CLASS__, 'page' ) );
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_ai_save' );
		$n = array();
		foreach ( array( 'on', 'box', 'bots', 'by' ) as $k ) {
			$n[ $k ] = empty( $_POST[ $k ] ) ? 0 : 1;
		}
		$allow = isset( $_POST['allow'] ) && is_array( $_POST['allow'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['allow'] ) ) : array(); // phpcs:ignore
		$n['off'] = array_values( array_diff( self::$bots, $allow ) );
		update_option( self::OPT, $n, false );
		delete_transient( 'mrsh_ai_checks' );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-ai&saved=1' ) );
		exit;
	}

	/** One-click: hide or show the Quick answer box on a single guide. */
	public static function toggle() {
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_die( 'Not allowed.' );
		}
		$id = absint( $_GET['post'] ?? 0 ); // phpcs:ignore
		check_admin_referer( 'mrsh_ai_toggle_' . $id );
		if ( $id && current_user_can( 'edit_post', $id ) ) {
			if ( get_post_meta( $id, '_mrsh_ai_off', true ) ) {
				delete_post_meta( $id, '_mrsh_ai_off' );
			} else {
				update_post_meta( $id, '_mrsh_ai_off', 1 );
			}
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-ai&saved=1#audit' ) );
		exit;
	}

	/** Live checks of the three files assistants look at. Cached for ten minutes. */
	private static function checks( $fresh ) {
		$c = get_transient( 'mrsh_ai_checks' );
		if ( ! $fresh && is_array( $c ) ) {
			return $c;
		}
		$get = function ( $path ) {
			$r = wp_remote_get( home_url( $path ), array( 'timeout' => 8, 'redirection' => 3, 'user-agent' => 'MyRishtaSelfCheck/1.0' ) );
			return is_wp_error( $r ) ? array( 0, '' ) : array( (int) wp_remote_retrieve_response_code( $r ), (string) wp_remote_retrieve_body( $r ) );
		};
		list( $rc, $rb ) = $get( '/robots.txt' );
		list( $lc, $lb ) = $get( '/llms.txt' );
		list( $sc, $sb ) = $get( '/wp-sitemap.xml' );
		$c = array(
			array( 'robots.txt is reachable', 200 === $rc, 200 === $rc ? 'Found.' : 'Code ' . $rc . '. Assistants cannot read your rules.' ),
			array( 'robots.txt welcomes AI assistants', false !== stripos( $rb, 'OAI-SearchBot' ) || false !== stripos( $rb, 'PerplexityBot' ), 'Turn on "Name AI crawlers" below.' ),
			array( 'robots.txt does not block everyone', ! preg_match( '/User-agent:\s*\*\s*\R\s*Disallow:\s*\/\s*(\R|$)/i', $rb ), 'It has "Disallow: /" for all bots. Check Settings > Reading: "Discourage search engines" must be off.' ),
			array( 'llms.txt is reachable', 200 === $lc && strlen( $lb ) > 100, 200 === $lc ? 'Found, ' . strlen( $lb ) . ' characters.' : 'Code ' . $lc . '.' ),
			array( 'Sitemap is reachable', 200 === $sc && false !== stripos( $sb, '<' ), 200 === $sc ? 'Found.' : 'Code ' . $sc . '.' ),
			array( 'Site can be indexed', '1' === (string) get_option( 'blog_public' ), 'Settings > Reading has "Discourage search engines" ticked.' ),
		);
		set_transient( 'mrsh_ai_checks', $c, 10 * MINUTE_IN_SECONDS );
		return $c;
	}

	/** Score each guide on what assistants need: summary, depth, structure, FAQ, sources, links, freshness. */
	private static function audit( $fresh ) {
		$a = get_transient( 'mrsh_ai_audit' );
		if ( ! $fresh && is_array( $a ) ) {
			return $a;
		}
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		$a    = array();
		foreach ( get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'numberposts' => 150, 'orderby' => 'modified', 'order' => 'DESC', 'suppress_filters' => true ) ) as $p ) {
			$t = (string) $p->post_content;
			$w = str_word_count( wp_strip_all_tags( $t ) );
			preg_match_all( '#<a [^>]*href=["\'](?:https?://(?:www\.)?' . preg_quote( (string) $host, '#' ) . '|/)[^"\']*#i', $t, $m );
			$chk = array(
				'a summary (meta description)' => '' !== trim( (string) get_post_meta( $p->ID, '_mrsh_desc', true ) ) || '' !== trim( (string) $p->post_excerpt ),
				'enough depth (500+ words)'    => $w >= 500,
				'clear sections (3+ H2)'       => preg_match_all( '/<h2[ >]/i', $t ) >= 3,
				'a FAQ'                        => (bool) preg_match( '/faq|frequently asked/i', $t ),
				'a Sources list'               => (bool) preg_match( '/>\s*sources?\s*</i', $t ),
				'3+ links to your own pages'   => count( $m[0] ) >= 3,
				'updated in the last year'     => strtotime( $p->post_modified_gmt . ' UTC' ) > time() - YEAR_IN_SECONDS,
			);
			$miss = array_keys( array_filter( $chk, function ( $v ) { return ! $v; } ) );
			$a[]  = array( 'id' => $p->ID, 'title' => get_the_title( $p ), 'score' => (int) round( 100 * ( count( $chk ) - count( $miss ) ) / count( $chk ) ), 'miss' => $miss, 'words' => $w );
		}
		usort( $a, function ( $x, $y ) { return $x['score'] <=> $y['score']; } );
		set_transient( 'mrsh_ai_audit', $a, HOUR_IN_SECONDS );
		return $a;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s = self::get();
		echo '<div class="wrap"><h1>AI visibility</h1><p>Helps ChatGPT, Claude, Perplexity and Google AI read, quote and credit your guides.</p>';
		if ( isset( $_GET['saved'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			echo '<div class="notice notice-success is-dismissible"><p>Saved.</p></div>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_ai_save">';
		wp_nonce_field( 'mrsh_ai_save' );
		$rows = array(
			'on'   => array( 'Turn all of this on', 'Master switch.' ),
			'bots' => array( 'Name AI crawlers in robots.txt', 'Welcomes GPTBot, ClaudeBot, PerplexityBot, Google-Extended and others. Member areas stay blocked.' ),
			'box'  => array( '"Quick answer" box on guides', 'Shows the page\'s own description at the top of long guides.' ),
			'by'   => array( '"By My Rishta Pakistan, Updated" line', 'Shows who wrote the guide and when it was last updated.' ),
		);
		echo '<table class="form-table">';
		foreach ( $rows as $k => $r ) {
			echo '<tr><th>' . esc_html( $r[0] ) . '</th><td><label><input type="checkbox" name="' . esc_attr( $k ) . '" value="1"' . checked( $s[ $k ], 1, false ) . '> On</label><p class="description">' . esc_html( $r[1] ) . '</p></td></tr>';
		}
		echo '</table>';
		echo '<h2>Which AI crawlers may read the site</h2><p class="description">Assistants (ChatGPT search, Perplexity, Claude search) send visitors to you, so welcoming them is usually good. "Training" crawlers only collect text to train models and send no visitors. Member areas and profiles stay closed for all.</p><p><button type="button" class="button" id="mrsh-ai-all">Allow all</button> <button type="button" class="button" id="mrsh-ai-asst">Allow assistants, block training</button></p><table class="widefat striped" style="max-width:640px"><thead><tr><th>Crawler</th><th>Kind</th><th>Allowed</th></tr></thead><tbody>';
		foreach ( self::$bots as $b ) {
			$as = in_array( $b, self::$assist, true );
			echo '<tr><td><code>' . esc_html( $b ) . '</code></td><td>' . ( $as ? 'Assistant (sends visitors)' : 'Training / collecting' ) . '</td><td><label><input type="checkbox" class="mrsh-bot" data-asst="' . ( $as ? 1 : 0 ) . '" name="allow[]" value="' . esc_attr( $b ) . '"' . checked( ! in_array( $b, (array) $s['off'], true ), true, false ) . '> Allow</label></td></tr>';
		}
		echo '</tbody></table>';
		echo '<p><button class="button button-primary">Save</button> <a class="button" target="_blank" rel="noopener" href="' . esc_url( home_url( '/robots.txt' ) ) . '">View robots.txt</a> <a class="button" target="_blank" rel="noopener" href="' . esc_url( home_url( '/llms.txt' ) ) . '">View llms.txt</a></p></form>';
		echo '<script>(function(){var b=document.querySelectorAll(".mrsh-bot");function set(f){b.forEach(function(x){x.checked=f(x)})}document.getElementById("mrsh-ai-all").onclick=function(){set(function(){return true})};document.getElementById("mrsh-ai-asst").onclick=function(){set(function(x){return x.dataset.asst==="1"})}})();</script>';

		$fresh = isset( $_GET['recheck'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ?? '' ) ), 'mrsh_ai_re' ); // phpcs:ignore
		$re    = wp_nonce_url( admin_url( 'admin.php?page=mrsh-ai&recheck=1' ), 'mrsh_ai_re' );
		echo '<h2>Live check <a class="button" href="' . esc_url( $re ) . '" style="margin-left:10px">Check again</a></h2>';
		foreach ( self::checks( $fresh ) as $c ) {
			echo '<p style="margin:6px 0"><span style="display:inline-block;width:20px;height:20px;border-radius:50%;color:#fff;text-align:center;line-height:20px;background:' . ( $c[1] ? '#16a34a' : '#dc2626' ) . '">' . ( $c[1] ? '&#10003;' : '!' ) . '</span> <b>' . esc_html( $c[0] ) . '</b> <small style="color:#646970">' . esc_html( $c[2] ) . '</small></p>';
		}

		$au = self::audit( $fresh );
		echo '<h2 id="audit">How ready is each guide? </h2>';
		if ( ! $au ) {
			echo '<p>No guides yet.</p>';
		} else {
			$avg = (int) round( array_sum( wp_list_pluck( $au, 'score' ) ) / count( $au ) );
			echo '<p>Average score: <b>' . $avg . ' / 100</b> across ' . count( $au ) . ' guides. The weakest are first. Fix the missing parts and assistants will quote you more.</p><div style="overflow-x:auto"><table class="widefat striped"><thead><tr><th>Guide</th><th>Score</th><th>Missing</th><th></th></tr></thead><tbody>';
			foreach ( array_slice( $au, 0, 30 ) as $r ) {
				$off = (bool) get_post_meta( $r['id'], '_mrsh_ai_off', true );
				$col = $r['score'] >= 85 ? '#16a34a' : ( $r['score'] >= 55 ? '#d97706' : '#dc2626' );
				echo '<tr><td><a href="' . esc_url( (string) get_permalink( $r['id'] ) ) . '" target="_blank" rel="noopener">' . esc_html( $r['title'] ) . '</a><br><small>' . (int) $r['words'] . ' words</small></td><td><b style="color:' . $col . '">' . (int) $r['score'] . '</b></td><td><small>' . esc_html( $r['miss'] ? implode( ', ', $r['miss'] ) : 'Nothing. Well done.' ) . '</small></td><td style="white-space:nowrap"><a class="button" href="' . esc_url( (string) get_edit_post_link( $r['id'] ) ) . '">Edit</a> <a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_ai_toggle&post=' . (int) $r['id'] ), 'mrsh_ai_toggle_' . (int) $r['id'] ) ) . '">' . ( $off ? 'Show Quick answer' : 'Hide Quick answer' ) . '</a></td></tr>';
			}
			echo '</tbody></table></div>';
		}

		$h  = wp_parse_url( home_url(), PHP_URL_HOST );
		$qs = array( 'What is ' . $h . ' and is it free?', 'How can I avoid fake rishta profiles in Pakistan?', 'Which websites help Pakistani families find a rishta online?' );
		echo '<h2>Test it yourself</h2><p class="description">Ask an assistant a real question and see whether your site is named. Do this once a month and write down the result.</p><p>';
		foreach ( $qs as $q ) {
			echo '<span style="display:block;margin:4px 0">' . esc_html( $q ) . ' &nbsp;<a class="button" target="_blank" rel="noopener" href="' . esc_url( 'https://www.perplexity.ai/search?q=' . rawurlencode( $q ) ) . '">Perplexity</a> <a class="button" target="_blank" rel="noopener" href="' . esc_url( 'https://chatgpt.com/?q=' . rawurlencode( $q ) ) . '">ChatGPT</a> <a class="button" target="_blank" rel="noopener" href="' . esc_url( 'https://www.google.com/search?q=' . rawurlencode( $q ) ) . '">Google</a></span>';
		}
		echo '</p>';
		echo '<p class="description">The same page also has Article data (word count, section, speakable parts) and a link to llms.txt in the page head. To hide the box on one guide, use the button in the table above.</p></div>';
	}
}
