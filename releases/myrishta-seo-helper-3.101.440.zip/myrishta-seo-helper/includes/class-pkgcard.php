<?php
/**
 * Package card. When a package order is completed the member gets a happy email with a designed card
 * (package, benefits, order number, valid until) and a link to a printable copy they can save as PDF.
 * Sent once per order. The team can send it again or preview it from the Package orders page.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_PkgCard {

	public static function init() {
		add_action( 'mrsh_order_done', array( __CLASS__, 'on_done' ), 10, 1 );
		add_action( 'template_redirect', array( __CLASS__, 'page' ), 6 );
	}

	/** Signed link to the printable card. */
	public static function url( $oid ) {
		$oid = (int) $oid;
		return add_query_arg( array( 'mrt_pkg' => $oid, 'k' => substr( hash_hmac( 'sha256', 'pkg' . $oid, wp_salt( 'auth' ) ), 0, 20 ) ), home_url( '/' ) );
	}

	private static function plan_info( $name ) {
		$info = array( 'color' => '#9b1b4b', 'perks' => array(), 'price' => '' );
		if ( function_exists( 'mrt_plans' ) ) {
			foreach ( mrt_plans() as $p ) {
				if ( 0 === strcasecmp( trim( $p[0] ), trim( (string) $name ) ) ) {
					$info['perks'] = array_slice( (array) $p[2], 0, 6 );
					$info['price'] = (string) $p[1];
					if ( ! empty( $p[3] ) && preg_match( '/^#[0-9a-f]{3,8}$/i', (string) $p[3] ) ) {
						$info['color'] = $p[3];
					}
					break;
				}
			}
		}
		return $info;
	}

	/** Everything the card shows, in one array. */
	public static function data( $oid ) {
		$uid  = (int) get_post_meta( $oid, '_uid', true );
		$u    = get_userdata( $uid );
		$plan = (string) get_post_meta( $oid, '_plan', true );
		$exp  = $u ? (int) get_user_meta( $uid, 'mrt_plan_exp', true ) : 0;
		$d    = array(
			'oid'    => (int) $oid,
			'no'     => class_exists( 'MRSH_Orders' ) ? MRSH_Orders::number( $oid ) : 'PO-' . $oid,
			'name'   => $u ? ( $u->display_name ?: $u->user_login ) : 'Member',
			'email'  => $u ? $u->user_email : '',
			'uid'    => $uid,
			'plan'   => $plan,
			'issued' => wp_date( 'j F Y', (int) ( get_post_meta( $oid, '_closed', true ) ?: time() ) ),
			'until'  => $exp ? wp_date( 'j F Y', $exp ) : 'No end date',
			'site'   => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			'link'   => self::url( $oid ),
			'acct'   => home_url( '/' ),
		);
		return array_merge( $d, self::plan_info( $plan ) );
	}

	/** The card itself: plain tables and inline styles so every mail app shows it. */
	public static function card_html( $d ) {
		$c = esc_attr( $d['color'] );
		$perks = '';
		foreach ( $d['perks'] as $p ) {
			$perks .= '<tr><td style="padding:3px 8px 3px 0;color:' . $c . ';font-weight:700;vertical-align:top">&#10003;</td><td style="padding:3px 0;font-size:14px;color:#374151">' . esc_html( $p ) . '</td></tr>';
		}
		return '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:520px;margin:0 auto;border:3px solid ' . $c . ';border-radius:20px;background:#ffffff;font-family:Arial,Helvetica,sans-serif">'
			. '<tr><td style="background:' . $c . ';border-radius:16px 16px 0 0;padding:16px 20px;color:#ffffff"><div style="font-size:12px;letter-spacing:2px;text-transform:uppercase;opacity:.9">' . esc_html( $d['site'] ) . ' &middot; Package card</div><div style="font-size:30px;font-weight:800;line-height:1.2;margin-top:4px">' . esc_html( $d['plan'] ) . ' Package</div><div style="font-size:15px;margin-top:2px">&#127881; Mubarak! &nbsp; مبارک ہو</div></td></tr>'
			. '<tr><td style="padding:18px 20px"><div style="font-size:12px;color:#6b7280;text-transform:uppercase;letter-spacing:1px">Issued to</div><div style="font-size:20px;font-weight:700;color:#111827;margin-bottom:10px">' . esc_html( $d['name'] ) . ' <span style="font-size:12px;color:#9ca3af;font-weight:400">#' . (int) $d['uid'] . '</span></div>'
			. ( $perks ? '<table role="presentation" cellpadding="0" cellspacing="0" style="margin:6px 0 10px">' . $perks . '</table>' : '' )
			. '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-top:2px dashed #e5e7eb;margin-top:6px"><tr>'
			. '<td style="padding:10px 0 0;font-size:12px;color:#6b7280">Order no.<br><b style="font-size:14px;color:#111827">' . esc_html( $d['no'] ) . '</b></td>'
			. '<td style="padding:10px 0 0;font-size:12px;color:#6b7280">Issued<br><b style="font-size:14px;color:#111827">' . esc_html( $d['issued'] ) . '</b></td>'
			. '<td style="padding:10px 0 0;font-size:12px;color:#6b7280">Valid until<br><b style="font-size:14px;color:#111827">' . esc_html( $d['until'] ) . '</b></td></tr></table></td></tr></table>';
	}

	public static function email_html( $d ) {
		$btn = '<a href="' . esc_url( $d['link'] ) . '" style="display:inline-block;background:' . esc_attr( $d['color'] ) . ';color:#ffffff;text-decoration:none;font-weight:700;padding:13px 26px;border-radius:12px;font-size:15px">View and save your package card (PDF)</a>';
		return '<!doctype html><html><body style="margin:0;background:#f4f5fa"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4f5fa"><tr><td align="center" style="padding:24px 12px">'
			. '<div style="font-family:Arial,Helvetica,sans-serif;max-width:560px;margin:0 auto;text-align:center"><div style="font-size:40px;line-height:1">&#127881;&#10024;&#127881;</div><h1 style="font-size:22px;color:#111827;margin:10px 0 4px">Assalam o Alaikum ' . esc_html( $d['name'] ) . ',</h1><p style="font-size:16px;color:#374151;margin:0 0 4px">Your <b>' . esc_html( $d['plan'] ) . '</b> package is now active. Congratulations!</p><p style="font-size:16px;color:#374151;margin:0 0 18px" dir="rtl">مبارک ہو! آپ کا ' . esc_html( $d['plan'] ) . ' پیکج فعال ہو گیا ہے۔</p></div>'
			. self::card_html( $d )
			. '<div style="font-family:Arial,Helvetica,sans-serif;max-width:560px;margin:20px auto 0;text-align:center">' . $btn . '<p style="font-size:13px;color:#6b7280;margin:16px 0 0">Open the link, then press <b>Print / Save as PDF</b> to keep a copy.<br>We wish you a good and blessed rishta, InshaAllah.</p><p style="font-size:12px;color:#9ca3af;margin:14px 0 0">' . esc_html( $d['site'] ) . ' &middot; <a href="' . esc_url( $d['acct'] ) . '" style="color:#9ca3af">' . esc_html( preg_replace( '#^https?://#', '', untrailingslashit( $d['acct'] ) ) ) . '</a></p></div>'
			. '</td></tr></table></body></html>';
	}

	/** Sends the card email. $force sends again even if it was sent before. */
	public static function send( $oid, $force = false ) {
		if ( ! $force && get_post_meta( $oid, '_card_sent', true ) ) {
			return false;
		}
		$d = self::data( $oid );
		if ( ! is_email( $d['email'] ) ) {
			return false;
		}
		$alt = static function ( $m ) use ( $d ) {
			$m->AltBody = 'Assalam o Alaikum ' . $d['name'] . ",\n\nCongratulations! Your " . $d['plan'] . ' package is now active (order ' . $d['no'] . ', valid until ' . $d['until'] . ").\n\nYour package card: " . $d['link'] . "\n\n" . $d['site'];
		};
		add_action( 'phpmailer_init', $alt, 200 );
		$ok = wp_mail( $d['email'], '🎉 Your ' . $d['plan'] . ' package is ready | آپ کا پیکج فعال ہو گیا', self::email_html( $d ), array( 'Content-Type: text/html; charset=UTF-8' ) );
		remove_action( 'phpmailer_init', $alt, 200 );
		if ( $ok ) {
			update_post_meta( $oid, '_card_sent', time() );
		}
		return (bool) $ok;
	}

	/** The same good news in the member's own messenger (My account > Messages), from the team. Once per order. */
	public static function message( $oid, $force = false ) {
		if ( ! class_exists( 'MRSH_Members' ) || ( ! $force && get_post_meta( $oid, '_card_msg', true ) ) ) {
			return false;
		}
		$d   = self::data( $oid );
		$uid = (int) $d['uid'];
		if ( ! $uid || ! get_userdata( $uid ) ) {
			return false;
		}
		$from = get_current_user_id();
		if ( ! $from || $from === $uid || ! user_can( $from, 'manage_options' ) ) {
			$a    = get_users( array( 'role' => 'administrator', 'number' => 1, 'orderby' => 'ID', 'order' => 'ASC', 'fields' => 'ID' ) );
			$from = $a ? (int) $a[0] : 0;
		}
		$from = (int) apply_filters( 'mrsh_team_uid', $from );
		if ( ! $from || $from === $uid ) {
			return false;
		}
		$text = "🎉 Mubarak, " . $d['name'] . "! Your " . $d['plan'] . " package is now active.\n"
			. 'Order ' . $d['no'] . ' · issued ' . $d['issued'] . ' · valid until ' . $d['until'] . ".\n"
			. "We emailed you your package card (you can save it as PDF). You can also see your package in My account.\n"
			. 'مبارک ہو! آپ کا ' . $d['plan'] . ' پیکج فعال ہو گیا ہے۔ JazakAllah, and we wish you a blessed rishta.';
		$id = MRSH_Members::send( $from, $uid, $text );
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $oid, '_card_msg', time() );
			if ( class_exists( 'MRSH_Mem_Push' ) ) {
				MRSH_Mem_Push::ping( $uid, 'msg' );
			}
			return true;
		}
		return false;
	}

	/** An order just closed as "done": send the card once (not for old orders that are only being tidied up). */
	public static function on_done( $oid ) {
		$p = get_post( $oid );
		if ( ! $p || ( time() - strtotime( $p->post_date_gmt . ' UTC' ) ) > 30 * DAY_IN_SECONDS ) {
			return;
		}
		self::send( $oid );
		self::message( $oid );
	}

	/** Printable card page: /?mrt_pkg=ID&k=KEY */
	public static function page() {
		if ( empty( $_GET['mrt_pkg'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$oid = absint( $_GET['mrt_pkg'] ); // phpcs:ignore
		$k   = (string) ( $_GET['k'] ?? '' ); // phpcs:ignore
		if ( ! $oid || ! class_exists( 'MRSH_Orders' ) || MRSH_Orders::CPT !== get_post_type( $oid ) || ! hash_equals( substr( hash_hmac( 'sha256', 'pkg' . $oid, wp_salt( 'auth' ) ), 0, 20 ), $k ) ) {
			wp_die( 'This package card link is not valid.', 'Not found', array( 'response' => 404 ) );
		}
		$d = self::data( $oid );
		nocache_headers();
		header( 'X-Robots-Tag: noindex, nofollow' );
		echo self::print_html( $d ); // phpcs:ignore WordPress.Security.EscapeOutput
		exit;
	}

	public static function print_html( $d ) {
		return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Package card ' . esc_html( $d['no'] ) . '</title><style>@page{size:A5 landscape;margin:10mm}*{box-sizing:border-box}body{margin:0;background:#eef0f6;font-family:Arial,Helvetica,sans-serif;color:#111827}.bar{background:' . esc_attr( $d['color'] ) . ';color:#fff;padding:10px 16px;text-align:center}.bar button{margin-left:10px;padding:8px 18px;border:0;border-radius:8px;background:#fff;color:#111;font-weight:700;cursor:pointer}.w{max-width:600px;margin:18px auto;padding:0 12px}.t{text-align:center;margin:0 0 12px;font-size:15px;color:#374151}.ft{text-align:center;color:#6b7280;font-size:12px;margin-top:12px}@media print{body{background:#fff}.bar,.t{display:none}.w{margin:0 auto;padding:0}}</style></head><body><div class="bar">Package card &middot; ' . esc_html( $d['no'] ) . ' <button onclick="window.print()">Print / Save as PDF</button></div><div class="w"><p class="t">&#127881; Mubarak, ' . esc_html( $d['name'] ) . '! Your ' . esc_html( $d['plan'] ) . ' package is active.</p>' . self::card_html( $d ) . '<div class="ft">' . esc_html( $d['site'] ) . ' &middot; ' . esc_html( preg_replace( '#^https?://#', '', untrailingslashit( $d['acct'] ) ) ) . '</div></div></body></html>';
	}
}
