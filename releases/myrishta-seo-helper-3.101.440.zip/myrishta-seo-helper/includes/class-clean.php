<?php
/**
 * Duplicate clean-up for the page head: repeated tags, repeated words and
 * repeated title parts. Works on the final HTML so it covers theme, SEO plugin
 * and this plugin alike. Only the <head> is touched; page content never is.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Clean {

	public static function init() {
		add_action( 'template_redirect', array( __CLASS__, 'start' ), 0 );
	}

	public static function start() {
		$o = MRSH_Options::get();
		if ( empty( $o['dedupe_head'] ) && empty( $o['clean_words'] ) ) {
			return;
		}
		if ( is_admin() || is_feed() || is_robots() || is_customize_preview() || isset( $_GET['elementor-preview'] ) || isset( $_GET['preview'] ) || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || wp_doing_ajax() ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		$path = isset( $_SERVER['REQUEST_URI'] ) ? strtok( (string) wp_unslash( $_SERVER['REQUEST_URI'] ), '?' ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( preg_match( '/\.(xml|xsl|txt|json)$/i', $path ) ) {
			return;
		}
		ob_start( array( __CLASS__, 'filter' ) );
	}

	public static function filter( $html ) {
		$o = MRSH_Options::get();
		if ( ! is_string( $html ) || false === stripos( $html, '<head' ) || ! preg_match( '/<head\b[^>]*>(.*?)<\/head>/is', $html, $m, PREG_OFFSET_CAPTURE ) ) {
			return $html;
		}
		$head = $m[1][0];
		$new  = $head;
		if ( ! empty( $o['dedupe_head'] ) ) {
			$new = self::dedupe( $new );
		}
		if ( ! empty( $o['clean_words'] ) ) {
			$new = self::words( $new, ! empty( $o['trim_description'] ) );
		}
		if ( $new === $head || '' === $new ) {
			return $html;
		}
		return substr( $html, 0, $m[1][1] ) . $new . substr( $html, $m[1][1] + strlen( $head ) );
	}

	/** Remove repeated tags. Single-value tags keep their first copy even if the text differs. */
	public static function dedupe( $head ) {
		$seen = array();
		if ( class_exists( 'MRSH_Frontend' ) && ! is_user_logged_in() ) {
			MRSH_Frontend::capture_verification( $head );
		}
		// Titles: the theme may print its own plain <title> before WordPress prints the real one.
		// Keep the last one (WordPress's, which carries the SEO title).
		if ( preg_match_all( '/<title\b[^>]*>.*?<\/title>/is', $head, $tt ) && count( $tt[0] ) > 1 ) {
			for ( $i = 0; $i < count( $tt[0] ) - 1; $i++ ) {
				$p = strpos( $head, $tt[0][ $i ] );
				if ( false !== $p ) {
					$head = substr( $head, 0, $p ) . substr( $head, $p + strlen( $tt[0][ $i ] ) );
				}
			}
		}
		// Description: a copy written for this page (marked) wins over a site-wide one from the theme.
		if ( false !== strpos( $head, 'data-mrsh="1"' ) && preg_match( '/<meta\s+name=["\']description["\'][^>]*data-mrsh="1"[^>]*>/i', $head ) ) {
			$head = preg_replace_callback( '/<meta\s+name=["\']description["\'][^>]*>/i', function ( $m ) {
				return false !== strpos( $m[0], 'data-mrsh="1"' ) ? str_replace( ' data-mrsh="1"', '', $m[0] ) : '';
			}, $head );
		}
		// A share image address that is not a real picture (the theme prints 'Logo 700x700'): use ours.
		if ( class_exists( 'MRSH_Frontend' ) && '' !== MRSH_Frontend::social_image() ) {
			$fixed = false;
			$head2 = preg_replace_callback( '/<meta\b[^>]*(?:property|name)=["\'](?:og:image|twitter:image)["\'][^>]*>/i', function ( $m ) use ( &$fixed ) {
				if ( ! preg_match( '/content=["\']([^"\']*)["\']/i', $m[0], $c ) || preg_match( '/\.(?:png|jpe?g|webp|gif)(\?[^"\']*)?$/i', $c[1] ) ) {
					return $m[0];
				}
				$fixed = true;
				return str_replace( $c[0], 'content="' . esc_url( MRSH_Frontend::social_image() ) . '"', $m[0] );
			}, $head );
			if ( $fixed && null !== $head2 ) {
				$head = preg_replace( '/<meta\b[^>]*property=["\']og:image:(?:width|height)["\'][^>]*>\s*/i', '', $head2 );
			}
		}
		// Several share images: prefer one that is not a favicon or tiny icon.
		$pref = array();
		foreach ( array( 'og:image', 'twitter:image' ) as $prop ) {
			if ( preg_match_all( '/<meta\b[^>]*>/i', $head, $tags ) ) {
				foreach ( $tags[0] as $tg ) {
					if ( self::key_of( $tg ) === $prop && preg_match( '/content=["\']([^"\']+)["\']/i', $tg, $cm ) && ! preg_match( '/favicon|site-icon|-(?:16|32|48|64|96|180)x(?:16|32|48|64|96|180)\b/i', $cm[1] ) ) {
						$pref[ $prop ] = $cm[1];
						break;
					}
				}
			}
		}
		$out = preg_replace_callback(
			'/<meta\b[^>]*>|<link\b[^>]*rel=["\'](?:canonical|alternate)["\'][^>]*>|<script\b[^>]*application\/ld\+json[^>]*>.*?<\/script>/is',
			function ( $mm ) use ( &$seen, $pref ) {
				$tag  = $mm[0];
				$norm = strtolower( trim( preg_replace( '/\s+/', ' ', $tag ) ) );
				$norm = preg_replace( '/\s*\/?>$/', '>', $norm );
				$key  = self::key_of( $tag );
				if ( isset( $pref[ $key ] ) && false === strpos( $tag, $pref[ $key ] ) ) {
					return '';
				}
				$keys = array( 'exact:' . $norm );
				if ( '' !== $key && self::is_single( $key, $tag ) ) {
					$keys[] = 'single:' . $key;
				}
				foreach ( $keys as $k ) {
					if ( isset( $seen[ $k ] ) ) {
						return '';
					}
				}
				foreach ( $keys as $k ) {
					$seen[ $k ] = true;
				}
				return $tag;
			},
			$head
		);
		return null === $out ? $head : $out;
	}

	/** Identifier of a tag: its property, name or rel value, lower-cased, in any attribute order. */
	private static function key_of( $tag ) {
		if ( preg_match( '/\b(?:property|name|rel)\s*=\s*["\']([^"\']+)["\']/i', $tag, $k ) ) {
			return strtolower( trim( $k[1] ) );
		}
		return '';
	}

	/** Tags that must appear once per page (the first copy is kept). */
	private static function is_single( $key, $tag ) {
		if ( in_array( $key, array( 'description', 'canonical', 'viewport', 'theme-color' ), true ) ) {
			return true;
		}
		if ( 'robots' === $key ) {
			return false;
		}
		return (bool) preg_match( '/^(?:og|twitter|fb):/', $key );
	}

	/** Repeated words, repeated title parts, doubled spaces and separators. */
	public static function text( $t ) {
		$t = html_entity_decode( $t, ENT_QUOTES, 'UTF-8' );
		$t = preg_replace( '/\s+/u', ' ', $t );
		// "Rishta Rishta" -> "Rishta" (consecutive repeats only).
		$t = preg_replace( '/\b(\p{L}[\p{L}\p{M}\']*)(\s+\1\b)+/iu', '$1', $t );
		// Repeated parts split by | - – — : "Site - Page | Site" -> "Site - Page".
		if ( preg_match( '/\s[|\-–—·]\s/u', $t ) ) {
			$parts = preg_split( '/(\s[|\-–—·]\s)/u', $t, -1, PREG_SPLIT_DELIM_CAPTURE );
			$keep  = array();
			$seen  = array();
			for ( $i = 0, $n = count( $parts ); $i < $n; $i += 2 ) {
				$key = mb_strtolower( trim( $parts[ $i ] ) );
				$dup = '' === $key;
				foreach ( array_keys( $seen ) as $prev ) {
					if ( false !== mb_strpos( $prev, $key ) ) {
						$dup = true;
						break;
					}
				}
				if ( $dup ) {
					continue;
				}
				$seen[ $key ] = true;
				$keep[]       = array( $parts[ $i ], isset( $parts[ $i - 1 ] ) && $i > 0 ? $parts[ $i - 1 ] : '' );
			}
			$t = '';
			foreach ( $keep as $idx => $k ) {
				$t .= ( $idx ? ( '' !== $k[1] ? $k[1] : ' | ' ) : '' ) . trim( $k[0] );
			}
		}
		$t = preg_replace( '/([,.;:!?])\1+/u', '$1', $t );
		return trim( $t );
	}

	private static function words( $head, $trim ) {
		$fix = function ( $text ) use ( $trim ) {
			$clean = self::text( $text );
			return $clean;
		};
		$head = preg_replace_callback(
			'/(<title[^>]*>)(.*?)(<\/title>)/is',
			function ( $m ) use ( $fix ) {
				return $m[1] . esc_html( $fix( $m[2] ) ) . $m[3];
			},
			$head,
			1
		);
		$head = preg_replace_callback(
			'/(<meta\b[^>]*(?:name|property)=["\'](?:description|og:title|og:description|twitter:title|twitter:description)["\'][^>]*content=")([^"]*)(")/i',
			function ( $m ) use ( $fix, $trim ) {
				$v = $fix( $m[2] );
				if ( $trim && mb_strlen( $v ) > 160 && false !== stripos( $m[0], 'description' ) ) {
					$cut = mb_substr( $v, 0, 157 );
					$sp  = mb_strrpos( $cut, ' ' );
					$v   = rtrim( $sp > 100 ? mb_substr( $cut, 0, $sp ) : $cut, ' ,.;:-' ) . '...';
				}
				return $m[1] . esc_attr( $v ) . $m[3];
			},
			$head
		);
		return $head;
	}
}
