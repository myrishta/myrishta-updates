<?php
/**
 * Quick find: a search box in the top bar of the admin. Type any part of a screen name (for example "optim", "keys",
 * "2fa", "backup") and jump straight to it. Press / anywhere in the admin to start typing. Reads the real admin menu,
 * so every new screen is found automatically.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_QuickFind {

	public static function init() {
		add_action( 'admin_bar_menu', array( __CLASS__, 'bar' ), 5 );
		add_action( 'admin_footer', array( __CLASS__, 'assets' ), 99 );
	}

	private static function items() {
		global $menu, $submenu;
		$out  = array();
		$seen = array();
		$add  = function ( $label, $slug, $group ) use ( &$out, &$seen ) {
			$label = trim( wp_strip_all_tags( preg_replace( '/<span.*?<\/span>/is', '', (string) $label ) ) );
			if ( '' === $label || isset( $seen[ $slug ] ) ) {
				return;
			}
			$seen[ $slug ] = 1;
			$url           = ( false !== strpos( $slug, '.php' ) ) ? admin_url( $slug ) : admin_url( 'admin.php?page=' . $slug );
			$out[]         = array( 'n' => $label, 'g' => $group, 'u' => $url );
		};
		foreach ( (array) $submenu as $parent => $subs ) {
			$gl = $parent;
			foreach ( (array) $menu as $m ) {
				if ( isset( $m[2] ) && $m[2] === $parent ) {
					$gl = trim( wp_strip_all_tags( preg_replace( '/<span.*?<\/span>/is', '', (string) $m[0] ) ) );
				}
			}
			foreach ( (array) $subs as $s ) {
				if ( ! empty( $s[1] ) && current_user_can( $s[1] ) ) {
					$add( $s[0], $s[2], $gl );
				}
			}
		}
		foreach ( (array) $menu as $m ) {
			if ( ! empty( $m[0] ) && ! empty( $m[1] ) && current_user_can( $m[1] ) ) {
				$add( $m[0], $m[2], 'Menu' );
			}
		}
		return $out;
	}

	public static function bar( $bar ) {
		if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$bar->add_node( array(
			'id'     => 'mrsh-qf',
			'parent' => 'top-secondary',
			'title'  => '<span class="mrsh-qf"><input type="search" id="mrsh-qf-in" placeholder="Find a screen… (press /)" autocomplete="off" aria-label="Find a MyRishta screen"><div id="mrsh-qf-out" hidden></div></span>',
			'meta'   => array( 'class' => 'mrsh-qf-node' ),
		) );
	}

	public static function assets() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		echo '<style>#wpadminbar .mrsh-qf{position:relative;display:inline-block}#wpadminbar #mrsh-qf-in{height:24px;width:210px;margin:4px 0;padding:0 10px;border:0;border-radius:99px;background:#3c434a;color:#fff;font-size:13px}#wpadminbar #mrsh-qf-in::placeholder{color:#c3c4c7}#wpadminbar #mrsh-qf-in:focus{background:#fff;color:#1d2327;outline:2px solid #7c3aed}#mrsh-qf-out{position:absolute;right:0;top:32px;width:340px;max-height:60vh;overflow:auto;background:#fff;border-radius:12px;box-shadow:0 12px 32px rgba(0,0,0,.25);padding:6px;z-index:99999}#mrsh-qf-out a{display:flex;justify-content:space-between;gap:10px;padding:9px 12px;border-radius:8px;color:#1d2327!important;font:600 13px/1.3 -apple-system,Segoe UI,sans-serif;height:auto!important;text-decoration:none}#mrsh-qf-out a small{color:#6b7280;font-weight:400}#mrsh-qf-out a.on,#mrsh-qf-out a:hover{background:#f3e8ff}#mrsh-qf-out p{margin:8px 12px;color:#6b7280;font:13px sans-serif}@media(max-width:782px){#wpadminbar #wp-admin-bar-mrsh-qf{display:block!important}#wpadminbar #mrsh-qf-in{width:130px}}</style>';
		echo '<script>(function(){var D=' . wp_json_encode( self::items() ) . ',i=document.getElementById("mrsh-qf-in"),o=document.getElementById("mrsh-qf-out");if(!i)return;var sel=0,L=[];
function norm(s){return s.toLowerCase().replace(/[^a-z0-9]+/g," ")}
function draw(){var q=norm(i.value).trim();if(!q){o.hidden=true;return}var w=q.split(" ");L=D.filter(function(d){var t=norm(d.n+" "+d.g);return w.every(function(x){return t.indexOf(x)>-1})}).sort(function(a,b){return (norm(a.n).indexOf(q)===0?0:1)-(norm(b.n).indexOf(q)===0?0:1)}).slice(0,12);sel=0;o.innerHTML=L.length?L.map(function(d,k){return \'<a href="\'+d.u+\'" class="\'+(k?"":"on")+\'">\'+d.n.replace(/</g,"&lt;")+" <small>"+d.g.replace(/</g,"&lt;")+"</small></a>"}).join(""):"<p>No screen with that name.</p>";o.hidden=false}
i.addEventListener("input",draw);i.addEventListener("focus",draw);
i.addEventListener("keydown",function(e){var a=o.querySelectorAll("a");if(e.key==="ArrowDown"||e.key==="ArrowUp"){e.preventDefault();if(!a.length)return;a[sel]&&a[sel].classList.remove("on");sel=(sel+(e.key==="ArrowDown"?1:a.length-1))%a.length;a[sel].classList.add("on");a[sel].scrollIntoView({block:"nearest"})}else if(e.key==="Enter"&&L[sel]){e.preventDefault();location.href=L[sel].u}else if(e.key==="Escape"){o.hidden=true;i.blur()}});
document.addEventListener("click",function(e){if(!e.target.closest(".mrsh-qf"))o.hidden=true});
document.addEventListener("keydown",function(e){if(e.key==="/"&&!/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)&&!e.target.isContentEditable){e.preventDefault();i.focus();i.select()}})})();</script>';
	}
}

MRSH_QuickFind::init();
