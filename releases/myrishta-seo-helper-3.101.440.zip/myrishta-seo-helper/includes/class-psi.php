<?php
/**
 * PageSpeed Insights inside the SEO menu: run mobile and desktop tests, keep a history,
 * and list what to fix. Uses Google's public PageSpeed Insights API (v5).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_PSI {

	const ENDPOINT = 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed';
	const HIST     = 'mrsh_psi_history';
	const KEYOPT   = 'mrsh_psi_key';
	const HOOK     = 'mrsh_psi_weekly';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 20 );
		add_action( 'admin_post_mrsh_psi', array( __CLASS__, 'handle' ) );
		add_action( self::HOOK, array( __CLASS__, 'weekly' ) );
		add_action( 'init', function () {
			if ( ! wp_next_scheduled( self::HOOK ) ) {
				wp_schedule_event( time() + DAY_IN_SECONDS, 'weekly', self::HOOK );
			}
		} );
		add_filter( 'cron_schedules', function ( $s ) {
			if ( ! isset( $s['weekly'] ) ) {
				$s['weekly'] = array( 'interval' => WEEK_IN_SECONDS, 'display' => 'Weekly' );
			}
			return $s;
		} );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'MyRishta SEO: PageSpeed', 'PageSpeed', 'manage_options', 'mrsh-psi', array( __CLASS__, 'page' ) );
	}

	/** Turn Google's JSON answer into the few numbers and fixes we show. */
	public static function parse( $json ) {
		if ( ! is_array( $json ) || empty( $json['lighthouseResult']['categories'] ) ) {
			return null;
		}
		$lh  = $json['lighthouseResult'];
		$cat = function ( $k ) use ( $lh ) {
			return isset( $lh['categories'][ $k ]['score'] ) ? (int) round( $lh['categories'][ $k ]['score'] * 100 ) : null;
		};
		$aud = isset( $lh['audits'] ) ? $lh['audits'] : array();
		$val = function ( $k ) use ( $aud ) {
			return isset( $aud[ $k ]['displayValue'] ) ? $aud[ $k ]['displayValue'] : '–';
		};
		$fix = array();
		foreach ( $aud as $id => $a ) {
			$ms = isset( $a['details']['overallSavingsMs'] ) ? (float) $a['details']['overallSavingsMs'] : 0;
			$by = isset( $a['details']['overallSavingsBytes'] ) ? (float) $a['details']['overallSavingsBytes'] : 0;
			if ( isset( $a['score'] ) && null !== $a['score'] && $a['score'] < 0.9 && ( $ms > 0 || $by > 10240 ) ) {
				$fix[] = array( 'title' => isset( $a['title'] ) ? $a['title'] : $id, 'ms' => (int) round( $ms ), 'kb' => (int) round( $by / 1024 ) );
			}
		}
		usort( $fix, function ( $x, $y ) {
			return $y['ms'] <=> $x['ms'] ?: $y['kb'] <=> $x['kb'];
		} );
		return array(
			'perf'  => $cat( 'performance' ),
			'a11y'  => $cat( 'accessibility' ),
			'best'  => $cat( 'best-practices' ),
			'seo'   => $cat( 'seo' ),
			'fcp'   => $val( 'first-contentful-paint' ),
			'lcp'   => $val( 'largest-contentful-paint' ),
			'tbt'   => $val( 'total-blocking-time' ),
			'cls'   => $val( 'cumulative-layout-shift' ),
			'si'    => $val( 'speed-index' ),
			'fix'   => array_slice( $fix, 0, 8 ),
		);
	}

	public static function run( $url, $strategy ) {
		$args = array(
			'url'      => $url,
			'strategy' => 'desktop' === $strategy ? 'desktop' : 'mobile',
		);
		$key = trim( (string) get_option( self::KEYOPT, '' ) );
		if ( '' === $key ) { // the Website keys page is the main place for this key
			$wk  = (array) get_option( 'mrsh_keys', array() );
			$key = trim( (string) ( $wk['psi_key'] ?? '' ) );
		}
		$q   = add_query_arg( $args, self::ENDPOINT );
		foreach ( array( 'performance', 'accessibility', 'best-practices', 'seo' ) as $c ) {
			$q .= '&category=' . $c;
		}
		if ( $key ) {
			$q .= '&key=' . rawurlencode( $key );
		}
		$r = wp_remote_get( $q, array( 'timeout' => 100 ) );
		if ( is_wp_error( $r ) ) {
			return array( 'error' => $r->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $r );
		$body = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( 200 !== $code ) {
			$m = isset( $body['error']['message'] ) ? $body['error']['message'] : 'HTTP ' . $code;
			if ( 429 === $code ) {
				$m = 'Google says too many tests right now. Wait a few minutes, or add a free API key below.';
			}
			return array( 'error' => $m );
		}
		$p = self::parse( $body );
		return $p ? $p : array( 'error' => 'Google returned no scores for this page.' );
	}

	public static function store( $url, $strategy, $res ) {
		if ( isset( $res['error'] ) ) {
			return;
		}
		$h = get_option( self::HIST, array() );
		$h = is_array( $h ) ? $h : array();
		array_unshift( $h, array_merge( array( 'time' => time(), 'url' => $url, 'strategy' => $strategy ), $res ) );
		update_option( self::HIST, array_slice( $h, 0, 40 ), false );
	}

	public static function weekly() {
		foreach ( array( 'mobile', 'desktop' ) as $s ) {
			self::store( home_url( '/' ), $s, self::run( home_url( '/' ), $s ) );
		}
	}

	public static function handle() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_psi' );
		$do = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
		if ( 'key' === $do ) {
			update_option( self::KEYOPT, preg_replace( '/[^A-Za-z0-9_\-]/', '', isset( $_POST['key'] ) ? wp_unslash( $_POST['key'] ) : '' ), false );
			$msg = 'API key saved.';
		} else {
			@set_time_limit( 240 ); // phpcs:ignore
			$url = isset( $_POST['url'] ) ? esc_url_raw( wp_unslash( $_POST['url'] ) ) : home_url( '/' );
			if ( '' === $url || wp_parse_url( $url, PHP_URL_HOST ) !== wp_parse_url( home_url(), PHP_URL_HOST ) ) {
				$url = home_url( '/' );
			}
			$msgs = array();
			foreach ( array( 'mobile', 'desktop' ) as $s ) {
				$r = self::run( $url, $s );
				self::store( $url, $s, $r );
				$msgs[] = ucfirst( $s ) . ': ' . ( isset( $r['error'] ) ? $r['error'] : 'score ' . $r['perf'] );
			}
			$msg = implode( ' | ', $msgs );
		}
		set_transient( 'mrsh_psi_msg', $msg, 120 );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-psi' ) );
		exit;
	}

	private static function badge( $n ) {
		if ( null === $n ) {
			return '<span>–</span>';
		}
		$c = $n >= 90 ? '#0c8f3c' : ( $n >= 50 ? '#e07a00' : '#d02020' );
		return '<strong style="display:inline-block;min-width:34px;text-align:center;padding:2px 6px;border-radius:12px;color:#fff;background:' . $c . '">' . (int) $n . '</strong>';
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$msg = get_transient( 'mrsh_psi_msg' );
		if ( $msg ) {
			delete_transient( 'mrsh_psi_msg' );
			echo '<div class="notice notice-info"><p>' . esc_html( $msg ) . '</p></div>';
		}
		$h = get_option( self::HIST, array() );
		$h = is_array( $h ) ? $h : array();
		MRSH_Admin::open( 'PageSpeed Insights', 'Runs Google PageSpeed Insights on your site (mobile and desktop) and keeps the results. A test takes about 30 to 60 seconds. It also runs by itself once a week on the homepage.' );
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin-bottom:12px"><input type="hidden" name="action" value="mrsh_psi"><input type="hidden" name="do" value="run">';
		wp_nonce_field( 'mrsh_psi' );
		echo '<input type="url" name="url" value="' . esc_attr( home_url( '/' ) ) . '" style="min-width:340px"> <button class="button button-primary">Run test (mobile and desktop)</button> <a class="button" target="_blank" rel="noopener" href="' . esc_url( 'https://pagespeed.web.dev/analysis?url=' . rawurlencode( home_url( '/' ) ) ) . '">Open pagespeed.web.dev</a></form>';

		if ( $h ) {
			$last = array();
			foreach ( $h as $row ) {
				if ( ! isset( $last[ $row['strategy'] ] ) ) {
					$last[ $row['strategy'] ] = $row;
				}
			}
			foreach ( $last as $s => $r ) {
				echo '<div style="background:#fff;border:1px solid #ccd0d4;padding:12px 16px;margin:0 0 14px;max-width:900px"><h2 style="margin-top:0">' . esc_html( ucfirst( $s ) ) . ' <small style="font-weight:400;color:#666">' . esc_html( human_time_diff( $r['time'] ) . ' ago, ' . $r['url'] ) . '</small></h2>';
				echo '<p>Performance ' . self::badge( $r['perf'] ) . ' &nbsp; Accessibility ' . self::badge( $r['a11y'] ) . ' &nbsp; Best practices ' . self::badge( $r['best'] ) . ' &nbsp; SEO ' . self::badge( $r['seo'] ) . '</p>';
				echo '<p>First paint <strong>' . esc_html( $r['fcp'] ) . '</strong> &middot; Largest paint <strong>' . esc_html( $r['lcp'] ) . '</strong> &middot; Blocking time <strong>' . esc_html( $r['tbt'] ) . '</strong> &middot; Layout shift <strong>' . esc_html( $r['cls'] ) . '</strong> &middot; Speed index <strong>' . esc_html( $r['si'] ) . '</strong></p>';
				if ( ! empty( $r['fix'] ) ) {
					echo '<p><strong>Biggest things to fix</strong></p><ol>';
					foreach ( $r['fix'] as $f ) {
						echo '<li>' . esc_html( $f['title'] ) . ' <span style="color:#666">' . ( $f['ms'] ? '(about ' . (int) $f['ms'] . ' ms' . ( $f['kb'] ? ', ' . (int) $f['kb'] . ' KB' : '' ) . ')' : '(' . (int) $f['kb'] . ' KB)' ) . '</span></li>';
					}
					echo '</ol>';
				}
				echo '</div>';
			}
			echo '<h2>History</h2><table class="widefat striped" style="max-width:900px"><thead><tr><th>When</th><th>Device</th><th>Perf</th><th>Access.</th><th>Best</th><th>SEO</th><th>LCP</th><th>FCP</th></tr></thead><tbody>';
			foreach ( array_slice( $h, 0, 20 ) as $r ) {
				echo '<tr><td>' . esc_html( wp_date( 'j M Y, g:i A', $r['time'] ) ) . '</td><td>' . esc_html( $r['strategy'] ) . '</td><td>' . self::badge( $r['perf'] ) . '</td><td>' . self::badge( $r['a11y'] ) . '</td><td>' . self::badge( $r['best'] ) . '</td><td>' . self::badge( $r['seo'] ) . '</td><td>' . esc_html( $r['lcp'] ) . '</td><td>' . esc_html( $r['fcp'] ) . '</td></tr>';
			}
			echo '</tbody></table>';
		} else {
			echo '<p><em>No tests yet. Click "Run test".</em></p>';
		}
		echo '<h2>API key (optional)</h2><p>Without a key Google may refuse tests when it is busy. A free key from Google Cloud (enable the "PageSpeed Insights API") fixes that.</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_psi"><input type="hidden" name="do" value="key">';
		wp_nonce_field( 'mrsh_psi' );
		echo '<input type="text" name="key" value="' . esc_attr( get_option( self::KEYOPT, '' ) ) . '" style="min-width:340px" autocomplete="off"> <button class="button">Save key</button></form></div>';
	}
}
