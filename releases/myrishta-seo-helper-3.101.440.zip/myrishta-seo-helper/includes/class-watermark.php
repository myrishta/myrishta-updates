<?php
/**
 * Photo watermark: every profile photo shown on the website carries "myrishta.pk".
 * Originals stay untouched in the media library. The site links to a watermarked copy, made once on first view
 * and kept in uploads/mrsh-wm. Staff see originals in the admin. Switch on or off, and clear the copies, on the
 * Photo safety screen (Members and matches).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Watermark {

	const OPT = 'mrsh_wm';

	public static function o( $k = null ) {
		$o = array_merge( array( 'on' => 1, 'text' => 'myrishta.pk', 'min' => 300, 'opacity' => 38 ), (array) get_option( self::OPT, array() ) );
		return null === $k ? $o : $o[ $k ];
	}

	public static function init() {
		add_action( 'init', array( __CLASS__, 'serve' ), 1 );
		add_filter( 'wp_get_attachment_image_src', array( __CLASS__, 'swap' ), 20, 4 );
		add_filter( 'wp_calculate_image_srcset', array( __CLASS__, 'nosrcset' ), 20, 5 );
		add_action( 'admin_post_mrsh_wm_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_mrsh_wm_clear', array( __CLASS__, 'clear' ) );
	}

	private static function dir() {
		$u = wp_upload_dir();
		return array( trailingslashit( $u['basedir'] ) . 'mrsh-wm/', $u['basedir'] );
	}

	/** Only photos that belong to a member profile. */
	private static function is_profile_photo( $aid ) {
		$par = (int) wp_get_post_parent_id( $aid );
		return $par && 'listing_type' === get_post_type( $par );
	}

	public static function swap( $image, $aid, $size, $icon ) {
		if ( ! $image || is_admin() || ! self::o( 'on' ) || $icon || empty( $image[0] ) || (int) $image[1] < (int) self::o( 'min' ) ) {
			return $image;
		}
		if ( ! self::is_profile_photo( (int) $aid ) || ! file_exists( (string) get_attached_file( $aid ) ) ) {
			return $image;
		}
		$image[0] = home_url( '/mr-wm/' . (int) $aid . '-' . (int) $image[1] . '.webp' );
		return $image;
	}

	public static function nosrcset( $sources, $size_array, $image_src, $meta, $aid ) {
		if ( ! is_admin() && self::o( 'on' ) && false !== strpos( (string) $image_src, '/mr-wm/' ) ) {
			return false;
		}
		return $sources;
	}

	/** Find the file on disk whose width is $w. */
	private static function source( $aid, $w ) {
		$file = get_attached_file( $aid );
		$meta = wp_get_attachment_metadata( $aid );
		if ( ! $file || ! is_array( $meta ) ) {
			return $file;
		}
		if ( (int) ( $meta['width'] ?? 0 ) === $w ) {
			return $file;
		}
		foreach ( (array) ( $meta['sizes'] ?? array() ) as $s ) {
			if ( (int) $s['width'] === $w ) {
				return trailingslashit( dirname( $file ) ) . $s['file'];
			}
		}
		return $file;
	}

	public static function serve() {
		$p = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore
		if ( false === strpos( $p, '/mr-wm/' ) || ! preg_match( '#/mr-wm/(\d+)-(\d+)\.webp#', $p, $m ) ) {
			return;
		}
		$aid = (int) $m[1];
		$w   = (int) $m[2];
		if ( ! $aid || $w < 50 || $w > 4000 || ! self::is_profile_photo( $aid ) ) {
			status_header( 404 );
			exit;
		}
		list( $dir ) = self::dir();
		$out         = $dir . $aid . '-' . $w . '.webp';
		$src         = self::source( $aid, $w );
		if ( ! $src || ! is_file( $src ) ) {
			status_header( 404 );
			exit;
		}
		$rebuild = ! is_file( $out ) || filemtime( $out ) < filemtime( $src ) || filemtime( $out ) < (int) get_option( 'mrsh_wm_gen', 0 );
		if ( $rebuild ) {
			wp_mkdir_p( $dir );
			if ( ! is_file( $dir . 'index.html' ) ) {
				file_put_contents( $dir . 'index.html', '' ); // phpcs:ignore
			}
			if ( ! self::make( $src, $out ) ) {
				// Could not mark it: never leak the original, send a plain 404.
				status_header( 404 );
				exit;
			}
		}
		nocache_headers();
		header_remove( 'Cache-Control' );
		header( 'Content-Type: image/webp' );
		header( 'Cache-Control: public, max-age=2592000' );
		header( 'Content-Length: ' . filesize( $out ) );
		header( 'X-Robots-Tag: noindex' );
		readfile( $out ); // phpcs:ignore
		exit;
	}

	/** Draw the mark: a faint pattern across the picture and a clear one in the corner. */
	public static function make( $src, $out ) {
		if ( ! function_exists( 'imagettftext' ) || ! function_exists( 'imagewebp' ) ) {
			return false;
		}
		$data = @file_get_contents( $src ); // phpcs:ignore
		$im   = $data ? @imagecreatefromstring( $data ) : false; // phpcs:ignore
		if ( ! $im ) {
			return false;
		}
		imagepalettetotruecolor( $im );
		imagealphablending( $im, true );
		$w    = imagesx( $im );
		$h    = imagesy( $im );
		$font = MRSH_DIR . 'assets/fonts/wm.ttf';
		$txt  = (string) self::o( 'text' );
		if ( ! is_file( $font ) || '' === $txt ) {
			imagedestroy( $im );
			return false;
		}
		$alpha = (int) max( 0, min( 127, 127 - round( 127 * ( (int) self::o( 'opacity' ) / 100 ) ) ) );
		$white = imagecolorallocatealpha( $im, 255, 255, 255, $alpha );
		$dark  = imagecolorallocatealpha( $im, 0, 0, 0, min( 127, $alpha + 30 ) );
		// Pattern: diagonal rows.
		$fs   = max( 12, (int) round( $w / 26 ) );
		$box  = imagettfbbox( $fs, 0, $font, $txt );
		$tw   = abs( $box[2] - $box[0] );
		$gapx = $tw + (int) ( $fs * 2.2 );
		$gapy = (int) ( $fs * 4.2 );
		$angle = 28;
		$row   = 0;
		for ( $y = (int) ( $h * 0.1 ); $y < $h + $gapy; $y += $gapy, $row++ ) {
			for ( $x = -$gapx + ( $row % 2 ) * (int) ( $gapx / 2 ); $x < $w + $gapx; $x += $gapx ) {
				imagettftext( $im, $fs, $angle, $x + 1, $y + $gapy / 2 + 1, $dark, $font, $txt );
				imagettftext( $im, $fs, $angle, $x, $y + $gapy / 2, $white, $font, $txt );
			}
		}
		// Corner mark, stronger.
		$fs2 = max( 14, (int) round( $w / 14 ) );
		$b2  = imagettfbbox( $fs2, 0, $font, $txt );
		$x2  = $w - abs( $b2[2] - $b2[0] ) - (int) ( $fs2 * 0.6 );
		$y2  = $h - (int) ( $fs2 * 0.7 );
		$cw  = imagecolorallocatealpha( $im, 255, 255, 255, max( 0, $alpha - 25 ) );
		imagettftext( $im, $fs2, 0, $x2 + 2, $y2 + 2, imagecolorallocatealpha( $im, 0, 0, 0, 40 ), $font, $txt );
		imagettftext( $im, $fs2, 0, $x2, $y2, $cw, $font, $txt );
		$ok = imagewebp( $im, $out, 82 );
		imagedestroy( $im );
		return (bool) $ok;
	}

	/* ---------- settings card (shown on the Photo safety screen) ---------- */

	public static function panel() {
		$o    = self::o();
		list( $dir ) = self::dir();
		$n    = is_dir( $dir ) ? count( (array) glob( $dir . '*.webp' ) ) : 0;
		$post = esc_url( admin_url( 'admin-post.php' ) );
		echo '<div class="card" style="max-width:none;padding:16px 18px;margin:16px 0"><h2 style="margin-top:0">Photo watermark</h2>';
		echo '<p>Every member photo on the website carries <b>' . esc_html( $o['text'] ) . '</b>, so a copied picture shows where it came from. Your originals stay clean in the media library. ' . (int) $n . ' marked copies made so far.</p>';
		echo '<form method="post" action="' . $post . '" style="display:flex;gap:12px;flex-wrap:wrap;align-items:end"><input type="hidden" name="action" value="mrsh_wm_save">' . wp_nonce_field( 'mrsh_wm_save', '_wpnonce', true, false ); // phpcs:ignore
		echo '<label><input type="checkbox" name="on" value="1"' . checked( $o['on'], 1, false ) . '> Watermark on</label>';
		echo '<label>Text<br><input name="text" value="' . esc_attr( $o['text'] ) . '" class="regular-text" style="width:200px"></label>';
		echo '<label>Strength (10-90)<br><input type="number" min="10" max="90" name="opacity" value="' . (int) $o['opacity'] . '" style="width:80px"></label>';
		echo '<button class="button button-primary">Save</button></form>';
		echo '<form method="post" action="' . $post . '" style="margin-top:10px"><input type="hidden" name="action" value="mrsh_wm_clear">' . wp_nonce_field( 'mrsh_wm_clear', '_wpnonce', true, false ) . '<button class="button">Remake all marked copies</button> <span class="description">Use after changing the text or strength.</span></form></div>'; // phpcs:ignore
	}

	private static function guard( $n ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.', '', array( 'response' => 403 ) );
		}
		check_admin_referer( $n );
	}

	public static function save() {
		self::guard( 'mrsh_wm_save' );
		$t = isset( $_POST['text'] ) ? sanitize_text_field( wp_unslash( $_POST['text'] ) ) : 'myrishta.pk'; // phpcs:ignore
		update_option( self::OPT, array( 'on' => empty( $_POST['on'] ) ? 0 : 1, 'text' => '' === $t ? 'myrishta.pk' : substr( $t, 0, 30 ), 'min' => 300, 'opacity' => max( 10, min( 90, (int) ( $_POST['opacity'] ?? 38 ) ) ) ), false ); // phpcs:ignore
		update_option( 'mrsh_wm_gen', time(), false );
		do_action( 'litespeed_purge_all' );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-photo-safety&wm=1' ) );
		exit;
	}

	public static function clear() {
		self::guard( 'mrsh_wm_clear' );
		update_option( 'mrsh_wm_gen', time(), false );
		do_action( 'litespeed_purge_all' );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-photo-safety&wm=1' ) );
		exit;
	}
}
MRSH_Watermark::init();
