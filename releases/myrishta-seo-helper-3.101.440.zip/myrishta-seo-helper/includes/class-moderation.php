<?php
/**
 * Photo safety filter. Every image a member uploads is checked for nudity by an image-safety service (Sightengine).
 * A photo that fails is removed from the site, kept privately for 14 days so the team can review it, and the member
 * gets a violation email. Admin uploads are never checked. If the service is down the photo stays and is re-checked later.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Moderation {

	const OPT   = 'mrsh_mod_settings';
	const LOG   = 'mrsh_mod_log';
	const META  = '_mrsh_mod';          // ok | pending | blocked.
	const STRIK = 'mrsh_mod_strikes';
	const KEEP  = 14 * DAY_IN_SECONDS;

	public static function settings() {
		$d = array(
			'enabled'   => 0,
			'user'      => '',
			'secret'    => '', // encrypted.
			'threshold' => 60, // percent.
			'suggest'   => 0,  // also block "very suggestive".
			'email'     => 1,
		);
		$s = get_option( self::OPT, array() );
		return is_array( $s ) ? array_merge( $d, $s ) : $d;
	}

	public static function active() {
		$s = self::settings();
		return ! empty( $s['enabled'] ) && '' !== $s['user'] && '' !== $s['secret'];
	}

	private static function secret() {
		$s = self::settings();
		return '' === $s['secret'] ? '' : (string) MRSH_TwoFactor::dec( $s['secret'] );
	}

	public static function init() {
		add_filter( 'wp_generate_attachment_metadata', array( __CLASS__, 'on_upload' ), 99, 2 );
		add_action( 'mrsh_mod_retry', array( __CLASS__, 'retry' ) );
		add_action( 'init', array( __CLASS__, 'arm' ) );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 22 );
		foreach ( array( 'save', 'test', 'scan', 'restore', 'purge', 'resend' ) as $a ) {
			add_action( 'admin_post_mrsh_mod_' . $a, array( __CLASS__, 'act_' . $a ) );
		}
	}

	public static function arm() {
		if ( ! wp_next_scheduled( 'mrsh_mod_retry' ) ) {
			wp_schedule_event( time() + 600, 'hourly', 'mrsh_mod_retry' );
		}
	}

	/* ---------- the check ---------- */

	/** @return array|WP_Error array( 'score' => 0-100, 'why' => string ). */
	public static function scan_url( $url ) {
		$s = self::settings();
		$r = wp_remote_get( add_query_arg( array(
			'models'     => 'nudity-2.1',
			'api_user'   => $s['user'],
			'api_secret' => self::secret(),
			'url'        => $url,
		), 'https://api.sightengine.com/1.0/check.json' ), array( 'timeout' => 8 ) );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$j = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( ! is_array( $j ) || ( isset( $j['status'] ) && 'success' !== $j['status'] ) || empty( $j['nudity'] ) ) {
			$m = is_array( $j ) && ! empty( $j['error']['message'] ) ? $j['error']['message'] : 'unexpected answer';
			return new WP_Error( 'mrsh_mod_api', 'Image service: ' . $m );
		}
		$n    = $j['nudity'];
		$keys = array( 'sexual_activity' => 'sexual activity', 'sexual_display' => 'sexual display', 'erotica' => 'erotica' );
		if ( ! empty( $s['suggest'] ) ) {
			$keys['very_suggestive'] = 'very suggestive content';
		}
		$top = 0;
		$why = '';
		foreach ( $keys as $k => $label ) {
			$v = isset( $n[ $k ] ) ? (float) $n[ $k ] : 0;
			if ( $v > $top ) {
				$top = $v;
				$why = $label;
			}
		}
		return array( 'score' => (int) round( $top * 100 ), 'why' => $why );
	}

	private static function url_for( $id ) {
		$u = wp_get_attachment_image_url( $id, 'large' );
		return $u ? $u : wp_get_attachment_url( $id );
	}

	private static function is_checkable( $id ) {
		return in_array( get_post_mime_type( $id ), array( 'image/jpeg', 'image/png', 'image/webp', 'image/gif' ), true );
	}

	public static function on_upload( $meta, $id ) {
		if ( ! self::active() || ! self::is_checkable( $id ) || get_post_meta( $id, self::META, true ) ) {
			return $meta;
		}
		$author = (int) get_post_field( 'post_author', $id );
		if ( $author && user_can( $author, 'manage_options' ) ) {
			update_post_meta( $id, self::META, 'ok' );
			return $meta;
		}
		// Do not make the member wait: answer the upload first, then check in the background.
		update_post_meta( $id, self::META, 'pending' );
		add_action( 'shutdown', function () use ( $id ) {
			if ( function_exists( 'fastcgi_finish_request' ) ) {
				fastcgi_finish_request();
			} elseif ( function_exists( 'litespeed_finish_request' ) ) {
				litespeed_finish_request();
			}
			if ( 'pending' === get_post_meta( $id, MRSH_Moderation::META, true ) ) {
				MRSH_Moderation::judge( $id );
			}
		}, 5 );
		return $meta;
	}

	/** Checks one attachment. Returns 'ok', 'blocked' or 'pending'. */
	public static function judge( $id ) {
		$r = self::scan_url( self::url_for( $id ) );
		if ( is_wp_error( $r ) ) {
			update_post_meta( $id, self::META, 'pending' );
			return 'pending';
		}
		$s = self::settings();
		if ( $r['score'] >= (int) $s['threshold'] ) {
			update_post_meta( $id, self::META, 'blocked' );
			self::remove( $id, $r['score'], $r['why'] );
			return 'blocked';
		}
		update_post_meta( $id, self::META, 'ok' );
		return 'ok';
	}

	public static function retry() {
		if ( ! self::active() ) {
			return;
		}
		$q = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'posts_per_page' => 20, 'fields' => 'ids', 'meta_key' => self::META, 'meta_value' => 'pending' ) );
		foreach ( $q as $id ) {
			self::judge( $id );
		}
	}

	/* ---------- removal, log and emails ---------- */

	private static function qdir() {
		$u = wp_upload_dir();
		$d = trailingslashit( $u['basedir'] ) . 'mrsh-quarantine';
		if ( ! is_dir( $d ) ) {
			wp_mkdir_p( $d );
			file_put_contents( $d . '/.htaccess', "Require all denied\nDeny from all\n" );
			file_put_contents( $d . '/index.html', '' );
		}
		return $d;
	}

	public static function remove( $id, $score, $why ) {
		$file = get_attached_file( $id );
		$uid  = (int) get_post_field( 'post_author', $id );
		$name = $file ? basename( $file ) : 'photo';
		$q    = '';
		if ( $file && is_readable( $file ) ) {
			$q = self::qdir() . '/' . (int) $id . '-' . wp_generate_password( 6, false ) . '-' . sanitize_file_name( $name );
			if ( ! @copy( $file, $q ) ) {
				$q = '';
			}
		}
		wp_delete_attachment( $id, true );
		$n = (int) get_user_meta( $uid, self::STRIK, true ) + 1;
		if ( $uid ) {
			update_user_meta( $uid, self::STRIK, $n );
		}
		$log = get_option( self::LOG, array() );
		$log = is_array( $log ) ? $log : array();
		array_unshift( $log, array( 'id' => (int) $id, 'user' => $uid, 'score' => (int) $score, 'why' => $why, 'time' => time(), 'file' => $q, 'name' => $name, 'state' => 'removed' ) );
		update_option( self::LOG, array_slice( $log, 0, 300 ), false );
		$s = self::settings();
		if ( ! empty( $s['email'] ) && $uid ) {
			self::mail_member( $uid, $n );
		}
		$u = $uid ? get_userdata( $uid ) : false;
		self::mail( get_option( 'admin_email' ), 'Photo removed on My Rishta Pakistan',
			"A photo was removed automatically.\n\nMember: " . ( $u ? $u->user_login . ' (' . $u->user_email . ')' : 'unknown' ) . "\nReason: " . $why . ' (' . $score . "%)\nViolations so far: " . $n . "\n\nThe file is kept privately for 14 days. Review it in wp-admin > My Rishta SEO > Photo safety." . ( $n >= 3 ? "\n\nThis member now has " . $n . ' violations. Please review the account.' : '' ) );
	}

	private static function mail_member( $uid, $n ) {
		$u = get_userdata( $uid );
		if ( ! $u || ! is_email( $u->user_email ) ) {
			return;
		}
		$name = $u->display_name ? $u->display_name : $u->user_login;
		$warn = $n >= 3 ? "\nThis is violation number " . $n . ". Further violations can lead to your profile being suspended.\n" : ( $n >= 2 ? "\nThis is violation number " . $n . ". Repeated violations can lead to your profile being suspended.\n" : '' );
		$body = "Assalam o Alaikum " . $name . ",\n\n"
			. "A photo you uploaded to My Rishta Pakistan was removed because it broke our profile rules. Photos must be decent: no nudity, sexual or explicit content.\n" . $warn . "\n"
			. "Please upload a clear, modest photo of yourself. Our rules: " . home_url( '/profile-guidelines/' ) . "\n"
			. "If you think this was a mistake, reply to this email and our team will review it.\n\n"
			. "آپ کی اپ لوڈ کی گئی تصویر ہمارے پروفائل قواعد کی خلاف ورزی کی وجہ سے ہٹا دی گئی ہے۔ تصویر شائستہ ہونی چاہیے۔ براہ کرم اپنی صاف اور باوقار تصویر لگائیں۔\n\n"
			. "My Rishta Pakistan\n" . home_url( '/' );
		self::mail( $u->user_email, 'Your photo was removed: My Rishta Pakistan', $body );
	}

	private static function mail( $to, $subject, $body ) {
		$name = static function () { return 'My Rishta Pakistan'; };
		$addr = static function () { return (string) apply_filters( 'mrsh_mail_from', 'noreply@myrishta.com' ); };
		add_filter( 'wp_mail_from_name', $name );
		add_filter( 'wp_mail_from', $addr );
		$ok = wp_mail( $to, $subject, $body, array( 'Reply-To: My Rishta Support <support@myrishta.pk>' ) );
		remove_filter( 'wp_mail_from_name', $name );
		remove_filter( 'wp_mail_from', $addr );
		return $ok;
	}

	/** Deletes quarantined files older than 14 days. */
	private static function sweep() {
		$log = get_option( self::LOG, array() );
		$ch  = false;
		foreach ( (array) $log as $i => $e ) {
			if ( 'removed' === $e['state'] && ! empty( $e['file'] ) && $e['time'] < time() - self::KEEP ) {
				if ( is_file( $e['file'] ) ) {
					@unlink( $e['file'] );
				}
				$log[ $i ]['file']  = '';
				$log[ $i ]['state'] = 'expired';
				$ch                 = true;
			}
		}
		if ( $ch ) {
			update_option( self::LOG, $log, false );
		}
	}

	/* ---------- admin ---------- */

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Photo safety', 'Photo safety', 'manage_options', 'mrsh-photo-safety', array( __CLASS__, 'page' ) );
	}

	private static function back( $msg ) {
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-photo-safety&msg=' . rawurlencode( $msg ) ) );
		exit;
	}

	private static function guard( $nonce ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( $nonce );
	}

	public static function act_save() {
		self::guard( 'mrsh_mod_save' );
		$s    = self::settings();
		$sec  = isset( $_POST['sec'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['sec'] ) ) ) : '';
		$s['enabled']   = empty( $_POST['enabled'] ) ? 0 : 1;
		$s['user']      = isset( $_POST['api_user'] ) ? sanitize_text_field( wp_unslash( $_POST['api_user'] ) ) : '';
		$s['threshold'] = isset( $_POST['threshold'] ) ? max( 30, min( 95, (int) $_POST['threshold'] ) ) : 60;
		$s['suggest']   = empty( $_POST['suggest'] ) ? 0 : 1;
		$s['email']     = empty( $_POST['email'] ) ? 0 : 1;
		if ( '' !== $sec ) {
			$s['secret'] = MRSH_TwoFactor::enc( $sec );
		}
		update_option( self::OPT, $s, false );
		self::back( 'Saved.' );
	}

	public static function act_test() {
		self::guard( 'mrsh_mod_test' );
		$url = isset( $_POST['url'] ) ? esc_url_raw( wp_unslash( $_POST['url'] ) ) : '';
		if ( '' === $url ) {
			self::back( 'Paste an image link to test.' );
		}
		$r = self::scan_url( $url );
		self::back( is_wp_error( $r ) ? $r->get_error_message() : 'Score ' . $r['score'] . '% (' . ( $r['why'] ? $r['why'] : 'clean' ) . '). Photos at or above ' . (int) self::settings()['threshold'] . '% are removed.' );
	}

	/** Checks the next 15 member photos that have never been checked. */
	public static function act_scan() {
		self::guard( 'mrsh_mod_scan' );
		if ( ! self::active() ) {
			self::back( 'Save your keys and switch the filter on first.' );
		}
		$q = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'posts_per_page' => 15, 'orderby' => 'ID', 'order' => 'DESC',
			'post_mime_type' => array( 'image/jpeg', 'image/png', 'image/webp', 'image/gif' ),
			'meta_query' => array( array( 'key' => self::META, 'compare' => 'NOT EXISTS' ) ), 'fields' => 'ids' ) );
		$b = 0; $o = 0; $p = 0;
		foreach ( $q as $id ) {
			$a = (int) get_post_field( 'post_author', $id );
			if ( $a && user_can( $a, 'manage_options' ) ) {
				update_post_meta( $id, self::META, 'ok' );
				continue;
			}
			$st = self::judge( $id );
			if ( 'blocked' === $st ) {
				$b++;
			} elseif ( 'ok' === $st ) {
				$o++;
			} else {
				$p++;
			}
		}
		self::back( count( $q ) . ' photos checked: ' . $o . ' fine, ' . $b . ' removed, ' . $p . ' could not be checked. Press again for the next batch.' );
	}

	public static function act_restore() {
		self::guard( 'mrsh_mod_restore' );
		$i   = isset( $_POST['i'] ) ? (int) $_POST['i'] : -1;
		$log = get_option( self::LOG, array() );
		if ( ! isset( $log[ $i ] ) || empty( $log[ $i ]['file'] ) || ! is_file( $log[ $i ]['file'] ) ) {
			self::back( 'That file is no longer available.' );
		}
		$e  = $log[ $i ];
		$up = wp_upload_dir();
		$to = wp_unique_filename( $up['path'], $e['name'] );
		copy( $e['file'], trailingslashit( $up['path'] ) . $to );
		$ft  = wp_check_filetype( $to );
		$aid = wp_insert_attachment( array( 'post_mime_type' => $ft['type'], 'post_title' => preg_replace( '/\.[^.]+$/', '', $to ), 'post_status' => 'inherit', 'post_author' => (int) $e['user'] ), trailingslashit( $up['path'] ) . $to );
		if ( is_wp_error( $aid ) || ! $aid ) {
			self::back( 'Could not restore the photo.' );
		}
		update_post_meta( $aid, self::META, 'ok' );
		require_once ABSPATH . 'wp-admin/includes/image.php';
		wp_update_attachment_metadata( $aid, wp_generate_attachment_metadata( $aid, trailingslashit( $up['path'] ) . $to ) );
		@unlink( $e['file'] );
		$log[ $i ]['file']  = '';
		$log[ $i ]['state'] = 'restored';
		update_option( self::LOG, $log, false );
		if ( $e['user'] ) {
			$n = max( 0, (int) get_user_meta( $e['user'], self::STRIK, true ) - 1 );
			update_user_meta( $e['user'], self::STRIK, $n );
		}
		self::back( 'Photo restored to the media library (new ID ' . $aid . '). The member must choose it again on their profile.' );
	}

	public static function act_purge() {
		self::guard( 'mrsh_mod_purge' );
		$i   = isset( $_POST['i'] ) ? (int) $_POST['i'] : -1;
		$log = get_option( self::LOG, array() );
		if ( isset( $log[ $i ] ) ) {
			if ( ! empty( $log[ $i ]['file'] ) && is_file( $log[ $i ]['file'] ) ) {
				@unlink( $log[ $i ]['file'] );
			}
			$log[ $i ]['file']  = '';
			$log[ $i ]['state'] = 'deleted';
			update_option( self::LOG, $log, false );
		}
		self::back( 'The private copy was deleted.' );
	}

	public static function act_resend() {
		self::guard( 'mrsh_mod_resend' );
		$i   = isset( $_POST['i'] ) ? (int) $_POST['i'] : -1;
		$log = get_option( self::LOG, array() );
		if ( isset( $log[ $i ] ) && $log[ $i ]['user'] ) {
			self::mail_member( (int) $log[ $i ]['user'], (int) get_user_meta( $log[ $i ]['user'], self::STRIK, true ) );
			self::back( 'Violation email sent again.' );
		}
		self::back( 'No member on that entry.' );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		self::sweep();
		$s   = self::settings();
		$log = get_option( self::LOG, array() );
		$ap  = esc_url( admin_url( 'admin-post.php' ) );
		echo '<div class="wrap"><h1>Photo safety</h1>';
		if ( isset( $_GET['msg'] ) ) {
			echo '<div class="notice notice-info"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['msg'] ) ) ) . '</p></div>';
		}
		if ( class_exists( 'MRSH_Watermark' ) ) {
			MRSH_Watermark::panel();
		}
		echo '<p>Member photos are checked for nudity when they are uploaded. A photo that fails is removed, kept privately for 14 days, and the member gets a violation email. Your own uploads are never checked. This sends member photos to an image-safety service (Sightengine), so mention it in your privacy policy.</p>';
		echo '<ol><li>Create a free account at <a href="https://sightengine.com" target="_blank" rel="noopener">sightengine.com</a> and copy the <strong>API user</strong> and <strong>API secret</strong>.</li><li>Paste them below, tick the filter on and save.</li><li>Press <strong>Check older photos</strong> to scan what is already uploaded.</li></ol>';
		echo '<form method="post" action="' . $ap . '"><input type="hidden" name="action" value="mrsh_mod_save">';
		wp_nonce_field( 'mrsh_mod_save' );
		echo '<table class="form-table"><tr><th>Filter</th><td><label><input type="checkbox" name="enabled" value="1"' . checked( $s['enabled'], 1, false ) . '> On</label></td></tr>';
		echo '<tr><th>API user</th><td><input type="text" name="api_user" class="regular-text" value="' . esc_attr( $s['user'] ) . '"></td></tr>';
		echo '<tr><th>API secret</th><td><input type="password" name="sec" class="regular-text" autocomplete="new-password" placeholder="' . ( '' !== $s['secret'] ? 'Saved. Leave empty to keep it.' : '' ) . '"></td></tr>';
		echo '<tr><th>Remove at score</th><td><input type="number" name="threshold" min="30" max="95" value="' . (int) $s['threshold'] . '"> % <span class="description">Lower removes more photos. 60 is a good start.</span></td></tr>';
		echo '<tr><th>Also remove</th><td><label><input type="checkbox" name="suggest" value="1"' . checked( $s['suggest'], 1, false ) . '> Very suggestive photos (stricter)</label></td></tr>';
		echo '<tr><th>Violation email</th><td><label><input type="checkbox" name="email" value="1"' . checked( $s['email'], 1, false ) . '> Email the member when a photo is removed</label></td></tr></table>';
		echo '<p><button class="button button-primary">Save</button></p></form>';
		echo '<hr><h2>Tools</h2><form method="post" action="' . $ap . '" style="display:inline-block;margin-right:20px"><input type="hidden" name="action" value="mrsh_mod_scan">';
		wp_nonce_field( 'mrsh_mod_scan' );
		echo '<button class="button button-primary">Check older photos (next 15)</button></form>';
		echo '<form method="post" action="' . $ap . '" style="display:inline-block"><input type="hidden" name="action" value="mrsh_mod_test">';
		wp_nonce_field( 'mrsh_mod_test' );
		echo '<input type="url" name="url" placeholder="Image link to test" class="regular-text"> <button class="button">Test this image</button></form>';
		echo '<hr><h2>Removed photos</h2>';
		if ( empty( $log ) ) {
			echo '<p>Nothing has been removed yet.</p>';
		} else {
			echo '<table class="widefat striped"><thead><tr><th>When</th><th>Member</th><th>Reason</th><th>Status</th><th>Actions</th></tr></thead><tbody>';
			foreach ( $log as $i => $e ) {
				$u = $e['user'] ? get_userdata( $e['user'] ) : false;
				echo '<tr><td>' . esc_html( wp_date( 'j M Y H:i', $e['time'] ) ) . '</td><td>' . ( $u ? esc_html( $u->user_login ) . ' (' . (int) get_user_meta( $e['user'], self::STRIK, true ) . ' strikes)' : '-' ) . '</td><td>' . esc_html( $e['why'] . ' ' . $e['score'] . '%' ) . '</td><td>' . esc_html( $e['state'] ) . '</td><td>';
				foreach ( array( 'resend' => 'Email again', 'restore' => 'Restore', 'purge' => 'Delete copy' ) as $a => $l ) {
					if ( 'removed' !== $e['state'] && 'resend' !== $a ) {
						continue;
					}
					echo '<form method="post" action="' . $ap . '" style="display:inline"><input type="hidden" name="action" value="mrsh_mod_' . $a . '"><input type="hidden" name="i" value="' . (int) $i . '">';
					wp_nonce_field( 'mrsh_mod_' . $a );
					echo '<button class="button button-small">' . esc_html( $l ) . '</button></form> ';
				}
				echo '</td></tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';
	}
}
