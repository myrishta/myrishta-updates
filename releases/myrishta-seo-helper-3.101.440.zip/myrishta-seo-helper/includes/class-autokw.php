<?php
/**
 * Automatic keyword phrases. Every published page gets the best-fitting phrase from the keyword bank as its
 * focus phrase, with no manual work. Phrases you set yourself are never changed. The phrase is also used in the
 * search-result description when the page does not already say it and there is room.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_AutoKW {

	const OPT  = 'mrsh_autokw';
	const HOOK = 'mrsh_autokw_run';
	const AUTO = '_mrsh_focus_auto'; // marks a phrase this tool chose (so it may be re-chosen later).

	public static function settings() {
		$d = array( 'enabled' => 1, 'desc' => 1, 'derive' => 1, 'last' => 0, 'last_msg' => '' );
		$s = get_option( self::OPT, array() );
		return is_array( $s ) ? array_merge( $d, $s ) : $d;
	}

	public static function init() {
		add_action( self::HOOK, array( __CLASS__, 'run' ) );
		add_action( 'init', array( __CLASS__, 'arm' ) );
		add_action( 'save_post', array( __CLASS__, 'on_save' ), 30, 2 );
		add_filter( 'mrsh_meta_description', array( __CLASS__, 'tune_desc' ), 10, 2 );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 23 );
		foreach ( array( 'save', 'run', 'undo', 'clear', 'gscan' ) as $a ) {
			add_action( 'admin_post_mrsh_autokw_' . $a, array( __CLASS__, 'act_' . $a ) );
		}
	}

	public static function arm() {
		$on   = ! empty( self::settings()['enabled'] );
		$next = wp_next_scheduled( self::HOOK );
		if ( $on && ! $next ) {
			wp_schedule_event( time() + 900, 'daily', self::HOOK );
		} elseif ( ! $on && $next ) {
			wp_clear_scheduled_hook( self::HOOK );
		}
	}

	/* ---------- matching ---------- */

	private static function norm( $t ) {
		$t = mb_strtolower( wp_strip_all_tags( (string) $t ), 'UTF-8' );
		$t = preg_replace( '/[^a-z0-9]+/u', ' ', $t );
		return ' ' . trim( (string) $t ) . ' ';
	}

	/** Candidate phrases: Target rows with two or more words; "a / b" rows give both. */
	private static function candidates() {
		static $c = null;
		if ( null !== $c ) {
			return $c;
		}
		$c = array();
		foreach ( MRSH_Keywords::all() as $r ) {
			if ( empty( $r['treatment'] ) || 'Target' !== $r['treatment'] ) {
				continue;
			}
			foreach ( explode( '/', (string) $r['roman'] ) as $p ) {
				$p = trim( preg_replace( '/\s+/', ' ', $p ) );
				$n = trim( self::norm( $p ) );
				if ( '' === $n || false === strpos( $n, ' ' ) ) {
					continue; // a single word is too general to be a page's focus.
				}
				$c[ $n ] = array( 'phrase' => $p, 'words' => count( explode( ' ', $n ) ), 'high' => ! empty( $r['priority'] ) && 'High' === $r['priority'] );
			}
		}
		return $c;
	}

	/** @return array|null array( phrase, score ) */
	public static function best( $post ) {
		$title   = self::norm( get_the_title( $post ) );
		$slug    = self::norm( str_replace( '-', ' ', (string) $post->post_name ) );
		$content = self::norm( mb_substr( wp_strip_all_tags( strip_shortcodes( (string) $post->post_content ) ), 0, 2500 ) );
		$best    = null;
		foreach ( self::candidates() as $n => $c ) {
			$needle = ' ' . $n . ' ';
			$score  = 0;
			if ( false !== strpos( $title, $needle ) ) {
				$score += 10;
			}
			if ( false !== strpos( $slug, $needle ) ) {
				$score += 6;
			}
			if ( $score < 6 ) {
				continue; // the phrase must really be about this page: in its title or its web address.
			}
			$score += min( 3, substr_count( $content, $needle ) ) * 1.5;
			$score *= 1 + 0.2 * ( $c['words'] - 1 );
			if ( $c['high'] ) {
				$score += 2;
			}
			if ( ! $best || $score > $best['score'] ) {
				$best = array( 'phrase' => $c['phrase'], 'score' => round( $score, 1 ) );
			}
		}
		return $best;
	}

	private static function eligible( $post ) {
		if ( ! $post || 'publish' !== $post->post_status || ! in_array( $post->post_type, array( 'page', 'post' ), true ) ) {
			return false;
		}
		$o = MRSH_Options::get();
		return ! ( in_array( $post->post_name, MRSH_Options::to_list( $o['noindex_slugs'] ), true ) || get_post_meta( $post->ID, '_mrsh_noindex', true ) );
	}

	/** Gives one page a phrase unless a person chose one. Returns the phrase or ''. */
	public static function assign( $post ) {
		if ( ! self::eligible( $post ) ) {
			return '';
		}
		if ( get_post_meta( $post->ID, '_mrsh_focus_skip', true ) ) {
			return '';
		}
		$cur = trim( (string) get_post_meta( $post->ID, '_mrsh_focus', true ) );
		if ( '' !== $cur && ! get_post_meta( $post->ID, self::AUTO, true ) ) {
			return $cur; // set by a person: leave it.
		}
		$b = self::best( $post );
		if ( ! $b ) {
			// No phrase from the keyword bank fits: use the page's own title so every page has a focus phrase (3.101.118).
			if ( ! empty( self::settings()['derive'] ) ) {
				$d = self::derive( $post );
				if ( '' !== $d ) {
					if ( $cur !== $d ) {
						update_post_meta( $post->ID, '_mrsh_focus', $d );
					}
					update_post_meta( $post->ID, self::AUTO, 'from title' );
					return $d;
				}
			}
			return $cur;
		}
		if ( $cur !== $b['phrase'] ) {
			update_post_meta( $post->ID, '_mrsh_focus', $b['phrase'] );
		}
		update_post_meta( $post->ID, self::AUTO, $b['score'] );
		return $b['phrase'];
	}

	/** The main words of the page title, without the site name, as a 2 to 4 word phrase. '' when the title gives none. */
	public static function derive( $post ) {
		$t = html_entity_decode( wp_strip_all_tags( get_the_title( $post ) ), ENT_QUOTES, 'UTF-8' );
		$t = trim( (string) preg_split( '/\s[|\x{2013}\x{2014}\-:]\s|[|\x{2013}\x{2014}]/u', $t )[0] );
		$t = preg_replace( '/\b(my\s*rishta(\.pk)?(\s*pakistan)?|myrishta(\.pk)?)\b/iu', ' ', $t );
		preg_match_all( '/[\p{L}\p{N}]+/u', mb_strtolower( $t, 'UTF-8' ), $m );
		$w    = $m[0];
		$stop = array( 'a', 'an', 'the', 'and', 'or', 'of', 'to', 'for', 'in', 'on', 'at', 'is', 'are', 'your', 'our', 'my', 'with', 'by', 'from', 'how', 'what', 'why' );
		while ( $w && in_array( $w[0], $stop, true ) ) {
			array_shift( $w );
		}
		while ( $w && in_array( end( $w ), $stop, true ) ) {
			array_pop( $w );
		}
		if ( count( $w ) < 2 ) {
			return '';
		}
		return implode( ' ', array_slice( $w, 0, 4 ) );
	}

	public static function on_save( $id, $post ) {
		if ( ! empty( self::settings()['enabled'] ) && ! wp_is_post_revision( $id ) && ! wp_is_post_autosave( $id ) ) {
			self::assign( $post );
		}
	}

	public static function run() {
		$q = get_posts( array( 'post_type' => array( 'page', 'post' ), 'post_status' => 'publish', 'posts_per_page' => 400, 'fields' => 'ids', 'suppress_filters' => true ) );
		$set = 0;
		$none = 0;
		foreach ( $q as $id ) {
			$p = get_post( $id );
			$had = get_post_meta( $id, '_mrsh_focus', true );
			$now = self::assign( $p );
			if ( '' !== $now && $now !== $had ) {
				$set++;
			} elseif ( '' === $now ) {
				$none++;
			}
		}
		$s             = self::settings();
		$s['last']     = time();
		$s['last_msg'] = $set . ' phrases set, ' . $none . ' pages with no matching phrase (left as they are).';
		update_option( self::OPT, $s, false );
		return $s['last_msg'];
	}

	/** Adds the phrase to an automatically written description when it is missing and there is room. */
	public static function tune_desc( $desc, $post_id ) {
		$s = self::settings();
		if ( empty( $s['enabled'] ) || empty( $s['desc'] ) || ! $post_id || '' !== (string) get_post_meta( $post_id, '_mrsh_desc', true ) ) {
			return $desc;
		}
		$f = trim( (string) get_post_meta( $post_id, '_mrsh_focus', true ) );
		if ( '' === $f || false !== mb_stripos( $desc, $f ) ) {
			return $desc;
		}
		$add = ' Read about ' . $f . ' on My Rishta Pakistan.';
		return mb_strlen( $desc . $add ) <= 160 ? rtrim( $desc ) . $add : $desc;
	}

	/* ---------- admin ---------- */

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Auto keywords', 'Auto keywords', 'manage_options', 'mrsh-autokw', array( __CLASS__, 'page' ) );
	}

	private static function back( $m ) {
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-autokw&msg=' . rawurlencode( $m ) ) );
		exit;
	}

	private static function guard( $n ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( $n );
	}

	public static function act_save() {
		self::guard( 'mrsh_autokw_save' );
		$s            = self::settings();
		$s['enabled'] = empty( $_POST['enabled'] ) ? 0 : 1;
		$s['desc']    = empty( $_POST['desc'] ) ? 0 : 1;
		$s['derive']  = empty( $_POST['derive'] ) ? 0 : 1;
		update_option( self::OPT, $s, false );
		self::arm();
		self::back( 'Saved.' );
	}

	public static function act_run() {
		self::guard( 'mrsh_autokw_run' );
		self::back( self::run() );
	}

	/** Removes only the phrases this tool chose. Phrases you typed stay. */
	public static function act_gscan() {
		self::guard( 'mrsh_autokw_gscan' );
		$m = class_exists( 'MRSH_Discovery' ) ? MRSH_Discovery::google_scan( 40 ) : 'Not available.';
		self::back( $m );
	}

	public static function act_undo() {
		self::guard( 'mrsh_autokw_undo' );
		$ids = get_posts( array( 'post_type' => array( 'page', 'post' ), 'post_status' => 'any', 'posts_per_page' => -1, 'fields' => 'ids', 'meta_key' => self::AUTO ) );
		foreach ( $ids as $id ) {
			delete_post_meta( $id, '_mrsh_focus' );
			delete_post_meta( $id, self::AUTO );
		}
		self::back( count( $ids ) . ' automatic phrases removed. Phrases you typed yourself were not touched.' );
	}

	public static function act_clear() {
		self::guard( 'mrsh_autokw_clear' );
		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		if ( $id && get_post_meta( $id, self::AUTO, true ) ) {
			delete_post_meta( $id, '_mrsh_focus' );
			delete_post_meta( $id, self::AUTO );
			update_post_meta( $id, '_mrsh_focus_skip', 1 );
		}
		self::back( 'Phrase removed for that page.' );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s  = self::settings();
		$ap = esc_url( admin_url( 'admin-post.php' ) );
		echo '<div class="wrap"><h1>Auto keywords</h1>';
		if ( isset( $_GET['msg'] ) ) {
			echo '<div class="notice notice-info"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['msg'] ) ) ) . '</p></div>';
		}
		echo '<p>Each page gets the best-fitting phrase from your keyword bank, automatically, once a day and whenever a page is saved. A phrase is only chosen when it really appears in the page title or web address. Phrases you type yourself are never changed.</p>';
		echo '<form method="post" action="' . $ap . '"><input type="hidden" name="action" value="mrsh_autokw_save">';
		wp_nonce_field( 'mrsh_autokw_save' );
		echo '<p><label><input type="checkbox" name="enabled" value="1"' . checked( $s['enabled'], 1, false ) . '> Choose phrases automatically</label></p>';
		echo '<p><label><input type="checkbox" name="desc" value="1"' . checked( $s['desc'], 1, false ) . '> Also add the phrase to the search-result description when it is missing and there is room (only for descriptions the plugin writes itself)</label></p>';
		echo '<p><label><input type="checkbox" name="derive" value="1"' . checked( $s['derive'], 1, false ) . '> When no phrase from the keyword bank fits a page, use the main words of the page title, so every page has a focus phrase</label></p>';
		echo '<p><button class="button button-primary">Save</button></p></form>';
		echo '<form method="post" action="' . $ap . '" style="display:inline-block;margin-right:12px"><input type="hidden" name="action" value="mrsh_autokw_run">';
		wp_nonce_field( 'mrsh_autokw_run' );
		echo '<button class="button button-primary">Run now</button></form>';
		echo '<form method="post" action="' . $ap . '" style="display:inline-block"><input type="hidden" name="action" value="mrsh_autokw_undo">';
		wp_nonce_field( 'mrsh_autokw_undo' );
		echo '<button class="button" onclick="return confirm(\'Remove all automatic phrases? Phrases you typed stay.\')">Undo all automatic phrases</button></form>';
		if ( class_exists( 'MRSH_Discovery' ) ) {
			$g = MRSH_Discovery::google_state();
			echo '<div style="background:#fff;border:1px solid #e5d9c4;border-radius:14px;padding:14px 16px;margin:16px 0"><b>Google phrase scan</b><p style="margin:6px 0">Reads Google\'s free search suggestions for rishta words (cities, Gulf countries, Urdu and Roman Urdu) and adds suitable new phrases to the keyword bank. Phrases with phone numbers, adult words or prices are never added. New phrases are applied to matching pages automatically. It runs once a day while the Autopilot keyword robot is ON.</p>';
			echo '<p style="margin:6px 0">' . ( $g['last'] ? 'Last scan: ' . esc_html( wp_date( 'j M Y H:i', $g['last'] ) ) . '. ' . esc_html( $g['msg'] ) . ' Total added so far: <b>' . (int) $g['total'] . '</b>.' : 'Not run yet.' ) . '</p>';
			if ( ! empty( $g['recent'] ) ) {
				echo '<p style="margin:6px 0;color:#555">Newest: ' . esc_html( implode( ' · ', array_slice( (array) $g['recent'], 0, 12 ) ) ) . '</p>';
			}
			echo '<form method="post" action="' . $ap . '"><input type="hidden" name="action" value="mrsh_autokw_gscan">';
			wp_nonce_field( 'mrsh_autokw_gscan' );
			echo '<button class="button button-primary">Scan Google now</button></form></div>';
		}
		if ( $s['last'] ) {
			echo '<p>Last run: ' . esc_html( wp_date( 'j M Y H:i', $s['last'] ) ) . '. ' . esc_html( $s['last_msg'] ) . '</p>';
		}
		$ids = get_posts( array( 'post_type' => array( 'page', 'post' ), 'post_status' => 'publish', 'posts_per_page' => 500, 'fields' => 'ids', 'meta_key' => self::AUTO, 'orderby' => 'title', 'order' => 'ASC' ) );
		echo '<h2>Pages with an automatic phrase (' . count( $ids ) . ')</h2>';
		if ( $ids ) {
			echo '<table class="widefat striped"><thead><tr><th>Page</th><th>Phrase</th><th>Fit</th><th></th></tr></thead><tbody>';
			foreach ( $ids as $id ) {
				echo '<tr><td><a href="' . esc_url( get_permalink( $id ) ) . '" target="_blank" rel="noopener">' . esc_html( get_the_title( $id ) ) . '</a></td><td>' . esc_html( (string) get_post_meta( $id, '_mrsh_focus', true ) ) . '</td><td>' . esc_html( (string) get_post_meta( $id, self::AUTO, true ) ) . '</td><td>';
				echo '<form method="post" action="' . $ap . '" style="display:inline"><input type="hidden" name="action" value="mrsh_autokw_clear"><input type="hidden" name="id" value="' . (int) $id . '">';
				wp_nonce_field( 'mrsh_autokw_clear' );
				echo '<button class="button button-small">Remove</button></form></td></tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';
	}
}
