<?php
/**
 * Table kit: every list table on a plugin screen gets search, column filters, an
 * "Needs attention" switch, sorting, paging, CSV export and "copy emails".
 * Pure browser code, nothing is stored, nothing to configure.
 * A red tab badge links with &attn=1 so the table opens already filtered to what is waiting.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_TableKit {

	public static function init() {
		add_action( 'admin_footer', array( __CLASS__, 'print_kit' ), 99 );
	}

	private static function ours() {
		$p = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore
		if ( '' === $p ) {
			return false;
		}
		if ( 0 === strpos( $p, 'mrsh' ) || 0 === strpos( $p, 'myrishta' ) || 'mrmb' === $p || 'mrads-check' === $p ) {
			return true;
		}
		return false;
	}

	public static function print_kit() {
		if ( ! current_user_can( 'manage_options' ) || ! self::ours() ) {
			return;
		}
		echo '<style>' . self::css() . '</style><script>' . self::js() . '</script>'; // phpcs:ignore
	}

	public static function css() {
		return '.mtk{--p:#7c3aed;--pl:#f5f3ff;--bd:#e5e7eb;--tx:#111827;--mu:#6b7280;display:flex;flex-direction:column;gap:12px;margin:12px 0 10px;padding:14px;background:linear-gradient(180deg,#fff,#fafafa);border:1px solid var(--bd);border-radius:18px;box-shadow:0 1px 2px rgba(17,24,39,.04),0 8px 24px -12px rgba(17,24,39,.12)}
.mtk-r{display:flex;flex-wrap:wrap;gap:10px;align-items:center}
.mtk-sw{position:relative;flex:1 1 260px;max-width:420px}
.mtk-sw svg{position:absolute;left:13px;top:50%;transform:translateY(-50%);width:17px;height:17px;stroke:var(--mu);fill:none;stroke-width:2;pointer-events:none}
.mtk input[type=search]{width:100%;height:42px;border:1px solid var(--bd);border-radius:999px;padding:0 16px 0 40px;background:#fff;font-size:14px;color:var(--tx);box-shadow:none;transition:.15s}
.mtk input[type=search]:focus{border-color:var(--p);box-shadow:0 0 0 4px rgba(124,58,237,.14);outline:0}
.mtk-seg{display:inline-flex;background:#f3f4f6;border-radius:999px;padding:4px;gap:2px}
.mtk-seg button{border:0;background:transparent;border-radius:999px;height:34px;padding:0 16px;font-size:13px;font-weight:600;color:var(--mu);cursor:pointer;display:inline-flex;align-items:center;gap:7px;transition:.15s}
.mtk-seg button.on{background:#fff;color:var(--tx);box-shadow:0 1px 3px rgba(17,24,39,.14)}
.mtk-seg button.red.on{background:#dc2626;color:#fff}
.mtk-seg b{font-size:11px;background:#fee2e2;color:#b91c1c;border-radius:999px;padding:1px 8px}
.mtk-seg .on b{background:rgba(255,255,255,.25);color:inherit}
.mtk-ic{width:42px;height:42px;border-radius:999px;border:1px solid var(--bd);background:#fff;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;transition:.15s;padding:0}
.mtk-ic:hover{border-color:var(--p);background:var(--pl)}
.mtk-ic svg{width:18px;height:18px;stroke:#374151;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.mtk-g{display:flex;flex-wrap:wrap;gap:6px;align-items:center}
.mtk-g>i{font-style:normal;font-size:11px;letter-spacing:.06em;text-transform:uppercase;color:var(--mu);margin-right:4px;font-weight:600}
.mtk-c{border:1px solid var(--bd);background:#fff;border-radius:999px;height:32px;padding:0 13px;font-size:13px;color:#374151;cursor:pointer;transition:.15s;display:inline-flex;align-items:center;gap:6px}
.mtk-c:hover{border-color:var(--p)}
.mtk-c.on{background:var(--p);border-color:var(--p);color:#fff}
.mtk-c small{opacity:.65;font-size:11px}
.mtk select{height:36px;border:1px solid var(--bd);border-radius:999px;padding:0 30px 0 14px;background-color:#fff;font-size:13px;max-width:210px;color:#374151}
.mtk-n{margin-left:auto;font-size:12px;font-weight:600;color:var(--p);background:var(--pl);border-radius:999px;padding:6px 12px;white-space:nowrap}
.mtk-pg{display:flex;gap:10px;align-items:center;justify-content:center;margin:12px 0;font-size:13px;color:#4b5563;flex-wrap:wrap}
.mtk-pg button{height:36px;border:1px solid #e5e7eb;background:#fff;border-radius:999px;padding:0 16px;cursor:pointer;font-weight:600}
.mtk-pg button:hover:not([disabled]){border-color:#7c3aed;background:#f5f3ff}
.mtk-pg button[disabled]{opacity:.4;cursor:default}
table.mtk-t{border:1px solid #e5e7eb!important;border-radius:16px;border-collapse:separate!important;border-spacing:0;overflow:hidden;box-shadow:0 1px 2px rgba(17,24,39,.04)}
table.mtk-t thead th{background:#f9fafb!important;font-size:11px!important;letter-spacing:.06em;text-transform:uppercase;color:#6b7280!important;font-weight:700!important;padding:13px 14px!important;border-bottom:1px solid #e5e7eb!important;white-space:nowrap}
table.mtk-t thead th.mtk-s{cursor:pointer;user-select:none}
table.mtk-t thead th.mtk-s:hover{color:#7c3aed!important}
table.mtk-t thead th.mtk-s:after{content:"\2195";opacity:.35;margin-left:6px}
table.mtk-t thead th.mtk-asc:after{content:"\2191";opacity:1;color:#7c3aed}
table.mtk-t thead th.mtk-desc:after{content:"\2193";opacity:1;color:#7c3aed}
table.mtk-t tbody td{padding:13px 14px!important;border-bottom:1px solid #f3f4f6;vertical-align:middle}
table.mtk-t tbody tr:last-child td{border-bottom:0}
table.mtk-t tbody tr:hover td{background:#faf5ff!important}
table.mtk-t.striped>tbody>tr:nth-child(odd)>td,table.mtk-t.striped>tbody>tr:nth-child(odd)>th{background:#fff}
table.mtk-t tr.mtk-hit>:first-child{box-shadow:inset 4px 0 0 #dc2626}
.mtk-pill{display:inline-flex;align-items:center;gap:6px;border-radius:999px;padding:3px 11px;font-size:12px;font-weight:600;background:#f3f4f6;color:#374151}
.mtk-pill:before{content:"";width:7px;height:7px;border-radius:50%;background:#9ca3af}
.mtk-pill.r{background:#fef2f2;color:#b91c1c}.mtk-pill.r:before{background:#dc2626}
.mtk-pill.g{background:#ecfdf5;color:#047857}.mtk-pill.g:before{background:#10b981}
.mtk-pill.a{background:#fffbeb;color:#b45309}.mtk-pill.a:before{background:#f59e0b}
.mtk-empty{padding:34px;text-align:center;color:#6b7280;background:#fff;border:1px dashed #d1d5db;border-radius:16px}
table.mtk-t.mtk-selmode tbody tr{cursor:pointer}
table.mtk-t tbody tr.mtk-sel td{background:#ede9fe!important}
.mtk-bulk{display:none;align-items:center;gap:8px;flex-wrap:wrap;padding:10px 14px;background:#4c1d95;color:#fff;border-radius:14px}
.mtk-bulk.on{display:flex}
.mtk-bulk b{margin-right:6px}
.mtk-bulk button{border:0;background:rgba(255,255,255,.16);color:#fff;border-radius:999px;height:32px;padding:0 14px;cursor:pointer;font-weight:600;font-size:13px}
.mtk-bulk button:hover{background:rgba(255,255,255,.3)}
.mtk-views{display:flex;flex-wrap:wrap;gap:6px;align-items:center}
.mtk-views>i{font-style:normal;font-size:11px;letter-spacing:.06em;text-transform:uppercase;color:#6b7280;font-weight:600;margin-right:4px}
.mtk-v{border:1px dashed #c4b5fd;background:#faf5ff;color:#5b21b6;border-radius:999px;height:30px;padding:0 6px 0 13px;font-size:13px;cursor:pointer;display:inline-flex;align-items:center;gap:6px}
.mtk-v u{text-decoration:none;opacity:.55;padding:0 6px;font-size:15px}
.mtk-v u:hover{opacity:1}
@media(max-width:782px){.mtk-sw{max-width:none;flex-basis:100%}.mtk-n{margin-left:0}table.mtk-t{display:block;overflow-x:auto}}';
	}

	public static function js() {
		return <<<'JS'
(function(){
var ATT=/\b(pending|failed|fail|open|overdue|late|flagged|flag|waiting|unread|new|error|spam|abuse|abusive|scam|blocked|rejected|unverified|expired|problem|needs?)\b/i;
var qs=new URLSearchParams(location.search);
var tables=[].slice.call(document.querySelectorAll('#wpbody-content table'));
var first=true;
tables.forEach(function(t){
 if(t.classList.contains('form-table')||t.closest('.mtk-skip')||t.dataset.mtk==='off'||t.querySelector('table')||t.closest('table')!==t||t.classList.contains('mtk-t'))return;
 var tb=t.tBodies[0];if(!tb)return;
 var rows=[].slice.call(tb.rows).filter(function(r){return r.cells.length>1});
 if(rows.length<3)return;
 var head=t.tHead&&t.tHead.rows[0]?[].slice.call(t.tHead.rows[0].cells):[];
 var nc=head.length;
 function txt(c){return (c.textContent||'').replace(/\s+/g,' ').trim()}
 rows.forEach(function(r){
  r._s=[].slice.call(r.cells).map(txt).join(' | ');r._t=r._s.toLowerCase();
  var red=r.querySelector('.mrt-n,.is-bad,.bad,.mx-red,[style*="#dc2626"],[style*="#b91c1c"],[style*="color:red"]');
  r._a=(r.dataset.attn==='0'||r.dataset.attn==='1')?r.dataset.attn==='1':(!!red||ATT.test(r._s));
 });
 var attN=rows.filter(function(r){return r._a}).length;
 var I={s:'<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>',d:'<svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/></svg>',c:'<svg viewBox="0 0 24 24"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>',r:'<svg viewBox="0 0 24 24"><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/></svg>'};
 function mk(tag,cls,html){var e=document.createElement(tag);if(cls)e.className=cls;if(html)e.innerHTML=html;return e}
 var bar=mk('div','mtk'),r1=mk('div','mtk-r');bar.appendChild(r1);
 var sw=mk('div','mtk-sw',I.s);var q=document.createElement('input');q.type='search';q.placeholder='Search anything in this table…  ( / )';q.setAttribute('aria-label','Search this table');sw.appendChild(q);r1.appendChild(sw);
 var seg=mk('div','mtk-seg'),bAll=mk('button','on','All <b style="background:#e5e7eb;color:#374151">'+rows.length+'</b>'),att=null;bAll.type='button';seg.appendChild(bAll);
 if(attN>0){att=mk('button','red','Needs attention <b>'+attN+'</b>');att.type='button';seg.appendChild(att)}
 r1.appendChild(seg);
 var csv=mk('button','mtk-ic',I.d);csv.type='button';csv.title='Export filtered rows as CSV';csv.setAttribute('aria-label','Export CSV');r1.appendChild(csv);
 var hasMail=rows.some(function(r){return /[\w.+-]+@[\w-]+\.[\w.]+/.test(r._s)});
 var cm=null;if(hasMail){cm=mk('button','mtk-ic',I.c);cm.type='button';cm.title='Copy emails of filtered rows';cm.setAttribute('aria-label','Copy emails');r1.appendChild(cm)}
 var rs=mk('button','mtk-ic',I.r);rs.type='button';rs.title='Reset filters';rs.setAttribute('aria-label','Reset');r1.appendChild(rs);
 var selb=mk('button','mtk-ic','<svg viewBox="0 0 24 24"><path d="m9 11 3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>');selb.type='button';selb.title='Select rows (then copy emails, export, and more)';selb.setAttribute('aria-label','Select rows');r1.appendChild(selb);
 var svb=mk('button','mtk-ic','<svg viewBox="0 0 24 24"><path d="m19 21-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>');svb.type='button';svb.title='Save this filter as a quick button';svb.setAttribute('aria-label','Save view');r1.appendChild(svb);
 var cnt=mk('span','mtk-n');r1.appendChild(cnt);
 var flt=[],sels=[];
 head.forEach(function(h,j){
  var label=txt(h);if(!label||h.querySelector('input'))return;
  var m={};rows.forEach(function(r){var c=r.cells[j];if(!c)return;var v=txt(c);if(v&&v.length<=40)m[v]=(m[v]||0)+1});
  var k=Object.keys(m);if(k.length<2||k.length>30)return;
  if(rows.filter(function(r){var c=r.cells[j];return c&&txt(c).length>40}).length>rows.length/3)return;
  k.sort(function(a,b){return m[b]-m[a]});
  var f={j:j,val:''};flt.push(f);
  if(k.length<=7){
   var g=mk('div','mtk-g','<i>'+label.replace(/</g,'')+'</i>'),chips=[];
   var all=mk('button','mtk-c on','All');all.type='button';g.appendChild(all);chips.push(all);
   all.onclick=function(){f.val='';chips.forEach(function(x){x.classList.toggle('on',x===all)});st.p=0;draw()};
   k.forEach(function(v){var c=mk('button','mtk-c');c.type='button';c.textContent=v;var sm=mk('small');sm.textContent=m[v];c.appendChild(sm);
    c.onclick=function(){f.val=(f.val===v)?'':v;chips.forEach(function(x){x.classList.toggle('on',f.val===''?x===all:x===c)});st.p=0;draw()};g.appendChild(c);chips.push(c)});
   f.reset=function(){f.val='';chips.forEach(function(x){x.classList.toggle('on',x===all)})};f.set=function(v){f.val=v;chips.forEach(function(x){var sm=x.querySelector('small');var tx=x.firstChild?x.firstChild.textContent:'';x.classList.toggle('on',tx===v)})};
   bar.appendChild(g);
  }else{
   var s=document.createElement('select');s.setAttribute('aria-label','Filter '+label);
   var o=document.createElement('option');o.value='';o.textContent='All: '+label;s.appendChild(o);
   k.sort().forEach(function(v){var x=document.createElement('option');x.value=v;x.textContent=v+' ('+m[v]+')';s.appendChild(x)});
   s.onchange=function(){f.val=s.value;st.p=0;draw()};f.reset=function(){f.val='';s.value=''};f.set=function(v){f.val=v;s.value=v};
   r1.insertBefore(s,cnt);
  }
 });
 var size=document.createElement('select');size.setAttribute('aria-label','Rows per page');
 [25,50,100,250,0].forEach(function(n){var o=document.createElement('option');o.value=n;o.textContent=n?n+' per page':'Show all';if(n===50)o.selected=true;size.appendChild(o)});
 r1.insertBefore(size,cnt);
 var views=mk('div','mtk-views');views.style.display='none';bar.appendChild(views);
 var bulk=mk('div','mtk-bulk');bar.appendChild(bulk);
 var host=t.closest('.mx-tbl')||t;host.parentNode.insertBefore(bar,host);
 var pg=mk('div','mtk-pg');host.parentNode.insertBefore(pg,host.nextSibling);
 var emp=mk('div','mtk-empty','Nothing matches these filters.');emp.hidden=true;host.parentNode.insertBefore(emp,pg);
 t.classList.add('mtk-t');
 var PR=/^(failed|error|rejected|spam|overdue|late|blocked|expired|unverified|abusive|flagged|pending|open|waiting|new|unpaid|inactive|declined)$/i,PG=/^(done|ok|approved|verified|paid|active|sent|resolved|closed|success|published|live|completed|delivered|accepted|yes)$/i,PA=/^(progress|in progress|processing|queued|draft|trial|review|on hold|scheduled)$/i;
 var scol=head.map(function(h,j){var v={};rows.forEach(function(r){var c=r.cells[j];if(c&&!c.children.length){var x=txt(c);if(x&&x.length<=18)v[x]=1}});var ks=Object.keys(v);return ks.length>1&&ks.length<=8&&ks.every(function(x){return PR.test(x)||PG.test(x)||PA.test(x)||ks.length<=5&&/^[A-Za-z ]+$/.test(x)})});
 scol.forEach(function(ok,j){if(!ok)return;rows.forEach(function(r){var c=r.cells[j];if(!c||c.children.length)return;var x=txt(c);if(!x||x.length>18)return;var sp=mk('span','mtk-pill'+(PR.test(x)?' r':PG.test(x)?' g':PA.test(x)?' a':''));sp.textContent=x;c.textContent='';c.appendChild(sp)})});
 var st={a:false,p:0,sortj:-1,dir:1};
 function vis(){
  var qq=q.value.trim().toLowerCase();
  return rows.filter(function(r){
   if(st.a&&!r._a)return false;
   if(qq&&r._t.indexOf(qq)<0)return false;
   for(var i=0;i<flt.length;i++){if(flt[i].val){var c=r.cells[flt[i].j];if(!c||txt(c)!==flt[i].val)return false}}
   return true;
  });
 }
 function draw(){
  var v=vis(),n=parseInt(size.value,10)||0,pages=n?Math.max(1,Math.ceil(v.length/n)):1;
  if(st.p>=pages)st.p=pages-1;if(st.p<0)st.p=0;
  var from=n?st.p*n:0,to=n?from+n:v.length,show=v.slice(from,to);
  var set={};show.forEach(function(r){set[rows.indexOf(r)]=1});
  rows.forEach(function(r,i){r.style.display=set[i]?'':'none';r.classList.toggle('mtk-hit',r._a&&attN<rows.length)});
  bAll.classList.toggle('on',!st.a);if(att)att.classList.toggle('on',st.a);
  cnt.textContent=v.length===rows.length?rows.length+' rows':v.length+' of '+rows.length;
  emp.hidden=v.length>0;
  pg.innerHTML='';
  if(n&&pages>1){
   var pv=mk('button');pv.type='button';pv.textContent='Previous';pv.disabled=st.p===0;pv.onclick=function(){st.p--;draw()};
   var nx=mk('button');nx.type='button';nx.textContent='Next';nx.disabled=st.p>=pages-1;nx.onclick=function(){st.p++;draw()};
   var lb=mk('span');lb.textContent='Page '+(st.p+1)+' of '+pages;
   pg.appendChild(pv);pg.appendChild(lb);pg.appendChild(nx);
  }
 }
 function reset(){q.value='';flt.forEach(function(f){f.reset&&f.reset()});st.a=false;st.p=0;draw()}
 q.addEventListener('input',function(){st.p=0;draw()});
 size.addEventListener('change',function(){st.p=0;draw()});
 bAll.addEventListener('click',function(){st.a=false;st.p=0;draw()});
 if(att)att.addEventListener('click',function(){st.a=true;st.p=0;draw()});
 rs.addEventListener('click',reset);
 csv.addEventListener('click',function(){
  var v=vis(),out=[];
  out.push(head.map(function(h){return txt(h)}).join('\t'));
  v.forEach(function(r){out.push([].slice.call(r.cells).map(function(c){return txt(c)}).join('\t'))});
  var rowsCsv=out.map(function(l){return l.split('\t').map(function(x){return '"'+x.replace(/"/g,'""')+'"'}).join(',')}).join('\r\n');
  var b=new Blob(['﻿'+rowsCsv],{type:'text/csv'});var a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='myrishta-table.csv';document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove()},500);
 });
 if(cm)cm.addEventListener('click',function(){
  var seen={},list=[];vis().forEach(function(r){(r._s.match(/[\w.+-]+@[\w-]+\.[\w.]+/g)||[]).forEach(function(e){e=e.toLowerCase();if(!seen[e]){seen[e]=1;list.push(e)}})});
  var s=list.join(', ');
  function done(){cm.textContent='Copied '+list.length;setTimeout(function(){cm.textContent='Copy emails'},1800)}
  if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(s).then(done,function(){window.prompt('Copy:',s)})}else{window.prompt('Copy:',s)}
 });
 head.forEach(function(h,j){
  if(h.querySelector('input')||!txt(h))return;
  h.classList.add('mtk-s');
  h.addEventListener('click',function(e){
   if(e.target.closest('a'))return;
   st.dir=(st.sortj===j)?-st.dir:1;st.sortj=j;
   head.forEach(function(x){x.classList.remove('mtk-asc','mtk-desc')});
   h.classList.add(st.dir>0?'mtk-asc':'mtk-desc');
   var num=rows.every(function(r){var c=r.cells[j];var v=c?txt(c).replace(/[,%\s]/g,''):'';return v===''||!isNaN(parseFloat(v))&&isFinite(v)});
   var sorted=rows.slice().sort(function(a,b){
    var x=a.cells[j]?txt(a.cells[j]):'',y=b.cells[j]?txt(b.cells[j]):'';
    if(num){x=parseFloat(x.replace(/[,%\s]/g,''))||0;y=parseFloat(y.replace(/[,%\s]/g,''))||0;return (x-y)*st.dir}
    return x.localeCompare(y,undefined,{numeric:true,sensitivity:'base'})*st.dir});
   sorted.forEach(function(r){tb.appendChild(r)});
   rows=sorted;st.p=0;draw();
  });
 });
 var pageKey='mtk:'+(qs.get('page')||'x')+':'+tables.indexOf(t),selOn=false;
 function selRows(){return rows.filter(function(r){return r.classList.contains('mtk-sel')})}
 function bulkDraw(){var n=selRows().length;bulk.classList.toggle('on',selOn);if(!selOn)return;bulk.innerHTML='';var b=mk('b');b.textContent=n+' selected';bulk.appendChild(b);
  function btn(l,f){var x=mk('button');x.type='button';x.textContent=l;x.onclick=f;bulk.appendChild(x)}
  btn('Select all filtered',function(){vis().forEach(function(r){r.classList.add('mtk-sel')});bulkDraw()});
  btn('Clear',function(){rows.forEach(function(r){r.classList.remove('mtk-sel')});bulkDraw()});
  if(hasMail)btn('Copy emails',function(){var seen={},l=[];selRows().forEach(function(r){(r._s.match(/[\w.+-]+@[\w-]+\.[\w.]+/g)||[]).forEach(function(e){e=e.toLowerCase();if(!seen[e]){seen[e]=1;l.push(e)}})});copy(l.join(', '),l.length+' emails')});
  btn('Copy phone numbers',function(){var seen={},l=[];selRows().forEach(function(r){(r._s.match(/(?:\+?92|0)?3\d{2}[\s-]?\d{7}/g)||[]).forEach(function(x){x=x.replace(/\D/g,'');if(!seen[x]){seen[x]=1;l.push(x)}})});copy(l.join('\n'),l.length+' numbers')});
  btn('Export selected',function(){var out=[head.map(function(h){return txt(h)})];selRows().forEach(function(r){out.push([].slice.call(r.cells).map(txt))});dl(out)});
  btn('Open links',function(){selRows().forEach(function(r){var a=r.querySelector('a[href]');if(a)window.open(a.href,'_blank')})});
 }
 function copy(s,l){if(!s){alert('Nothing to copy in the selected rows.');return}if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(s).then(function(){flash('Copied '+l)},function(){window.prompt('Copy:',s)})}else window.prompt('Copy:',s)}
 function flash(m){cnt.textContent=m;setTimeout(draw,1800)}
 function dl(out){var c=out.map(function(l){return l.map(function(x){return '"'+String(x).replace(/"/g,'""')+'"'}).join(',')}).join('\r\n');var b=new Blob(['﻿'+c],{type:'text/csv'});var a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='myrishta-selected.csv';document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove()},500)}
 selb.addEventListener('click',function(){selOn=!selOn;t.classList.toggle('mtk-selmode',selOn);if(!selOn)rows.forEach(function(r){r.classList.remove('mtk-sel')});bulkDraw()});
 tb.addEventListener('click',function(e){if(!selOn)return;if(e.target.closest('a,button,input,select,textarea,label'))return;var r=e.target.closest('tr');if(r&&rows.indexOf(r)>-1){r.classList.toggle('mtk-sel');bulkDraw()}});
 function lsGet(){try{return JSON.parse(localStorage.getItem(pageKey)||'[]')}catch(x){return[]}}
 function lsSet(v){try{localStorage.setItem(pageKey,JSON.stringify(v))}catch(x){}}
 function drawViews(){var v=lsGet();views.innerHTML='';views.style.display=v.length?'flex':'none';if(!v.length)return;views.appendChild(mk('i','','Saved views'));
  v.forEach(function(w,i){var c=mk('span','mtk-v');var l=mk('span');l.textContent=w.n;c.appendChild(l);var x=mk('u');x.textContent='×';x.title='Remove this view';c.appendChild(x);
   l.onclick=function(){q.value=w.q||'';st.a=!!w.a;flt.forEach(function(f){f.reset&&f.reset();var m=(w.f||[]).filter(function(y){return y.j===f.j})[0];if(m&&f.set)f.set(m.val)});st.p=0;draw()};
   x.onclick=function(e){e.stopPropagation();var a=lsGet();a.splice(i,1);lsSet(a);drawViews()};views.appendChild(c)})}
 svb.addEventListener('click',function(){var n=window.prompt('Name this view (for example: Pending gold members)','');if(!n)return;var a=lsGet();a.push({n:n.slice(0,30),q:q.value,a:st.a,f:flt.filter(function(f){return f.val}).map(function(f){return{j:f.j,val:f.val}})});lsSet(a);drawViews()});
 drawViews();
 if(first){
  first=false;
  if(qs.get('q')){q.value=qs.get('q')}
  if(qs.get('attn')==='1'&&att){st.a=true}
  var gk=0;document.addEventListener('keydown',function(e){
   if(/^(INPUT|TEXTAREA|SELECT)$/.test((e.target.tagName||''))||e.target.isContentEditable||e.ctrlKey||e.metaKey||e.altKey)return;
   if(gk&&Date.now()-gk<1200){var M={i:'mrsh-inbox',t:'mrsh-tickets',m:'mrsh-desk',d:'myrishta-seo',n:'mrsh-today',s:'mrsh-shield'};if(M[e.key]){e.preventDefault();location.href=location.pathname.replace(/[^\/]*$/,'')+'admin.php?page='+M[e.key]+'&attn=1'}gk=0;return}
   if(e.key==='g'){gk=Date.now();return}
   if(e.key==='/'&&!/^(INPUT|TEXTAREA|SELECT)$/.test((e.target.tagName||''))&&!e.target.isContentEditable){e.preventDefault();q.focus();q.select()}
  });
 }
 draw();
});
})();
JS;
	}
}
MRSH_TableKit::init();
