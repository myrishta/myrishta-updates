<?php
/**
 * One plugin for everything: the SEO helper, the phone app (/app/) and the ads/app-promotion module.
 * The app and ads code live in modules/. They load only when the separate "My Rishta App" / "MyRishta Ads" plugins are not
 * already running, so nothing is declared twice. On a fresh install you only need this one plugin.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( ! defined( 'MRAPP_VERSION' ) && ! function_exists( 'mrapp_serve' ) ) {
	MRSH_Safe::load( 'modules/app/myrishta-app.php' );
}
if ( ! class_exists( 'MRADS', false ) ) {
	MRSH_Safe::load( 'modules/ads/myrishta-ads.php' );
}
if ( ! class_exists( 'MRSH_Core', false ) ) {
	MRSH_Safe::load( 'modules/core/class-core.php' );
}
if ( ! class_exists( 'MRSH_Keys', false ) ) {
	MRSH_Safe::load( 'modules/core/class-keys.php' );
	MRSH_Safe::load( 'modules/core/class-captcha.php' );
}
MRSH_Safe::load( 'modules/members/class-members.php' );
MRSH_Safe::load( 'modules/members/class-match.php' );
MRSH_Safe::load( 'modules/members/class-extras.php' );
MRSH_Safe::load( 'modules/members/class-mail.php' );
MRSH_Safe::load( 'modules/members/class-feat.php' );
MRSH_Safe::load( 'modules/members/class-secrets.php' );
MRSH_Safe::load( 'modules/members/class-pages.php' );
MRSH_Safe::load( 'modules/members/class-harden.php' );
MRSH_Safe::load( 'modules/members/class-photos.php' );
MRSH_Safe::load( 'modules/members/class-photobackup.php' );
MRSH_Safe::load( 'modules/members/class-mobile.php' );
MRSH_Safe::load( 'modules/members/class-autoads-more.php' );
MRSH_Safe::load( 'modules/members/class-prostyle.php' );
MRSH_Safe::load( 'modules/members/class-queue.php' );
MRSH_Safe::load( 'modules/members/class-autoads.php' );
MRSH_Safe::load( 'modules/members/class-photodiag.php' );
MRSH_Safe::load( 'modules/members/class-boost.php' );
MRSH_Safe::load( 'modules/members/class-desk.php' );
MRSH_Safe::load( 'modules/members/class-noprofile.php' );
MRSH_Safe::load( 'modules/members/class-tickets.php' );
MRSH_Safe::load( 'modules/members/class-attn.php' );
MRSH_Safe::load( 'modules/members/class-actlog.php' );
MRSH_Safe::load( 'modules/members/class-master.php' );
MRSH_Safe::load( 'modules/members/class-switch.php' );
MRSH_Safe::load( 'modules/members/class-delacct.php' );
MRSH_Safe::load( 'modules/members/class-guard.php' );
MRSH_Safe::load( 'modules/members/class-shield.php' );
MRSH_Safe::load( 'modules/members/class-emtpl.php' );
MRSH_Safe::load( 'modules/members/class-import.php' );
MRSH_Safe::load( 'modules/members/class-themeopts.php' );
MRSH_Safe::load( 'modules/members/class-polish.php' );
MRSH_Safe::load( 'modules/members/class-growth.php' );
MRSH_Safe::load( 'modules/members/class-more.php' );
MRSH_Safe::load( 'modules/members/class-integr.php' );
MRSH_Safe::load( 'modules/members/class-more2.php' );
MRSH_Safe::load( 'modules/members/class-more3.php' );
MRSH_Safe::load( 'modules/members/class-social.php' );
MRSH_Safe::load( 'modules/members/class-photocheck.php' );
MRSH_Safe::load( 'modules/members/class-logokit.php' );
MRSH_Safe::load( 'modules/members/class-agreement.php' );
MRSH_Safe::load( 'modules/members/class-notify.php' );
MRSH_Safe::load( 'modules/members/class-more4.php' );
MRSH_Safe::load( 'modules/members/class-more5.php' );
MRSH_Safe::load( 'modules/members/class-family.php' );
MRSH_Safe::load( 'modules/members/class-gads.php' );
MRSH_Safe::load( 'modules/members/class-adsplan.php' );
MRSH_Safe::load( 'modules/members/class-adstools.php' );
MRSH_Safe::load( 'modules/members/class-gbp.php' );
MRSH_Safe::load( 'modules/members/class-seofix.php' );
MRSH_Safe::load( 'modules/members/class-signprompt.php' );
MRSH_Safe::load( 'modules/members/class-ngo.php' );
MRSH_Safe::load( 'modules/members/class-growthboost.php' );
MRSH_Safe::load( 'modules/members/class-connect.php' );
MRSH_Safe::load( 'modules/members/class-offtopic.php' );
MRSH_Safe::load( 'modules/members/class-names.php' );
MRSH_Safe::load( 'modules/members/class-plans.php' );
MRSH_Safe::load( 'modules/members/class-fresh.php' );
MRSH_Safe::load( 'modules/members/class-pay.php' );
MRSH_Safe::load( 'modules/members/class-guide.php' );
MRSH_Safe::load( 'modules/members/class-ideas.php' );
MRSH_Safe::load( 'modules/members/class-fullbackup.php' );
MRSH_Safe::load( 'modules/members/class-drive.php' );
MRSH_Safe::load( 'modules/members/class-delivery.php' );
MRSH_Safe::load( 'modules/members/class-places.php' );
MRSH_Safe::load( 'modules/members/class-boosters.php' );
MRSH_Safe::load( 'modules/members/class-adscheck.php' );
MRSH_Safe::load( 'modules/members/class-thin.php' );
MRSH_Safe::load( 'modules/members/class-bounce.php' );
MRSH_Safe::load( 'modules/members/class-fixer.php' );
MRSH_Safe::load( 'modules/members/class-aihub.php' );
MRSH_Safe::load( 'modules/members/class-aijobs.php' );
MRSH_Safe::load( 'modules/members/class-concierge.php' );
MRSH_Safe::load( 'modules/members/class-autohelp.php' );
MRSH_Safe::load( 'modules/members/class-keepin.php' );
MRSH_Safe::load( 'modules/members/class-finish.php' );
MRSH_Safe::load( 'modules/members/class-helper.php' );
MRSH_Safe::load( 'modules/members/class-coach.php' );
MRSH_Safe::load( 'modules/members/class-helperadmin.php' );
MRSH_Safe::load( 'modules/members/class-photoguard.php' );
MRSH_Safe::load( 'modules/members/class-community.php' );
MRSH_Safe::load( 'modules/members/class-namefix.php' );
MRSH_Safe::load( 'modules/members/class-orders.php' );
MRSH_Safe::load( 'modules/members/class-maint.php' );
MRSH_Safe::load( 'modules/members/class-cwv.php' );
MRSH_Safe::load( 'modules/members/class-updater.php' );
MRSH_Safe::load( 'modules/members/class-logout.php' );
MRSH_Safe::load( 'modules/members/class-settings.php' );
MRSH_Safe::load( 'modules/members/class-autopilot.php' );
MRSH_Safe::load( 'modules/members/class-landing.php' );
MRSH_Safe::load( 'modules/members/class-adsguard.php' );
MRSH_Safe::load( 'modules/members/class-permban.php' );
MRSH_Safe::load( 'modules/members/class-secbot.php' );
MRSH_Safe::load( 'modules/members/class-robots2.php' );
MRSH_Safe::load( 'modules/members/class-useful.php' );
MRSH_Safe::load( 'modules/members/class-easyform.php' );
MRSH_Safe::load( 'modules/members/class-lite.php' );
MRSH_Safe::load( 'modules/members/class-agentready.php' );
MRSH_Safe::load( 'modules/members/class-searchdash.php' );
MRSH_Safe::load( 'modules/members/class-storyhelper.php' );
MRSH_Safe::load( 'modules/members/class-chat.php' );
MRSH_Safe::load( 'modules/members/class-push.php' );
MRSH_Safe::load( 'modules/members/class-manage.php' );
MRSH_Safe::load( 'modules/members/class-site.php' );
MRSH_Safe::load( 'modules/members/class-tabs.php' );
MRSH_Safe::load( 'modules/members/class-menu.php' );
