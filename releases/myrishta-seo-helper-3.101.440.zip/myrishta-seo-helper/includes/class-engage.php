<?php
/**
 * Member engagement: welcome email, heavy-viewer alert to the site owner, and a friendly
 * "your profile was viewed" email to members who have been away for two weeks.
 * Emails are plain text, English and Urdu, and never contain phone numbers.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class MRSH_Engage {
	const CRON  = 'mrsh_engage_daily';
	const TYPE  = 'listing_type';
	const AWAY  = 1209600; // 14 days.

	public static function init() {
		add_action( 'user_register', array( __CLASS__, 'welcome' ), 20 );
		add_action( 'init', array( __CLASS__, 'boot' ) );
		add_action( self::CRON, array( __CLASS__, 'daily' ) );
		add_action( 'wp_footer', array( __CLASS__, 'beacon' ), 99 );
		add_action( 'wp_ajax_mrsh_pv', array( __CLASS__, 'pv' ) );
		add_action( 'wp_ajax_nopriv_mrsh_pv', array( __CLASS__, 'pv' ) );
	}

	public static function boot() {
		if ( ! wp_next_scheduled( self::CRON ) ) {
			wp_schedule_event( time() + 1800, 'daily', self::CRON );
		}
		// Remember when a member was last on the site (at most once every 6 hours).
		if ( is_user_logged_in() && ! is_admin() ) {
			$id   = get_current_user_id();
			$last = (int) get_user_meta( $id, 'mrsh_last_active', true );
			if ( time() - $last > 21600 ) { update_user_meta( $id, 'mrsh_last_active', time() ); }
		}
		// One-click unsubscribe from the "profile viewed" emails.
		if ( isset( $_GET['mrsh_unsub'], $_GET['k'] ) ) {
			$uid = (int) $_GET['mrsh_unsub'];
			if ( $uid && hash_equals( self::key( $uid ), sanitize_text_field( wp_unslash( $_GET['k'] ) ) ) ) {
				update_user_meta( $uid, 'mrsh_no_reengage', 1 );
				wp_die( 'You will no longer get these reminders. آپ کو اب یہ یاد دہانیاں نہیں ملیں گی۔', 'Unsubscribed', array( 'response' => 200 ) );
			}
		}
	}

	private static function key( $uid ) { return hash_hmac( 'sha256', 'unsub' . (int) $uid, wp_salt( 'auth' ) ); }

	private static function send( $to, $subject, $body ) {
		$name = static function () { return 'My Rishta Pakistan'; };
		$addr = static function () { return (string) apply_filters( 'mrsh_mail_from', 'noreply@myrishta.com' ); };
		add_filter( 'wp_mail_from_name', $name );
		add_filter( 'wp_mail_from', $addr );
		$ok = wp_mail( $to, $subject, $body, array( 'Reply-To: My Rishta Support <support@myrishta.pk>' ) );
		remove_filter( 'wp_mail_from_name', $name );
		remove_filter( 'wp_mail_from', $addr );
		return $ok;
	}

	/* 1. Welcome email */
	public static function welcome( $user_id ) {
		if ( get_option( 'mrsh_engage_off' ) ) { return; }
		$u = get_userdata( $user_id );
		if ( ! $u || ! is_email( $u->user_email ) || get_user_meta( $user_id, 'mrsh_welcomed', true ) ) { return; }
		update_user_meta( $user_id, 'mrsh_welcomed', time() );
		update_user_meta( $user_id, 'mrsh_last_active', time() );
		$name = $u->display_name ? $u->display_name : $u->user_login;
		$body = "Assalam o Alaikum {$name},\n\n"
			. "Welcome to My Rishta Pakistan! We are a free, non-profit rishta service in Lahore and we are glad you joined.\n\n"
			. "Three easy steps to start:\n"
			. "1. Add or complete your profile: " . home_url( '/add-listing/' ) . "\n"
			. "2. Browse proposals: " . home_url( '/latest-profiles/' ) . "\n"
			. "3. Read the safety tips: " . home_url( '/rishta-safety-tips-avoid-fake-profiles-scams/' ) . "\n\n"
			. "Tip: a clear, honest profile gets many more replies. Meet with family, in a public place, and never send money to anyone.\n"
			. "You can also use our phone app: " . home_url( '/app/' ) . "\n\n"
			. "If you need help, write to support@myrishta.pk or use " . home_url( '/contact/' ) . "\n\n"
			. "May Allah bless you with a good rishta.\nMy Rishta Pakistan team\n\n"
			. "-----\n"
			. "السلام علیکم {$name}،\n"
			. "مائی رشتہ پاکستان میں خوش آمدید! ہم لاہور میں ایک مفت، غیر منافع بخش رشتہ سروس ہیں۔\n"
			. "اپنا پروفائل مکمل کریں: " . home_url( '/add-listing/' ) . "\n"
			. "رشتے دیکھیں: " . home_url( '/latest-profiles/' ) . "\n"
			. "ملاقات ہمیشہ گھر والوں کے ساتھ اور کسی عوامی جگہ پر کریں، اور کسی کو پیسے نہ بھیجیں۔\n"
			. "اللہ آپ کو اچھا رشتہ نصیب کرے۔\n";
		self::send( $u->user_email, 'Welcome to My Rishta Pakistan · خوش آمدید', $body );
	}

	/* 2. Count profile views (works with page caching, because the page calls us with a tiny beacon) */
	public static function beacon() {
		if ( is_admin() || ! is_singular( self::TYPE ) || get_option( 'mrsh_engage_off' ) ) { return; }
		$id = (int) get_queried_object_id();
		echo '<script id="mrsh-pv">(function(){try{var u=' . wp_json_encode( admin_url( 'admin-ajax.php' ) ) . ',b="action=mrsh_pv&p=' . $id . '";'
			. 'if(navigator.sendBeacon){navigator.sendBeacon(u,new Blob([b],{type:"application/x-www-form-urlencoded"}))}'
			. 'else{fetch(u,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:b,keepalive:true})}}catch(e){}})();</script>' . "\n";
	}

	public static function pv() {
		$p = isset( $_POST['p'] ) ? (int) $_POST['p'] : 0;
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';
		if ( ! $p || self::TYPE !== get_post_type( $p ) || 'publish' !== get_post_status( $p ) || '' === $ua || preg_match( '/bot|crawl|spider|slurp|lighthouse|pagespeed|preview|headless/i', $ua ) ) { wp_die(); }
		$uid = is_user_logged_in() ? get_current_user_id() : 0;
		$post = get_post( $p );
		if ( $uid && ( (int) $post->post_author === $uid || current_user_can( 'edit_others_posts' ) ) ) { wp_die(); }
		$ip     = function_exists( 'mrt_ip' ) ? mrt_ip() : ( isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '' );
		$viewer = $uid ? 'u' . $uid : 'a' . substr( md5( $ip . $ua . wp_salt() ), 0, 12 );
		$day    = gmdate( 'Ymd' );
		$seen   = 'mrsh_s_' . md5( $viewer . $p . $day );
		if ( get_transient( $seen ) ) { wp_die(); }
		set_transient( $seen, 1, DAY_IN_SECONDS );
		// One address can add at most 80 profile views a day, so a bot cannot inflate the counts.
		$cap = 'mrsh_ipc_' . md5( $ip . $day );
		$cn  = (int) get_transient( $cap );
		if ( $cn >= 80 ) { wp_die(); }
		set_transient( $cap, $cn + 1, DAY_IN_SECONDS );

		// Per-profile daily counter, kept for 30 days.
		$vd = get_post_meta( $p, 'mrsh_vd', true );
		$vd = is_array( $vd ) ? $vd : array();
		$vd[ $day ] = ( isset( $vd[ $day ] ) ? (int) $vd[ $day ] : 0 ) + 1;
		$cut = gmdate( 'Ymd', time() - 30 * DAY_IN_SECONDS );
		foreach ( array_keys( $vd ) as $k ) { if ( (string) $k < $cut ) { unset( $vd[ $k ] ); } }
		update_post_meta( $p, 'mrsh_vd', $vd );

		// Heavy viewer alert: one email per viewer per day.
		$vk  = 'mrsh_v_' . md5( $viewer . $day );
		$set = get_transient( $vk );
		$set = is_array( $set ) ? $set : array();
		$set[ $p ] = 1;
		set_transient( $vk, $set, DAY_IN_SECONDS );
		$limit = (int) apply_filters( 'mrsh_view_alert_threshold', 10 );
		if ( count( $set ) >= $limit && ! get_transient( $vk . '_a' ) ) {
			set_transient( $vk . '_a', 1, DAY_IN_SECONDS );
			$who = 'A visitor who is not logged in';
			if ( $uid ) {
				$u   = get_userdata( $uid );
				$who = $u ? $u->display_name . ' (' . $u->user_email . '), ' . admin_url( 'user-edit.php?user_id=' . $uid ) : 'User #' . $uid;
			}
			$list = '';
			foreach ( array_keys( $set ) as $pid ) { $list .= '- ' . get_the_title( $pid ) . ' ' . get_permalink( $pid ) . "\n"; }
			self::send( get_option( 'admin_email' ), 'Heavy profile viewer: ' . count( $set ) . ' profiles today', $who . " has looked at " . count( $set ) . " different profiles today.\n\nThis can be a serious member, or someone collecting profiles. Profiles viewed:\n" . $list );
		}
		wp_die();
	}

	/* 3. Members away for 2 weeks */
	public static function daily() {
		if ( get_option( 'mrsh_engage_off' ) ) { return; }
		// Start the clock for members we have not seen yet, so nobody gets an email on day one.
		$new = get_users( array( 'meta_key' => 'mrsh_last_active', 'meta_compare' => 'NOT EXISTS', 'number' => 500, 'fields' => 'ID' ) );
		foreach ( $new as $uid ) { update_user_meta( $uid, 'mrsh_last_active', time() ); }

		$due = get_users( array(
			'number'     => 40,
			'fields'     => 'all',
			'meta_query' => array(
				'relation' => 'AND',
				array( 'key' => 'mrsh_last_active', 'value' => time() - self::AWAY, 'compare' => '<', 'type' => 'NUMERIC' ),
				array( 'relation' => 'OR', array( 'key' => 'mrsh_reeng_sent', 'compare' => 'NOT EXISTS' ), array( 'key' => 'mrsh_reeng_sent', 'value' => time() - self::AWAY, 'compare' => '<', 'type' => 'NUMERIC' ) ),
				array( 'relation' => 'OR', array( 'key' => 'mrsh_no_reengage', 'compare' => 'NOT EXISTS' ), array( 'key' => 'mrsh_no_reengage', 'value' => '1', 'compare' => '!=' ) ),
			),
		) );
		$from = gmdate( 'Ymd', time() - self::AWAY );
		foreach ( $due as $u ) {
			if ( user_can( $u, 'edit_posts' ) || ! is_email( $u->user_email ) ) { continue; }
			$posts = get_posts( array( 'post_type' => self::TYPE, 'author' => $u->ID, 'post_status' => 'publish', 'numberposts' => 5, 'fields' => 'ids' ) );
			$views = 0;
			foreach ( $posts as $pid ) {
				$vd = get_post_meta( $pid, 'mrsh_vd', true );
				if ( is_array( $vd ) ) { foreach ( $vd as $d => $c ) { if ( (string) $d >= $from ) { $views += (int) $c; } } }
			}
			if ( $views < 1 ) { continue; } // Only say "viewed" when it is true.
			update_user_meta( $u->ID, 'mrsh_reeng_sent', time() );
			$name  = $u->display_name ? $u->display_name : $u->user_login;
			$unsub = home_url( '/?mrsh_unsub=' . $u->ID . '&k=' . self::key( $u->ID ) );
			$body  = "Assalam o Alaikum {$name},\n\n"
				. "Good news: your profile on My Rishta Pakistan was viewed {$views} time" . ( 1 === $views ? '' : 's' ) . " in the last 2 weeks.\n\n"
				. "Families are looking. Log in, check your messages and keep your profile up to date so you do not miss a good proposal:\n" . home_url( '/' ) . "\n"
				. "Or open the app: " . home_url( '/app/' ) . "\n\n"
				. "Questions? Write to support@myrishta.pk\nMy Rishta Pakistan team\n\n"
				. "-----\n"
				. "السلام علیکم {$name}،\n"
				. "پچھلے 2 ہفتوں میں آپ کا پروفائل {$views} بار دیکھا گیا۔ لاگ اِن کریں، پیغامات دیکھیں اور اپنا پروفائل اپ ڈیٹ رکھیں: " . home_url( '/' ) . "\n\n"
				. "Stop these emails / یہ ای میلز بند کریں: {$unsub}\n";
			self::send( $u->user_email, 'Your profile was viewed ' . $views . ' time' . ( 1 === $views ? '' : 's' ) . ' · آپ کا پروفائل دیکھا گیا', $body );
		}
	}
}
MRSH_Engage::init();
