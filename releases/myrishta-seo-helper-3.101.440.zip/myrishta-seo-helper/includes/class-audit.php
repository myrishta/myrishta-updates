<?php
/**
 * Site Audit: a built-in website checker in the style of SEOptimer, Seobility, SEO Site Checkup
 * and Semrush Site Audit. Crawls the site's own pages and reports On-Page, Technical, Search
 * Intent, Performance and Off-Page items, with a score, plain-language fixes and a CSV export.
 * Off-page signals such as backlinks need paid data; this tab gives a tracked checklist instead.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Audit {

	const PAGES = 'mrsh_audit_pages';
	const SITE  = 'mrsh_audit_site';
	const QUEUE = 'mrsh_audit_queue';
	const OFF   = 'mrsh_audit_offpage';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 20 );
		foreach ( array( 'start', 'step', 'links' ) as $a ) {
			add_action( 'wp_ajax_mrsh_audit_' . $a, array( __CLASS__, 'ajax_' . $a ) );
		}
		add_action( 'admin_post_mrsh_audit_csv', array( __CLASS__, 'csv' ) );
		add_action( 'admin_post_mrsh_audit_off', array( __CLASS__, 'save_off' ) );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'MyRishta SEO: Site Audit', 'Site Audit', 'manage_options', 'mrsh-audit', array( __CLASS__, 'page' ) );
	}

	/* ---------- Search intent ---------- */

	public static function intent( $text ) {
		$t   = ' ' . strtolower( $text ) . ' ';
		$map = array(
			'Transactional' => '/\b(buy|price|prices|pricing|order|register|sign ?up|join|apply|download|subscribe|hire|book|booking|add profile|free trial|get started)\b/',
			'Commercial'    => '/\b(best|top|vs|versus|review|reviews|compare|comparison|alternative|alternatives|ranking|rated|cost)\b/',
			'Local'         => '/\b(near me|lahore|karachi|islamabad|rawalpindi|faisalabad|multan|peshawar|quetta|sialkot|gujranwala|pakistan|pakistani|punjab|sindh)\b/',
			'Navigational'  => '/\b(login|log in|sign in|contact|about us|about|my account|dashboard|support|home)\b/',
			'Informational' => '/\b(how|what|why|when|which|who|guide|tips|ideas|checklist|steps|tutorial|meaning|examples?|difference|explained|advice|things|questions?|faq)\b/',
		);
		$hits = array();
		foreach ( $map as $name => $re ) {
			if ( preg_match( $re, $t ) ) {
				$hits[] = $name;
			}
		}
		if ( empty( $hits ) ) {
			return 'Unclear';
		}
		// Local is a modifier; report the main intent if there is one.
		$main = array_values( array_diff( $hits, array( 'Local' ) ) );
		return empty( $main ) ? 'Local' : $main[0] . ( in_array( 'Local', $hits, true ) ? ' + Local' : '' );
	}

	public static function intent_advice( $intent ) {
		$base = trim( explode( '+', $intent )[0] );
		$a    = array(
			'Informational' => 'Answer the question in the first paragraph, add question-style subheadings, a short FAQ and links to related guides.',
			'Commercial'    => 'Compare options clearly, add pros and cons, real examples and a clear next step.',
			'Transactional' => 'Make the action obvious: a clear button above the fold, short form, trust signals (non-profit, free).',
			'Navigational'  => 'Keep it short, make the title match the brand name and link to the most used pages.',
			'Local'         => 'Mention the city or area in the title, heading and first paragraph, and show your address.',
			'Unclear'       => 'Rewrite the title so a searcher can tell what they get: add the topic and a benefit.',
		);
		return isset( $a[ $base ] ) ? $a[ $base ] : $a['Unclear'];
	}

	/* ---------- Page analysis (pure) ---------- */

	public static function analyze( $html, $headers, $url, $ttfb, $host, $focus = '', $pid = 0 ) {
		$iss  = array();
		$add  = function ( $sev, $cat, $msg ) use ( &$iss ) {
			$iss[] = array( 'sev' => $sev, 'cat' => $cat, 'msg' => $msg );
		};
		$size = strlen( $html );
		$d    = new DOMDocument();
		libxml_use_internal_errors( true );
		$d->loadHTML( '<?xml encoding="utf-8" ?>' . $html );
		libxml_clear_errors();
		$x    = new DOMXPath( $d );
		$q    = function ( $e ) use ( $x ) {
			return $x->query( $e );
		};
		$title = $q( '//title' )->length ? trim( $q( '//title' )->item( 0 )->textContent ) : '';
		$desc  = '';
		foreach ( $q( '//meta[@name]' ) as $m ) {
			if ( 'description' === strtolower( $m->getAttribute( 'name' ) ) ) {
				$desc = trim( $m->getAttribute( 'content' ) );
			}
		}
		$robots = '';
		foreach ( $q( '//meta[@name]' ) as $m ) {
			if ( 'robots' === strtolower( $m->getAttribute( 'name' ) ) ) {
				$robots = strtolower( $m->getAttribute( 'content' ) );
			}
		}
		$hx = isset( $headers['x-robots-tag'] ) ? strtolower( is_array( $headers['x-robots-tag'] ) ? implode( ',', $headers['x-robots-tag'] ) : $headers['x-robots-tag'] ) : '';
		$noindex = false !== strpos( $robots . ' ' . $hx, 'noindex' );
		$h1s = $q( '//h1' );
		$h1  = $h1s->length ? trim( preg_replace( '/\s+/', ' ', $h1s->item( 0 )->textContent ) ) : '';
		$canon = '';
		foreach ( $q( '//link[@rel="canonical"]' ) as $l ) {
			$canon = $l->getAttribute( 'href' );
		}
		$lang = $q( '//html' )->length ? $q( '//html' )->item( 0 )->getAttribute( 'lang' ) : '';
		$viewport = $q( '//meta[@name="viewport"]' )->length > 0;
		$ogt = $q( '//meta[@property="og:title"]' )->length > 0;
		$ogi = $q( '//meta[@property="og:image"]' )->length > 0;
		$schema = $q( '//script[@type="application/ld+json"]' )->length;
		// Body text.
		$body = $q( '//body' )->length ? $q( '//body' )->item( 0 ) : null;
		$text = '';
		if ( $body ) {
			$c = $body->cloneNode( true );
			foreach ( array( 'script', 'style', 'noscript', 'nav', 'header', 'footer' ) as $tag ) {
				$rm = $c->getElementsByTagName( $tag );
				for ( $i = $rm->length - 1; $i >= 0; $i-- ) {
					$rm->item( $i )->parentNode->removeChild( $rm->item( $i ) );
				}
			}
			$text = trim( preg_replace( '/\s+/', ' ', $c->textContent ) );
		}
		$words = str_word_count( $text );
		// Images.
		$imgs = $q( '//img' );
		$noalt = 0;
		foreach ( $imgs as $im ) {
			if ( ! $im->hasAttribute( 'alt' ) || '' === trim( $im->getAttribute( 'alt' ) ) ) {
				if ( 'presentation' !== $im->getAttribute( 'role' ) ) {
					$noalt++;
				}
			}
		}
		// Links.
		$int = array();
		$ext = 0;
		foreach ( $q( '//a[@href]' ) as $a ) {
			$h = trim( $a->getAttribute( 'href' ) );
			if ( '' === $h || '#' === $h[0] || preg_match( '/^(mailto|tel|javascript|sms|whatsapp):/i', $h ) ) {
				continue;
			}
			$p = wp_parse_url( $h );
			if ( empty( $p['host'] ) || 0 === strcasecmp( preg_replace( '/^www\./', '', $p['host'] ), preg_replace( '/^www\./', '', $host ) ) ) {
				$abs = empty( $p['host'] ) ? home_url( '/' . ltrim( $h, '/' ) ) : $h;
				$int[ strtok( $abs, '#' ) ] = 1;
			} else {
				$ext++;
			}
		}
		$hn = array( 'h2' => $q( '//h2' )->length, 'h3' => $q( '//h3' )->length );
		// Mixed content.
		$mixed = ( 0 === strpos( $url, 'https://' ) ) ? preg_match_all( '/(?:src|href)=["\']http:\/\/(?!schema\.org|www\.w3\.org)[^"\']+/i', $html ) : 0;

		// More tags (3.101.116): social tags, keywords tag, canonical, headings, links, images, structured data.
		$metas = array();
		foreach ( $q( '//meta' ) as $m ) {
			$k = strtolower( $m->getAttribute( 'name' ) ? $m->getAttribute( 'name' ) : $m->getAttribute( 'property' ) );
			if ( '' !== $k ) {
				$metas[ $k ][] = trim( $m->getAttribute( 'content' ) );
			}
		}
		$ogd   = ! empty( $metas['og:description'][0] );
		$ogu   = ! empty( $metas['og:url'][0] );
		$twc   = ! empty( $metas['twitter:card'][0] );
		$kwtag = isset( $metas['keywords'][0] ) ? $metas['keywords'][0] : '';
		$ndesc = isset( $metas['description'] ) ? count( $metas['description'] ) : 0;
		$ntit  = $q( '//title' )->length;
		$charset = $q( '//meta[@charset]' )->length > 0 || $q( '//meta[@http-equiv]' )->length > 0;
		$icon    = $q( '//link[contains(translate(@rel,"ICON","icon"),"icon")]' )->length > 0;
		$emptyh  = 0;
		foreach ( $q( '//h1|//h2|//h3|//h4' ) as $hh ) {
			if ( '' === trim( $hh->textContent ) && ! $hh->getElementsByTagName( 'img' )->length ) {
				$emptyh++;
			}
		}
		$skip = ( $h1s->length && 0 === $hn['h2'] && $hn['h3'] > 0 );
		$emptya = 0;
		foreach ( $q( '//a[@href]' ) as $a ) {
			if ( '' === trim( $a->textContent ) && '' === trim( $a->getAttribute( 'aria-label' ) ) && '' === trim( $a->getAttribute( 'title' ) ) && ! $a->getElementsByTagName( 'img' )->length && ! $a->getElementsByTagName( 'svg' )->length ) {
				$emptya++;
			}
		}
		$nosize = 0;
		foreach ( $imgs as $im ) {
			if ( ! $im->getAttribute( 'width' ) || ! $im->getAttribute( 'height' ) ) {
				$nosize++;
			}
		}
		$types = array();
		$badld = 0;
		foreach ( $q( '//script[@type="application/ld+json"]' ) as $sc ) {
			$j = json_decode( trim( $sc->textContent ), true );
			if ( ! is_array( $j ) ) {
				$badld++;
				continue;
			}
			$stack = isset( $j['@graph'] ) && is_array( $j['@graph'] ) ? $j['@graph'] : array( $j );
			foreach ( $stack as $node ) {
				if ( is_array( $node ) && isset( $node['@type'] ) ) {
					foreach ( (array) $node['@type'] as $t ) {
						$types[ (string) $t ] = 1;
					}
				}
			}
		}
		$types = array_keys( $types );
		$cpath = $canon ? rtrim( (string) wp_parse_url( $canon, PHP_URL_PATH ), '/' ) : '';
		$upath = rtrim( (string) wp_parse_url( $url, PHP_URL_PATH ), '/' );
		$chost = $canon ? preg_replace( '/^www\./', '', (string) wp_parse_url( $canon, PHP_URL_HOST ) ) : '';
		$canon_bad = '' !== $canon && ( ( $chost && 0 !== strcasecmp( $chost, preg_replace( '/^www\./', '', $host ) ) ) || $cpath !== $upath );
		$path = (string) wp_parse_url( $url, PHP_URL_PATH );
		$slug = strtolower( trim( $path, '/' ) );
		// Focus phrase checks.
		$fl = strtolower( trim( $focus ) );
		$in = array( 't' => null, 'd' => null, 'h' => null, 'u' => null, 'i' => null, 'dens' => null );
		if ( '' !== $fl ) {
			$ft = strtolower( $title );
			$in['t'] = false !== strpos( $ft, $fl );
			$in['d'] = false !== strpos( strtolower( $desc ), $fl );
			$in['h'] = false !== strpos( strtolower( $h1 ), $fl );
			$toks    = array_filter( preg_split( '/[^\p{L}\p{N}]+/u', $fl ) );
			$hit     = 0;
			foreach ( $toks as $tk ) {
				if ( false !== strpos( $slug, $tk ) ) {
					$hit++;
				}
			}
			$in['u'] = $toks && $hit >= max( 1, (int) ceil( count( $toks ) / 2 ) );
			$first   = implode( ' ', array_slice( preg_split( '/\s+/', strtolower( $text ) ), 0, 100 ) );
			$in['i'] = false !== strpos( $first, $fl );
			$cnt     = $words > 0 ? substr_count( strtolower( $text ), $fl ) : 0;
			$in['dens'] = $words > 0 ? round( $cnt * max( 1, str_word_count( $fl ) ) / $words * 100, 1 ) : 0;
		}
		// Rules.
		if ( ! $noindex ) {
			$tl = function_exists( 'mb_strlen' ) ? mb_strlen( $title ) : strlen( $title );
			$dl = function_exists( 'mb_strlen' ) ? mb_strlen( $desc ) : strlen( $desc );
			if ( '' === $title ) {
				$add( 'high', 'onpage', 'Missing title tag' );
			} elseif ( $tl < 25 ) {
				$add( 'med', 'onpage', 'Title is too short (under 25 characters)' );
			} elseif ( $tl > 65 ) {
				$add( 'low', 'onpage', 'Title is too long (over 65 characters, may be cut in Google)' );
			}
			if ( '' === $desc ) {
				$add( 'high', 'onpage', 'Missing meta description' );
			} elseif ( $dl < 70 ) {
				$add( 'med', 'onpage', 'Meta description is too short (under 70 characters)' );
			} elseif ( $dl > 165 ) {
				$add( 'low', 'onpage', 'Meta description is too long (over 165 characters)' );
			}
			if ( 0 === $h1s->length ) {
				$add( 'high', 'onpage', 'No H1 heading' );
			} elseif ( $h1s->length > 1 ) {
				$add( 'low', 'onpage', 'More than one H1 heading' );
			}
			if ( 0 === $hn['h2'] && $words > 300 ) {
				$add( 'low', 'onpage', 'Long page with no H2 subheadings' );
			}
			if ( $words < 150 ) {
				$add( 'med', 'content', 'Very little text (under 150 words): thin content' );
			} elseif ( $words < 300 ) {
				$add( 'low', 'content', 'Short content (under 300 words)' );
			}
			if ( $noalt > 0 ) {
				$add( $noalt > 3 ? 'med' : 'low', 'onpage', $noalt . ' image(s) without alt text' );
			}
			if ( '' === $canon ) {
				$add( 'med', 'tech', 'No canonical tag' );
			}
			if ( ! $ogt || ! $ogi ) {
				$add( 'low', 'onpage', 'Missing Open Graph title or image (poor link previews on WhatsApp and Facebook)' );
			}
			if ( 0 === $schema ) {
				$add( 'low', 'tech', 'No structured data (schema)' );
			}
			if ( count( $int ) < 3 ) {
				$add( 'med', 'onpage', 'Fewer than 3 internal links' );
			}

			if ( ! $ogd ) {
				$add( 'low', 'onpage', 'Missing Open Graph description (link previews on WhatsApp and Facebook)' );
			}
			if ( ! $twc ) {
				$add( 'low', 'onpage', 'Missing Twitter / X card tag' );
			}
			if ( $ntit > 1 ) {
				$add( 'med', 'onpage', 'More than one title tag' );
			}
			if ( $ndesc > 1 ) {
				$add( 'med', 'onpage', 'More than one meta description' );
			}
			if ( $canon_bad ) {
				$add( 'med', 'tech', 'Canonical points to a different address than the page itself' );
			}
			if ( false !== strpos( $robots, 'nofollow' ) ) {
				$add( 'med', 'tech', 'Meta robots says nofollow' );
			}
			if ( $skip ) {
				$add( 'low', 'onpage', 'Headings skip a level (H1 then H3 without H2)' );
			}
			if ( $emptyh > 0 ) {
				$add( 'low', 'onpage', $emptyh . ' empty heading(s)' );
			}
			if ( $emptya > 0 ) {
				$add( 'low', 'onpage', $emptya . ' link(s) with no text or label (hard for Google and screen readers)' );
			}
			if ( $nosize > 3 ) {
				$add( 'low', 'perf', $nosize . ' image(s) without width and height (page jumps while loading)' );
			}
			if ( $badld > 0 ) {
				$add( 'med', 'tech', $badld . ' structured data block(s) with invalid JSON' );
			}
			if ( ! $charset ) {
				$add( 'low', 'tech', 'No character set declared' );
			}
			if ( ! $icon ) {
				$add( 'low', 'tech', 'No favicon link' );
			}
			if ( strlen( $path ) > 100 ) {
				$add( 'low', 'onpage', 'Address (URL) is very long (over 100 characters)' );
			}
			if ( preg_match( '/[A-Z_]/', $path ) ) {
				$add( 'low', 'onpage', 'Address (URL) has capital letters or underscores' );
			}
			if ( '' === $fl ) {
				$add( 'low', 'onpage', 'No focus phrase set for this page (use Auto keywords or the page editor)' );
			} else {
				if ( ! $in['t'] ) {
					$add( 'med', 'onpage', 'Focus phrase is not in the title' );
				}
				if ( ! $in['d'] ) {
					$add( 'low', 'onpage', 'Focus phrase is not in the meta description' );
				}
				if ( ! $in['h'] ) {
					$add( 'med', 'onpage', 'Focus phrase is not in the H1 heading' );
				}
				if ( ! $in['u'] ) {
					$add( 'low', 'onpage', 'Focus phrase is not in the address (URL)' );
				}
				if ( ! $in['i'] ) {
					$add( 'low', 'content', 'Focus phrase is not in the first 100 words' );
				}
				if ( $words >= 150 && null !== $in['dens'] && $in['dens'] < 0.3 ) {
					$add( 'low', 'content', 'Focus phrase is hardly used in the text (under 0.3%)' );
				}
				if ( null !== $in['dens'] && $in['dens'] > 3.5 ) {
					$add( 'med', 'content', 'Focus phrase is repeated too often (over 3.5%, looks like keyword stuffing)' );
				}
			}
		}
		if ( '' === $lang ) {
			$add( 'low', 'tech', 'No language set on the html tag' );
		}
		if ( ! $viewport ) {
			$add( 'high', 'tech', 'No mobile viewport tag' );
		}
		if ( $mixed > 0 ) {
			$add( 'med', 'tech', 'Mixed content: ' . $mixed . ' resource(s) loaded over http' );
		}
		if ( $ttfb > 2.5 ) {
			$add( 'low', 'perf', 'Slow uncached server response (over 2.5 s on this test)' );
		}
		if ( $size > 300000 ) {
			$add( 'low', 'perf', 'Large HTML (' . round( $size / 1024 ) . ' KB)' );
		}
		$intent = self::intent( $title . ' ' . $h1 . ' ' . wp_parse_url( $url, PHP_URL_PATH ) );
		return array(
			'url' => $url, 'title' => $title, 'desc' => $desc, 'h1' => $h1, 'words' => $words, 'noalt' => $noalt,
			'noindex' => $noindex, 'intent' => $intent, 'issues' => $iss, 'ttfb' => round( $ttfb, 2 ), 'kb' => round( $size / 1024 ),
			'links' => array_slice( array_keys( $int ), 0, 60 ), 'ext' => $ext,
			'pid' => (int) $pid, 'focus' => $focus, 'in' => $in, 'kw' => $kwtag, 'tl' => function_exists( 'mb_strlen' ) ? mb_strlen( $title ) : strlen( $title ), 'dl' => function_exists( 'mb_strlen' ) ? mb_strlen( $desc ) : strlen( $desc ),
			'h1n' => $h1s->length, 'ogt' => $ogt, 'ogd' => $ogd, 'ogi' => $ogi, 'ogu' => $ogu, 'twc' => $twc, 'canon' => $canon, 'canon_bad' => $canon_bad, 'types' => $types,
		);
	}

	/* ---------- Site-wide technical checks ---------- */

	public static function site_checks() {
		$home = home_url( '/' );
		$out  = array();
		$add  = function ( $ok, $sev, $label, $detail ) use ( &$out ) {
			$out[] = array( 'ok' => $ok, 'sev' => $sev, 'label' => $label, 'detail' => $detail );
		};
		$get = function ( $u, $args = array() ) {
			return wp_remote_get( $u, array_merge( array( 'timeout' => 12, 'redirection' => 0 ), $args ) );
		};
		$add( 0 === strpos( $home, 'https://' ), 'high', 'Site uses HTTPS', $home );
		$r = wp_remote_get( $home, array( 'timeout' => 15 ) );
		if ( ! is_wp_error( $r ) ) {
			$h = wp_remote_retrieve_headers( $r );
			$enc = isset( $h['content-encoding'] ) ? $h['content-encoding'] : '';
			$add( '' !== $enc, 'med', 'Text compression (gzip or brotli)', $enc ? 'Using ' . $enc : 'Pages are sent uncompressed' );
			$add( isset( $h['cache-control'] ) || isset( $h['x-litespeed-cache'] ), 'low', 'Page caching active', isset( $h['x-litespeed-cache'] ) ? 'LiteSpeed cache: ' . $h['x-litespeed-cache'] : 'Cache header: ' . ( isset( $h['cache-control'] ) ? $h['cache-control'] : 'none' ) );
			$add( isset( $h['strict-transport-security'] ), 'low', 'HSTS header (forces https)', isset( $h['strict-transport-security'] ) ? 'On' : 'Not set' );
			$add( isset( $h['x-content-type-options'] ), 'low', 'X-Content-Type-Options header', isset( $h['x-content-type-options'] ) ? 'On' : 'Not set' );
		}
		// www / non-www.
		$p     = wp_parse_url( $home );
		$alt   = ( 0 === strpos( $p['host'], 'www.' ) ? substr( $p['host'], 4 ) : 'www.' . $p['host'] );
		$ra    = $get( $p['scheme'] . '://' . $alt . '/' );
		$loc   = ! is_wp_error( $ra ) ? wp_remote_retrieve_header( $ra, 'location' ) : '';
		$add( ! is_wp_error( $ra ) && in_array( (int) wp_remote_retrieve_response_code( $ra ), array( 301, 308 ), true ) && false !== strpos( (string) $loc, $p['host'] ), 'med', 'www and non-www go to one version', is_wp_error( $ra ) ? 'Alternate host not reachable (fine if not used)' : 'Alternate host answers ' . wp_remote_retrieve_response_code( $ra ) . ( $loc ? ' to ' . $loc : '' ) );
		// http to https.
		$rh = $get( 'http://' . $p['host'] . '/' );
		$add( ! is_wp_error( $rh ) && in_array( (int) wp_remote_retrieve_response_code( $rh ), array( 301, 302, 307, 308 ), true ) && 0 === strpos( (string) wp_remote_retrieve_header( $rh, 'location' ), 'https://' ), 'high', 'http redirects to https', is_wp_error( $rh ) ? 'http not reachable' : 'http answers ' . wp_remote_retrieve_response_code( $rh ) );
		// robots.txt.
		$rb = $get( home_url( '/robots.txt' ), array( 'redirection' => 3 ) );
		$rbb = ! is_wp_error( $rb ) ? wp_remote_retrieve_body( $rb ) : '';
		$add( ! is_wp_error( $rb ) && 200 === (int) wp_remote_retrieve_response_code( $rb ), 'high', 'robots.txt exists', 'robots.txt' );
		$add( false !== stripos( $rbb, 'sitemap:' ), 'med', 'robots.txt lists the sitemap', 'Sitemap line ' . ( false !== stripos( $rbb, 'sitemap:' ) ? 'found' : 'missing' ) );
		$add( ! preg_match( '/^\s*disallow:\s*\/\s*$/mi', $rbb ), 'high', 'robots.txt does not block the whole site', 'Checked for "Disallow: /"' );
		// Sitemap.
		$sm = $get( home_url( '/wp-sitemap.xml' ), array( 'redirection' => 3 ) );
		$smb = ! is_wp_error( $sm ) ? wp_remote_retrieve_body( $sm ) : '';
		$add( ! is_wp_error( $sm ) && 200 === (int) wp_remote_retrieve_response_code( $sm ) && false !== strpos( $smb, '<sitemap' ), 'high', 'XML sitemap works', '/wp-sitemap.xml' );
		// 404 page.
		$nf = $get( home_url( '/mrsh-audit-' . wp_rand( 1000, 9999 ) . '-missing/' ) );
		$add( ! is_wp_error( $nf ) && 404 === (int) wp_remote_retrieve_response_code( $nf ), 'med', 'Missing pages return a real 404', is_wp_error( $nf ) ? 'Could not test' : 'Answers ' . wp_remote_retrieve_response_code( $nf ) );
		// ads.txt and favicon.
		$ad = $get( home_url( '/ads.txt' ), array( 'redirection' => 3 ) );
		$add( ! is_wp_error( $ad ) && 200 === (int) wp_remote_retrieve_response_code( $ad ) && false !== stripos( wp_remote_retrieve_body( $ad ), 'google.com' ), 'low', 'ads.txt for AdSense', 'ads.txt' );
		$fv = $get( home_url( '/favicon.ico' ), array( 'redirection' => 3 ) );
		$add( ! is_wp_error( $fv ) && 200 === (int) wp_remote_retrieve_response_code( $fv ), 'low', 'Favicon', 'favicon.ico' );
		// SSL certificate expiry.
		$ssl = '';
		if ( function_exists( 'stream_context_create' ) && 0 === strpos( $home, 'https://' ) ) {
			$ctx = stream_context_create( array( 'ssl' => array( 'capture_peer_cert' => true, 'verify_peer' => false, 'verify_peer_name' => false ) ) );
			$fp  = @stream_socket_client( 'ssl://' . $p['host'] . ':443', $en, $es, 8, STREAM_CLIENT_CONNECT, $ctx );
			if ( $fp ) {
				$par = stream_context_get_params( $fp );
				if ( ! empty( $par['options']['ssl']['peer_certificate'] ) ) {
					$ci  = openssl_x509_parse( $par['options']['ssl']['peer_certificate'] );
					$days = isset( $ci['validTo_time_t'] ) ? (int) floor( ( $ci['validTo_time_t'] - time() ) / DAY_IN_SECONDS ) : null;
					if ( null !== $days ) {
						$add( $days > 14, 'high', 'SSL certificate not about to expire', 'Valid for ' . $days . ' more days' );
					}
				}
				fclose( $fp );
			}
		}
		// Social profiles for brand signals.
		$o = class_exists( 'MRSH_Options' ) ? MRSH_Options::get() : array();
		$same = ! empty( $o['org_same_as'] ) ? $o['org_same_as'] : '';
		$add( ! empty( $same ), 'low', 'Social profile links added for Google (sameAs)', ! empty( $same ) ? 'Set' : 'Add your Facebook, Instagram, YouTube and LinkedIn pages in SEO settings' );
		return $out;
	}

	/* ---------- Crawl (AJAX, in small batches) ---------- */

	private static function guard() {
		check_ajax_referer( 'mrsh_audit' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'No permission' );
		}
	}

	public static function urls() {
		$urls = array( home_url( '/' ) );
		$ids  = get_posts( array( 'post_type' => array( 'page', 'post' ), 'post_status' => 'publish', 'posts_per_page' => 300, 'fields' => 'ids', 'orderby' => 'modified', 'order' => 'DESC', 'no_found_rows' => true ) );
		foreach ( $ids as $id ) {
			$urls[] = get_permalink( $id );
		}
		// A sample of the newest live profiles, so profile pages are checked too.
		$pr = get_posts( array( 'post_type' => 'listing_type', 'post_status' => 'publish', 'posts_per_page' => 30, 'fields' => 'ids', 'orderby' => 'date', 'order' => 'DESC', 'no_found_rows' => true ) );
		foreach ( $pr as $id ) {
			$urls[] = get_permalink( $id );
		}
		return array_values( array_unique( $urls ) );
	}

	public static function ajax_start() {
		self::guard();
		$urls = self::urls();
		update_option( self::QUEUE, $urls, false );
		update_option( self::PAGES, array(), false );
		update_option( self::SITE, array( 'time' => time(), 'checks' => self::site_checks(), 'broken' => array() ), false );
		wp_send_json_success( array( 'total' => count( $urls ) ) );
	}

	public static function ajax_step() {
		self::guard();
		$off   = max( 0, (int) ( isset( $_POST['offset'] ) ? $_POST['offset'] : 0 ) );
		$queue = get_option( self::QUEUE, array() );
		$pages = get_option( self::PAGES, array() );
		$host  = wp_parse_url( home_url(), PHP_URL_HOST );
		foreach ( array_slice( $queue, $off, 4 ) as $u ) {
			$t0 = microtime( true );
			$r  = wp_remote_get( $u, array( 'timeout' => 20, 'redirection' => 0, 'user-agent' => 'MyRishta-SEO-Audit' ) );
			$tt = microtime( true ) - $t0;
			$rc = is_wp_error( $r ) ? 0 : (int) wp_remote_retrieve_response_code( $r );
			if ( $rc >= 300 && $rc < 400 ) {
				// Redirecting pages (login-only or old addresses) are not content pages: no SEO issues to report.
				$pages[ $u ] = array( 'url' => $u, 'title' => '', 'desc' => '', 'h1' => '', 'words' => 0, 'noalt' => 0, 'noindex' => true, 'intent' => '-', 'ttfb' => round( $tt, 2 ), 'kb' => 0, 'links' => array(), 'ext' => 0, 'issues' => array(), 'redirect' => (string) wp_remote_retrieve_header( $r, 'location' ) );
				continue;
			}
			if ( is_wp_error( $r ) || 200 !== (int) wp_remote_retrieve_response_code( $r ) ) {
				$pages[ $u ] = array( 'url' => $u, 'title' => '', 'desc' => '', 'h1' => '', 'words' => 0, 'noalt' => 0, 'noindex' => false, 'intent' => '-', 'ttfb' => round( $tt, 2 ), 'kb' => 0, 'links' => array(), 'ext' => 0,
					'issues' => array( array( 'sev' => 'high', 'cat' => 'tech', 'msg' => 'Page did not load (' . ( is_wp_error( $r ) ? $r->get_error_message() : 'HTTP ' . wp_remote_retrieve_response_code( $r ) ) . ')' ) ) );
				continue;
			}
			$h = wp_remote_retrieve_headers( $r );
			$pid = (int) url_to_postid( $u );
			$fp  = $pid ? trim( (string) get_post_meta( $pid, '_mrsh_focus', true ) ) : '';
			$pages[ $u ] = self::analyze( wp_remote_retrieve_body( $r ), is_object( $h ) && method_exists( $h, 'getAll' ) ? array_change_key_case( $h->getAll() ) : (array) $h, $u, $tt, $host, $fp, $pid );
		}
		update_option( self::PAGES, $pages, false );
		wp_send_json_success( array( 'done' => min( count( $queue ), $off + 4 ), 'total' => count( $queue ) ) );
	}

	/** Check internal link targets that were not crawled (broken-link finder). */
	public static function ajax_links() {
		self::guard();
		$off   = max( 0, (int) ( isset( $_POST['offset'] ) ? $_POST['offset'] : 0 ) );
		$pages = get_option( self::PAGES, array() );
		$site  = get_option( self::SITE, array() );
		$known = array_map( 'untrailingslashit', array_keys( $pages ) );
		$seen  = array();
		foreach ( $pages as $p ) {
			foreach ( $p['links'] as $l ) {
				$k = untrailingslashit( $l );
				if ( ! in_array( $k, $known, true ) && ! preg_match( '/\.(jpg|jpeg|png|gif|webp|svg|css|js|pdf|ico|woff2?)(\?|$)/i', $l ) && false === strpos( $l, '/wp-' ) ) {
					$seen[ $l ][] = $p['url'];
				}
			}
		}
		$keys = array_keys( $seen );
		$broken = isset( $site['broken'] ) ? $site['broken'] : array();
		foreach ( array_slice( $keys, $off, 8 ) as $l ) {
			$r = wp_remote_head( $l, array( 'timeout' => 10, 'redirection' => 3 ) );
			$c = is_wp_error( $r ) ? 0 : (int) wp_remote_retrieve_response_code( $r );
			if ( 405 === $c || 403 === $c ) {
				$r = wp_remote_get( $l, array( 'timeout' => 10, 'redirection' => 3 ) );
				$c = is_wp_error( $r ) ? 0 : (int) wp_remote_retrieve_response_code( $r );
			}
			if ( 0 === $c || $c >= 400 ) {
				$broken[ $l ] = array( 'code' => $c, 'from' => array_slice( $seen[ $l ], 0, 3 ) );
			}
		}
		$site['broken'] = $broken;
		update_option( self::SITE, $site, false );
		wp_send_json_success( array( 'done' => min( count( $keys ), $off + 8 ), 'total' => count( $keys ) ) );
	}

	/* ---------- Report ---------- */

	public static function report() {
		$pages = get_option( self::PAGES, array() );
		$site  = get_option( self::SITE, array() );
		if ( empty( $pages ) ) {
			return null;
		}
		$sev  = array( 'high' => 0, 'med' => 0, 'low' => 0 );
		$grp  = array();
		$titles = array();
		$descs  = array();
		foreach ( $pages as $u => $p ) {
			if ( ! empty( $p['noindex'] ) ) {
				continue;
			}
			if ( '' !== $p['title'] ) {
				$titles[ strtolower( $p['title'] ) ][] = $u;
			}
			if ( '' !== $p['desc'] ) {
				$descs[ strtolower( $p['desc'] ) ][] = $u;
			}
		}
		foreach ( $pages as $u => $p ) {
			foreach ( $p['issues'] as $i ) {
				$k = $i['cat'] . '|' . $i['sev'] . '|' . $i['msg'];
				$grp[ $k ] = isset( $grp[ $k ] ) ? $grp[ $k ] : array( 'cat' => $i['cat'], 'sev' => $i['sev'], 'msg' => $i['msg'], 'urls' => array() );
				$grp[ $k ]['urls'][] = $u;
			}
		}
		foreach ( $titles as $t => $us ) {
			if ( count( $us ) > 1 ) {
				$grp[ 'dt' . $t ] = array( 'cat' => 'onpage', 'sev' => 'med', 'msg' => 'Duplicate title used on ' . count( $us ) . ' pages: ' . $t, 'urls' => $us );
			}
		}
		foreach ( $descs as $t => $us ) {
			if ( count( $us ) > 1 ) {
				$grp[ 'dd' . $t ] = array( 'cat' => 'onpage', 'sev' => 'med', 'msg' => 'Duplicate meta description used on ' . count( $us ) . ' pages', 'urls' => $us );
			}
		}
		if ( ! empty( $site['broken'] ) ) {
			foreach ( $site['broken'] as $l => $b ) {
				$grp[ 'bl' . $l ] = array( 'cat' => 'tech', 'sev' => 'high', 'msg' => 'Broken internal link (' . ( $b['code'] ? $b['code'] : 'no answer' ) . '): ' . $l, 'urls' => $b['from'] );
			}
		}
		if ( ! empty( $site['checks'] ) ) {
			foreach ( $site['checks'] as $c ) {
				if ( ! $c['ok'] ) {
					$grp[ 'sc' . $c['label'] ] = array( 'cat' => 'tech', 'sev' => $c['sev'], 'msg' => 'Site: ' . $c['label'] . ' (' . $c['detail'] . ')', 'urls' => array() );
				}
			}
		}
		$pen = array( 'high' => 6, 'med' => 3, 'low' => 1 );
		$pts = 0;
		$cats = array( 'onpage' => 0, 'tech' => 0, 'content' => 0, 'perf' => 0 );
		$n   = max( 1, count( $pages ) );
		foreach ( $grp as $g ) {
			$w = max( 1, count( $g['urls'] ) );
			$sev[ $g['sev'] ]++;
			// Penalty grows with how many pages are affected, but is capped per issue type.
			$cost = $pen[ $g['sev'] ] * min( 1, $w / $n * 2 + 0.2 );
			$pts += $cost;
			$cats[ $g['cat'] ] += $cost;
		}
		uasort( $grp, function ( $a, $b ) use ( $pen ) {
			return ( $pen[ $b['sev'] ] * 1000 + count( $b['urls'] ) ) <=> ( $pen[ $a['sev'] ] * 1000 + count( $a['urls'] ) );
		} );
		return array( 'score' => max( 0, (int) round( 100 - $pts * 1.4 ) ), 'sev' => $sev, 'groups' => $grp, 'pages' => $pages, 'site' => $site, 'cats' => $cats );
	}

	public static function csv() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'No permission' );
		}
		check_admin_referer( 'mrsh_audit_csv' );
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=site-audit-' . gmdate( 'Y-m-d' ) . '.csv' );
		$o = fopen( 'php://output', 'w' );
		fputcsv( $o, array( 'URL', 'Title', 'Title length', 'Meta description', 'Description length', 'H1', 'Focus phrase', 'Meta keywords tag', 'Canonical', 'Schema types', 'Words', 'Intent', 'Server time (s)', 'Issues' ) );
		foreach ( get_option( self::PAGES, array() ) as $p ) {
			fputcsv( $o, array( $p['url'], $p['title'], $p['tl'] ?? '', $p['desc'], $p['dl'] ?? '', $p['h1'], $p['focus'] ?? '', $p['kw'] ?? '', $p['canon'] ?? '', implode( ' ', (array) ( $p['types'] ?? array() ) ), $p['words'], $p['intent'], $p['ttfb'], implode( '; ', wp_list_pluck( $p['issues'], 'msg' ) ) ) );
		}
		fclose( $o );
		exit;
	}

	/* ---------- Off-page checklist ---------- */

	public static function off_items() {
		return array(
			'gsc'       => array( 'Google Search Console verified and sitemap submitted', 'Free. Shows links to your site under Links.' ),
			'bing'      => array( 'Bing Webmaster Tools verified (import from Search Console)', 'Bing also feeds Yahoo, DuckDuckGo and ChatGPT search.' ),
			'gbp'       => array( 'Google Business Profile created for My Rishta Pakistan, Lahore', 'Free; add address, phone, hours and photos. Builds local trust.' ),
			'fb'        => array( 'Facebook page linked from the site and in schema (sameAs)', 'Post success-story and article links regularly.' ),
			'ig'        => array( 'Instagram, YouTube and LinkedIn profiles created and linked', 'Use the same name, logo and description everywhere.' ),
			'dir'       => array( 'Listed in Pakistani business and NGO directories', 'Only real, relevant directories. No paid link packages.' ),
			'ngo'       => array( 'Mentioned or listed by a registered NGO or community website', 'Ask partners to link to the About page.' ),
			'press'     => array( 'One press or blog mention (guest post or interview)', 'Offer a helpful rishta-advice article to a Pakistani lifestyle site.' ),
			'forum'     => array( 'Helpful answers on Quora and Pakistani forums with a link where it fits', 'Never spam. Links from comments and forums carry little weight.' ),
			'review'    => array( 'Reviews collected (Google Business Profile and Trustpilot)', 'Ask happy families after a successful match.' ),
			'broken'    => array( 'Checked who links to you and fixed any lost or wrong links', 'Use Search Console > Links. Redirect old URLs that still get links.' ),
			'disavow'   => array( 'No spammy or paid links pointing to the site', 'Ignore normal low-quality links. Google already discounts them.' ),
		);
	}

	public static function save_off() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'No permission' );
		}
		check_admin_referer( 'mrsh_audit_off' );
		$done = array();
		foreach ( array_keys( self::off_items() ) as $k ) {
			if ( ! empty( $_POST['off'][ $k ] ) ) {
				$done[ $k ] = 1;
			}
		}
		update_option( self::OFF, $done, false );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-audit&tab=off&saved=1' ) );
		exit;
	}

	/* ---------- Admin page ---------- */

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$tab  = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'overview';
		$tabs = array( 'overview' => 'Overview', 'onpage' => 'On-Page', 'tags' => 'Tags and keywords', 'tech' => 'Technical', 'intent' => 'Search Intent', 'perf' => 'Performance', 'off' => 'Off-Page' );
		$rep  = self::report();
		MRSH_Admin::open( 'Site Audit', 'Checks your own pages the way SEOptimer, Seobility, SEO Site Checkup and Semrush do, and tells you what to fix first.' );
		echo '<div style="margin:10px 0"><button class="button button-primary" id="mrsh-run">Run full audit</button> <span id="mrsh-prog" style="margin-left:10px"></span>';
		if ( $rep ) {
			echo ' <a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_audit_csv' ), 'mrsh_audit_csv' ) ) . '">Download CSV</a> <span style="color:#50575e;margin-left:8px">Last run ' . esc_html( human_time_diff( (int) $rep['site']['time'] ) ) . ' ago</span>';
		}
		echo '</div><div class="mrt-sub">';
		foreach ( $tabs as $k => $l ) {
			echo '<a class="' . ( $k === $tab ? 'on' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=mrsh-audit&tab=' . $k ) ) . '">' . esc_html( $l ) . '</a>';
		}
		echo '</div><div style="margin-top:16px">';
		if ( 'off' === $tab ) {
			self::tab_off();
		} elseif ( ! $rep ) {
			echo '<p>No audit yet. Click <b>Run full audit</b>. It takes 1 to 3 minutes and checks every published page and post.</p>';
		} elseif ( 'overview' === $tab ) {
			self::tab_overview( $rep );
		} elseif ( 'tags' === $tab ) {
			self::tab_tags( $rep );
		} elseif ( 'intent' === $tab ) {
			self::tab_intent( $rep );
		} elseif ( 'perf' === $tab ) {
			self::tab_perf( $rep );
		} else {
			self::tab_issues( $rep, $tab );
		}
		echo '</div>';
		$nonce = wp_create_nonce( 'mrsh_audit' );
		$ajax  = admin_url( 'admin-ajax.php' );
		echo '<script>(function(){var b=document.getElementById("mrsh-run"),p=document.getElementById("mrsh-prog");if(!b)return;function post(a,o){var f=new FormData();f.append("action",a);f.append("_ajax_nonce",' . wp_json_encode( $nonce ) . ');f.append("offset",o||0);return fetch(' . wp_json_encode( $ajax ) . ',{method:"POST",body:f,credentials:"same-origin"}).then(function(r){return r.json()});}function loop(a,o,label,next){post(a,o).then(function(j){if(!j.success){p.textContent="Error: "+(j.data||"failed");b.disabled=false;return;}var d=j.data;p.textContent=label+" "+d.done+" / "+d.total;if(d.done<d.total)loop(a,d.done,label,next);else next();}).catch(function(){p.textContent="Network error, try again";b.disabled=false;});}b.addEventListener("click",function(){b.disabled=true;p.textContent="Starting...";post("mrsh_audit_start").then(function(j){if(!j.success){p.textContent="Error";b.disabled=false;return;}loop("mrsh_audit_step",0,"Checking pages",function(){loop("mrsh_audit_links",0,"Checking links",function(){p.textContent="Done. Loading report...";location.href=' . wp_json_encode( admin_url( 'admin.php?page=mrsh-audit&tab=overview' ) ) . ';});});});});})();</script></div>';
	}

	private static function badge( $sev ) {
		$c = array( 'high' => '#b32d2e', 'med' => '#dba617', 'low' => '#787c82' );
		$l = array( 'high' => 'Fix first', 'med' => 'Should fix', 'low' => 'Nice to fix' );
		return '<span style="background:' . $c[ $sev ] . ';color:#fff;border-radius:3px;padding:1px 7px;font-size:11px">' . $l[ $sev ] . '</span>';
	}

	private static function tab_overview( $rep ) {
		$s   = $rep['score'];
		echo '<div class="mrsh-tiles">';
		echo MRSH_Admin::tile( (int) $s, 'SEO health score', $s >= 90 ? 'good' : ( $s >= 70 ? 'ok' : 'bad' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo MRSH_Admin::tile( (int) $rep['sev']['high'], 'Fix first', $rep['sev']['high'] ? 'bad' : 'good' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo MRSH_Admin::tile( (int) $rep['sev']['med'], 'Should fix', $rep['sev']['med'] ? 'ok' : 'good' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo MRSH_Admin::tile( (int) $rep['sev']['low'], 'Nice to fix', '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo MRSH_Admin::tile( count( $rep['pages'] ), 'Pages checked', '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '</div>';
		echo '<h2>Top things to fix</h2>';
		$i = 0;
		echo '<table class="widefat striped"><thead><tr><th>Priority</th><th>Issue</th><th>Pages</th></tr></thead><tbody>';
		foreach ( $rep['groups'] as $g ) {
			if ( ++$i > 12 ) {
				break;
			}
			echo '<tr><td>' . self::badge( $g['sev'] ) . '</td><td>' . esc_html( $g['msg'] ) . '</td><td>' . ( count( $g['urls'] ) ? count( $g['urls'] ) : 'Whole site' ) . '</td></tr>';
		}
		echo '</tbody></table><p style="color:#50575e">Open the On-Page, Technical and Performance tabs for every item with the affected pages.</p>';
		if ( ! empty( $rep['site']['checks'] ) ) {
			echo '<h2>Technical checklist</h2><table class="widefat striped" style="max-width:900px"><tbody>';
			foreach ( $rep['site']['checks'] as $c ) {
				echo '<tr><td style="width:24px">' . ( $c['ok'] ? '<span style="color:#008a20">&#10003;</span>' : '<span style="color:#b32d2e">&#10007;</span>' ) . '</td><td>' . esc_html( $c['label'] ) . '</td><td style="color:#50575e">' . esc_html( $c['detail'] ) . '</td></tr>';
			}
			echo '</tbody></table>';
		}
	}

	private static function tab_issues( $rep, $cat ) {
		$any = false;
		echo '<table class="widefat striped"><thead><tr><th style="width:90px">Priority</th><th>Issue</th><th>Affected pages</th></tr></thead><tbody>';
		foreach ( $rep['groups'] as $g ) {
			$in = ( 'onpage' === $cat && in_array( $g['cat'], array( 'onpage', 'content' ), true ) ) || $g['cat'] === $cat;
			if ( ! $in ) {
				continue;
			}
			$any = true;
			$list = '';
			foreach ( array_slice( $g['urls'], 0, 6 ) as $u ) {
				$list .= '<div><a href="' . esc_url( $u ) . '" target="_blank" rel="noopener">' . esc_html( preg_replace( '#^https?://[^/]+#', '', $u ) ?: '/' ) . '</a></div>';
			}
			if ( count( $g['urls'] ) > 6 ) {
				$list .= '<div style="color:#50575e">and ' . ( count( $g['urls'] ) - 6 ) . ' more (see CSV)</div>';
			}
			echo '<tr><td>' . self::badge( $g['sev'] ) . '</td><td>' . esc_html( $g['msg'] ) . '</td><td>' . ( $list ? $list : 'Whole site' ) . '</td></tr>';
		}
		if ( ! $any ) {
			echo '<tr><td colspan="3">Nothing to fix here. Good work.</td></tr>';
		}
		echo '</tbody></table>';
	}


	/** One row per page: every tag and the focus phrase checks, with a tick or a cross (3.101.116). */
	private static function tab_tags( $rep ) {
		$ok  = function ( $v ) {
			return null === $v ? '<span style="color:#9ca3af" title="No focus phrase">-</span>' : ( $v ? '<span style="color:#16a34a;font-weight:700">&#10003;</span>' : '<span style="color:#dc2626;font-weight:700">&#10007;</span>' );
		};
		$len = function ( $n, $lo, $hi ) {
			$c = ( $n >= $lo && $n <= $hi ) ? '#16a34a' : ( 0 === (int) $n ? '#dc2626' : '#d97706' );
			return '<b style="color:' . $c . '">' . (int) $n . '</b>';
		};
		$rows = array();
		foreach ( $rep['pages'] as $u => $p ) {
			if ( ! empty( $p['noindex'] ) || ! isset( $p['tl'] ) ) {
				continue;
			}
			$bad = 0;
			foreach ( array( $p['tl'] < 25 || $p['tl'] > 65, $p['dl'] < 70 || $p['dl'] > 165, 1 !== (int) $p['h1n'], ! $p['ogt'], ! $p['ogd'], ! $p['ogi'], ! $p['twc'], '' === (string) $p['canon'] || ! empty( $p['canon_bad'] ), empty( $p['types'] ), '' === (string) $p['focus'] ) as $f ) {
				$bad += $f ? 1 : 0;
			}
			foreach ( (array) $p['in'] as $k => $v ) {
				if ( 'dens' !== $k && false === $v ) {
					$bad++;
				}
			}
			$rows[ $u ] = array( $bad, $p );
		}
		uasort( $rows, function ( $a, $b ) {
			return $b[0] <=> $a[0];
		} );
		$tot = count( $rows );
		$nofocus = 0;
		$nodesc  = 0;
		$notitle = 0;
		foreach ( $rows as $r ) {
			$nofocus += '' === (string) $r[1]['focus'] ? 1 : 0;
			$nodesc  += 0 === (int) $r[1]['dl'] ? 1 : 0;
			$notitle += 0 === (int) $r[1]['tl'] ? 1 : 0;
		}
		$card = function ( $n, $l, $c ) {
			return '<div style="background:#fff;border:1px solid #dcdcde;border-left:4px solid ' . $c . ';border-radius:8px;padding:10px 16px;min-width:130px"><b style="font-size:22px">' . (int) $n . '</b><br><span style="color:#50575e">' . esc_html( $l ) . '</span></div>';
		};
		echo '<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:12px">' . $card( $tot, 'pages checked', '#7c3aed' ) . $card( $notitle, 'no title', '#dc2626' ) . $card( $nodesc, 'no description', '#dc2626' ) . $card( $nofocus, 'no focus phrase', '#d97706' ) . '</div>';
		echo '<p>Worst pages first. Green numbers are in the good range (title 25 to 65 characters, description 70 to 165). The focus phrase columns show whether the page\'s chosen phrase is in the <b>T</b>itle, <b>D</b>escription, <b>H1</b>, <b>U</b>RL and the <b>I</b>ntro (first 100 words). Pages with no focus phrase: open <a href="' . esc_url( admin_url( 'admin.php?page=mrsh-autokw' ) ) . '">Auto keywords</a> to fill them. The "keywords tag" column is the old meta keywords tag; Google ignores it, so it is fine when empty.</p>';
		echo '<p><label><input type="checkbox" id="mrsh-onlybad"> Show only pages with something missing</label></p><div style="overflow-x:auto"><table class="widefat striped" id="mrsh-tagtbl"><thead><tr><th>Page</th><th>Title</th><th>Desc.</th><th>H1</th><th>Focus phrase</th><th>T</th><th>D</th><th>H1</th><th>U</th><th>I</th><th>Density</th><th>OG</th><th>X card</th><th>Canonical</th><th>Schema</th><th>Keywords tag</th><th></th></tr></thead><tbody>';
		foreach ( $rows as $u => $r ) {
			$p   = $r[1];
			$in  = (array) $p['in'];
			$ed  = $p['pid'] ? get_edit_post_link( (int) $p['pid'] ) : '';
			echo '<tr data-bad="' . (int) $r[0] . '"><td><a href="' . esc_url( $u ) . '" target="_blank" rel="noopener">' . esc_html( preg_replace( '#^https?://[^/]+#', '', $u ) ?: '/' ) . '</a><br><small style="color:#50575e">' . esc_html( mb_substr( $p['title'], 0, 60 ) ) . '</small></td>';
			echo '<td>' . $len( $p['tl'], 25, 65 ) . '</td><td>' . $len( $p['dl'], 70, 165 ) . '</td><td>' . $ok( 1 === (int) $p['h1n'] ) . '</td>';
			echo '<td>' . ( '' !== (string) $p['focus'] ? esc_html( $p['focus'] ) : '<span style="color:#dc2626">not set</span>' ) . '</td>';
			echo '<td>' . $ok( $in['t'] ?? null ) . '</td><td>' . $ok( $in['d'] ?? null ) . '</td><td>' . $ok( $in['h'] ?? null ) . '</td><td>' . $ok( $in['u'] ?? null ) . '</td><td>' . $ok( $in['i'] ?? null ) . '</td>';
			$dn = $in['dens'] ?? null;
			echo '<td>' . ( null === $dn ? '-' : '<b style="color:' . ( $dn >= 0.3 && $dn <= 3.5 ? '#16a34a' : '#d97706' ) . '">' . esc_html( $dn ) . '%</b>' ) . '</td>';
			echo '<td>' . $ok( $p['ogt'] && $p['ogd'] && $p['ogi'] ) . '</td><td>' . $ok( $p['twc'] ) . '</td><td>' . $ok( '' !== (string) $p['canon'] && empty( $p['canon_bad'] ) ) . '</td>';
			echo '<td>' . ( $p['types'] ? esc_html( implode( ', ', array_slice( $p['types'], 0, 3 ) ) ) : '<span style="color:#dc2626">none</span>' ) . '</td><td>' . ( '' !== (string) $p['kw'] ? esc_html( mb_substr( $p['kw'], 0, 40 ) ) : '<span style="color:#9ca3af">empty</span>' ) . '</td>';
			echo '<td>' . ( $ed ? '<a class="button button-small" href="' . esc_url( $ed ) . '">Edit</a>' : '' ) . '</td></tr>';
		}
		echo '</tbody></table></div><script>document.getElementById("mrsh-onlybad").addEventListener("change",function(){var on=this.checked;document.querySelectorAll("#mrsh-tagtbl tbody tr").forEach(function(r){r.style.display=on&&r.getAttribute("data-bad")==="0"?"none":""})});</script>';
	}

	private static function tab_intent( $rep ) {
		echo '<p>Search intent is what the visitor wants when they search: to learn (informational), compare (commercial), act (transactional), find a place (local) or reach a page (navigational). Each page should match one clear intent.</p>';
		echo '<table class="widefat striped"><thead><tr><th>Page</th><th>Title</th><th>Intent</th><th>What to do</th></tr></thead><tbody>';
		foreach ( $rep['pages'] as $u => $p ) {
			if ( ! empty( $p['noindex'] ) ) {
				continue;
			}
			echo '<tr><td><a href="' . esc_url( $u ) . '" target="_blank" rel="noopener">' . esc_html( preg_replace( '#^https?://[^/]+#', '', $u ) ?: '/' ) . '</a></td><td>' . esc_html( $p['title'] ) . '</td><td><b>' . esc_html( $p['intent'] ) . '</b></td><td>' . esc_html( self::intent_advice( $p['intent'] ) ) . '</td></tr>';
		}
		echo '</tbody></table>';
	}

	private static function tab_perf( $rep ) {
		$rows = $rep['pages'];
		uasort( $rows, function ( $a, $b ) {
			return $b['ttfb'] <=> $a['ttfb'];
		} );
		echo '<p>Server response time and page size per page, slowest first. For full mobile and desktop scores use the <a href="' . esc_url( admin_url( 'admin.php?page=mrsh-psi' ) ) . '">PageSpeed</a> tab. Pages answering in under 1 second are good. Pages not yet in the cache look slower here.</p>';
		echo '<table class="widefat striped"><thead><tr><th>Page</th><th>Server time</th><th>HTML size</th><th>Words</th></tr></thead><tbody>';
		foreach ( array_slice( $rows, 0, 40, true ) as $u => $p ) {
			echo '<tr><td><a href="' . esc_url( $u ) . '" target="_blank" rel="noopener">' . esc_html( preg_replace( '#^https?://[^/]+#', '', $u ) ?: '/' ) . '</a></td><td>' . esc_html( $p['ttfb'] ) . ' s</td><td>' . (int) $p['kb'] . ' KB</td><td>' . (int) $p['words'] . '</td></tr>';
		}
		echo '</tbody></table>';
	}

	private static function tab_off() {
		$done = get_option( self::OFF, array() );
		echo '<p>Off-page SEO is what happens outside your site: links from other websites, mentions, reviews and social profiles. Real backlink counts need paid data, so this tab gives a checklist of the steps that matter for a Pakistani matrimonial non-profit. Tick items as you finish them.</p>';
		if ( isset( $_GET['saved'] ) ) {
			echo '<div class="notice notice-success inline"><p>Saved.</p></div>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_audit_off">';
		wp_nonce_field( 'mrsh_audit_off' );
		echo '<table class="widefat striped" style="max-width:900px"><tbody>';
		foreach ( self::off_items() as $k => $it ) {
			echo '<tr data-attn="' . ( empty( $done[ $k ] ) ? '1' : '0' ) . '"><td style="width:30px"><input type="checkbox" name="off[' . esc_attr( $k ) . ']" value="1"' . checked( ! empty( $done[ $k ] ), true, false ) . '></td><td><b>' . esc_html( $it[0] ) . '</b><br><span style="color:#50575e">' . esc_html( $it[1] ) . '</span></td></tr>';
		}
		$n = count( $done );
		echo '</tbody></table><p><b>' . (int) $n . ' of ' . count( self::off_items() ) . ' done.</b> <button class="button button-primary">Save</button></p></form>';
		echo '<p>Free tools: <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Search Console</a> (Links report), <a href="https://www.bing.com/webmasters" target="_blank" rel="noopener">Bing Webmaster Tools</a>, <a href="https://business.google.com" target="_blank" rel="noopener">Google Business Profile</a>.</p>';
	}
}
