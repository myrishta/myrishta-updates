<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Options {

	const KEY = 'mrsh_options';

	public static function defaults() {
		return array(
			'noindex_post_types'  => 'listing_type',
			'noindex_taxonomies'  => '',
			'noindex_params'      => 's,sort,reset',
			'noindex_search'      => 1,
			'strip_canonical'     => 1,
			'robots_txt'          => 1,
			'robots_disallow'     => "/wp-login.php\n/my-account/",
			'sitemap_url'         => '',
			'org_schema'          => 0,
			'org_name'            => '',
			'org_logo'            => '',
			'org_same_as'         => '',
			'org_email'           => '',
			'org_phone'           => '',
			'org_street'          => 'Shahdara',
			'org_city'            => 'Lahore',
			'org_region'          => 'Punjab',
			'org_postal'          => '54000',
			'pk_hreflang'         => 1,
			'auto_discover'       => 1,
			'auto_meta'           => 1,
			'standalone'          => 1,
			'og_tags'             => 1,
			'canonical_tags'      => 1,
			'article_schema'      => 1,
			'sitemap_redirect'    => 1,
			'noindex_slugs'       => 'login,registration,forgot-password,profile,my-account,my-account-2,cart,checkout,shop,add-listing,chatroom,callback,country-list,country-list-2,country-list-3,country-list-4,refund_returns',
			'noindex_author'      => 1,
			'noindex_date'        => 1,
			'noindex_attachment'  => 1,
			'noindex_paged'       => 0,
			'website_schema'      => 1,
			'breadcrumb_schema'   => 1,
			'speed_emojis'        => 1,
			'speed_embeds'        => 1,
			'speed_preconnect'    => 0,
			'speed_fonts'         => 1,
			'cache_enabled'       => 0,
			'cache_ttl'           => 6,
			'cache_exclude'       => 'login,registration,forgot-password,profile,my-account,my-account-2,cart,checkout,add-listing,chatroom,wp-json,wp-admin',
			'img_compress'        => 1,
			'img_quality'         => 75,
			'img_max'             => 1200,
			'cdn_url'             => '',
			'adsense_pub'         => '',
			'adstxt_extra'        => '',
			'cdn_themes'          => 1,
			'speed_images'        => 1,
			'fix_access'          => 1,
			'speed_dimensions'    => 1,
			'speed_eager_images'  => 2,
			'speed_dashicons'     => 1,
			'speed_unhide'        => 1,
			'pk_theme'            => 1,
			'org_footer'          => 1,
			'speed_webp'          => 1,
			'speed_delay_ads'     => 0,
			'speed_hide_adminbar' => 1,
			'speed_delay_ga'      => 1,
			'speed_hero'          => 1,
			'speed_heartbeat'     => 1,
			'speed_blocks'        => 0,
			'speed_defer'         => 0,
			'speed_defer_exclude' => '',
			'speed_preload_img'   => '',
			'dedupe_head'         => 1,
			'clean_words'         => 1,
			'trim_description'    => 0,
			'clean_generator'     => 1,
			'clean_shortlink'     => 1,
			'clean_rsd'           => 1,
			'clean_rest_links'    => 0,
			'meta_title_home'     => 'Online Rishta in Pakistan | Free Rishta Lahore & Islamabad',
			'meta_desc_home'      => 'Online rishta service in Pakistan, free for every family. Find rishta in Lahore, Karachi, Islamabad, Rawalpindi and abroad. Register free, connect safely.',
			'meta_title_page'     => '%title% | %sitename%',
			'social_image'        => '',
			'google_verification'    => '',
			'bing_verification'      => '',
			'yandex_verification'    => '',
			'baidu_verification'     => '',
			'naver_verification'     => '',
			'seznam_verification'    => '',
			'pinterest_verification' => '',
			'facebook_verification'  => '',
			'ahrefs_verification'    => '',
			'bing_verified_other'    => 0,
			'verify_custom'          => '',
			'verify_files'           => '',
			'indexnow_enabled'       => 0,
			'indexnow_key'           => '',
		);
	}

	/** Office details used everywhere (schema, footer, contact page, shortcodes). Change them once in the plugin settings. */
	public static function org() {
		$o = self::get();
		$d = array( 'street' => 'Shahdara', 'city' => 'Lahore', 'region' => 'Punjab', 'postal' => '54000' );
		$r = array();
		foreach ( $d as $k => $def ) {
			$v       = isset( $o[ 'org_' . $k ] ) ? trim( (string) $o[ 'org_' . $k ] ) : '';
			$r[ $k ] = '' !== $v ? $v : '';
		}
		$r['phone'] = '' !== trim( (string) $o['org_phone'] ) ? trim( (string) $o['org_phone'] ) : '+92-42-29292921';
		$r['email'] = '' !== trim( (string) $o['org_email'] ) ? trim( (string) $o['org_email'] ) : 'support@myrishta.pk';
		$r['tel']   = '+' . ltrim( preg_replace( '/[^0-9]/', '', $r['phone'] ), '0' );
		$parts      = array_filter( array( $r['street'], $r['city'] . ( '' !== $r['postal'] ? ' ' . $r['postal'] : '' ) ), 'strlen' );
		$r['line']  = implode( ', ', $parts );
		return $r;
	}

	public static function get() {
		$o = wp_parse_args( (array) get_option( self::KEY, array() ), self::defaults() );
		// Office phone: the old placeholder number is replaced by the real one everywhere (structured data, pages, footer).
		$ph = trim( (string) $o['org_phone'] );
		if ( '' === $ph || '+92-42292929' === $ph ) {
			$o['org_phone'] = '+92-42-29292921';
		}
		if ( '' === trim( (string) $o['bing_verification'] ) ) {
			$o['bing_verification'] = '5677316611B8643D289EB43150086010'; // Bing Webmaster Tools code for myrishta.pk.
		}
		return $o;
	}

	/** "a, b,c" becomes array( 'a', 'b', 'c' ). */
	public static function to_list( $str ) {
		$items = array_map( 'sanitize_key', explode( ',', (string) $str ) );
		return array_values( array_filter( $items ) );
	}

	public static function lines( $str ) {
		return preg_split( '/\R/', (string) $str );
	}

	/**
	 * Each form posts a hidden _section so saving one page never resets the other.
	 * A value without _section is treated as already sanitized (WordPress calls the
	 * callback twice the first time an option is created).
	 */
	/** Pull a code out of a pasted value or a whole meta tag. False when it is clearly not a code. */
	public static function extract_code( $raw ) {
		$raw = trim( (string) $raw );
		if ( '' === $raw ) {
			return '';
		}
		if ( preg_match( '/content\s*=\s*["\']([^"\']+)["\']/i', $raw, $m ) ) {
			$raw = trim( $m[1] );
		}
		if ( preg_match( '#https?:|/|\.(txt|html|xml)$|\s#i', $raw ) || ! preg_match( '/^[A-Za-z0-9_\-:.]{6,120}$/', $raw ) ) {
			return false;
		}
		return $raw;
	}

	public static function sanitize( $in ) {
		$in  = is_array( $in ) ? $in : array();
		$cur = self::get();

		if ( ! isset( $in['_section'] ) ) {
			return array_merge( $cur, array_intersect_key( $in, self::defaults() ) );
		}

		if ( 'rules' === $in['_section'] ) {
			foreach ( array( 'noindex_post_types', 'noindex_taxonomies', 'noindex_params', 'noindex_slugs' ) as $k ) {
				$cur[ $k ] = implode( ',', self::to_list( isset( $in[ $k ] ) ? $in[ $k ] : '' ) );
			}
			foreach ( array( 'noindex_search', 'strip_canonical', 'robots_txt', 'org_schema', 'pk_hreflang', 'auto_discover', 'auto_meta', 'standalone', 'og_tags', 'canonical_tags', 'article_schema', 'sitemap_redirect', 'noindex_author', 'noindex_date', 'noindex_attachment', 'noindex_paged', 'website_schema', 'breadcrumb_schema', 'speed_emojis', 'speed_embeds', 'speed_preconnect', 'speed_fonts', 'speed_images', 'fix_access', 'speed_dimensions', 'speed_dashicons', 'speed_unhide', 'pk_theme', 'org_footer', 'speed_webp', 'speed_delay_ads', 'speed_hide_adminbar', 'speed_delay_ga', 'speed_hero', 'speed_heartbeat', 'speed_blocks', 'speed_defer', 'dedupe_head', 'clean_words', 'trim_description', 'clean_generator', 'clean_shortlink', 'clean_rsd', 'clean_rest_links' ) as $k ) {
				$cur[ $k ] = empty( $in[ $k ] ) ? 0 : 1;
			}
			$paths = array();
			foreach ( self::lines( isset( $in['robots_disallow'] ) ? $in['robots_disallow'] : '' ) as $p ) {
				$p = sanitize_text_field( $p );
				if ( '' !== $p && '/' === $p[0] && ! preg_match( '/\s/', $p ) ) {
					$paths[] = $p;
				}
			}
			$cur['robots_disallow'] = implode( "\n", $paths );
			$cur['sitemap_url']     = esc_url_raw( isset( $in['sitemap_url'] ) ? trim( $in['sitemap_url'] ) : '' );
			$cur['org_name']        = sanitize_text_field( isset( $in['org_name'] ) ? $in['org_name'] : '' );
			$cur['org_email']       = sanitize_email( isset( $in['org_email'] ) ? $in['org_email'] : '' );
			$cur['org_phone']       = preg_replace( '/[^0-9+\-\s()]/', '', isset( $in['org_phone'] ) ? (string) $in['org_phone'] : '' );
			foreach ( array( 'org_street', 'org_city', 'org_region', 'org_postal' ) as $k ) {
				$cur[ $k ] = sanitize_text_field( isset( $in[ $k ] ) ? $in[ $k ] : '' );
			}
			foreach ( array( 'meta_title_home', 'meta_desc_home', 'meta_title_page' ) as $k ) {
				$v         = sanitize_text_field( isset( $in[ $k ] ) ? $in[ $k ] : '' );
				$cur[ $k ] = '' !== $v ? $v : self::defaults()[ $k ];
			}
			$cur['speed_eager_images'] = max( 0, min( 6, (int) ( isset( $in['speed_eager_images'] ) ? $in['speed_eager_images'] : 2 ) ) );
			$cur['speed_defer_exclude'] = implode( ',', self::to_list( isset( $in['speed_defer_exclude'] ) ? $in['speed_defer_exclude'] : '' ) );
			$cur['speed_preload_img']   = esc_url_raw( isset( $in['speed_preload_img'] ) ? trim( $in['speed_preload_img'] ) : '' );
			$cur['social_image']    = esc_url_raw( isset( $in['social_image'] ) ? trim( $in['social_image'] ) : '' );
			$cur['org_logo']        = esc_url_raw( isset( $in['org_logo'] ) ? trim( $in['org_logo'] ) : '' );
			$same                   = array();
			foreach ( self::lines( isset( $in['org_same_as'] ) ? $in['org_same_as'] : '' ) as $u ) {
				$u = esc_url_raw( trim( $u ) );
				if ( '' !== $u ) {
					$same[] = $u;
				}
			}
			$cur['org_same_as'] = implode( "\n", $same );
		} elseif ( 'tools' === $in['_section'] ) {
			foreach ( array( 'cache_enabled', 'img_compress', 'cdn_themes' ) as $k ) {
				$cur[ $k ] = empty( $in[ $k ] ) ? 0 : 1;
			}
			$cur['cache_ttl']     = max( 1, min( 168, (int) ( isset( $in['cache_ttl'] ) ? $in['cache_ttl'] : 6 ) ) );
			$cur['cache_exclude'] = implode( ',', self::to_list( isset( $in['cache_exclude'] ) ? $in['cache_exclude'] : '' ) );
			$cur['img_quality']   = max( 50, min( 95, (int) ( isset( $in['img_quality'] ) ? $in['img_quality'] : 82 ) ) );
			$cur['img_max']       = max( 1000, min( 5000, (int) ( isset( $in['img_max'] ) ? $in['img_max'] : 2000 ) ) );
			$pub                  = strtolower( trim( isset( $in['adsense_pub'] ) ? (string) $in['adsense_pub'] : '' ) );
			$pub                  = preg_replace( '/^ca-/', '', $pub );
			$cur['adsense_pub']   = preg_match( '/^pub-\d{10,20}$/', $pub ) ? $pub : '';
			$extra                = array();
			foreach ( self::lines( isset( $in['adstxt_extra'] ) ? $in['adstxt_extra'] : '' ) as $l ) {
				$l = trim( sanitize_text_field( $l ) );
				if ( preg_match( '/^[a-z0-9.\-]+,\s*[A-Za-z0-9\-_]+,\s*(DIRECT|RESELLER)(,\s*[A-Za-z0-9]+)?$/i', $l ) ) {
					$extra[] = $l;
				}
			}
			$cur['adstxt_extra']  = implode( "\n", $extra );
			$cdn                  = esc_url_raw( isset( $in['cdn_url'] ) ? trim( $in['cdn_url'] ) : '' );
			$cur['cdn_url']       = ( '' !== $cdn && 0 === strpos( $cdn, 'https://' ) ) ? untrailingslashit( $cdn ) : '';
		} elseif ( 'engines' === $in['_section'] ) {
			$vals = array();
			foreach ( array_keys( MRSH_Frontend::verification_map() ) as $k ) {
				$code = self::extract_code( isset( $in[ $k ] ) ? (string) $in[ $k ] : '' );
				if ( false === $code ) {
					add_settings_error( self::KEY, 'mrsh_code_' . $k, 'The ' . $k . ' value is not a verification code (it looks like a web address or file name). It was cleared. Copy only the value after content= from the engine.', 'error' );
					$code = '';
				}
				$cur[ $k ] = $code;
				if ( '' !== $code ) {
					$vals[ $code ][] = $k;
				}
			}
			foreach ( $vals as $code => $keys ) {
				if ( count( $keys ) > 1 ) {
					foreach ( $keys as $k ) {
						$cur[ $k ] = '';
					}
					add_settings_error( self::KEY, 'mrsh_dupe_' . md5( $code ), 'The same code was entered for ' . implode( ', ', $keys ) . '. Every search engine gives a different code, so those fields were cleared. Browser autofill can cause this; the fields now turn it off.', 'error' );
				}
			}
			$lines = array();
			foreach ( self::lines( isset( $in['verify_custom'] ) ? $in['verify_custom'] : '' ) as $l ) {
				if ( preg_match( '/^([A-Za-z0-9_.:\-]{3,60})\s*=\s*(.+)$/', trim( $l ), $m ) ) {
					$v = self::extract_code( $m[2] );
					if ( false !== $v && '' !== $v ) {
						$lines[] = $m[1] . '=' . $v;
					}
				}
			}
			$cur['verify_custom'] = implode( "\n", array_slice( $lines, 0, 20 ) );
			$files = array();
			foreach ( self::lines( isset( $in['verify_files'] ) ? $in['verify_files'] : '' ) as $l ) {
				$parts = explode( '|', trim( $l ), 2 );
				$name  = trim( $parts[0] );
				$body  = isset( $parts[1] ) ? trim( $parts[1] ) : '';
				if ( ! preg_match( '/^[A-Za-z0-9_\-]{3,80}\.(html|xml|txt)$/', $name ) || '' === $body ) {
					continue;
				}
				if ( preg_match( '/\.xml$/', $name ) ) {
					if ( ! preg_match( '/^(<\?xml[^>]*\?>\s*)?<users>\s*<user>[A-Za-z0-9]+<\/user>\s*<\/users>$/', $body ) ) {
						continue;
					}
				} else {
					$body = sanitize_text_field( $body );
				}
				$files[] = $name . '|' . $body;
			}
			$cur['verify_files'] = implode( "\n", array_slice( $files, 0, 10 ) );
		} elseif ( 'indexnow' === $in['_section'] ) {
			$cur['indexnow_enabled'] = empty( $in['indexnow_enabled'] ) ? 0 : 1;
			if ( $cur['indexnow_enabled'] && ! MRSH_IndexNow::valid_key( $cur['indexnow_key'] ) ) {
				$cur['indexnow_key'] = MRSH_IndexNow::new_key();
			}
		}
		return $cur;
	}
}
