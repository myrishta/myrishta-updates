<?php
/**
 * Email queue (3.101.107). Member emails are saved in a database table first and sent a few at a time, so none is lost
 * when the host is slow or blocks mail. A failed email is retried (10 min, 1 h, 6 h, 24 h) and only then marked failed.
 * Trust and spam protection:
 *  - every email is sent as HTML plus a plain-text copy, from one real mailbox (see Email (SMTP)),
 *  - addresses whose domain cannot receive mail are skipped, and addresses the mail server says do not exist are never tried again,
 *  - one-click unsubscribe headers (List-Unsubscribe and List-Unsubscribe-Post),
 *  - a limit per run and per day, so the sending reputation of the domain stays clean,
 *  - the page shows a live check of SPF, DKIM and DMARC for the domain.
 * Table: {prefix}mrsh_mailq. Option: mrsh_mailq (limits).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Mailq {
	const HOOK = 'mrsh_mailq_run';
	const OPT  = 'mrsh_mailq';

	private static $alt = '';

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'mrsh_mailq';
	}

	public static function get() {
		$d = array( 'per_run' => 10, 'per_day' => 150, 'max_tries' => 5 );
		$o = get_option( self::OPT, array() );
		return is_array( $o ) ? array_merge( $d, $o ) : $d;
	}

	public static function init() {
		add_filter( 'cron_schedules', function ( $s ) {
			$s['mrsh_5min'] = array( 'interval' => 300, 'display' => 'Every 5 minutes' );
			return $s;
		} );
		add_action( self::HOOK, array( __CLASS__, 'run' ) );
		add_action( 'init', array( __CLASS__, 'boot' ) );
		add_action( 'phpmailer_init', array( __CLASS__, 'alt_body' ), 40 );
		if ( is_admin() ) {
			add_action( 'admin_menu', array( __CLASS__, 'menu' ), 27 );
			foreach ( array( 'save', 'run_now', 'retry', 'purge', 'test' ) as $a ) {
				add_action( 'admin_post_mrsh_mailq_' . $a, array( __CLASS__, 'act_' . $a ) );
			}
		}
	}

	public static function boot() {
		self::install();
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + 120, 'mrsh_5min', self::HOOK );
		}
	}

	public static function install() {
		if ( 1 === (int) get_option( 'mrsh_mailq_db', 0 ) ) {
			return;
		}
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$t = self::table();
		dbDelta( "CREATE TABLE {$t} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			to_email varchar(190) NOT NULL,
			subject varchar(255) NOT NULL,
			body longtext NOT NULL,
			html longtext NULL,
			headers text NULL,
			kind varchar(30) NOT NULL DEFAULT '',
			uid bigint(20) unsigned NOT NULL DEFAULT 0,
			status varchar(10) NOT NULL DEFAULT 'queued',
			tries tinyint(3) unsigned NOT NULL DEFAULT 0,
			created int(10) unsigned NOT NULL DEFAULT 0,
			next_try int(10) unsigned NOT NULL DEFAULT 0,
			sent_at int(10) unsigned NOT NULL DEFAULT 0,
			err varchar(255) NOT NULL DEFAULT '',
			PRIMARY KEY  (id),
			KEY st (status, next_try),
			KEY uid (uid)
		) " . $wpdb->get_charset_collate() . ';' );
		update_option( 'mrsh_mailq_db', 1, false );
	}

	/* ---------- adding ---------- */

	private static function mx_ok( $email ) {
		$d = strtolower( substr( strrchr( $email, '@' ), 1 ) );
		if ( '' === $d || ! function_exists( 'checkdnsrr' ) ) {
			return true;
		}
		$k = 'mrsh_mx_' . md5( $d );
		$c = get_transient( $k );
		if ( false !== $c ) {
			return 'y' === $c;
		}
		$ok = checkdnsrr( $d . '.', 'MX' ) || checkdnsrr( $d . '.', 'A' );
		set_transient( $k, $ok ? 'y' : 'n', 7 * DAY_IN_SECONDS );
		return $ok;
	}

	/** Queue one email. Returns the queue id, or 0 when the address must not be mailed. $a: html, headers (array), kind, uid. */
	public static function add( $to, $subject, $text, $a = array() ) {
		global $wpdb;
		self::install();
		$to  = sanitize_email( $to );
		$uid = (int) ( $a['uid'] ?? 0 );
		if ( class_exists( 'MRSH_PermBan' ) && MRSH_PermBan::mail_blocked( $to, $uid, $a['kind'] ?? '' ) ) {
			return 0;
		}
		if ( ! is_email( $to ) || ( $uid && get_user_meta( $uid, 'mrsh_mail_bad', true ) ) || ! self::mx_ok( $to ) ) {
			return 0;
		}
		$ok = $wpdb->insert( self::table(), array(
			'to_email' => $to,
			'subject'  => mb_substr( (string) $subject, 0, 250 ),
			'body'     => (string) $text,
			'html'     => isset( $a['html'] ) ? (string) $a['html'] : null,
			'headers'  => wp_json_encode( array_values( (array) ( $a['headers'] ?? array() ) ) ),
			'kind'     => substr( (string) ( $a['kind'] ?? '' ), 0, 30 ),
			'uid'      => $uid,
			'status'   => 'queued',
			'created'  => time(),
			'next_try' => time(),
		) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return $ok ? (int) $wpdb->insert_id : 0;
	}

	/* ---------- sending ---------- */

	public static function alt_body( $m ) {
		if ( '' !== self::$alt ) {
			$m->AltBody = self::$alt;
		}
	}

	private static function sent_last_day() {
		global $wpdb;
		$t = self::table();
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$t} WHERE status='sent' AND sent_at > %d", time() - DAY_IN_SECONDS ) ); // phpcs:ignore
	}

	private static function deliver( $r, &$err ) {
		$err = '';
		$cap = static function ( $e ) use ( &$err ) {
			$err = is_wp_error( $e ) ? $e->get_error_message() : 'mail failed';
		};
		$name = static function () { return 'My Rishta Pakistan'; };
		$addr = static function () { return 'noreply@myrishta.pk'; };
		$hdr  = json_decode( (string) $r->headers, true );
		$hdr  = is_array( $hdr ) ? $hdr : array();
		$html = ! empty( $r->html );
		$ct   = static function () { return 'text/html'; };
		add_action( 'wp_mail_failed', $cap );
		add_filter( 'wp_mail_from_name', $name );
		add_filter( 'wp_mail_from', $addr );
		if ( $html ) {
			add_filter( 'wp_mail_content_type', $ct );
			self::$alt = (string) $r->body;
		}
		$ok = wp_mail( $r->to_email, $r->subject, $html ? $r->html : $r->body, $hdr );
		self::$alt = '';
		if ( $html ) {
			remove_filter( 'wp_mail_content_type', $ct );
		}
		remove_filter( 'wp_mail_from_name', $name );
		remove_filter( 'wp_mail_from', $addr );
		remove_action( 'wp_mail_failed', $cap );
		if ( ! $ok && '' === $err ) {
			$err = 'mail failed';
		}
		return (bool) $ok;
	}

	/** Send due emails. Returns how many were sent. */
	public static function run( $force = false ) {
		global $wpdb;
		self::install();
		if ( get_transient( 'mrsh_mailq_lock' ) ) {
			return 0;
		}
		set_transient( 'mrsh_mailq_lock', 1, 240 );
		$s     = self::get();
		$t     = self::table();
		$room  = ( class_exists( 'MRSH_Relay' ) && MRSH_Relay::on() ) ? MRSH_Relay::room() : max( 0, (int) $s['per_day'] - self::sent_last_day() );
		$limit = min( (int) $s['per_run'], $room );
		$sent  = 0;
		if ( $limit > 0 ) {
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$t} WHERE status='queued' AND next_try <= %d ORDER BY id ASC LIMIT %d", time(), $limit ) ); // phpcs:ignore
			$back = array( 600, 3600, 21600, 86400 );
			foreach ( $rows as $r ) {
				$err = '';
				if ( self::deliver( $r, $err ) ) {
					$wpdb->update( $t, array( 'status' => 'sent', 'sent_at' => time(), 'tries' => (int) $r->tries + 1, 'err' => '' ), array( 'id' => (int) $r->id ) ); // phpcs:ignore
					++$sent;
					continue;
				}
				$tries = (int) $r->tries + 1;
				$bad   = (bool) preg_match( '/user unknown|does not exist|no such user|mailbox unavailable|invalid recipient|recipient (address )?rejected|\b550\b|5\.1\.1/i', $err );
				if ( $bad ) {
					$wpdb->update( $t, array( 'status' => 'bad', 'tries' => $tries, 'err' => mb_substr( $err, 0, 250 ) ), array( 'id' => (int) $r->id ) ); // phpcs:ignore
					if ( (int) $r->uid ) {
						update_user_meta( (int) $r->uid, 'mrsh_mail_bad', time() );
					}
				} elseif ( $tries >= (int) $s['max_tries'] ) {
					$wpdb->update( $t, array( 'status' => 'failed', 'tries' => $tries, 'err' => mb_substr( $err, 0, 250 ) ), array( 'id' => (int) $r->id ) ); // phpcs:ignore
				} else {
					$wpdb->update( $t, array( 'tries' => $tries, 'err' => mb_substr( $err, 0, 250 ), 'next_try' => time() + $back[ min( $tries - 1, 3 ) ] ), array( 'id' => (int) $r->id ) ); // phpcs:ignore
				}
			}
		}
		delete_transient( 'mrsh_mailq_lock' );
		return $sent;
	}

	/* ---------- admin ---------- */

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Email queue', 'Email queue', 'manage_options', 'mrsh-mailq', array( __CLASS__, 'page' ) );
	}

	private static function back( $m ) {
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-mailq&msg=' . rawurlencode( $m ) ) );
		exit;
	}

	private static function guard( $a ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_mailq_' . $a );
	}

	public static function act_save() {
		self::guard( 'save' );
		$in = isset( $_POST['q'] ) && is_array( $_POST['q'] ) ? wp_unslash( $_POST['q'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		update_option( self::OPT, array(
			'per_run'   => max( 1, min( 30, (int) ( $in['per_run'] ?? 10 ) ) ),
			'per_day'   => max( 10, min( 500, (int) ( $in['per_day'] ?? 150 ) ) ),
			'max_tries' => max( 1, min( 8, (int) ( $in['max_tries'] ?? 5 ) ) ),
		), false );
		self::back( 'Saved.' );
	}

	public static function act_run_now() {
		self::guard( 'run_now' );
		self::back( 'Sent ' . (int) self::run( true ) . ' email(s) now.' );
	}

	/** Put failed emails back in the queue (used by the Autopilot). Returns how many. */
	public static function requeue_failed() {
		global $wpdb;
		$t = self::table();
		return (int) $wpdb->query( "UPDATE {$t} SET status='queued', tries=0, next_try=" . time() . " WHERE status='failed' AND created > " . ( time() - 3 * DAY_IN_SECONDS ) ); // phpcs:ignore WordPress.DB
	}

	public static function failed_count() {
		global $wpdb;
		$t = self::table();
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t} WHERE status='failed'" ); // phpcs:ignore WordPress.DB
	}

	public static function act_retry() {
		self::guard( 'retry' );
		global $wpdb;
		$t = self::table();
		$n = (int) $wpdb->query( "UPDATE {$t} SET status='queued', tries=0, next_try=" . time() . " WHERE status='failed'" ); // phpcs:ignore
		self::back( $n . ' failed email(s) put back in the queue.' );
	}

	public static function act_purge() {
		self::guard( 'purge' );
		global $wpdb;
		$t = self::table();
		$n = (int) $wpdb->query( $wpdb->prepare( "DELETE FROM {$t} WHERE status IN ('sent','bad') AND created < %d", time() - 30 * DAY_IN_SECONDS ) ); // phpcs:ignore
		self::back( $n . ' old record(s) removed.' );
	}

	public static function act_test() {
		self::guard( 'test' );
		$u  = wp_get_current_user();
		$id = self::add( $u->user_email, 'My Rishta queue test', "This email went through the My Rishta email queue.\n\nIf you can read it, the queue, the mail settings and the sender all work.", array( 'kind' => 'test', 'uid' => 0 ) );
		$n  = self::run( true );
		self::back( $id ? ( $n ? 'Test sent to ' . $u->user_email . '. Check the inbox and the spam folder.' : 'Test queued. It will be sent in a few minutes, or press "Send batch now".' ) : 'The test could not be queued.' );
	}

	private static function dns( $name, $type, $needle ) {
		if ( ! function_exists( 'dns_get_record' ) ) {
			return null;
		}
		$r = @dns_get_record( $name, $type ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		if ( ! is_array( $r ) ) {
			return null;
		}
		foreach ( $r as $x ) {
			$v = $x['txt'] ?? ( $x['target'] ?? '' );
			if ( false !== stripos( (string) $v, $needle ) ) {
				return (string) $v;
			}
		}
		return false;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		global $wpdb;
		self::install();
		$t  = self::table();
		$s  = self::get();
		$ap = esc_url( admin_url( 'admin-post.php' ) );
		$f  = static function ( $a ) {
			return '<input type="hidden" name="action" value="mrsh_mailq_' . $a . '">' . wp_nonce_field( 'mrsh_mailq_' . $a, '_wpnonce', true, false );
		};
		$c = array( 'queued' => 0, 'sent' => 0, 'failed' => 0, 'bad' => 0 );
		foreach ( (array) $wpdb->get_results( "SELECT status, COUNT(*) n FROM {$t} GROUP BY status" ) as $r ) { // phpcs:ignore
			$c[ $r->status ] = (int) $r->n;
		}
		echo '<div class="wrap"><h1>Email queue</h1><p>Member emails wait here and are sent a few at a time. A failed email is tried again, so nobody is missed.</p>';
		if ( isset( $_GET['msg'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			echo '<div class="notice notice-info is-dismissible"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['msg'] ) ) ) . '</p></div>';
		}
		echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:14px 16px;max-width:760px;margin:12px 0"><b>Now</b><br>Waiting: <b>' . (int) $c['queued'] . '</b> &nbsp;|&nbsp; Sent: <b>' . (int) $c['sent'] . '</b> (last 24 h: ' . (int) self::sent_last_day() . ' of ' . (int) $s['per_day'] . ') &nbsp;|&nbsp; Failed: <b>' . (int) $c['failed'] . '</b> &nbsp;|&nbsp; Address does not exist: <b>' . (int) $c['bad'] . '</b></div>';

		$spf   = self::dns( 'myrishta.pk', DNS_TXT, 'v=spf1' );
		$dmarc = self::dns( '_dmarc.myrishta.pk', DNS_TXT, 'v=DMARC1' );
		$dkim  = self::dns( 'hostingermail-a._domainkey.myrishta.pk', DNS_CNAME, 'dkim' );
		$row   = static function ( $name, $v, $help ) {
			$st = null === $v ? '<span style="color:#666">could not check</span>' : ( $v ? '<span style="color:#00a32a">OK</span>' : '<span style="color:#d63638">missing</span>' );
			return '<tr><td><b>' . esc_html( $name ) . '</b></td><td>' . $st . '</td><td class="description">' . esc_html( $help ) . ( is_string( $v ) ? ' <code>' . esc_html( mb_substr( $v, 0, 90 ) ) . '</code>' : '' ) . '</td></tr>';
		};
		echo '<h2>Spam protection check (myrishta.pk)</h2><table class="widefat striped" style="max-width:760px"><tbody>'
			. $row( 'SPF', $spf, 'Says which servers may send mail for your domain.' )
			. $row( 'DKIM', $dkim, 'A digital signature added by Hostinger to every email.' )
			. $row( 'DMARC', $dmarc, 'Tells inboxes what to do with fake mail. "p=none" is fine to start; "p=quarantine" is stricter once all mail is passing.' )
			. '</tbody></table><p class="description" style="max-width:760px">Also built in: HTML plus plain-text copy, one real sender mailbox, one-click unsubscribe, skipping addresses whose domain cannot receive mail, no retry for addresses that do not exist, and sending limits.</p>';

		echo '<form method="post" action="' . $ap . '">' . $f( 'save' ) . '<table class="form-table">';
		echo '<tr><th>Emails per run</th><td><input type="number" min="1" max="30" name="q[per_run]" value="' . (int) $s['per_run'] . '" style="width:70px"> <span class="description">A run happens every 5 minutes.</span></td></tr>';
		echo '<tr><th>Most emails per day</th><td><input type="number" min="10" max="500" name="q[per_day]" value="' . (int) $s['per_day'] . '" style="width:80px"> <span class="description">Keeps your domain reputation clean. Raise it slowly.</span></td></tr>';
		echo '<tr><th>Tries before "failed"</th><td><input type="number" min="1" max="8" name="q[max_tries]" value="' . (int) $s['max_tries'] . '" style="width:70px"></td></tr>';
		echo '</table><p><button class="button button-primary">Save</button></p></form>';
		echo '<p><form method="post" action="' . $ap . '" style="display:inline">' . $f( 'test' ) . '<button class="button">Send a test to me</button></form> '
			. '<form method="post" action="' . $ap . '" style="display:inline">' . $f( 'run_now' ) . '<button class="button">Send batch now</button></form> '
			. '<form method="post" action="' . $ap . '" style="display:inline">' . $f( 'retry' ) . '<button class="button">Retry failed</button></form> '
			. '<form method="post" action="' . $ap . '" style="display:inline" onsubmit="return confirm(\'Remove sent records older than 30 days?\')">' . $f( 'purge' ) . '<button class="button">Clean old records</button></form></p>';

		$rows = $wpdb->get_results( "SELECT id, to_email, subject, kind, status, tries, created, sent_at, err FROM {$t} ORDER BY id DESC LIMIT 25" ); // phpcs:ignore
		if ( $rows ) {
			echo '<h2>Latest emails</h2><table class="widefat striped" style="max-width:980px"><thead><tr><th>When</th><th>To</th><th>Subject</th><th>Status</th><th>Tries</th><th>Note</th></tr></thead><tbody>';
			foreach ( $rows as $r ) {
				$em = $r->to_email;
				$em = substr( $em, 0, 2 ) . '***' . substr( $em, (int) strpos( $em, '@' ) );
				echo '<tr><td>' . esc_html( wp_date( 'j M H:i', (int) $r->created ) ) . '</td><td>' . esc_html( $em ) . '</td><td>' . esc_html( $r->subject ) . '</td><td>' . esc_html( $r->status ) . '</td><td>' . (int) $r->tries . '</td><td>' . esc_html( $r->err ) . '</td></tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';
	}
}
