<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Fills the site's location list (taxonomy "country": country > city) with more cities and with the countries Pakistani
 * families live in, puts Pakistan first in every country list, and helps the location form pick the visitor's city.
 * Runs once per DATA_VERSION, only ever ADDS missing names, never changes or deletes existing ones.
 */
class MRSH_Data {

	const DATA_VERSION = 2;
	const OPT          = 'mrsh_data_done';
	const TAX          = 'country';

	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'maybe_run' ) );
		add_filter( 'get_terms', array( __CLASS__, 'pakistan_first' ), 20, 4 );
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'wp_footer', array( __CLASS__, 'city_js' ), 40 );
		add_action( 'wp_footer', array( __CLASS__, 'easy_js' ), 41 );
	}

	/** Extra places. Keys are countries; the list is what families commonly need. */
	private static function data() {
		return array(
			'Pakistan' => array( 'Rawalpindi', 'Islamabad', 'Sheikhupura', 'Gwadar', 'Wah Cantonment', 'Lahore Cantonment', 'Kotri', 'Sanghar', 'Mithi', 'Matiari', 'Nowshera', 'Swat', 'Buner', 'Malakand', 'Lower Dir', 'Upper Dir', 'Kohistan', 'Shangla', 'Khushab', 'Bhimber', 'Hunza', 'Chilas', 'Gahkuch', 'Astore', 'Mastung', 'Nushki', 'Chagai', 'Lasbela', 'Ziarat', 'Kalat', 'Jaffarabad', 'Dalbandin', 'Bela', 'Hattian Bala', 'Neelum', 'Sudhnoti', 'Pind Dadan Khan', 'Kallar Kahar', 'Jauharabad', 'Isa Khel', 'Kahna', 'Ferozewala', 'Shahpur', 'Ahmadpur East', 'Ahmadpur Sial', 'Chishtian', 'Karor Lal Esan', 'Gilgit-Baltistan', 'Azad Kashmir', 'Khyber Pakhtunkhwa', 'Karachi Central', 'Gulshan-e-Iqbal Karachi', 'Defence Karachi', 'DHA Lahore', 'Bahria Town', 'Johar Town Lahore', 'Gulberg Lahore', 'Model Town Lahore', 'Wapda Town Lahore', 'Hayatabad Peshawar', 'Satellite Town Rawalpindi', 'Saddar Rawalpindi', 'F-6 Islamabad', 'G-11 Islamabad', 'E-11 Islamabad', 'I-8 Islamabad', 'Sahiwal Cantonment', 'Kamra', 'Chakri', 'Gujar Khan' ),
			'United Kingdom' => array( 'London', 'Birmingham', 'Manchester', 'Bradford', 'Glasgow', 'Leeds', 'Liverpool', 'Sheffield', 'Edinburgh', 'Leicester', 'Nottingham', 'Bristol', 'Cardiff', 'Oldham', 'Luton', 'Slough', 'Walsall', 'Wolverhampton', 'Coventry', 'Derby', 'Blackburn', 'Rochdale', 'Bolton', 'Huddersfield', 'Dewsbury', 'Peterborough', 'Reading', 'Newcastle', 'Southampton', 'Belfast', 'Aberdeen', 'Dundee', 'Stoke-on-Trent', 'Preston', 'Burnley', 'Keighley', 'High Wycombe', 'Crawley', 'Watford', 'Milton Keynes', 'Northampton', 'Oxford', 'Cambridge', 'Ilford', 'Southall', 'Wembley', 'Croydon', 'Harrow' ),
			'United States' => array( 'New York City', 'Houston', 'Chicago', 'Los Angeles', 'Dallas', 'Atlanta', 'Washington DC', 'Philadelphia', 'San Francisco', 'San Jose', 'Boston', 'Detroit', 'Seattle', 'Phoenix', 'Austin', 'San Antonio', 'Miami', 'Orlando', 'Tampa', 'Charlotte', 'Columbus', 'Minneapolis', 'Baltimore', 'Jersey City', 'Brooklyn', 'Queens', 'Plano', 'Irving', 'Sugar Land', 'Fremont', 'Edison', 'Staten Island', 'Newark', 'Indianapolis', 'Cleveland', 'Pittsburgh', 'Las Vegas', 'Denver', 'San Diego', 'Sacramento', 'Fairfax' ),
			'Canada' => array( 'Toronto', 'Mississauga', 'Brampton', 'Markham', 'Vaughan', 'Scarborough', 'Oakville', 'Ottawa', 'Montreal', 'Calgary', 'Edmonton', 'Vancouver', 'Surrey', 'Winnipeg', 'Hamilton', 'Kitchener', 'London Ontario', 'Windsor', 'Halifax', 'Regina', 'Saskatoon', 'Burnaby', 'Richmond Hill', 'Ajax', 'Pickering', 'Milton', 'Waterloo' ),
			'United Arab Emirates' => array( 'Dubai', 'Abu Dhabi', 'Sharjah', 'Al Ain', 'Ajman', 'Ras Al Khaimah', 'Fujairah', 'Umm Al Quwain', 'Jebel Ali', 'Khor Fakkan', 'Dibba' ),
			'Saudi Arabia' => array( 'Riyadh', 'Jeddah', 'Makkah', 'Madinah', 'Dammam', 'Al Khobar', 'Dhahran', 'Jubail', 'Yanbu', 'Taif', 'Tabuk', 'Abha', 'Buraidah', 'Hail', 'Najran', 'Jazan', 'Khamis Mushait', 'Hofuf', 'Al Qatif', 'Qassim' ),
			'Qatar' => array( 'Doha', 'Al Rayyan', 'Al Wakrah', 'Al Khor', 'Umm Salal', 'Lusail' ),
			'Kuwait' => array( 'Kuwait City', 'Hawalli', 'Salmiya', 'Farwaniya', 'Jahra', 'Ahmadi', 'Fahaheel', 'Mangaf' ),
			'Oman' => array( 'Muscat', 'Salalah', 'Sohar', 'Nizwa', 'Sur', 'Seeb', 'Barka', 'Ibri' ),
			'Bahrain' => array( 'Manama', 'Muharraq', 'Riffa', 'Hamad Town', 'Isa Town', 'Sitra' ),
			'Australia' => array( 'Sydney', 'Melbourne', 'Brisbane', 'Perth', 'Adelaide', 'Canberra', 'Gold Coast', 'Newcastle', 'Wollongong', 'Hobart', 'Darwin' ),
			'New Zealand' => array( 'Auckland', 'Wellington', 'Christchurch', 'Hamilton', 'Dunedin' ),
			'Germany' => array( 'Berlin', 'Hamburg', 'Munich', 'Frankfurt', 'Cologne', 'Dusseldorf', 'Stuttgart', 'Dortmund', 'Essen', 'Bremen', 'Hanover', 'Leipzig' ),
			'France' => array( 'Paris', 'Lyon', 'Marseille', 'Toulouse', 'Nice', 'Lille', 'Bordeaux', 'Strasbourg' ),
			'Italy' => array( 'Rome', 'Milan', 'Naples', 'Turin', 'Brescia', 'Bologna', 'Florence', 'Venice', 'Genoa', 'Verona' ),
			'Spain' => array( 'Madrid', 'Barcelona', 'Valencia', 'Seville', 'Malaga', 'Bilbao' ),
			'Netherlands' => array( 'Amsterdam', 'Rotterdam', 'The Hague', 'Utrecht', 'Eindhoven' ),
			'Belgium' => array( 'Brussels', 'Antwerp', 'Ghent', 'Liege' ),
			'Norway' => array( 'Oslo', 'Bergen', 'Trondheim', 'Stavanger', 'Drammen' ),
			'Sweden' => array( 'Stockholm', 'Gothenburg', 'Malmo', 'Uppsala' ),
			'Denmark' => array( 'Copenhagen', 'Aarhus', 'Odense', 'Aalborg' ),
			'Finland' => array( 'Helsinki', 'Espoo', 'Tampere', 'Turku' ),
			'Ireland' => array( 'Dublin', 'Cork', 'Galway', 'Limerick' ),
			'Switzerland' => array( 'Zurich', 'Geneva', 'Basel', 'Bern' ),
			'Austria' => array( 'Vienna', 'Graz', 'Salzburg', 'Linz' ),
			'Greece' => array( 'Athens', 'Thessaloniki' ),
			'Turkey' => array( 'Istanbul', 'Ankara', 'Izmir', 'Bursa', 'Antalya' ),
			'Malaysia' => array( 'Kuala Lumpur', 'Johor Bahru', 'Penang', 'Ipoh', 'Shah Alam', 'Petaling Jaya', 'Kota Kinabalu' ),
			'Singapore' => array( 'Singapore' ),
			'Hong Kong' => array( 'Hong Kong' ),
			'Japan' => array( 'Tokyo', 'Osaka', 'Yokohama', 'Nagoya' ),
			'South Korea' => array( 'Seoul', 'Busan', 'Incheon' ),
			'Thailand' => array( 'Bangkok', 'Chiang Mai', 'Phuket' ),
			'Afghanistan' => array( 'Kabul', 'Kandahar', 'Herat', 'Mazar-i-Sharif', 'Jalalabad' ),
			'Iran' => array( 'Tehran', 'Mashhad', 'Qom', 'Isfahan', 'Shiraz' ),
			'Iraq' => array( 'Baghdad', 'Najaf', 'Karbala', 'Basra' ),
			'Jordan' => array( 'Amman', 'Zarqa', 'Irbid' ),
			'Egypt' => array( 'Cairo', 'Alexandria', 'Giza' ),
			'Sri Lanka' => array( 'Colombo', 'Kandy', 'Galle' ),
			'Nepal' => array( 'Kathmandu', 'Pokhara' ),
			'South Africa' => array( 'Johannesburg', 'Cape Town', 'Durban', 'Pretoria' ),
			'Kenya' => array( 'Nairobi', 'Mombasa' ),
			'Nigeria' => array( 'Lagos', 'Abuja' ),
			'Mauritius' => array( 'Port Louis' ),
			'Brazil' => array( 'Sao Paulo', 'Rio de Janeiro' ),
			'Maldives' => array( 'Male' ),
			'Indonesia' => array( 'Jakarta', 'Surabaya' ),
			'Bangladesh' => array( 'Dhaka', 'Chittagong', 'Sylhet', 'Khulna' ),
			'India' => array( 'Delhi', 'Mumbai', 'Hyderabad', 'Lucknow', 'Kolkata', 'Bengaluru', 'Chennai', 'Ahmedabad' ),
			'China' => array( 'Beijing', 'Shanghai', 'Guangzhou', 'Shenzhen', 'Urumqi' ),
			'Azerbaijan' => array( 'Baku' ),
		);
	}

	private static function norm( $s ) {
		return strtolower( preg_replace( '/[^a-z0-9]+/', '', remove_accents( (string) $s ) ) );
	}

	/** Compact picture of a stored settings value: keys, types and short samples (long text cut). */
	private static function shape( $v, $d = 0 ) {
		if ( is_array( $v ) ) {
			if ( $d > 3 ) {
				return 'array(' . count( $v ) . ')';
			}
			$o = array();
			$n = 0;
			foreach ( $v as $k => $x ) {
				if ( ++$n > 40 ) {
					$o['...'] = count( $v ) . ' items';
					break;
				}
				$o[ $k ] = self::shape( $x, $d + 1 );
			}
			return $o;
		}
		return is_string( $v ) ? ( strlen( $v ) > 160 ? substr( $v, 0, 160 ) . '…(' . strlen( $v ) . ')' : $v ) : $v;
	}

	public static function maybe_run( $force = false ) {
		if ( current_user_can( 'manage_options' ) ) {
			self::refine();
			self::interests();
		}
		if ( ! current_user_can( 'manage_options' ) || (int) get_option( self::OPT, 0 ) >= self::DATA_VERSION || ! taxonomy_exists( self::TAX ) ) {
			return;
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 120 ); // phpcs:ignore
		}
		$added = 0;
		$log   = array();
		wp_defer_term_counting( true );
		$top = get_terms( array( 'taxonomy' => self::TAX, 'parent' => 0, 'hide_empty' => false, 'fields' => 'all' ) );
		$map = array();
		foreach ( is_wp_error( $top ) ? array() : $top as $t ) {
			$map[ self::norm( $t->name ) ] = (int) $t->term_id;
		}
		foreach ( self::data() as $country => $cities ) {
			$k = self::norm( $country );
			if ( ! isset( $map[ $k ] ) ) {
				$r = wp_insert_term( $country, self::TAX, array( 'parent' => 0 ) );
				if ( is_wp_error( $r ) ) {
					$log[] = 'Could not add country ' . $country;
					continue;
				}
				$map[ $k ] = (int) $r['term_id'];
				++$added;
			}
			$pid  = $map[ $k ];
			$have = array();
			foreach ( get_terms( array( 'taxonomy' => self::TAX, 'parent' => $pid, 'hide_empty' => false, 'fields' => 'names' ) ) as $n ) {
				$have[ self::norm( $n ) ] = 1;
			}
			foreach ( $cities as $c ) {
				if ( isset( $have[ self::norm( $c ) ] ) ) {
					continue;
				}
				$r = wp_insert_term( $c, self::TAX, array( 'parent' => $pid ) );
				if ( ! is_wp_error( $r ) ) {
					++$added;
					$have[ self::norm( $c ) ] = 1;
				}
			}
		}
		wp_defer_term_counting( false );
		update_option( self::OPT, self::DATA_VERSION, false );
		update_option( 'mrsh_data_log', array( 'time' => time(), 'added' => $added, 'notes' => $log ), false );
		delete_transient( 'mrsh_people' );
	}


	const REFINE = 3;

	/** Clean, complete dropdown lists for the profile form. Old values stay valid. Original saved once in mrsh_cfields_backup. */
	public static function refine() {
		if ( (int) get_option( 'mrsh_refine_done', 0 ) >= self::REFINE ) {
			return;
		}
		$cf = get_option( 'cfields' );
		if ( ! is_array( $cf ) || empty( $cf['dbkey'] ) || empty( $cf['values'] ) ) {
			return;
		}
		if ( false === get_option( 'mrsh_cfields_backup' ) ) {
			add_option( 'mrsh_cfields_backup', $cf, '', 'no' );
		}
		$lists = array(
			'custom-19'   => array('Prefer to not Say','Suni','Barelvi','Deobandi','Al Hadees','Shia','Ismaili','Sufi','Just Muslim','Religious','Other'),
			'custom-2322' => array('Primary (1-7)','Middle (8-10)','Matric (10)','O-Levels','FA,FSe,ICS,ICom,DBA,D.Com.etc','Intermediate (FA / FSc / ICS / ICom)','A-Levels','Diploma (DAE / Technical)','Certificate / Vocational Training','BA/BSC ADE Associate Degree','Bachelor Degree','BA / BSc (2 years)','BS (4 years)','BBA','BCom','BSc Engineering','BE / BTech','MBBS','BDS','Pharm-D','DPT (Physiotherapy)','BSc Nursing','LLB','BEd','BSc Agriculture','BCS / BSCS / BSIT','Master Degree','MA','MSc','MBA','MCom','MPhil / MS','LLM','MEd','MSc Engineering','Doctoral Degree','PhD','FCPS / MD','CA / ACCA / CFA','Hafiz-e-Quran','Dars-e-Nizami / Aalim / Mufti','Religious education','No formal education','Other'),
			'custom-24'   => array('Prefer to not say','Government Employee','Private Sector Employee','Semi-Government / Autonomous Body','Doctor','Surgeon','Dentist','Pharmacist','Nurse','Medical / Lab Technician','Physiotherapist','Software Engineer / Developer','IT Professional','Civil Engineer','Electrical Engineer','Mechanical Engineer','Other Engineer','Architect','Teacher','Lecturer / Professor','Principal / Education Manager','Lawyer / Advocate','Judge','Accountant','Chartered Accountant','Banker','Finance Professional','Business Owner','Shopkeeper / Trader','Farmer / Landowner','Army Officer','Army Soldier / JCO','Navy','Air Force','Police Officer','Civil Servant (CSS / PMS)','Pilot','Cabin Crew','Journalist / Media','Designer / Artist','Fashion Designer','Interior Designer','Photographer','Chef / Hotel Industry','Driver','Electrician / Technician','Mechanic','Tailor','Beauty / Salon Professional','Marketing / Sales','Manager','Freelancer','Self Employed','Overseas Worker (Gulf)','Researcher / Scientist','Imam / Religious Scholar','Hafiz / Quran Teacher','Social Worker / NGO','Student','Housewife / Homemaker','Retired','No Job','Other'),
			'key2'        => array('Pakistani','Punjabi','Sindhi','Pashtun / Pathan','Baloch','Muhajir','Kashmiri','Saraiki','Hindko','Chitrali','Gilgiti / Baltistani','Hazara','Brahui','Memon','Bengali','Arab','Asian','Indian','American','European','African','Persian','Turkish','Mixed','Other'),
		);
		$castes = array('Abbasi','Abidi','Abro','Achakzai','Afridi','Agha','Ahanger','Ahmadzai','Akakhel','Alizai','Alpial','Alvi','Ansari','Arain','Askari','Aulakh','Awan','Bahmani','Baig','Baizai','Bajwa','Baloch','Balti','Bangash','Bangulzai','Bannuchi','Barakzai','Bhandara','Bhanghar','Bhangu','Bhat','Bhatia','Bhatti','Bhittani','Bhurgri','Bhutta','Bhutto','Bizenjo','Bohra','Bokhari','Bosan','Brahui','Brohi','Bugti','Bukhari','Burusho','Butt','Buzdar','Chachar','Chadhar','Chandio','Channa','Chattha','Chaudhry','Cheema','Cheena','Chhina','Chishti','Chitrali','Dahri','Dar','Daudzai','Daultana','Dawar','Dayo','Dehlvi','Dhillon','Dogar','Dombki','Domki','Dreshak','Durrani','Farooqi','Gabol','Gakhar','Gakkhar','Ganai','Gandapur','Gardezi','Ghakhar','Ghanghro','Ghauri','Ghilzai','Ghumman','Gigyani','Gilani','Gill','Gondal','Gujjar','Gurchani','Gurmani','Hakro','Halepoto','Hans','Hashmi','Hazara','Hijazi','Hindko','Hiraj','Hotak','Hundal','Hunzai','Hussaini','Jadoon','Jafri','Jakhrani','Jamali','Janjua','Jatoi','Jatt','Jhandir','Joiya','Junejo','Kakar','Kalash','Kalhoro','Kalyar','Kamboh','Kang','Kashmiri','Kasi','Kasuri','Kathia','Kazmi','Kehar','Khalil','Khan','Kharal','Kharral','Khattak','Khawaja','Khetran','Khichi','Khoja','Khokhar','Khosa','Khuhro','Kiani','Kirmani','Korai','Kuki','Kundi','Kurd','Kutchi','Laghari','Lak','Langah','Lango','Lashari','Leghari','Lodhi','Lone','Lucknowi','Lund','Maan','Magsi','Mahar','Mahay','Mahi','Malik','Mallah','Mandokhel','Mangrio','Marri','Marwat','Mashhadi','Mattoo','Mazari','Mehsud','Mekan','Memon','Mengal','Mian','Minhas','Mir','Mirani','Mirza','Mohammadzai','Mohmand','Mughal','Muhajir','Muhammadzai','Mullagori','Mushwani','Nagra','Nakai','Naqvi','Naru','Niazi','Nizamani','Noon','Orakzai','Panhwar','Pannu','Pashtun','Pathan','Pirzada','Popalzai','Punjabi','Qazi','Qureshi','Raisani','Rajpar','Rajput','Rakhshani','Rana','Randhawa','Ranghar','Ranjha','Rather','Rind','Rizvi','Rokhri','Sabzwari','Safi','Sahi','Sahito','Samma','Samra','Sandhu','Sandila','Sanjrani','Saraiki','Sargana','Sayyid','Shah','Shar','Sheikh','Sherani','Shina','Shinwari','Shirazi','Sial','Siddiqui','Sidhu','Sindhi','Sipra','Siyal','Solangi','Soomro','Sulaimankhel','Sulehria','Sulemani','Swati','Syal','Syed','Talpur','Tanoli','Tarar','Tareen','Tarin','Taunsvi','Thaheem','Tirmizi','Tiwana','Tunio','Turi','Umrani','Unar','Usmani','Ustrana','Utmankhel','Utmanzai','Varaich','Virk','Wahla','Wains','Wakhi','Wani','Warraich','Warriach','Wassan','Wattoo','Wazir','Yousafzai','Zaidi','Zardari','Zazai','Zehri');
		$fix = array( 'Satying Saprate' => 'Staying Separate', 'Satying With Mother' => 'Staying With Mother', 'Lond' => 'Long', 'Saikh' => 'Sikh' );
		foreach ( $cf['dbkey'] as $i => $key ) {
			if ( ! isset( $cf['values'][ $i ] ) ) {
				continue;
			}
			$cur = preg_split( '/\r\n|\n|\r/', (string) $cf['values'][ $i ] );
			$cur = array_values( array_filter( array_map( function ( $x ) {
				return trim( str_replace( "\xC2\xA0", ' ', $x ) );
			}, $cur ), 'strlen' ) );
			if ( isset( $lists[ $key ] ) ) {
				$new = $lists[ $key ];
			} elseif ( 'custom-20' === $key ) {
				$seen = array();
				$new  = array();
				foreach ( array_merge( $cur, $castes ) as $c ) {
					$k = self::norm( $c );
					if ( '' !== $k && ! isset( $seen[ $k ] ) && ! in_array( $k, array( 'other', 'others', 'prefernottosay' ), true ) ) {
						$seen[ $k ] = 1;
						$new[]      = $c;
					}
				}
				natcasesort( $new );
				$new   = array_values( $new );
				$new[] = 'Others';
				$new[] = 'Prefer not to say';
			} elseif ( 'custom-18' === $key ) {
				$new = array( 'Muslims-Islam', 'Christianity', 'Hinduism', 'Sikhism', 'Others' );
			} elseif ( 'custom-16' === $key ) {
				$new = array( 'Prefer to not say', 'None', '1', '2', '3 or Above' );
			} elseif ( 'custom-17' === $key ) {
				$new = array( 'Prefer to not say', 'Staying with me', 'Staying With Mother', 'Staying With Father', 'Staying Separate', 'Staying With Grandparents' );
			} elseif ( 'custom-13' === $key ) {
				$new = array( 'Self', 'Parents', 'Sibling', 'Relative', 'Friend', 'Guardian' );
			} elseif ( 'key6' === $key ) {
				$new = array_values( array_unique( array_merge( $cur, array( 'Black' ) ) ) );
				sort( $new );
			} elseif ( 'key8' === $key ) {
				$new = array_values( array_unique( array_merge( $cur, array( 'Athletic', 'Muscular' ) ) ) );
				sort( $new );
			} elseif ( 'key439' === $key ) {
				$new = array_map( function ( $x ) use ( $fix ) {
					return isset( $fix[ $x ] ) ? $fix[ $x ] : $x;
				}, $cur );
			} else {
				continue;
			}
			$cf['values'][ $i ] = implode( "\r\n", $new );
		}
		update_option( 'cfields', $cf );
		// Religion filter on the home page reads this term list: fix the spelling and drop the odd entries.
		if ( taxonomy_exists( 'religion' ) ) {
			foreach ( get_terms( array( 'taxonomy' => 'religion', 'hide_empty' => false ) ) as $t ) {
				if ( ! ( $t instanceof WP_Term ) ) {
					continue;
				}
				$n = strtolower( trim( $t->name ) );
				if ( in_array( $n, array( 'saikh', 'sikh' ), true ) ) {
					wp_update_term( $t->term_id, 'religion', array( 'name' => 'Sikhism', 'slug' => 'sikhism' ) );
				} elseif ( in_array( $n, array( 'tenrikyo', 'animism' ), true ) && 0 === (int) $t->count ) {
					wp_delete_term( $t->term_id, 'religion' );
				}
			}
		}
		update_option( 'mrsh_refine_done', self::REFINE, false );
	}


	/** "My Interests": replace the theme's sample list (bartending, beekeeping...) with real interests. Only removes the known sample names. */
	public static function interests() {
		if ( get_option( 'mrsh_interests_done' ) || ! taxonomy_exists( 'features' ) ) {
			return;
		}
		foreach ( array('Bartending','Becoming A Fitness Instructor','Beekeeping','Being A Handyman','Catering','Coding','Cooking','Decorating Homes','Drive Others Around','Flea Market Shopping','Flipping Items','Graphic Design','Making Music','Making T-Shirts','Performing Stand Up Comedy','Pet Sitting','Playing The Stock Market','Programming','Proofreading And Editing','Refinishing Furniture','Reviewing Things','Starting A YouTube Channel','Tapping Maple Trees','Writing/Blogging') as $n ) {
			$t = get_term_by( 'name', $n, 'features' );
			if ( $t && ! is_wp_error( $t ) ) {
				wp_delete_term( $t->term_id, 'features' );
			}
		}
		foreach ( array('Reading','Quran & Islamic Studies','Prayer & Spirituality','Cooking','Baking','Traditional Food','Travelling','Hiking & Nature','Cricket','Football','Badminton','Gym & Fitness','Walking & Jogging','Swimming','Cycling','Photography','Poetry & Shayari','Writing','Art & Painting','Calligraphy','Gardening','Charity & Social Work','Volunteering','Family Time','Shopping','Fashion & Stitching','Mehndi Design','Home Decoration','Technology','Programming','Video Games','Music','Nasheeds','Movies & Dramas','Learning Languages','Teaching','Business & Entrepreneurship','Driving','Pets','Board Games','History','Current Affairs') as $n ) {
			if ( ! term_exists( $n, 'features' ) ) {
				wp_insert_term( $n, 'features' );
			}
		}
		update_option( 'mrsh_interests_done', 1, false );
	}

	/** Pakistan always first, then the rest A to Z, in every top-level country list. */
	public static function pakistan_first( $terms, $taxonomies, $args, $query ) {
		if ( ! is_array( $terms ) || ! in_array( self::TAX, (array) $taxonomies, true ) || ( isset( $args['fields'] ) && 'all' !== $args['fields'] ) ) {
			return $terms;
		}
		if ( isset( $args['parent'] ) && 0 !== (int) $args['parent'] ) {
			return $terms;
		}
		$first = array();
		$rest  = array();
		foreach ( $terms as $t ) {
			if ( is_object( $t ) && isset( $t->name ) && 'Pakistan' === $t->name && 0 === (int) $t->parent ) {
				$first[] = $t;
			} else {
				$rest[] = $t;
			}
		}
		return $first ? array_merge( $first, $rest ) : $terms;
	}

	public static function routes() {
		register_rest_route( 'mrsh/v1', '/data-status', array(
			'methods'             => 'GET',
			'permission_callback' => function () {
				return current_user_can( 'manage_options' );
			},
			'callback'            => array( __CLASS__, 'status' ),
		) );
	}

	/** Admin only: what was added, and where the caste list is stored (so it can be extended safely). */
	public static function status() {
		global $wpdb;
		self::maybe_run( true );
		$out = array( 'cfields_shape' => self::shape( get_option( 'cfields' ) ), 'version' => (int) get_option( self::OPT, 0 ), 'log' => get_option( 'mrsh_data_log', array() ), 'fields_in' => array() );
		foreach ( array( 'Zardari', 'warlords', 'Master_Degree' ) as $tok ) {
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT option_name, LENGTH(option_value) AS len FROM {$wpdb->options} WHERE option_value LIKE %s LIMIT 10", '%' . $wpdb->esc_like( $tok ) . '%' ), ARRAY_A ); // phpcs:ignore
			foreach ( (array) $rows as $r ) {
				$v   = (string) get_option( $r['option_name'] );
				$pos = strpos( $v, $tok );
				$out['fields_in'][ $tok ][] = array( 'option' => $r['option_name'], 'len' => (int) $r['len'], 'around' => substr( $v, max( 0, $pos - 300 ), 600 ) );
			}
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT post_id, meta_key FROM {$wpdb->postmeta} WHERE meta_value LIKE %s LIMIT 5", '%' . $wpdb->esc_like( $tok ) . '%' ), ARRAY_A ); // phpcs:ignore
			if ( $rows ) {
				$out['fields_in_postmeta'][ $tok ] = $rows;
			}
		}
		$out['countries']         = wp_list_pluck( (array) get_terms( array( 'taxonomy' => self::TAX, 'parent' => 0, 'hide_empty' => false ) ), 'name' );
		return $out;
	}

	/** Easier profile form: type-to-find on the long lists (caste, nationality, study, job) and sensible starting answers. */
	public static function easy_js() {
		if ( is_admin() || ! is_page() ) {
			return;
		}
		$js = <<<'MREASY'
(function(){
  if(window.__mrEasy) return; window.__mrEasy=1;
  var LONG=25;
  function norm(s){return (s||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'');}
  function setDefault(id,val){var s=document.getElementById(id);if(!s||s.value)return;for(var i=0;i<s.options.length;i++){if(s.options[i].value===val){s.selectedIndex=i;s.dispatchEvent(new Event('change',{bubbles:true}));return;}}}
  function enhance(sel){
    if(sel.dataset.mrEasy||sel.options.length<LONG)return; sel.dataset.mrEasy=1;
    var all=[].map.call(sel.options,function(o){return{v:o.value,t:o.text};});
    var box=document.createElement('input');box.type='search';box.placeholder='Type to find…  (کچھ لکھیں)';box.autocomplete='off';
    box.setAttribute('aria-label','Filter list');
    box.style.cssText='display:block;width:100%;margin:0 0 6px;padding:8px 10px;border:1px solid #cbd5e1;border-radius:8px;font-size:14px';
    sel.parentNode.insertBefore(box,sel);
    var shut=function(){sel.removeAttribute('size');};sel.addEventListener('change',shut);sel.addEventListener('click',function(){if(sel.size>1&&sel.value!=='')shut();});sel.addEventListener('keydown',function(e){if(e.key==='Enter'){shut();}});
    box.addEventListener('input',function(){
      var q=norm(box.value.trim()),cur=sel.value,out=[];
      all.forEach(function(o){if(o.v===''||!q||norm(o.t).indexOf(q)>-1||o.v===cur)out.push(o);});
      sel.innerHTML='';out.forEach(function(o){var e=document.createElement('option');e.value=o.v;e.textContent=o.t;if(o.v===cur)e.selected=true;sel.appendChild(e);});
      var ne=out.filter(function(o){return o.v!==''});if(q){sel.size=Math.max(2,Math.min(7,out.length));}else{sel.removeAttribute('size');}
      if(q&&ne.length===1&&!cur){for(var j=0;j<sel.options.length;j++){if(sel.options[j].value===ne[0].v)sel.selectedIndex=j;}sel.dispatchEvent(new Event('change',{bubbles:true}));}
    });
  }

  // ---- Step 1: the "star sign" box is really the marital-status list. Show it as simple one-tap choices. ----
  function maritalChips(){
    var btn=document.getElementById('cataddnew');
    if(!btn||btn.dataset.mrChips)return; btn.dataset.mrChips=1;
    var wrap=btn.parentElement&&btn.parentElement.parentElement; if(!wrap)return;
    var lab=wrap.parentElement&&wrap.parentElement.querySelector('label'); 
    var labs=[].slice.call(document.querySelectorAll('label')).filter(function(l){return /star sign/i.test(l.textContent)});
    labs.forEach(function(l){l.innerHTML='Your marital status <span class="text-danger">*</span>';});
    btn.parentElement.style.display='none';
    var names=['Unmarried','Divorced','Widowed','Separated','Married'];
    var ids={Unmarried:'316',Divorced:'314',Widowed:'315',Separated:'313',Married:'312'};
    var row=document.createElement('div');row.id='mr-marital';row.style.cssText='display:flex;flex-wrap:wrap;gap:8px;margin:8px 0 4px';
    names.forEach(function(n){
      var b=document.createElement('button');b.type='button';b.textContent=n;
      b.style.cssText='padding:10px 16px;border-radius:999px;border:1.5px solid #14532d;background:#fff;color:#14532d;font-size:15px;font-weight:600';
      b.addEventListener('click',function(){
        var f=btn.closest('form')||document.getElementById('formcats')||document.body;
        [].forEach.call(document.querySelectorAll('input[name="form[category][]"]'),function(o){o.remove()});
        var i=document.createElement('input');i.type='hidden';i.name='form[category][]';i.value=ids[n];i.setAttribute('data-catid',ids[n]);f.appendChild(i);
        [].forEach.call(row.children,function(c){c.style.background='#fff';c.style.color='#14532d'});
        b.style.background='#14532d';b.style.color='#fff';
        var s=document.getElementById('reg_field_custom-15');
        if(s){for(var k=0;k<s.options.length;k++){if(s.options[k].value===n){s.selectedIndex=k;break;}}
          var w=document.getElementById('fkeycustom-15');if(w)w.style.display='none';}
      });
      row.appendChild(b);
    });
    btn.parentElement.insertAdjacentElement('afterend',row);
  }
  // ---- Popups: friendlier bottom-sheet look ----
  if(!document.getElementById('mr-popcss')){var st=document.createElement('style');st.id='mr-popcss';st.textContent=
   '.ppt-modal-wrap.show .ppt-modal-item{position:fixed!important;left:0!important;right:0!important;bottom:0!important;top:auto!important;width:100%!important;max-width:520px;margin:0 auto!important;max-height:88vh;height:auto!important;min-height:0!important;overflow:auto;border-radius:20px 20px 0 0!important;padding:20px 18px 28px!important;box-shadow:0 -8px 30px rgba(0,0,0,.25)}'+
   '.ppt-modal-wrap.show .ppt-modal-item select,.ppt-modal-wrap.show .ppt-modal-item input[type=text]{width:100%!important;max-width:none!important;height:50px;font-size:16px;border-radius:12px}'+
   '.ppt-modal-wrap.show .ppt-modal-item .btn-close,.ppt-modal-wrap.show .ppt-modal-item button.btn-primary{width:100%;padding:14px;font-size:16px;font-weight:700;border-radius:12px;margin-top:6px}'+
   '.ppt-modal-wrap.show .ppt-modal-item .fs-md{font-size:20px;font-weight:700}'+
   '.ppt-modal-wrap-overlay{background:rgba(0,0,0,.45)!important}';document.head.appendChild(st);}


  // the popup's close button is a bare "X": make it a clear green "Done"
  function doneBtn(){[].forEach.call(document.querySelectorAll('button,div,a,span'),function(e){
    if(e.children.length===0&&e.textContent.trim()==='X'&&!e.dataset.mrDone){var m=e.closest('[class*=modal]')||e.parentElement;if(!m)return;e.dataset.mrDone=1;e.textContent='Done ✓';var bt=e.closest('button')||e.parentElement;[e,bt].forEach(function(x){x.style.cssText+=';font-weight:700;font-size:16px;color:#fff;background:#14532d;border-radius:12px;border-color:#14532d'});}});}
  new MutationObserver(function(){doneBtn();bilAll()}).observe(document.body,{childList:true,subtree:true});


  // ---- Urdu + English: show both on every list and label (stored values stay English, nothing else changes) ----
  var UR={"Prefer to not Say": "بتانا نہیں چاہتے", "Prefer to not say": "بتانا نہیں چاہتے", "Prefer not to say": "بتانا نہیں چاہتے", "Divorced": "طلاق یافتہ", "Married": "شادی شدہ", "Separated": "علیحدہ", "Unmarried": "غیر شادی شدہ", "Widowed": "بیوہ / رنڈوا", "None": "کوئی نہیں", "1": "1", "2": "2", "3 or Above": "3 یا زیادہ", "Staying with me": "میرے ساتھ", "Staying With Mother": "والدہ کے ساتھ", "Staying With Father": "والد کے ساتھ", "Staying Separate": "علیحدہ رہتے ہیں", "Staying With Grandparents": "دادا دادی/نانا نانی کے ساتھ", "Self": "خود", "Parents": "والدین", "Sibling": "بہن بھائی", "Relative": "رشتہ دار", "Friend": "دوست", "Guardian": "سرپرست", "Muslims-Islam": "اسلام (مسلمان)", "Christianity": "عیسائیت", "Hinduism": "ہندو مت", "Sikhism": "سکھ مت", "Buddhism": "بدھ مت", "Judaism": "یہودیت", "Jainism": "جین مت", "Zoroastrianism": "زرتشت", "Others": "دیگر", "Other": "دیگر", "Suni": "سنی", "Sunni": "سنی", "Barelvi": "بریلوی", "Deobandi": "دیوبندی", "Al Hadees": "اہلِ حدیث", "Shia": "شیعہ", "Ismaili": "اسماعیلی", "Sufi": "صوفی", "Just Muslim": "صرف مسلمان", "Religious": "دیندار", "Primary (1-7)": "پرائمری (1-7)", "Middle (8-10)": "مڈل (8-10)", "Matric (10)": "میٹرک (10)", "O-Levels": "او لیول", "FA,FSe,ICS,ICom,DBA,D.Com.etc": "ایف اے، ایف ایس سی، آئی سی ایس، آئی کام", "Intermediate (FA / FSc / ICS / ICom)": "انٹرمیڈیٹ (ایف اے / ایف ایس سی / آئی سی ایس / آئی کام)", "A-Levels": "اے لیول", "Diploma (DAE / Technical)": "ڈپلومہ (ڈی اے ای / ٹیکنیکل)", "Certificate / Vocational Training": "سرٹیفکیٹ / ہنر مندی", "BA/BSC ADE Associate Degree": "بی اے / بی ایس سی / اے ڈی ای", "Bachelor Degree": "بیچلر ڈگری", "BA / BSc (2 years)": "بی اے / بی ایس سی (2 سال)", "BS (4 years)": "بی ایس (4 سال)", "BBA": "بی بی اے", "BCom": "بی کام", "BSc Engineering": "بی ایس سی انجینئرنگ", "BE / BTech": "بی ای / بی ٹیک", "MBBS": "ایم بی بی ایس", "BDS": "بی ڈی ایس", "Pharm-D": "فارم ڈی", "DPT (Physiotherapy)": "ڈی پی ٹی (فزیوتھراپی)", "BSc Nursing": "بی ایس سی نرسنگ", "LLB": "ایل ایل بی", "BEd": "بی ایڈ", "BSc Agriculture": "بی ایس سی زراعت", "BCS / BSCS / BSIT": "بی سی ایس / بی ایس سی ایس / بی ایس آئی ٹی", "Master Degree": "ماسٹر ڈگری", "MA": "ایم اے", "MSc": "ایم ایس سی", "MBA": "ایم بی اے", "MCom": "ایم کام", "MPhil / MS": "ایم فل / ایم ایس", "LLM": "ایل ایل ایم", "MEd": "ایم ایڈ", "MSc Engineering": "ایم ایس سی انجینئرنگ", "Doctoral Degree": "ڈاکٹریٹ", "PhD": "پی ایچ ڈی", "FCPS / MD": "ایف سی پی ایس / ایم ڈی", "CA / ACCA / CFA": "سی اے / اے سی سی اے / سی ایف اے", "Hafiz-e-Quran": "حافظِ قرآن", "Dars-e-Nizami / Aalim / Mufti": "درسِ نظامی / عالم / مفتی", "Religious education": "دینی تعلیم", "No formal education": "رسمی تعلیم نہیں", "Government Employee": "سرکاری ملازم", "Private Sector Employee": "پرائیویٹ ملازم", "Semi-Government / Autonomous Body": "نیم سرکاری / خودمختار ادارہ", "Doctor": "ڈاکٹر", "Surgeon": "سرجن", "Dentist": "ڈینٹسٹ", "Pharmacist": "فارماسسٹ", "Nurse": "نرس", "Medical / Lab Technician": "میڈیکل / لیب ٹیکنیشن", "Physiotherapist": "فزیوتھراپسٹ", "Software Engineer / Developer": "سافٹ ویئر انجینئر / ڈویلپر", "IT Professional": "آئی ٹی پروفیشنل", "Civil Engineer": "سول انجینئر", "Electrical Engineer": "الیکٹریکل انجینئر", "Mechanical Engineer": "مکینیکل انجینئر", "Other Engineer": "دیگر انجینئر", "Architect": "آرکیٹیکٹ", "Teacher": "استاد / ٹیچر", "Lecturer / Professor": "لیکچرار / پروفیسر", "Principal / Education Manager": "پرنسپل / ایجوکیشن مینیجر", "Lawyer / Advocate": "وکیل", "Judge": "جج", "Accountant": "اکاؤنٹنٹ", "Chartered Accountant": "چارٹرڈ اکاؤنٹنٹ", "Banker": "بینکر", "Finance Professional": "فنانس پروفیشنل", "Business Owner": "کاروباری", "Shopkeeper / Trader": "دکاندار / تاجر", "Farmer / Landowner": "کسان / زمیندار", "Army Officer": "آرمی آفیسر", "Army Soldier / JCO": "فوجی / جے سی او", "Navy": "نیوی", "Air Force": "ایئر فورس", "Police Officer": "پولیس آفیسر", "Civil Servant (CSS / PMS)": "سول سرونٹ (سی ایس ایس / پی ایم ایس)", "Pilot": "پائلٹ", "Cabin Crew": "کیبن کریو", "Journalist / Media": "صحافی / میڈیا", "Designer / Artist": "ڈیزائنر / آرٹسٹ", "Fashion Designer": "فیشن ڈیزائنر", "Interior Designer": "انٹیریئر ڈیزائنر", "Photographer": "فوٹوگرافر", "Chef / Hotel Industry": "شیف / ہوٹل انڈسٹری", "Driver": "ڈرائیور", "Electrician / Technician": "الیکٹریشن / ٹیکنیشن", "Mechanic": "مکینک", "Tailor": "درزی", "Beauty / Salon Professional": "بیوٹی / سیلون", "Marketing / Sales": "مارکیٹنگ / سیلز", "Manager": "مینیجر", "Freelancer": "فری لانسر", "Self Employed": "ذاتی کام", "Overseas Worker (Gulf)": "بیرونِ ملک ملازم (خلیج)", "Researcher / Scientist": "محقق / سائنسدان", "Imam / Religious Scholar": "امام / عالمِ دین", "Hafiz / Quran Teacher": "حافظ / قاری", "Social Worker / NGO": "سماجی کارکن / این جی او", "Student": "طالب علم", "Housewife / Homemaker": "گھریلو خاتون", "Retired": "ریٹائرڈ", "No Job": "بے روزگار", "Pakistani": "پاکستانی", "Punjabi": "پنجابی", "Sindhi": "سندھی", "Pashtun / Pathan": "پشتون / پٹھان", "Baloch": "بلوچ", "Muhajir": "مہاجر", "Kashmiri": "کشمیری", "Saraiki": "سرائیکی", "Hindko": "ہندکو", "Chitrali": "چترالی", "Gilgiti / Baltistani": "گلگتی / بلتستانی", "Hazara": "ہزارہ", "Brahui": "براہوی", "Memon": "میمن", "Bengali": "بنگالی", "Arab": "عرب", "Asian": "ایشیائی", "Indian": "ہندوستانی", "American": "امریکی", "European": "یورپی", "African": "افریقی", "Persian": "ایرانی", "Turkish": "ترک", "Mixed": "مخلوط", "Amber": "عنبری", "Black": "کالا", "Blue": "نیلا", "Brown": "بھورا", "Gray": "سرمئی", "Green": "سبز", "Hazel": "ہیزل", "Blond": "سنہرا", "Red": "سرخ", "A little plump": "تھوڑا بھرا ہوا", "Athletic": "ورزشی", "Average": "درمیانہ", "Big and lovely": "بھرپور", "Muscular": "مضبوط", "Slim": "سمارٹ", "Bald": "گنجا", "Long": "لمبے", "Medium": "درمیانے", "Shaved Head": "منڈھا ہوا سر", "Short": "چھوٹے", "Very Long": "بہت لمبے", "Never": "کبھی نہیں", "Often": "اکثر", "Quit": "چھوڑ دیا", "Rarely": "شاذ و نادر", "Socially": "کبھی کبھار", "Very often": "بہت اکثر", "Straight": "عام", "Pakistan": "پاکستان", "Afghan": "افغان", "Bangladeshi": "بنگلہ دیشی", "British": "برطانوی", "Canadian": "کینیڈین", "Saudi": "سعودی", "Emirati": "اماراتی", "Australian": "آسٹریلوی", "German": "جرمن", "Iranian": "ایرانی", "Qatari": "قطری", "Kuwaiti": "کویتی", "Omani": "عمانی", "Bahraini": "بحرینی", "Malaysian": "ملائیشین", "Chinese": "چینی", "Norwegian": "ناروے", "Swedish": "سویڈش", "Danish": "ڈنمارک", "French": "فرانسیسی", "Italian": "اطالوی", "Spanish": "ہسپانوی", "Dutch": "ڈچ", "Irish": "آئرش", "Egyptian": "مصری", "Jordanian": "اردنی", "Iraqi": "عراقی", "Sri Lankan": "سری لنکن", "Nepalese": "نیپالی", "Abbasi": "عباسی", "Abidi": "عابدی", "Abro": "ابڑو", "Achakzai": "اچکزئی", "Afridi": "آفریدی", "Agha": "آغا", "Alizai": "علیزئی", "Alvi": "علوی", "Ansari": "انصاری", "Arain": "آرائیں", "Askari": "عسکری", "Aulakh": "اولکھ", "Awan": "اعوان", "Bajwa": "باجوہ", "Bangash": "بنگش", "Baig": "بیگ", "Bhatti": "بھٹی", "Bhutto": "بھٹو", "Bhat": "بھٹ", "Bokhari": "بخاری", "Bukhari": "بخاری", "Bugti": "بگٹی", "Butt": "بٹ", "Chaudhry": "چوہدری", "Cheema": "چیمہ", "Chishti": "چشتی", "Dar": "ڈار", "Dogar": "ڈوگر", "Durrani": "درانی", "Farooqi": "فاروقی", "Gakhar": "گکھڑ", "Gardezi": "گردیزی", "Ghumman": "گھمن", "Gilani": "گیلانی", "Gill": "گل", "Gondal": "گوندل", "Gujjar": "گجر", "Hashmi": "ہاشمی", "Hussaini": "حسینی", "Jadoon": "جدون", "Jafri": "جعفری", "Janjua": "جنجوعہ", "Jatoi": "جتوئی", "Jatt": "جٹ", "Junejo": "جونیجو", "Kakar": "کاکڑ", "Kamboh": "کمبوہ", "Kazmi": "کاظمی", "Khan": "خان", "Kharal": "کھرل", "Khattak": "خٹک", "Khokhar": "کھوکھر", "Khosa": "کھوسہ", "Lashari": "لاشاری", "Leghari": "لغاری", "Lodhi": "لودھی", "Lone": "لون", "Mahar": "مہر", "Malik": "ملک", "Marri": "مری", "Mazari": "مزاری", "Mehsud": "محسود", "Mengal": "مینگل", "Mian": "میاں", "Minhas": "منہاس", "Mir": "میر", "Mirza": "مرزا", "Mohmand": "مہمند", "Mughal": "مغل", "Naqvi": "نقوی", "Niazi": "نیازی", "Noon": "نون", "Orakzai": "اورکزئی", "Pathan": "پٹھان", "Pirzada": "پیرزادہ", "Qazi": "قاضی", "Qureshi": "قریشی", "Raisani": "رئیسانی", "Rajput": "راجپوت", "Rana": "رانا", "Randhawa": "رندھاوا", "Rind": "رند", "Rizvi": "رضوی", "Sandhu": "سندھو", "Shah": "شاہ", "Sheikh": "شیخ", "Shinwari": "شنواری", "Siddiqui": "صدیقی", "Sial": "سیال", "Soomro": "سومرو", "Swati": "سواتی", "Syed": "سید", "Sayyid": "سید", "Talpur": "تالپور", "Tanoli": "تنولی", "Tarar": "تارڑ", "Tareen": "ترین", "Tiwana": "ٹوانہ", "Usmani": "عثمانی", "Virk": "ورک", "Wani": "وانی", "Warraich": "وڑائچ", "Wattoo": "واٹو", "Wazir": "وزیر", "Yousafzai": "یوسفزئی", "Zaidi": "زیدی", "Zardari": "زرداری", "Zehri": "زہری", "Bohra": "بوہرہ", "Khoja": "خوجہ", "Balti": "بلتی", "Burusho": "بروشو", "Hunzai": "ہنزائی", "Dehlvi": "دہلوی", "Bhutta": "بھٹہ", "Brohi": "بروہی", "Chandio": "چانڈیو", "Mallah": "ملاح", "Magsi": "مگسی"};
  var UL={"I'm a": "میں ہوں", "Looking for a": "تلاش", "Where are you located?": "آپ کہاں رہتے ہیں؟", "Your marital status": "آپ کی ازدواجی حیثیت", "Create a display name for your profile.": "پروفائل کا نام", "About Me": "میرے بارے میں", "My Interests": "میری دلچسپیاں", "Age": "عمر", "Profile Created by": "پروفائل کس نے بنایا", "Phone No": "فون نمبر", "Marital Status": "ازدواجی حیثیت", "Children": "بچے", "Children Satus": "بچوں کی رہائش", "Children's Status": "بچوں کی رہائش", "Religion": "مذہب", "Sect": "مسلک", "Caste": "ذات / برادری", "Nationalty": "قومیت", "Nationality": "قومیت", "Nationality": "قومیت", "Education": "تعلیم", "Occupation": "پیشہ / ملازمت", "Ethnicity": "نسلی گروہ", "My Eyes": "آنکھوں کا رنگ", "My Hair": "بالوں کا رنگ", "My Body": "جسامت", "Hair Length": "بالوں کی لمبائی", "Drinking": "شراب نوشی", "Smoking": "تمباکو نوشی", "What do I look like?": "میری شکل و صورت", "Education and Occupation": "تعلیم اور پیشہ", "My Habbits": "میری عادات", "My Habits": "میری عادات", "Female": "خاتون", "Male": "مرد", "Country": "ملک", "City": "شہر", "Full Address": "مکمل پتہ", "My Location": "میرا مقام", "Sexuality": "رجحان"};
  function bilOpt(o){var k=(o.getAttribute('data-mr-en')||o.text).replace(/\s+/g,' ').trim();if(o.getAttribute('data-mr-en')||!UR[k]||o.value==='')return;o.setAttribute('data-mr-en',k);o.text=k+'  —  '+UR[k];}
  function bilAll(){[].forEach.call(document.querySelectorAll('select[id^="reg_field_"],#mobile_catlist,#parent_country_list,#category_subs'),function(s){[].forEach.call(s.options,bilOpt);});
    [].forEach.call(document.querySelectorAll('label,.block-header__title,.fs-md,._title,.mt-4.text-600,.mb-2.text-600'),function(l){if(l.getAttribute('data-mr-l'))return;var n=null;for(var c=l.firstChild;c;c=c.nextSibling){if(c.nodeType===3&&c.nodeValue.replace(/\s+/g,' ').trim()){n=c;break;}}if(!n&&l.children.length&&l.firstElementChild.id==='contentbox-title')n=l.firstElementChild.firstChild;if(!n)return;var k=n.nodeValue.replace(/\s+/g,' ').trim();if(UL[k]){l.setAttribute('data-mr-l',1);n.nodeValue=n.nodeValue.replace(k,({'Nationalty':'Nationality','Children Satus':'Children Status','My Habbits':'My Habits',"Children's Status":"Children's Status"}[k]||k)+' / '+UL[k]);}});}


  // ---- Phone: a real phone field (number keypad, digits only, private note) ----
  function phoneField(){
    var i=document.querySelector('input[name="custom[custom-14]"]');if(!i||i.dataset.mrPh)return;i.dataset.mrPh=1;
    try{i.type='tel';}catch(e){}
    i.setAttribute('inputmode','tel');i.setAttribute('autocomplete','tel');i.setAttribute('maxlength','20');i.setAttribute('placeholder','03XX 1234567  or  +92 3XX 1234567');
    i.addEventListener('input',function(){var v=i.value.replace(/[^0-9+\-\s]/g,'');if(v!==i.value)i.value=v;});
    i.addEventListener('blur',function(){var d=i.value.replace(/[^0-9+]/g,'');if(/^03\d{9}$/.test(d))i.value=d.slice(0,4)+' '+d.slice(4);});
    var n=document.createElement('small');n.style.cssText='display:block;margin-top:4px;color:#475569';n.textContent='Private: only you can see your number. / آپ کا نمبر صرف آپ کو نظر آتا ہے۔';
    i.insertAdjacentElement('afterend',n);
  }

  function run(){
    phoneField();
    bilAll();
    maritalChips();
    [].forEach.call(document.querySelectorAll('select[id^="reg_field_"]'),enhance);
    setDefault('reg_field_custom-13','Self');setDefault('reg_field_custom-18','Muslims-Islam');setDefault('reg_field_custom-21','Pakistan');
  }
  run();var n=0,t=setInterval(function(){run();if(++n>20)clearInterval(t)},1000);
})();

(function(){
  var KEEP={'Family Time':'خاندان کے ساتھ وقت','Prayer & Spirituality':'نماز اور روحانیت','Quran & Islamic Studies':'قرآن اور اسلامی علوم','Charity & Social Work':'خیرات اور سماجی خدمت','Reading':'مطالعہ','Cooking':'کھانا پکانا','Travelling':'سفر','Cricket':'کرکٹ','Gym & Fitness':'ورزش','Gardening':'باغبانی','Photography':'فوٹوگرافی','Technology':'ٹیکنالوجی'};
  function tidy(){
    [].forEach.call(document.querySelectorAll('input[name="tax[features][]"]'),function(c){
      var lab=c.closest('label');if(!lab||lab.__mrI)return;lab.__mrI=1;
      var t=lab.textContent.replace(/\s+/g,' ').trim(),box=lab.closest('.col-md-4')||lab.parentElement;
      if(KEEP.hasOwnProperty(t)){var s=document.createElement('small');s.style.cssText='display:block;color:#8a6414;font-weight:500;line-height:1.5';s.textContent=KEEP[t];lab.appendChild(s)}
      else if(!c.checked&&box)box.style.display='none';
    });
    var hs=[].slice.call(document.querySelectorAll('input[name="tax[features][]"]'));
    if(hs.length){var h=document.querySelector('.block-header__title[data-mr-l]');}
  }
  tidy();var k=0,tt=setInterval(function(){tidy();if(++k>20)clearInterval(tt)},1000);
})();
MREASY;
		echo '<script>' . $js . "</script>\n"; // phpcs:ignore
	}

	/** On the location form: when the theme knows the visitor's city from their connection, pick it in the city list. */
	public static function city_js() {
		if ( is_admin() || ! is_page() ) {
			return;
		}
		?>
<script>(function(){function n(s){return(s||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/[^a-z0-9]+/g,'')}
var tries=0,t=setInterval(function(){if(++tries>60){clearInterval(t);return}var ip=document.querySelector('input.data-map-ip-city'),sel=document.getElementById('category_subs');if(!ip||!sel||!ip.value||sel.options.length<2||sel.value)return;var w=n(ip.value);for(var i=0;i<sel.options.length;i++){if(n(sel.options[i].text)===w){sel.selectedIndex=i;if(typeof jQuery!=='undefined')jQuery(sel).trigger('change');clearInterval(t);return}}},1000)})();</script>
		<?php
	}
}
