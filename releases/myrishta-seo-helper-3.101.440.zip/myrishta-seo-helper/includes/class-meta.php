<?php
/**
 * Automatic titles, meta descriptions and image alt text.
 * Fills only what is empty: anything you set by hand in Rank Math wins.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Meta {

	public static function init() {
		add_filter( 'rank_math/frontend/title', array( __CLASS__, 'rm_title' ) );
		add_filter( 'rank_math/frontend/description', array( __CLASS__, 'rm_desc' ) );
		add_filter( 'pre_get_document_title', array( __CLASS__, 'core_title' ), 20 );
		add_action( 'wp_head', array( __CLASS__, 'core_desc' ), 3 );
		add_filter( 'wp_get_attachment_image_attributes', array( __CLASS__, 'alt' ), 10, 2 );
	}

	private static function on() {
		return ! empty( MRSH_Options::get()['auto_meta'] );
	}

	private static function has_seo_plugin() {
		return MRSH_Frontend::has_seo_plugin();
	}

	private static function fill( $tpl, $title, $excerpt ) {
		return trim( wp_specialchars_decode( str_replace( array( '%title%', '%sitename%', '%excerpt%', '%tagline%' ), array( $title, get_bloginfo( 'name' ), $excerpt, get_bloginfo( 'description' ) ), $tpl ), ENT_QUOTES ) );
	}

	private static function clip( $text, $max ) {
		$text = preg_replace( '/<\/(h[1-6]|p|li|div|ul|ol|tr|td|th|blockquote)>/i', '$0 ', (string) $text );
		$text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $text ) ) );
		if ( mb_strlen( $text ) <= $max ) {
			return $text;
		}
		$cut = mb_substr( $text, 0, $max );
		// Prefer to end on a whole sentence so the snippet reads complete.
		$dot = max( (int) mb_strrpos( $cut, '. ' ), (int) mb_strrpos( $cut, '۔' ), (int) mb_strrpos( $cut, '? ' ) );
		if ( $dot > $max * 0.55 ) {
			return rtrim( mb_substr( $cut, 0, $dot + 1 ) );
		}
		$cut = mb_substr( $text, 0, $max - 1 );
		$sp  = mb_strrpos( $cut, ' ' );
		return rtrim( $sp > $max * 0.6 ? mb_substr( $cut, 0, $sp ) : $cut, " ,.;:-" ) . '…';
	}

	/** A search-result title that is never cut mid-word: use the short brand when the long one will not fit. */
	private static function fit_title( $t ) {
		$t = trim( wp_specialchars_decode( (string) $t, ENT_QUOTES ) );
		if ( mb_strlen( $t ) <= 60 ) {
			// Very short titles are weak for search: add a descriptive tail ("Safety Tips | MyRishta.pk" becomes longer).
			if ( mb_strlen( $t ) < 32 && preg_match( '/^(.+?) \| MyRishta\.pk$/u', $t, $m ) && mb_strlen( $m[1] ) <= 26 ) {
				return $m[1] . ' | Free Rishta in Pakistan | MyRishta.pk';
			}
			return $t;
		}
		$pos  = mb_strrpos( $t, ' | ' );
		$head = false !== $pos ? mb_substr( $t, 0, $pos ) : $t;
		$try  = $head . ' | MyRishta.pk';
		if ( mb_strlen( $try ) <= 62 ) {
			return $try;
		}
		if ( mb_strlen( $head ) <= 62 ) {
			return $head;
		}
		$cut = mb_substr( $head, 0, 60 );
		$sp  = mb_strrpos( $cut, ' ' );
		$cut = rtrim( $sp > 35 ? mb_substr( $cut, 0, $sp ) : $cut, " ,.;:-|" );
		// Do not end on a dangling small word such as "for" or "and".
		while ( preg_match( '/\s(a|an|and|for|of|the|to|in|on|with|or|by|at)$/i', $cut, $m ) ) {
			$cut = rtrim( mb_substr( $cut, 0, -strlen( $m[0] ) ), " ,.;:-|" );
		}
		return $cut;
	}

	/** Descriptions under about 120 characters get a short, useful tail so they are not flagged as too short. */
	private static function pad_desc( $d ) {
		$d = trim( (string) $d );
		if ( '' !== $d && mb_strlen( $d ) < 120 && mb_strlen( $d ) >= 40 ) {
			$d = rtrim( $d, ' …' );
			if ( ! preg_match( '/[.!?۔]$/u', $d ) ) {
				$d .= '.';
			}
			$d .= ' Free and private, from My Rishta Pakistan.';
		}
		return $d;
	}

	private static function skip() {
		return is_admin() || is_feed() || MRSH_Frontend::should_noindex();
	}

	private static function excerpt_of( $post ) {
		if ( ! $post ) {
			return '';
		}
		if ( has_excerpt( $post ) ) {
			return self::clip( $post->post_excerpt, 155 );
		}
		$c = strip_shortcodes( $post->post_content );
		// Use the opening paragraph(s) only, so widget/filter labels further down never leak in.
		if ( preg_match_all( '/<p\b[^>]*>(.*?)<\/p>/is', $c, $pm ) ) {
			$acc = '';
			foreach ( $pm[1] as $para ) {
				$para = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $para ) ) );
				if ( mb_strlen( $para ) < 25 ) {
					continue;
				}
				$acc = trim( $acc . ' ' . $para );
				if ( mb_strlen( $acc ) >= 110 ) {
					break;
				}
			}
			if ( mb_strlen( $acc ) >= 70 ) {
				return self::clip( $acc, 155 );
			}
		}
		return self::clip( $c, 155 );
	}

	/** Returns array(title, description) or null when nothing should be added. */
	public static function build() {
		if ( ! self::on() || is_admin() || is_feed() ) {
			return null;
		}
		$o = MRSH_Options::get();
		if ( is_front_page() ) {
			return array( self::fill( $o['meta_title_home'], '', '' ), self::fill( $o['meta_desc_home'], '', '' ), 0 );
		}
		if ( is_singular() ) {
			$post = get_queried_object();
			$ct   = $post ? (string) get_post_meta( $post->ID, '_mrsh_title', true ) : '';
			$cd   = $post ? (string) get_post_meta( $post->ID, '_mrsh_desc', true ) : '';
			$tt   = '' !== $ct ? self::fill( $ct, get_the_title( $post ), '' ) : self::fill( $o['meta_title_page'], get_the_title( $post ), '' );
			$desc = '' !== $cd ? $cd : self::excerpt_of( $post );
			$ttl  = $post ? trim( wp_strip_all_tags( get_the_title( $post ) ) ) : '';
			if ( $post && '' === $ct && in_array( $post->post_type, MRSH_Options::to_list( $o['noindex_post_types'] ), true ) ) {
				// Member profiles: a clear, unique title instead of the long site-name default.
				$tt = $ttl . ' | Rishta Profile | My Rishta Pakistan';
			}
			if ( $post && '' !== $ttl && mb_strlen( $desc ) < 70 ) {
				// Too-short or missing description: write a unique one from the page title.
				$desc = self::clip( $ttl . ' on My Rishta Pakistan, a free non-profit rishta service in Lahore. Read the details and connect safely with Pakistani families at home and abroad.', 160 );
			}
			$desc = apply_filters( 'mrsh_meta_description', $desc, $post ? $post->ID : 0 );
			return array( $tt, self::pad_desc( $desc ), $post ? $post->ID : 0 );
		}
		if ( is_category() || is_tag() || is_tax() ) {
			$term = get_queried_object();
			$td = self::clip( term_description( $term->term_id ), 155 );
			if ( mb_strlen( $td ) < 70 ) {
				$td = self::clip( 'Browse ' . $term->name . ' rishta guides and profiles on My Rishta Pakistan, a free non-profit rishta service in Lahore. Connect safely with Pakistani families.', 160 );
			}
			return array( self::fill( $o['meta_title_page'], $term->name, '' ), self::pad_desc( $td ), 0 );
		}
		return null;
	}

	/** Description for the current page, for Open Graph tags. */
	public static function current_description() {
		$b = self::build();
		if ( $b && '' !== $b[1] ) {
			return self::clip( $b[1], 160 );
		}
		return self::clip( (string) get_bloginfo( 'description' ), 160 );
	}

	public static function rm_title( $title ) {
		$b = self::build();
		if ( ! $b || $b[2] && get_post_meta( $b[2], 'rank_math_title', true ) ) {
			return $title;
		}
		return self::fit_title( $b[0] );
	}

	public static function rm_desc( $desc ) {
		$b = self::build();
		if ( ! $b || '' === $b[1] || $b[2] && get_post_meta( $b[2], 'rank_math_description', true ) ) {
			return $desc;
		}
		return self::clip( $b[1], 160 );
	}

	public static function core_title( $title ) {
		if ( self::has_seo_plugin() ) {
			return $title;
		}
		$b = self::build();
		return $b && '' !== $b[0] ? self::fit_title( $b[0] ) : $title;
	}

	public static function core_desc() {
		if ( self::has_seo_plugin() ) {
			return;
		}
		$b = self::build();
		if ( $b && '' !== $b[1] ) {
			echo '<meta name="description" content="' . esc_attr( self::clip( $b[1], 160 ) ) . '" data-mrsh="1">' . "\n";
		}
	}

	/** Alt text from the image title when none was written. */
	public static function alt( $attr, $attachment ) {
		if ( ! self::on() || ! empty( $attr['alt'] ) || ! $attachment ) {
			return $attr;
		}
		$t = trim( preg_replace( '/[-_]+/', ' ', get_the_title( $attachment->ID ) ) );
		$attr['alt'] = ( '' !== $t && ! preg_match( '/^(img|dsc|image|screenshot|whatsapp)\b|^\d+$/i', $t ) ) ? $t : get_bloginfo( 'name' );
		return $attr;
	}
}
