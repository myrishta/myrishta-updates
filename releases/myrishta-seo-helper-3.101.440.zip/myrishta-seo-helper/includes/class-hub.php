<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Browse pages that fill themselves: [mrsh_hub gender="Female" status="Divorced" city="Lahore" caste="" country="" limit="24"]
 * and [mrsh_stories] (success stories = posts in the "success-stories" category).
 * Shows only what each profile already shows publicly (name, age, status, place, photo). Never the phone.
 */
class MRSH_Hub {

	public static function init() {
		add_shortcode( 'mrsh_hub', array( __CLASS__, 'hub' ) );
		add_shortcode( 'mrsh_stories', array( __CLASS__, 'stories' ) );
	}

	private static function css() {
		wp_register_style( 'mrsh-hub', false, array(), MRSH_VERSION );
		wp_enqueue_style( 'mrsh-hub' );
		wp_add_inline_style( 'mrsh-hub', '.mrsh-hub{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:12px;margin:16px 0}.mrsh-hub a{display:block;text-decoration:none;color:inherit;border:1px solid rgba(128,128,128,.3);border-radius:14px;overflow:hidden}.mrsh-hub .ph{aspect-ratio:3/4;background:#12304a;display:flex;align-items:center;justify-content:center;color:#d4af37;font-size:42px;font-weight:700}.mrsh-hub img{width:100%;height:100%;object-fit:cover;display:block}.mrsh-hub .tx{padding:8px 10px;font-size:14px;line-height:1.35}.mrsh-hub .tx b{display:block;font-size:15px}.mrsh-hub .tx span{opacity:.75}.mrsh-hubnote{padding:14px;border:1px dashed rgba(128,128,128,.5);border-radius:12px}' );
	}

	public static function hub( $atts ) {
		$a = shortcode_atts( array( 'gender' => '', 'status' => '', 'city' => '', 'country' => '', 'caste' => '', 'limit' => 24 ), $atts, 'mrsh_hub' );
		self::css();
		$rows = array();
		foreach ( MRSH_Details::people() as $r ) {
			$t = (array) $r['tax'];
			$m = (array) $r['meta'];
			if ( '' !== $a['gender'] && ! in_array( $a['gender'], isset( $t['dagender'] ) ? $t['dagender'] : array(), true ) ) {
				continue;
			}
			$st = isset( $t['listing'] ) ? $t['listing'] : array();
			if ( '' !== $a['status'] && ! in_array( $a['status'], $st, true ) ) {
				continue;
			}
			if ( '' !== $a['city'] && 0 !== strcasecmp( $a['city'], $r['city'] ) ) {
				continue;
			}
			if ( '' !== $a['country'] && 0 !== strcasecmp( $a['country'], $r['country'] ) ) {
				continue;
			}
			if ( '' !== $a['caste'] && 0 !== strcasecmp( $a['caste'], str_replace( '_', ' ', isset( $m['custom-20'] ) ? $m['custom-20'] : '' ) ) ) {
				continue;
			}
			$rows[] = $r;
		}
		$lead = '';
		if ( ! $rows && '' !== $a['city'] ) {
			// No profile from this city yet: honestly show the newest public profiles from elsewhere instead of an empty box.
			foreach ( MRSH_Details::people() as $r ) {
				$t = (array) $r['tax'];
				if ( '' !== $a['gender'] && ! in_array( $a['gender'], isset( $t['dagender'] ) ? $t['dagender'] : array(), true ) ) {
					continue;
				}
				$rows[] = $r;
			}
			if ( $rows ) {
				$lead = '<p class="mrsh-hubnote">There are no public profiles from ' . esc_html( $a['city'] ) . ' yet. Here are the newest profiles from other cities. <a href="' . esc_url( home_url( '/add-listing/' ) ) . '">Add your free profile</a> to be the first from ' . esc_html( $a['city'] ) . '.</p>';
			}
		}
		if ( ! $rows ) {
			return '<p class="mrsh-hubnote">There are no public profiles here yet. <a href="' . esc_url( home_url( '/add-listing/' ) ) . '">Add your free profile</a> to be among the first.</p>';
		}
		// featured first, then those with a photo, then newest (the list is already newest first)
		usort( $rows, function ( $x, $y ) {
			$fx = ( ( (array) $x['meta'] )['featured'] ?? '0' ) === '1' ? 2 : 0;
			$fy = ( ( (array) $y['meta'] )['featured'] ?? '0' ) === '1' ? 2 : 0;
			return ( $fy + ( $y['thumb'] ? 1 : 0 ) ) - ( $fx + ( $x['thumb'] ? 1 : 0 ) );
		} );
		$rows = array_slice( $rows, 0, max( 1, min( 60, (int) $a['limit'] ) ) );
		$h    = $lead . '<div class="mrsh-hub">';
		foreach ( $rows as $r ) {
			$t    = (array) $r['tax'];
			$m    = (array) $r['meta'];
			$bits = array();
			if ( ! empty( $m['daage'] ) ) {
				$bits[] = (int) $m['daage'] . ' yrs';
			}
			if ( ! empty( $t['listing'][0] ) ) {
				$bits[] = $t['listing'][0];
			}
			$place = trim( $r['city'] . ( $r['city'] && $r['country'] ? ', ' : '' ) . $r['country'] );
			$h    .= '<a href="' . esc_url( $r['link'] ) . '">';
			$h    .= '<div class="ph">' . ( $r['thumb'] ? '<img loading="lazy" decoding="async" alt="' . esc_attr( $r['title'] ) . '" src="' . esc_url( $r['thumb'] ) . '">' : esc_html( mb_strtoupper( mb_substr( $r['title'], 0, 1 ) ) ) ) . '</div>';
			$h    .= '<div class="tx"><b>' . esc_html( $r['title'] ) . '</b><span>' . esc_html( implode( ' · ', $bits ) ) . ( $place ? '<br>' . esc_html( $place ) : '' ) . '</span></div></a>';
		}
		return $h . '</div>';
	}

	/** Success Stories page: how it works, a safe submit form, and real approved stories only (never invented). */
	public static function stories( $atts ) {
		$cards = array();
		$q     = new WP_Query( array( 'category_name' => 'success-stories', 'posts_per_page' => 12, 'post_status' => 'publish', 'no_found_rows' => true ) );
		while ( $q->have_posts() ) {
			$q->the_post();
			$cards[] = array( get_the_title(), wp_trim_words( get_the_excerpt(), 45 ), get_permalink() );
		}
		wp_reset_postdata();
		if ( post_type_exists( 'mrsh_story' ) ) {
			foreach ( get_posts( array( 'post_type' => 'mrsh_story', 'post_status' => 'publish', 'posts_per_page' => 30, 'no_found_rows' => true ) ) as $s ) {
				$cards[] = array( $s->post_title, wp_strip_all_tags( $s->post_content ), '' );
			}
		}
		$form = class_exists( 'MRSH_Growthboost' ) ? MRSH_Growthboost::form_html() : '';
		$site = esc_html( get_bloginfo( 'name' ) );
		$h    = '<style>.mrsh-ss{max-width:860px;margin:0 auto;font-family:inherit;color:#222}.mrsh-ss *{box-sizing:border-box}.ss-hero{background:linear-gradient(135deg,#3b0a19,#6e1230 55%,#9b1b4b);color:#fff;border-radius:22px;padding:28px 22px;margin:0 0 18px;position:relative;overflow:hidden}.ss-hero:after{content:"";position:absolute;right:-50px;top:-50px;width:190px;height:190px;border-radius:50%;background:rgba(240,208,128,.18)}.ss-hero h2{margin:0 0 8px;color:#fff;font-size:1.7rem;line-height:1.2}.ss-hero p{margin:0;max-width:560px;opacity:.92}.ss-hero .ur{display:block;margin-top:8px;direction:rtl;opacity:.9}.ss-steps{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px;margin:0 0 18px}.ss-step{background:#fff;border:1px solid #eadfe3;border-radius:18px;padding:16px;box-shadow:0 8px 24px rgba(110,18,48,.06)}.ss-step i{display:grid;place-items:center;width:34px;height:34px;border-radius:11px;background:linear-gradient(135deg,#9b1b4b,#6e1230);color:#fff;font-style:normal;font-weight:700;margin-bottom:8px}.ss-step b{display:block;margin-bottom:4px}.ss-step span{color:#555;font-size:.94rem}.ss-card{background:#fff;border:1px solid #eadfe3;border-radius:20px;padding:18px;margin:0 0 18px;box-shadow:0 8px 28px rgba(110,18,48,.06)}.ss-card h3{margin:0 0 6px;color:#6e1230}.ss-q{border-left:4px solid #c9962f;background:#fbf7f0;border-radius:10px;padding:10px 14px;margin:12px 0}.ss-q p{margin:0 0 6px}.ss-q b{color:#6e1230}.ss-safe{display:grid;gap:8px;margin:10px 0 0;padding:0;list-style:none}.ss-safe li{padding-left:26px;position:relative}.ss-safe li:before{content:"\2713";position:absolute;left:0;color:#12a375;font-weight:700}.ss-form{display:grid;gap:10px;margin-top:10px}.ss-form input,.ss-form textarea{width:100%;padding:12px 14px;border:1px solid #eadfe3;border-radius:12px;font:inherit;background:#fffdfb}.ss-form input:focus,.ss-form textarea:focus{outline:2px solid #e4c9d3;border-color:#9b1b4b}.ss-form button{background:linear-gradient(135deg,#9b1b4b,#6e1230);color:#fff;border:0;border-radius:999px;padding:14px 22px;font-weight:700;font-size:1rem;cursor:pointer}.ss-c{display:flex;gap:8px;align-items:flex-start;font-size:.9rem;color:#555}.ss-c input{width:auto;margin-top:4px}.ss-ok,.ss-bad{border-radius:14px;padding:12px 14px;margin:10px 0}.ss-ok{background:#e9f9f2;border:1px solid #bfe9d6;color:#0b6b4a}.ss-bad{background:#fdecec;border:1px solid #f4c4c4;color:#8a1f1f}.ss-note{font-size:.85rem;color:#8a7c80;margin-top:8px}.ss-btn{display:inline-block;background:#6e1230;color:#fff!important;border-radius:999px;padding:12px 20px;font-weight:700;text-decoration:none}</style><div class="mrsh-ss">';
		$h   .= '<div class="ss-hero"><h2>Success stories</h2><p>Real families who found a match through ' . $site . '. Every story is shared with the family\'s permission, and nothing is published without it.</p><span class="ur">کامیاب کہانیاں · ہر کہانی خاندان کی اجازت سے شائع ہوتی ہے</span></div>';
		if ( $cards ) {
			foreach ( $cards as $c ) {
				$h .= '<div class="ss-q"><p>' . esc_html( $c[1] ) . '</p><b>' . esc_html( $c[0] ) . '</b>' . ( $c[2] ? ' &middot; <a href="' . esc_url( $c[2] ) . '">Read more</a>' : '' ) . '</div>';
			}
		} else {
			$h .= '<div class="ss-card"><h3>Our first stories are on the way</h3><p>We are a new, free service and we only publish real stories. If you found your rishta through ' . $site . ', we would be happy and grateful to hear it.</p></div>';
		}
		$h .= '<div class="ss-steps"><div class="ss-step"><i>1</i><b>Tell us in a few lines</b><span>Use the form below, or write to us on the Contact page.</span></div><div class="ss-step"><i>2</i><b>We check with you</b><span>A team member reads it and asks you before anything goes live.</span></div><div class="ss-step"><i>3</i><b>You decide the details</b><span>First names only, or no names at all. No photos unless you agree.</span></div></div>';
		$h .= '<div class="ss-card"><h3>What to write <span lang="ur" dir="rtl" style="font-weight:400;color:#777">· کیا لکھیں</span></h3><p>A few honest lines are enough. For example:</p><div class="ss-q"><p>How did you first connect, and how long before the families met?</p><p>What helped you decide: values, family, shared plans?</p><p>What advice would you give someone who is still looking?</p><b>This is only a guide to what to write. It is not a real story.</b></div><ul class="ss-safe"><li>No phone numbers, addresses or CNIC numbers, please. We remove them if they appear.</li><li>You can ask us to remove your story at any time.</li><li>Stories are never used for advertising without your permission.</li></ul></div>';
		$h .= '<div class="ss-card"><h3>Share your story <span lang="ur" dir="rtl" style="font-weight:400;color:#777">· اپنی کہانی بھیجیں</span></h3>';
		if ( $form ) {
			$h .= $form . '<p class="ss-note">Your story waits as pending until our team approves it.</p>';
		} else {
			$h .= '<p>Found your rishta through ' . $site . '? Tell us in a few lines and we will check with you before publishing anything.</p><a class="ss-btn" href="' . esc_url( home_url( '/contact/' ) ) . '">Contact us</a>';
		}
		$h .= '</div><div class="ss-card" style="text-align:center"><h3>Still looking?</h3><p>Create a free profile in three minutes. No fees, no agents.</p><a class="ss-btn" href="' . esc_url( home_url( '/add-listing/' ) ) . '">Create free profile</a></div></div>';
		return $h;
	}
}
