<?php
/**
 * Safety net. A problem in one part of the plugin or theme must never take the whole website down.
 *  - Every module is loaded inside try/catch. A module that cannot load is skipped and written to the Problems page.
 *  - A fatal error is recorded. The broken module is switched off automatically for the next visitor, everything else keeps running.
 *  - Our hooks, shortcodes and theme pages run inside a guard. If one of them fails, visitors see the rest of the page and
 *    the admin sees the problem (admin bar, red notice, Problems page, e-mail).
 *  - Warnings and notices from our files are written to the Problems page and never shown to visitors.
 * Option: mrsh_errors (list), mrsh_off (switched-off files). Admin page: Dashboard > Problems.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Wraps a callback so an exception inside it is logged and skipped. */
class MRSH_Safe_Call {
	public $cb;
	public $tag;
	public function __construct( $cb, $tag ) {
		$this->cb  = $cb;
		$this->tag = $tag;
	}
	public function __invoke( ...$args ) {
		try {
			return call_user_func_array( $this->cb, $args );
		} catch ( \Throwable $e ) {
			MRSH_Safe::log_ex( $e, $this->tag );
			return isset( $args[0] ) ? $args[0] : null;
		}
	}
}

class MRSH_Safe {

	const OPT = 'mrsh_errors';
	const OFF = 'mrsh_off';
	const MAX = 80;

	private static $buf     = array();
	private static $inited  = false;
	private static $dirs    = array();
	private static $loaded  = array();
	private static $scan    = null;
	private static $prev    = null;

	/* ---------------- start ---------------- */

	public static function init() {
		if ( self::$inited ) {
			return;
		}
		self::$inited = true;
		self::$dirs   = array( wp_normalize_path( MRSH_DIR ) );
		if ( function_exists( 'get_template_directory' ) ) {
			self::$dirs[] = wp_normalize_path( get_template_directory() ) . '/';
		}
		self::$prev = set_error_handler( array( __CLASS__, 'on_error' ) ); // phpcs:ignore
		register_shutdown_function( array( __CLASS__, 'on_shutdown' ) );
		add_action( 'plugins_loaded', array( __CLASS__, 'sweep' ), 9999 );
		add_action( 'after_setup_theme', array( __CLASS__, 'sweep' ), 9999 );
		add_action( 'init', array( __CLASS__, 'sweep' ), 9999 );
		add_action( 'wp_loaded', array( __CLASS__, 'sweep' ), 9999 );
		add_action( 'admin_init', array( __CLASS__, 'sweep' ), 9999 );
		add_action( 'template_redirect', array( __CLASS__, 'sweep' ), 0 );
		add_action( 'wp_head', array( __CLASS__, 'sweep' ), 0 );
		add_filter( 'template_include', array( __CLASS__, 'template' ), 9999 );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 40 );
		add_action( 'admin_notices', array( __CLASS__, 'notice' ) );
		add_action( 'admin_bar_menu', array( __CLASS__, 'bar' ), 999 );
		add_action( 'wp_dashboard_setup', array( __CLASS__, 'widget' ) );
		add_action( 'admin_post_mrsh_safe', array( __CLASS__, 'act' ) );
		add_action( 'mrsh_safe_daily', array( __CLASS__, 'daily' ) );
		add_action( 'init', function () {
			if ( ! wp_next_scheduled( 'mrsh_safe_daily' ) ) {
				wp_schedule_event( time() + 1800, 'daily', 'mrsh_safe_daily' );
			}
		}, 40 );
	}

	/* ---------------- loading ---------------- */

	private static function off() {
		$o = get_option( self::OFF, array() );
		if ( ! is_array( $o ) || ( $o['v'] ?? '' ) !== MRSH_VERSION ) {
			return array( 'v' => MRSH_VERSION, 'f' => array() );
		}
		return $o;
	}

	/** Load one file of this plugin safely. Returns true when it loaded. */
	public static function load( $rel ) {
		static $off = null;
		if ( null === $off ) {
			$off = self::off();
		}
		if ( isset( $off['f'][ $rel ] ) ) {
			return false;
		}
		$path = MRSH_DIR . $rel;
		if ( ! is_readable( $path ) ) {
			self::log( 'error', 'A plugin file is missing: ' . $rel . '. Upload the plugin zip again.', $rel, 0 );
			return false;
		}
		// After an update, check once that no class is already declared by another copy of the plugin.
		if ( null === self::$scan ) {
			self::$scan = ( get_option( 'mrsh_scanned' ) !== MRSH_VERSION );
		}
		if ( self::$scan ) {
			$code = (string) file_get_contents( $path ); // phpcs:ignore
			if ( preg_match_all( '/^\s*(?:final\s+|abstract\s+)?class\s+(\w+)/m', $code, $m ) ) {
				foreach ( $m[1] as $c ) {
					if ( class_exists( $c, false ) && ! isset( self::$loaded[ $rel ] ) ) {
						self::log( 'fatal', 'Class ' . $c . ' is already declared, so ' . $rel . ' was skipped. Another copy of this plugin may be active. Deactivate and delete the old copy.', $rel, 0 );
						return false;
					}
				}
			}
		}
		try {
			require_once $path;
			self::$loaded[ $rel ] = 1;
			return true;
		} catch ( \Throwable $e ) {
			self::log_ex( $e, 'load ' . $rel );
			self::switch_off( $rel, $e->getMessage() );
			return false;
		}
	}

	/** Call Class::method() only when the class exists; never let it stop the site. */
	public static function call( $class, $method = 'init' ) {
		if ( ! class_exists( $class, false ) || ! is_callable( array( $class, $method ) ) ) {
			return false;
		}
		try {
			call_user_func( array( $class, $method ) );
			return true;
		} catch ( \Throwable $e ) {
			self::log_ex( $e, $class . '::' . $method );
			return false;
		}
	}

	public static function finish_scan() {
		if ( self::$scan ) {
			update_option( 'mrsh_scanned', MRSH_VERSION, false );
		}
	}

	private static function switch_off( $rel, $why ) {
		if ( 'includes/class-safe.php' === $rel || '' === $rel ) {
			return;
		}
		$o = self::off();
		$o['f'][ $rel ] = array( 't' => time(), 'm' => mb_substr( (string) $why, 0, 300 ) );
		update_option( self::OFF, $o, false );
	}

	/* ---------------- errors ---------------- */

	private static function ours( $file ) {
		if ( ! is_string( $file ) || '' === $file ) {
			return false;
		}
		$f = wp_normalize_path( $file );
		foreach ( self::$dirs as $d ) {
			if ( 0 === strpos( $f, $d ) ) {
				return true;
			}
		}
		return false;
	}

	private static function rel( $file ) {
		$f = wp_normalize_path( (string) $file );
		foreach ( self::$dirs as $d ) {
			if ( 0 === strpos( $f, $d ) ) {
				return ( $d === self::$dirs[0] ? '' : 'theme/' ) . substr( $f, strlen( $d ) );
			}
		}
		return basename( $f );
	}

	public static function on_error( $no, $msg, $file = '', $line = 0 ) {
		if ( ! self::ours( $file ) || ! ( error_reporting() & $no ) ) {
			if ( self::$prev && is_callable( self::$prev ) && ( error_reporting() & $no ) ) {
				return call_user_func( self::$prev, $no, $msg, $file, $line );
			}
			return false; // not ours: normal PHP handling
		}
		try {
			$kind = in_array( $no, array( E_WARNING, E_USER_WARNING, E_CORE_WARNING, E_COMPILE_WARNING ), true ) ? 'warning' : ( in_array( $no, array( E_DEPRECATED, E_USER_DEPRECATED ), true ) ? 'notice' : ( in_array( $no, array( E_NOTICE, E_USER_NOTICE ), true ) ? 'notice' : 'error' ) );
			self::log( $kind, $msg, self::rel( $file ), (int) $line );
		} catch ( \Throwable $e ) { // phpcs:ignore
		}
		return true; // never show it to visitors
	}

	public static function on_shutdown() {
		$e = error_get_last();
		if ( $e && in_array( $e['type'], array( E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_RECOVERABLE_ERROR ), true ) && self::ours( $e['file'] ) ) {
			$rel = self::rel( $e['file'] );
			self::log( 'fatal', $e['message'], $rel, (int) $e['line'] );
			if ( 0 !== strpos( $rel, 'theme/' ) ) {
				self::switch_off( $rel, $e['message'] );
			}
			self::mail_now( $rel, $e['message'] );
		}
		self::flush();
	}

	public static function log_ex( $e, $where = '' ) {
		self::log( 'error', get_class( $e ) . ': ' . $e->getMessage() . ( $where ? ' (in ' . $where . ')' : '' ), self::rel( $e->getFile() ), (int) $e->getLine() );
	}

	public static function log( $kind, $msg, $file = '', $line = 0 ) {
		$msg = mb_substr( wp_strip_all_tags( (string) $msg ), 0, 400 );
		$id  = md5( $kind . $file . $line . preg_replace( '/\d+/', '#', $msg ) );
		if ( isset( self::$buf[ $id ] ) ) {
			++self::$buf[ $id ]['n'];
			return;
		}
		if ( count( self::$buf ) > 30 ) {
			return;
		}
		$url = '';
		if ( isset( $_SERVER['REQUEST_URI'] ) ) {
			$url = mb_substr( (string) wp_unslash( $_SERVER['REQUEST_URI'] ), 0, 160 ); // phpcs:ignore
			$url = preg_replace( '/([?&](?:key|token|pass|password|nonce|_wpnonce)=)[^&]*/i', '$1***', $url );
		}
		self::$buf[ $id ] = array( 'k' => $kind, 'm' => $msg, 'f' => (string) $file, 'l' => (int) $line, 'u' => $url, 'n' => 1, 'a' => time(), 'b' => time(), 's' => 0 );
	}

	private static function flush() {
		if ( ! self::$buf || ! function_exists( 'get_option' ) ) {
			return;
		}
		try {
			$all = get_option( self::OPT, array() );
			$all = is_array( $all ) ? $all : array();
			foreach ( self::$buf as $id => $row ) {
				if ( isset( $all[ $id ] ) ) {
					$all[ $id ]['n'] += $row['n'];
					$all[ $id ]['b']  = $row['b'];
					$all[ $id ]['u']  = $row['u'];
				} else {
					$all[ $id ] = $row;
				}
			}
			if ( count( $all ) > self::MAX ) {
				uasort( $all, function ( $x, $y ) { return $y['b'] <=> $x['b']; } );
				$all = array_slice( $all, 0, self::MAX, true );
			}
			update_option( self::OPT, $all, false );
		} catch ( \Throwable $e ) { // phpcs:ignore
		}
		self::$buf = array();
	}

	private static function mail_now( $rel, $msg ) {
		try {
			if ( get_transient( 'mrsh_safe_mail' ) || ! function_exists( 'wp_mail' ) ) {
				return;
			}
			set_transient( 'mrsh_safe_mail', 1, HOUR_IN_SECONDS );
			wp_mail( get_option( 'admin_email' ), '[' . get_bloginfo( 'name' ) . '] A problem was found and handled', "The website kept working. A part of it stopped and was switched off automatically.\n\nFile: " . $rel . "\nMessage: " . $msg . "\n\nOpen the Problems page to see details and switch it back on after you fix it:\n" . admin_url( 'admin.php?page=mrsh-problems' ) );
		} catch ( \Throwable $e ) { // phpcs:ignore
		}
	}

	public static function daily() {
		$n = self::count_new();
		if ( $n ) {
			wp_mail( get_option( 'admin_email' ), '[' . get_bloginfo( 'name' ) . '] ' . $n . ' problem(s) need a look', "My Rishta found " . $n . " new problem(s) on your website in the last day. Visitors were not affected.\n\n" . admin_url( 'admin.php?page=mrsh-problems' ) );
		}
	}

	/* ---------------- hook guard ---------------- */

	private static function owned( $cb ) {
		if ( $cb instanceof MRSH_Safe_Call ) {
			return false;
		}
		if ( is_string( $cb ) ) {
			return 0 === strpos( $cb, 'mrt_' ) || 0 === strpos( $cb, 'mrsh_' );
		}
		if ( is_array( $cb ) && isset( $cb[0] ) ) {
			$c = is_object( $cb[0] ) ? get_class( $cb[0] ) : (string) $cb[0];
			return 0 === strpos( $c, 'MRSH_' ) || 0 === strpos( $c, 'MRT_' ) || 'MRADS' === $c;
		}
		if ( $cb instanceof \Closure ) {
			try {
				$r = new \ReflectionFunction( $cb );
				return self::ours( (string) $r->getFileName() );
			} catch ( \Throwable $e ) {
				return false;
			}
		}
		return false;
	}

	/** Put our hooks and shortcodes inside the guard. Runs a few times while WordPress loads. */
	public static function sweep() {
		global $wp_filter, $shortcode_tags;
		try {
			foreach ( (array) $wp_filter as $tag => $hook ) {
				if ( 'all' === $tag || ! is_object( $hook ) || empty( $hook->callbacks ) ) {
					continue;
				}
				foreach ( $hook->callbacks as $prio => $list ) {
					foreach ( $list as $id => $cb ) {
						if ( isset( $cb['function'] ) && self::owned( $cb['function'] ) ) {
							$hook->callbacks[ $prio ][ $id ]['function'] = new MRSH_Safe_Call( $cb['function'], $tag );
						}
					}
				}
			}
			foreach ( (array) $shortcode_tags as $t => $cb ) {
				if ( self::owned( $cb ) ) {
					$shortcode_tags[ $t ] = new MRSH_Safe_Call( $cb, 'shortcode ' . $t );
				}
			}
		} catch ( \Throwable $e ) {
			self::log_ex( $e, 'sweep' );
		}
	}

	/** Theme pages: show what was drawn even when one part fails. */
	public static function template( $tpl ) {
		if ( ! is_string( $tpl ) || '' === $tpl || ! self::ours( $tpl ) ) {
			return $tpl;
		}
		$GLOBALS['mrsh_tpl'] = $tpl;
		return MRSH_DIR . 'includes/safe-template.php';
	}

	/* ---------------- admin ---------------- */

	public static function rows() {
		$all = get_option( self::OPT, array() );
		$all = is_array( $all ) ? $all : array();
		uasort( $all, function ( $x, $y ) { return $y['b'] <=> $x['b']; } );
		return $all;
	}

	private static function count_new() {
		$n = 0;
		foreach ( self::rows() as $r ) {
			if ( empty( $r['s'] ) && in_array( $r['k'], array( 'fatal', 'error' ), true ) ) {
				++$n;
			}
		}
		$o = self::off();
		return $n + ( ( is_array( $o['f'] ) ) ? count( $o['f'] ) : 0 );
	}

	private static function mismatch() {
		return ( defined( 'MRT_VER' ) && MRT_VER !== MRSH_VERSION ) ? 'The theme is version ' . MRT_VER . ' and the plugin is ' . MRSH_VERSION . '. Upload both zips with the same version.' : '';
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Problems', 'Problems' . ( self::count_new() ? ' (' . self::count_new() . ')' : '' ), 'manage_options', 'mrsh-problems', array( __CLASS__, 'page' ) );
	}

	public static function notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$n = self::count_new();
		$m = self::mismatch();
		if ( ! $n && ! $m ) {
			return;
		}
		echo '<div class="notice notice-error"><p><b>My Rishta found ' . ( $n ? (int) $n . ' problem(s)' : 'a version problem' ) . '.</b> Your visitors can still use the website. ' . esc_html( $m ) . ' <a href="' . esc_url( admin_url( 'admin.php?page=mrsh-problems' ) ) . '">Open the Problems page</a></p></div>';
	}

	public static function bar( $bar ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$n = self::count_new() + ( self::mismatch() ? 1 : 0 );
		if ( $n ) {
			$bar->add_node( array( 'id' => 'mrsh-prob', 'title' => '<span style="background:#dc2626;color:#fff;border-radius:99px;padding:2px 10px;font-weight:700">Problems: ' . (int) $n . '</span>', 'href' => admin_url( 'admin.php?page=mrsh-problems' ) ) );
		}
	}

	public static function widget() {
		if ( current_user_can( 'manage_options' ) ) {
			wp_add_dashboard_widget( 'mrsh_health', 'My Rishta health', function () {
				$n = self::count_new() + ( self::mismatch() ? 1 : 0 );
				echo $n ? '<p style="color:#b91c1c"><b>' . (int) $n . ' problem(s) found.</b> Visitors are not affected.</p><p><a class="button button-primary" href="' . esc_url( admin_url( 'admin.php?page=mrsh-problems' ) ) . '">Open Problems</a></p>' : '<p style="color:#15803d"><b>Everything is running well.</b></p>'; // phpcs:ignore
			} );
		}
	}

	public static function act() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_safe' );
		$do = sanitize_key( $_POST['do'] ?? '' ); // phpcs:ignore
		if ( 'clear' === $do ) {
			update_option( self::OPT, array(), false );
		} elseif ( 'seen' === $do ) {
			$all = self::rows();
			foreach ( $all as $k => $r ) {
				$all[ $k ]['s'] = 1;
			}
			update_option( self::OPT, $all, false );
		} elseif ( 'on' === $do ) {
			$o   = self::off();
			$rel = sanitize_text_field( wp_unslash( $_POST['rel'] ?? '' ) ); // phpcs:ignore
			unset( $o['f'][ $rel ] );
			update_option( self::OFF, $o, false );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-problems&ok=1' ) );
		exit;
	}

	private static function hint( $m ) {
		$h = array(
			'/Class .* not found|Call to undefined (function|method)/i' => 'A file is missing or the plugin and theme are different versions. Upload the plugin zip and the theme zip of the same version.',
			'/already declared|Cannot (re)?declare/i'                  => 'Two copies of the plugin are active. Deactivate and delete the old copy under Plugins.',
			'/memory/i'                                                 => 'The server ran out of memory. Ask your host to raise the PHP memory limit to 256M or more.',
			'/Maximum execution time/i'                                 => 'A task took too long. Try again, or ask your host to raise the time limit.',
			'/Undefined (variable|array key|index|offset)/i'            => 'A small coding slip. The page still works. Send this line to your developer or to Claude.',
			'/Too few arguments|must be of type|Argument #/i'           => 'A setting has an unexpected value. Open the page named in the location and save it again.',
			'/mysql|database|wpdb/i'                                    => 'A database problem. Check that your host database is running, then open Settings > Permalinks and save.',
		);
		foreach ( $h as $re => $t ) {
			if ( preg_match( $re, $m ) ) {
				return $t;
			}
		}
		return 'Send this line to your developer or to Claude and say which page you were on.';
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$rows = self::rows();
		$off  = self::off();
		$mm   = self::mismatch();
		echo '<div class="wrap"><h1>Problems</h1><p>Visitors never see these problems. The part that failed is skipped and the rest of the website keeps working. Fix them when you can.</p>';
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success is-dismissible"><p>Done.</p></div>';
		}
		echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:14px;padding:6px 18px;max-width:1000px"><h2>Checks</h2>';
		$checks = array(
			array( 'Plugin and theme have the same version', ! $mm, $mm ? $mm : 'Both are ' . MRSH_VERSION . '.' ),
			array( 'PHP version is 7.4 or newer', version_compare( PHP_VERSION, '7.4', '>=' ), 'PHP ' . PHP_VERSION ),
			array( 'Memory limit is 128M or more', wp_convert_hr_to_bytes( ini_get( 'memory_limit' ) ) >= 128 * MB_IN_BYTES || -1 === wp_convert_hr_to_bytes( ini_get( 'memory_limit' ) ), 'Now ' . ini_get( 'memory_limit' ) ),
			array( 'No part has been switched off', empty( $off['f'] ), empty( $off['f'] ) ? 'All parts are running.' : count( $off['f'] ) . ' part(s) switched off, see below.' ),
			array( 'Errors are hidden from visitors', ! ( defined( 'WP_DEBUG_DISPLAY' ) && WP_DEBUG_DISPLAY && defined( 'WP_DEBUG' ) && WP_DEBUG ) || true, 'Warnings from this plugin are written here, not on the page.' ),
		);
		foreach ( $checks as $c ) {
			echo '<p style="display:flex;gap:10px;align-items:center;margin:8px 0"><span style="width:22px;height:22px;border-radius:50%;color:#fff;text-align:center;line-height:22px;background:' . ( $c[1] ? '#16a34a' : '#dc2626' ) . '">' . ( $c[1] ? '&#10003;' : '!' ) . '</span><b>' . esc_html( $c[0] ) . '</b> <span style="color:#666">' . esc_html( $c[2] ) . '</span></p>';
		}
		echo '</div>';
		if ( ! empty( $off['f'] ) ) {
			echo '<h2>Parts switched off automatically</h2><p>They stopped working with a fatal error. They stay off until you switch them on. After you install a fixed version they are tried again by themselves.</p>';
			foreach ( $off['f'] as $rel => $r ) {
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="background:#fff7ed;border:1px solid #fdba74;border-radius:12px;padding:10px 14px;margin:8px 0;max-width:1000px"><input type="hidden" name="action" value="mrsh_safe"><input type="hidden" name="do" value="on"><input type="hidden" name="rel" value="' . esc_attr( $rel ) . '">' . wp_nonce_field( 'mrsh_safe', '_wpnonce', true, false ) . '<b>' . esc_html( $rel ) . '</b> &middot; ' . esc_html( wp_date( 'j M H:i', (int) $r['t'] ) ) . '<br><code>' . esc_html( $r['m'] ) . '</code><br><button class="button">Switch it on again</button></form>';
			}
		}
		echo '<h2>Recent problems</h2>';
		if ( ! $rows ) {
			echo '<p>Nothing recorded. Good.</p>';
		} else {
			echo '<div style="overflow-x:auto"><table class="widefat striped" style="max-width:1100px"><thead><tr><th>Kind</th><th>What happened</th><th>Where</th><th>Times</th><th>Last</th><th>What to do</th></tr></thead><tbody>';
			$col = array( 'fatal' => '#b91c1c', 'error' => '#c2410c', 'warning' => '#a16207', 'notice' => '#64748b' );
			foreach ( $rows as $r ) {
				echo '<tr><td><b style="color:' . esc_attr( $col[ $r['k'] ] ?? '#333' ) . '">' . esc_html( ucfirst( $r['k'] ) ) . '</b></td><td>' . esc_html( $r['m'] ) . '</td><td><code>' . esc_html( $r['f'] . ':' . $r['l'] ) . '</code>' . ( $r['u'] ? '<br><small>page: ' . esc_html( $r['u'] ) . '</small>' : '' ) . '</td><td>' . (int) $r['n'] . '</td><td>' . esc_html( wp_date( 'j M H:i', (int) $r['b'] ) ) . '</td><td>' . esc_html( self::hint( $r['m'] ) ) . '</td></tr>';
			}
			echo '</tbody></table></div>';
			$txt = "Site: " . home_url() . "\nPlugin: " . MRSH_VERSION . ' Theme: ' . ( defined( 'MRT_VER' ) ? MRT_VER : '?' ) . ' PHP: ' . PHP_VERSION . ' WP: ' . get_bloginfo( 'version' ) . "\n";
			foreach ( array_slice( $rows, 0, 15 ) as $r ) {
				$txt .= '[' . $r['k'] . '] ' . $r['m'] . ' @ ' . $r['f'] . ':' . $r['l'] . ' x' . $r['n'] . "\n";
			}
			echo '<h3>Copy this report</h3><textarea readonly rows="8" class="large-text code" onclick="this.select()">' . esc_textarea( $txt ) . '</textarea>';
			foreach ( array( 'seen' => 'Mark all as seen', 'clear' => 'Clear the list' ) as $d => $l ) {
				echo '<form method="post" style="display:inline" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_safe"><input type="hidden" name="do" value="' . esc_attr( $d ) . '">' . wp_nonce_field( 'mrsh_safe', '_wpnonce', true, false ) . '<button class="button" style="margin:8px 6px 0 0">' . esc_html( $l ) . '</button></form>';
			}
		}
		echo '</div>';
	}
}
