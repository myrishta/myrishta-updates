<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * IndexNow: tells Bing, Yandex, Naver, Seznam.cz, Yep and Amazon when a URL is new or changed.
 * Google does not take part in IndexNow.
 */
class MRSH_IndexNow {

	const ENDPOINT = 'https://api.indexnow.org/indexnow';
	const LOG      = 'mrsh_indexnow_log';

	private static $queue = array();

	public static function init() {
		add_action( 'init', array( __CLASS__, 'serve_key' ), 1 );
		add_action( 'transition_post_status', array( __CLASS__, 'on_transition' ), 10, 3 );
		add_action( 'shutdown', array( __CLASS__, 'flush_queue' ) );
	}

	public static function valid_key( $key ) {
		return (bool) preg_match( '/^[A-Za-z0-9\-]{8,128}$/', (string) $key );
	}

	public static function new_key() {
		return bin2hex( random_bytes( 16 ) );
	}

	public static function key() {
		$o = MRSH_Options::get();
		return $o['indexnow_key'];
	}

	public static function key_url() {
		return home_url( '/' . self::key() . '.txt' );
	}

	/** Serves {key}.txt from the site root without a physical file. */
	public static function serve_key() {
		$key = self::key();
		if ( ! self::valid_key( $key ) || empty( $_SERVER['REQUEST_URI'] ) ) {
			return;
		}
		$uri  = sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) );
		$path = wp_parse_url( $uri, PHP_URL_PATH );
		$base = wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		if ( $path === $base . $key . '.txt' ) {
			status_header( 200 );
			nocache_headers();
			header( 'Content-Type: text/plain; charset=utf-8' );
			echo $key; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			exit;
		}
	}

	/** Public, published content that is not set to noindex. */
	public static function eligible( $post ) {
		if ( ! $post || 'publish' !== $post->post_status || ! is_post_type_viewable( $post->post_type ) ) {
			return false;
		}
		$o    = MRSH_Options::get();
		$skip = array_merge( array( 'attachment', 'revision', 'nav_menu_item' ), MRSH_Options::to_list( $o['noindex_post_types'] ) );
		return ! in_array( $post->post_type, $skip, true );
	}

	public static function on_transition( $new, $old, $post ) {
		$o = MRSH_Options::get();
		if ( empty( $o['indexnow_enabled'] ) || ! self::valid_key( $o['indexnow_key'] ) || 'publish' !== $new || ! self::eligible( $post ) ) {
			return;
		}
		$url = get_permalink( $post );
		if ( ! $url ) {
			return;
		}
		// IndexNow asks not to resend the same URL within minutes.
		$guard = 'mrsh_in_' . md5( $url );
		if ( get_transient( $guard ) ) {
			return;
		}
		set_transient( $guard, 1, 10 * MINUTE_IN_SECONDS );
		self::$queue[ $url ] = true;
	}

	public static function flush_queue() {
		if ( self::$queue ) {
			$urls        = array_keys( self::$queue );
			self::$queue = array();
			self::submit( $urls, 'auto' );
		}
	}

	public static function explain( $code ) {
		$map = array(
			200 => 'Received by the search engines.',
			202 => 'Received; key check pending. Make sure the key file URL opens.',
			400 => 'Bad request format.',
			403 => 'Key not valid. Open the key file URL and check it shows the key.',
			422 => 'URLs do not belong to this host, or the key does not match.',
			429 => 'Too many requests. Wait before resubmitting.',
		);
		return isset( $map[ $code ] ) ? $map[ $code ] : 'Unexpected response.';
	}

	public static function submit( $urls, $source = 'manual' ) {
		$key = self::key();
		if ( ! self::valid_key( $key ) ) {
			return array( 'ok' => false, 'code' => 0, 'count' => 0, 'message' => 'No valid key yet. Turn on IndexNow and save first.' );
		}
		$host  = wp_parse_url( home_url(), PHP_URL_HOST );
		$clean = array();
		foreach ( (array) $urls as $u ) {
			$u = esc_url_raw( trim( (string) $u ) );
			if ( '' !== $u && wp_parse_url( $u, PHP_URL_HOST ) === $host ) {
				$clean[ $u ] = true;
			}
		}
		$clean = array_slice( array_keys( $clean ), 0, 10000 );
		if ( ! $clean ) {
			return array( 'ok' => false, 'code' => 0, 'count' => 0, 'message' => 'No valid URLs from this site.' );
		}
		$resp = wp_remote_post(
			self::ENDPOINT,
			array(
				'timeout' => 10,
				'headers' => array( 'Content-Type' => 'application/json; charset=utf-8' ),
				'body'    => wp_json_encode(
					array(
						'host'        => $host,
						'key'         => $key,
						'keyLocation' => self::key_url(),
						'urlList'     => $clean,
					)
				),
			)
		);
		if ( is_wp_error( $resp ) ) {
			$code = 0;
			$msg  = $resp->get_error_message();
		} else {
			$code = (int) wp_remote_retrieve_response_code( $resp );
			$msg  = self::explain( $code );
		}
		$result = array( 'ok' => in_array( $code, array( 200, 202 ), true ), 'code' => $code, 'count' => count( $clean ), 'message' => $msg );
		self::log( $source, $result, $clean[0] );
		return $result;
	}

	private static function log( $source, $result, $sample ) {
		$log = get_option( self::LOG, array() );
		$log = is_array( $log ) ? $log : array();
		array_unshift(
			$log,
			array(
				'time'   => time(),
				'source' => $source,
				'count'  => $result['count'],
				'code'   => $result['code'],
				'ok'     => $result['ok'],
				'sample' => $sample,
			)
		);
		update_option( self::LOG, array_slice( $log, 0, 20 ), false );
	}

	public static function log_rows() {
		$log = get_option( self::LOG, array() );
		return is_array( $log ) ? $log : array();
	}

	public static function all_urls() {
		$o     = MRSH_Options::get();
		$skip  = array_merge( array( 'attachment' ), MRSH_Options::to_list( $o['noindex_post_types'] ) );
		$types = array_values( array_diff( array_keys( get_post_types( array( 'public' => true ) ) ), $skip ) );
		$posts = get_posts( array( 'post_type' => $types, 'post_status' => 'publish', 'numberposts' => 500, 'suppress_filters' => true ) );
		$urls  = array( home_url( '/' ) );
		foreach ( $posts as $p ) {
			$urls[] = get_permalink( $p );
		}
		return $urls;
	}
}
