<?php
/**
 * Indexing push agent: every 6 hours it sends new and changed pages to the search engines
 * that accept pushes (IndexNow: Bing, Yandex, Naver, Seznam, Yep). Google reads the sitemap,
 * which this plugin keeps current; Google has no push service for ordinary pages.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Agent {

	const OPT  = 'mrsh_agent';
	const HOOK = 'mrsh_agent_run';

	public static function state() {
		$d = array( 'enabled' => 1, 'last' => 0, 'last_count' => 0, 'last_msg' => '', 'total' => 0 );
		$s = get_option( self::OPT, array() );
		return is_array( $s ) ? array_merge( $d, $s ) : $d;
	}

	private static function save( $s ) {
		update_option( self::OPT, $s, false );
	}

	public static function init() {
		add_filter( 'cron_schedules', array( __CLASS__, 'schedules' ) );
		add_action( self::HOOK, array( __CLASS__, 'run' ) );
		add_action( 'init', array( __CLASS__, 'ensure_scheduled' ) );
		add_action( 'admin_post_mrsh_agent', array( __CLASS__, 'handle' ) );
	}

	public static function schedules( $s ) {
		$s['mrsh_6h'] = array( 'interval' => 6 * HOUR_IN_SECONDS, 'display' => 'Every 6 hours' );
		return $s;
	}

	public static function ensure_scheduled() {
		$on   = ! empty( self::state()['enabled'] );
		$next = wp_next_scheduled( self::HOOK );
		if ( $on && ! $next ) {
			wp_schedule_event( time() + 300, 'mrsh_6h', self::HOOK );
		} elseif ( ! $on && $next ) {
			wp_clear_scheduled_hook( self::HOOK );
		}
	}

	/** Posts worth announcing: public, indexable, changed since $since. */
	public static function changed_urls( $since ) {
		$o     = MRSH_Options::get();
		$skip  = array_merge( array( 'attachment' ), MRSH_Options::to_list( $o['noindex_post_types'] ) );
		$types = array_values( array_diff( array_keys( get_post_types( array( 'public' => true ) ) ), $skip ) );
		$slugs = MRSH_Options::to_list( $o['noindex_slugs'] );
		$posts = get_posts( array(
			'post_type'        => $types,
			'post_status'      => 'publish',
			'numberposts'      => 200,
			'suppress_filters' => true,
			'orderby'          => 'modified',
			'order'            => 'DESC',
			'date_query'       => array( array( 'column' => 'post_modified_gmt', 'after' => gmdate( 'Y-m-d H:i:s', $since ) ) ),
		) );
		$urls = array();
		foreach ( $posts as $p ) {
			if ( in_array( $p->post_name, $slugs, true ) || get_post_meta( $p->ID, '_mrsh_noindex', true ) ) {
				continue;
			}
			$u = get_permalink( $p );
			if ( $u ) {
				$urls[] = $u;
			}
		}
		return $urls;
	}

	public static function run( $all = false, $force = false ) {
		$all = ( true === $all );
		$s   = self::state();
		if ( empty( $s['enabled'] ) && ! $force ) {
			return;
		}
		$o = MRSH_Options::get();
		if ( ! MRSH_IndexNow::valid_key( $o['indexnow_key'] ) || empty( $o['indexnow_enabled'] ) ) {
			$o['indexnow_key']     = MRSH_IndexNow::valid_key( $o['indexnow_key'] ) ? $o['indexnow_key'] : MRSH_IndexNow::new_key();
			$o['indexnow_enabled'] = 1;
			update_option( MRSH_Options::KEY, $o );
		}
		$since = $s['last'] ? (int) $s['last'] - HOUR_IN_SECONDS : time() - 14 * DAY_IN_SECONDS;
		$urls  = $all ? MRSH_IndexNow::all_urls() : self::changed_urls( $since );
		$urls[] = home_url( '/' );
		if ( ! $all && ! $force && count( $urls ) <= 1 ) {
			// Nothing changed: still keep the homepage fresh, but only once a day.
			if ( time() - (int) $s['last'] < DAY_IN_SECONDS ) {
				return;
			}
		}
		$r = MRSH_IndexNow::submit( array_unique( $urls ), $all ? 'agent-all' : 'agent' );
		$s['last']       = time();
		$s['last_count'] = (int) $r['count'];
		$s['last_msg']   = $r['message'];
		if ( ! empty( $r['ok'] ) ) {
			$s['total'] = (int) $s['total'] + (int) $r['count'];
		}
		self::save( $s );
		return $r;
	}

	public static function handle() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_agent' );
		$do = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
		$s  = self::state();
		$m  = '';
		if ( 'toggle' === $do ) {
			$s['enabled'] = empty( $_POST['enabled'] ) ? 0 : 1;
			self::save( $s );
			self::ensure_scheduled();
			$m = $s['enabled'] ? 'Indexing agent is on.' : 'Indexing agent is off.';
		} elseif ( 'now' === $do || 'all' === $do ) {
			$r = self::run( 'all' === $do, true );
			$m = $r ? ( 'Sent ' . $r['count'] . ' URL(s). ' . $r['message'] ) : 'Nothing to send.';
		}
		set_transient( 'mrsh_easy_msg', $m, 60 );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-easy' ) );
		exit;
	}

	public static function panel() {
		$s   = self::state();
		$nxt = wp_next_scheduled( self::HOOK );
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="background:#fff;border:1px solid #ccd0d4;padding:14px 16px;max-width:860px;margin-top:16px"><input type="hidden" name="action" value="mrsh_agent">';
		wp_nonce_field( 'mrsh_agent' );
		echo '<h2 style="margin-top:0">Indexing agent</h2><p>Every 6 hours it sends new and changed pages to Bing, Yandex, Naver, Seznam and other IndexNow engines, so they stay up to date. Google finds changes through your sitemap, which stays current automatically; Google does not accept pushes for normal pages.</p>';
		echo '<p><label><input type="checkbox" name="enabled" value="1"' . checked( ! empty( $s['enabled'] ), true, false ) . '> Keep search engines updated automatically</label></p>';
		echo '<p>Last run: <strong>' . ( $s['last'] ? esc_html( human_time_diff( $s['last'] ) . ' ago: ' . $s['last_count'] . ' URL(s), ' . $s['last_msg'] ) : 'not yet' ) . '</strong><br>Next run: <strong>' . ( $nxt ? esc_html( human_time_diff( time(), $nxt ) . ' from now' ) : 'not scheduled' ) . '</strong><br>Total sent: <strong>' . (int) $s['total'] . '</strong></p>';
		echo '<p><button class="button button-primary" name="do" value="toggle">Save</button> <button class="button" name="do" value="now">Push changes now</button> <button class="button" name="do" value="all">Push every page now</button></p>';
		echo '<p class="description">WordPress runs this when someone visits the site. On low-traffic sites you can add a real server cron that opens wp-cron.php every 15 minutes.</p></form>';
	}
}
