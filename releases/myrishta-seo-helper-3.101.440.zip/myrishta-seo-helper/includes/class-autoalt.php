<?php
/**
 * Automatic image alt text. New pictures get alt text the moment they are uploaded, and a daily job fills any that are
 * still empty (for example pictures that were attached to a profile later). Camera-style or code-style names
 * (IMG_1234, FB_IMG_..., WhatsApp, UUID codes) are never used as alt text; the profile or page the picture belongs to is used instead.
 * Manual buttons: "Run now" and "Also replace code-style alt text". Option: mrsh_autoalt {on, last, n}.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_AutoAlt {

	const OPT  = 'mrsh_autoalt';
	const CRON = 'mrsh_autoalt_daily';

	public static function get() {
		$o = get_option( self::OPT, array() );
		return array_merge( array( 'on' => 1, 'last' => 0, 'n' => 0, 'total' => 0 ), is_array( $o ) ? $o : array() );
	}

	public static function init() {
		add_action( 'add_attachment', array( __CLASS__, 'on_upload' ), 20 );
		add_action( self::CRON, array( __CLASS__, 'daily' ) );
		if ( ! wp_next_scheduled( self::CRON ) ) {
			wp_schedule_event( time() + 900, 'daily', self::CRON );
		}
		add_action( 'admin_post_mrsh_autoalt_run', array( __CLASS__, 'act_run' ) );
		add_action( 'admin_post_mrsh_autoalt_toggle', array( __CLASS__, 'act_toggle' ) );
	}

	/** True when a text looks like a file code and would make poor alt text. */
	public static function is_junk( $t ) {
		$t = trim( (string) $t );
		if ( '' === $t || mb_strlen( $t ) <= 2 ) {
			return true;
		}
		return (bool) preg_match( '/\d{6,}|[0-9a-f]{8}[\s_-][0-9a-f]{4}[\s_-][0-9a-f]{4}|^(img|dsc|fb|wa|snapchat|screenshot|screen shot|image|images|photo|picture|download|me|pxl|vid|file|whatsapp|removebg|untitled|unnamed)\b[\s_-]*[\w\s-]{0,30}$|^[a-z]{0,4}[\s_-]?\d+([\s_-]\d+)*$|\bscaled\b|\bremovebg\b/i', $t );
	}

	/** Build the alt text for one image. */
	public static function make( $id ) {
		$t = html_entity_decode( get_the_title( $id ), ENT_QUOTES, 'UTF-8' );
		$t = trim( preg_replace( '/[-_]+/', ' ', $t ) );
		if ( self::is_junk( $t ) ) {
			$par = (int) wp_get_post_parent_id( $id );
			$pt  = $par ? trim( html_entity_decode( get_the_title( $par ), ENT_QUOTES, 'UTF-8' ) ) : '';
			if ( $pt && ! self::is_junk( $pt ) && 'Auto Draft' !== $pt ) {
				$t = 'listing_type' === get_post_type( $par ) ? 'Profile photo of ' . $pt : $pt;
			} else {
				$t = 'Profile photo on MyRishta.pk free rishta service';
			}
		}
		return sanitize_text_field( mb_substr( $t, 0, 120 ) );
	}

	public static function on_upload( $id ) {
		if ( empty( self::get()['on'] ) || ! wp_attachment_is_image( $id ) ) {
			return;
		}
		if ( '' === (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) ) {
			update_post_meta( $id, '_wp_attachment_image_alt', self::make( $id ) );
		}
	}

	/** Fill empty alt text; with $replace also swap code-style alt text. Returns how many changed. */
	public static function run( $replace = false, $limit = 300 ) {
		$n = 0;
		foreach ( MRSH_Frontend::missing_alt_ids( $limit ) as $id ) {
			update_post_meta( $id, '_wp_attachment_image_alt', self::make( $id ) );
			$n++;
		}
		if ( $replace ) {
			$ids = get_posts( array( 'post_type' => 'attachment', 'post_mime_type' => 'image', 'post_status' => 'inherit', 'posts_per_page' => $limit, 'fields' => 'ids', 'no_found_rows' => true, 'orderby' => 'ID', 'order' => 'DESC', 'meta_query' => array( array( 'key' => '_wp_attachment_image_alt', 'value' => '', 'compare' => '!=' ) ) ) );
			foreach ( $ids as $id ) {
				$alt = (string) get_post_meta( $id, '_wp_attachment_image_alt', true );
				if ( self::is_junk( $alt ) ) {
					$new = self::make( $id );
					if ( $new !== $alt ) {
						update_post_meta( $id, '_wp_attachment_image_alt', $new );
						$n++;
					}
				}
			}
		}
		$o          = self::get();
		$o['last']  = time();
		$o['n']     = $n;
		$o['total'] = (int) $o['total'] + $n;
		update_option( self::OPT, $o, false );
		return $n;
	}

	public static function daily() {
		if ( ! empty( self::get()['on'] ) ) {
			self::run( true, 300 );
		}
	}

	private static function guard( $n ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( $n );
	}

	public static function act_run() {
		self::guard( 'mrsh_autoalt_run' );
		$n = self::run( ! empty( $_POST['replace'] ), 500 );
		set_transient( 'mrsh_notice_' . get_current_user_id(), array( $n ? 'Alt text added or improved on ' . $n . ' image(s).' : 'Nothing to fix. Every image has good alt text.', $n ? 'success' : 'info' ), 120 );
		wp_safe_redirect( admin_url( 'admin.php?page=myrishta-seo' ) );
		exit;
	}

	public static function act_toggle() {
		self::guard( 'mrsh_autoalt_toggle' );
		$o       = self::get();
		$o['on'] = empty( $_POST['on'] ) ? 0 : 1;
		update_option( self::OPT, $o, false );
		wp_safe_redirect( admin_url( 'admin.php?page=myrishta-seo' ) );
		exit;
	}

	/** Small control block shown in the Images card on the dashboard. */
	public static function panel() {
		$o    = self::get();
		$post = esc_url( admin_url( 'admin-post.php' ) );
		echo '<div style="margin-top:12px;padding:12px 14px;border:1px solid #e5e7eb;border-radius:12px;background:#f9fafb">';
		echo '<form method="post" action="' . $post . '" style="margin:0 0 8px"><input type="hidden" name="action" value="mrsh_autoalt_toggle">';
		wp_nonce_field( 'mrsh_autoalt_toggle' );
		echo '<label><input type="checkbox" name="on" value="1"' . checked( ! empty( $o['on'] ), true, false ) . ' onchange="this.form.submit()"> <b>Fix alt text automatically</b></label> ';
		echo '<span class="description">New pictures get alt text when uploaded, and a daily check fills the rest. ' . ( $o['last'] ? 'Last run ' . esc_html( wp_date( 'j M g:i a', (int) $o['last'] ) ) . ', changed ' . (int) $o['n'] . ' (' . (int) $o['total'] . ' in total).' : 'First run is within 15 minutes.' ) . '</span></form>';
		echo '<form method="post" action="' . $post . '" style="margin:0;display:flex;gap:10px;flex-wrap:wrap;align-items:center"><input type="hidden" name="action" value="mrsh_autoalt_run">';
		wp_nonce_field( 'mrsh_autoalt_run' );
		echo '<button class="button button-primary" type="submit">Fix alt text now</button> <button class="button" type="submit" name="replace" value="1">Also replace code-style alt text</button></form>';
		echo '</div>';
	}
}

MRSH_AutoAlt::init();
