<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Frontend {

	private static function org_address() {
		$g = MRSH_Options::org();
		$a = array( '@type' => 'PostalAddress' );
		if ( '' !== $g['street'] ) {
			$a['streetAddress'] = $g['street'];
		}
		if ( '' !== $g['city'] ) {
			$a['addressLocality'] = $g['city'];
		}
		if ( '' !== $g['region'] ) {
			$a['addressRegion'] = $g['region'];
		}
		if ( '' !== $g['postal'] ) {
			$a['postalCode'] = $g['postal'];
		}
		$a['addressCountry'] = 'PK';
		return $a;
	}

	public static function init() {
		add_filter( 'rank_math/frontend/robots', array( __CLASS__, 'rank_math_robots' ) );
		add_filter( 'rank_math/frontend/canonical', array( __CLASS__, 'canonical' ) );
		add_filter( 'wp_robots', array( __CLASS__, 'core_robots' ), 99 );
		add_filter( 'aioseo_canonical_url', array( __CLASS__, 'canonical' ) );
		add_filter( 'aioseo_robots_meta', array( __CLASS__, 'aioseo_robots' ) );
		add_action( 'template_redirect', array( __CLASS__, 'noindex_header' ), 1 );
		add_action( 'wp_head', array( __CLASS__, 'noindex_meta' ), 1 );
		add_filter( 'robots_txt', array( __CLASS__, 'robots_txt' ), 20, 2 );
		add_action( 'wp_head', array( __CLASS__, 'verification_tags' ), 1 );
		add_action( 'wp_head', array( __CLASS__, 'ahrefs_analytics' ), 99 );
		add_action( 'init', array( __CLASS__, 'serve_verification_file' ), 1 );
		add_action( 'wp_head', array( __CLASS__, 'hreflang' ), 2 );
		add_filter( 'language_attributes', array( __CLASS__, 'html_lang' ) );
		add_filter( 'rank_math/opengraph/facebook/image', array( __CLASS__, 'social_fallback' ) );
		add_filter( 'rank_math/opengraph/twitter/image', array( __CLASS__, 'social_fallback' ) );
		add_action( 'wp_head', array( __CLASS__, 'org_schema' ), 30 );
		add_action( 'wp_head', array( __CLASS__, 'website_schema' ), 31 );
		add_action( 'wp_head', array( __CLASS__, 'breadcrumb_schema' ), 32 );
		add_action( 'init', array( __CLASS__, 'speed' ) );
		add_filter( 'wp_resource_hints', array( __CLASS__, 'hints' ), 10, 2 );
	}

	/** Should the current request carry a noindex directive? */
	public static function should_noindex() {
		$o = MRSH_Options::get();

		if ( ! empty( $o['noindex_search'] ) && is_search() ) {
			return true;
		}
		// Only the presence of a query-string key is read, to choose an SEO tag. Nothing is stored or printed.
		foreach ( MRSH_Options::to_list( $o['noindex_params'] ) as $param ) {
			if ( isset( $_GET[ $param ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				return true;
			}
		}
		if ( ( ! empty( $o['noindex_author'] ) && is_author() ) || ( ! empty( $o['noindex_date'] ) && is_date() ) || ( ! empty( $o['noindex_attachment'] ) && is_attachment() ) || ( ! empty( $o['noindex_paged'] ) && is_paged() ) ) {
			return true;
		}
		// Theme-generated /country/... place pages are thin (menu text only), so keep them out of Google.
		$req = isset( $_SERVER['REQUEST_URI'] ) ? strtolower( (string) strtok( (string) $_SERVER['REQUEST_URI'], '?' ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( 0 === strpos( $req, '/country/' ) ) {
			return true;
		}
		$slugs = MRSH_Options::to_list( $o['noindex_slugs'] );
		if ( $slugs && is_page( $slugs ) ) {
			return true;
		}
		if ( is_singular() && get_post_meta( get_queried_object_id(), '_mrsh_noindex', true ) ) {
			return true;
		}
		$types = MRSH_Options::to_list( $o['noindex_post_types'] );
		if ( $types && is_singular( $types ) ) {
			return true;
		}
		$taxes = MRSH_Options::to_list( $o['noindex_taxonomies'] );
		if ( $taxes && is_tax( $taxes ) ) {
			return true;
		}
		// Built-in tag archives all repeat the same posts, so they count as duplicate content.
		if ( $taxes && in_array( 'post_tag', $taxes, true ) && is_tag() ) {
			return true;
		}
		return false;
	}

	public static function rank_math_robots( $robots ) {
		if ( self::should_noindex() ) {
			$robots          = (array) $robots;
			$robots['index'] = 'noindex';
			unset( $robots['noindex'] );
		}
		return $robots;
	}

	/** Used only when Rank Math is inactive, so the tag is never doubled. */
	public static function core_robots( $robots ) {
		if ( self::has_rank_math() ) {
			return $robots;
		}
		if ( self::should_noindex() ) {
			$robots['noindex'] = true;
			$robots['follow']  = true;
			unset( $robots['index'] );
		}
		return $robots;
	}

	public static function canonical( $canonical ) {
		$o = MRSH_Options::get();
		if ( empty( $o['strip_canonical'] ) || ! is_string( $canonical ) || '' === $canonical ) {
			return $canonical;
		}
		$params = MRSH_Options::to_list( $o['noindex_params'] );
		return $params ? remove_query_arg( $params, $canonical ) : $canonical;
	}

	public static function robots_txt( $output, $public ) {
		$o = MRSH_Options::get();
		if ( empty( $o['robots_txt'] ) || ! $public ) {
			return $output;
		}
		$add = '';
		// Internal search, sort and login-redirect URLs make endless near-duplicate pages for crawlers.
		foreach ( array( '/?s=', '/*?s=', '/*&s=', '/*sort=', '/*adid=', '/*noaccess=', '/*eail_not_verified' ) as $dis ) {
			if ( false === strpos( $output, 'Disallow: ' . $dis ) ) {
				$add .= 'Disallow: ' . $dis . "\n";
			}
		}
		foreach ( preg_split( '/\R/', (string) $o['robots_disallow'] ) as $path ) {
			$path = trim( $path );
			if ( '' === $path || '/' !== $path[0] || preg_match( '/\s/', $path ) ) {
				continue;
			}
			if ( false === strpos( $output, 'Disallow: ' . $path ) ) {
				$add .= 'Disallow: ' . $path . "\n";
			}
		}
		if ( '' !== $add ) {
			if ( preg_match( '/^Sitemap:/mi', $output, $m, PREG_OFFSET_CAPTURE ) ) {
				$pos    = $m[0][1];
				$output = rtrim( substr( $output, 0, $pos ) ) . "\n" . $add . "\n" . substr( $output, $pos );
			} else {
				$output = rtrim( $output ) . "\n" . $add;
			}
		}
		$sitemap = trim( (string) $o['sitemap_url'] );
		if ( '' !== $sitemap && false === stripos( $output, 'Sitemap:' ) ) {
			$output = rtrim( $output ) . "\n\nSitemap: " . esc_url_raw( $sitemap ) . "\n";
		}
		return $output;
	}

	/** Option key => meta tag name. Each engine states its own tag name. */
	public static function verification_map() {
		return array(
			'google_verification'    => 'google-site-verification',
			'bing_verification'      => 'msvalidate.01',
			'yandex_verification'    => 'yandex-verification',
			'baidu_verification'     => 'baidu-site-verification',
			'naver_verification'     => 'naver-site-verification',
			'seznam_verification'    => 'seznam-wmt',
			'pinterest_verification' => 'p:domain_verify',
			'facebook_verification'  => 'facebook-domain-verification',
			'ahrefs_verification'    => 'ahrefs-site-verification',
		);
	}

	/**
	 * Auto-sync: remember verification tags that other plugins or the theme print on the home page
	 * (Site Kit, a theme field), so they stay in place if that source is switched off later.
	 */
	public static function capture_verification( $head ) {
		if ( ! is_front_page() || false === stripos( $head, 'verif' ) && false === stripos( $head, 'msvalidate' ) && false === stripos( $head, 'domain_verify' ) && false === stripos( $head, 'seznam' ) ) {
			return;
		}
		$o     = MRSH_Options::get();
		$found = array();
		foreach ( self::verification_map() as $key => $name ) {
			if ( '' !== $o[ $key ] ) {
				continue;
			}
			if ( preg_match( '/<meta\b[^>]*name=["\']' . preg_quote( $name, '/' ) . '["\'][^>]*content=["\']([A-Za-z0-9_\-:.=]{8,200})["\']/i', $head, $m ) ) {
				$found[ $key ] = $m[1];
			}
		}
		if ( $found ) {
			$cur = get_option( MRSH_Options::KEY, array() );
			update_option( MRSH_Options::KEY, array_merge( is_array( $cur ) ? $cur : array(), $found ) );
		}
	}

	/** Ownership tags for search engines and social platforms, homepage only. */
	/** Ahrefs Web Analytics. The site owner supplied this tag. Not output in admin, feeds or previews. */
	public static function ahrefs_analytics() {
		if ( is_admin() || is_feed() || is_preview() || is_customize_preview() ) {
			return;
		}
		$key = apply_filters( 'mrsh_ahrefs_key', 'xUWL6DlWe53d/MxKSNnqrw' );
		if ( ! is_string( $key ) || ! preg_match( '#^[A-Za-z0-9/+=_-]{10,64}$#', $key ) ) {
			return;
		}
		echo '<script src="https://analytics.ahrefs.com/analytics.js" data-key="' . esc_attr( $key ) . '" async></script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	public static function verification_tags() {
		if ( ! is_front_page() ) {
			return;
		}
		$o = MRSH_Options::get();
		foreach ( self::verification_map() as $key => $name ) {
			if ( '' !== $o[ $key ] ) {
				echo '<meta name="' . esc_attr( $name ) . '" content="' . esc_attr( $o[ $key ] ) . '">' . "\n";
			}
		}
		foreach ( MRSH_Options::lines( $o['verify_custom'] ) as $l ) {
			$kv = explode( '=', $l, 2 );
			if ( 2 === count( $kv ) ) {
				echo '<meta name="' . esc_attr( trim( $kv[0] ) ) . '" content="' . esc_attr( trim( $kv[1] ) ) . '">' . "\n";
			}
		}
	}

	/** Verification files (Google .html, Bing BingSiteAuth.xml, Yandex .html) served from the site root. */
	public static function serve_verification_file() {
		$o = MRSH_Options::get();
		if ( '' === $o['verify_files'] || empty( $_SERVER['REQUEST_URI'] ) ) {
			return;
		}
		$path = strtok( (string) wp_unslash( $_SERVER['REQUEST_URI'] ), '?' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$base = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		$name = ltrim( substr( $path, strlen( $base ) ), '/' );
		if ( ! preg_match( '/^[A-Za-z0-9_\-]{3,80}\.(html|xml|txt)$/', $name ) ) {
			return;
		}
		foreach ( MRSH_Options::lines( $o['verify_files'] ) as $l ) {
			$parts = explode( '|', $l, 2 );
			if ( 2 === count( $parts ) && trim( $parts[0] ) === $name ) {
				status_header( 200 );
				nocache_headers();
				header( 'Content-Type: ' . ( preg_match( '/\.xml$/', $name ) ? 'application/xml' : 'text/plain' ) . '; charset=utf-8' );
				echo trim( $parts[1] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- validated on save
				exit;
			}
		}
	}

	/** The site's own logo from WordPress (custom logo, else site icon). */
	public static function site_logo() {
		$id   = (int) get_theme_mod( 'custom_logo' );
		$logo = $id ? wp_get_attachment_image_url( $id, 'full' ) : '';
		if ( ! $logo ) {
			$logo = get_site_icon_url( 512 );
		}
		if ( ! $logo && defined( 'MRSH_URL' ) ) {
			$logo = MRSH_URL . 'assets/logo-512.png';
		}
		return $logo ? $logo : '';
	}

	public static function has_aioseo() {
		return defined( 'AIOSEO_VERSION' ) || function_exists( 'aioseo' );
	}

	/** Any SEO plugin that prints its own titles, schema and breadcrumbs. */
	public static function has_seo_plugin() {
		return self::has_rank_math() || self::has_aioseo() || defined( 'WPSEO_VERSION' );
	}

	public static function seo_plugin_name() {
		if ( self::has_rank_math() ) {
			return 'Rank Math';
		}
		if ( self::has_aioseo() ) {
			return 'All in One SEO';
		}
		return defined( 'WPSEO_VERSION' ) ? 'Yoast SEO' : '';
	}

	/** Header works even where the SEO plugin removes WordPress's robots tag (All in One SEO). */
	public static function noindex_header() {
		if ( is_admin() || headers_sent() || self::has_rank_math() || ! self::should_noindex() ) {
			return;
		}
		header( 'X-Robots-Tag: noindex, follow', true );
	}

	/** All in One SEO builds one robots tag from this array, so no second tag is needed. */
	public static function aioseo_robots( $attributes ) {
		if ( is_array( $attributes ) && self::should_noindex() ) {
			$attributes['noindex'] = 'noindex';
			unset( $attributes['index'] );
		}
		return $attributes;
	}

	public static function noindex_meta() {
		if ( ! self::has_aioseo() && ! self::has_seo_plugin() && ! function_exists( 'wp_robots' ) && self::should_noindex() ) {
			echo '<meta name="robots" content="noindex, follow">' . "\n";
		}
	}

	public static function has_rank_math() {
		return defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' ) || class_exists( '\\RankMath\\Helper' ) || function_exists( 'rank_math' );
	}

	/** Share image: chosen image, else the site logo. */
	public static function social_image() {
		$o = MRSH_Options::get();
		if ( '' !== $o['social_image'] ) {
			return $o['social_image'];
		}
		return defined( 'MRSH_URL' ) ? MRSH_URL . 'assets/og-image.jpg' : self::site_logo();
	}

	public static function social_fallback( $image ) {
		return empty( $image ) ? self::social_image() : $image;
	}

	/** Only when no SEO plugin prints share tags itself. */
	public static function social_image_tags() {
		if ( self::has_seo_plugin() || ! is_front_page() || '' === self::social_image() ) {
			return;
		}
		echo '<meta property="og:image" content="' . esc_url( self::social_image() ) . '">' . "\n";
		echo '<meta name="twitter:image" content="' . esc_url( self::social_image() ) . '">' . "\n";
	}

	/** Image attachments with no alt text. */
	public static function missing_alt_ids( $limit = 500 ) {
		return get_posts( array(
			'post_type'      => 'attachment',
			'post_mime_type' => 'image',
			'post_status'    => 'inherit',
			'posts_per_page' => $limit,
			'fields'         => 'ids',
			'no_found_rows'  => true,
			'meta_query'     => array(
				'relation' => 'OR',
				array( 'key' => '_wp_attachment_image_alt', 'compare' => 'NOT EXISTS' ),
				array( 'key' => '_wp_attachment_image_alt', 'value' => '', 'compare' => '=' ),
			),
		) );
	}

	/** Language of the current single post or page: "ur-PK" when the text is mostly Urdu script, else "en-PK". */
	public static function content_lang() {
		static $cache = array();
		if ( ! is_singular() ) {
			return 'en-PK';
		}
		$id = (int) get_queried_object_id();
		if ( isset( $cache[ $id ] ) ) {
			return $cache[ $id ];
		}
		$post = get_post( $id );
		$text = $post ? wp_strip_all_tags( $post->post_title . ' ' . $post->post_content ) : '';
		$all  = preg_match_all( '/\p{L}/u', $text );
		$ur   = preg_match_all( '/\p{Arabic}/u', $text );
		$cache[ $id ] = ( $all > 20 && $ur / max( 1, $all ) > 0.4 ) ? 'ur-PK' : 'en-PK';
		return $cache[ $id ];
	}

	/** Declare the real language in the <html> tag on Urdu pages (the layout direction is left to the theme). */
	public static function html_lang( $output ) {
		if ( is_admin() || 'ur-PK' !== self::content_lang() ) {
			return $output;
		}
		return preg_replace( '/lang="[^"]*"/', 'lang="ur-PK"', $output, 1 );
	}

	/** Self-referencing Pakistan language tag on indexable pages. */
	public static function hreflang() {
		$o = MRSH_Options::get();
		if ( empty( $o['pk_hreflang'] ) || self::should_noindex() ) {
			return;
		}
		if ( (int) get_query_var( 'paged' ) > 1 ) {
			return;
		}
		$url = '';
		if ( is_front_page() ) {
			$url = home_url( '/' );
		} elseif ( is_singular() ) {
			$url = get_permalink();
		}
		if ( $url ) {
			echo '<link rel="alternate" hreflang="' . esc_attr( self::content_lang() ) . '" href="' . esc_url( $url ) . '">' . "\n";
			echo '<link rel="alternate" hreflang="x-default" href="' . esc_url( $url ) . '">' . "\n";
		}
	}

	public static function default_sitemap() {
		return self::has_seo_plugin() ? home_url( '/sitemap_index.xml' ) : home_url( '/wp-sitemap.xml' );
	}

	public static function website_schema() {
		$o = MRSH_Options::get();
		if ( empty( $o['website_schema'] ) || self::has_seo_plugin() || ! is_front_page() ) {
			return;
		}
		$data = array(
			'@context'        => 'https://schema.org',
			'@type'           => 'WebSite',
			'name'            => '' !== $o['org_name'] ? $o['org_name'] : get_bloginfo( 'name' ),
			'url'             => home_url( '/' ),
			'inLanguage'      => 'en-PK',
			'potentialAction' => array(
				'@type'       => 'SearchAction',
				'target'      => home_url( '/?s={search_term_string}' ),
				'query-input' => 'required name=search_term_string',
			),
		);
		echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/** Only when no SEO plugin already prints breadcrumbs. */
	public static function breadcrumb_schema() {
		$o = MRSH_Options::get();
		if ( empty( $o['breadcrumb_schema'] ) || self::has_seo_plugin() || ! is_singular() || is_front_page() || self::should_noindex() ) {
			return;
		}
		$items = array( array( '@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => home_url( '/' ) ) );
		$pos   = 2;
		$post  = get_queried_object();
		foreach ( array_reverse( get_post_ancestors( $post ) ) as $aid ) {
			$items[] = array( '@type' => 'ListItem', 'position' => $pos++, 'name' => html_entity_decode( get_the_title( $aid ), ENT_QUOTES, 'UTF-8' ), 'item' => get_permalink( $aid ) );
		}
		$items[] = array( '@type' => 'ListItem', 'position' => $pos, 'name' => html_entity_decode( get_the_title( $post ), ENT_QUOTES, 'UTF-8' ), 'item' => get_permalink( $post ) );
		$data    = array( '@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => $items );
		echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/** Small speed wins that help Core Web Vitals. */
	public static function speed() {
		$o = MRSH_Options::get();
		if ( ! empty( $o['speed_emojis'] ) ) {
			remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
			remove_action( 'wp_print_styles', 'print_emoji_styles' );
		}
		if ( ! empty( $o['clean_generator'] ) ) {
			remove_action( 'wp_head', 'wp_generator' );
			add_filter( 'the_generator', '__return_empty_string' );
		}
		if ( ! empty( $o['clean_shortlink'] ) ) {
			remove_action( 'wp_head', 'wp_shortlink_wp_head', 10 );
		}
		if ( ! empty( $o['clean_rsd'] ) ) {
			remove_action( 'wp_head', 'rsd_link' );
			remove_action( 'wp_head', 'wlwmanifest_link' );
		}
		if ( ! empty( $o['clean_rest_links'] ) ) {
			remove_action( 'wp_head', 'rest_output_link_wp_head', 10 );
		}
		if ( ! empty( $o['speed_embeds'] ) ) {
			remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
			remove_action( 'wp_head', 'wp_oembed_add_host_js' );
		}
	}

	public static function hints( $urls, $type ) {
		if ( 'preconnect' === $type && ! empty( MRSH_Options::get()['speed_preconnect'] ) ) {
			$urls[] = 'https://fonts.gstatic.com';
		}
		return $urls;
	}

	public static function org_schema() {
		$o = MRSH_Options::get();
		if ( empty( $o['org_schema'] ) || ! is_front_page() ) {
			return;
		}
		$data = array(
			'@context' => 'https://schema.org',
			'@type'    => 'NGO',
			'name'     => '' !== $o['org_name'] ? $o['org_name'] : get_bloginfo( 'name' ),
			'alternateName' => 'MyRishta.pk',
			'url'      => home_url( '/' ),
			'description' => 'A non-profit organization in ' . ( '' !== MRSH_Options::org()['city'] ? MRSH_Options::org()['city'] : 'Pakistan' ) . ', Pakistan, running MyRishta.pk, a free rishta and matrimonial service for Pakistani families in Pakistan and abroad.',
			'address'  => self::org_address(),
		);
		if ( '' !== $o['org_phone'] ) {
			$data['telephone'] = $o['org_phone'];
		}
		if ( '' !== $o['org_email'] ) {
			$data['email'] = $o['org_email'];
		}
		$logo = '' !== $o['org_logo'] ? $o['org_logo'] : ( defined( 'MRSH_URL' ) ? MRSH_URL . 'assets/logos/logo-mark-padded.png' : self::site_logo() );
		if ( '' !== $logo ) {
			$data['logo'] = esc_url_raw( $logo );
		}
		if ( defined( 'MRSH_URL' ) ) {
			$data['image'] = array( esc_url_raw( MRSH_URL . 'assets/logos/og-image-1200x630.png' ), esc_url_raw( MRSH_URL . 'assets/logos/ads-square-1200x1200.png' ), esc_url_raw( MRSH_URL . 'assets/og-image.jpg' ) );
		}
		$data['location']   = array(
			'@type'   => 'Place',
			'name'    => 'My Rishta Office',
			'address' => self::org_address(),
			'geo'     => array( '@type' => 'GeoCoordinates', 'latitude' => 31.614324, 'longitude' => 74.265098 ),
			'hasMap'  => 'https://maps.app.goo.gl/KytbDLdkV5KrPZSj7',
		);
		$data['areaServed'] = array( '@type' => 'Country', 'name' => 'Pakistan' );
		if ( '' !== $o['org_email'] || '' !== $o['org_phone'] ) {
			$cp = array( '@type' => 'ContactPoint', 'contactType' => 'customer support', 'areaServed' => 'PK', 'availableLanguage' => array( 'English', 'Urdu' ) );
			if ( '' !== $o['org_email'] ) {
				$cp['email'] = $o['org_email'];
			}
			if ( '' !== $o['org_phone'] ) {
				$cp['telephone'] = $o['org_phone'];
			}
			$data['contactPoint'] = $cp;
		}
		$same = array_values( array_filter( array_map( 'esc_url_raw', preg_split( '/\R/', (string) $o['org_same_as'] ) ) ) );
		if ( $same ) {
			$data['sameAs'] = $same;
		}
		echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG ) . "</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
