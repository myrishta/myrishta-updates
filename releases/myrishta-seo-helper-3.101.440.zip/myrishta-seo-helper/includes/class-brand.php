<?php
/**
 * Own logo on the WordPress login page, the admin bar and the admin area.
 */
defined( 'ABSPATH' ) || exit;

class MRSH_Brand {

	public static function init() {
		add_shortcode( 'mrsh_address', array( 'MRSH_PK', 'sc_address' ) );
		add_shortcode( 'mrsh_phone', array( 'MRSH_PK', 'sc_phone' ) );
		add_shortcode( 'mrsh_email', array( 'MRSH_PK', 'sc_email' ) );
		add_action( 'login_enqueue_scripts', array( __CLASS__, 'login_css' ) );
		add_filter( 'login_headerurl', array( __CLASS__, 'login_url' ) );
		add_filter( 'login_headertext', array( __CLASS__, 'login_text' ) );
		add_action( 'login_head', array( __CLASS__, 'icons' ) );
		add_action( 'admin_head', array( __CLASS__, 'icons' ) );
		add_action( 'admin_head', array( __CLASS__, 'bar_css' ) );
		add_action( 'wp_head', array( __CLASS__, 'bar_css_front' ), 99 );
		add_filter( 'admin_footer_text', array( __CLASS__, 'footer' ) );
	}

	public static function login_url() {
		return home_url( '/' );
	}

	public static function login_text() {
		return 'My Rishta Pakistan';
	}

	public static function icons() {
		$u = MRSH_URL . 'assets/';
		$v = '?v=' . MRSH_VERSION;
		echo '<link rel="icon" type="image/png" sizes="32x32" href="' . esc_url( $u . 'icon-32.png' . $v ) . '">' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<link rel="icon" type="image/png" sizes="192x192" href="' . esc_url( $u . 'icon-192.png' . $v ) . '">' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<link rel="apple-touch-icon" href="' . esc_url( $u . 'icon-180.png' . $v ) . '">' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	public static function login_css() {
		$logo = esc_url( MRSH_URL . 'assets/logos/google-profile-logo-720x720.png?v=' . MRSH_VERSION );
		echo '<style id="mrsh-login">'
			. 'body.login{min-height:100vh;display:flex;align-items:center;justify-content:center;background:radial-gradient(520px 520px at 100% 0,rgba(155,27,75,.14),transparent 70%),radial-gradient(460px 460px at 0 100%,rgba(201,150,47,.18),transparent 70%),#fbf5f1!important}'
			. '#login{width:min(400px,92vw)!important;padding:0!important;margin:0 auto}'
			. '.googlesitekit-sign-in-with-google__frontend-output-button,#login>.googlesitekit-sign-in-with-google__frontend-output-button{display:none!important}'
			. '#login h1{margin:0 0 18px}'
			. '#login h1 a{background:#fff url(' . $logo . ') center/cover no-repeat!important;width:92px!important;height:92px!important;margin:0 auto!important;border-radius:24px!important;box-shadow:0 14px 30px rgba(110,18,48,.28)!important;text-indent:-9999px;overflow:hidden}'
			. '.login form{margin:0!important;padding:28px 26px!important;border:0!important;border-radius:24px!important;background:#fff!important;border:1px solid #efe3e7!important;box-shadow:0 22px 50px rgba(110,18,48,.14)!important}'
			. '.login label{font-size:.86rem!important;font-weight:700!important;color:#2b2433!important}'
			. '.login form .input,.login input[type=text],.login input[type=password]{height:50px!important;margin:6px 0 14px!important;padding:0 15px!important;font-size:1rem!important;border:1.5px solid #e4dfee!important;border-radius:14px!important;background:#fbfaff!important;box-shadow:none!important}'
			. '.login input:focus{border-color:#9b1b4b!important;box-shadow:0 0 0 4px rgba(155,27,75,.16)!important;outline:0!important}'
			. '.login .button-primary{width:100%!important;float:none!important;height:52px!important;margin-top:6px!important;border:0!important;border-radius:15px!important;font-size:1.04rem!important;font-weight:700!important;background:linear-gradient(135deg,#9b1b4b,#6e1230)!important;color:#fff!important;text-shadow:none!important;box-shadow:0 12px 24px rgba(110,18,48,.35)!important}'
			. '.login .button-primary:hover,.login .button-primary:focus{filter:brightness(1.06);color:#fff!important}'
			. '.login .forgetmenot{float:none!important;margin:0 0 14px!important}.login .submit{margin:0!important}'
			. '.login .button.wp-hide-pw{color:#6e1230!important;top:7px!important}'
			. '.login #nav,.login #backtoblog{text-align:center;padding:0!important;margin:16px 0 0!important}'
			. '.login #nav a,.login #backtoblog a{color:#6e1230!important;font-weight:600;text-shadow:none}'
			. '.login .message,.login .notice,.login #login_error{border:0!important;border-radius:14px!important;box-shadow:0 8px 20px rgba(20,10,70,.18)!important}'
			. '.login .privacy-policy-page-link{display:none}'
			. '.login .mrsh-soc,.login .mrsh-soc .sb{box-sizing:border-box;max-width:100%}.login .mrsh-soc .sb{width:100%}'
			. '.language-switcher{display:none}'
			. '</style>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	private static function bar_rules() {
		$i = esc_url( MRSH_URL . 'assets/icon-48.png?v=' . MRSH_VERSION );
		return '#wpadminbar #wp-admin-bar-wp-logo>.ab-item .ab-icon:before{content:""!important;display:block;width:22px;height:22px;margin-top:5px;background:url(' . $i . ') center/contain no-repeat!important;color:transparent!important}'
			. '#wpadminbar #wp-admin-bar-wp-logo>.ab-item .ab-icon{width:24px;height:32px}'
			. '#adminmenuwrap{border-top:0}';
	}

	public static function bar_css() {
		echo '<style id="mrsh-bar">' . self::bar_rules() . '</style>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	public static function bar_css_front() {
		if ( is_admin_bar_showing() ) {
			echo '<style id="mrsh-bar">' . self::bar_rules() . '</style>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}

	public static function footer() {
		return 'My Rishta Pakistan, free rishta service for Pakistan.';
	}
}
