<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Admin {

	const CAP = 'manage_options';

	public static function init() {
		add_action( 'admin_bar_menu', array( __CLASS__, 'admin_bar' ), 100 );
		if ( ! is_admin() ) {
			return;
		}
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'wp_dashboard_setup', array( __CLASS__, 'dash_widget' ), 20 );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_metabox' ) );
		add_action( 'admin_post_mrsh_export', array( 'MRSH_Keywords', 'export_csv' ) );
		add_action( 'admin_post_mrsh_run_checks', array( __CLASS__, 'handle_checks' ) );
		add_action( 'admin_post_mrsh_scan', array( __CLASS__, 'handle_scan' ) );
		add_action( 'admin_post_mrsh_indexnow_submit', array( __CLASS__, 'handle_indexnow_submit' ) );
		add_action( 'admin_post_mrsh_indexnow_all', array( __CLASS__, 'handle_indexnow_all' ) );
		add_action( 'admin_post_mrsh_create_drafts', array( __CLASS__, 'handle_create_drafts' ) );
		add_action( 'admin_post_mrsh_csv_preview', array( __CLASS__, 'handle_csv_preview' ) );
		add_action( 'admin_post_mrsh_add_phrases', array( __CLASS__, 'handle_add_phrases' ) );
		add_action( 'admin_post_mrsh_remove_phrase', array( __CLASS__, 'handle_remove_phrase' ) );
		add_action( 'admin_post_mrsh_import_aioseo', array( __CLASS__, 'handle_import_aioseo' ) );
		add_action( 'admin_post_mrsh_verify_test', array( __CLASS__, 'handle_verify_test' ) );
		add_action( 'admin_post_mrsh_fill_alt', array( __CLASS__, 'handle_fill_alt' ) );
		add_action( 'admin_post_mrsh_scan_now', array( __CLASS__, 'handle_scan_now' ) );
		add_action( 'admin_post_mrsh_clear_searches', array( __CLASS__, 'handle_clear_searches' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( MRSH_FILE ), array( __CLASS__, 'action_links' ) );
	}

	/* ---------------- Menus ---------------- */

	private static function pages() {
		return array(
			'myrishta-seo'          => array( 'Dashboard', 'page_dashboard' ),
			'myrishta-seo-rules'    => array( 'Rules', 'page_rules' ),
			'myrishta-seo-engines'  => array( 'Search Engines', 'page_engines' ),
			'myrishta-seo-keywords' => array( 'Keyword Bank', 'page_keywords' ),
			'myrishta-seo-discover' => array( 'Discover', 'page_discover' ),
			'myrishta-seo-coverage' => array( 'Coverage', 'page_coverage' ),
			'myrishta-seo-tools'    => array( 'Speed Tools', 'page_tools' ),
			'myrishta-seo-backup'   => array( 'Backup & Restore', 'page_backup' ),
		);
	}

	public static function url( $slug ) {
		return admin_url( 'admin.php?page=' . $slug );
	}

	public static function menu() {
		add_menu_page( 'MyRishta Admin', 'MyRishta Admin', self::CAP, 'myrishta-seo', array( __CLASS__, 'page_dashboard' ), 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMCAyMCI+PHBhdGggZmlsbD0iI2E3YWFhZCIgZmlsbC1ydWxlPSJldmVub2RkIiBkPSJNOC41IDEuNWE3IDcgMCAxIDAgNC4yIDEyLjZsNC40IDQuNCAxLjQtMS40LTQuNC00LjRBNyA3IDAgMCAwIDguNSAxLjV6bTAgMmE1IDUgMCAxIDEgMCAxMCA1IDUgMCAwIDEgMC0xMHoiLz48cGF0aCBmaWxsPSIjYTdhYWFkIiBkPSJNOS43IDQuN2EzLjYgMy42IDAgMSAwIDAgNi42IDIuOSAyLjkgMCAxIDEgMC02LjZ6Ii8+PHBhdGggZmlsbD0iI2E3YWFhZCIgZD0iTTExLjQgNi4ybC41IDEuMSAxLjIuMS0uOS44LjMgMS4yLTEuMS0uNi0xLjEuNi4zLTEuMi0uOS0uOCAxLjItLjF6Ii8+PC9zdmc+', 58 );
		foreach ( self::pages() as $slug => $page ) {
			add_submenu_page( 'myrishta-seo', 'MyRishta SEO: ' . $page[0], $page[0], self::CAP, $slug, array( __CLASS__, $page[1] ) );
		}
		// External link to the private SEO dashboard (opens in Claude; sharing is controlled there).
		global $submenu;
		$dash = apply_filters( 'mrsh_seo_dashboard_url', 'https://claude.ai/artifact/PSzSxWczV9RZ3XktLtNpr7' );
		if ( is_array( $submenu ) && isset( $submenu['myrishta-seo'] ) && is_string( $dash ) && 0 === strpos( $dash, 'https://' ) ) {
			$submenu['myrishta-seo'][] = array( 'SEO Dashboard &#8599;', self::CAP, esc_url( $dash ) ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		}
	}

	/** WordPress Dashboard box: quick SEO status and links. Shown or hidden from Screen Options. */
	public static function dash_widget() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		wp_add_dashboard_widget( 'mrsh_seo_widget', 'MyRishta SEO', array( __CLASS__, 'dash_widget_body' ) );
	}

	public static function dash_widget_body() {
		$pages   = wp_count_posts( 'page' );
		$posts   = wp_count_posts( 'post' );
		$missing = count( MRSH_Frontend::missing_alt_ids( 500 ) );
		$log     = MRSH_IndexNow::log_rows();
		$last    = $log ? $log[0] : null;
		$o       = MRSH_Options::get();
		MRSH_Watchdog::box();
		MRSH_AppRedirect::box();
		echo '<ul style="margin:0 0 12px;padding:0;list-style:none;line-height:1.9">';
		echo '<li><strong>' . (int) $pages->publish . '</strong> published pages, <strong>' . (int) $posts->publish . '</strong> published posts</li>';
		echo '<li>Images without alt text: <strong>' . (int) $missing . '</strong></li>';
		echo '<li>IndexNow (Bing, Yandex and others): <strong>' . ( ! empty( $o['indexnow_enabled'] ) ? 'on' : 'off' ) . '</strong>';
		if ( $last ) {
			echo ', last sent ' . esc_html( human_time_diff( (int) $last['time'] ) ) . ' ago (' . (int) $last['count'] . ' URL' . ( 1 === (int) $last['count'] ? '' : 's' ) . ', ' . ( ! empty( $last['ok'] ) ? 'accepted' : 'not accepted' ) . ')';
		}
		echo '</li></ul>';
		$dash = apply_filters( 'mrsh_seo_dashboard_url', 'https://claude.ai/artifact/PSzSxWczV9RZ3XktLtNpr7' );
		echo '<p style="margin:0;display:flex;flex-wrap:wrap;gap:8px">';
		if ( is_string( $dash ) && 0 === strpos( $dash, 'https://' ) ) {
			echo '<a class="button button-primary" target="_blank" rel="noopener" href="' . esc_url( $dash ) . '">SEO dashboard</a>';
		}
		echo '<a class="button" target="_blank" rel="noopener" href="https://search.google.com/search-console">Search Console</a>';
		echo '<a class="button" href="' . esc_url( self::url( 'myrishta-seo-engines' ) ) . '">Search Engines</a>';
		echo '</p>';
	}

	/** Top toolbar: quick links everywhere, and the indexing state of the page being viewed. */
	public static function admin_bar( $bar ) {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		$bar->add_node(
			array(
				'id'    => 'mrsh',
				'title' => 'MyRishta SEO',
				'href'  => self::url( 'myrishta-seo' ),
			)
		);
		foreach ( self::pages() as $slug => $page ) {
			$bar->add_node(
				array(
					'id'     => 'mrsh-' . $slug,
					'parent' => 'mrsh',
					'title'  => $page[0],
					'href'   => self::url( $slug ),
				)
			);
		}
		if ( ! is_admin() ) {
			$noindex = MRSH_Frontend::should_noindex();
			$bar->add_node(
				array(
					'id'     => 'mrsh-state',
					'parent' => 'mrsh',
					'title'  => $noindex ? 'This page: noindex' : 'This page: indexable',
					'href'   => self::url( 'myrishta-seo-rules' ),
				)
			);
		}
	}

	public static function action_links( $links ) {
		array_unshift( $links, '<a href="' . esc_url( self::url( 'myrishta-seo' ) ) . '">Dashboard</a>' );
		return $links;
	}

	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, 'myrishta-seo' ) ) {
			return;
		}
		wp_enqueue_style( 'mrsh-admin', MRSH_URL . 'assets/admin.css', array(), MRSH_VERSION );
		wp_enqueue_script( 'mrsh-admin', MRSH_URL . 'assets/admin.js', array(), MRSH_VERSION, true );
	}

	public static function register() {
		register_setting( 'mrsh_group', MRSH_Options::KEY, array( 'sanitize_callback' => array( 'MRSH_Options', 'sanitize' ) ) );
	}

	/* ---------------- Form handlers ---------------- */

	public static function handle_checks() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_run_checks' );
		MRSH_Checks::run();
		wp_safe_redirect( self::url( 'myrishta-seo' ) );
		exit;
	}

	public static function handle_scan() {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_scan' );
		MRSH_Keywords::site_report( true );
		wp_safe_redirect( self::url( 'myrishta-seo-coverage' ) );
		exit;
	}

	/* ---------------- Layout helpers ---------------- */

	public static function open( $title, $lead ) {
		$logo = MRSH_URL . 'assets/seo-app-icon-128.png';
		echo '<div class="wrap mrsh-wrap"><div class="mrsh-hero"><div class="mrsh-hero-main">';
		if ( $logo ) {
			echo '<img class="mrsh-logo" src="' . esc_url( $logo ) . '" width="64" height="64" alt="MyRishta SEO">';
		}
		echo '<div><h1>' . esc_html( $title ) . '</h1><p>' . esc_html( $lead ) . '</p></div></div><span class="mrsh-ver">v' . esc_html( MRSH_VERSION ) . '</span></div>';
		self::nav();
		$note = get_transient( 'mrsh_notice_' . get_current_user_id() );
		if ( is_array( $note ) ) {
			delete_transient( 'mrsh_notice_' . get_current_user_id() );
			echo '<div class="notice notice-' . esc_attr( $note[1] ) . ' is-dismissible"><p>' . esc_html( $note[0] ) . '</p></div>';
		}
		settings_errors();
	}

	/** Navigation bar shown on every MyRishta SEO screen, grouped by job. */
	public static function nav() {
		$cur    = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$groups = array(
			'Overview' => array( 'myrishta-seo' => 'Dashboard', 'mrsh-easy' => 'Easy Setup', 'myrishta-seo-backup' => 'Backup & Restore' ),
			'Audit & speed' => array( 'mrsh-audit' => 'Site Audit', 'mrsh-psi' => 'PageSpeed', 'myrishta-seo-tools' => 'Speed Tools', 'mrsh-live' => 'Live Users' ),
			'Search' => array( 'myrishta-seo-engines' => 'Search Engines', 'myrishta-seo-rules' => 'Rules', 'myrishta-seo-keywords' => 'Keywords', 'myrishta-seo-discover' => 'Discover', 'myrishta-seo-coverage' => 'Coverage' ),
			'Security' => array( 'mrsh-2fa' => 'Login Security' ),
		);
		echo '<nav class="mrsh-nav" aria-label="MyRishta SEO">';
		foreach ( $groups as $label => $items ) {
			echo '<div class="mrsh-nav-group"><span class="mrsh-nav-label">' . esc_html( $label ) . '</span><span class="mrsh-nav-items">';
			foreach ( $items as $slug => $name ) {
				$ic = array( 'myrishta-seo' => 'dash', 'mrsh-easy' => 'wand', 'myrishta-seo-backup' => 'backup', 'mrsh-audit' => 'audit', 'mrsh-psi' => 'speed', 'myrishta-seo-tools' => 'bolt', 'mrsh-live' => 'users', 'myrishta-seo-engines' => 'globe', 'myrishta-seo-rules' => 'sliders', 'myrishta-seo-keywords' => 'tag', 'myrishta-seo-discover' => 'spark', 'myrishta-seo-coverage' => 'layers', 'mrsh-2fa' => 'lock' );
				echo '<a class="mrsh-nav-item' . ( $slug === $cur ? ' is-active' : '' ) . '"' . ( isset( $ic[ $slug ] ) ? ' data-i="' . esc_attr( $ic[ $slug ] ) . '"' : '' ) . ' href="' . esc_url( self::url( $slug ) ) . '">' . esc_html( $name ) . '</a>';
			}
			echo '</span></div>';
		}
		echo '</nav>';
	}

	/** A number tile used in rows of results. */
	public static function tile( $value, $label, $tone = '', $href = '' ) {
		$h = '<' . ( $href ? 'a href="' . esc_url( $href ) . '"' : 'div' ) . ' class="mrsh-tile' . ( $tone ? ' is-' . esc_attr( $tone ) : '' ) . '"><span class="mrsh-tile-value">' . esc_html( (string) $value ) . '</span><span class="mrsh-tile-label">' . esc_html( $label ) . '</span></' . ( $href ? 'a' : 'div' ) . '>';
		return $h;
	}

	private static function notice( $msg, $type = 'success' ) {
		set_transient( 'mrsh_notice_' . get_current_user_id(), array( $msg, $type ), 60 );
	}

	private static function guard( $action ) {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( $action );
	}

	public static function back( $slug ) {
		wp_safe_redirect( self::url( $slug ) );
		exit;
	}

	public static function close() {
		echo '</div>';
	}

	public static function badge( $status, $text ) {
		return '<span class="mrsh-badge mrsh-' . esc_attr( $status ) . '">' . esc_html( $text ) . '</span>';
	}

	public static function stat( $label, $value, $note ) {
		return '<div class="mrsh-card mrsh-stat"><span class="mrsh-stat-label">' . esc_html( $label ) . '</span><span class="mrsh-stat-value">' . $value . '</span><span class="mrsh-stat-note">' . esc_html( $note ) . '</span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	public static function post_button( $action, $label, $primary = true ) {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="mrsh-inline">';
		echo '<input type="hidden" name="action" value="' . esc_attr( $action ) . '">';
		wp_nonce_field( $action );
		echo '<button type="submit" class="button ' . ( $primary ? 'button-primary' : '' ) . '">' . esc_html( $label ) . '</button></form>';
	}

	public static function field_text( $key, $label, $help = '', $placeholder = '' ) {
		$o = MRSH_Options::get();
		printf(
			'<tr><th scope="row"><label for="mrsh_%1$s">%2$s</label></th><td><input type="text" class="regular-text" id="mrsh_%1$s" name="%3$s[%1$s]" value="%4$s" placeholder="%5$s" autocomplete="off" data-lpignore="true"><p class="description">%6$s</p></td></tr>',
			esc_attr( $key ),
			esc_html( $label ),
			esc_attr( MRSH_Options::KEY ),
			esc_attr( $o[ $key ] ),
			esc_attr( $placeholder ),
			esc_html( $help )
		);
	}

	public static function field_area( $key, $label, $help = '' ) {
		$o = MRSH_Options::get();
		printf(
			'<tr><th scope="row"><label for="mrsh_%1$s">%2$s</label></th><td><textarea class="large-text" rows="3" id="mrsh_%1$s" name="%3$s[%1$s]">%4$s</textarea><p class="description">%5$s</p></td></tr>',
			esc_attr( $key ),
			esc_html( $label ),
			esc_attr( MRSH_Options::KEY ),
			esc_textarea( $o[ $key ] ),
			esc_html( $help )
		);
	}

	public static function field_check( $key, $label, $text ) {
		$o = MRSH_Options::get();
		printf(
			'<tr><th scope="row">%2$s</th><td><label><input type="checkbox" name="%3$s[%1$s]" value="1" %4$s> %5$s</label></td></tr>',
			esc_attr( $key ),
			esc_html( $label ),
			esc_attr( MRSH_Options::KEY ),
			checked( ! empty( $o[ $key ] ), true, false ),
			esc_html( $text )
		);
	}

	/* ---------------- Dashboard ---------------- */

	public static function page_backup() {
		MRSH_Backup::page();
	}

	public static function page_tools() {
		MRSH_Tools::page();
	}

	public static function page_dashboard() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		$o      = MRSH_Options::get();
		$stats  = MRSH_Keywords::stats();
		$checks = MRSH_Checks::last();
		$cov    = get_transient( MRSH_Keywords::CACHE );
		$types  = MRSH_Options::to_list( $o['noindex_post_types'] );
		$params = MRSH_Options::to_list( $o['noindex_params'] );
		$rm     = MRSH_Frontend::has_seo_plugin();
		$rmname = MRSH_Frontend::seo_plugin_name();

		self::open( 'MyRishta SEO', 'Control panel for myrishta.pk search visibility in Pakistan.' );

		// At a glance: the numbers that matter most, each linking to its screen.
		$ar    = MRSH_Audit::report();
		$ph    = get_option( 'mrsh_psi_history', array() );
		$pm    = null;
		$pd    = null;
		foreach ( is_array( $ph ) ? $ph : array() as $row ) {
			if ( null === $pm && isset( $row['strategy'] ) && 'mobile' === $row['strategy'] && isset( $row['perf'] ) ) {
				$pm = (int) $row['perf'];
			}
			if ( null === $pd && isset( $row['strategy'] ) && 'desktop' === $row['strategy'] && isset( $row['perf'] ) ) {
				$pd = (int) $row['perf'];
			}
		}
		$tone = function ( $v ) {
			return null === $v ? '' : ( $v >= 90 ? 'good' : ( $v >= 70 ? 'ok' : 'bad' ) );
		};
		$live = MRSH_Live::stats();
		echo '<div class="mrsh-tiles">';
		echo self::tile( $ar ? $ar['score'] : '–', 'SEO audit score', $ar ? $tone( $ar['score'] ) : '', self::url( 'mrsh-audit' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo self::tile( null === $pm ? '–' : $pm, 'Mobile speed', $tone( $pm ), self::url( 'mrsh-psi' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo self::tile( null === $pd ? '–' : $pd, 'Desktop speed', $tone( $pd ), self::url( 'mrsh-psi' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo self::tile( (int) $live['online'], 'Online now', 'live', self::url( 'mrsh-live' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo self::tile( (int) $live['today'], 'Visitors today', '', self::url( 'mrsh-live' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '</div>';
		echo '<div class="mrsh-actions"><a class="button button-primary" href="' . esc_url( self::url( 'mrsh-audit' ) ) . '">Run site audit</a> <a class="button" href="' . esc_url( self::url( 'mrsh-psi' ) ) . '">Test speed</a> <a class="button" href="' . esc_url( self::url( 'mrsh-easy' ) ) . '">Easy setup &amp; indexing push</a> <a class="button" href="' . esc_url( self::url( 'mrsh-live' ) ) . '">Live users</a></div>';

		echo '<div class="mrsh-grid mrsh-grid-4">';
		echo self::stat( 'SEO engine', self::badge( 'pass', $rm ? $rmname . ' active' : ( ! empty( $o['standalone'] ) ? 'MyRishta (standalone)' : 'Basic mode' ) ), $rm ? ( 'Rank Math' === $rmname ? 'Rank Math hooks are used for robots and canonical.' : 'Noindex is sent as a header and robots tag; canonical is cleaned. Set titles and descriptions in ' . $rmname . '.' ) : 'This plugin prints titles, canonical, Open Graph, schema and controls the sitemap (' . MRSH_Frontend::default_sitemap() . ').' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo self::stat( 'Noindex rules', (int) count( $types ) + (int) count( $params ), count( $types ) . ' post type(s), ' . count( $params ) . ' URL parameter(s)' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo self::stat( 'Keyword bank', (int) $stats['total'], $stats['target'] . ' targets, ' . $stats['high'] . ' high priority' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( is_array( $cov ) ) {
			$uncovered = count( $cov['uncovered'] );
			echo self::stat( 'Phrases used on site', (int) ( $stats['total'] - $uncovered ), $uncovered . ' not used on any page yet' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} else {
			echo self::stat( 'Phrases used on site', '–', 'Run a coverage scan to see' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</div>';

		// Live checks.
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Live site checks</h2>';
		self::post_button( 'mrsh_run_checks', $checks ? 'Run again' : 'Run checks' );
		echo '</div>';
		if ( $checks ) {
			echo '<p class="mrsh-muted">Last run ' . esc_html( human_time_diff( $checks['time'] ) ) . ' ago. These fetch your own public URLs, so they show what Google and Bing will see.</p>';
			echo '<table class="widefat striped mrsh-table"><tbody>';
			$names = array( 'pass' => 'Pass', 'warn' => 'Check', 'fail' => 'Fix', 'unknown' => 'Unknown' );
			foreach ( $checks['rows'] as $row ) {
				echo '<tr><td class="mrsh-w-label">' . esc_html( $row['label'] ) . '</td><td class="mrsh-w-badge">' . self::badge( $row['status'], $names[ $row['status'] ] ) . '</td><td>' . esc_html( $row['detail'] ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			echo '</tbody></table>';
		} else {
			echo '<p class="mrsh-muted">No checks run yet. The run takes a few seconds: it tests robots.txt, the sitemap, the homepage, a search URL, a parameter URL and one member profile.</p>';
		}
		echo '</div>';

		$missing = count( MRSH_Frontend::missing_alt_ids( 500 ) );
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Images and logo</h2></div>';
		$logo = MRSH_Frontend::site_logo();
		echo '<p>' . ( $logo ? 'Logo found and used in the schema and share tags: <a target="_blank" rel="noopener" href="' . esc_url( $logo ) . '">view</a>.' : 'No logo found. Set one in Appearance > Customize > Site Identity.' ) . '</p>';
		echo '<p>' . ( $missing ? (int) $missing . ' image(s) in the media library have no alt text. Alt text helps image search.' : 'All media library images have alt text.' ) . '</p>';
		if ( $missing ) {
			self::post_button( 'mrsh_fill_alt', 'Fill missing alt text from titles', false );
		}
		if ( class_exists( 'MRSH_AutoAlt' ) ) {
			MRSH_AutoAlt::panel();
		}
		echo '</div>';

		// Setup checklist.
		$first  = $types ? $types[0] : '';
		$items  = array(
			array( $rm || ! empty( $o['standalone'] ), 'SEO engine active', 'MyRishta SEO is running as the SEO engine. You do not need Rank Math. Turn on "Complete SEO engine" under Rules if this stays red.', 'myrishta-seo-rules' ),
			array( '' !== $first && post_type_exists( $first ), 'Member profile post type found', 'Confirm the slug under Rules; the Status table lists the real ones.', 'myrishta-seo-rules' ),
			array( '' !== $o['google_verification'], 'Google verification code saved', 'Add it under Search Engines, or verify another way (DNS).', 'myrishta-seo-engines' ),
			array( '' !== $o['bing_verification'] || ! empty( $o['bing_verified_other'] ), 'Bing verification code saved', 'Or import the site from Google Search Console in Bing Webmaster Tools.', 'myrishta-seo-engines' ),
			array( ! empty( $o['indexnow_enabled'] ) && MRSH_IndexNow::valid_key( $o['indexnow_key'] ), 'Automatic IndexNow submission on', 'Tells Bing, Yandex, Naver, Seznam.cz and Yep when you publish or update a page.', 'myrishta-seo-engines' ),
			array( '' !== $o['sitemap_url'], 'Sitemap URL set', 'Needed for the robots.txt Sitemap line.', 'myrishta-seo-rules' ),
			array( '' !== $o['org_logo'], 'Organization name and logo set', 'Used for the optional homepage schema.', 'myrishta-seo-rules' ),
			array( null !== $checks, 'Live checks run', 'Run them after every settings change.', 'myrishta-seo' ),
			array( is_array( $cov ), 'Keyword coverage scanned', 'Shows which phrases no page uses yet.', 'myrishta-seo-coverage' ),
		);
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Setup checklist</h2></div><ul class="mrsh-checklist">';
		foreach ( $items as $it ) {
			echo '<li class="' . ( $it[0] ? 'is-done' : '' ) . '"><span class="mrsh-tick">' . ( $it[0] ? '&#10003;' : '' ) . '</span><div><strong>' . esc_html( $it[1] ) . '</strong><br><span class="mrsh-muted">' . esc_html( $it[2] ) . '</span></div>';
			if ( ! $it[0] && 'myrishta-seo' !== $it[3] ) {
				echo '<a class="button" href="' . esc_url( self::url( $it[3] ) ) . '">Open</a>';
			}
			echo '</li>';
		}
		echo '</ul></div>';

		// Useful tools.
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Search engine tools</h2></div><p>';
		$links = array(
			'Google Search Console' => 'https://search.google.com/search-console',
			'Bing Webmaster Tools'  => 'https://www.bing.com/webmasters',
			'PageSpeed Insights'    => 'https://pagespeed.web.dev/',
			'Rich Results Test'     => 'https://search.google.com/test/rich-results',
		);
		foreach ( $links as $name => $href ) {
			echo '<a class="button" target="_blank" rel="noopener noreferrer" href="' . esc_url( $href ) . '">' . esc_html( $name ) . '</a> ';
		}
		echo '</p></div>';

		self::close();
	}

	/* ---------------- Rules ---------------- */

	public static function page_rules() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		$o = MRSH_Options::get();
		self::open( 'Rules', 'What search engines may index, how URLs are cleaned, and what robots.txt says.' );
		echo '<form method="post" action="options.php">';
		settings_fields( 'mrsh_group' );
		echo '<input type="hidden" name="' . esc_attr( MRSH_Options::KEY ) . '[_section]" value="rules">';

		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Noindex</h2></div><table class="form-table" role="presentation">';
		self::field_text( 'noindex_post_types', 'Post types', 'Comma-separated slugs. Member profiles on myrishta.pk use "listing_type"; check the Status table below.', 'listing_type' );
		self::field_text( 'noindex_taxonomies', 'Taxonomies', 'Optional. Add a taxonomy only when its pages are too thin to index.' );
		self::field_text( 'noindex_params', 'URL parameters', 'Any URL containing one of these keys gets noindex, and the keys are removed from the canonical URL.', 's,sort,reset' );
		self::field_check( 'noindex_search', 'Search results', 'Noindex WordPress search results pages' );
		self::field_check( 'strip_canonical', 'Canonical URLs', 'Remove the parameters above from canonical URLs (Rank Math)' );
		echo '</table></div>';

		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>robots.txt</h2></div><table class="form-table" role="presentation">';
		self::field_check( 'robots_txt', 'Edit robots.txt', 'Add the lines below (no effect if a real robots.txt file exists on the server)' );
		self::field_area( 'robots_disallow', 'Disallow paths', 'One path per line, starting with /. Do not add search or sort URLs until Search Console shows them dropped from the index.' );
		self::field_text( 'sitemap_url', 'Sitemap URL', 'Added only if robots.txt has no Sitemap line yet. Leave empty to use the default for your setup.', MRSH_Frontend::default_sitemap() );
		echo '</table></div>';

		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Organization schema</h2></div><table class="form-table" role="presentation">';
		self::field_check( 'org_schema', 'Homepage output', 'Turn on only if Rank Math is not already printing Organization schema' );
		self::field_text( 'org_name', 'Name', '', 'MyRishta.pk' );
		self::field_text( 'org_logo', 'Logo URL', 'Leave empty to use your WordPress logo.', '' );
		self::field_area( 'org_same_as', 'Social profile URLs', 'One real profile URL per line. Leave out accounts you do not have.' );
		self::field_text( 'org_email', 'Support email', 'Optional. Added to the schema as customer support contact for Pakistan.' );
		self::field_text( 'org_phone', 'Support phone', 'Optional, for example +92 300 0000000.' );
		self::field_text( 'org_street', 'Office street or area', 'Change the office here once. The schema, footer, contact page and the shortcodes use it.', 'Shahdara' );
		self::field_text( 'org_city', 'City', '', 'Lahore' );
		self::field_text( 'org_region', 'Province', '', 'Punjab' );
		self::field_text( 'org_postal', 'Postal code', '', '54000' );
		echo '</table></div><div class="mrsh-card"><div class="mrsh-card-head"><h2>Complete SEO engine</h2></div><p class="mrsh-muted">Active only when no other SEO plugin (All in One SEO, Rank Math, Yoast) is running, so nothing is printed twice.</p><table class="form-table" role="presentation">';
		self::field_check( 'standalone', 'Standalone mode', 'Use this plugin for titles, canonical, Open Graph and schema' );
		self::field_check( 'canonical_tags', 'Canonical tags', 'One clean canonical URL on every page' );
		self::field_check( 'og_tags', 'Social tags', 'Open Graph and Twitter tags for WhatsApp, Facebook and X' );
		self::field_check( 'article_schema', 'Article schema', 'Article data for blog posts' );
		self::field_check( 'sitemap_redirect', 'Old sitemap addresses', 'Redirect /sitemap.xml and /sitemap_index.xml to /wp-sitemap.xml' );
		self::field_area( 'noindex_slugs', 'Hidden pages', 'Page slugs kept out of Google and the sitemap, comma separated: login, cart, account and similar utility pages.' );
		echo '</table></div><div class="mrsh-card"><div class="mrsh-card-head"><h2>Advanced SEO</h2></div><table class="form-table" role="presentation">';
		self::field_check( 'noindex_author', 'Author archives', 'Noindex author pages (thin, duplicate content)' );
		self::field_check( 'noindex_date', 'Date archives', 'Noindex date archives' );
		self::field_check( 'noindex_attachment', 'Attachment pages', 'Noindex media attachment pages' );
		self::field_check( 'noindex_paged', 'Page 2, 3 and beyond', 'Noindex paginated archives (leave off unless listings are duplicated)' );
		self::field_check( 'website_schema', 'WebSite schema', 'Name, language en-PK and a site search box for search engines' );
		self::field_check( 'breadcrumb_schema', 'Breadcrumb schema', 'Only used when Rank Math is not active (Rank Math has its own)' );
		echo '</table></div><div class="mrsh-card"><div class="mrsh-card-head"><h2>Duplicate and clutter clean-up</h2></div><p class="mrsh-muted">Works on the final page, so it also catches duplicates made by your theme, Elementor or two SEO plugins. Only the page head is changed, never your content.</p><table class="form-table" role="presentation">';
		self::field_check( 'dedupe_head', 'Remove duplicate tags', 'Keep one copy of repeated meta tags, canonical, hreflang, Open Graph, Twitter and schema blocks' );
		self::field_check( 'clean_words', 'Remove duplicate words', 'Fix repeated words ("Rishta Rishta"), repeated title parts and doubled punctuation in titles and descriptions' );
		self::field_check( 'trim_description', 'Shorten long descriptions', 'Cut meta descriptions over 160 characters at a word boundary' );
		self::field_check( 'clean_generator', 'Hide WordPress version', 'Remove the generator tag' );
		self::field_check( 'clean_shortlink', 'Remove shortlink', 'Remove the ?p=123 shortlink tag, a source of duplicate URLs' );
		self::field_check( 'clean_rsd', 'Remove old editor links', 'Remove RSD and Windows Live Writer links' );
		self::field_check( 'clean_rest_links', 'Remove REST API link', 'Remove the wp-json discovery link from the head' );
		echo '</table></div><div class="mrsh-card"><div class="mrsh-card-head"><h2>Speed</h2></div><table class="form-table" role="presentation">';
		self::field_check( 'speed_emojis', 'Speed: emoji script', 'Remove the WordPress emoji script and styles' );
		self::field_check( 'speed_embeds', 'Speed: embed links', 'Remove oEmbed discovery links' );
		self::field_check( 'speed_preconnect', 'Speed: font preconnect', 'Preconnect to fonts.gstatic.com (only if your theme uses Google Fonts)' );
		self::field_check( 'speed_fonts', 'Speed: font swap', 'Show text at once while fonts load (font-display swap)' );
		self::field_check( 'speed_images', 'Speed: smart images', 'Lazy-load images below the fold and give the top image high priority' );
		self::field_check( 'fix_access', 'Accessibility: name icon links, fix empty headings', 'Adds a name to icon-only links (social, phone, email) and turns empty headings into plain blocks' );
		self::field_check( 'speed_dimensions', 'Speed: image sizes', 'Add missing width and height to your own images so the page does not jump while loading' );
		self::field_text( 'speed_eager_images', 'Top images loaded at once', 'How many images at the top of each page are not lazy-loaded (0 to 6). Default 2.' );
		self::field_text( 'speed_preload_img', 'Preload homepage hero image', 'Optional image URL of the main picture at the top of the homepage. Improves Largest Contentful Paint.' );
		self::field_check( 'org_footer', 'Organization details in the footer', 'Shows the organization name, address, phone, email, legal links and a non-profit statement at the bottom of every page' );
		self::field_check( 'pk_theme', 'Pakistani look: welcome strip, ornaments and skyline banner', 'Green strip with an Urdu greeting, gold ornament under headings and an original skyline banner on the home, About, How it works and FAQ pages' );
		self::field_check( 'speed_unhide', 'Speed: show the page at once (no loading spinner)', 'Theme hides the whole page until its scripts finish; this shows it immediately and loads the theme styles in the head' );
		self::field_check( 'speed_delay_ads', 'Speed: load the AdSense library after the first touch', 'Raises the speed score a lot, but turn it on only after Google has approved the site (during review Google needs to see the ads load)' );
		self::field_check( 'speed_hide_adminbar', 'Speed: hide the top admin bar on the website', 'While you are logged in, the bar loads about 2 MB of Site Kit scripts on every page, which makes the site feel slow on your phone. Visitors never see it. You can still reach the dashboard at /wp-admin/.' );
		self::field_check( 'speed_webp', 'Speed: use WebP copies of images', 'Uses the smaller WebP file next to each image when it exists (create them under Speed Tools, image compressor)' );
		self::field_check( 'speed_delay_ga', 'Speed: load Google Analytics after the first touch', 'Keeps the first paint fast; the AdSense tag is not changed' );
		self::field_check( 'speed_hero', 'Speed: load the first big picture first', 'Gives the top picture a real source and preloads it' );
		self::field_check( 'speed_dashicons', 'Speed: drop Dashicons for visitors', 'Admin icon font is not needed by visitors' );
		self::field_check( 'speed_heartbeat', 'Speed: slow background pings', 'WordPress heartbeat every 60 seconds' );
		self::field_check( 'speed_blocks', 'Speed: remove block editor CSS', 'Only if your pages are built with Elementor or the theme, not the block editor. Check the site after turning on.' );
		self::field_check( 'speed_defer', 'Speed: defer scripts', 'Load scripts after the page is drawn. Visitors only. jQuery and Elementor core are never deferred. Test the site after turning on.' );
		self::field_text( 'speed_defer_exclude', 'Never defer these', 'Script handles or file-name parts, comma separated, if something breaks.' );
		echo '</table></div><div class="mrsh-card"><div class="mrsh-card-head"><h2>Automatic tags, sharing and discovery</h2></div><table class="form-table" role="presentation">';
		self::field_check( 'auto_meta', 'Automatic tags', 'Fill empty page titles, meta descriptions and image alt text automatically (anything you set by hand in Rank Math is kept)' );
		self::field_text( 'meta_title_home', 'Homepage title', 'Keep under about 60 characters. Variables: %sitename% %tagline%.' );
		self::field_area( 'meta_desc_home', 'Homepage description', 'Around 150 characters. Write what the site really offers.' );
		self::field_text( 'meta_title_page', 'Other pages title', 'Variables: %title% %sitename%. Descriptions for other pages come from the excerpt or the first words of the content.' );
		self::field_text( 'social_image', 'Share image URL', 'Shown when a page is shared on WhatsApp, Facebook or in Google Discover. Empty uses your logo. A 1200x630 image is best. With Rank Math, also set Titles & Meta > Global Meta > Open Graph thumbnail.' );
		self::field_check( 'auto_discover', 'Automatic phrase discovery', 'Scan my pages, posts and listings every week and add new Pakistan phrases to the keyword bank' );
		self::field_check( 'pk_hreflang', 'Pakistan language tag', 'Add hreflang en-PK to indexable pages' );
		echo '</table><p class="mrsh-muted">If Logo URL is empty, the logo set in Appearance > Customize (or the Site Icon) is used automatically. The schema also states that you serve Pakistan.</p></div>';

		submit_button( 'Save rules' );
		echo '</form>';

		// Status.
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Status</h2></div><table class="widefat striped mrsh-table"><tbody>';
		foreach ( MRSH_Options::to_list( $o['noindex_post_types'] ) as $pt ) {
			echo '<tr><td>Post type "' . esc_html( $pt ) . '"</td><td>';
			if ( post_type_exists( $pt ) ) {
				$c = wp_count_posts( $pt );
				echo self::badge( 'pass', 'Found' ) . ' ' . (int) ( isset( $c->publish ) ? $c->publish : 0 ) . ' published, all noindexed'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			} else {
				echo self::badge( 'fail', 'Not found' ) . ' Check the slug against the list below.'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			echo '</td></tr>';
		}
		echo '<tr><td>Public post types</td><td>' . esc_html( implode( ', ', array_keys( get_post_types( array( 'public' => true ) ) ) ) ) . '</td></tr>';
		echo '<tr><td>Public taxonomies</td><td>' . esc_html( implode( ', ', array_keys( get_taxonomies( array( 'public' => true ) ) ) ) ) . '</td></tr>';
		echo '<tr><td>robots.txt</td><td><a target="_blank" rel="noopener" href="' . esc_url( home_url( '/robots.txt' ) ) . '">Open robots.txt</a></td></tr>';
		echo '</tbody></table></div>';
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Move from All in One SEO</h2></div><p class="mrsh-muted">Before you remove All in One SEO, copy its custom page titles, descriptions, focus phrases and hidden-page flags into this plugin. Settings it already had on your pages are kept; template titles are skipped.</p>';
		self::post_button( 'mrsh_import_aioseo', 'Import from All in One SEO', false );
		echo '</div>';
		self::close();
	}

	/* ---------------- Search engines ---------------- */

	public static function page_engines() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		$o       = MRSH_Options::get();
		$sitemap = '' !== $o['sitemap_url'] ? $o['sitemap_url'] : MRSH_Frontend::default_sitemap();
		$ready   = ! empty( $o['indexnow_enabled'] ) && MRSH_IndexNow::valid_key( $o['indexnow_key'] );
		self::open( 'Search Engines', 'Verify the site with each search engine and submit pages automatically.' );

		// Verification codes.
		echo '<form method="post" action="options.php">';
		settings_fields( 'mrsh_group' );
		echo '<input type="hidden" name="' . esc_attr( MRSH_Options::KEY ) . '[_section]" value="engines">';
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Verification codes</h2></div>';
		echo '<p class="mrsh-muted">Enter each code in one place only: here or in your SEO plugin (All in One SEO: General Settings > Webmaster Tools), never both. Paste only the code (the value after content=), not the whole tag. Tags print on the homepage. If Rank Math already prints the same code, leave it out here.</p><table class="form-table" role="presentation">';
		self::field_text( 'google_verification', 'Google', 'Search Console: URL prefix property, HTML tag method.', 'abc123...' );
		self::field_text( 'bing_verification', 'Bing', 'Bing Webmaster Tools: HTML meta tag method. Also used by Yahoo and DuckDuckGo results through Bing.', 'ABC123...' );
		self::field_text( 'yandex_verification', 'Yandex', 'Yandex Webmaster: meta tag method.' );
		self::field_text( 'baidu_verification', 'Baidu', 'Baidu Webmaster: HTML tag method.' );
		self::field_text( 'naver_verification', 'Naver', 'Naver Search Advisor: HTML tag method.' );
		self::field_text( 'seznam_verification', 'Seznam.cz', 'Seznam Webmaster: meta tag method.' );
		self::field_text( 'pinterest_verification', 'Pinterest', 'Social, not a search engine: claim the website in Pinterest.' );
		self::field_text( 'facebook_verification', 'Facebook', 'Social: domain verification in Meta Business settings.' );
		self::field_text( 'ahrefs_verification', 'Ahrefs', 'Optional: Ahrefs Webmaster Tools, free site audit.' );
		self::field_area( 'verify_custom', 'Other meta tags', 'For any engine not listed. One per line as name=code, for example norton-safeweb-site-verification=ABC123' );
		self::field_area( 'verify_files', 'Verification files', 'For the file method. One per line as filename|content. Google: google1234abcd.html|google-site-verification: google1234abcd.html . Bing: BingSiteAuth.xml|<users><user>YOURCODE</user></users> . Yandex: yandex_1234abcd.html|the text Yandex shows. The plugin serves the file at the site root, no upload needed.' );
		echo '</table>';
		submit_button( 'Save codes' );
		echo '</div></form>';

		$vr = get_transient( 'mrsh_verify' );
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Test my verification</h2></div><p class="mrsh-muted">Reads your live homepage and compares it with the saved codes. It also catches the same code reused, and tags added by another plugin or the theme.</p>';
		self::post_button( 'mrsh_verify_test', 'Test now', false );
		if ( is_array( $vr ) ) {
			echo '<table class="widefat striped mrsh-table"><tbody>';
			foreach ( $vr as $row ) {
				echo '<tr><td><strong>' . esc_html( $row['label'] ) . '</strong></td><td>' . self::badge( 'pass' === $row['status'] ? 'pass' : ( 'fail' === $row['status'] ? 'fail' : ( 'warn' === $row['status'] ? 'warn' : 'unknown' ) ), strtoupper( $row['status'] ) ) . '</td><td>' . esc_html( $row['detail'] ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			echo '</tbody></table>';
		}
		echo '</div>';
		$host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Other ways to verify</h2></div><ol class="mrsh-steps">';
		echo '<li><strong>DNS TXT record (best for Google):</strong> choose the Domain property in Search Console, copy the TXT value it gives, then add a TXT record for <code>' . esc_html( $host ) . '</code> at your domain registrar or in Cloudflare DNS. It covers http, https and all subdomains and never breaks when themes change.</li>';
		echo '<li><strong>HTML file:</strong> use the Verification files box above, with the exact file name and content the engine shows.</li>';
		echo '<li><strong>Import from Google:</strong> Bing Webmaster Tools can import the verified site from Search Console, with no code at all.</li>';
		echo '<li><strong>SEO plugin:</strong> All in One SEO has its own Webmaster Tools page under General Settings. Use either that or this page for a code, not both.</li></ol></div>';

		// IndexNow.
		echo '<form method="post" action="options.php">';
		settings_fields( 'mrsh_group' );
		echo '<input type="hidden" name="' . esc_attr( MRSH_Options::KEY ) . '[_section]" value="indexnow">';
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Automatic indexing (IndexNow)</h2>' . self::badge( $ready ? 'pass' : 'unknown', $ready ? 'On' : 'Off' ) . '</div>';
		echo '<p>When you publish or update a page, the plugin tells Bing, Yandex, Naver, Seznam.cz, Yep and Amazon straight away, instead of waiting for them to find it. Google and Baidu are not listed by indexnow.org, so they still rely on the sitemap (and URL Inspection for Google).</p><table class="form-table" role="presentation">';
		self::field_check( 'indexnow_enabled', 'Automatic submission', 'Submit new and updated public pages (member profiles and noindex pages are never sent)' );
		echo '</table>';
		if ( MRSH_IndexNow::valid_key( $o['indexnow_key'] ) ) {
			echo '<p>Key file: <a target="_blank" rel="noopener" href="' . esc_url( MRSH_IndexNow::key_url() ) . '">' . esc_html( MRSH_IndexNow::key_url() ) . '</a> <span class="mrsh-muted">(open it; it should show only the key)</span></p>';
		}
		submit_button( 'Save IndexNow settings' );
		echo '</div></form>';

		if ( $ready ) {
			echo '<div class="mrsh-grid mrsh-grid-2"><div class="mrsh-card"><div class="mrsh-card-head"><h2>Submit URLs now</h2></div>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_indexnow_submit">';
			wp_nonce_field( 'mrsh_indexnow_submit' );
			echo '<p><textarea name="urls" class="large-text" rows="5" placeholder="' . esc_attr( home_url( '/rishta/lahore/' ) ) . '"></textarea></p><p class="mrsh-muted">One URL per line, from this site only. Do not resubmit unchanged pages.</p>';
			echo '<button type="submit" class="button button-primary">Submit</button></form></div>';
			echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Submit all published pages</h2></div><p class="mrsh-muted">Sends the homepage and up to 500 published, indexable pages. Use once after launch or a big update, not daily.</p>';
			self::post_button( 'mrsh_indexnow_all', 'Submit all pages' );
			echo '</div></div>';

			$log = MRSH_IndexNow::log_rows();
			echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Recent submissions</h2></div>';
			if ( $log ) {
				echo '<table class="widefat striped mrsh-table"><thead><tr><th>When</th><th>Source</th><th>URLs</th><th>Result</th><th>Example</th></tr></thead><tbody>';
				foreach ( $log as $row ) {
					echo '<tr><td>' . esc_html( human_time_diff( $row['time'] ) ) . ' ago</td><td>' . esc_html( $row['source'] ) . '</td><td>' . (int) $row['count'] . '</td><td>' . self::badge( $row['ok'] ? 'pass' : 'fail', $row['ok'] ? 'HTTP ' . (int) $row['code'] : 'Failed ' . (int) $row['code'] ) . '</td><td>' . esc_html( $row['sample'] ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				}
				echo '</tbody></table>';
			} else {
				echo '<p class="mrsh-muted">Nothing submitted yet.</p>';
			}
			echo '</div>';
		}

		$blocked = ! (int) get_option( 'blog_public' );
		$have    = array( 'google_verification', 'bing_verification' );
		$reqs    = array(
			array( ! $blocked, 'Search engines are allowed to index the site', 'Settings > Reading must not have "Discourage search engines" ticked.' ),
			array( is_ssl() || 0 === strpos( home_url(), 'https://' ), 'Site runs on HTTPS', 'Google and Bing expect a secure site.' ),
			array( true, 'Sitemap address known', 'Your sitemap is ' . MRSH_Frontend::default_sitemap() . ' (leave the box empty to use it).' ),
			array( '' !== $o['google_verification'], 'Google verification code added', 'Or verify the whole domain with a DNS TXT record instead.' ),
			array( '' !== $o['bing_verification'] || ! empty( $o['bing_verified_other'] ), 'Bing verification code added', 'Or import the site from Search Console in Bing Webmaster Tools.' ),
			array( $ready, 'IndexNow is on', 'Covers Bing, Yandex, Naver, Seznam.cz and Yep.' ),
			array( '' !== MRSH_Frontend::social_image(), 'A logo or share image is available', 'Used for social sharing and the Organization schema.' ),
			array( ! empty( $o['org_schema'] ), 'Organization schema on', 'Helps Google show the correct name and logo.' ),
		);
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Submission requirements</h2></div><ul class="mrsh-checklist">';
		foreach ( $reqs as $r ) {
			echo '<li>' . self::badge( $r[0] ? 'pass' : 'warn', $r[0] ? 'Done' : 'To do' ) . ' <strong>' . esc_html( $r[1] ) . '</strong> <span class="mrsh-muted">' . esc_html( $r[2] ) . '</span></li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</ul></div>';

		echo '<div class="mrsh-grid mrsh-grid-2">';
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Google</h2></div><ol class="mrsh-steps">';
		echo '<li>Open Search Console and add myrishta.pk. Choose <strong>Domain</strong> and verify with the DNS TXT record at your registrar (most reliable), or choose <strong>URL prefix</strong> and use the HTML tag, then paste the code above.</li>';
		echo '<li>Click Verify, then open Sitemaps and submit: <code>' . esc_html( $sitemap ) . '</code></li>';
		echo '<li>Use URL Inspection, then Request indexing, for the homepage and each new landing page. Google offers no public automatic submission for ordinary pages, so the sitemap and this step are the supported routes.</li></ol></div>';
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Bing, Yandex and others</h2></div><ol class="mrsh-steps">';
		echo '<li>Bing: import the site from Google Search Console in Bing Webmaster Tools, or paste the meta tag code above.</li>';
		echo '<li>Yandex, Naver, Seznam and Baidu: add the site in their webmaster tools, choose the meta tag method and paste the code above.</li>';
		echo '<li>Submit the same sitemap in each one, and turn on IndexNow above.</li></ol></div></div>';

		echo '<div class="mrsh-card"><p class="mrsh-muted">Rankings are decided by the search engines; nothing can force a position. Verification, a sitemap and IndexNow let them find your pages quickly, and original Pakistani content decides whether they rank. After saving, run the live checks on the Dashboard.</p><p>';
		foreach ( array( 'Google Search Console' => 'https://search.google.com/search-console', 'Bing Webmaster Tools' => 'https://www.bing.com/webmasters', 'Yandex Webmaster' => 'https://webmaster.yandex.com/', 'Naver Search Advisor' => 'https://searchadvisor.naver.com/', 'Seznam Webmaster' => 'https://search.seznam.cz/' ) as $name => $href ) {
			echo '<a class="button" target="_blank" rel="noopener noreferrer" href="' . esc_url( $href ) . '">' . esc_html( $name ) . '</a> ';
		}
		echo '</p></div>';
		self::close();
	}

	/* ---------------- Discover ---------------- */

	private static function phrase_form( $rows, $heads, $cells, $empty ) {
		if ( ! $rows ) {
			echo '<p class="mrsh-muted">' . esc_html( $empty ) . '</p>';
			return;
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_add_phrases">';
		wp_nonce_field( 'mrsh_add_phrases' );
		echo '<table class="widefat striped mrsh-table"><thead><tr><th><input type="checkbox" class="mrsh-all" aria-label="Select all"></th><th>Phrase</th>';
		foreach ( $heads as $h ) {
			echo '<th>' . esc_html( $h ) . '</th>';
		}
		echo '</tr></thead><tbody>';
		foreach ( $rows as $r ) {
			echo '<tr><td><input type="checkbox" name="terms[]" value="' . esc_attr( $r['term'] ) . '"></td><td>' . esc_html( $r['term'] ) . '</td>' . call_user_func( $cells, $r ) . '</tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</tbody></table><p><button type="submit" class="button button-primary">Add selected to keyword bank</button></p></form>';
	}

	private static function bank_set() {
		$have = array();
		foreach ( MRSH_Keywords::all() as $r ) {
			foreach ( MRSH_Keywords::variants( $r ) as $v ) {
				$have[ $v ] = true;
			}
		}
		return $have;
	}

	public static function page_discover() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		$have = self::bank_set();
		self::open( 'Discover', 'Find new Pakistan search phrases from real data, then add the ones you choose to the keyword bank.' );
		echo '<div class="mrsh-card"><p>Nothing here is added automatically, and nothing is fetched from Google. Phrases come from three places you own: what visitors search for on your site, your Search Console export, and your own content. Adding a phrase to the bank does not change how Google shows the site by itself; it feeds the Coverage report and your page plan, and the phrase only helps once a page genuinely covers it.</p></div>';

		$last = get_option( 'mrsh_last_scan' );
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Automatic scan of your site</h2></div><p>' . ( ! empty( MRSH_Options::get()['auto_discover'] ) ? 'Every week the plugin reads your published pages, posts and listings and adds up to 20 new phrases to the bank.' : 'Weekly scan is off (turn it on under Rules).' );
		if ( is_array( $last ) ) {
			echo ' Last run: ' . esc_html( human_time_diff( $last['time'] ) ) . ' ago, ' . (int) $last['added'] . ' added.';
		}
		echo '</p>';
		self::post_button( 'mrsh_scan_now', 'Scan now', false );
		echo '</div>';

		// A: visitor searches.
		$rows = array();
		foreach ( MRSH_Discovery::search_rows() as $r ) {
			if ( empty( $have[ $r['term'] ] ) ) {
				$rows[] = $r;
			}
		}
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Visitor searches on your site</h2>';
		if ( MRSH_Discovery::search_rows() ) {
			self::post_button( 'mrsh_clear_searches', 'Clear log', false );
		}
		echo '</div><p class="mrsh-muted">Logged automatically from the site search box: the words only, no IP address or user, and your own admin searches are skipped. Mention it in your privacy policy.</p>';
		self::phrase_form(
			array_slice( $rows, 0, 100 ),
			array( 'Searches', 'Last seen' ),
			function ( $r ) {
				return '<td>' . (int) $r['count'] . '</td><td>' . esc_html( human_time_diff( $r['last'] ) ) . ' ago</td>';
			},
			'No new searches logged yet. Visitors need to use the search box on the site.'
		);
		echo '</div>';

		// B: Search Console CSV.
		$csv = get_transient( 'mrsh_csv_' . get_current_user_id() );
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Search Console export</h2></div><p class="mrsh-muted">In Search Console open Performance, set the country to Pakistan, choose the Queries tab and export as CSV. Upload the Queries file here. It is read once and not stored.</p>';
		echo '<form method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_csv_preview">';
		wp_nonce_field( 'mrsh_csv_preview' );
		echo '<input type="file" name="csv" accept=".csv,.tsv,.txt"> <button type="submit" class="button">Read file</button></form>';
		if ( is_array( $csv ) ) {
			$list = array();
			foreach ( $csv as $r ) {
				if ( empty( $have[ mb_strtolower( $r['term'] ) ] ) ) {
					$list[] = $r;
				}
			}
			echo '<p>' . (int) count( $csv ) . ' queries read, ' . (int) count( $list ) . ' not in your bank yet.</p>';
			self::phrase_form(
				array_slice( $list, 0, 150 ),
				array( 'Clicks', 'Impressions', 'Avg. position' ),
				function ( $r ) {
					$f = function ( $v, $d = 0 ) {
						return null === $v ? '–' : esc_html( number_format_i18n( $v, $d ) );
					};
					return '<td>' . $f( $r['clicks'] ) . '</td><td>' . $f( $r['impressions'] ) . '</td><td>' . $f( $r['position'], 1 ) . '</td>';
				},
				'Every query in the file is already in the bank.'
			);
		}
		echo '</div>';

		// C: own content.
		$cands = array();
		foreach ( MRSH_Discovery::content_candidates( MRSH_Discovery::site_posts() ) as $c ) {
			$cands[] = $c;
		}
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Phrases in your own content</h2></div><p class="mrsh-muted">Two and three word phrases around rishta, shadi, nikah and similar words that appear on at least two published pages and are not in the bank.</p>';
		self::phrase_form(
			$cands,
			array( 'Pages' ),
			function ( $r ) {
				return '<td>' . (int) $r['pages'] . '</td>';
			},
			'Nothing found yet. This fills in as you publish more pages.'
		);
		echo '</div>';

		// D: discovered phrases already in the bank.
		$mine = MRSH_Discovery::custom_rows();
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Phrases you added</h2></div>';
		if ( $mine ) {
			echo '<table class="widefat striped mrsh-table"><tbody>';
			foreach ( $mine as $r ) {
				echo '<tr><td>' . esc_html( MRSH_Keywords::label( $r ) ) . '</td><td>';
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="mrsh-inline"><input type="hidden" name="action" value="mrsh_remove_phrase"><input type="hidden" name="n" value="' . (int) $r['n'] . '">';
				wp_nonce_field( 'mrsh_remove_phrase' );
				echo '<button class="button-link" type="submit">Remove</button></form></td></tr>';
			}
			echo '</tbody></table>';
		} else {
			echo '<p class="mrsh-muted">None yet.</p>';
		}
		echo '</div>';
		self::close();
	}

	/* ---------------- Discover and IndexNow handlers ---------------- */

	public static function handle_indexnow_submit() {
		self::guard( 'mrsh_indexnow_submit' );
		$raw = isset( $_POST['urls'] ) ? sanitize_textarea_field( wp_unslash( $_POST['urls'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$r   = MRSH_IndexNow::submit( preg_split( '/\R/', $raw ), 'manual' );
		self::notice( ( $r['ok'] ? 'Submitted ' . $r['count'] . ' URL(s). ' : 'Not submitted. ' ) . $r['message'], $r['ok'] ? 'success' : 'error' );
		self::back( 'myrishta-seo-engines' );
	}

	public static function handle_indexnow_all() {
		self::guard( 'mrsh_indexnow_all' );
		$r = MRSH_IndexNow::submit( MRSH_IndexNow::all_urls(), 'all pages' );
		self::notice( ( $r['ok'] ? 'Submitted ' . $r['count'] . ' URL(s). ' : 'Not submitted. ' ) . $r['message'], $r['ok'] ? 'success' : 'error' );
		self::back( 'myrishta-seo-engines' );
	}

	public static function handle_create_drafts() {
		self::guard( 'mrsh_create_drafts' );
		$n    = isset( $_POST['n'] ) ? array_map( 'intval', (array) wp_unslash( $_POST['n'] ) ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$made = MRSH_Keywords::create_drafts( $n );
		self::notice( $made ? 'Created ' . $made . ' draft page(s). They are unpublished outlines: write original content before publishing.' : 'No drafts created. Pages with the same title may already exist.', $made ? 'success' : 'warning' );
		self::back( 'myrishta-seo-coverage' );
	}

	public static function handle_csv_preview() {
		self::guard( 'mrsh_csv_preview' );
		$file = isset( $_FILES['csv'] ) ? $_FILES['csv'] : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$name = isset( $file['name'] ) ? sanitize_file_name( (string) $file['name'] ) : '';
		if ( empty( $file['tmp_name'] ) || ! is_uploaded_file( $file['tmp_name'] ) || ! preg_match( '/\.(csv|tsv|txt)$/i', $name ) || (int) $file['size'] > 2 * MB_IN_BYTES ) {
			self::notice( 'Choose a .csv file under 2 MB.', 'error' );
			self::back( 'myrishta-seo-discover' );
		}
		$rows = MRSH_Discovery::parse_csv( file_get_contents( $file['tmp_name'] ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		set_transient( 'mrsh_csv_' . get_current_user_id(), $rows, HOUR_IN_SECONDS );
		self::notice( $rows ? 'Read ' . count( $rows ) . ' queries.' : 'No queries found. Use the Queries export from Search Console.', $rows ? 'success' : 'warning' );
		self::back( 'myrishta-seo-discover' );
	}

	public static function handle_add_phrases() {
		self::guard( 'mrsh_add_phrases' );
		$terms = isset( $_POST['terms'] ) ? array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['terms'] ) ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$added = MRSH_Discovery::add( $terms );
		self::notice( $added ? 'Added ' . $added . ' phrase(s) to the keyword bank.' : 'Nothing added. Select at least one new phrase.', $added ? 'success' : 'warning' );
		self::back( 'myrishta-seo-discover' );
	}

	public static function handle_remove_phrase() {
		self::guard( 'mrsh_remove_phrase' );
		MRSH_Discovery::remove( isset( $_POST['n'] ) ? (int) $_POST['n'] : 0 ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		self::notice( 'Phrase removed.' );
		self::back( 'myrishta-seo-discover' );
	}

	public static function handle_import_aioseo() {
		self::guard( 'mrsh_import_aioseo' );
		$n = MRSH_Standalone::import_aioseo();
		if ( -1 === $n ) {
			self::notice( 'All in One SEO data was not found on this site.', 'warning' );
		} else {
			self::notice( 'Imported SEO fields for ' . (int) $n . ' page(s).', $n ? 'success' : 'warning' );
		}
		self::back( 'myrishta-seo-rules' );
	}

	public static function handle_verify_test() {
		self::guard( 'mrsh_verify_test' );
		set_transient( 'mrsh_verify', MRSH_Checks::verify_report(), HOUR_IN_SECONDS );
		self::back( 'myrishta-seo-engines' );
	}

	public static function handle_fill_alt() {
		self::guard( 'mrsh_fill_alt' );
		$n = 0;
		$n = class_exists( 'MRSH_AutoAlt' ) ? MRSH_AutoAlt::run( false, 200 ) : 0;
		self::notice( $n ? 'Added alt text to ' . $n . ' image(s) from their titles. Check important ones by hand.' : 'No images were missing alt text.', $n ? 'success' : 'warning' );
		self::back( 'myrishta-seo' );
	}

	public static function handle_scan_now() {
		self::guard( 'mrsh_scan_now' );
		$was = MRSH_Options::get();
		$n   = MRSH_Discovery::add( array_map( function ( $c ) { return $c['term']; }, array_slice( MRSH_Discovery::content_candidates( MRSH_Discovery::site_posts() ), 0, 20 ) ) );
		self::notice( $n ? 'Added ' . $n . ' phrase(s) found in your content.' : 'No new phrases found in your content yet.', $n ? 'success' : 'warning' );
		self::back( 'myrishta-seo-discover' );
	}

	public static function handle_clear_searches() {
		self::guard( 'mrsh_clear_searches' );
		delete_option( MRSH_Discovery::SEARCH_LOG );
		self::notice( 'Search log cleared.' );
		self::back( 'myrishta-seo-discover' );
	}

	/* ---------------- Keyword bank ---------------- */

	public static function page_keywords() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		$rows   = MRSH_Keywords::all();
		$stats  = MRSH_Keywords::stats();
		$export = wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_export' ), 'mrsh_export' );
		self::open( 'Keyword Bank', 'Your phrases plus a Pakistan-focused expansion, with how to use each one. Expansion phrases are suggestions: check demand in Search Console or Keyword Planner.' );

		echo '<div class="mrsh-grid mrsh-grid-3">';
		echo self::stat( 'Phrases', (int) $stats['total'], 'Your 100 plus expansion and discovered' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo self::stat( 'Targets', (int) $stats['target'], 'Build pages or sections around these' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo self::stat( 'High priority', (int) $stats['high'], 'Start with these' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '</div>';

		echo '<div class="mrsh-card"><div class="mrsh-toolbar">';
		echo '<input type="search" id="mrsh-q" placeholder="Search phrases, Urdu or Roman" class="regular-text">';
		echo '<select id="mrsh-f-group"><option value="">All groups</option>';
		foreach ( MRSH_Keywords::groups() as $g ) {
			echo '<option value="' . esc_attr( $g ) . '">' . esc_html( $g ) . '</option>';
		}
		echo '</select><select id="mrsh-f-treat"><option value="">All treatments</option>';
		foreach ( array( 'Target', 'Filter / neutral guide only', 'Guide hook', 'Convert to question', 'Do not target' ) as $t ) {
			echo '<option value="' . esc_attr( $t ) . '">' . esc_html( $t ) . '</option>';
		}
		echo '</select><select id="mrsh-f-pri"><option value="">All priorities</option><option>High</option><option>Medium</option><option>Low</option></select>';
		echo '<span class="mrsh-count" id="mrsh-count"></span><a class="button" href="' . esc_url( $export ) . '">Download CSV</a></div>';

		echo '<table class="widefat striped mrsh-table" id="mrsh-table"><thead><tr><th>#</th><th>Group</th><th>Urdu</th><th>Roman Urdu / English</th><th>Treatment</th><th>Target page or use</th><th>Priority</th></tr></thead><tbody>';
		$tone = array( 'High' => 'pass', 'Medium' => 'warn', 'Low' => 'unknown' );
		foreach ( $rows as $r ) {
			echo '<tr data-group="' . esc_attr( $r['group'] ) . '" data-treat="' . esc_attr( $r['treatment'] ) . '" data-pri="' . esc_attr( $r['priority'] ) . '">';
			echo '<td>' . (int) $r['n'] . '</td><td>' . esc_html( $r['group'] ) . '</td><td dir="rtl" class="mrsh-urdu">' . esc_html( $r['urdu'] ) . '</td><td>' . esc_html( $r['roman'] ) . '</td><td>' . esc_html( $r['treatment'] ) . '</td><td>' . esc_html( $r['use'] ) . '</td><td>' . self::badge( $tone[ $r['priority'] ], $r['priority'] ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</tbody></table></div>';
		self::close();
	}

	/* ---------------- Coverage ---------------- */

	public static function page_coverage() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		self::open( 'Coverage', 'Which keyword phrases your published pages and guides actually use.' );
		$rep = get_transient( MRSH_Keywords::CACHE );

		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Scan</h2>';
		self::post_button( 'mrsh_scan', $rep ? 'Scan again' : 'Scan site' );
		echo '</div><p class="mrsh-muted">Reads published pages, posts and other indexable content (up to 300). Member profiles are skipped. A phrase counts as used when it appears in a page title or body.</p></div>';

		if ( ! is_array( $rep ) ) {
			self::close();
			return;
		}
		$total = MRSH_Keywords::stats();
		$used  = $total['total'] - count( $rep['uncovered'] );
		echo '<div class="mrsh-grid mrsh-grid-3">';
		echo self::stat( 'Pages scanned', (int) $rep['scanned'], 'Scanned ' . human_time_diff( $rep['time'] ) . ' ago' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo self::stat( 'Phrases used', (int) $used, 'of ' . (int) $total['total'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo self::stat( 'Not used anywhere', (int) count( $rep['uncovered'] ), 'Candidates for new pages or guides' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '</div>';

		$todo = array();
		foreach ( $rep['uncovered'] as $r ) {
			if ( 'Target' === $r['treatment'] ) {
				$todo[] = $r;
			}
		}
		usort(
			$todo,
			function ( $a, $b ) {
				$rank = array( 'High' => 0, 'Medium' => 1, 'Low' => 2 );
				return $rank[ $a['priority'] ] - $rank[ $b['priority'] ];
			}
		);
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Target phrases not used yet</h2></div>';
		if ( $todo ) {
			echo '<p class="mrsh-muted">Showing the first ' . (int) min( 100, count( $todo ) ) . ' of ' . (int) count( $todo ) . ', highest priority first. Ticked phrases get an unpublished draft page with an outline; you write the content and publish it. Phrases without a tick box belong on the homepage, in a filter or inside a guide.</p>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_create_drafts">';
			wp_nonce_field( 'mrsh_create_drafts' );
			echo '<table class="widefat striped mrsh-table"><thead><tr><th><input type="checkbox" class="mrsh-all" aria-label="Select all"></th><th>Phrase</th><th>Group</th><th>Suggested page</th><th>Priority</th></tr></thead><tbody>';
			$tone = array( 'High' => 'pass', 'Medium' => 'warn', 'Low' => 'unknown' );
			foreach ( array_slice( $todo, 0, 100 ) as $r ) {
				$name = '' !== $r['urdu'] && '' !== $r['roman'] ? $r['roman'] . ' (' . $r['urdu'] . ')' : MRSH_Keywords::label( $r );
				$box  = MRSH_Keywords::draftable( $r ) ? '<input type="checkbox" name="n[]" value="' . (int) $r['n'] . '">' : '';
				echo '<tr><td>' . $box . '</td><td>' . esc_html( $name ) . '</td><td>' . esc_html( $r['group'] ) . '</td><td>' . esc_html( $r['use'] ) . '</td><td>' . self::badge( $tone[ $r['priority'] ], $r['priority'] ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			echo '</tbody></table><p><button type="submit" class="button button-primary">Create drafts for ticked phrases (max 10)</button></p></form>';
		} else {
			echo '<p>Every target phrase appears on at least one page.</p>';
		}
		echo '</div>';

		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Pages by phrases used</h2></div><table class="widefat striped mrsh-table"><thead><tr><th>Page</th><th>Phrases used</th><th></th></tr></thead><tbody>';
		foreach ( array_slice( $rep['pages'], 0, 50 ) as $p ) {
			$edit = get_edit_post_link( $p['id'] );
			echo '<tr><td>' . esc_html( '' !== $p['title'] ? $p['title'] : '(no title)' ) . '</td><td>' . (int) $p['matched'] . '</td><td>' . ( $edit ? '<a href="' . esc_url( $edit ) . '">Edit</a>' : '' ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</tbody></table></div>';
		self::close();
	}

	/* ---------------- Editor box ---------------- */

	public static function add_metabox() {
		$types = array_diff( array_keys( get_post_types( array( 'public' => true ) ) ), array( 'attachment' ) );
		foreach ( $types as $type ) {
			add_meta_box( 'mrsh_kw', 'MyRishta keyword coverage', array( __CLASS__, 'render_metabox' ), $type, 'side', 'low' );
		}
	}

	public static function render_metabox( $post ) {
		$cov     = MRSH_Keywords::coverage( $post->post_title . ' ' . $post->post_content );
		$total   = count( MRSH_Keywords::all() );
		$suggest = array();
		$avoid   = array();
		foreach ( $cov['missing'] as $row ) {
			if ( 'Target' === $row['treatment'] && 'High' === $row['priority'] && count( $suggest ) < 10 ) {
				$suggest[] = MRSH_Keywords::label( $row );
			}
		}
		foreach ( $cov['matched'] as $row ) {
			if ( 'Do not target' === $row['treatment'] ) {
				$avoid[] = MRSH_Keywords::label( $row );
			}
		}
		echo '<p><strong>' . (int) count( $cov['matched'] ) . ' of ' . (int) $total . '</strong> bank phrases appear in the saved content.</p>';
		if ( $cov['matched'] ) {
			$names = array_map( array( 'MRSH_Keywords', 'label' ), array_slice( $cov['matched'], 0, 30 ) );
			echo '<p>Used: ' . esc_html( implode( ', ', $names ) ) . '</p>';
		}
		if ( $suggest ) {
			echo '<p>High-priority phrases not used yet: ' . esc_html( implode( ', ', $suggest ) ) . '</p>';
		}
		if ( $avoid ) {
			echo '<p style="color:#b32d2e">Review: ' . esc_html( implode( ', ', $avoid ) ) . ' is marked "do not target". Mention it only to question the preference.</p>';
		}
		echo '<p class="description">Update the page to refresh this. Use phrases where they fit naturally; do not repeat them to fill space. <a href="' . esc_url( self::url( 'myrishta-seo-keywords' ) ) . '">Open keyword bank</a></p>';
	}
}
