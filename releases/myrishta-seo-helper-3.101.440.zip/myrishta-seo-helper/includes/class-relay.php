<?php
/**
 * Email backup senders (failover). The main mailbox (Email (SMTP)) has a daily limit set by the host. When it is used up,
 * mail goes out through the next sender that still has room (Brevo, Mailjet, Resend, Gmail, Outlook or any SMTP), each with
 * its own daily limit. Counting is a rolling 24 hours. A small reserve is kept so password-reset and login-code emails
 * always go out. If every sender is full, the email queue simply waits; nothing is lost.
 * Options: mrsh_relay (settings, passwords encrypted), mrsh_relay_log (send times per sender), mrsh_relay_err (last error).
 * The names contain "relay" and the secrets are encrypted; keep this class free of other plugins.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Relay {

	const OPT = 'mrsh_relay';
	const LOG = 'mrsh_relay_log';
	const ERR = 'mrsh_relay_err';

	private static $cur   = '';
	private static $force = '';
	private static $err   = '';

	public static function get() {
		$d = array( 'on' => 1, 'primary_cap' => 100, 'reserve' => 5, 'providers' => array() );
		$o = get_option( self::OPT, array() );
		$o = is_array( $o ) ? array_merge( $d, $o ) : $d;
		$o['providers'] = is_array( $o['providers'] ) ? $o['providers'] : array();
		return $o;
	}

	public static function on() {
		return ! empty( self::get()['on'] );
	}

	public static function init() {
		add_action( 'phpmailer_init', array( __CLASS__, 'configure' ), 100 );
		add_action( 'wp_mail_succeeded', array( __CLASS__, 'sent' ) );
		add_action( 'wp_mail_failed', array( __CLASS__, 'failed' ), 5 );
		add_action( 'mrsh_relay_keepalive', array( __CLASS__, 'keepalive' ) );
		if ( ! wp_next_scheduled( 'mrsh_relay_keepalive' ) ) {
			wp_schedule_event( time() + 3600, 'daily', 'mrsh_relay_keepalive' );
		}
		if ( is_admin() ) {
			add_action( 'admin_menu', array( __CLASS__, 'menu' ), 28 );
			foreach ( array( 'save', 'psave', 'pdel', 'test', 'reset', 'first' ) as $a ) {
				add_action( 'admin_post_mrsh_relay_' . $a, array( __CLASS__, 'act_' . $a ) );
			}
		}
	}

	/* ---------------------------------------------------------------- secrets */
	private static function key() {
		return hash( 'sha256', wp_salt( 'auth' ) . 'relay', true );
	}

	private static function enc( $plain ) {
		if ( '' === $plain || ! function_exists( 'openssl_encrypt' ) ) {
			return '' === $plain ? '' : 'p:' . $plain;
		}
		$iv = random_bytes( 16 );
		return 'e:' . base64_encode( $iv . openssl_encrypt( $plain, 'aes-256-cbc', self::key(), OPENSSL_RAW_DATA, $iv ) );
	}

	private static function dec( $s ) {
		$s = (string) $s;
		if ( 0 === strpos( $s, 'p:' ) ) {
			return substr( $s, 2 );
		}
		if ( 0 !== strpos( $s, 'e:' ) || ! function_exists( 'openssl_decrypt' ) ) {
			return '';
		}
		$raw = base64_decode( substr( $s, 2 ) );
		$out = openssl_decrypt( substr( $raw, 16 ), 'aes-256-cbc', self::key(), OPENSSL_RAW_DATA, substr( $raw, 0, 16 ) );
		return false === $out ? '' : $out;
	}

	/* ---------------------------------------------------------------- counting */
	private static function used( $id ) {
		$l = get_option( self::LOG, array() );
		$a = is_array( $l ) && isset( $l[ $id ] ) ? (array) $l[ $id ] : array();
		$n = 0;
		$c = time() - DAY_IN_SECONDS;
		foreach ( $a as $t ) {
			if ( (int) $t > $c ) {
				$n++;
			}
		}
		return $n;
	}

	private static function bump( $id ) {
		$l  = get_option( self::LOG, array() );
		$l  = is_array( $l ) ? $l : array();
		$c  = time() - DAY_IN_SECONDS;
		$a  = array_values( array_filter( (array) ( $l[ $id ] ?? array() ), function ( $t ) use ( $c ) {
			return (int) $t > $c;
		} ) );
		$a[]        = time();
		$l[ $id ]   = array_slice( $a, -1500 );
		update_option( self::LOG, $l, false );
	}

	/** All senders in order: the main mailbox first, then the backups. */
	public static function senders() {
		$o   = self::get();
		$smt = class_exists( 'MRSH_Smtp' ) ? MRSH_Smtp::get() : array();
		$out = array( array( 'id' => 'primary', 'name' => 'Main mailbox' . ( ! empty( $smt['user'] ) ? ' (' . $smt['user'] . ')' : '' ), 'cap' => max( 1, (int) $o['primary_cap'] ), 'on' => 1 ) );
		foreach ( $o['providers'] as $p ) {
			$out[] = $p;
		}
		return $out;
	}

	private static function cooling( $id ) {
		return (bool) get_transient( 'mrsh_relay_cd_' . $id );
	}

	private static function room_of( $s ) {
		if ( empty( $s['on'] ) || self::cooling( $s['id'] ) ) {
			return 0;
		}
		return max( 0, (int) $s['cap'] - self::used( $s['id'] ) );
	}

	/** Emails that can still be sent today by the queue (keeps a reserve for password and login-code emails). */
	public static function room() {
		$o = self::get();
		if ( empty( $o['on'] ) ) {
			return 100000;
		}
		$room = 0;
		$n    = 0;
		foreach ( self::senders() as $s ) {
			$r = self::room_of( $s );
			if ( $r > 0 || ! empty( $s['on'] ) ) {
				$n++;
			}
			$room += $r;
		}
		return max( 0, $room - max( 0, (int) $o['reserve'] ) );
	}

	private static function pick() {
		foreach ( self::senders() as $s ) {
			if ( self::room_of( $s ) > 0 ) {
				return $s;
			}
		}
		return null;
	}

	/* ---------------------------------------------------------------- sending */
	public static function configure( $m ) {
		self::$cur = 'primary';
		if ( '' !== self::$force ) {
			$s = null;
			foreach ( self::senders() as $x ) {
				if ( $x['id'] === self::$force ) {
					$s = $x;
				}
			}
		} else {
			if ( ! self::on() ) {
				return;
			}
			$s = self::pick();
		}
		if ( ! $s || 'primary' === $s['id'] ) {
			return; // the main mailbox is already set up by Email (SMTP)
		}
		self::$cur = $s['id'];
		$pass = self::dec( $s['pass'] ?? '' );
		if ( '' === ( $s['host'] ?? '' ) || '' === ( $s['user'] ?? '' ) || '' === $pass ) {
			return;
		}
		$m->isSMTP();
		$m->Host        = $s['host'];
		$m->Port        = (int) $s['port'];
		$m->SMTPAuth    = true;
		$m->Username    = $s['user'];
		$m->Password    = $pass;
		$m->SMTPSecure  = in_array( $s['enc'], array( 'ssl', 'tls' ), true ) ? $s['enc'] : '';
		$m->SMTPAutoTLS = ( 'tls' === $s['enc'] );
		$m->Timeout     = 12;
		$from           = is_email( $s['from'] ?? '' ) ? $s['from'] : $s['user'];
		$m->Sender      = $from;
		try {
			$smt  = class_exists( 'MRSH_Smtp' ) ? MRSH_Smtp::get() : array();
			$name = ! empty( $smt['name'] ) ? $smt['name'] : wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
			$m->setFrom( $from, $name, false );
			if ( ! empty( $smt['user'] ) && is_email( $smt['user'] ) ) {
				$m->clearReplyTos();
				$m->addReplyTo( $smt['user'], $name );
			}
		} catch ( \Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement
		}
	}

	public static function sent( $data = array() ) {
		self::bump( '' !== self::$cur ? self::$cur : 'primary' );
		self::$cur = '';
	}

	public static function failed( $err ) {
		$id  = '' !== self::$cur ? self::$cur : 'primary';
		$msg = is_wp_error( $err ) ? $err->get_error_message() : 'mail failed';
		self::$err = $msg;
		$e   = get_option( self::ERR, array() );
		$e   = is_array( $e ) ? $e : array();
		$e[ $id ] = array( time(), mb_substr( $msg, 0, 220 ) );
		update_option( self::ERR, $e, false );
		if ( preg_match( '/quota|limit|exceed|too many|rate|throttl|\b45[012]\b|\b421\b|5\.4\.5|daily|suspended|blocked/i', $msg ) ) {
			set_transient( 'mrsh_relay_cd_' . $id, 1, 2 * HOUR_IN_SECONDS ); // resume after 2 hours
		} elseif ( preg_match( '/auth|credential|password|username|login|\b535\b|\b530\b/i', $msg ) ) {
			set_transient( 'mrsh_relay_cd_' . $id, 1, 30 * MINUTE_IN_SECONDS );
		}
	}

	/* ---------------------------------------------------------------- admin actions */
	private static function guard( $n ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( $n );
	}

	private static function back( $m ) {
		wp_safe_redirect( add_query_arg( 'msg', rawurlencode( $m ), admin_url( 'admin.php?page=mrsh-relay' ) ) );
		exit;
	}

	public static function act_save() {
		self::guard( 'mrsh_relay_save' );
		$o = self::get();
		$o['on']          = empty( $_POST['on'] ) ? 0 : 1;
		$o['primary_cap'] = max( 1, min( 5000, (int) ( $_POST['primary_cap'] ?? 100 ) ) );
		$o['reserve']     = max( 0, min( 100, (int) ( $_POST['reserve'] ?? 5 ) ) );
		update_option( self::OPT, $o, false );
		self::back( 'Saved.' );
	}

	public static function act_psave() {
		self::guard( 'mrsh_relay_psave' );
		$o   = self::get();
		$id  = isset( $_POST['pid'] ) ? sanitize_key( wp_unslash( $_POST['pid'] ) ) : '';
		$idx = -1;
		foreach ( $o['providers'] as $i => $p ) {
			if ( '' !== $id && $p['id'] === $id ) {
				$idx = $i;
			}
		}
		if ( $idx < 0 && count( $o['providers'] ) >= 5 ) {
			self::back( 'You can add up to 5 backup senders.' );
		}
		$old  = $idx >= 0 ? $o['providers'][ $idx ] : array();
		$pass = isset( $_POST['pass'] ) ? trim( (string) wp_unslash( $_POST['pass'] ) ) : ''; // phpcs:ignore WordPress.Security
		$enc  = isset( $_POST['enc'] ) ? sanitize_key( wp_unslash( $_POST['enc'] ) ) : 'tls';
		$new  = array(
			'id'   => $idx >= 0 ? $id : 'p' . substr( md5( uniqid( '', true ) ), 0, 6 ),
			'name' => mb_substr( sanitize_text_field( wp_unslash( $_POST['name'] ?? 'Backup sender' ) ), 0, 40 ),
			'host' => sanitize_text_field( wp_unslash( $_POST['host'] ?? '' ) ),
			'port' => max( 1, min( 65535, (int) ( $_POST['port'] ?? 587 ) ) ),
			'enc'  => in_array( $enc, array( 'ssl', 'tls', 'none' ), true ) ? $enc : 'tls',
			'user' => sanitize_text_field( wp_unslash( $_POST['user'] ?? '' ) ),
			'pass' => '' !== $pass ? self::enc( $pass ) : ( $old['pass'] ?? '' ),
			'from' => sanitize_email( wp_unslash( $_POST['from'] ?? '' ) ),
			'cap'  => max( 1, min( 5000, (int) ( $_POST['cap'] ?? 100 ) ) ),
			'on'   => empty( $_POST['pon'] ) ? 0 : 1,
		);
		if ( $idx >= 0 ) {
			$o['providers'][ $idx ] = $new;
		} else {
			$o['providers'][] = $new;
		}
		update_option( self::OPT, $o, false );
		delete_transient( 'mrsh_relay_cd_' . $new['id'] );
		self::back( 'Saved "' . $new['name'] . '". Press Send test to check it.' );
	}

	public static function act_pdel() {
		self::guard( 'mrsh_relay_pdel' );
		$id = isset( $_POST['pid'] ) ? sanitize_key( wp_unslash( $_POST['pid'] ) ) : '';
		$o  = self::get();
		$o['providers'] = array_values( array_filter( $o['providers'], function ( $p ) use ( $id ) {
			return $p['id'] !== $id;
		} ) );
		update_option( self::OPT, $o, false );
		self::back( 'Removed.' );
	}

	/** Puts one backup sender at the top of the backup list (tried right after the main mailbox). */
	public static function act_first() {
		self::guard( 'mrsh_relay_first' );
		$id = isset( $_POST['pid'] ) ? sanitize_key( wp_unslash( $_POST['pid'] ) ) : '';
		$o  = self::get();
		$top = array();
		$rest = array();
		foreach ( $o['providers'] as $p ) {
			if ( $p['id'] === $id ) {
				$top[] = $p;
			} else {
				$rest[] = $p;
			}
		}
		$o['providers'] = array_merge( $top, $rest );
		update_option( self::OPT, $o, false );
		self::back( 'Done. This sender is now the first backup.' );
	}

	public static function act_reset() {
		self::guard( 'mrsh_relay_reset' );
		delete_option( self::LOG );
		delete_option( self::ERR );
		foreach ( self::senders() as $s ) {
			delete_transient( 'mrsh_relay_cd_' . $s['id'] );
		}
		self::back( 'Counters cleared. Every sender is ready again.' );
	}

	/** Once a month send one tiny mail through every backup sender, so a free key is never "unused" for 90 days. */
	public static function keepalive() {
		if ( time() - (int) get_option( 'mrsh_relay_ka', 0 ) < 25 * DAY_IN_SECONDS ) {
			return;
		}
		update_option( 'mrsh_relay_ka', time(), false );
		$to = get_option( 'admin_email' );
		foreach ( self::senders() as $s ) {
			if ( 'primary' === $s['id'] || '' === (string) ( $s['host'] ?? '' ) ) {
				continue;
			}
			self::$force = $s['id'];
			wp_mail( $to, 'Monthly check: backup sender "' . $s['id'] . '" works', 'This is the automatic monthly check. It keeps the backup sender active. Nothing to do.' );
			self::$force = '';
		}
	}

	public static function act_test() {
		self::guard( 'mrsh_relay_test' );
		$id = isset( $_POST['pid'] ) ? sanitize_key( wp_unslash( $_POST['pid'] ) ) : 'primary';
		$to = isset( $_POST['to'] ) ? sanitize_email( wp_unslash( $_POST['to'] ) ) : '';
		if ( ! is_email( $to ) ) {
			$to = wp_get_current_user()->user_email;
		}
		self::$force = $id;
		self::$err   = '';
		$ok = wp_mail( $to, 'Test email from ' . wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ), 'This test email was sent through the sender "' . $id . '". If you can read it, that sender works.' );
		self::$force = '';
		if ( $ok ) {
			delete_transient( 'mrsh_relay_cd_' . $id );
		}
		self::back( $ok ? 'Test email sent to ' . $to . '. Check the inbox and the junk folder.' : 'The test failed: ' . ( self::$err ? self::$err : 'unknown error' ) );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Email backup senders', 'Email backup senders', 'manage_options', 'mrsh-relay', array( __CLASS__, 'page' ) );
	}

	/* ---------------------------------------------------------------- page */
	private static function form( $p, $new = false ) {
		$post = esc_url( admin_url( 'admin-post.php' ) );
		$p    = array_merge( array( 'id' => '', 'name' => '', 'host' => '', 'port' => 587, 'enc' => 'tls', 'user' => '', 'pass' => '', 'from' => '', 'cap' => 100, 'on' => 1 ), $p );
		$h    = '<form method="post" action="' . $post . '" class="rl-f"' . ( $new ? ' id="rl-new"' : '' ) . '><input type="hidden" name="action" value="mrsh_relay_psave"><input type="hidden" name="pid" value="' . esc_attr( $p['id'] ) . '">' . wp_nonce_field( 'mrsh_relay_psave', '_wpnonce', true, false );
		if ( $new ) {
			$h .= '<label class="rl-w">Choose a provider<select id="rl-preset"><option value="">Custom SMTP</option><option value="brevo">Brevo (free plan about 300 a day)</option><option value="mailjet">Mailjet (free plan about 200 a day)</option><option value="resend">Resend (free plan about 100 a day)</option><option value="gmail">Gmail (about 500 a day)</option><option value="outlook">Outlook / Microsoft 365</option><option value="zoho">Zoho Mail</option></select><span id="rl-hint" class="rl-s">Pick one to fill the boxes. Limits change, so check your own plan.</span></label>';
		}
		$h .= '<label>Name<input type="text" name="name" value="' . esc_attr( $p['name'] ) . '" required></label>';
		$h .= '<label>SMTP host<input type="text" name="host" value="' . esc_attr( $p['host'] ) . '" required></label>';
		$h .= '<label>Port<input type="number" name="port" value="' . (int) $p['port'] . '"></label>';
		$h .= '<label>Security<select name="enc"><option value="tls"' . selected( $p['enc'], 'tls', false ) . '>TLS (587)</option><option value="ssl"' . selected( $p['enc'], 'ssl', false ) . '>SSL (465)</option><option value="none"' . selected( $p['enc'], 'none', false ) . '>None</option></select></label>';
		$h .= '<label>Username<input type="text" name="user" value="' . esc_attr( $p['user'] ) . '" autocomplete="off" required></label>';
		$h .= '<label>Password or key<input type="password" name="pass" autocomplete="new-password" placeholder="' . esc_attr( '' !== $p['pass'] ? 'saved (leave empty to keep)' : '' ) . '"' . ( $new ? ' required' : '' ) . '></label>';
		$h .= '<label>Send from (verified address)<input type="email" name="from" value="' . esc_attr( $p['from'] ) . '" placeholder="noreply@myrishta.pk"></label>';
		$h .= '<label>Emails per day<input type="number" name="cap" min="1" max="5000" value="' . (int) $p['cap'] . '"></label>';
		$h .= '<label class="rl-chk"><input type="checkbox" name="pon" value="1"' . checked( ! empty( $p['on'] ), true, false ) . '> Use this sender</label>';
		$h .= '<div class="rl-b"><button class="button button-primary">' . ( $new ? 'Add sender' : 'Save sender' ) . '</button></div></form>';
		return $h;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		global $wpdb;
		$o     = self::get();
		$list  = self::senders();
		$post  = esc_url( admin_url( 'admin-post.php' ) );
		$errs  = get_option( self::ERR, array() );
		$errs  = is_array( $errs ) ? $errs : array();
		$tot_u = 0;
		$tot_c = 0;
		foreach ( $list as $s ) {
			if ( ! empty( $s['on'] ) ) {
				$tot_u += self::used( $s['id'] );
				$tot_c += (int) $s['cap'];
			}
		}
		$q = 0;
		if ( class_exists( 'MRSH_Mailq' ) ) {
			$t = MRSH_Mailq::table();
			if ( $wpdb->get_var( "SHOW TABLES LIKE '{$t}'" ) === $t ) { // phpcs:ignore WordPress.DB
				$q = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$t} WHERE status='queued'" ); // phpcs:ignore WordPress.DB
			}
		}
		if ( class_exists( 'MRSH_Admin' ) ) {
			MRSH_Admin::open( 'Email backup senders', 'When your main mailbox reaches its daily limit, email keeps going out through your backup senders. Nothing is lost.' );
		} else {
			echo '<div class="wrap"><h1>Email backup senders</h1>';
		}
		if ( isset( $_GET['msg'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="notice notice-info"><p>' . esc_html( rawurldecode( (string) wp_unslash( $_GET['msg'] ) ) ) . '</p></div>'; // phpcs:ignore
		}
		?>
<style>
.rl{max-width:1000px;margin:18px 0 40px;font-size:14px}.rl *{box-sizing:border-box}
.rl-chips{display:flex;gap:10px;flex-wrap:wrap;margin:0 0 16px}
.rl-chip{background:#fff;border-radius:14px;padding:12px 16px;min-width:150px;box-shadow:0 1px 3px rgba(17,24,39,.08),0 0 0 1px rgba(17,24,39,.04)}.rl-chip small{display:block;color:#6b7280;text-transform:uppercase;letter-spacing:.06em;font-size:11px}.rl-chip b{font-size:20px}
.rl-card{background:#fff;border-radius:20px;padding:22px 26px;margin:0 0 16px;box-shadow:0 1px 3px rgba(17,24,39,.07),0 0 0 1px rgba(17,24,39,.04)}
.rl-hd{display:flex;align-items:center;gap:12px;margin:0 0 6px}.rl-hd h2{margin:0;font-size:17px}
.rl-n{width:30px;height:30px;border-radius:10px;background:linear-gradient(135deg,#1c8a6a,#0b4d3b);color:#fff;display:grid;place-items:center;font-weight:700}
.rl-sub{margin:0 0 14px;color:#6b7280;line-height:1.55;max-width:780px}
.rl-row{display:grid;grid-template-columns:minmax(0,1.4fr) minmax(0,2fr) auto;gap:14px;align-items:center;padding:12px 0;border-bottom:1px solid #eef0f3}.rl-row:last-child{border:0}
.rl-bar{height:10px;border-radius:99px;background:#e8eaf0;overflow:hidden;margin:6px 0 2px}.rl-bar i{display:block;height:100%;background:linear-gradient(90deg,#1c8a6a,#0b4d3b)}.rl-bar i.f{background:#dc2626}
.rl-pill{display:inline-block;border-radius:999px;padding:2px 10px;font-size:12px;background:#e8f7ee;color:#14532d}.rl-pill.w{background:#fef3c7;color:#78350f}.rl-pill.r{background:#fee2e2;color:#7f1d1d}.rl-pill.g{background:#eef0f3;color:#4b5563}
.rl-s{display:block;font-weight:400;color:#6b7280;font-size:12.5px;margin-top:3px}
.rl-f{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px;margin-top:10px}
.rl-f label{display:flex;flex-direction:column;gap:4px;font-weight:600;font-size:13px}.rl-f .rl-w,.rl-f .rl-b{grid-column:1/-1}
.rl-f input[type=text],.rl-f input[type=email],.rl-f input[type=password],.rl-f input[type=number],.rl-f select,.rl input.rl-i{border:1px solid #d6dae1;border-radius:12px;padding:9px 12px;background:#f8fafc;font-weight:400;width:100%}
.rl-chk{flex-direction:row!important;align-items:center;gap:8px!important}
.rl details{border:1px solid #e5e7eb;border-radius:14px;padding:10px 14px;margin:8px 0}.rl summary{cursor:pointer;font-weight:700}
.rl-tb{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px;align-items:center}
.rl-sw{display:flex;gap:12px;align-items:flex-start;padding:12px 14px;border:1px solid #e5e7eb;border-radius:14px;margin:0 0 10px;cursor:pointer}.rl-sw input{margin-top:4px;width:18px;height:18px;accent-color:#0b8f4d}.rl-sw b{display:block}.rl-sw span{color:#6b7280;font-size:13px}
.rl code{background:#f3f4f6;padding:2px 6px;border-radius:6px;overflow-wrap:anywhere}
@media(max-width:782px){.rl-row{grid-template-columns:minmax(0,1fr)}}
</style>
<div class="rl">
	<div class="rl-chips">
		<div class="rl-chip"><small>Sent in the last 24 hours</small><b><?php echo (int) $tot_u; ?> of <?php echo (int) $tot_c; ?></b></div>
		<div class="rl-chip"><small>Waiting in the queue</small><b><?php echo (int) $q; ?></b></div>
		<div class="rl-chip"><small>Failover</small><b style="color:<?php echo $o['on'] ? '#047857' : '#b91c1c'; ?>"><?php echo $o['on'] ? 'ON' : 'OFF'; ?></b></div>
	</div>

	<div class="rl-card">
		<div class="rl-hd"><span class="rl-n">1</span><h2>Today's senders</h2></div>
		<p class="rl-sub">Emails are sent through the first sender with room. When it is full, the next one takes over. The count is for the last 24 hours.</p>
		<?php foreach ( $list as $s ) :
			$u   = self::used( $s['id'] );
			$cap = max( 1, (int) $s['cap'] );
			$pct = min( 100, (int) round( 100 * $u / $cap ) );
			$cd  = self::cooling( $s['id'] );
			if ( empty( $s['on'] ) ) {
				$st = array( 'g', 'switched off' );
			} elseif ( $cd ) {
				$st = array( 'r', 'resting after an error' );
			} elseif ( $u >= $cap ) {
				$st = array( 'w', 'full for now' );
			} else {
				$st = array( '', 'ready' );
			}
			$e = $errs[ $s['id'] ] ?? null;
			?>
		<div class="rl-row">
			<div><b><?php echo esc_html( $s['name'] ); ?></b><br><span class="rl-pill <?php echo esc_attr( $st[0] ); ?>"><?php echo esc_html( $st[1] ); ?></span></div>
			<div><div class="rl-bar"><i class="<?php echo $u >= $cap ? 'f' : ''; ?>" style="width:<?php echo (int) $pct; ?>%"></i></div><span class="rl-s"><?php echo (int) $u; ?> of <?php echo (int) $cap; ?> used<?php echo $e ? ' &middot; last problem ' . esc_html( wp_date( 'j M g:i a', (int) $e[0] ) ) . ': ' . esc_html( $e[1] ) : ''; ?></span></div>
			<form method="post" action="<?php echo $post; // phpcs:ignore ?>" style="margin:0"><input type="hidden" name="action" value="mrsh_relay_test"><input type="hidden" name="pid" value="<?php echo esc_attr( $s['id'] ); ?>"><?php wp_nonce_field( 'mrsh_relay_test' ); ?><button class="button">Send test</button></form>
		</div>
		<?php endforeach; ?>
		<div class="rl-tb"><form method="post" action="<?php echo $post; // phpcs:ignore ?>" style="margin:0"><input type="hidden" name="action" value="mrsh_relay_reset"><?php wp_nonce_field( 'mrsh_relay_reset' ); ?><button class="button">Clear counters and start fresh</button></form><span class="rl-s">Use it only if you know the provider reset its limit.</span></div>
	</div>

	<div class="rl-card">
		<div class="rl-hd"><span class="rl-n">2</span><h2>Rules</h2></div>
		<form method="post" action="<?php echo $post; // phpcs:ignore ?>">
			<input type="hidden" name="action" value="mrsh_relay_save"><?php wp_nonce_field( 'mrsh_relay_save' ); ?>
			<label class="rl-sw"><input type="checkbox" name="on" value="1"<?php checked( $o['on'], 1 ); ?>><div><b>Switch to a backup sender when the main mailbox is full</b><span>Also switches if a sender returns a "limit reached" error. If everything is full, emails wait in the queue and go out later.</span></div></label>
			<div class="rl-f">
				<label>Main mailbox: emails per day<input type="number" name="primary_cap" min="1" max="5000" value="<?php echo (int) $o['primary_cap']; ?>"><span class="rl-s">Hostinger: 100 a day on the free mailbox that comes with Premium hosting, 1,000 on Business Starter, 3,000 on Business Standard or Premium email. Check hPanel, Emails, Mailboxes, View limits.</span></label>
				<label>Keep a reserve for important emails<input type="number" name="reserve" min="0" max="100" value="<?php echo (int) $o['reserve']; ?>"><span class="rl-s">Password-reset and login-code emails always get through. Bulk mail stops this many early.</span></label>
				<div class="rl-b"><button class="button button-primary">Save rules</button></div>
			</div>
		</form>
	</div>

	<div class="rl-card">
		<div class="rl-hd"><span class="rl-n">3</span><h2>Backup senders</h2></div>
		<p class="rl-sub">Add a free account from another mail service. It takes over when the main mailbox is full. Use the same website address as the sender, and verify it in that service so mail does not go to junk.</p>
		<?php foreach ( $o['providers'] as $p ) : ?>
		<details>
			<summary><?php echo esc_html( ( $i0 = ( isset( $i0 ) ? $i0 + 1 : 1 ) ) . '. ' . $p['name'] ); ?> &middot; <?php echo (int) $p['cap']; ?> a day <?php echo empty( $p['on'] ) ? '(off)' : ''; ?></summary>
			<?php echo self::form( $p ); // phpcs:ignore ?>
			<div class="rl-tb"><form method="post" action="<?php echo $post; // phpcs:ignore ?>" onsubmit="return confirm('Remove this sender?')" style="margin:0"><input type="hidden" name="action" value="mrsh_relay_pdel"><input type="hidden" name="pid" value="<?php echo esc_attr( $p['id'] ); ?>"><?php wp_nonce_field( 'mrsh_relay_pdel' ); ?><button class="button">Remove this sender</button></form> <form method="post" action="<?php echo $post; // phpcs:ignore ?>" style="margin:0"><input type="hidden" name="action" value="mrsh_relay_first"><input type="hidden" name="pid" value="<?php echo esc_attr( $p['id'] ); ?>"><?php wp_nonce_field( 'mrsh_relay_first' ); ?><button class="button button-primary">Make this the first backup</button></form></div>
		</details>
		<?php endforeach; ?>
		<details<?php echo $o['providers'] ? '' : ' open'; ?>>
			<summary>+ Add a backup sender</summary>
			<?php echo self::form( array(), true ); // phpcs:ignore ?>
		</details>
	</div>

	<div class="rl-card">
		<div class="rl-hd"><span class="rl-n">4</span><h2>Tips so mail is not marked as junk</h2></div>
		<p class="rl-sub">Add these to your domain's DNS (Hostinger, DNS zone) once. Each backup service shows the exact records after you verify the domain in its dashboard.</p>
		<ul style="margin:0 0 0 18px;list-style:disc">
			<li><b>Brevo:</b> sender domain with DKIM; SPF include <code>include:spf.brevo.com</code></li>
			<li><b>Mailjet:</b> SPF include <code>include:spf.mailjet.com</code>, plus DKIM from its dashboard</li>
			<li><b>Resend:</b> add the three records it shows (SPF, DKIM, return path)</li>
			<li><b>Gmail:</b> use a Gmail App Password; mail is sent from that Gmail address</li>
			<li>Keep one SPF record only: join all <code>include:</code> parts into a single line.</li>
		</ul>
	</div>
</div>
<script>
(function(){var P={brevo:{n:'Brevo',h:'smtp-relay.brevo.com',p:587,e:'tls',c:280,t:'Username: your Brevo login email. Password: the SMTP key from Brevo, SMTP and API (not your account password). Verify the sender address in Brevo.'},
mailjet:{n:'Mailjet',h:'in-v3.mailjet.com',p:587,e:'tls',c:180,t:'Username: your API key. Password: your Secret key. Verify the sender address in Mailjet.'},
resend:{n:'Resend',h:'smtp.resend.com',p:465,e:'ssl',c:90,u:'resend',t:'Username is resend. Password: your Resend API key. Verify your domain in Resend first.'},
gmail:{n:'Gmail',h:'smtp.gmail.com',p:587,e:'tls',c:450,t:'Username: your full Gmail address. Password: a Gmail App Password (turn on 2-step verification first). Send from that same Gmail address.'},
outlook:{n:'Outlook',h:'smtp.office365.com',p:587,e:'tls',c:250,t:'Username: your Outlook or Microsoft 365 address. Use an app password if asked. Send from that address.'},
zoho:{n:'Zoho Mail',h:'smtp.zoho.com',p:465,e:'ssl',c:100,t:'Username: your Zoho mailbox address. Use an app-specific password. Send from that address.'}};
var s=document.getElementById('rl-preset');if(!s)return;var f=document.getElementById('rl-new');
s.onchange=function(){var d=P[s.value],h=document.getElementById('rl-hint');if(!d){h.textContent='Enter the details your mail service gave you.';return}
f.elements.name.value=d.n;f.elements.host.value=d.h;f.elements.port.value=d.p;f.elements.enc.value=d.e;f.elements.cap.value=d.c;if(d.u)f.elements.user.value=d.u;h.textContent=d.t}})();
</script>
		<?php
		if ( class_exists( 'MRSH_Admin' ) ) {
			MRSH_Admin::close();
		} else {
			echo '</div>';
		}
	}
}

MRSH_Relay::init();
