<?php
/**
 * Photo Optimizer.
 *  1. Automatic: every JPEG/PNG uploaded to the site is turned into a small WebP (longest side limited, quality ~72).
 *     EXIF/GPS data inside the photo is removed by the conversion. The original is only replaced when the result is smaller.
 *  2. Bulk tool (Settings > Photo Optimizer): shrinks photos that are already in the Media Library, a few at a time.
 *     It keeps each file's name and type, so no link on the website breaks. Originals are backed up first (optional).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Images {

	const OPT      = 'mrsh_img_opts';
	const SAVED    = 'mrsh_img_saved';   // array( 'files' => n, 'bytes' => n )
	const DONE     = '_mrsh_img_done';   // attachment meta: already optimised.
	const BACKUP   = 'mrsh-photo-backup';

	public static function opts() {
		$o = get_option( self::OPT, array() );
		return array(
			'enabled'  => isset( $o['enabled'] ) ? (int) $o['enabled'] : 1,
			'max_edge' => isset( $o['max_edge'] ) ? max( 600, min( 4000, (int) $o['max_edge'] ) ) : 1600,
			'quality'  => isset( $o['quality'] ) ? max( 40, min( 95, (int) $o['quality'] ) ) : 80,
			'webp'     => isset( $o['webp'] ) ? (int) $o['webp'] : 1,
			'backup'   => isset( $o['backup'] ) ? (int) $o['backup'] : 1,
		);
	}

	public static function init() {
		add_filter( 'wp_handle_upload', array( __CLASS__, 'shrink' ), 20, 2 );
		add_filter( 'wp_editor_set_quality', array( __CLASS__, 'quality' ), 20, 2 );
		add_filter( 'jpeg_quality', array( __CLASS__, 'jpeg_q' ), 20 );
		add_filter( 'big_image_size_threshold', array( __CLASS__, 'threshold' ), 20 );
		add_action( 'mrsh_img_cron', array( __CLASS__, 'cron_batch' ) );
		add_action( 'init', array( __CLASS__, 'cron_arm' ), 30 );
		add_action( 'init', array( __CLASS__, 'protect_backup' ), 31 );
		if ( is_admin() ) {
			add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
			add_action( 'admin_post_mrsh_img_save', array( __CLASS__, 'save' ) );
			add_action( 'wp_ajax_mrsh_img_batch', array( __CLASS__, 'ajax_batch' ) );
			add_action( 'admin_post_mrsh_img_clear_backup', array( __CLASS__, 'clear_backup' ) );
		}
	}

	public static function quality( $q, $mime = '' ) {
		$o = self::opts();
		return $o['enabled'] ? $o['quality'] : $q;
	}

	public static function jpeg_q( $q ) {
		$o = self::opts();
		return $o['enabled'] ? min( 80, $o['quality'] + 3 ) : $q;
	}

	public static function threshold( $t ) {
		$o = self::opts();
		return $o['enabled'] ? max( 1600, $o['max_edge'] ) : $t;
	}

	private static function add_saved( $bytes ) {
		$s = get_option( self::SAVED, array( 'files' => 0, 'bytes' => 0 ) );
		$s['files'] = (int) $s['files'] + 1;
		$s['bytes'] = (int) $s['bytes'] + max( 0, (int) $bytes );
		update_option( self::SAVED, $s, false );
	}

	/* ---------- 1. automatic, on upload ---------- */

	public static function shrink( $upload, $context = 'upload' ) {
		$o = self::opts();
		if ( ! $o['enabled'] || ! is_array( $upload ) || ! empty( $upload['error'] ) || empty( $upload['file'] ) || empty( $upload['type'] ) ) {
			return $upload;
		}
		if ( ! in_array( $upload['type'], array( 'image/jpeg', 'image/png' ), true ) ) {
			return $upload; // gif (may be animated), webp (already small), svg and documents are left alone.
		}
		$file = $upload['file'];
		if ( ! file_exists( $file ) ) {
			return $upload;
		}
		$before = (int) filesize( $file );
		$editor = wp_get_image_editor( $file );
		if ( is_wp_error( $editor ) ) {
			return $upload;
		}
		if ( method_exists( $editor, 'maybe_exif_rotate' ) ) {
			$editor->maybe_exif_rotate();
		}
		$size = $editor->get_size();
		if ( ! empty( $size['width'] ) && ( $size['width'] > $o['max_edge'] || $size['height'] > $o['max_edge'] ) ) {
			$editor->resize( $o['max_edge'], $o['max_edge'], false );
		}
		$editor->set_quality( $o['quality'] );
		$webp = $o['webp'] && wp_image_editor_supports( array( 'mime_type' => 'image/webp' ) );
		$mime = $webp ? 'image/webp' : 'image/jpeg';
		$ext  = $webp ? 'webp' : 'jpg';
		$dir  = dirname( $file );
		$name = wp_unique_filename( $dir, preg_replace( '/\.[^.]+$/', '', basename( $file ) ) . '.' . $ext );
		$dest = trailingslashit( $dir ) . $name;
		$saved = $editor->save( $dest, $mime );
		if ( is_wp_error( $saved ) || empty( $saved['path'] ) || ! file_exists( $saved['path'] ) ) {
			return $upload;
		}
		$after = (int) filesize( $saved['path'] );
		if ( $after <= 0 || $after >= $before ) {
			@unlink( $saved['path'] );
			return $upload;
		}
		@unlink( $file );
		self::add_saved( $before - $after );
		$upload['file'] = $saved['path'];
		$upload['url']  = trailingslashit( dirname( $upload['url'] ) ) . basename( $saved['path'] );
		$upload['type'] = $mime;
		return $upload;
	}

	/* ---------- 2. bulk tool for photos already on the site ---------- */

	/** Keeps the private copies of original photos from being opened by anyone with the link. */
	public static function protect_backup() {
		if ( 'v1' === get_option( 'mrsh_bk_prot', '' ) ) {
			return;
		}
		$bd = self::backup_dir();
		if ( ! is_dir( $bd ) ) {
			return; // created later by optimise_one(), which writes the same file.
		}
		if ( @file_put_contents( $bd . '.htaccess', "Require all denied\nDeny from all\n" ) ) {
			update_option( 'mrsh_bk_prot', 'v1', false );
		}
	}

	private static function backup_dir() {
		$u = wp_upload_dir();
		return trailingslashit( $u['basedir'] ) . self::BACKUP . '/';
	}

	/** Shrinks one existing JPEG in place (same file name). Returns bytes saved (0 = left as it was). */
	private static function optimise_one( $id, $o ) {
		$file = get_attached_file( $id );
		if ( ! $file || ! file_exists( $file ) ) {
			return 0;
		}
		$before = (int) filesize( $file );
		$editor = wp_get_image_editor( $file );
		if ( is_wp_error( $editor ) ) {
			return 0;
		}
		if ( method_exists( $editor, 'maybe_exif_rotate' ) ) {
			$editor->maybe_exif_rotate();
		}
		$size = $editor->get_size();
		if ( ! empty( $size['width'] ) && ( $size['width'] > $o['max_edge'] || $size['height'] > $o['max_edge'] ) ) {
			$editor->resize( $o['max_edge'], $o['max_edge'], false );
		}
		$editor->set_quality( $o['quality'] );
		$tmp   = $file . '.mrsh-tmp.jpg';
		$saved = $editor->save( $tmp, 'image/jpeg' );
		if ( is_wp_error( $saved ) || empty( $saved['path'] ) || ! file_exists( $saved['path'] ) ) {
			return 0;
		}
		$after = (int) filesize( $saved['path'] );
		if ( $after <= 0 ) {
			@unlink( $saved['path'] );
			return 0;
		}
		if ( $after > $before * 0.92 ) { // less than 8% smaller: not worth touching.
			@unlink( $saved['path'] );
			return 0;
		}
		if ( $o['backup'] ) {
			$bd = self::backup_dir();
			if ( wp_mkdir_p( $bd ) ) {
				if ( ! file_exists( $bd . 'index.html' ) ) {
					@file_put_contents( $bd . 'index.html', '' );
				}
				if ( ! file_exists( $bd . '.htaccess' ) ) {
					@file_put_contents( $bd . '.htaccess', "Require all denied\nDeny from all\n" );
				}
				@copy( $file, $bd . $id . '-' . basename( $file ) );
			}
		}
		if ( ! @rename( $saved['path'], $file ) ) {
			@unlink( $saved['path'] );
			return 0;
		}
		clearstatcache();
		$meta = wp_generate_attachment_metadata( $id, $file ); // rebuilds the thumbnails from the smaller original.
		if ( is_array( $meta ) ) {
			wp_update_attachment_metadata( $id, $meta );
		}
		return $before - $after;
	}

	/* ---------- 3. automatic background run over the existing library ---------- */

	/** Starts the background run once, and again after it finishes only when new photos are waiting. */
	public static function cron_arm() {
		if ( ! self::opts()['enabled'] || wp_doing_ajax() || 'done' === get_option( 'mrsh_img_auto', '' ) || wp_next_scheduled( 'mrsh_img_cron' ) ) {
			return;
		}
		wp_schedule_single_event( time() + 90, 'mrsh_img_cron' );
	}

	/** A few photos per run. Only photos that are really heavy are touched, so small, already-good photos keep their quality. */
	public static function cron_batch() {
		@set_time_limit( 120 );
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$o   = self::opts();
		$ids = get_posts( array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'post_mime_type' => 'image/jpeg',
			'posts_per_page' => 3,
			'fields'         => 'ids',
			'orderby'        => 'ID',
			'order'          => 'DESC',
			'no_found_rows'  => true,
			'meta_query'     => array( array( 'key' => self::DONE, 'compare' => 'NOT EXISTS' ) ),
		) );
		foreach ( $ids as $id ) {
			$file = get_attached_file( $id );
			$heavy = $file && file_exists( $file ) && filesize( $file ) > 200 * 1024;
			if ( $heavy ) {
				$b = self::optimise_one( (int) $id, $o );
				if ( $b > 0 ) {
					self::add_saved( $b );
				}
			}
			update_post_meta( $id, self::DONE, time() );
		}
		if ( count( $ids ) < 3 ) {
			update_option( 'mrsh_img_auto', 'done', false );
			return;
		}
		wp_schedule_single_event( time() + 120, 'mrsh_img_cron' );
	}

	private static function counts() {
		global $wpdb;
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='attachment' AND post_mime_type='image/jpeg'" );
		$done  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->postmeta} pm JOIN {$wpdb->posts} p ON p.ID=pm.post_id WHERE pm.meta_key=%s AND p.post_mime_type='image/jpeg'", self::DONE ) );
		return array( $total, $done );
	}

	public static function ajax_batch() {
		if ( ! current_user_can( 'manage_options' ) || ! check_ajax_referer( 'mrsh_img_batch', 'n', false ) ) {
			wp_send_json_error( 'Not allowed', 403 );
		}
		@set_time_limit( 120 );
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$o   = self::opts();
		$ids = get_posts( array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'post_mime_type' => 'image/jpeg',
			'posts_per_page' => 4,
			'fields'         => 'ids',
			'orderby'        => 'ID',
			'order'          => 'ASC',
			'no_found_rows'  => true,
			'meta_query'     => array( array( 'key' => self::DONE, 'compare' => 'NOT EXISTS' ) ),
		) );
		$saved = 0;
		foreach ( $ids as $id ) {
			$b = self::optimise_one( (int) $id, $o );
			update_post_meta( $id, self::DONE, time() );
			if ( $b > 0 ) {
				$saved += $b;
				self::add_saved( $b );
			}
		}
		list( $total, $done ) = self::counts();
		wp_send_json_success( array( 'processed' => count( $ids ), 'saved' => $saved, 'total' => $total, 'done' => $done, 'left' => max( 0, $total - $done ) ) );
	}

	/* ---------- settings page ---------- */

	public static function menu() {
		add_options_page( 'Photo Optimizer', 'Photo Optimizer', 'manage_options', 'mrsh-photos', array( __CLASS__, 'page' ) );
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) || ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'mrsh_img_save' ) ) {
			wp_die( 'Not allowed' );
		}
		update_option( self::OPT, array(
			'enabled'  => empty( $_POST['enabled'] ) ? 0 : 1,
			'max_edge' => isset( $_POST['max_edge'] ) ? (int) $_POST['max_edge'] : 1280,
			'quality'  => isset( $_POST['quality'] ) ? (int) $_POST['quality'] : 72,
			'webp'     => empty( $_POST['webp'] ) ? 0 : 1,
			'backup'   => empty( $_POST['backup'] ) ? 0 : 1,
		), false );
		wp_safe_redirect( admin_url( 'options-general.php?page=mrsh-photos&saved=1' ) );
		exit;
	}

	public static function clear_backup() {
		if ( ! current_user_can( 'manage_options' ) || ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'mrsh_img_clear' ) ) {
			wp_die( 'Not allowed' );
		}
		$bd = self::backup_dir();
		if ( is_dir( $bd ) ) {
			foreach ( (array) glob( $bd . '*' ) as $f ) {
				if ( is_file( $f ) ) {
					@unlink( $f );
				}
			}
		}
		wp_safe_redirect( admin_url( 'options-general.php?page=mrsh-photos&cleared=1' ) );
		exit;
	}

	private static function backup_size() {
		$bd = self::backup_dir();
		$n  = 0;
		if ( is_dir( $bd ) ) {
			foreach ( (array) glob( $bd . '*' ) as $f ) {
				if ( is_file( $f ) ) {
					$n += (int) filesize( $f );
				}
			}
		}
		return $n;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$o = self::opts();
		$s = get_option( self::SAVED, array( 'files' => 0, 'bytes' => 0 ) );
		list( $total, $done ) = self::counts();
		$webp = wp_image_editor_supports( array( 'mime_type' => 'image/webp' ) );
		$bk   = self::backup_size();
		$mb   = function ( $b ) { return number_format( $b / 1048576, 1 ) . ' MB'; };
		echo '<div class="wrap"><h1>Photo Optimizer</h1>';
		if ( ! empty( $_GET['saved'] ) ) {
			echo '<div class="notice notice-success"><p>Settings saved.</p></div>';
		}
		if ( ! empty( $_GET['cleared'] ) ) {
			echo '<div class="notice notice-success"><p>Backups deleted.</p></div>';
		}
		echo '<p>Makes photos small so the website and the app load fast. New photos are shrunk automatically. Photos already on the site can be shrunk with the button below.</p>';
		echo '<h2>Saved so far</h2><p><strong>' . esc_html( $mb( (int) $s['bytes'] ) ) . '</strong> saved across <strong>' . (int) $s['files'] . '</strong> photos.</p>';

		echo '<h2>Settings</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_img_save">';
		wp_nonce_field( 'mrsh_img_save' );
		echo '<table class="form-table">';
		echo '<tr><th>Shrink new photos automatically</th><td><label><input type="checkbox" name="enabled" value="1"' . checked( $o['enabled'], 1, false ) . '> On</label></td></tr>';
		echo '<tr><th>Longest side (pixels)</th><td><input type="number" name="max_edge" min="600" max="4000" step="10" value="' . (int) $o['max_edge'] . '"> <span class="description">1280 is sharp on every phone. Lower = smaller files.</span></td></tr>';
		echo '<tr><th>Quality (40 to 95)</th><td><input type="number" name="quality" min="40" max="95" value="' . (int) $o['quality'] . '"> <span class="description">72 is a good balance.</span></td></tr>';
		echo '<tr><th>Save new photos as WebP</th><td><label><input type="checkbox" name="webp" value="1"' . checked( $o['webp'], 1, false ) . '> Yes (smallest)</label> <span class="description">' . ( $webp ? 'This server supports WebP.' : 'This server cannot make WebP, so JPEG is used.' ) . '</span></td></tr>';
		echo '<tr><th>Keep a backup of old photos</th><td><label><input type="checkbox" name="backup" value="1"' . checked( $o['backup'], 1, false ) . '> Yes, before the bulk tool changes a photo</label></td></tr>';
		echo '</table><p><button class="button button-primary">Save settings</button></p></form>';

		echo '<h2>Shrink photos already on the site</h2>';
		echo '<p>JPEG photos in the Media Library: <strong>' . (int) $total . '</strong>. Already checked: <strong id="mrsh-done">' . (int) $done . '</strong>. Each photo keeps its name and address, so nothing on the website breaks. Photos that would only get a little smaller are left alone.</p>';
		echo '<p><button class="button button-primary" id="mrsh-run">Start shrinking</button> <button class="button" id="mrsh-stop" disabled>Pause</button></p>';
		echo '<div style="max-width:520px;background:#e5e5e5;border-radius:6px;height:14px;overflow:hidden"><div id="mrsh-bar" style="height:14px;width:' . ( $total ? (int) ( 100 * $done / $total ) : 0 ) . '%;background:#01411c"></div></div>';
		echo '<p id="mrsh-msg" class="description"></p>';

		echo '<h2>Backups</h2><p>Backup copies use <strong>' . esc_html( $mb( $bk ) ) . '</strong>. Once you have looked at the site and are happy, delete them to free the space.</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" onsubmit="return confirm(\'Delete all backup copies? This cannot be undone.\')"><input type="hidden" name="action" value="mrsh_img_clear_backup">';
		wp_nonce_field( 'mrsh_img_clear' );
		echo '<button class="button">Delete backups</button></form>';

		$ajax = esc_url_raw( admin_url( 'admin-ajax.php' ) );
		$n    = wp_create_nonce( 'mrsh_img_batch' );
		echo '<script>(function(){var run=document.getElementById("mrsh-run"),stop=document.getElementById("mrsh-stop"),bar=document.getElementById("mrsh-bar"),msg=document.getElementById("mrsh-msg"),done=document.getElementById("mrsh-done");var go=false,saved=0;
function step(){if(!go)return;var f=new FormData();f.append("action","mrsh_img_batch");f.append("n",' . wp_json_encode( $n ) . ');
fetch(' . wp_json_encode( $ajax ) . ',{method:"POST",body:f,credentials:"same-origin"}).then(function(r){return r.json()}).then(function(j){if(!j.success){msg.textContent="Stopped: "+(j.data||"error");finish();return}var d=j.data;saved+=d.saved;done.textContent=d.done;bar.style.width=(d.total?Math.round(100*d.done/d.total):100)+"%";msg.textContent="Saved "+(saved/1048576).toFixed(1)+" MB in this run. "+d.left+" photos left.";if(d.left>0&&d.processed>0){setTimeout(step,150)}else{msg.textContent+=" Finished.";finish()}}).catch(function(){msg.textContent="Connection problem. Press Start to continue.";finish()})}
function finish(){go=false;run.disabled=false;stop.disabled=true}
run.onclick=function(){go=true;run.disabled=true;stop.disabled=false;step()};stop.onclick=function(){finish();msg.textContent+=" Paused."};})();</script>';
		echo '</div>';
	}
}
