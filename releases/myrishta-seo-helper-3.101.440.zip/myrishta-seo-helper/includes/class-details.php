<?php
/**
 * Extra profile details that members add themselves: caste, study, work status, job, sector, city.
 * A member fills a short form on /profile-details/ ([mrsh_profile_details]).
 * The details are public on purpose (they are shown on the member's profile and in the My Rishta App),
 * so the form says so. No phone, address, income or ID is asked for here.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Details {

	const META      = '_mrsh_details';
	const TRANSIENT = 'mrsh_details_map';
	const POST_TYPE = 'listing_type';

	public static function fields() {
		return array(
			'education'   => array( 'Study (highest education)', 'select', array( 'Matric', 'Intermediate', 'Diploma', 'Bachelor', 'Master', 'MPhil / PhD', 'Madrasa / Dars-e-Nizami', 'Other' ) ),
			'caste'       => array( 'Caste / Biradri', 'text', array() ),
			'work_status' => array( 'Current status', 'select', array( 'Employed', 'Self-employed / Business', 'Studying', 'Looking for a job', 'Homemaker', 'Retired' ) ),
			'job_title'   => array( 'What is your job? (e.g. Teacher, Engineer, Shop owner)', 'text', array() ),
			'sector'      => array( 'Government or private?', 'select', array( 'Government', 'Semi-government', 'Private', 'Own business', 'Not working' ) ),
			'city'        => array( 'City', 'text', array() ),
		);
	}

	public static function init() {
		add_shortcode( 'mrsh_profile_details', array( __CLASS__, 'shortcode' ) );
		add_action( 'template_redirect', array( __CLASS__, 'handle' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'wp_footer', array( __CLASS__, 'script' ), 99 );
		add_filter( 'get_post_metadata', array( __CLASS__, 'phone_guard' ), 10, 4 );
	}

	/**
	 * The phone number field of a profile is private: only the member who owns the profile (and site admins)
	 * can read it. Everyone else gets an empty value, wherever the theme asks for it on the website.
	 */
	public static function phone_guard( $value, $post_id, $meta_key, $single ) {
		if ( ! in_array( $meta_key, array( 'custom-14', 'custom_14', 'custom14' ), true ) ) {
			return $value;
		}
		if ( is_admin() && ! wp_doing_ajax() ) {
			return $value; // wp-admin edit screens.
		}
		if ( current_user_can( 'manage_options' ) ) {
			return $value;
		}
		$post = get_post( (int) $post_id );
		if ( ! $post || self::POST_TYPE !== $post->post_type ) {
			return $value;
		}
		if ( is_user_logged_in() && (int) $post->post_author === get_current_user_id() ) {
			return $value;
		}
		return $single ? '' : array( '' );
	}

	public static function get( $user_id ) {
		$v = get_user_meta( $user_id, self::META, true );
		return is_array( $v ) ? $v : array();
	}

	public static function handle() {
		if ( empty( $_POST['mrsh_details_nonce'] ) || ! is_user_logged_in() ) {
			return;
		}
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['mrsh_details_nonce'] ) ), 'mrsh_details' ) ) {
			return;
		}
		$clean = array();
		foreach ( self::fields() as $k => $def ) {
			$raw = isset( $_POST[ 'mrsh_d_' . $k ] ) ? sanitize_text_field( wp_unslash( $_POST[ 'mrsh_d_' . $k ] ) ) : '';
			if ( 'select' === $def[1] ) {
				$raw = in_array( $raw, $def[2], true ) ? $raw : '';
			} else {
				$raw = function_exists( 'mb_substr' ) ? mb_substr( $raw, 0, 60 ) : substr( $raw, 0, 60 );
			}
			if ( '' !== $raw ) {
				$clean[ $k ] = $raw;
			}
		}
		update_user_meta( get_current_user_id(), self::META, $clean );
		delete_transient( self::TRANSIENT );
		wp_safe_redirect( add_query_arg( 'saved', '1', wp_get_referer() ? wp_get_referer() : home_url( '/profile-details/' ) ) );
		exit;
	}

	public static function shortcode() {
		if ( ! is_user_logged_in() ) {
			return '<p>Please <a href="' . esc_url( wp_login_url( get_permalink() ) ) . '">sign in</a> (or <a href="' . esc_url( wp_registration_url() ) . '">register free</a>) to add your details.</p>';
		}
		$cur = self::get( get_current_user_id() );
		$h   = '';
		if ( ! empty( $_GET['saved'] ) ) {
			$h .= '<p style="background:#e8f5ee;border:1px solid #0d6a3b;color:#01411c;padding:10px 14px;border-radius:10px"><strong>Saved.</strong> Your details will show on your profile and in the My Rishta App within a few minutes.</p>';
		}
		$h .= '<form method="post" style="max-width:520px">';
		$h .= wp_nonce_field( 'mrsh_details', 'mrsh_details_nonce', true, false );
		foreach ( self::fields() as $k => $def ) {
			$val = isset( $cur[ $k ] ) ? $cur[ $k ] : '';
			$h  .= '<p style="margin:0 0 14px"><label style="display:block;font-weight:600;margin-bottom:4px">' . esc_html( $def[0] ) . '</label>';
			if ( 'select' === $def[1] ) {
				$h .= '<select name="mrsh_d_' . esc_attr( $k ) . '" style="width:100%;padding:10px;border:1px solid #ccc;border-radius:8px"><option value="">— Prefer not to say —</option>';
				foreach ( $def[2] as $o ) {
					$h .= '<option value="' . esc_attr( $o ) . '"' . selected( $val, $o, false ) . '>' . esc_html( $o ) . '</option>';
				}
				$h .= '</select>';
			} else {
				$h .= '<input type="text" maxlength="60" name="mrsh_d_' . esc_attr( $k ) . '" value="' . esc_attr( $val ) . '" style="width:100%;padding:10px;border:1px solid #ccc;border-radius:8px">';
			}
			$h .= '</p>';
		}
		$h .= '<p style="font-size:13px;color:#555">These details are <strong>public</strong>: they show on your profile and in the My Rishta App. Leave any box empty to keep it private. Never write a phone number, address or bank detail here.</p>';
		$h .= '<p><button type="submit" style="background:#01411c;color:#f1deaa;border:0;border-radius:999px;padding:12px 28px;font-weight:700;cursor:pointer">Save my details</button></p></form>';
		return $h;
	}

	/** array( profile id => details ). Only members who filled something in and have a published profile. */
	public static function map() {
		$c = get_transient( self::TRANSIENT );
		if ( is_array( $c ) ) {
			return $c;
		}
		$out   = array();
		$users = get_users( array( 'meta_key' => self::META, 'fields' => 'ID', 'number' => 2000 ) );
		if ( $users ) {
			$posts = get_posts( array( 'post_type' => self::POST_TYPE, 'post_status' => 'publish', 'author__in' => array_map( 'intval', $users ), 'posts_per_page' => 3000, 'no_found_rows' => true ) );
			foreach ( $posts as $p ) {
				$d = self::get( (int) $p->post_author );
				if ( $d ) {
					$out[ (int) $p->ID ] = $d;
				}
			}
		}
		set_transient( self::TRANSIENT, $out, 5 * MINUTE_IN_SECONDS );
		return $out;
	}

	/** Public facts only, for the phone app: one small answer instead of opening every profile page. */
	private static $PUBLIC_META = array( 'daage', 'custom-15', 'custom-20', 'custom-2322', 'custom-24', 'featured' );

	public static function people() {
		$c = get_transient( 'mrsh_people' );
		if ( is_array( $c ) ) {
			return $c;
		}
		$posts = get_posts( array( 'post_type' => self::POST_TYPE, 'post_status' => 'publish', 'posts_per_page' => 300, 'orderby' => 'date', 'order' => 'DESC', 'no_found_rows' => true ) );
		$taxes = array_values( array_intersect( array( 'dagender', 'listing', 'country' ), get_object_taxonomies( self::POST_TYPE, 'names' ) ) ); // only what the app shows.
		$out   = array();
		// first attached photo of each profile (many profiles have no "featured image")
		$ids  = wp_list_pluck( $posts, 'ID' );
		$pics = array();
		if ( $ids ) {
			$att = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'post_mime_type' => 'image', 'post_parent__in' => $ids, 'posts_per_page' => 900, 'orderby' => 'menu_order ID', 'order' => 'ASC', 'no_found_rows' => true ) );
			foreach ( $att as $a ) {
				if ( ! isset( $pics[ $a->post_parent ] ) ) {
					$u = wp_get_attachment_image_url( $a->ID, 'medium' );
					if ( $u ) {
						$pics[ $a->post_parent ] = $u;
					}
				}
			}
		}
		foreach ( $posts as $p ) {
			$row = array( 'id' => (int) $p->ID, 'slug' => $p->post_name, 'title' => get_the_title( $p ), 'link' => get_permalink( $p ), 'thumb' => (string) ( get_the_post_thumbnail_url( $p, 'medium' ) ?: ( isset( $pics[ $p->ID ] ) ? $pics[ $p->ID ] : '' ) ), 'city' => '', 'country' => '', 'tax' => array(), 'meta' => array() );
			foreach ( $taxes as $tx ) {
				$terms = get_the_terms( $p->ID, $tx );
				if ( $terms && ! is_wp_error( $terms ) && 'country' === $tx ) {
					foreach ( $terms as $x ) { // country is a tree: country > city
						if ( 0 === (int) $x->parent ) {
							$row['country'] = $x->name;
						} else {
							$row['city'] = $x->name;
						}
					}
				}
				if ( $terms && ! is_wp_error( $terms ) ) {
					$row['tax'][ $tx ] = array_values( array_map( function ( $x ) { return $x->name; }, $terms ) );
				}
			}
			foreach ( self::$PUBLIC_META as $k ) {
				$v = get_post_meta( $p->ID, $k, true );
				if ( is_string( $v ) && '' !== $v && strlen( $v ) < 80 ) {
					$row['meta'][ $k ] = $v;
				}
			}
			$row['tax']  = (object) $row['tax'];
			$row['meta'] = (object) $row['meta'];
			$out[]       = $row;
		}
		set_transient( 'mrsh_people', $out, 5 * MINUTE_IN_SECONDS );
		return $out;
	}

	public static function routes() {
		register_rest_route( 'mrsh/v1', '/people', array(
			'methods'             => 'GET',
			'permission_callback' => '__return_true',
			'callback'            => function () {
				$r = new WP_REST_Response( self::people() );
				$r->header( 'Cache-Control', 'public, max-age=300' );
				return $r;
			},
		) );
		register_rest_route( 'mrsh/v1', '/details', array(
			'methods'             => 'GET',
			'permission_callback' => '__return_true',
			'callback'            => function () {
				$r = new WP_REST_Response( (object) self::map() );
				$r->header( 'Cache-Control', 'public, max-age=300' );
				return $r;
			},
		) );
	}

	/** Show the details on the member's own profile page on the website. */
	public static function script() {
		if ( is_admin() || ! is_singular( self::POST_TYPE ) ) {
			return;
		}
		$id = (int) get_queried_object_id();
		$d  = isset( self::map()[ $id ] ) ? self::map()[ $id ] : array();
		if ( ! $d ) {
			return;
		}
		$labels = array( 'education' => 'Study', 'caste' => 'Caste', 'work_status' => 'Status', 'job_title' => 'Job', 'sector' => 'Sector', 'city' => 'City' );
		$rows   = '';
		foreach ( $labels as $k => $l ) {
			if ( ! empty( $d[ $k ] ) ) {
				$rows .= '<li style="display:flex;gap:12px;padding:4px 0"><span style="width:90px;opacity:.7">' . esc_html( $l ) . '</span><span>' . esc_html( $d[ $k ] ) . '</span></li>';
			}
		}
		if ( ! $rows ) {
			return;
		}
		$html = '<div class="mrsh-det" style="margin:10px 0;padding:12px 16px;border:1px solid #0d6a3b33;border-radius:12px;background:#f4faf6"><strong style="color:#01411c">Education &amp; Work</strong><ul style="list-style:none;margin:6px 0 0;padding:0">' . $rows . '</ul></div>';
		echo '<script id="mrsh-det-js">(function(){var d=document,h=d.querySelector(".mrsh-vb-single")||d.querySelector("h1.fs-lg")||d.querySelector("h1");if(!h||d.querySelector(".mrsh-det"))return;h.insertAdjacentHTML("afterend",' . wp_json_encode( $html ) . ')})();</script>' . "\n";
	}
}
