<?php
/**
 * Speed Tools: page cache, junk cleaner, image compressor and CDN rewrite.
 * Every tool is off or preview-only until the administrator uses it.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Tools {

	const CAP = 'manage_options';

	/* ---------- boot ---------- */

	/** Runs very early so cached pages skip most of WordPress. */
	public static function early() {
		$o = MRSH_Options::get();
		if ( ! empty( $o['cache_enabled'] ) ) {
			self::serve();
		}
	}

	public static function init() {
		$o = MRSH_Options::get();
		add_action( 'init', array( __CLASS__, 'ads_txt' ), 0 );
		add_action( 'admin_post_mrsh_junk_clean', array( __CLASS__, 'handle_junk' ) );
		add_action( 'admin_post_mrsh_cache_purge', array( __CLASS__, 'handle_purge' ) );
		add_action( 'admin_post_mrsh_cdn_check', array( __CLASS__, 'handle_cdn_check' ) );
		add_action( 'admin_post_mrsh_img_batch', array( __CLASS__, 'handle_img_batch' ) );
		if ( ! empty( $o['cache_enabled'] ) ) {
			add_action( 'template_redirect', array( __CLASS__, 'start_cache' ), 2 );
			foreach ( array( 'save_post', 'deleted_post', 'comment_post', 'switch_theme', 'wp_update_nav_menu', 'update_option_mrsh_options' ) as $h ) {
				add_action( $h, array( __CLASS__, 'purge_all' ) );
			}
		}
		if ( ! empty( $o['img_compress'] ) ) {
			add_filter( 'wp_editor_set_quality', array( __CLASS__, 'quality' ), 20 );
			add_filter( 'big_image_size_threshold', array( __CLASS__, 'threshold' ), 20 );
			add_filter( 'wp_generate_attachment_metadata', array( __CLASS__, 'on_upload' ), 20, 2 );
		}
		if ( '' !== $o['cdn_url'] && ! is_admin() ) {
			add_filter( 'wp_get_attachment_url', array( __CLASS__, 'cdn_url' ), 20 );
			add_action( 'template_redirect', array( __CLASS__, 'start_cdn' ), 3 );
		}
	}

	/* ---------- AdSense ---------- */

	/** Serve /ads.txt so Google (and other ad buyers) can verify who may sell your ad space. */
	public static function ads_txt() {
		$path = isset( $_SERVER['REQUEST_URI'] ) ? strtolower( (string) strtok( (string) $_SERVER['REQUEST_URI'], '?' ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( '/ads.txt' !== $path ) {
			return;
		}
		$body = self::ads_txt_body();
		if ( '' === $body ) {
			return;
		}
		status_header( 200 );
		header( 'Content-Type: text/plain; charset=utf-8' );
		header( 'Cache-Control: public, max-age=3600' );
		echo $body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	public static function ads_txt_body() {
		$o     = MRSH_Options::get();
		$lines = array();
		if ( '' !== $o['adsense_pub'] ) {
			$lines[] = 'google.com, ' . $o['adsense_pub'] . ', DIRECT, f08c47fec0942fa0';
		}
		foreach ( MRSH_Options::lines( $o['adstxt_extra'] ) as $l ) {
			$l     = trim( $l );
			$parts = array_map( 'trim', explode( ',', $l ) );
			// Skip placeholder entries (all-zero IDs) and anything that is not "domain, id, DIRECT|RESELLER".
			if ( count( $parts ) < 3 || '' === $parts[1] || preg_match( '/^0+$/', $parts[1] ) || ! preg_match( '/^(DIRECT|RESELLER)$/i', $parts[2] ) ) {
				continue;
			}
			$lines[] = $l;
		}
		$lines = array_values( array_unique( $lines ) );
		return $lines ? implode( "\n", $lines ) . "\n" : '';
	}

	/** Things AdSense reviewers look for before approving a site. */
	public static function adsense_checks() {
		$out  = array();
		$find = function ( $slugs ) {
			foreach ( $slugs as $sl ) {
				$p = get_page_by_path( $sl );
				if ( $p && 'publish' === $p->post_status ) {
					return true;
				}
			}
			return false;
		};
		$out[] = array( 'Privacy Policy page', $find( array( 'privacy-policy', 'privacy', 'privacy-policy-2' ) ), 'Required by AdSense. Publish a page at /privacy-policy/.' );
		$out[] = array( 'About page', $find( array( 'about-us', 'about' ) ), 'Shows real people or a real service stands behind the site.' );
		$out[] = array( 'Contact page', $find( array( 'contact', 'contact-us' ) ), 'A working contact page with real details.' );
		$out[] = array( 'Terms page', $find( array( 'terms-and-conditions', 'terms', 'terms-of-service', 'terms-conditions' ) ), 'Helpful for a matrimonial site.' );
		$out[] = array( 'Publisher ID saved for ads.txt', '' !== MRSH_Options::get()['adsense_pub'], 'Enter your pub-… number below. ads.txt is then served at /ads.txt.' );
		$posts = wp_count_posts( 'post' );
		$out[] = array( 'At least 10 published articles', isset( $posts->publish ) && (int) $posts->publish >= 10, 'AdSense approves sites with enough original content. Publish helpful guides.' );
		return $out;
	}

	/* ---------- page cache ---------- */

	public static function cache_dir() {
		return WP_CONTENT_DIR . '/cache/mrsh/';
	}

	private static function cache_file() {
		$host = isset( $_SERVER['HTTP_HOST'] ) ? preg_replace( '/[^a-z0-9.\-]/i', '', (string) $_SERVER['HTTP_HOST'] ) : 'site'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '/'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$mob  = ( isset( $_SERVER['HTTP_USER_AGENT'] ) && preg_match( '/Mobile|Android|iPhone/i', (string) $_SERVER['HTTP_USER_AGENT'] ) ) ? 'm' : 'd'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		return self::cache_dir() . $host . '-' . $mob . '-' . md5( $uri ) . '.html';
	}

	/** Can this request be cached at all? */
	public static function cacheable() {
		if ( 'GET' !== ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' ) || ! empty( $_SERVER['QUERY_STRING'] ) ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			return false;
		}
		foreach ( $_COOKIE as $k => $v ) { // phpcs:ignore WordPress.Security.NonceVerification
			if ( preg_match( '/^(wordpress_logged_in|wp-postpass|comment_author|woocommerce_items_in_cart|wordpress_sec)/', $k ) ) {
				return false;
			}
		}
		if ( defined( 'DOING_AJAX' ) || defined( 'REST_REQUEST' ) || defined( 'DONOTCACHEPAGE' ) ) {
			return false;
		}
		$path = strtolower( trim( (string) strtok( isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '/', '?' ), '/' ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( preg_match( '/\.(xml|xsl|txt|json|php)$/', $path ) ) {
			return false;
		}
		foreach ( MRSH_Options::to_list( MRSH_Options::get()['cache_exclude'] ) as $ex ) {
			if ( '' !== $ex && ( $path === $ex || 0 === strpos( $path, $ex . '/' ) || false !== strpos( '/' . $path . '/', '/' . $ex . '/' ) ) ) {
				return false;
			}
		}
		return true;
	}

	public static function serve() {
		if ( ! self::cacheable() ) {
			return;
		}
		$file = self::cache_file();
		$ttl  = max( 1, (int) MRSH_Options::get()['cache_ttl'] ) * HOUR_IN_SECONDS;
		if ( is_readable( $file ) && ( time() - filemtime( $file ) ) < $ttl ) {
			header( 'X-MRSH-Cache: HIT' );
			header( 'Content-Type: text/html; charset=UTF-8' );
			readfile( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			exit;
		}
	}

	public static function start_cache() {
		if ( is_admin() || is_404() || is_search() || is_feed() || is_robots() || is_user_logged_in() || is_preview() || ! self::cacheable() ) {
			return;
		}
		ob_start( array( __CLASS__, 'store' ) );
	}

	public static function store( $html ) {
		if ( ! is_string( $html ) || strlen( $html ) < 500 || 200 !== http_response_code() || false === stripos( $html, '</html>' ) ) {
			return $html;
		}
		if ( false !== stripos( $html, '_wpnonce' ) || false !== stripos( $html, 'wp_nonce' ) || false !== stripos( $html, 'name="_wp_http_referer"' ) ) {
			return $html; // pages with security tokens must stay live.
		}
		$dir = self::cache_dir();
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
			@file_put_contents( $dir . 'index.html', '' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			@file_put_contents( $dir . '.htaccess', "Require all denied\n" ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		}
		@file_put_contents( self::cache_file(), $html . "\n<!-- cached by MyRishta SEO Helper -->", LOCK_EX ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		return $html;
	}

	public static function purge_all() {
		$n = 0;
		foreach ( (array) glob( self::cache_dir() . '*.html' ) as $f ) {
			if ( is_file( $f ) && 'index.html' !== basename( $f ) && @unlink( $f ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors,WordPress.WP.AlternativeFunctions
				++$n;
			}
		}
		return $n;
	}

	public static function cache_stats() {
		$files = array_filter( (array) glob( self::cache_dir() . '*.html' ), function ( $f ) {
			return 'index.html' !== basename( $f );
		} );
		$size = 0;
		foreach ( $files as $f ) {
			$size += (int) filesize( $f );
		}
		return array( count( $files ), $size );
	}

	/* ---------- junk cleaner ---------- */

	public static function junk_items() {
		global $wpdb;
		return array(
			'revisions'  => array( 'Post revisions', "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='revision'" ),
			'autodrafts' => array( 'Auto drafts', "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status='auto-draft'" ),
			'trash'      => array( 'Posts in trash', "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_status='trash'" ),
			'spam'       => array( 'Spam and trashed comments', "SELECT COUNT(*) FROM {$wpdb->comments} WHERE comment_approved IN ('spam','trash')" ),
			'transients' => array( 'Expired transients', "SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_timeout\\_%' AND option_value < UNIX_TIMESTAMP()" ),
			'postmeta'   => array( 'Orphan post meta', "SELECT COUNT(*) FROM {$wpdb->postmeta} pm LEFT JOIN {$wpdb->posts} p ON p.ID=pm.post_id WHERE p.ID IS NULL" ),
			'commmeta'   => array( 'Orphan comment meta', "SELECT COUNT(*) FROM {$wpdb->commentmeta} cm LEFT JOIN {$wpdb->comments} c ON c.comment_ID=cm.comment_id WHERE c.comment_ID IS NULL" ),
			'oembed'     => array( 'Cached embeds', "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key LIKE '\\_oembed\\_%'" ),
		);
	}

	public static function junk_count( $key ) {
		global $wpdb;
		$items = self::junk_items();
		return isset( $items[ $key ] ) ? (int) $wpdb->get_var( $items[ $key ][1] ) : 0; // phpcs:ignore WordPress.DB
	}

	public static function junk_clean( $key ) {
		global $wpdb;
		$n = 0;
		switch ( $key ) {
			case 'revisions':
				foreach ( (array) $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE post_type='revision' LIMIT 2000" ) as $id ) { // phpcs:ignore WordPress.DB
					wp_delete_post_revision( (int) $id ) && ++$n;
				}
				break;
			case 'autodrafts':
				foreach ( (array) $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE post_status='auto-draft' LIMIT 2000" ) as $id ) { // phpcs:ignore WordPress.DB
					wp_delete_post( (int) $id, true ) && ++$n;
				}
				break;
			case 'trash':
				foreach ( (array) $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE post_status='trash' LIMIT 1000" ) as $id ) { // phpcs:ignore WordPress.DB
					wp_delete_post( (int) $id, true ) && ++$n;
				}
				break;
			case 'spam':
				foreach ( (array) $wpdb->get_col( "SELECT comment_ID FROM {$wpdb->comments} WHERE comment_approved IN ('spam','trash') LIMIT 2000" ) as $id ) { // phpcs:ignore WordPress.DB
					wp_delete_comment( (int) $id, true ) && ++$n;
				}
				break;
			case 'transients':
				foreach ( (array) $wpdb->get_col( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_timeout\\_%' AND option_value < UNIX_TIMESTAMP() LIMIT 2000" ) as $name ) { // phpcs:ignore WordPress.DB
					$base = str_replace( '_transient_timeout_', '', $name );
					delete_transient( $base ) && ++$n;
					delete_option( $name );
				}
				break;
			case 'postmeta':
				$n = (int) $wpdb->query( "DELETE pm FROM {$wpdb->postmeta} pm LEFT JOIN {$wpdb->posts} p ON p.ID=pm.post_id WHERE p.ID IS NULL" ); // phpcs:ignore WordPress.DB
				break;
			case 'commmeta':
				$n = (int) $wpdb->query( "DELETE cm FROM {$wpdb->commentmeta} cm LEFT JOIN {$wpdb->comments} c ON c.comment_ID=cm.comment_id WHERE c.comment_ID IS NULL" ); // phpcs:ignore WordPress.DB
				break;
			case 'oembed':
				$n = (int) $wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE '\\_oembed\\_%'" ); // phpcs:ignore WordPress.DB
				break;
		}
		return $n;
	}

	/* ---------- image compressor ---------- */

	public static function quality() {
		return (int) MRSH_Options::get()['img_quality'];
	}

	public static function threshold() {
		return (int) MRSH_Options::get()['img_max'];
	}

	/** Re-save the generated sizes at the chosen quality (originals are never rewritten here). */
	public static function on_upload( $meta, $id ) {
		self::shrink_sizes( $meta, $id );
		return $meta;
	}

	public static function shrink_sizes( $meta, $id ) {
		$saved = 0;
		$file  = get_attached_file( $id );
		if ( ! $file ) {
			return 0;
		}
		$meta['sizes'] = empty( $meta['sizes'] ) ? array() : $meta['sizes'];
		$dir = dirname( $file ) . '/';
		foreach ( $meta['sizes'] as $s ) {
			if ( empty( $s['file'] ) || ! preg_match( '/\.(jpe?g|png|webp)$/i', $s['file'] ) ) {
				continue;
			}
			$path = $dir . $s['file'];
			if ( ! is_writable( $path ) ) {
				continue;
			}
			$before = filesize( $path );
			$ed     = wp_get_image_editor( $path );
			if ( is_wp_error( $ed ) ) {
				continue;
			}
			$ed->set_quality( self::quality() );
			$tmp = $path . '.mrsh';
			$res = $ed->save( $tmp, wp_check_filetype( $path )['type'] );
			if ( ! is_wp_error( $res ) && file_exists( $tmp ) ) {
				if ( filesize( $tmp ) < $before ) {
					$saved += $before - filesize( $tmp );
					rename( $tmp, $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				} else {
					unlink( $tmp ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				}
			} elseif ( file_exists( $tmp ) ) {
				unlink( $tmp ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			}
		}
		// WebP copies (original and every size) next to the files; pages use them when present.
		self::make_webp( $file );
		foreach ( $meta['sizes'] as $s ) {
			if ( ! empty( $s['file'] ) ) {
				self::make_webp( $dir . $s['file'] );
			}
		}
		update_post_meta( $id, '_mrsh_compressed', 2 );
		return $saved;
	}

	/** Write FILE.webp when it is smaller than the source. */
	public static function make_webp( $path ) {
		if ( ! preg_match( '/\.(jpe?g|png)$/i', $path ) || ! file_exists( $path ) || file_exists( $path . '.webp' ) ) {
			return false;
		}
		if ( ! wp_image_editor_supports( array( 'mime_type' => 'image/webp' ) ) ) {
			return false;
		}
		$ed = wp_get_image_editor( $path );
		if ( is_wp_error( $ed ) ) {
			return false;
		}
		$ed->set_quality( 80 );
		$res = $ed->save( $path . '.webp', 'image/webp' );
		if ( is_wp_error( $res ) || ! file_exists( $path . '.webp' ) ) {
			return false;
		}
		if ( filesize( $path . '.webp' ) >= filesize( $path ) ) {
			unlink( $path . '.webp' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			return false;
		}
		return true;
	}

	public static function img_pending() {
		$q = new WP_Query( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'post_mime_type' => array( 'image/jpeg', 'image/png' ), 'posts_per_page' => 1, 'fields' => 'ids', 'meta_query' => array( 'relation' => 'OR', array( 'key' => '_mrsh_compressed', 'compare' => 'NOT EXISTS' ), array( 'key' => '_mrsh_compressed', 'value' => '2', 'compare' => '!=' ) ) ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		return (int) $q->found_posts;
	}

	/* ---------- CDN ---------- */

	public static function cdn_url( $url ) {
		return self::cdn_swap( $url );
	}

	public static function cdn_swap( $html ) {
		$o    = MRSH_Options::get();
		$cdn  = $o['cdn_url'];
		$home = untrailingslashit( home_url() );
		if ( '' === $cdn || ! is_string( $html ) ) {
			return $html;
		}
		$up   = wp_get_upload_dir();
		$bases = array( $up['baseurl'] );
		if ( ! empty( $o['cdn_themes'] ) ) {
			$bases[] = content_url( 'themes' );
			$bases[] = content_url( 'plugins' );
			$bases[] = $home . '/wp-includes';
		}
		foreach ( $bases as $b ) {
			if ( 0 === strpos( $b, $home ) ) {
				$html = str_replace( $b, $cdn . substr( $b, strlen( $home ) ), $html );
			}
		}
		return $html;
	}

	public static function start_cdn() {
		if ( is_admin() || is_feed() || is_robots() || is_customize_preview() || isset( $_GET['elementor-preview'] ) || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		$path = isset( $_SERVER['REQUEST_URI'] ) ? strtok( (string) wp_unslash( $_SERVER['REQUEST_URI'] ), '?' ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( preg_match( '/\.(xml|xsl|txt|json)$/i', $path ) ) {
			return;
		}
		ob_start( array( __CLASS__, 'cdn_page' ) );
	}

	/** Only the page body is rewritten; canonical, OG and schema URLs stay on the real domain. */
	public static function cdn_page( $html ) {
		if ( ! is_string( $html ) || false === ( $pos = stripos( $html, '<body' ) ) ) { // phpcs:ignore Squiz.PHP.DisallowMultipleAssignments
			return $html;
		}
		$head = substr( $html, 0, $pos );
		$head = preg_replace_callback( '/<link\b[^>]*rel=["\']?stylesheet[^>]*>|<script\b[^>]*\ssrc=[^>]*>/i', function ( $m ) {
			return self::cdn_swap( $m[0] );
		}, $head );
		return $head . self::cdn_swap( substr( $html, $pos ) );
	}

	/* ---------- handlers ---------- */

	private static function guard( $action ) {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'Not allowed.', 'myrishta-seo-helper' ), 403 );
		}
		check_admin_referer( $action );
	}

	private static function back( $note ) {
		wp_safe_redirect( add_query_arg( 'mrsh_note', rawurlencode( $note ), MRSH_Admin::url( 'myrishta-seo-tools' ) ) );
		exit;
	}

	public static function handle_junk() {
		self::guard( 'mrsh_junk_clean' );
		$items = self::junk_items();
		$what  = isset( $_POST['what'] ) ? sanitize_key( wp_unslash( $_POST['what'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$total = 0;
		if ( 'all' === $what ) {
			foreach ( array_keys( $items ) as $k ) {
				$total += self::junk_clean( $k );
			}
		} elseif ( isset( $items[ $what ] ) ) {
			$total = self::junk_clean( $what );
		}
		self::back( 'Removed ' . $total . ' junk items.' );
	}

	public static function handle_purge() {
		self::guard( 'mrsh_cache_purge' );
		self::back( 'Cache cleared: ' . self::purge_all() . ' pages removed.' );
	}

	/** Looks at the site from outside: which CDN is in front, and are static files really served from its cache? */
	public static function handle_cdn_check() {
		self::guard( 'mrsh_cdn_check' );
		$home = home_url( '/' );
		$r    = wp_remote_get( $home, array( 'timeout' => 15, 'redirection' => 3 ) );
		$urls = array();
		if ( ! is_wp_error( $r ) ) {
			$host = wp_parse_url( $home, PHP_URL_HOST );
			if ( preg_match_all( '#(?:src|href)=["\'](https?://' . preg_quote( (string) $host, '#' ) . '/wp-content/[^"\'?\s]+\.(?:css|js|png|jpe?g|webp|svg|woff2))#i', (string) wp_remote_retrieve_body( $r ), $m ) ) {
				$by = array();
				foreach ( array_unique( $m[1] ) as $u ) {
					$ext = strtolower( pathinfo( $u, PATHINFO_EXTENSION ) );
					$grp = in_array( $ext, array( 'css' ), true ) ? 'css' : ( 'js' === $ext ? 'js' : ( 'woff2' === $ext ? 'font' : 'img' ) );
					if ( count( $by[ $grp ] ?? array() ) < 2 ) {
						$by[ $grp ][] = $u;
					}
				}
				foreach ( $by as $list ) {
					$urls = array_merge( $urls, $list );
				}
				$urls = array_slice( $urls, 0, 7 );
			}
		}
		$out = array( 'time' => time(), 'rows' => array(), 'err' => is_wp_error( $r ) ? $r->get_error_message() : '' );
		foreach ( $urls as $u ) {
			wp_remote_get( $u, array( 'timeout' => 10 ) ); // fetch once so an edge stores a copy.
			// A CDN has many edge servers, each with its own copy, so ask up to 6 times and keep the best answer.
			$h  = null;
			$ms = 0;
			for ( $i = 0; $i < 6; $i++ ) {
				$t0 = microtime( true );
				$try = wp_remote_head( $u, array( 'timeout' => 10 ) );
				$tm  = (int) round( ( microtime( true ) - $t0 ) * 1000 );
				if ( is_wp_error( $try ) ) {
					$h = $h ?: $try;
					continue;
				}
				$st = strtolower( (string) ( wp_remote_retrieve_header( $try, 'x-hcdn-cache-status' ) ?: ( wp_remote_retrieve_header( $try, 'cf-cache-status' ) ?: wp_remote_retrieve_header( $try, 'x-cache' ) ) ) );
				if ( null === $h || is_wp_error( $h ) || false !== strpos( $st, 'hit' ) ) {
					$h  = $try;
					$ms = $tm;
				}
				if ( false !== strpos( $st, 'hit' ) ) {
					break;
				}
			}
			if ( is_wp_error( $h ) || null === $h ) {
				$out['rows'][] = array( 'url' => $u, 'who' => '', 'state' => 'error', 'ms' => $ms );
				continue;
			}
			$g     = function ( $k ) use ( $h ) {
				return strtolower( (string) wp_remote_retrieve_header( $h, $k ) );
			};
			$state = $g( 'x-hcdn-cache-status' ) ?: ( $g( 'cf-cache-status' ) ?: ( $g( 'x-cache' ) ?: ( $g( 'x-bunny-cache-state' ) ?: '' ) ) );
			$who   = $g( 'cf-ray' ) ? 'Cloudflare' : ( $g( 'x-hcdn-request-id' ) ? 'Hostinger CDN' : ( $g( 'x-bunny-cache-state' ) || $g( 'cdn-pullzone' ) ? 'Bunny' : ( $g( 'server' ) ?: 'none' ) ) );
			$out['rows'][] = array( 'url' => $u, 'who' => $who, 'state' => $state ?: 'unknown', 'ms' => $ms );
		}
		set_transient( 'mrsh_cdn_check', $out, DAY_IN_SECONDS );
		self::back( $out['rows'] ? 'CDN check finished. See the result in the CDN box.' : 'Could not read any files from the site. ' . $out['err'] );
	}

	public static function handle_img_batch() {
		self::guard( 'mrsh_img_batch' );
		$q     = new WP_Query( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'post_mime_type' => array( 'image/jpeg', 'image/png' ), 'posts_per_page' => 15, 'fields' => 'ids', 'meta_query' => array( 'relation' => 'OR', array( 'key' => '_mrsh_compressed', 'compare' => 'NOT EXISTS' ), array( 'key' => '_mrsh_compressed', 'value' => '2', 'compare' => '!=' ) ) ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		$saved = 0;
		foreach ( $q->posts as $id ) {
			$saved += self::shrink_sizes( wp_get_attachment_metadata( $id ), $id );
		}
		self::back( 'Compressed ' . count( $q->posts ) . ' images, saved ' . size_format( $saved ) . '. ' . self::img_pending() . ' left.' );
	}

	/* ---------- admin page ---------- */

	public static function page() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		$o = MRSH_Options::get();
		MRSH_Admin::open( 'Speed Tools', 'Page cache, junk cleaner, image compressor and CDN. Each is optional.' );
		if ( ! empty( $_GET['mrsh_note'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="notice notice-success"><p>' . esc_html( rawurldecode( wp_unslash( $_GET['mrsh_note'] ) ) ) . '</p></div>'; // phpcs:ignore WordPress.Security.NonceVerification,WordPress.Security.ValidatedSanitizedInput
		}
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Junk cleaner</h2></div><p class="mrsh-muted">Back up the database first. Cleaning permanently deletes these items.</p><table class="widefat striped"><thead><tr><th>Item</th><th>Found</th></tr></thead><tbody>';
		foreach ( self::junk_items() as $k => $it ) {
			echo '<tr><td>' . esc_html( $it[0] ) . '</td><td>' . esc_html( number_format_i18n( self::junk_count( $k ) ) ) . '</td></tr>';
		}
		echo '</tbody></table><p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="mrsh-inline"><input type="hidden" name="action" value="mrsh_junk_clean"><input type="hidden" name="what" value="all">';
		wp_nonce_field( 'mrsh_junk_clean' );
		echo '<button class="button button-primary" onclick="return confirm(\'Delete all junk listed above?\')">Clean all junk</button></form></p></div>';

		list( $n, $size ) = self::cache_stats();
		echo '<form method="post" action="options.php">';
		settings_fields( 'mrsh_group' );
		echo '<input type="hidden" name="' . esc_attr( MRSH_Options::KEY ) . '[_section]" value="tools">';
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Page cache</h2></div><p class="mrsh-muted">Saves a finished copy of each public page for visitors who are not logged in. Pages with forms, logins, carts and member areas are never cached. ' . esc_html( $n ) . ' pages stored (' . esc_html( size_format( $size ) ) . '). If your host already caches pages, keep this off.</p><table class="form-table" role="presentation">';
		MRSH_Admin::field_check( 'cache_enabled', 'Turn on page cache', 'Visitors get saved pages; changes to posts, menus and settings clear the cache automatically' );
		MRSH_Admin::field_text( 'cache_ttl', 'Keep pages for (hours)', '1 to 168. Default 6.' );
		MRSH_Admin::field_text( 'cache_exclude', 'Never cache these paths', 'Comma separated page slugs.' );
		echo '</table></div>';
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Google AdSense</h2></div><p class="mrsh-muted">Your ads code is already added by Site Kit. Google decides where automatic ads appear, set under AdSense → Ads → By site → Auto ads. This tool adds the ads.txt file AdSense asks for, and checks what the AdSense review looks for.</p><table class="widefat striped"><tbody>';
		foreach ( self::adsense_checks() as $c ) {
			echo '<tr><td>' . esc_html( $c[0] ) . '</td><td>' . ( $c[1] ? 'Done' : 'Missing: ' . esc_html( $c[2] ) ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		echo '</tbody></table><table class="form-table" role="presentation">';
		MRSH_Admin::field_text( 'adsense_pub', 'AdSense publisher ID', 'From AdSense → Account → Account information. Looks like pub-1234567890123456. Enables /ads.txt.' );
		MRSH_Admin::field_area( 'adstxt_extra', 'Extra ads.txt lines', 'One per line, for other ad networks. Format: domain, ID, DIRECT.' );
		echo '</table></div>';
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Image compressor</h2></div><p class="mrsh-muted">Smaller image files load faster. Only the resized copies are recompressed; your original uploads are never overwritten. ' . esc_html( self::img_pending() ) . ' images not processed yet.</p><table class="form-table" role="presentation">';
		MRSH_Admin::field_check( 'img_compress', 'Compress new uploads', 'Recompress each new image and cap very large photos' );
		MRSH_Admin::field_text( 'img_quality', 'Quality (50 to 95)', 'Default 82 looks the same to the eye and saves about a third.' );
		MRSH_Admin::field_text( 'img_max', 'Largest side in pixels', 'Photos bigger than this are scaled down on upload. Default 1200.' );
		echo '</table></div>';
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>CDN</h2></div><p class="mrsh-muted">Serves images, styles and scripts from a CDN address. You must first create a CDN (for example a Cloudflare, Bunny or Hostinger CDN zone that pulls from myrishta.pk), then paste its https address here. Leave empty to keep everything on your own server.</p><table class="form-table" role="presentation">';
		MRSH_Admin::field_text( 'cdn_url', 'CDN address', 'Example: https://cdn.myrishta.pk (https only)' );
		MRSH_Admin::field_check( 'cdn_themes', 'Also theme, plugin and core files', 'Not only uploads' );
		echo '</table>';
		$ck = get_transient( 'mrsh_cdn_check' );
		if ( is_array( $ck ) && ! empty( $ck['rows'] ) ) {
			$hit = 0;
			$byp = 0;
			$who = '';
			foreach ( $ck['rows'] as $row ) {
				$hit += ( false !== strpos( $row['state'], 'hit' ) ) ? 1 : 0;
				$byp += ( false !== strpos( $row['state'], 'bypass' ) || false !== strpos( $row['state'], 'dynamic' ) ) ? 1 : 0;
				$who  = $who ?: $row['who'];
			}
			$tot = count( $ck['rows'] );
			if ( $hit === $tot ) {
				$msg = 'Good. ' . $who . ' is serving all checked files from its cache. You do not need the CDN address box.';
				$col = '#047857';
			} elseif ( $hit > 0 && 0 === $byp ) {
				$msg = 'Working. ' . $who . ' is caching your files (' . $hit . ' of ' . $tot . ' already served from cache). MISS means a file was just stored and will be a HIT on the next visit. Run the check again in a minute to confirm.';
				$col = '#047857';
			} elseif ( $byp > 0 && ( 'Hostinger CDN' === $who || 'Cloudflare' === $who ) ) {
				$msg = $who . ' is in front of the site but is skipping its cache (BYPASS). In Hostinger hPanel open CDN and switch Development mode OFF, press Flush cache, then run this check again.';
				$col = '#b45309';
			} elseif ( 'Hostinger CDN' === $who || 'Cloudflare' === $who ) {
				$msg = $who . ' is caching (no BYPASS), but these files were not stored on the edge servers tried yet. Each edge server stores its own copy after its first visitor, so this is normal right after a cache flush. Run the check again in a few minutes.';
				$col = '#b45309';
			} else {
				$msg = 'No CDN was found in front of the site. Files come straight from the server.';
				$col = '#b91c1c';
			}
			echo '<div class="mrsh-card" style="margin:14px 0 0;border-left:5px solid ' . esc_attr( $col ) . '"><b style="color:' . esc_attr( $col ) . '">' . esc_html( $msg ) . '</b><table class="widefat striped" style="margin-top:10px;max-width:880px"><thead><tr><th>File</th><th>Served by</th><th>Cache</th><th>Time</th></tr></thead><tbody>';
			foreach ( $ck['rows'] as $row ) {
				echo '<tr><td style="word-break:break-all">' . esc_html( preg_replace( '#^https?://[^/]+#', '', $row['url'] ) ) . '</td><td>' . esc_html( $row['who'] ) . '</td><td>' . esc_html( strtoupper( $row['state'] ) ) . '</td><td>' . (int) $row['ms'] . ' ms</td></tr>';
			}
			echo '</tbody></table><p class="mrsh-muted" style="margin:8px 0 0">Checked ' . esc_html( wp_date( 'j M H:i', (int) $ck['time'] ) ) . '. The time is measured from the server, not from a visitor.</p></div>';
		}
		echo '<p class="mrsh-muted" style="margin:12px 0 0">Not sure if you need this box? Press <b>Check my CDN now</b> under Actions below. If your host already runs a CDN, leave the address empty.</p></div>';
		submit_button( 'Save Speed Tools' );
		echo '</form>';
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Actions</h2></div><p>';
		MRSH_Admin::post_button( 'mrsh_cache_purge', 'Clear page cache', false );
		MRSH_Admin::post_button( 'mrsh_cdn_check', 'Check my CDN now', false );
		MRSH_Admin::post_button( 'mrsh_img_batch', 'Compress next 15 existing images', false );
		echo '</p></div>';
		MRSH_Admin::close();
	}
}
