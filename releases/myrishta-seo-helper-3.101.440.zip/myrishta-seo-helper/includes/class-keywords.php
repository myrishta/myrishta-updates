<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Keywords {

	const CACHE = 'mrsh_coverage';

	private static $cache = null;

	public static function flush() {
		self::$cache = null;
	}

	public static function all() {
		if ( null === self::$cache ) {
			$file = MRSH_DIR . 'data/keywords.json';
			$json = is_readable( $file ) ? file_get_contents( $file ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			$rows = $json ? json_decode( $json, true ) : array();
			$rows = is_array( $rows ) ? $rows : array();
			self::$cache = array_merge( $rows, MRSH_Discovery::custom_rows() );
		}
		return self::$cache;
	}

	public static function label( $row ) {
		return '' !== $row['roman'] ? $row['roman'] : $row['urdu'];
	}

	public static function groups() {
		$g = array();
		foreach ( self::all() as $r ) {
			$g[ $r['group'] ] = true;
		}
		return array_keys( $g );
	}

	public static function stats() {
		$rows  = self::all();
		$stats = array( 'total' => count( $rows ), 'target' => 0, 'high' => 0 );
		foreach ( $rows as $r ) {
			if ( 'Target' === $r['treatment'] ) {
				$stats['target']++;
			}
			if ( 'High' === $r['priority'] ) {
				$stats['high']++;
			}
		}
		return $stats;
	}

	/** Searchable spellings of one row: Roman and Urdu parts, bracketed notes removed. */
	public static function variants( $row ) {
		$out = array();
		foreach ( array( 'roman', 'urdu' ) as $f ) {
			$s = isset( $row[ $f ] ) ? (string) $row[ $f ] : '';
			$s = preg_replace( '/\([^)]*\)/u', '', $s );
			foreach ( explode( '/', $s ) as $part ) {
				$part = trim( preg_replace( '/[?!,.]+$/u', '', trim( $part ) ) );
				if ( mb_strlen( $part ) >= 2 ) {
					$out[] = mb_strtolower( $part );
				}
			}
		}
		return array_values( array_unique( $out ) );
	}

	/** Which bank phrases appear in a text. A plain text match; it does not judge quality. */
	public static function coverage( $text, $rows = null ) {
		$rows    = null === $rows ? self::all() : $rows;
		$text    = mb_strtolower( wp_strip_all_tags( (string) $text ) );
		$matched = array();
		$missing = array();
		foreach ( $rows as $row ) {
			$hit = false;
			foreach ( self::variants( $row ) as $v ) {
				if ( false !== mb_stripos( $text, $v ) ) {
					$hit = true;
					break;
				}
			}
			if ( $hit ) {
				$matched[] = $row;
			} else {
				$missing[] = $row;
			}
		}
		return array( 'matched' => $matched, 'missing' => $missing );
	}

	/**
	 * Site-wide report from a list of posts (objects with ID, post_title, post_content).
	 * Returns pages with their phrase counts, and phrases used on no page.
	 */
	public static function report_for_posts( $posts, $rows = null ) {
		$rows    = null === $rows ? self::all() : $rows;
		$covered = array();
		$pages   = array();
		foreach ( $posts as $p ) {
			$cov = self::coverage( $p->post_title . ' ' . $p->post_content, $rows );
			foreach ( $cov['matched'] as $r ) {
				$covered[ $r['n'] ] = true;
			}
			$pages[] = array(
				'id'      => (int) $p->ID,
				'title'   => $p->post_title,
				'matched' => count( $cov['matched'] ),
			);
		}
		usort(
			$pages,
			function ( $a, $b ) {
				return $b['matched'] - $a['matched'];
			}
		);
		$uncovered = array();
		foreach ( $rows as $r ) {
			if ( empty( $covered[ $r['n'] ] ) ) {
				$uncovered[] = $r;
			}
		}
		return array(
			'scanned'   => count( $posts ),
			'pages'     => $pages,
			'uncovered' => $uncovered,
			'time'      => time(),
		);
	}

	/** Scan published, indexable content. Member profiles are skipped on purpose. */
	public static function site_report( $force = false ) {
		$cached = get_transient( self::CACHE );
		if ( ! $force && is_array( $cached ) ) {
			return $cached;
		}
		$o     = MRSH_Options::get();
		$skip  = array_merge( array( 'attachment' ), MRSH_Options::to_list( $o['noindex_post_types'] ) );
		$types = array_values( array_diff( array_keys( get_post_types( array( 'public' => true ) ) ), $skip ) );
		$posts = get_posts(
			array(
				'post_type'        => $types,
				'post_status'      => 'publish',
				'numberposts'      => 300,
				'suppress_filters' => true,
			)
		);
		$report = self::report_for_posts( $posts );
		set_transient( self::CACHE, $report, HOUR_IN_SECONDS * 30 );
		return $report;
	}

	/** Rows that map to their own page (not a filter, homepage or guide hook). */
	public static function draftable( $row ) {
		return 'Target' === $row['treatment'] && (bool) preg_match( '/^(Landing page|Guide|Status page|Profession page|Community pages)/', $row['use'] );
	}

	public static function draft_title( $row ) {
		$t = self::label( $row );
		if ( preg_match( '/^[A-Za-z ]+:\s*(.+)$/', $row['use'], $m ) ) {
			$t = $m[1];
		}
		return ucfirst( trim( $t ) );
	}

	public static function draft_content( $row ) {
		$label = self::label( $row );
		$block = function ( $tag, $text ) {
			return 'p' === $tag
				? '<!-- wp:paragraph --><p>' . esc_html( $text ) . '</p><!-- /wp:paragraph -->' . "\n"
				: '<!-- wp:heading --><h2 class="wp-block-heading">' . esc_html( $text ) . '</h2><!-- /wp:heading -->' . "\n";
		};
		return $block( 'p', 'DRAFT OUTLINE: write original content for "' . $label . '", then delete this note. Do not publish the outline as it is.' )
			. $block( 'h', 'What is ' . $label . '?' ) . $block( 'p', 'Explain it in plain words for Pakistani families.' )
			. $block( 'h', 'What families should know' ) . $block( 'p', 'Practical points, with accurate facts only.' )
			. $block( 'h', 'Questions people ask' ) . $block( 'p', 'Three to five real questions with short answers.' )
			. $block( 'h', 'How MyRishta.pk can help' ) . $block( 'p', 'Link to the profile search and sign-up.' );
	}

	/** Creates unpublished drafts for chosen phrases. Never publishes. Returns the number created. */
	public static function create_drafts( $numbers ) {
		$made = 0;
		$byn  = array();
		foreach ( self::all() as $r ) {
			$byn[ (int) $r['n'] ] = $r;
		}
		foreach ( array_slice( array_unique( array_map( 'intval', (array) $numbers ) ), 0, 10 ) as $n ) {
			if ( empty( $byn[ $n ] ) || ! self::draftable( $byn[ $n ] ) ) {
				continue;
			}
			$title = self::draft_title( $byn[ $n ] );
			if ( get_posts( array( 'post_type' => 'page', 'post_status' => 'any', 'title' => $title, 'numberposts' => 1, 'suppress_filters' => true ) ) ) {
				continue;
			}
			$id = wp_insert_post(
				array(
					'post_type'    => 'page',
					'post_status'  => 'draft',
					'post_title'   => $title,
					'post_content' => self::draft_content( $byn[ $n ] ),
				)
			);
			if ( $id && ! is_wp_error( $id ) ) {
				$made++;
			}
		}
		return $made;
	}

	public static function export_csv() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_export' );
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="myrishta-keywords.csv"' );
		echo "\xEF\xBB\xBF"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		fputcsv( $out, array( '#', 'List', 'Group', 'Urdu', 'Roman Urdu / English', 'Treatment', 'Target page or use', 'Priority' ) );
		foreach ( self::all() as $r ) {
			fputcsv( $out, array( $r['n'], $r['list'], $r['group'], $r['urdu'], $r['roman'], $r['treatment'], $r['use'], $r['priority'] ) );
		}
		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		exit;
	}
}
