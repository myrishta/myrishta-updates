<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Weekly YouTube Community post helper (3.101.416).
 * YouTube does not let websites or tools publish Community posts yet (the official API is a closed pilot), so the site
 * writes the post (free AI first, a ready-made template when AI is off), emails it, and raises a ticket. The owner pastes it
 * into YouTube Studio, which takes about half a minute. One button marks it done.
 */
class MRSH_YtPost {

	const OPT  = 'mrsh_ytpost';
	const CRON = 'mrsh_ytpost_tick';
	const CHAN = 'UCOntUYcYplrPn3GgVjtfv4w';

	public static function init() {
		add_action( self::CRON, array( __CLASS__, 'tick' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
		if ( is_admin() ) {
			add_action( 'admin_menu', array( __CLASS__, 'menu' ), 46 );
			foreach ( array( 'save', 'new', 'done', 'skip', 'save_text' ) as $a ) {
				add_action( 'admin_post_mrsh_yt_' . $a, array( __CLASS__, 'act_' . $a ) );
			}
		}
	}

	public static function o() {
		$o = get_option( self::OPT, array() );
		$o = is_array( $o ) ? $o : array();
		return $o + array( 'on' => 1, 'dow' => 1, 'mail' => 1, 'last_week' => '', 'n' => 0, 'cur' => null, 'hist' => array() );
	}

	private static function put( $o ) {
		update_option( self::OPT, $o, false );
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::CRON ) ) {
			wp_schedule_event( time() + 900, 'hourly', self::CRON );
		}
	}

	/** Topics rotate week by week: key, English topic, link, Urdu fallback text, English fallback text. */
	public static function topics() {
		$h = home_url( '/' );
		$v = home_url( '/video-guides/' );
		return array(
			array( 'safe', 'staying safe: never send money or CNIC copies, meet with family in a public place', home_url( '/rishta-scam-warning-signs/' ), 'رشتے میں محفوظ رہیں: کبھی رقم یا شناختی کارڈ کی کاپی نہ بھیجیں، اور ملاقات خاندان کے ساتھ عوامی جگہ پر کریں۔', 'Stay safe: never send money or CNIC copies, and meet with family in a public place.' ),
			array( 'signup', 'how to sign up for a free profile in a minute', $v . '#vg-signup', 'مفت پروفائل ایک منٹ میں بنائیں۔ ویڈیو دیکھیں اور قدم بہ قدم سیکھیں۔', 'Make your free profile in a minute. Watch the short video and follow each step.' ),
			array( 'photo', 'adding a clear photo and good details to get more replies', $v . '#vg-photo', 'صاف تصویر اور مکمل تفصیل سے آپ کو زیادہ جواب ملتے ہیں۔ ویڈیو میں دیکھیں کیسے لگائیں۔', 'A clear photo and full details get more replies. See how in the video.' ),
			array( 'search', 'searching by age, city and education to find suitable rishta', $v . '#vg-search', 'عمر، شہر اور تعلیم کے مطابق مناسب رشتہ تلاش کریں۔ ویڈیو میں طریقہ دیکھیں۔', 'Search by age, city and education to find a suitable rishta. Watch how in the video.' ),
			array( 'chat', 'the messenger with ready questions families can ask each other', $v . '#vg-chat', 'میسنجر میں تیار سوالات کے ساتھ خاندان آسانی سے بات کر سکتے ہیں۔', 'Our messenger has ready questions so families can talk easily.' ),
			array( 'free', 'a free, non-profit rishta service with no agents and no fees', home_url( '/how-it-works/' ), 'مائی رشتہ پاکستان مفت ہے۔ کوئی ایجنٹ نہیں، کوئی فیس نہیں۔ یہ کیسے کام کرتا ہے، دیکھیں۔', 'MyRishta.pk is free. No agents, no fees. See how it works.' ),
			array( 'password', 'what to do if you forget your password', $v . '#vg-forgot', 'پاس ورڈ بھول گئے؟ پریشان نہ ہوں۔ ویڈیو میں دیکھیں کہ نیا پاس ورڈ کیسے بنائیں۔', 'Forgot your password? No problem. See how to set a new one in the video.' ),
			array( 'cities', 'rishta in Lahore, Karachi and Islamabad', home_url( '/pakistan-rishta/' ), 'لاہور، کراچی اور اسلام آباد کے رشتے مفت دیکھیں۔', 'See free rishta profiles from Lahore, Karachi and Islamabad.' ),
			array( 'phone', 'phone numbers stay private until the other family approves', $v . '#vg-phone', 'آپ کا فون نمبر نجی رہتا ہے، جب تک دوسرا خاندان منظوری نہ دے۔', 'Your phone number stays private until the other family approves.' ),
			array( 'verify', 'verifying your email so your profile is trusted', $v . '#vg-verify', 'ای میل کی تصدیق کریں تاکہ آپ کا پروفائل قابل اعتماد بنے۔', 'Verify your email so your profile is more trusted.' ),
		);
	}

	private static function fallback( $t ) {
		return $t[3] . "\n\n" . $t[4] . "\n\n" . $t[2] . "\n\n#MyRishta #PakistaniRishta #Rishta";
	}

	/** Writes the next post. Returns the text. */
	public static function make( $o ) {
		$tops = self::topics();
		$t    = $tops[ (int) $o['n'] % count( $tops ) ];
		$txt  = '';
		if ( class_exists( 'MRSH_AIHub' ) && MRSH_AIHub::ready() ) {
			$sys = 'You write one short YouTube Community post for MyRishta.pk, a free non-profit Pakistani rishta (matrimonial) website. Write first in simple, warm Urdu (Urdu script), then 1 or 2 lines in simple English. Total under 420 characters before the link. No promises about marriage, no money requests, no personal data, no exaggeration, no emojis except at most one. End with the link on its own line, then the hashtags #MyRishta #PakistaniRishta. Output only the post.';
			$r   = MRSH_AIHub::ask( $sys, 'Topic: ' . $t[1] . "\nLink: " . $t[2], 450 );
			if ( ! is_wp_error( $r ) ) {
				$r = trim( (string) $r );
				if ( strlen( $r ) > 60 && false !== strpos( $r, home_url() ) ) {
					$txt = $r;
				}
			}
		}
		if ( '' === $txt ) {
			$txt = self::fallback( $t );
		}
		return array( $t[0], $txt );
	}

	public static function generate( $force = false ) {
		if ( self::o()['cur'] ) {
			self::close( 'skipped' ); // an unposted older draft is closed so its ticket does not linger
		}
		$o = self::o();
		list( $key, $txt ) = self::make( $o );
		$o['cur']       = array( 'id' => time(), 'topic' => $key, 'text' => $txt, 'status' => 'new', 'ts' => time() );
		$o['n']         = (int) $o['n'] + 1;
		$o['last_week'] = gmdate( 'o-W', current_time( 'timestamp' ) );
		self::put( $o );
		if ( class_exists( 'MRSH_Fixer' ) ) {
			MRSH_Fixer::ticket( 'ytpost-' . $o['cur']['id'], 'YouTube post is ready to paste', 'This week\'s YouTube Community post is written. Open YouTube posts, copy it and paste it in YouTube Studio, then press Mark as posted.', 'low', 'needs_approval', admin_url( 'admin.php?page=mrsh-ytpost' ) );
		}
		if ( ! empty( $o['mail'] ) && ! $force ) {
			wp_mail( get_option( 'admin_email' ), '[MyRishta] This week\'s YouTube post is ready', "Assalam o Alaikum,\n\nThis week's YouTube Community post is ready. Copy it, then in YouTube Studio press Create, Create post, paste and Post.\n\n----------------\n" . $txt . "\n----------------\n\nOpen it with one tap: " . admin_url( 'admin.php?page=mrsh-ytpost' ) . "\n" );
		}
		return $txt;
	}

	public static function tick() {
		$o = self::o();
		if ( empty( $o['on'] ) ) {
			return;
		}
		$now = current_time( 'timestamp' );
		if ( $o['last_week'] === gmdate( 'o-W', $now ) || (int) gmdate( 'N', $now ) < (int) $o['dow'] || (int) gmdate( 'G', $now ) < 8 ) {
			return;
		}
		self::generate();
	}

	/* ---------------------------------------------------------------- admin */
	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'YouTube posts', 'YouTube posts', 'manage_options', 'mrsh-ytpost', array( __CLASS__, 'page' ) );
	}

	private static function guard( $a ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( $a );
	}

	private static function back( $m ) {
		wp_safe_redirect( add_query_arg( array( 'page' => 'mrsh-ytpost', 'msg' => rawurlencode( $m ) ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public static function act_save() {
		self::guard( 'mrsh_yt_save' );
		$o        = self::o();
		$o['on']   = empty( $_POST['on'] ) ? 0 : 1;
		$o['mail'] = empty( $_POST['mail'] ) ? 0 : 1;
		$o['dow']  = max( 1, min( 7, (int) ( $_POST['dow'] ?? 1 ) ) ); // phpcs:ignore WordPress.Security.NonceVerification
		self::put( $o );
		self::back( 'Settings saved.' );
	}

	public static function act_new() {
		self::guard( 'mrsh_yt_new' );
		self::generate( true );
		self::back( 'A new post was written.' );
	}

	public static function act_save_text() {
		self::guard( 'mrsh_yt_save_text' );
		$o = self::o();
		if ( $o['cur'] ) {
			$o['cur']['text'] = sanitize_textarea_field( wp_unslash( $_POST['text'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification
			self::put( $o );
		}
		self::back( 'Your edit was saved.' );
	}

	private static function close( $status ) {
		$o = self::o();
		if ( $o['cur'] ) {
			$c           = $o['cur'];
			$c['status'] = $status;
			array_unshift( $o['hist'], $c );
			$o['hist'] = array_slice( $o['hist'], 0, 20 );
			if ( class_exists( 'MRSH_Fixer' ) ) {
				MRSH_Fixer::ticket_resolve( 'ytpost-' . $c['id'] );
			}
			$o['cur'] = null;
			self::put( $o );
		}
	}

	public static function act_done() {
		self::guard( 'mrsh_yt_done' );
		self::close( 'posted' );
		self::back( 'Marked as posted. Next week\'s post will be written for you.' );
	}

	public static function act_skip() {
		self::guard( 'mrsh_yt_skip' );
		self::close( 'skipped' );
		self::back( 'Skipped.' );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$o     = self::o();
		$posted = 0;
		foreach ( $o['hist'] as $h ) {
			if ( 'posted' === $h['status'] ) {
				++$posted;
			}
		}
		$studio = 'https://studio.youtube.com/channel/' . self::CHAN;
		MRSH_Boost::ui_open( 'YouTube posts', 'A fresh Community post is written for you every week. Copy it, paste it in YouTube Studio, press Mark as posted.', 'g-red', 'M10 15l5.2-3L10 9v6zm11-3c0-2-.2-3.4-.5-4.4-.3-1-1-1.7-2-2C17.5 5.3 12 5.3 12 5.3s-5.5 0-6.5.3c-1 .3-1.7 1-2 2C3.2 8.600 3 10 3 12s.2 3.400.5 4.400c.3 1 1 1.700 2 2 1 .3 6.500.3 6.500.3s5.500 0 6.500-.3c1-.3 1.700-1 2-2 .3-1 .5-2.400.5-4.400z' );
		if ( isset( $_GET['msg'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			MRSH_Boost::ui_ok( rawurldecode( (string) wp_unslash( $_GET['msg'] ) ) ); // phpcs:ignore
		}
		echo '<div class="mx-stats">' . MRSH_Boost::ui_stat( $o['cur'] ? 'Ready' : 'None waiting', 'This week', $o['cur'] ? '#f59e0b' : '#10b981' ) . MRSH_Boost::ui_stat( $posted, 'Posted so far', '#10b981' ) . MRSH_Boost::ui_stat( $o['on'] ? 'On' : 'Off', 'Weekly writer', $o['on'] ? '#0ea5e9' : '#6b7280' ) . '</div>'; // phpcs:ignore
		echo '<div class="mx-card"><h2>This week\'s post</h2>';
		if ( $o['cur'] ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_yt_save_text">';
			wp_nonce_field( 'mrsh_yt_save_text' );
			echo '<textarea id="mrsh-yt-text" name="text" rows="9" style="width:100%;font-size:15px;line-height:1.6">' . esc_textarea( $o['cur']['text'] ) . '</textarea><p style="display:flex;gap:8px;flex-wrap:wrap">';
			echo '<button type="button" class="button button-primary button-large" id="mrsh-yt-copy">Copy the text</button> <a class="button button-large" target="_blank" rel="noopener" href="' . esc_url( $studio ) . '">Open YouTube Studio (then Create, Create post)</a> <button class="button button-large">Save my edit</button></p></form>';
			echo '<p style="display:flex;gap:8px;flex-wrap:wrap">';
			MRSH_Admin::post_button( 'mrsh_yt_done', 'Mark as posted', true );
			MRSH_Admin::post_button( 'mrsh_yt_new', 'Write another one', false );
			MRSH_Admin::post_button( 'mrsh_yt_skip', 'Skip this week', false );
			echo '</p>';
			echo '<script>(function(){var b=document.getElementById("mrsh-yt-copy"),t=document.getElementById("mrsh-yt-text");if(!b)return;b.onclick=function(){t.select();var ok=false;try{ok=document.execCommand("copy")}catch(e){}if(!ok&&navigator.clipboard){navigator.clipboard.writeText(t.value)}b.textContent="Copied. Now paste it in YouTube."}})();</script>';
		} else {
			echo '<p class="mx-sub">Nothing waiting. The next post is written on its own, or press the button now.</p>';
			MRSH_Admin::post_button( 'mrsh_yt_new', 'Write this week\'s post now', true );
		}
		echo '</div><div class="mx-card"><h2>Settings</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_yt_save">';
		wp_nonce_field( 'mrsh_yt_save' );
		echo '<p><label><input type="checkbox" name="on" value="1" ' . checked( $o['on'], 1, false ) . '> Write a post every week</label></p><p><label><input type="checkbox" name="mail" value="1" ' . checked( $o['mail'], 1, false ) . '> Email it to me ' . esc_html( get_option( 'admin_email' ) ) . '</label></p><p>Write it on <select name="dow">';
		foreach ( array( 1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday', 7 => 'Sunday' ) as $k => $l ) {
			echo '<option value="' . (int) $k . '" ' . selected( (int) $o['dow'], $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select> (after 8 am)</p><p><button class="button button-primary">Save settings</button></p></form>';
		echo '<p class="mx-sub"><b>Why not fully automatic?</b> YouTube does not allow any website or tool to publish Community posts yet. Its official way is a closed test for selected partners, planned for everyone in 2027. When it opens, this page can post by itself.</p>';
		echo '<p class="mx-sub"><b>Tip:</b> YouTube Studio can also schedule a post for later, so you can paste several weeks at once.</p></div>';
		if ( $o['hist'] ) {
			echo '<div class="mx-card"><h2>Earlier posts</h2><table class="widefat striped"><tbody>';
			foreach ( $o['hist'] as $h ) {
				echo '<tr><td style="white-space:nowrap">' . esc_html( wp_date( 'j M Y', (int) $h['ts'] ) ) . '</td><td>' . esc_html( wp_trim_words( $h['text'], 18 ) ) . '</td><td>' . esc_html( ucfirst( $h['status'] ) ) . '</td></tr>';
			}
			echo '</tbody></table></div>';
		}
		echo '</div>';
	}
}
