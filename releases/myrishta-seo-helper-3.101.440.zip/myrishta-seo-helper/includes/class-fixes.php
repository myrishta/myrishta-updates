<?php
/**
 * Permalink repairs found by the Search Console review:
 *  - category and tag base set to text with spaces (e.g. " Matrimony Pakistan", "Pakistan Rishta"),
 *    which gives addresses like /%20Matrimony%20Pakistan/slug/ that show the homepage.
 *  - 301 redirects from those old addresses to the real category and tag pages.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Fixes {

	const FLAG = 'mrsh_bases_fixed';

	public static function init() {
		add_action( 'send_headers', array( __CLASS__, 'security_headers' ) );
		add_action( 'init', array( __CLASS__, 'repair_bases' ), 4 );
		add_action( 'init', array( __CLASS__, 'redirect_old' ), 5 );
		add_action( 'template_redirect', array( __CLASS__, 'redirect_legacy' ), 1 );
		add_filter( 'auto_update_plugin', array( __CLASS__, 'auto_plugin' ), 20, 2 );
		add_filter( 'auto_update_theme', array( __CLASS__, 'auto_theme' ), 20, 2 );
		add_filter( 'allow_major_auto_core_updates', array( __CLASS__, 'auto_core' ), 20 );
		add_filter( 'allow_minor_auto_core_updates', '__return_true', 20 );
		add_filter( 'auto_update_translation', array( __CLASS__, 'auto_lang' ), 20 );
		add_action( 'admin_post_mrsh_auto', array( __CLASS__, 'save_auto' ) );
	}

	/**
	 * Staging only: when "Discourage search engines" is on, the app page (/app/) is closed to visitors who are not logged in,
	 * like the rest of the site. The live site has that setting off, so nothing changes there.
	 */
	public static function hide_app_on_staging() {
		if ( '0' !== (string) get_option( 'blog_public' ) || is_admin() ) {
			return;
		}
		foreach ( array_keys( $_COOKIE ) as $c ) { // Logged-in admins (any WordPress login cookie) still see the app.
			if ( 0 === strpos( (string) $c, 'wordpress_logged_in_' ) ) {
				return;
			}
		}
		$path = isset( $_SERVER['REQUEST_URI'] ) ? wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH ) : '';
		if ( ! is_string( $path ) || ! preg_match( '#^/app(/|$)#', $path ) ) {
			return;
		}
		status_header( 503 );
		header( 'Retry-After: 3600' );
		header( 'X-Robots-Tag: noindex, nofollow' );
		header( 'Cache-Control: no-store' );
		echo '<!DOCTYPE html><meta charset="utf-8"><meta name="robots" content="noindex"><title>Coming Soon</title><p style="font-family:sans-serif;text-align:center;margin-top:20vh">Coming soon.</p>';
		exit;
	}

	/* ---------- automatic updates ---------- */

	public static function auto_opts() {
		$d = array( 'plugins' => 1, 'themes' => 1, 'core' => 1, 'lang' => 1 );
		$o = get_option( 'mrsh_autoupdate', array() );
		return is_array( $o ) ? array_merge( $d, $o ) : $d;
	}

	public static function auto_plugin( $update, $item = null ) {
		return self::auto_opts()['plugins'] ? true : $update;
	}

	public static function auto_theme( $update, $item = null ) {
		return self::auto_opts()['themes'] ? true : $update;
	}

	public static function auto_core( $update ) {
		return self::auto_opts()['core'] ? true : $update;
	}

	public static function auto_lang( $update ) {
		return self::auto_opts()['lang'] ? true : $update;
	}

	public static function save_auto() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_auto' );
		$o = array();
		foreach ( array( 'plugins', 'themes', 'core', 'lang' ) as $k ) {
			$o[ $k ] = empty( $_POST[ $k ] ) ? 0 : 1;
		}
		update_option( 'mrsh_autoupdate', $o, false );
		set_transient( 'mrsh_easy_msg', 'Automatic updates saved.', 60 );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-easy' ) );
		exit;
	}

	public static function auto_panel() {
		$o = self::auto_opts();
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="background:#fff;border:1px solid #ccd0d4;padding:14px 16px;max-width:860px;margin-top:16px"><input type="hidden" name="action" value="mrsh_auto">';
		wp_nonce_field( 'mrsh_auto' );
		echo '<h2 style="margin-top:0">Automatic updates</h2><p>WordPress checks for updates twice a day and installs the ones you switch on here. Keep a backup (Hostinger makes daily backups) in case an update breaks something.</p>';
		foreach ( array( 'plugins' => 'Plugins (including Elementor, Site Kit and LiteSpeed Cache)', 'themes' => 'Themes (the PremiumPress theme needs its licence to update; it may be skipped)', 'core' => 'WordPress itself (major and minor versions)', 'lang' => 'Translations' ) as $k => $label ) {
			echo '<p><label><input type="checkbox" name="' . esc_attr( $k ) . '" value="1"' . checked( ! empty( $o[ $k ] ), true, false ) . '> ' . esc_html( $label ) . '</label></p>';
		}
		echo '<p><button class="button button-primary">Save</button></p></form>';
	}

	/** A base is broken if it has spaces, capital letters or encoded characters. */
	public static function bad_base( $base ) {
		$base = (string) $base;
		return '' !== $base && (bool) preg_match( '/[\s%A-Z]/', $base );
	}

	/** Light security headers that cost nothing and are checked by site auditors. */
	public static function security_headers() {
		if ( is_admin() ) {
			return;
		}
		header( 'X-Content-Type-Options: nosniff' );
		if ( is_ssl() ) {
			header( 'Strict-Transport-Security: max-age=31536000' );
		}
	}

	public static function repair_bases() {
		if ( get_option( self::FLAG ) === MRSH_VERSION ) {
			return;
		}
		$changed = false;
		foreach ( array( 'category_base', 'tag_base' ) as $opt ) {
			$cur = get_option( $opt );
			if ( self::bad_base( $cur ) ) {
				update_option( 'mrsh_old_' . $opt, $cur, false ); // kept so redirects can match it
				update_option( $opt, '' );
				$changed = true;
			}
		}
		update_option( self::FLAG, MRSH_VERSION, false );
		if ( $changed ) {
			flush_rewrite_rules( false );
		}
	}

	/** [ 'category'|'tag', slug ] when the path uses a broken old base, else null. */
	public static function match_old( $path, $old_cat, $old_tag ) {
		$path = trim( rawurldecode( (string) $path ), '/' );
		$parts = explode( '/', $path );
		if ( 2 !== count( $parts ) || '' === $parts[1] ) {
			return null;
		}
		$base = trim( $parts[0] );
		$bases = array(
			'category' => array_filter( array( strtolower( trim( (string) $old_cat ) ), 'matrimony pakistan' ) ),
			'tag'      => array_filter( array( strtolower( trim( (string) $old_tag ) ), 'pakistan rishta' ) ),
		);
		foreach ( $bases as $type => $list ) {
			if ( in_array( strtolower( $base ), $list, true ) ) {
				return array( $type, sanitize_title( $parts[1] ) );
			}
		}
		return null;
	}

	/** Old demo policy pages point to the real ones, so site-wide footer links count for the right page. */
	public static function legacy_map() {
		return array(
			'privacy' => 'privacy-policy',
			'terms'   => 'terms-and-conditions',
		);
	}

	public static function redirect_legacy() {
		if ( '0' === (string) get_option( 'mrsh_redirects', '1' ) || ! is_page() ) {
			return;
		}
		$slug = get_queried_object() ? get_queried_object()->post_name : '';
		// Leftover pages from a form plugin that is not installed: send visitors to the theme's own pages.
		$dead = array(
			'registration'    => home_url( '/add-listing/' ),
			'login'           => wp_login_url(),
			'forgot-password' => wp_lostpassword_url(),
			'profile'         => home_url( '/my-account/' ),
		);
		if ( isset( $dead[ $slug ] ) && ! shortcode_exists( 'pie_register_form' ) ) {
			wp_safe_redirect( $dead[ $slug ], 301 );
			exit;
		}
		$map = self::legacy_map();
		if ( ! isset( $map[ $slug ] ) ) {
			return;
		}
		$to = get_page_by_path( $map[ $slug ] );
		if ( $to && 'publish' === $to->post_status ) {
			wp_safe_redirect( get_permalink( $to ), 301 );
			exit;
		}
	}

	public static function redirect_old() {
		if ( '0' === (string) get_option( 'mrsh_redirects', '1' ) || is_admin() || empty( $_SERVER['REQUEST_URI'] ) ) {
			return;
		}
		$path = wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$m    = self::match_old( $path, get_option( 'mrsh_old_category_base' ), get_option( 'mrsh_old_tag_base' ) );
		if ( ! $m ) {
			return;
		}
		$term = get_term_by( 'slug', $m[1], 'category' === $m[0] ? 'category' : 'post_tag' );
		$url  = $term && ! is_wp_error( $term ) ? get_term_link( $term ) : home_url( '/blog/' );
		if ( is_wp_error( $url ) ) {
			$url = home_url( '/blog/' );
		}
		wp_safe_redirect( $url, 301 );
		exit;
	}
}

// Registered when the file loads (not in init()), so it runs before the app plugin serves /app/.
add_action( 'plugins_loaded', array( 'MRSH_Fixes', 'hide_app_on_staging' ), -100 );
