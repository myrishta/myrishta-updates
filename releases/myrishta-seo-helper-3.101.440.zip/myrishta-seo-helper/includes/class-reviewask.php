<?php
/**
 * Review ask: a small, polite popup for logged-in members that invites them to rate the site on Google.
 * The member picks their own stars on the Google page. Nothing is pre-filled and nobody is filtered by rating
 * (Google does not allow either). Shows after a short delay, once per cooldown; "Rate on Google" or "I already did"
 * stops it for good, "Later" brings it back after 30 days (max 3 times).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_ReviewAsk {

	const META = '_mrsh_review_ask';
	const URL  = 'https://g.page/r/CcC0TTAQ2osjEAI/review';

	public static function init() {
		add_action( 'wp_footer', array( __CLASS__, 'render' ), 99 );
		add_action( 'wp_ajax_mrsh_review_ask', array( __CLASS__, 'ajax' ) );
	}

	private static function url() {
		return (string) apply_filters( 'mrsh_review_url', self::URL );
	}

	private static function should_show( $uid ) {
		if ( ! apply_filters( 'mrsh_review_popup_on', true ) ) {
			return false;
		}
		$m = get_user_meta( $uid, self::META, true );
		if ( ! is_array( $m ) ) {
			return true;
		}
		if ( ! empty( $m['done'] ) ) {
			return false;
		}
		$n = (int) ( $m['n'] ?? 0 );
		if ( $n >= 3 ) {
			return false;
		}
		return time() - (int) ( $m['t'] ?? 0 ) > 30 * DAY_IN_SECONDS;
	}

	public static function ajax() {
		check_ajax_referer( 'mrsh_review_ask', 'n' );
		$uid = get_current_user_id();
		if ( ! $uid ) {
			wp_send_json_error();
		}
		$what = isset( $_POST['what'] ) ? sanitize_key( wp_unslash( $_POST['what'] ) ) : '';
		$m    = get_user_meta( $uid, self::META, true );
		$m    = is_array( $m ) ? $m : array();
		$m['t'] = time();
		if ( 'later' === $what ) {
			$m['n'] = (int) ( $m['n'] ?? 0 ) + 1;
		} else {
			$m['done'] = 1;
		}
		update_user_meta( $uid, self::META, $m );
		wp_send_json_success();
	}

	public static function render() {
		if ( is_admin() || ! is_user_logged_in() || is_customize_preview() || wp_doing_ajax() || isset( $_GET['elementor-preview'] ) || isset( $_GET['preview'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		$uid = get_current_user_id();
		if ( ! self::should_show( $uid ) ) {
			return;
		}
		$cfg = array(
			'url'  => esc_url_raw( self::url() ),
			'ajax' => admin_url( 'admin-ajax.php' ),
			'n'    => wp_create_nonce( 'mrsh_review_ask' ),
		);
		?>
<style id="mrsh-ra-css">
#mrsh-ra{position:fixed;right:16px;bottom:16px;z-index:99999;width:min(340px,calc(100vw - 32px));background:#fff;color:#1f2937;border:1px solid #e5e7eb;border-radius:16px;box-shadow:0 12px 40px rgba(0,0,0,.18);padding:18px 18px 14px;font:14px/1.45 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;transform:translateY(24px);opacity:0;transition:.35s}
#mrsh-ra.on{transform:none;opacity:1}
#mrsh-ra h3{margin:0 24px 4px 0;font-size:16px;font-weight:700;color:#111827}
#mrsh-ra p{margin:0 0 10px;color:#4b5563}
#mrsh-ra .x{position:absolute;top:8px;right:10px;border:0;background:none;font-size:22px;line-height:1;color:#9ca3af;cursor:pointer}
#mrsh-ra .st{display:flex;gap:4px;margin:2px 0 12px}
#mrsh-ra .st button{border:0;background:none;padding:0;font-size:30px;line-height:1;color:#d1d5db;cursor:pointer;transition:.12s}
#mrsh-ra .st:hover button{color:#f5b301}
#mrsh-ra .st button:hover~button{color:#d1d5db}
#mrsh-ra .go{display:block;width:100%;text-align:center;background:#0f766e;color:#fff;border:0;border-radius:10px;padding:10px;font-weight:600;font-size:14px;cursor:pointer;text-decoration:none}
#mrsh-ra .go:hover{background:#115e59;color:#fff}
#mrsh-ra .ln{display:flex;justify-content:space-between;margin-top:8px}
#mrsh-ra .ln button{border:0;background:none;color:#6b7280;font-size:13px;cursor:pointer;padding:4px 0}
#mrsh-ra .ln button:hover{color:#111827;text-decoration:underline}
@media (prefers-color-scheme:dark){#mrsh-ra{background:#1f2937;color:#e5e7eb;border-color:#374151}#mrsh-ra h3{color:#f9fafb}#mrsh-ra p{color:#cbd5e1}#mrsh-ra .st button{color:#4b5563}#mrsh-ra .ln button{color:#9ca3af}}
</style>
<div id="mrsh-ra" role="dialog" aria-label="Rate My Rishta on Google" hidden>
	<button type="button" class="x" data-a="later" aria-label="Close">&times;</button>
	<h3>Enjoying My Rishta?</h3>
	<p>My Rishta is free and non-profit. If we helped you, an honest rating on Google helps other families find us.</p>
	<div class="st" aria-label="Choose your stars on the Google page">
		<button type="button" data-a="rate" aria-label="1 star">&#9733;</button><button type="button" data-a="rate" aria-label="2 stars">&#9733;</button><button type="button" data-a="rate" aria-label="3 stars">&#9733;</button><button type="button" data-a="rate" aria-label="4 stars">&#9733;</button><button type="button" data-a="rate" aria-label="5 stars">&#9733;</button>
	</div>
	<a class="go" href="<?php echo esc_url( self::url() ); ?>" target="_blank" rel="noopener" data-a="rate">Rate us on Google</a>
	<div class="ln"><button type="button" data-a="later">Maybe later</button><button type="button" data-a="done">I already did</button></div>
</div>
<script>
(function(){
	var c=<?php echo wp_json_encode( $cfg ); ?>,b=document.getElementById('mrsh-ra');
	if(!b)return;
	function save(w){try{var f=new FormData();f.append('action','mrsh_review_ask');f.append('n',c.n);f.append('what',w);fetch(c.ajax,{method:'POST',body:f,credentials:'same-origin'});}catch(e){}}
	function close(){b.classList.remove('on');setTimeout(function(){b.hidden=true;},350);}
	b.addEventListener('click',function(e){
		var t=e.target.closest('[data-a]');if(!t)return;
		var a=t.getAttribute('data-a');
		if(a==='rate'){e.preventDefault();window.open(c.url,'_blank','noopener');save('rate');close();return;}
		save(a);close();
	});
	setTimeout(function(){b.hidden=false;requestAnimationFrame(function(){b.classList.add('on');});},4000);
})();
</script>
		<?php
	}
}

MRSH_ReviewAsk::init();
