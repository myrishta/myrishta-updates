<?php
/**
 * Daily digest: one email each morning with what is waiting, so nothing is missed when many members join.
 * Counts only, with links to the filtered lists. Switch on or off, pick the hour, send now, or preview.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Digest {

	const OPT  = 'mrsh_digest';
	const CRON = 'mrsh_digest_tick';

	public static function o( $k = null ) {
		$o = array_merge( array( 'on' => 1, 'to' => '', 'hour' => 8, 'empty' => 0, 'last' => '' ), (array) get_option( self::OPT, array() ) );
		return null === $k ? $o : $o[ $k ];
	}

	public static function init() {
		add_action( self::CRON, array( __CLASS__, 'tick' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 29 );
		add_action( 'admin_post_mrsh_digest_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_mrsh_digest_now', array( __CLASS__, 'now' ) );
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::CRON ) ) {
			wp_schedule_event( time() + 600, 'hourly', self::CRON );
		}
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Daily digest', 'Daily digest', 'manage_options', 'mrsh-digest', array( __CLASS__, 'page' ) );
	}

	/** array( lines, total ) lines = array( label, count, url ) */
	public static function data() {
		$lines = array();
		$tot   = 0;
		if ( class_exists( 'MRSH_Tabs' ) ) {
			delete_transient( 'mrsh_cnt' );
			$c = MRSH_Tabs::counts();
			foreach ( MRSH_Tabs::groups() as $g ) {
				foreach ( $g[2] as $slug => $label ) {
					$n = (int) ( $c[ $slug ] ?? 0 );
					if ( $n > 0 && ! in_array( $slug, array( 'mrsh-users', 'mrsh-plans', 'mrsh-tlate' ), true ) ) {
						$lines[] = array( $label . ' waiting', $n, admin_url( 'admin.php?page=' . $slug . '&attn=1' ) );
						$tot    += $n;
					}
				}
			}
			if ( ! empty( $c['mrsh-tlate'] ) ) {
				$lines[] = array( 'Overdue tickets', (int) $c['mrsh-tlate'], admin_url( 'admin.php?page=mrsh-tickets&attn=1' ) );
			}
		}
		if ( class_exists( 'MRSH_Attn' ) ) {
			$new = count( MRSH_Attn::new_members( 1 ) );
			if ( $new ) {
				$lines[] = array( 'New members in the last 24 hours', $new, admin_url( 'admin.php?page=mrsh-desk' ) );
			}
		}
		$log = get_option( 'mrsh_shield_log', array() );
		$bad = 0;
		foreach ( (array) $log as $e ) {
			if ( isset( $e[0], $e[3] ) && (int) $e[0] > time() - DAY_IN_SECONDS && in_array( $e[3], array( 'fail', 'locked' ), true ) ) {
				$bad++;
			}
		}
		if ( $bad ) {
			$lines[] = array( 'Failed log in attempts in 24 hours', $bad, admin_url( 'admin.php?page=mrsh-shield' ) );
		}
		return array( $lines, $tot );
	}

	public static function body() {
		list( $lines, $tot ) = self::data();
		$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$t    = $site . " daily digest\n" . wp_date( 'l j F Y' ) . "\n\n";
		if ( ! $lines ) {
			return $t . "Nothing is waiting. All clear.\n";
		}
		foreach ( $lines as $l ) {
			$t .= $l[1] . '  ' . $l[0] . "\n    " . $l[2] . "\n";
		}
		return $t . "\nOpen the links above: each list opens already filtered to what needs you.\n";
	}

	public static function send( $force = false ) {
		$o  = self::o();
		$to = is_email( $o['to'] ) ? $o['to'] : get_option( 'admin_email' );
		list( $lines ) = self::data();
		if ( ! $lines && ! $o['empty'] && ! $force ) {
			return false;
		}
		$ok = wp_mail( $to, '[' . wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) . '] Daily digest: ' . ( $lines ? count( $lines ) . ' things need you' : 'all clear' ), self::body() );
		return (bool) $ok;
	}

	public static function tick() {
		$o = self::o();
		if ( ! $o['on'] ) {
			return;
		}
		$today = wp_date( 'Y-m-d' );
		if ( $o['last'] === $today || (int) wp_date( 'G' ) < (int) $o['hour'] ) {
			return;
		}
		self::send( false );
		$o['last'] = $today;
		update_option( self::OPT, $o, false );
	}

	private static function guard( $n ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.', '', array( 'response' => 403 ) );
		}
		check_admin_referer( $n );
	}

	public static function save() {
		self::guard( 'mrsh_digest_save' );
		$o = self::o();
		$o['on']    = empty( $_POST['on'] ) ? 0 : 1; // phpcs:ignore
		$o['empty'] = empty( $_POST['empty'] ) ? 0 : 1; // phpcs:ignore
		$o['hour']  = max( 0, min( 23, (int) ( $_POST['hour'] ?? 8 ) ) ); // phpcs:ignore
		$to         = isset( $_POST['to'] ) ? sanitize_email( wp_unslash( $_POST['to'] ) ) : ''; // phpcs:ignore
		$o['to']    = is_email( $to ) ? $to : '';
		update_option( self::OPT, $o, false );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-digest&done=saved' ) );
		exit;
	}

	public static function now() {
		self::guard( 'mrsh_digest_now' );
		$ok = self::send( true );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-digest&done=' . ( $ok ? 'sent' : 'fail' ) ) );
		exit;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$o    = self::o();
		$post = esc_url( admin_url( 'admin-post.php' ) );
		echo '<div class="wrap"><h1>Daily digest</h1>';
		$d = isset( $_GET['done'] ) ? sanitize_key( wp_unslash( $_GET['done'] ) ) : ''; // phpcs:ignore
		if ( 'saved' === $d ) {
			echo '<div class="notice notice-success"><p>Saved.</p></div>';
		} elseif ( 'sent' === $d ) {
			echo '<div class="notice notice-success"><p>The digest was sent. Check your inbox.</p></div>';
		} elseif ( 'fail' === $d ) {
			echo '<div class="notice notice-error"><p>The email could not be sent. Check Email delivery.</p></div>';
		}
		echo '<p>One short email each morning with what is waiting for you, and a link to each list already filtered. Nothing is sent when everything is clear, unless you tick the box.</p>';
		echo '<div class="card" style="max-width:none;padding:16px 18px"><form method="post" action="' . $post . '" style="display:flex;gap:16px;flex-wrap:wrap;align-items:end"><input type="hidden" name="action" value="mrsh_digest_save">' . wp_nonce_field( 'mrsh_digest_save', '_wpnonce', true, false ); // phpcs:ignore
		echo '<label><input type="checkbox" name="on" value="1"' . checked( $o['on'], 1, false ) . '> Send every day</label>';
		echo '<label>Send after (hour, site time)<br><input type="number" min="0" max="23" name="hour" value="' . (int) $o['hour'] . '" style="width:80px"></label>';
		echo '<label>Send to<br><input type="email" name="to" value="' . esc_attr( $o['to'] ) . '" placeholder="' . esc_attr( get_option( 'admin_email' ) ) . '" class="regular-text"></label>';
		echo '<label><input type="checkbox" name="empty" value="1"' . checked( $o['empty'], 1, false ) . '> Also send when nothing is waiting</label>';
		echo '<button class="button button-primary">Save</button></form>';
		echo '<form method="post" action="' . $post . '" style="margin-top:12px"><input type="hidden" name="action" value="mrsh_digest_now">' . wp_nonce_field( 'mrsh_digest_now', '_wpnonce', true, false ) . '<button class="button">Send me the digest now</button></form></div>'; // phpcs:ignore
		echo '<h2>Preview (what it says right now)</h2><pre style="background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:14px;white-space:pre-wrap;max-width:760px">' . esc_html( self::body() ) . '</pre></div>';
	}
}
MRSH_Digest::init();
