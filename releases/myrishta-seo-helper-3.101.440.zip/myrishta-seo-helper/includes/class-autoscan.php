<?php
/**
 * Automatic live checks and keyword coverage scan (3.101.226).
 * Runs twice a day in the background and once soon after the plugin
 * is updated or the saved results are missing. The manual buttons stay.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Autoscan {
	const HOOK = 'mrsh_autoscan';
	const ONCE = 'mrsh_autoscan_once';

	public static function init() {
		add_action( self::HOOK, array( __CLASS__, 'run' ) );
		add_action( self::ONCE, array( __CLASS__, 'run' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + 300, 'twicedaily', self::HOOK );
		}
		// Results missing (first run, or they expired): run once soon.
		if ( ( false === get_transient( MRSH_Checks::CACHE ) || false === get_transient( MRSH_Keywords::CACHE ) ) && ! wp_next_scheduled( self::ONCE ) ) {
			wp_schedule_single_event( time() + 60, self::ONCE );
		}
	}

	public static function run() {
		if ( get_transient( 'mrsh_autoscan_lock' ) ) {
			return;
		}
		set_transient( 'mrsh_autoscan_lock', 1, 5 * MINUTE_IN_SECONDS );
		try {
			if ( class_exists( 'MRSH_Checks' ) ) {
				MRSH_Checks::run();
			}
		} catch ( \Throwable $e ) { // phpcs:ignore
			unset( $e );
		}
		try {
			if ( class_exists( 'MRSH_Keywords' ) ) {
				MRSH_Keywords::site_report( true );
			}
		} catch ( \Throwable $e ) { // phpcs:ignore
			unset( $e );
		}
	}
}
MRSH_Autoscan::init();
