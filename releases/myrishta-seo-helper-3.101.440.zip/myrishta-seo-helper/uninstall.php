<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
// Keep every setting (verification codes, rules, keyword bank) when the plugin is deleted and
// reinstalled. Only wipe when the site owner has explicitly set mrsh_delete_data to 1.
if ( 1 !== (int) get_option( 'mrsh_delete_data', 0 ) ) {
	wp_clear_scheduled_hook( 'mrsh_weekly_scan' );
	return;
}
delete_option( 'mrsh_options' );
delete_transient( 'mrsh_coverage' );
delete_transient( 'mrsh_checks' );
delete_option( 'mrsh_indexnow_log' );
delete_transient( 'mrsh_titles' );
delete_option( 'mrsh_custom_keywords' );
delete_option( 'mrsh_search_log' );
delete_option( 'mrsh_last_scan' );
wp_clear_scheduled_hook( 'mrsh_weekly_scan' );
delete_option( 'mrsh_rewrite_state' );
delete_option( 'mrsh_ver' );
