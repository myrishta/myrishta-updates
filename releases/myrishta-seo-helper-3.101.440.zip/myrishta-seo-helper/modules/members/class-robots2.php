<?php
/**
 * Three helpers in one file (3.101.240):
 *  1. Family link: a member makes a private, read-only preview link for parents. Expires, can be stopped any time.
 *  2. Matches email: every few days a member gets up to 3 good matches with the reasons. One-click unsubscribe.
 *  3. Weekly report: every Monday the owner gets one short email with the week in numbers and what to do first.
 * Everything is free, runs through the mail queue (so the host mailbox is never flooded) and has manual buttons.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Robots2 {

	const OPT  = 'mrsh_robots2';
	const CRON = 'mrsh_robots2_tick';
	const SLUG = 'mrsh-matchrep';
	const WK   = 'mrsh_robots2_week';
	const LAST = 'mrsh_robots2_last';

	public static function o() {
		$o = get_option( self::OPT, array() );
		return array_merge( array( 'mm_on' => 1, 'mm_gap' => 3, 'mm_max' => 40, 'mm_min' => 55, 'wk_on' => 1, 'wk_to' => '', 'fam_on' => 1 ), is_array( $o ) ? $o : array() );
	}

	public static function init() {
		add_action( self::CRON, array( __CLASS__, 'tick' ) );
		add_action( 'init', function () {
			if ( ! wp_next_scheduled( self::CRON ) ) {
				wp_schedule_event( time() + 900, 'hourly', self::CRON );
			}
			self::unsub();
			self::links();
		} );
		add_action( 'mrt_account_extra', array( __CLASS__, 'account' ), 46 );
		add_action( 'admin_post_mrsh_famlink', array( __CLASS__, 'fam_save' ) );
		if ( is_admin() ) {
			add_action( 'admin_menu', array( __CLASS__, 'menu' ), 45 );
			foreach ( array( 'save', 'mm', 'wk' ) as $a ) {
				add_action( 'admin_post_mrsh_r2_' . $a, array( __CLASS__, 'h_' . $a ) );
			}
		}
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Matches and report', 'Matches and report', 'manage_options', self::SLUG, array( __CLASS__, 'page' ) );
	}

	/* ================= 1. family link ================= */

	private static function my_profile( $uid ) {
		$p = get_posts( array( 'post_type' => MRSH_Members::CPT, 'author' => $uid, 'post_status' => array( 'publish', 'pending', 'draft', 'private' ), 'numberposts' => 1 ) );
		return $p ? $p[0] : null;
	}

	public static function account( $uid ) {
		if ( ! $uid || empty( self::o()['fam_on'] ) ) {
			return;
		}
		$tok = (string) get_user_meta( $uid, 'mrt_fam_tok', true );
		$exp = (int) get_user_meta( $uid, 'mrt_fam_exp', true );
		$live = $tok && $exp > time();
		echo '<div class="wrap narrow"><div class="box"><h3>Share with my family</h3>';
		echo '<p class="mut">Make a private link for your parents or guardian. They see a short, read-only preview of your profile: no phone number, no messages. The link stops working after 30 days, or when you stop it.</p>';
		if ( ! empty( $_GET['famlink'] ) ) { // phpcs:ignore
			echo '<div class="note2">Done.</div>';
		}
		if ( $live ) {
			$url = home_url( '/?mrsh_fam=' . (int) $uid . '&t=' . rawurlencode( $tok ) );
			echo '<p><input type="text" readonly value="' . esc_url( $url ) . '" style="width:100%" onclick="this.select()"></p><p class="mut">Valid until ' . esc_html( wp_date( 'j M Y', $exp ) ) . '. Send it on WhatsApp.</p>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:flex;gap:8px;flex-wrap:wrap"><input type="hidden" name="action" value="mrsh_famlink">' . wp_nonce_field( 'mrsh_famlink', '_wpnonce', true, false );
		echo '<button class="btn" name="do" value="make">' . ( $live ? 'Make a new link' : 'Make a family link' ) . '</button>';
		if ( $live ) {
			echo '<button class="btn" name="do" value="stop">Stop sharing</button>';
		}
		echo '</form></div></div>';
	}

	public static function fam_save() {
		if ( ! is_user_logged_in() ) {
			wp_die( 'Please log in.' );
		}
		check_admin_referer( 'mrsh_famlink' );
		$uid = get_current_user_id();
		if ( 'stop' === ( $_POST['do'] ?? '' ) ) { // phpcs:ignore
			delete_user_meta( $uid, 'mrt_fam_tok' );
			delete_user_meta( $uid, 'mrt_fam_exp' );
		} else {
			update_user_meta( $uid, 'mrt_fam_tok', wp_generate_password( 24, false ) );
			update_user_meta( $uid, 'mrt_fam_exp', time() + 30 * DAY_IN_SECONDS );
		}
		wp_safe_redirect( add_query_arg( 'famlink', '1', wp_get_referer() ?: home_url( '/' ) ) );
		exit;
	}

	private static function links() {
		if ( empty( $_GET['mrsh_fam'] ) || empty( $_GET['t'] ) ) { // phpcs:ignore
			return;
		}
		$uid = absint( $_GET['mrsh_fam'] ); // phpcs:ignore
		$t   = sanitize_text_field( wp_unslash( $_GET['t'] ) ); // phpcs:ignore
		$tok = (string) get_user_meta( $uid, 'mrt_fam_tok', true );
		$exp = (int) get_user_meta( $uid, 'mrt_fam_exp', true );
		nocache_headers();
		header( 'X-Robots-Tag: noindex, nofollow' );
		if ( ! $tok || $exp < time() || ! hash_equals( $tok, $t ) ) {
			wp_die( 'This family link is not valid any more. Please ask for a new one. / یہ لنک اب کام نہیں کرتا۔', 'Link', array( 'response' => 403 ) );
		}
		$p = self::my_profile( $uid );
		if ( ! $p ) {
			wp_die( 'No profile yet.', 'Profile', array( 'response' => 404 ) );
		}
		$u    = get_userdata( $uid );
		$age  = (int) get_post_meta( $p->ID, 'daage', true );
		$img  = get_the_post_thumbnail_url( $p->ID, 'medium' );
		$text = wp_trim_words( wp_strip_all_tags( $p->post_content ?: $p->post_excerpt ), 90 );
		$site = get_bloginfo( 'name' );
		echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Family preview | ' . esc_html( $site ) . '</title></head>';
		echo '<body style="margin:0;background:#f3f4f8;font-family:Arial,Helvetica,sans-serif"><div style="max-width:520px;margin:0 auto;padding:16px"><div style="background:#fff;border-radius:16px;overflow:hidden;border:1px solid #e5e7eb">';
		echo '<div style="background:linear-gradient(110deg,#e11d74,#7c3aed);color:#fff;padding:14px 20px;font-weight:800;font-size:18px">' . esc_html( $site ) . ' &middot; Family preview</div>';
		if ( $img ) {
			echo '<img src="' . esc_url( $img ) . '" alt="" style="display:block;width:100%;max-height:360px;object-fit:cover">';
		}
		echo '<div style="padding:18px 20px;color:#1f2430"><h1 style="margin:0 0 4px;font-size:22px">' . esc_html( $p->post_title ) . '</h1>';
		echo '<div style="color:#6b7280;margin-bottom:10px">' . ( $age ? esc_html( $age ) . ' years' : '' ) . ( $u ? ' &middot; shared by ' . esc_html( $u->display_name ) : '' ) . '</div>';
		echo '<p style="line-height:1.7;margin:0 0 12px">' . esc_html( $text ) . '</p>';
		echo '<p style="font-size:13px;color:#9a3412;background:#fff7ed;border:1px solid #fed7aa;border-radius:10px;padding:10px;line-height:1.5">This is a private preview, valid for a limited time. Please do not forward it. Contact details are not shown here. / یہ نجی پیش منظر ہے، آگے نہ بھیجیں۔</p>';
		echo '</div></div></div></body></html>';
		exit;
	}

	/* ================= 2. matches email ================= */

	private static function unsub_key( $uid ) {
		return hash_hmac( 'sha256', 'mmoff' . $uid, wp_salt() );
	}

	public static function unsub() {
		if ( empty( $_GET['mrsh_mm_off'] ) ) { // phpcs:ignore
			return;
		}
		$uid = absint( $_GET['mrsh_mm_off'] ); // phpcs:ignore
		if ( $uid && hash_equals( self::unsub_key( $uid ), sanitize_text_field( wp_unslash( $_GET['k'] ?? '' ) ) ) ) { // phpcs:ignore
			update_user_meta( $uid, 'mrsh_mm_off', 1 );
			wp_die( 'You will not get match emails any more. / آپ کو اب میچ ای میل نہیں ملیں گی۔', 'Unsubscribed', array( 'response' => 200 ) );
		}
	}

	/** Send match emails now. Returns the number queued. */
	public static function run_matches( $limit ) {
		if ( ! class_exists( 'MRSH_Match' ) || ! class_exists( 'MRSH_Mailq' ) || ! class_exists( 'MRSH_Members' ) ) {
			return 0;
		}
		$o      = self::o();
		$gap    = max( 1, (int) $o['mm_gap'] ) * DAY_IN_SECONDS;
		$queued = 0;
		$mine   = get_posts( array( 'post_type' => MRSH_Members::CPT, 'post_status' => 'publish', 'numberposts' => 80, 'orderby' => 'rand', 'meta_query' => array( array( 'key' => 'daage', 'compare' => 'EXISTS' ) ) ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		foreach ( $mine as $a ) {
			if ( $queued >= $limit ) {
				break;
			}
			$uid = (int) $a->post_author;
			$u   = get_userdata( $uid );
			if ( ! $u || ! is_email( $u->user_email ) || get_user_meta( $uid, 'mrsh_mm_off', true ) || get_user_meta( $uid, 'mrsh_mail_bad', true ) || user_can( $uid, 'manage_options' ) ) {
				continue;
			}
			if ( time() - (int) get_user_meta( $uid, 'mrsh_mm_last', true ) < $gap ) {
				continue;
			}
			$sent = (array) get_user_meta( $uid, 'mrsh_mm_sent', true );
			$best = array();
			foreach ( MRSH_Members::matches( $a, 24 ) as $b ) {
				if ( in_array( $b->ID, $sent, true ) ) {
					continue;
				}
				$s = MRSH_Match::score( $a, $b );
				if ( empty( $s[2] ) && (int) $s[0] >= (int) $o['mm_min'] ) {
					$best[] = array( $s[0], $b, (array) $s[1] );
				}
			}
			if ( ! $best ) {
				continue;
			}
			usort( $best, static function ( $x, $y ) {
				return $y[0] <=> $x[0];
			} );
			$best = array_slice( $best, 0, 3 );
			$text = "Assalam o Alaikum " . $u->display_name . ",\n\nThese profiles may suit you:\n\n";
			foreach ( $best as $m ) {
				$text  .= '- ' . $m[1]->post_title . ' (' . (int) $m[0] . "% match)\n";
				$text  .= $m[2] ? '  ' . implode( '; ', array_slice( $m[2], 0, 3 ) ) . "\n" : '';
				$text  .= '  ' . get_permalink( $m[1] ) . "\n\n";
				$sent[] = $m[1]->ID;
			}
			$un    = home_url( '/?mrsh_mm_off=' . $uid . '&k=' . self::unsub_key( $uid ) );
			$text .= "Open a profile and send your interest if you like it. Take your time and involve your family.\n\nآپ کے لیے چند مناسب رشتے اوپر دیے گئے ہیں۔\n\nStop these emails: " . $un . "\n";
			$id    = MRSH_Mailq::add( $u->user_email, 'Matches for you | آپ کے لیے رشتے', $text, array( 'kind' => 'matches', 'uid' => $uid, 'headers' => array( 'List-Unsubscribe: <' . $un . '>' ) ) );
			if ( $id ) {
				update_user_meta( $uid, 'mrsh_mm_sent', array_slice( array_values( array_unique( array_map( 'intval', $sent ) ) ), -60 ) );
				update_user_meta( $uid, 'mrsh_mm_last', time() );
				++$queued;
			}
		}
		$st = get_option( 'mrsh_robots2_mm', array() );
		$st = is_array( $st ) ? $st : array();
		$st[ wp_date( 'Y-m-d' ) ] = (int) ( $st[ wp_date( 'Y-m-d' ) ] ?? 0 ) + $queued;
		update_option( 'mrsh_robots2_mm', array_slice( $st, -14, null, true ), false );
		return $queued;
	}

	/* ================= 3. weekly report ================= */

	public static function stats() {
		global $wpdb;
		$wk  = gmdate( 'Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS );
		$s   = array();
		$s['New members']        = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->users} WHERE user_registered >= %s", $wk ) ); // phpcs:ignore
		$s['New profiles']       = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type=%s AND post_status='publish' AND post_date_gmt >= %s", class_exists( 'MRSH_Members' ) ? MRSH_Members::CPT : 'listing_type', $wk ) ); // phpcs:ignore
		$s['Profiles in total']  = (int) wp_count_posts( class_exists( 'MRSH_Members' ) ? MRSH_Members::CPT : 'listing_type' )->publish;
		$s['Guides published']   = (int) wp_count_posts( 'post' )->publish;
		$mm = (array) get_option( 'mrsh_robots2_mm', array() );
		$n  = 0;
		foreach ( $mm as $d => $c ) {
			if ( $d >= wp_date( 'Y-m-d', time() - 7 * DAY_IN_SECONDS ) ) {
				$n += (int) $c;
			}
		}
		$s['Match emails sent'] = $n;
		$fx = array( 'auto_fixed' => 0, 'needs_approval' => 0, 'needs_claude' => 0 );
		if ( class_exists( 'MRSH_Fixer' ) ) {
			foreach ( MRSH_Fixer::tickets() as $t ) {
				if ( isset( $fx[ $t['status'] ] ) ) {
					++$fx[ $t['status'] ];
				}
			}
		}
		$s['Fixed by the robot']      = $fx['auto_fixed'];
		$s['Waiting for your OK']     = $fx['needs_approval'];
		$s['Waiting for Claude fixer'] = $fx['needs_claude'];
		$bad = 0;
		foreach ( (array) get_option( 'mrsh_smtp_log', array() ) as $r ) {
			if ( is_array( $r ) && time() - (int) ( $r['t'] ?? 0 ) < 7 * DAY_IN_SECONDS ) {
				++$bad;
			}
		}
		$s['Mail problems'] = $bad;
		$sb = get_option( 'mrsh_secbot_last', array() );
		if ( ! empty( $sb['rows'] ) ) {
			$p = 0;
			foreach ( $sb['rows'] as $r ) {
				if ( 'pass' === $r[0] ) {
					++$p;
				}
			}
			$s['Security checks passing'] = $p . ' of ' . count( $sb['rows'] );
		}
		return $s;
	}

	public static function send_report( $force = false ) {
		$o    = self::o();
		$to   = is_email( $o['wk_to'] ) ? $o['wk_to'] : get_option( 'admin_email' );
		$s    = self::stats();
		$prev = (array) get_option( self::WK, array() );
		$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$body = $site . ' - week in numbers (' . wp_date( 'j M Y' ) . ")\n\n";
		$facts = '';
		foreach ( $s as $k => $v ) {
			$d = '';
			if ( isset( $prev[ $k ] ) && is_numeric( $v ) && is_numeric( $prev[ $k ] ) ) {
				$diff = $v - $prev[ $k ];
				$d    = $diff ? ' (' . ( $diff > 0 ? '+' : '' ) . $diff . ' vs last week)' : ' (same as last week)';
			}
			$body  .= $k . ': ' . $v . $d . "\n";
			$facts .= $k . ': ' . $v . $d . "\n";
		}
		$tips = '';
		if ( class_exists( 'MRSH_AIHub' ) && MRSH_AIHub::ready() ) {
			$a = MRSH_AIHub::ask( 'You help the owner of a free, non-profit Pakistani matrimonial website. From the weekly numbers, write at most 3 short action points for a busy owner, each starting with "- ". Use only the numbers given; invent nothing; no jargon.', $facts, 220 );
			if ( ! is_wp_error( $a ) ) {
				$tips = wp_strip_all_tags( $a );
			}
		}
		if ( '' === $tips ) {
			$tips = $s['Waiting for your OK'] ? "- Open the Auto-Fixer: " . $s['Waiting for your OK'] . ' item(s) wait for your OK.' : '- Nothing needs you. The robots are handling it.';
		}
		$body .= "\nWhat to do first:\n" . $tips . "\n\nOpen the dashboard: " . admin_url( 'admin.php?page=myrishta-seo' ) . "\n";
		$ok = wp_mail( $to, '[' . $site . '] Weekly report', $body );
		update_option( self::WK, array_map( static function ( $v ) {
			return is_numeric( $v ) ? $v : 0;
		}, $s ), false );
		update_option( self::LAST, array( 't' => time(), 'body' => $body ), false );
		return (bool) $ok;
	}

	/* ================= schedule ================= */

	public static function tick() {
		$o = self::o();
		$h = (int) wp_date( 'G' );
		if ( ! empty( $o['mm_on'] ) && $h >= 10 && $h <= 20 && get_transient( 'mrsh_r2_mm_run' ) === false ) {
			set_transient( 'mrsh_r2_mm_run', 1, 5 * HOUR_IN_SECONDS );
			self::run_matches( max( 1, (int) $o['mm_max'] ) );
		}
		if ( ! empty( $o['wk_on'] ) && 1 === (int) wp_date( 'N' ) && $h >= 7 && get_transient( 'mrsh_r2_wk_run' ) === false ) {
			set_transient( 'mrsh_r2_wk_run', 1, 6 * DAY_IN_SECONDS );
			self::send_report();
		}
	}

	/* ================= admin ================= */

	private static function guard( $n ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( $n );
	}

	private static function back( $m ) {
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&done=' . rawurlencode( $m ) ) );
		exit;
	}

	public static function h_save() {
		self::guard( 'mrsh_r2_save' );
		update_option( self::OPT, array(
			'mm_on'  => empty( $_POST['mm_on'] ) ? 0 : 1, // phpcs:ignore
			'mm_gap' => min( 14, max( 1, absint( $_POST['mm_gap'] ?? 3 ) ) ), // phpcs:ignore
			'mm_max' => min( 150, max( 1, absint( $_POST['mm_max'] ?? 40 ) ) ), // phpcs:ignore
			'mm_min' => min( 95, max( 30, absint( $_POST['mm_min'] ?? 55 ) ) ), // phpcs:ignore
			'wk_on'  => empty( $_POST['wk_on'] ) ? 0 : 1, // phpcs:ignore
			'wk_to'  => sanitize_email( wp_unslash( $_POST['wk_to'] ?? '' ) ), // phpcs:ignore
			'fam_on' => empty( $_POST['fam_on'] ) ? 0 : 1, // phpcs:ignore
		), false );
		self::back( 'Saved.' );
	}

	public static function h_mm() {
		self::guard( 'mrsh_r2_mm' );
		$n = self::run_matches( max( 1, (int) self::o()['mm_max'] ) );
		self::back( $n . ' match email(s) were put in the mail queue.' );
	}

	public static function h_wk() {
		self::guard( 'mrsh_r2_wk' );
		self::back( self::send_report( true ) ? 'Weekly report sent.' : 'The report could not be sent. Check Email delivery.' );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$o    = self::o();
		$post = esc_url( admin_url( 'admin-post.php' ) );
		$mm   = (array) get_option( 'mrsh_robots2_mm', array() );
		$week = 0;
		foreach ( $mm as $d => $c ) {
			if ( $d >= wp_date( 'Y-m-d', time() - 7 * DAY_IN_SECONDS ) ) {
				$week += (int) $c;
			}
		}
		$last = get_option( self::LAST, array() );
		MRSH_Admin::open( 'Matches and weekly report', 'Members get good matches by email. You get one short report every Monday. Members can also share a private preview with their family.' );
		if ( ! empty( $_GET['done'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( wp_unslash( $_GET['done'] ) ) . '</p></div>'; // phpcs:ignore
		}
		echo '<div class="mrsh-grid mrsh-grid-4">';
		echo MRSH_Admin::stat( 'Match emails', $o['mm_on'] ? 'On' : 'Off', 'every ' . (int) $o['mm_gap'] . ' days per member' ); // phpcs:ignore
		echo MRSH_Admin::stat( 'Sent this week', $week, 'through the mail queue' ); // phpcs:ignore
		echo MRSH_Admin::stat( 'Weekly report', $o['wk_on'] ? 'On' : 'Off', 'Mondays' ); // phpcs:ignore
		echo MRSH_Admin::stat( 'Family link', $o['fam_on'] ? 'On' : 'Off', 'in My account' ); // phpcs:ignore
		echo '</div>';
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Actions</h2></div><div class="mrsh-actions">';
		foreach ( array( 'mm' => array( 'Send match emails now', true ), 'wk' => array( 'Send the weekly report now', false ) ) as $a => $d ) {
			echo '<form method="post" action="' . $post . '" class="mrsh-inline">';
			wp_nonce_field( 'mrsh_r2_' . $a );
			echo '<input type="hidden" name="action" value="mrsh_r2_' . esc_attr( $a ) . '"><button class="button' . ( $d[1] ? ' button-primary' : '' ) . '">' . esc_html( $d[0] ) . '</button></form> ';
		}
		echo '</div></div>';
		if ( ! empty( $last['body'] ) ) {
			echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Last weekly report (' . esc_html( human_time_diff( (int) $last['t'] ) ) . ' ago)</h2></div><div style="white-space:pre-line">' . esc_html( $last['body'] ) . '</div></div>';
		}
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Settings</h2></div><form method="post" action="' . $post . '">';
		wp_nonce_field( 'mrsh_r2_save' );
		echo '<input type="hidden" name="action" value="mrsh_r2_save">';
		echo '<p><label><input type="checkbox" name="mm_on" value="1"' . checked( $o['mm_on'], 1, false ) . '> Email members up to 3 good matches (with the reasons and a one-click unsubscribe)</label></p>';
		echo '<p>Gap between emails to the same member (days) <input type="number" name="mm_gap" min="1" max="14" value="' . (int) $o['mm_gap'] . '" style="width:70px"> &nbsp; Most emails per day <input type="number" name="mm_max" min="1" max="150" value="' . (int) $o['mm_max'] . '" style="width:70px"> &nbsp; Minimum match % <input type="number" name="mm_min" min="30" max="95" value="' . (int) $o['mm_min'] . '" style="width:70px"></p>';
		echo '<p><label><input type="checkbox" name="wk_on" value="1"' . checked( $o['wk_on'], 1, false ) . '> Send me the weekly report on Monday</label> &nbsp; to <input type="email" name="wk_to" value="' . esc_attr( $o['wk_to'] ) . '" placeholder="' . esc_attr( get_option( 'admin_email' ) ) . '" style="width:260px"></p>';
		echo '<p><label><input type="checkbox" name="fam_on" value="1"' . checked( $o['fam_on'], 1, false ) . '> Let members make a private family preview link</label></p>';
		echo '<button class="button button-primary">Save</button></form></div>';
		MRSH_Admin::close();
	}
}
MRSH_Robots2::init();
