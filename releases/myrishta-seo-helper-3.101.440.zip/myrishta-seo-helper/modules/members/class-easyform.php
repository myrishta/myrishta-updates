<?php
/**
 * Easy profile form (3.101.261).
 * The add / edit profile page is one long form. For people who find that hard, this turns it into one short step at a time:
 * a progress bar, big Back / Next buttons, plain English and Urdu help for each step, a check of each step before moving on, and a
 * draft kept on the phone so nothing is lost. New profiles (and anyone who signed up with Google) get the steps automatically;
 * members editing an old profile see everything on one page, with a switch to the steps. The form and its saving are not changed.
 * Switch: option `mrsh_easyform` (on by default).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Easyform {

	const OPT = 'mrsh_easyform';

	public static function on() {
		$o = get_option( self::OPT, null );
		return null === $o ? true : (bool) $o;
	}

	public static function init() {
		add_action( 'wp_footer', array( __CLASS__, 'out' ), 99 );
	}

	public static function out() {
		if ( ! self::on() || ! is_user_logged_in() || ! is_page() ) {
			return;
		}
		$tpl = (string) get_page_template_slug( get_queried_object_id() );
		if ( 'page-add-listing.php' !== $tpl ) {
			return;
		}
		$tips = array(
			'your name'           => array( 'Start with your first name. It takes about 5 minutes in all.', 'پہلے اپنا نام لکھیں۔ سارا کام تقریباً 5 منٹ کا ہے۔' ),
			'about you'           => array( 'The basics. Choose from the lists, or type your answer.', 'بنیادی معلومات۔ فہرست سے چنیں یا خود لکھیں۔' ),
			'religion and family' => array( 'Families look at this first. Answer honestly.', 'گھرانے سب سے پہلے یہی دیکھتے ہیں۔ سچ لکھیں۔' ),
			'education and work'  => array( 'Your studies and your job.', 'آپ کی تعلیم اور کام۔' ),
			'where you live'      => array( 'Tap "Detect my country and city" to fill this for you.', '"Detect" کا بٹن دبائیں، ملک اور شہر خود بھر جائے گا۔' ),
			'contact'             => array( 'Only for sign-in and safety. It is never shown to other members.', 'صرف لاگ ان اور حفاظت کے لیے۔ کسی کو دکھایا نہیں جاتا۔' ),
			'more details'        => array( 'Optional. You can skip this step.', 'اختیاری۔ آپ اسے چھوڑ سکتے ہیں۔' ),
			'your story'          => array( 'Write 3 or 4 lines about yourself and the partner you want. No phone numbers or links.', '3 یا 4 سطریں اپنے بارے میں اور مطلوبہ رشتے کے بارے میں لکھیں۔ فون نمبر یا لنک نہ لکھیں۔' ),
			'photos'              => array( 'A clear face photo gets many more replies. You can add it later.', 'صاف تصویر پر بہت زیادہ جواب آتے ہیں۔ آپ بعد میں بھی لگا سکتے ہیں۔' ),
		);
		?>
<style id="mrt-ez-css">
.ez-bar{position:sticky;top:0;z-index:30;background:#fff;border-bottom:1px solid #e7e2f3;margin:0 -4px 16px;padding:10px 4px 12px}
.ez-top{display:flex;justify-content:space-between;align-items:center;gap:10px;font-size:14px;color:#4a3d6b}
.ez-top b{color:#2b1f4a;font-size:15px}
.ez-trk{height:10px;border-radius:99px;background:#eee9f8;margin-top:8px;overflow:hidden}
.ez-fill{height:100%;width:0;border-radius:99px;background:linear-gradient(90deg,#7c3aed,#db2777);transition:width .3s}
.ez-tip{background:#f6f2ff;border:1px solid #e3d9fb;border-radius:12px;padding:12px 14px;margin:0 0 16px;font-size:15px;line-height:1.5;color:#2b1f4a}
.ez-tip span{display:block;direction:rtl;text-align:right;margin-top:6px;font-size:16px}
.ez-nav{display:flex;gap:12px;margin:22px 0 4px;position:sticky;bottom:0;background:#fff;padding:12px 0;border-top:1px solid #e7e2f3;z-index:20}
.ez-nav button{flex:1;min-height:52px;font-size:17px;border-radius:12px;cursor:pointer;font-weight:600;border:2px solid #7c3aed}
.ez-back{background:#fff;color:#5b21b6}
.ez-next{background:#7c3aed;color:#fff}
.ez-nav button[hidden]{display:none}
.ez-sw{display:block;text-align:center;margin:10px 0 0;font-size:14px}
.ez-sw a{color:#5b21b6;text-decoration:underline;cursor:pointer}
form.pf.ez-on .fsec{display:none}
form.pf.ez-on .fsec.ez-cur{display:block}
form.pf.ez-on input,form.pf.ez-on select,form.pf.ez-on textarea{font-size:17px;min-height:48px}
form.pf:not(.ez-on) .ez-nav,.ez-all .ez-bar,.ez-all .ez-tip{display:none}
.ez-bad{outline:2px solid #dc2626!important}
</style>
<script id="mrt-ez-js">
(function(){
var TIPS=<?php echo wp_json_encode( $tips ); ?>;
var f=document.querySelector('form.pf');if(!f)return;
var pid=(f.querySelector('input[name=pid]')||{}).value||'0';
var KEY='mrt_ez_'+location.pathname;
var pref=null;try{pref=localStorage.getItem('mrt_ez_mode')}catch(e){}
var want=pref?pref==='steps':pid==='0';
// step 0: the name box that sits above the sections
var first=f.querySelector('input[name=title]');
var secs=[].slice.call(f.querySelectorAll(':scope > .fsec'));
if(!secs.length)return;
if(first){var lab=first.previousElementSibling;var s0=document.createElement('section');s0.className='fsec ez-first';s0.innerHTML='<h2>Your name</h2>';if(lab&&lab.tagName==='LABEL')s0.appendChild(lab);s0.appendChild(first);f.insertBefore(s0,secs[0]);secs.unshift(s0)}
// the agree box and the save button belong to the last step
var last=secs[secs.length-1],after=[],n=last.nextElementSibling;
while(n){var nx=n.nextElementSibling;if(!n.classList.contains('ez-nav')&&!n.classList.contains('ez-bar')&&n.tagName!=='INPUT'&&n.tagName!=='SCRIPT'&&n.tagName!=='STYLE'){after.push(n)}n=nx}
after.forEach(function(x){last.appendChild(x)});
var bar=document.createElement('div');bar.className='ez-bar';bar.innerHTML='<div class="ez-top"><span><b class="ez-t"></b></span><span class="ez-c"></span></div><div class="ez-trk"><div class="ez-fill"></div></div>';
f.insertBefore(bar,f.firstChild);
var nav=document.createElement('div');nav.className='ez-nav';nav.innerHTML='<button type="button" class="ez-back">Back / پیچھے</button><button type="button" class="ez-next">Next / آگے</button>';
f.appendChild(nav);
var sw=document.createElement('div');sw.className='ez-sw';f.parentNode.insertBefore(sw,f.nextSibling);
var cur=0,T=secs.length;
function title(s){var h=s.querySelector('h2');return h?h.textContent.trim():''}
secs.forEach(function(s){var k=title(s).toLowerCase().replace(/\s*\(.*$/,'');var t=null;for(var x in TIPS){if(k.indexOf(x)===0){t=TIPS[x];break}}if(t){var d=document.createElement('div');d.className='ez-tip';d.innerHTML='<div></div><span lang="ur" dir="rtl"></span>';d.firstChild.textContent=t[0];d.lastChild.textContent=t[1];var h=s.querySelector('h2');h.parentNode.insertBefore(d,h.nextSibling)}});
function show(i){cur=Math.max(0,Math.min(T-1,i));secs.forEach(function(s,j){s.classList.toggle('ez-cur',j===cur)});
bar.querySelector('.ez-t').textContent=title(secs[cur]);bar.querySelector('.ez-c').textContent='Step '+(cur+1)+' of '+T+' / مرحلہ '+(cur+1)+' از '+T;bar.querySelector('.ez-fill').style.width=Math.round((cur+1)/T*100)+'%';
nav.querySelector('.ez-back').hidden=cur===0;nav.querySelector('.ez-next').hidden=cur===T-1;
try{window.scrollTo({top:Math.max(0,f.getBoundingClientRect().top+window.pageYOffset-70),behavior:'smooth'})}catch(e){window.scrollTo(0,0)}}
function ok(){var bad=null;[].slice.call(secs[cur].querySelectorAll('input,select,textarea')).forEach(function(x){x.classList.remove('ez-bad');if(x.type==='hidden'||x.disabled)return;if(!x.checkValidity()){x.classList.add('ez-bad');if(!bad)bad=x}});
if(bad){bad.focus();try{bad.reportValidity()}catch(e){}return false}return true}
nav.querySelector('.ez-next').addEventListener('click',function(){if(ok())show(cur+1)});
nav.querySelector('.ez-back').addEventListener('click',function(){show(cur-1)});
f.addEventListener('submit',function(e){// a missed answer sends the person back to that step
var els=[].slice.call(f.querySelectorAll('input,select,textarea'));for(var i=0;i<els.length;i++){var x=els[i];if(x.type!=='hidden'&&!x.disabled&&!x.checkValidity()){var s=x.closest('.fsec'),j=secs.indexOf(s);if(j>-1&&f.classList.contains('ez-on')){show(j);setTimeout(function(){x.focus();try{x.reportValidity()}catch(e){}},50)}return}}
try{localStorage.removeItem(KEY)}catch(e){}});
// draft kept on the phone
function save(){try{var d={};[].slice.call(f.querySelectorAll('input,select,textarea')).forEach(function(x){if(!x.name||x.type==='file'||x.type==='hidden'||x.type==='password'||x.type==='checkbox')return;d[x.name]=x.value});localStorage.setItem(KEY,JSON.stringify(d))}catch(e){}}
function load(){try{var d=JSON.parse(localStorage.getItem(KEY)||'null');if(!d||pid!=='0')return;[].slice.call(f.querySelectorAll('input,select,textarea')).forEach(function(x){if(x.name&&d[x.name]&&!x.value&&x.type!=='file'&&x.type!=='checkbox'&&x.type!=='hidden'){x.value=d[x.name]}})}catch(e){}}
load();f.addEventListener('change',save);f.addEventListener('input',function(){clearTimeout(window.__ezt);window.__ezt=setTimeout(save,600)});
function mode(on){f.classList.toggle('ez-on',on);document.body.classList.toggle('ez-all',!on);try{localStorage.setItem('mrt_ez_mode',on?'steps':'all')}catch(e){}
sw.innerHTML=on?'<a>Show the whole form on one page / پورا فارم ایک صفحے پر دیکھیں</a>':'<a>Fill it step by step (easier) / قدم بہ قدم بھریں (آسان)</a>';sw.firstChild.onclick=function(){mode(!on)};if(on)show(cur)}
mode(want);
})();
</script>
		<?php
	}
}
MRSH_Easyform::init();
