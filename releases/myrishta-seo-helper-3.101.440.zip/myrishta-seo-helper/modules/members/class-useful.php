<?php
/**
 * Member self-service extras in My account:
 * - "Take a break / Come back": a member hides their own profile (for example when engaged or married) and brings it back later,
 *   everything is kept. One friendly email after 90 days asks if they are looking again.
 * - "Download my data": the member's own profile and details as a file.
 * - "Meeting safely" checklist (English and Urdu).
 * Admin side: a paused member shows as Retired in Member manager (same flag).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Useful {
	const CRON = 'mrsh_useful_tick';

	public static function init() {
		add_action( 'mrt_account_extra', array( __CLASS__, 'cards' ), 30 );
		add_action( 'admin_post_mrsh_self_pause', array( __CLASS__, 'pause' ) );
		add_action( 'admin_post_mrsh_self_resume', array( __CLASS__, 'resume' ) );
		add_action( 'admin_post_mrsh_self_export', array( __CLASS__, 'export' ) );
		add_action( self::CRON, array( __CLASS__, 'tick' ) );
		add_action( 'init', array( __CLASS__, 'one_list' ), 99 );
		add_action( 'template_redirect', array( __CLASS__, 'old_signup_links' ), 1 );
		add_action( 'init', function () {
			if ( ! wp_next_scheduled( self::CRON ) ) {
				wp_schedule_event( time() + 1800, 'daily', self::CRON );
			}
		} );
	}

	/** Common sign-up addresses that people type or old links use. Only when the page would otherwise be "not found". */
	public static function old_signup_links() {
		if ( ! is_404() ) {
			return;
		}
		$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ), '/' ); // phpcs:ignore
		$path = strtolower( $path );
		$map  = array(
			'register' => 'add-listing', 'join' => 'add-listing', 'sign-up' => 'add-listing', 'signup' => 'add-listing', 'sign_up' => 'add-listing',
			'create-account' => 'add-listing', 'join-now' => 'add-listing', 'join-free' => 'add-listing', 'register-now' => 'add-listing', 'new-account' => 'add-listing',
			'sign-in' => 'login', 'signin' => 'login', 'log-in' => 'login',
		);
		if ( isset( $map[ $path ] ) ) {
			wp_safe_redirect( home_url( '/' . $map[ $path ] . '/' ), 301 );
			exit;
		}
	}

	/** A search as a stable key, so the same search saved twice is seen as one. */
	public static function key( $q ) {
		parse_str( ltrim( (string) $q, '?' ), $g );
		foreach ( array( 'post_type', 'paged', 'pwa', 'lang', 'mrt', 'n' ) as $k ) {
			unset( $g[ $k ] );
		}
		$g = array_filter( (array) $g, function ( $v ) {
			return '' !== $v && null !== $v;
		} );
		ksort( $g );
		return http_build_query( $g );
	}

	public static function same_search( $a, $b ) {
		return self::key( $a ) === self::key( $b );
	}

	/** Saved searches used to live in three places. Merge them into the one list (once per member) and show one button. */
	public static function one_list() {
		remove_action( 'wp_footer', array( 'MRSH_Ideas', 'ss_button' ) ); // the second "Save this search" button
		$uid = get_current_user_id();
		if ( ! $uid || is_admin() || get_user_meta( $uid, 'mrsh_ss_one', true ) ) {
			return;
		}
		$all = array();
		foreach ( array_filter( (array) get_user_meta( $uid, 'mrt_searches', true ), 'is_array' ) as $e ) {
			if ( ! empty( $e['q'] ) ) {
				$all[] = array( 'q' => $e['q'], 'd' => $e['d'] ?? current_time( 'mysql' ) );
			}
		}
		foreach ( array_filter( (array) get_user_meta( $uid, 'mrt_saved_search', true ), 'is_array' ) as $e ) {
			if ( ! empty( $e['q'] ) ) {
				$all[] = array( 'q' => $e['q'], 'd' => isset( $e['t'] ) ? gmdate( 'Y-m-d H:i:s', (int) $e['t'] ) : current_time( 'mysql' ) );
			}
		}
		foreach ( array_filter( (array) get_user_meta( $uid, 'mrt_saved', true ), 'is_array' ) as $e ) {
			if ( ! empty( $e['qs'] ) && is_array( $e['qs'] ) ) {
				$all[] = array( 'q' => 'post_type=listing_type&' . http_build_query( $e['qs'] ), 'd' => current_time( 'mysql' ) );
			}
		}
		$seen = array();
		$out  = array();
		foreach ( $all as $e ) {
			$k = self::key( $e['q'] );
			if ( '' === $k || isset( $seen[ $k ] ) ) {
				continue;
			}
			$seen[ $k ] = 1;
			$out[]      = $e;
		}
		$out = array_slice( $out, 0, 10 );
		if ( $out ) {
			update_user_meta( $uid, 'mrt_searches', $out );
		}
		delete_user_meta( $uid, 'mrt_saved_search' );
		delete_user_meta( $uid, 'mrt_saved' );
		update_user_meta( $uid, 'mrsh_ss_one', 1 );
	}

	private static function guard( $action ) {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( wp_login_url() );
			exit;
		}
		check_admin_referer( $action );
		return get_current_user_id();
	}

	private static function back( $note ) {
		$ref = wp_get_referer();
		wp_safe_redirect( add_query_arg( 'mrsh_note', rawurlencode( $note ), $ref ? $ref : home_url( '/' ) ) );
		exit;
	}

	private static function blocked( $uid ) {
		return get_user_meta( $uid, 'mrt_banned', true ) || get_user_meta( $uid, 'mrsh_perm_ban', true );
	}

	public static function pause() {
		$uid = self::guard( 'mrsh_self_pause' );
		if ( user_can( $uid, 'manage_options' ) || self::blocked( $uid ) || ! class_exists( 'MRSH_Members' ) ) {
			self::back( 'Not possible.' );
		}
		$p = MRSH_Members::my_profile( $uid );
		if ( $p ) {
			update_user_meta( $uid, 'mrsh_pause_prev', $p->post_status );
			wp_update_post( array( 'ID' => $p->ID, 'post_status' => 'draft' ) );
			delete_post_meta( $p->ID, 'featured' );
			if ( class_exists( 'MRSH_Manage' ) ) {
				MRSH_Manage::purge_member( $uid, $p->ID );
			}
		}
		update_user_meta( $uid, 'mrsh_retired', time() );
		update_user_meta( $uid, 'mrsh_self_paused', 1 );
		update_user_meta( $uid, 'mrsh_mm_off', 1 );
		delete_user_meta( $uid, 'mrsh_back_nudge' );
		self::back( 'Your profile is hidden. Nothing is deleted. Press "Bring my profile back" whenever you are ready.' );
	}

	public static function resume() {
		$uid = self::guard( 'mrsh_self_resume' );
		if ( self::blocked( $uid ) ) {
			self::back( 'Not possible.' );
		}
		$p = class_exists( 'MRSH_Members' ) ? MRSH_Members::my_profile( $uid ) : null;
		if ( $p && 'publish' === get_user_meta( $uid, 'mrsh_pause_prev', true ) ) {
			wp_update_post( array( 'ID' => $p->ID, 'post_status' => 'publish' ) );
			if ( class_exists( 'MRSH_Manage' ) ) {
				MRSH_Manage::purge_member( $uid, $p->ID );
			}
		}
		delete_user_meta( $uid, 'mrsh_retired' );
		delete_user_meta( $uid, 'mrsh_self_paused' );
		delete_user_meta( $uid, 'mrsh_mm_off' );
		delete_user_meta( $uid, 'mrsh_pause_prev' );
		self::back( 'Welcome back. Please check your profile details and update anything that changed.' );
	}

	public static function export() {
		$uid = self::guard( 'mrsh_self_export' );
		$u   = get_userdata( $uid );
		if ( ! $u ) {
			exit;
		}
		$out = array( 'site' => get_bloginfo( 'name' ), 'made' => gmdate( 'c' ), 'account' => array( 'name' => $u->display_name, 'email' => $u->user_email, 'joined' => mysql2date( 'j F Y', $u->user_registered ) ) );
		$p   = class_exists( 'MRSH_Members' ) ? MRSH_Members::my_profile( $uid ) : null;
		if ( $p ) {
			$meta = array();
			foreach ( (array) get_post_meta( $p->ID ) as $k => $v ) {
				if ( 0 !== strpos( $k, '_' ) ) {
					$meta[ $k ] = maybe_unserialize( $v[0] );
				}
			}
			$out['profile'] = array( 'title' => $p->post_title, 'about' => wp_strip_all_tags( $p->post_content ), 'status' => $p->post_status, 'details' => $meta );
		}
		if ( class_exists( 'MRSH_Switch' ) && ! MRSH_Switch::on( 'mydata' ) ) {
			wp_die( 'This is switched off.' );
		}
		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		$rows = function ( $arr ) {
			$h = '';
			foreach ( (array) $arr as $k => $v ) {
				if ( is_array( $v ) ) {
					$v = implode( ', ', array_map( 'strval', $v ) );
				}
				if ( '' === trim( (string) $v ) ) {
					continue;
				}
				$h .= '<tr><th>' . esc_html( ucwords( str_replace( array( '_', '-' ), ' ', (string) $k ) ) ) . '</th><td>' . esc_html( (string) $v ) . '</td></tr>';
			}
			return $h;
		};
		echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>My data - ' . esc_html( $out['site'] ) . '</title><style>body{font-family:system-ui,Arial,sans-serif;max-width:760px;margin:0 auto;padding:20px;color:#2a1f24}h1{font-size:24px;margin:0 0 4px}h2{font-size:18px;margin:26px 0 8px;border-bottom:2px solid #9b1b4b;padding-bottom:4px}table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:8px 10px;border-bottom:1px solid #e6dde1;vertical-align:top;font-size:15px}th{width:38%;color:#6b5560;font-weight:600}.n{color:#6b5560;font-size:13px}.b{display:inline-block;margin:14px 0;padding:12px 22px;background:#9b1b4b;color:#fff;border:0;border-radius:10px;font-size:16px;cursor:pointer}@media print{.b{display:none}body{padding:0}}</style></head><body>';
		echo '<h1>' . esc_html( $out['site'] ) . '</h1><p class="n">A copy of your details, made on ' . esc_html( wp_date( 'j F Y, g:i a' ) ) . '. Keep it safe: it has your personal information.</p><button class="b" onclick="window.print()">Print this page</button>';
		echo '<h2>Account</h2><table>' . $rows( $out['account'] ) . '</table>'; // phpcs:ignore
		if ( ! empty( $out['profile'] ) ) {
			$pr  = $out['profile'];
			$det = self::pretty_details( $p, (array) $pr['details'] );
			echo '<h2>Profile</h2><table>' . $rows( array( 'name' => $pr['title'], 'status' => ucfirst( 'publish' === $pr['status'] ? 'live' : $pr['status'] ), 'about' => $pr['about'] ) ) . self::rows_plain( $det ) . '</table>'; // phpcs:ignore
		}
		echo '</body></html>';
		exit;
	}


	/** Flatten any value (including arrays) to readable text. */
	private static function flat( $v ) {
		if ( is_array( $v ) ) {
			$o = array();
			foreach ( $v as $x ) {
				$t = self::flat( $x );
				if ( '' !== $t ) {
					$o[] = $t;
				}
			}
			return implode( ', ', $o );
		}
		if ( is_object( $v ) ) {
			return '';
		}
		$t = trim( (string) $v );
		if ( preg_match( '/^[a-z0-9]+(_[a-z0-9]+)+$/', $t ) ) {
			$t = ucfirst( str_replace( '_', ' ', $t ) ); // prefer_not_to_say -> Prefer not to say
		}
		return $t;
	}

	private static function rows_plain( $arr ) {
		$h = '';
		foreach ( $arr as $k => $v ) {
			if ( '' === trim( (string) $v ) ) {
				continue;
			}
			$h .= '<tr><th>' . esc_html( $k ) . '</th><td>' . esc_html( $v ) . '</td></tr>';
		}
		return $h;
	}

	private static function norm( $v ) {
		return strtolower( trim( preg_replace( '/[^a-z0-9]+/i', ' ', (string) $v ) ) );
	}

	/** Match every saved value to the form field it belongs to. Old saves can sit under shifted keys, so a value goes to the field whose choices contain it. Returns array( fields, field index => value, loose values ). */
	public static function assign( $p, $meta ) {
		$fields = class_exists( 'MRSH_Members' ) ? MRSH_Members::form_fields() : array();
		$loc    = class_exists( 'MRSH_Members' ) ? MRSH_Members::loc_of( $p->ID ) : array( '', '' );
		$byk    = array();
		foreach ( $fields as $i => $f ) {
			$byk[ $f['key'] ] = $i;
		}
		$res   = array(); // field index => value
		$loose = array(); // values with no clear field
		$generic = array( 'prefer not to say', 'prefer to not say', 'na', 'n a', 'none' );
		foreach ( $meta as $k => $v ) {
			$t = self::flat( $v );
			$t = trim( str_replace( '_', ' ', $t ) );
			if ( '' === $t || preg_match( '/^(map_|mrsh|mrt|lat|lng|geo|_)|_tax$|nonce|token|views|hits|plan|^winks$|^msg_|rate|gift|interest/i', $k ) || strlen( $t ) > 900 || preg_match( '/^\d{9,}$/', $t ) ) {
				continue;
			}
			$nv = self::norm( $t );
			$ix = isset( $byk[ $k ] ) ? $byk[ $k ] : -1;
			if ( $ix >= 0 ) {
				$f  = $fields[ $ix ];
				$ok = ! $f['opts'] || in_array( $nv, array_map( array( __CLASS__, 'norm' ), $f['opts'] ), true );
				if ( 'taxonomy' === $f['type'] && $f['opts'] ) {
					continue;
				}
				if ( $ok && ( ! preg_match( '/phone|mobile|contact|whatsapp/i', $f['label'] ) || preg_match( '/^[+0-9][0-9 +-]{6,}$/', $t ) ) ) {
					$res[ $ix ] = $t;
					continue;
				}
			}
			// shifted or unknown key: find the one field (not yet filled) whose choices hold this value
			$hit = array();
			if ( ! in_array( $nv, $generic, true ) ) {
				foreach ( $fields as $j => $f ) {
					if ( $f['opts'] && 'taxonomy' !== $f['type'] && ! isset( $res[ $j ] ) && in_array( $nv, array_map( array( __CLASS__, 'norm' ), $f['opts'] ), true ) ) {
						$hit[] = $j;
					}
				}
			}
			if ( 1 === count( $hit ) ) {
				$res[ $hit[0] ] = $t;
			} elseif ( ! in_array( $nv, $generic, true ) ) {
				$loose[ $k ] = $t;
			}
		}
		return array( $fields, $res, $loose, $loc );
	}

	/** For the profile page: dbkey => the right value. */
	public static function by_key( $pid ) {
		$p = get_post( $pid );
		if ( ! $p ) {
			return array();
		}
		$meta = array();
		foreach ( (array) get_post_meta( $pid ) as $k => $v ) {
			if ( 0 !== strpos( $k, '_' ) ) {
				$meta[ $k ] = maybe_unserialize( $v[0] );
			}
		}
		list( $fields, $res ) = self::assign( $p, $meta );
		$o = array();
		foreach ( $res as $i => $v ) {
			$o[ $fields[ $i ]['key'] ] = $v;
		}
		return $o;
	}

	private static function pretty_details( $p, $meta ) {
		list( $fields, $res, $loose, $loc ) = self::assign( $p, $meta );
		$out = array();
		foreach ( $fields as $i => $f ) {
			$val = isset( $res[ $i ] ) ? $res[ $i ] : '';
			if ( '' === $val && 'taxonomy' === $f['type'] ) {
				$tx = MRSH_Members::tax_for( $f['label'] );
				if ( $tx && taxonomy_exists( $tx ) ) {
					$tt  = wp_get_object_terms( $p->ID, $tx, array( 'fields' => 'names' ) );
					$val = is_wp_error( $tt ) ? '' : implode( ', ', $tt );
				}
			}
			if ( preg_match( '/^\s*(education and occupation|what do i look like\?|my habbits)\s*$/i', $f['label'] ) ) {
				continue; // section headings
			}
			if ( '' !== $val ) {
				$out[ str_replace( array( 'Nationalty', 'Satus', 'Habbits' ), array( 'Nationality', 'Status', 'Habits' ), trim( $f['label'] ) ) ] = $val;
			}
		}
		if ( $loc[0] ) {
			$out['Country'] = $loc[0];
		}
		if ( $loc[1] ) {
			$out['City'] = $loc[1];
		}
		$names = array( 'lookinggen' => 'Partner age from', 'daage' => 'Age' );
		foreach ( $loose as $k => $t ) {
			if ( isset( $names[ $k ] ) ) {
				$out[ $names[ $k ] ] = $t;
			} elseif ( preg_match( '/^\d\s*ft/i', $t ) || preg_match( '/\binch\b/i', $t ) ) {
				$out['Height'] = $t;
			} elseif ( strlen( $t ) > 25 ) {
				$out['What I am looking for'] = $t;
			}
		}
		return $out;
	}

	private static function form( $action, $label, $cls, $confirm = '' ) {
		return '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"' . ( $confirm ? ' onsubmit="return confirm(\'' . esc_js( $confirm ) . '\')"' : '' ) . '><input type="hidden" name="action" value="' . esc_attr( $action ) . '">' . wp_nonce_field( $action, '_wpnonce', true, false ) . '<button class="mu-btn ' . esc_attr( $cls ) . '" type="submit">' . esc_html( $label ) . '</button></form>';
	}

	private static function css() {
		return '<style>
.mu-card{--b1:#9b1b4b;--b2:#6e1230;position:relative;background:#fff;border:1px solid #eadde3;border-radius:18px;padding:20px 20px 18px;box-shadow:0 2px 6px rgba(110,18,48,.05),0 10px 28px rgba(110,18,48,.07);transition:transform .25s ease,box-shadow .25s ease;overflow:hidden;color:#2b1a22}
.mu-card:hover{transform:translateY(-2px);box-shadow:0 4px 10px rgba(110,18,48,.08),0 16px 36px rgba(110,18,48,.12)}
.mu-card:before{content:"";position:absolute;left:0;top:0;bottom:0;width:4px;background:linear-gradient(180deg,var(--b1),var(--b2))}
.mu-card.g:before{background:linear-gradient(180deg,#12a375,#0a7a3d)}.mu-card.v:before{background:linear-gradient(180deg,#7c3aed,#4c1d95)}
.mu-hd{display:flex;align-items:center;gap:12px;margin:0 0 10px}
.mu-ic{flex:none;width:42px;height:42px;border-radius:12px;display:grid;place-items:center;color:#fff;background:linear-gradient(135deg,var(--b1),var(--b2));box-shadow:0 6px 14px rgba(110,18,48,.25)}
.g .mu-ic{background:linear-gradient(135deg,#12a375,#0a7a3d);box-shadow:0 6px 14px rgba(10,122,61,.25)}.v .mu-ic{background:linear-gradient(135deg,#7c3aed,#4c1d95);box-shadow:0 6px 14px rgba(76,29,149,.25)}
.mu-ic svg{width:22px;height:22px}
.mu-card h3{margin:0;font-size:1.05rem;line-height:1.25;letter-spacing:.1px}.mu-card h3 small{display:block;font-weight:500;color:#8a6a76;font-size:.82rem;margin-top:2px}
.mu-card p{margin:0 0 14px;color:#5b4a52;font-size:.92rem;line-height:1.6}.mu-card p .ur,.mu-ur{display:block;margin-top:4px;color:#8a6a76;direction:rtl;text-align:right}
.mu-st{display:inline-flex;align-items:center;gap:6px;font-size:.78rem;font-weight:700;padding:4px 11px;border-radius:99px;margin-bottom:10px}.mu-st.on{background:#d1fae5;color:#065f46}.mu-st.off{background:#fef3c7;color:#92400e}.mu-st.x{background:#fee2e2;color:#991b1b}
.mu-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;border:0;cursor:pointer;font:inherit;font-weight:700;font-size:.92rem;padding:11px 20px;border-radius:999px;color:#fff;background:linear-gradient(135deg,var(--b1),var(--b2));box-shadow:0 6px 16px rgba(110,18,48,.28);transition:transform .15s ease,box-shadow .2s ease,filter .2s ease}
.mu-btn:hover{transform:translateY(-1px);filter:brightness(1.07);box-shadow:0 10px 22px rgba(110,18,48,.34)}.mu-btn:active{transform:none}.mu-btn:focus-visible{outline:3px solid #f7c6d8;outline-offset:2px}
.mu-btn.soft{background:#fff;color:var(--b2);border:1.5px solid #e2c6d1;box-shadow:none}.mu-btn.soft:hover{background:#fdf3f6;box-shadow:none}
.mu-btn.ok{background:linear-gradient(135deg,#12a375,#0a7a3d);box-shadow:0 6px 16px rgba(10,122,61,.28)}
.mu-ck{list-style:none;margin:0;padding:0;display:grid;gap:9px}.mu-ck li{display:flex;gap:10px;align-items:flex-start;font-size:.9rem;line-height:1.5;color:#3a2a31}.mu-ck li i{flex:none;width:20px;height:20px;border-radius:50%;background:#d1fae5;color:#047857;display:grid;place-items:center;font-style:normal;font-size:.72rem;font-weight:800;margin-top:1px}.mu-ck li span{color:#8a6a76;display:block;font-size:.8rem}
.mu-note{margin:0 0 12px;padding:12px 16px;border-radius:14px;background:#ecfdf5;border:1px solid #a7f3d0;color:#065f46;font-weight:600;font-size:.92rem}
@media(max-width:480px){.mu-card{padding:16px 16px 16px 18px}.mu-btn{width:100%}}
@media(prefers-reduced-motion:reduce){.mu-card,.mu-btn{transition:none}.mu-card:hover{transform:none}}
</style>';
	}

	public static function cards( $uid ) {
		if ( ! $uid || user_can( $uid, 'manage_options' ) ) {
			return;
		}
		$ic = array(
			'pause' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M10 9v6M14 9v6"/></svg>',
			'shield' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l8 3v6c0 4.5-3.4 8-8 9-4.6-1-8-4.5-8-9V6z"/><path d="M9 12l2 2 4-4"/></svg>',
			'file' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4v11M7 11l5 5 5-5M5 20h14"/></svg>',
		);
		echo self::css(); // phpcs:ignore
		if ( ! empty( $_GET['mrsh_note'] ) ) { // phpcs:ignore
			echo '<div class="mu-note">' . esc_html( sanitize_text_field( wp_unslash( $_GET['mrsh_note'] ) ) ) . '</div>'; // phpcs:ignore
		}
		$paused  = (bool) get_user_meta( $uid, 'mrsh_retired', true );
		$blocked = self::blocked( $uid );
		$show_break = ! class_exists( 'MRSH_Switch' ) || MRSH_Switch::on( 'pause' ) || $paused || $blocked || get_user_meta( $uid, 'mrsh_self_paused', true );
		if ( $show_break ) {
		echo '<section class="mu-card"><div class="mu-hd"><span class="mu-ic">' . $ic['pause'] . '</span><h3>Take a break or close your search<small>وقفہ لیں یا تلاش مکمل کریں</small></h3></div>'; // phpcs:ignore
		if ( $blocked ) {
			echo '<span class="mu-st x">Account closed</span>';
		} elseif ( $paused ) {
			echo '<span class="mu-st off">&#9208; Your profile is hidden</span><p>Nobody can see it, and everything you wrote is safe. Looking again, or a second marriage in the future? Bring it back in one click.<span class="mu-ur">آپ کی پروفائل چھپی ہوئی ہے۔ دوبارہ شروع کرنے کے لیے بٹن دبائیں۔</span></p>' . self::form( 'mrsh_self_resume', 'Bring my profile back', 'ok' ); // phpcs:ignore
		} else {
			echo '<span class="mu-st on">&#9679; Your profile is visible</span><p>Engaged, married, or just need time? Hide your profile with one click. Nothing is deleted, and you can bring it back later.<span class="mu-ur">رشتہ طے ہو گیا یا وقفہ چاہیے؟ پروفائل چھپا دیں، کچھ ڈیلیٹ نہیں ہوگا۔</span></p>' . self::form( 'mrsh_self_pause', 'Hide my profile', 'soft', 'Hide your profile now? You can bring it back at any time.' ); // phpcs:ignore
		}
		echo '</section>';
		}

		$tips = array(
			array( 'Meet first with your family, at home or in a public place.', 'پہلی ملاقات خاندان کے ساتھ کریں۔' ),
			array( 'Never send money, gifts or bank details before the Nikah.', 'نکاح سے پہلے پیسے نہ بھیجیں۔' ),
			array( 'Check job and family through people you trust.', 'معلومات خود تصدیق کریں۔' ),
			array( 'Keep chatting on this site until you trust them.', 'اعتماد ہونے تک رابطہ یہیں رکھیں۔' ),
			array( 'Someone asks for money? Press Report on their profile.', 'پیسے مانگنے والے کو رپورٹ کریں۔' ),
		);
		echo '<section class="mu-card g"><div class="mu-hd"><span class="mu-ic">' . $ic['shield'] . '</span><h3>Meeting safely<small>محفوظ ملاقات</small></h3></div><ul class="mu-ck">'; // phpcs:ignore
		foreach ( $tips as $t ) {
			echo '<li><i>&#10003;</i><div>' . esc_html( $t[0] ) . '<span>' . esc_html( $t[1] ) . '</span></div></li>';
		}
		echo '</ul></section>';

		if ( ! class_exists( 'MRSH_Switch' ) || MRSH_Switch::on( 'mydata' ) ) {
			echo '<section class="mu-card v"><div class="mu-hd"><span class="mu-ic">' . $ic['file'] . '</span><h3>My data<small>میرا ڈیٹا</small></h3></div><p>Open a clean page with your profile and account details, and print it.</p>' . self::form( 'mrsh_self_export', 'Open printable copy', 'soft' ) . '</section>'; // phpcs:ignore
		}
	}

	/** Once, after 90 days of a break: one gentle email. At most 20 a day. */
	/** An honest "people are looking" card: counts real visitors of the other gender from the profile's own viewer list. */
	public static function nudge( $mine ) {
		if ( ! $mine || 'publish' !== $mine->post_status || ! class_exists( 'MRSH_Match' ) ) {
			return;
		}
		$me   = MRSH_Match::gender( $mine->ID );
		$want = 'Male' === $me ? 'Female' : ( 'Female' === $me ? 'Male' : '' );
		if ( '' === $want ) {
			return;
		}
		$ids = array_unique( array_map( 'intval', array_filter( (array) get_post_meta( $mine->ID, 'mrt_viewers', true ) ) ) );
		$opp = 0;
		$all = 0;
		foreach ( $ids as $vu ) {
			$vp = class_exists( 'MRSH_Members' ) ? MRSH_Members::my_profile( $vu ) : null;
			if ( ! $vp ) {
				continue;
			}
			++$all;
			if ( MRSH_Match::gender( $vp->ID ) === $want ) {
				++$opp;
			}
		}
		$who  = 'Female' === $want ? 'women' : 'men';
		$link = esc_url( add_query_arg( 'tab', 'views', get_permalink() ) );
		if ( $opp > 0 ) {
			$head = ( $all > 0 && $opp * 2 > $all ) ? 'Most of your visitors are ' . $who : (int) $opp . ' ' . $who . ' viewed your profile';
			$txt  = $opp . ' ' . $who . ' have looked at your profile. Keep it fresh and reply quickly to the messages you get.';
			$ur   = 'Female' === $want ? 'کئی خواتین نے آپ کی پروفائل دیکھی ہے۔' : 'کئی مردوں نے آپ کی پروفائل دیکھی ہے۔';
			$btn  = 'See who viewed you';
		} else {
			$head = 'Be seen by more ' . $who;
			$txt  = 'Your profile is live. A clear photo and a complete profile bring the most visits from ' . $who . '.';
			$ur   = 'صاف تصویر اور مکمل پروفائل پر زیادہ لوگ آتے ہیں۔';
			$btn  = 'Improve my profile';
			$link = esc_url( add_query_arg( 'edit', $mine->ID, home_url( '/add-listing/' ) ) );
		}
		echo self::css(); // phpcs:ignore
		echo '<section class="mu-card g" style="margin:0 0 16px"><div class="mu-hd"><span class="mu-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg></span><h3>' . esc_html( $head ) . '</h3></div><p>' . esc_html( $txt ) . '<span class="mu-ur">' . esc_html( $ur ) . '</span></p><a class="mu-btn ok" href="' . $link . '">' . esc_html( $btn ) . '</a></section>'; // phpcs:ignore
	}

	public static function tick() {
		if ( ! class_exists( 'MRSH_Mailq' ) ) {
			return;
		}
		$ids = get_users( array( 'meta_key' => 'mrsh_self_paused', 'meta_value' => '1', 'fields' => 'ID', 'number' => 100 ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		$n   = 0;
		foreach ( $ids as $uid ) {
			$uid = (int) $uid;
			$t   = (int) get_user_meta( $uid, 'mrsh_retired', true );
			if ( $n >= 20 || ! $t || time() - $t < 90 * DAY_IN_SECONDS || get_user_meta( $uid, 'mrsh_back_nudge', true ) || self::blocked( $uid ) ) {
				continue;
			}
			$u = get_userdata( $uid );
			if ( ! $u ) {
				continue;
			}
			update_user_meta( $uid, 'mrsh_back_nudge', time() );
			MRSH_Mailq::add( $u->user_email, 'Are you looking again? Your profile is safe', "Assalam o Alaikum " . $u->display_name . ",\n\nYour profile on " . get_bloginfo( 'name' ) . " has been hidden since you took a break. Everything is saved. If you are looking again, sign in and press \"Bring my profile back\" in My account.\n\nIf you are happily settled, we wish you every blessing. You do not need to do anything.\n\n" . home_url( '/' ), array( 'kind' => 'nudge', 'uid' => $uid ) );
			++$n;
		}
	}
}

MRSH_Useful::init();
