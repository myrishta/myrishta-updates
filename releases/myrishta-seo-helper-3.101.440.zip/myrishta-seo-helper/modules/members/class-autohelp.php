<?php
/**
 * Autopilot help desk: the robots ask for support when they need something.
 *
 * - MRSH_Help::ask( key, title, detail, steps, kind ) is how any robot says "I need help". kind = 'owner' (needs your input or a choice) or
 *   'fixer' (needs a developer or Claude). The same problem is asked once, never repeated.
 * - Each request goes to the Inbox and one email, with plain steps. A reminder email comes after 3 days if it is still open.
 * - Every request has a ready brief that can be pasted to Claude (or any developer) so the fix needs no explaining.
 * - Watchers: plugin errors, AI not ready, background tasks stopped. Option: mrsh_help.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Help {

	const OPT = 'mrsh_help';

	private static function all() {
		$o = get_option( self::OPT, array() );
		return is_array( $o ) ? $o : array();
	}

	private static function save( $o ) {
		if ( count( $o ) > 60 ) {
			uasort( $o, function ( $a, $b ) {
				return (int) $b['t'] <=> (int) $a['t'];
			} );
			$o = array_slice( $o, 0, 60, true );
		}
		update_option( self::OPT, $o, false );
	}

	public static function open_count() {
		$n = 0;
		foreach ( self::all() as $r ) {
			if ( 'open' === $r['status'] ) {
				$n++;
			}
		}
		return $n;
	}

	/** A robot asks for support. Safe to call many times: one open request per key. */
	public static function ask( $key, $title, $detail = '', $steps = array(), $kind = 'owner' ) {
		$key = sanitize_key( $key );
		$o   = self::all();
		if ( isset( $o[ $key ] ) && in_array( $o[ $key ]['status'], array( 'open', 'snoozed' ), true ) ) {
			$o[ $key ]['detail'] = mb_substr( (string) $detail, 0, 1500 );
			self::save( $o );
			return false;
		}
		$o[ $key ] = array(
			't'      => time(),
			'mail'   => 0,
			'kind'   => 'fixer' === $kind ? 'fixer' : 'owner',
			'title'  => mb_substr( wp_strip_all_tags( (string) $title ), 0, 140 ),
			'detail' => mb_substr( (string) $detail, 0, 1500 ),
			'steps'  => array_slice( array_map( 'strval', (array) $steps ), 0, 8 ),
			'status' => 'open',
			'until'  => 0,
		);
		self::save( $o );
		if ( class_exists( 'MRSH_Attn' ) ) {
			MRSH_Attn::add( 'autopilot', 0, 'Autopilot needs help: ' . $o[ $key ]['title'], admin_url( 'admin.php?page=mrsh-autopilot' ) );
		}
		if ( class_exists( 'MRSH_Autopilot' ) ) {
			MRSH_Autopilot::log( 'Help', 'Asked for support: ' . $o[ $key ]['title'] );
		}
		self::mail( $key, false );
		return true;
	}

	/** The robot found the problem gone: close the request by itself. */
	public static function resolve( $key ) {
		$key = sanitize_key( $key );
		$o   = self::all();
		if ( isset( $o[ $key ] ) && 'done' !== $o[ $key ]['status'] ) {
			$o[ $key ]['status'] = 'done';
			$o[ $key ]['t']      = time();
			self::save( $o );
		}
	}

	private static function mail( $key, $reminder ) {
		$o = self::all();
		if ( empty( $o[ $key ] ) || ! class_exists( 'MRSH_Mailq' ) ) {
			return;
		}
		$r  = $o[ $key ];
		$b  = ( $reminder ? "Reminder: this is still waiting.\n\n" : '' ) . $r['title'] . "\n\n" . $r['detail'] . "\n\n";
		$b .= 'owner' === $r['kind'] ? "What only you can do:\n" : "This needs a developer or Claude. Open the link below, press Copy brief and paste it to Claude:\n";
		foreach ( $r['steps'] as $i => $s ) {
			$b .= ( $i + 1 ) . '. ' . $s . "\n";
		}
		$b .= "\nOpen: " . admin_url( 'admin.php?page=mrsh-autopilot' ) . "\n";
		MRSH_Mailq::add( get_option( 'admin_email' ), 'My Rishta Autopilot needs help: ' . $r['title'], $b, array( 'kind' => 'ticket_ai' ) );
		$o[ $key ]['mail'] = time();
		self::save( $o );
	}

	/** Text to paste to Claude or a developer: everything needed, nothing to explain. */
	public static function brief( $key ) {
		$o = self::all();
		if ( empty( $o[ $key ] ) ) {
			return '';
		}
		$r = $o[ $key ];
		$t  = "Please fix this on myrishta.pk (WordPress). Work only inside the plugin myrishta-seo-helper and the theme myrishta; no extra plugins. Keep everything that works; nothing may be lost.\n\n";
		$t .= 'Problem: ' . $r['title'] . "\n" . $r['detail'] . "\n\n";
		$t .= 'Site: ' . home_url() . ' | Plugin ' . ( defined( 'MRSH_VERSION' ) ? MRSH_VERSION : '?' ) . ' | WordPress ' . get_bloginfo( 'version' ) . ' | PHP ' . PHP_VERSION . "\n";
		$er = get_option( 'mrsh_errors', array() );
		if ( is_array( $er ) && $er ) {
			$t .= "\nRecent errors:\n";
			foreach ( array_slice( $er, 0, 6 ) as $e ) {
				$t .= ' - ' . ( $e['m'] ?? '' ) . ( ! empty( $e['f'] ) ? ' @ ' . $e['f'] . ':' . (int) ( $e['l'] ?? 0 ) : '' ) . "\n";
			}
		}
		return $t;
	}

	public static function init() {
		add_action( 'admin_post_mrsh_help_act', array( __CLASS__, 'act' ) );
		add_action( 'admin_post_mrsh_help_new', array( __CLASS__, 'add_note' ) );
		add_action( 'admin_init', array( __CLASS__, 'beat_check' ) );
	}

	/** Called by the Autopilot every 5 minutes. */
	public static function tick() {
		update_option( 'mrsh_ap_beat', time(), false );
		self::resolve( 'cron' );
		if ( get_transient( 'mrsh_help_watch' ) ) {
			return;
		}
		set_transient( 'mrsh_help_watch', 1, 30 * MINUTE_IN_SECONDS );
		self::triage_inbox();
		// Plugin errors the safety layer caught.
		$er = get_option( 'mrsh_errors', array() );
		if ( is_array( $er ) && count( $er ) ) {
			$first = reset( $er );
			self::ask( 'errors', count( $er ) . ' plugin error(s) were caught and contained', 'The site stays up, but something inside the plugin keeps failing. First: ' . ( $first['m'] ?? '' ), array( 'Open the Claude chat you use for this site.', 'Press Copy brief below and paste it.', 'Upload the fixed zip Claude gives you.' ), 'fixer' );
		} else {
			self::resolve( 'errors' );
		}
		// AI helper not ready.
		if ( class_exists( 'MRSH_Autopilot' ) && MRSH_Autopilot::on() && class_exists( 'MRSH_AIHub' ) ) {
			if ( ! MRSH_AIHub::ready() ) {
				self::ask( 'ai', 'The AI helper is not ready', 'Tickets and profile checks cannot be answered by the AI until it is connected.', array( 'Open AI Assistant (Autopilot page, AI helper).', 'Check that the Claude key is saved and the balance is above zero.', 'Press Test: it should say OK.' ), 'owner' );
			} else {
				self::resolve( 'ai' );
			}
		}
		// Emails that failed: put them back in the queue every 6 hours; after 3 rounds still failing, ask for help.
		if ( class_exists( 'MRSH_Mailq' ) && method_exists( 'MRSH_Mailq', 'failed_count' ) ) {
			$fc = MRSH_Mailq::failed_count();
			if ( ! $fc ) {
				update_option( 'mrsh_help_mrounds', 0, false );
				self::resolve( 'mail' );
			} elseif ( time() - (int) get_option( 'mrsh_help_mlast', 0 ) > 6 * HOUR_IN_SECONDS ) {
				$n = (int) get_option( 'mrsh_help_mrounds', 0 );
				update_option( 'mrsh_help_mlast', time(), false );
				update_option( 'mrsh_help_mrounds', $n + 1, false );
				$q = MRSH_Mailq::requeue_failed();
				if ( $q && class_exists( 'MRSH_Autopilot' ) ) {
					MRSH_Autopilot::log( 'Email', 'Tried ' . $q . ' failed email(s) again.' );
				}
				if ( $n >= 3 ) {
					self::ask( 'mail', $fc . ' email(s) keep failing to send', 'The robot tried again several times. Often the email password or the sender address needs a look.', array( 'Open Email delivery and press Send a test email.', 'If it fails, press Copy brief and paste it to Claude.' ), 'fixer' );
				}
			}
		}
		// Reminders: still open after 3 days, at most one email a day.
		foreach ( self::all() as $k => $r ) {
			if ( 'snoozed' === $r['status'] && time() > (int) $r['until'] ) {
				$o            = self::all();
				$o[ $k ]['status'] = 'open';
				self::save( $o );
				$r['status'] = 'open';
			}
			if ( 'open' === $r['status'] && time() - max( (int) $r['t'], (int) $r['mail'] ) > 3 * DAY_IN_SECONDS ) {
				self::mail( $k, true );
			}
		}
	}

	/** The AI reads the Inbox like an agent: false alarms are closed with a reason, real problems stay for you. Max 5 per run, each item once. */
	public static function triage_inbox() {
		if ( ! class_exists( 'MRSH_Attn' ) || ! class_exists( 'MRSH_AIHub' ) || ! MRSH_AIHub::ready() || ! class_exists( 'MRSH_Autopilot' ) || ! MRSH_Autopilot::can( 'profiles' ) ) {
			return;
		}
		$closed = 0;
		foreach ( MRSH_Attn::unreviewed( array( 'profile_text' ), 5 ) as $e ) {
			$sys = "You help the owner of a free Pakistani rishta website review warnings. A warning says a member's profile text may have a problem. "
				. "Reply with exactly one word: DISMISS if it is clearly harmless, a test, or a false alarm (for example the text is just letters like 'xyz' or a normal sentence with no contact details, money request or abuse); KEEP if a person should look (real phone number, request for money, WhatsApp or contact request, scam, rude or sexual words, unclear).";
			$a = MRSH_AIHub::ask( $sys, (string) $e['text'], 12 );
			if ( is_wp_error( $a ) ) {
				break;
			}
			$d = false !== stripos( (string) $a, 'DISMISS' ) && false === stripos( (string) $a, 'KEEP' );
			MRSH_Attn::reviewed( $e['t'], $d );
			if ( $d ) {
				$closed++;
				MRSH_Autopilot::log( 'Inbox', 'Closed a false alarm: ' . mb_substr( (string) $e['text'], 0, 90 ) );
			}
		}
	}

	/** Background tasks that stopped are noticed when you open the admin. */
	public static function beat_check() {
		if ( ! current_user_can( 'manage_options' ) || ! class_exists( 'MRSH_Autopilot' ) || ! MRSH_Autopilot::on() ) {
			return;
		}
		$b = (int) get_option( 'mrsh_ap_beat', 0 );
		if ( $b && time() - $b > 3 * HOUR_IN_SECONDS ) {
			self::ask( 'cron', 'The background robots have not run for ' . (int) round( ( time() - $b ) / HOUR_IN_SECONDS ) . ' hours', 'The Autopilot does its work every 5 minutes. Something stopped WordPress background tasks (often hosting cron or a very busy server).', array( 'In the hosting panel, check that WordPress cron or a cron job for wp-cron.php is running.', 'If unsure, press Copy brief and paste it to Claude.' ), 'fixer' );
		}
	}

	private static function guard( $n ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.', '', array( 'response' => 403 ) );
		}
		check_admin_referer( $n );
	}

	public static function act() {
		self::guard( 'mrsh_help_act' );
		$k  = sanitize_key( wp_unslash( $_POST['k'] ?? '' ) ); // phpcs:ignore
		$w  = sanitize_key( wp_unslash( $_POST['w'] ?? '' ) ); // phpcs:ignore
		$o  = self::all();
		if ( isset( $o[ $k ] ) ) {
			if ( 'done' === $w ) {
				$o[ $k ]['status'] = 'done';
			} elseif ( 'later' === $w ) {
				$o[ $k ]['status'] = 'snoozed';
				$o[ $k ]['until']  = time() + 3 * DAY_IN_SECONDS;
			} elseif ( 'del' === $w ) {
				unset( $o[ $k ] );
			}
			self::save( $o );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-autopilot&help=1' ) );
		exit;
	}

	/** You can also ask for help yourself: write what you need, and a ready brief is made. */
	public static function add_note() {
		self::guard( 'mrsh_help_new' );
		$t = sanitize_textarea_field( wp_unslash( $_POST['note'] ?? '' ) ); // phpcs:ignore
		if ( '' !== trim( $t ) ) {
			self::ask( 'note_' . substr( md5( $t . time() ), 0, 8 ), mb_substr( $t, 0, 80 ), $t, array( 'Press Copy brief and paste it to Claude.' ), 'fixer' );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-autopilot&help=1' ) );
		exit;
	}

	/** Card on the Autopilot page. */
	public static function card() {
		$o    = self::all();
		$post = admin_url( 'admin-post.php' );
		$open = array_filter( $o, function ( $r ) {
			return in_array( $r['status'], array( 'open', 'snoozed' ), true );
		} );
		echo '<div class="mx-card"><h2 class="mx-h">Autopilot help desk</h2>';
		echo '<p class="mx-sub">When a robot meets something it cannot do alone, it asks here, in your Inbox and by email, once. Nothing is lost while it waits.</p>';
		if ( ! $open ) {
			echo '<p><b style="color:#139a86">&#10003; Nothing is waiting for you or for a developer.</b></p>';
		}
		foreach ( $open as $k => $r ) {
			$tag = 'owner' === $r['kind'] ? '<span style="background:#fef3c7;color:#92400e;border-radius:99px;padding:2px 10px;font-size:12px">Needs you</span>' : '<span style="background:#ede9fe;color:#5b21b6;border-radius:99px;padding:2px 10px;font-size:12px">Needs Claude or a developer</span>';
			echo '<div style="border:1px solid #e5e7eb;border-radius:12px;padding:12px 14px;margin:10px 0"><div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center"><b>' . esc_html( $r['title'] ) . '</b> ' . $tag . ( 'snoozed' === $r['status'] ? ' <small>(reminds again in a few days)</small>' : '' ) . '</div>';
			if ( $r['detail'] ) {
				echo '<p style="margin:6px 0">' . esc_html( $r['detail'] ) . '</p>';
			}
			if ( $r['steps'] ) {
				echo '<ol style="margin:6px 0 6px 18px">';
				foreach ( $r['steps'] as $s ) {
					echo '<li>' . esc_html( $s ) . '</li>';
				}
				echo '</ol>';
			}
			$id = 'mrshb_' . esc_attr( $k );
			echo '<textarea id="' . $id . '" readonly rows="3" style="width:100%;font-size:12px;display:none">' . esc_textarea( self::brief( $k ) ) . '</textarea>';
			echo '<form method="post" action="' . esc_url( $post ) . '" style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px"><input type="hidden" name="action" value="mrsh_help_act"><input type="hidden" name="k" value="' . esc_attr( $k ) . '">' . wp_nonce_field( 'mrsh_help_act', '_wpnonce', true, false );
			echo '<button type="button" class="mx-btn" onclick="var t=document.getElementById(\'' . $id . '\');t.style.display=\'block\';t.select();try{navigator.clipboard.writeText(t.value);this.textContent=\'Copied\'}catch(e){document.execCommand(\'copy\')}">Copy brief for Claude</button>';
			echo '<button name="w" value="done" class="button">Done</button><button name="w" value="later" class="button">Remind me later</button></form></div>';
		}
		echo '<form method="post" action="' . esc_url( $post ) . '" style="margin-top:12px"><input type="hidden" name="action" value="mrsh_help_new">' . wp_nonce_field( 'mrsh_help_new', '_wpnonce', true, false ) . '<p><b>Need something yourself?</b> Write it in your own words (English or Urdu). A ready brief is made for Claude.</p><textarea name="note" rows="2" style="width:100%" placeholder="For example: add a page for Rishta in Canada"></textarea><p><button class="mx-btn">Make my request</button></p></form>';
		echo '</div>';
	}
}
MRSH_Help::init();
