<?php
/**
 * Real-name robot. Finds profiles whose name is a placeholder (Female, xyz, test, no name, a long username...)
 * and sends the member a friendly email in English and Urdu asking for a real first name. One email, one last
 * reminder a week later, then it stops. It never changes or hides a profile by itself.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_NameFix {

	const CUR = 'mrsh_nf_cursor';
	const LOG = 'mrsh_nf_stats';

	public static function init() {
		add_action( 'mrsh_tk_poll', array( __CLASS__, 'tick' ), 45 );
	}

	/** True when a profile name looks like a placeholder or a username, not a first name. */
	public static function is_bad( $name ) {
		$n = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( (string) $name ) ) );
		$l = mb_strtolower( $n );
		if ( '' === $l || mb_strlen( $l ) < 2 ) {
			return true;
		}
		if ( preg_match( '#https?://|www\.|@|\d{3,}#', $l ) ) {
			return true;
		}
		$words = '/^(male|female|man|woman|boy|girl|groom|bride|lady|gents|name|no ?name|noname|none|na|n\/a|unknown|anonymous|anon|user\d*|test\d*|testing|demo|sample|xyz( .*)?|abc\d*|asd+f*|qwe+r*t*y*|aaa+|bbb+|xxx+|zzz+|hello|hi|profile|my profile|member|admin|rishta|sister|brother|me|self|myself)$/u';
		if ( preg_match( '/\bno ?name\b/u', $l ) || preg_match( $words, $l ) || preg_match( '/^(.)\1{2,}$/u', $l ) ) {
			return true;
		}
		// one long lowercase word with no capital letter and no space: a username such as briellegraysonsa
		if ( false === strpos( $n, ' ' ) && mb_strlen( $n ) >= 14 && $n === mb_strtolower( $n ) && preg_match( '/^[a-z]+$/', $n ) ) {
			return true;
		}
		return false;
	}

	private static function stat( $k ) {
		$o = get_option( self::LOG, array() );
		$o = is_array( $o ) ? $o : array();
		$o[ $k ] = (int) ( $o[ $k ] ?? 0 ) + 1;
		update_option( self::LOG, $o, false );
	}

	public static function tick() {
		if ( ! class_exists( 'MRSH_Mem_Mail' ) || ( class_exists( 'MRSH_Autopilot' ) && ! MRSH_Autopilot::can( 'members' ) ) ) {
			return;
		}
		if ( get_transient( 'mrsh_nf_run' ) ) {
			return;
		}
		set_transient( 'mrsh_nf_run', 1, 15 * MINUTE_IN_SECONDS );
		global $wpdb;
		$cur  = (int) get_option( self::CUR, 0 );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_author, post_title FROM {$wpdb->posts} WHERE post_type='listing_type' AND post_status='publish' AND ID > %d ORDER BY ID ASC LIMIT 150", $cur ) ); // phpcs:ignore WordPress.DB
		if ( ! $rows ) {
			update_option( self::CUR, 0, false ); // finished a full pass; start again next time (reminder two comes then)
			return;
		}
		$now  = time();
		$sent = 0;
		foreach ( $rows as $r ) {
			$cur = (int) $r->ID;
			if ( $sent >= 6 || ! self::is_bad( $r->post_title ) ) {
				if ( $sent >= 6 ) {
					$cur = (int) $r->ID - 1; // come back to this one next time
					break;
				}
				continue;
			}
			$uid = (int) $r->post_author;
			$u   = $uid ? get_userdata( $uid ) : null;
			if ( ! $u || user_can( $u, 'manage_options' ) || get_user_meta( $uid, 'mrt_helper', true ) || get_user_meta( $uid, 'mrsh_nf_off', true ) || ! is_email( $u->user_email ) ) {
				continue; // agency family accounts and admins are never emailed
			}
			$n1 = (int) get_user_meta( $uid, 'mrsh_nf1', true );
			$n2 = (int) get_user_meta( $uid, 'mrsh_nf2', true );
			if ( $n2 ) {
				continue;
			}
			if ( ! $n1 ) {
				$key = 'namefix1';
			} elseif ( $now - $n1 >= 7 * DAY_IN_SECONDS ) {
				$key = 'namefix2';
			} else {
				continue;
			}
			$nm   = self::is_bad( $u->display_name ) ? 'there' : $u->display_name;
			$link = add_query_arg( array( 'edit' => (int) $r->ID, 'utm_source' => 'email', 'utm_medium' => 'namefix', 'utm_campaign' => $key ), home_url( '/add-listing/' ) );
			$ok   = MRSH_Mem_Mail::send( $u->user_email, $key, array( 'name' => $nm, 'link' => $link ) );
			update_user_meta( $uid, 'namefix1' === $key ? 'mrsh_nf1' : 'mrsh_nf2', $now );
			if ( $ok ) {
				$sent++;
				self::stat( $key );
			}
		}
		update_option( self::CUR, $cur, false );
		if ( $sent && class_exists( 'MRSH_Autopilot' ) ) {
			MRSH_Autopilot::log( 'Real names', 'Asked ' . $sent . ' member(s) to change a placeholder profile name to a real name.' );
		}
	}

	/** Small card for the Autopilot page. */
	public static function card() {
		$o = get_option( self::LOG, array() );
		$o = is_array( $o ) ? $o : array();
		echo '<div class="mx-card"><h2 class="mx-h">Real names</h2><p style="color:#6b7280;margin:0">The robot emails members whose profile name looks like a placeholder (Female, xyz, test, a long username). First email: <b>' . (int) ( $o['namefix1'] ?? 0 ) . '</b>. Last reminder: <b>' . (int) ( $o['namefix2'] ?? 0 ) . '</b>. It never hides or changes a profile.</p></div>';
	}
}
MRSH_NameFix::init();
