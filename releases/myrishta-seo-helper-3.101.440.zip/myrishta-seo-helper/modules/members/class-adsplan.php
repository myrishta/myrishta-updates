<?php
/**
 * Google Ads campaign plan (Growth > Google Ads, 3.101.226).
 * Keeps the ready plan (campaigns, ad groups, keywords, negatives, ads in English and Urdu) inside the site, lets you edit it,
 * and builds ONE file for Google Ads Editor: open Editor, Account > Import > From file, and every campaign, ad group,
 * keyword and ad is created at once instead of typed by hand. Campaigns are exported as Paused so nothing spends until you switch them on.
 * Option: mrsh_adsplan. No tables, no visitor data.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Adsplan {

	const OPT = 'mrsh_adsplan';

	private static function lines( $s ) {
		return array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) $s ) ), 'strlen' ) );
	}

	private static function neg() {
		return "job\njobs\ncourse\nfree download\npdf\nmovie\ndrama\nsong\nlyrics\ndivorce lawyer\ncourt marriage\nvisa\nrent\nproperty\nwedding hall\nwedding dress\nphotographer";
	}

	private static function en_h() {
		return "Free Pakistani Rishta Service\nNo Fees. No Agents.\nVerified Rishta Profiles\nRishta for Pakistani Families\nAdd Your Profile Free Today\nPhone Numbers Stay Private\nFind a Rishta in Pakistan\nRishta Chahiye? Start Free";
	}

	private static function en_d() {
		return "Free matrimonial service for Pakistani families. Search profiles by city and religion.\nNo fees, no agents. Add your profile free and find a suitable proposal for your family.\nPhone numbers stay private. Verified profiles. Run by a non-profit in Lahore.";
	}

	private static function ur_h() {
		return "مفت پاکستانی رشتہ سروس\nکوئی فیس نہیں، کوئی ایجنٹ نہیں\nتصدیق شدہ رشتہ پروفائلز\nآج ہی مفت پروفائل بنائیں\nفون نمبر محفوظ رہتے ہیں\nپاکستان میں رشتہ تلاش کریں";
	}

	private static function ur_d() {
		return "پاکستانی خاندانوں کے لیے مفت رشتہ سروس۔ شہر اور مذہب کے مطابق پروفائلز تلاش کریں۔\nفیس نہیں، ایجنٹ نہیں۔ اپنا پروفائل مفت بنائیں اور اپنے خاندان کے لیے موزوں رشتہ تلاش کریں۔";
	}

	public static function defaults() {
		$ab_h = "Rishta for Pakistanis Abroad\nFree Pakistani Rishta Service\nRishta in Saudi Arabia\nRishta in UAE and Dubai\nRishta in Qatar and Kuwait\nFamily-First Rishta Search\nAdd Your Profile Free\nNo Fees. No Agents.\nVerified Rishta Profiles";
		$ab_d = "Living abroad? Search Pakistani rishta profiles free and involve your family from day one.\nFree for overseas Pakistanis. Add your profile, search by city and connect with families.\nPhone numbers stay private. Run by a non-profit in Lahore. Start free today.";
		$ab_uh = "بیرون ملک پاکستانیوں کا رشتہ\nسعودی عرب میں پاکستانی رشتہ\nیو اے ای میں رشتہ تلاش کریں\nآج ہی مفت پروفائل بنائیں";
		$ab_ud = "بیرون ملک رہتے ہیں؟ پاکستانی رشتے مفت تلاش کریں اور خاندان کو شامل رکھیں۔\nاوورسیز پاکستانیوں کے لیے مفت۔ پروفائل بنائیں اور شہر کے مطابق رشتہ تلاش کریں۔";
		return array(
			array(
				'name' => 'MyRishta - Pakistan', 'budget' => '1500', 'locations' => "Pakistan", 'languages' => "English\nUrdu", 'url' => home_url( '/pakistan-rishta/' ),
				'negatives' => self::neg(),
				'groups' => array(
					array( 'name' => 'English generic', 'kw' => "free rishta service | phrase\npakistani rishta online | phrase\nrishta for marriage in pakistan | phrase\nmatrimonial service pakistan | phrase", 'h' => self::en_h(), 'd' => self::en_d(), 'url' => '' ),
					array( 'name' => 'Roman Urdu', 'kw' => "rishta chahiye | phrase\nrishta online | phrase\nrishta in lahore | phrase\nrishta in karachi | phrase\nrishta in islamabad | phrase", 'h' => self::en_h(), 'd' => self::en_d(), 'url' => '' ),
					array( 'name' => 'Urdu script', 'kw' => "رشتہ | phrase\nرشتے چاہئیں | phrase\nآن لائن رشتہ | phrase\nلاہور میں رشتہ | phrase", 'h' => self::ur_h(), 'd' => self::ur_d(), 'url' => '' ),
					array( 'name' => 'Brand', 'kw' => "myrishta | exact\nmy rishta pakistan | exact", 'h' => self::en_h(), 'd' => self::en_d(), 'url' => home_url( '/' ) ),
				),
			),
			array(
				'name' => 'MyRishta - Overseas', 'budget' => '750', 'locations' => "Saudi Arabia\nUnited Arab Emirates\nQatar\nKuwait\nBahrain\nOman", 'languages' => "English\nUrdu", 'url' => home_url( '/rishta-overseas-pakistanis/' ),
				'negatives' => self::neg() . "\nwork permit\niqama\nsponsor\nimmigration\nspouse visa",
				'groups' => array(
					array( 'name' => 'Abroad English', 'kw' => "pakistani rishta for overseas | phrase\nrishta for pakistani in saudi arabia | phrase\nrishta for pakistani in dubai | phrase\npakistani matrimonial uae | phrase\nrishta for pakistani in qatar | phrase\nrishta for pakistani in kuwait | phrase\nrishta for pakistani in bahrain | phrase\nrishta for pakistani in oman | phrase\nrishta from abroad | phrase", 'h' => $ab_h, 'd' => $ab_d, 'url' => '' ),
					array( 'name' => 'Abroad Roman Urdu', 'kw' => "rishta chahiye saudi arabia | phrase\nrishta in dubai | phrase\nrishta in qatar | phrase\nrishta in kuwait | phrase\nrishta in bahrain | phrase\nrishta in oman | phrase\noverseas pakistani rishta | phrase", 'h' => $ab_h, 'd' => $ab_d, 'url' => '' ),
					array( 'name' => 'Abroad Urdu script', 'kw' => "سعودی عرب میں رشتہ | phrase\nدبئی میں پاکستانی رشتہ | phrase\nقطر میں پاکستانی رشتہ | phrase\nکویت میں پاکستانی رشتہ | phrase\nبحرین میں پاکستانی رشتہ | phrase\nعمان میں پاکستانی رشتہ | phrase", 'h' => $ab_uh, 'd' => $ab_ud, 'url' => '' ),
				),
			),
		);
	}

	public static function get() {
		$o = get_option( self::OPT, null );
		return ( is_array( $o ) && $o ) ? $o : self::defaults();
	}


	/** Add every GCC country (and its keywords) to the Overseas campaign of a saved plan. */
	public static function gcc( $plan ) {
		$gcc = array( 'Saudi Arabia', 'United Arab Emirates', 'Qatar', 'Kuwait', 'Bahrain', 'Oman' );
		$kw  = array(
			'Abroad English'     => array( 'rishta for pakistani in qatar', 'rishta for pakistani in kuwait', 'rishta for pakistani in bahrain', 'rishta for pakistani in oman' ),
			'Abroad Roman Urdu'  => array( 'rishta in qatar', 'rishta in kuwait', 'rishta in bahrain', 'rishta in oman' ),
		);
		foreach ( $plan as $i => $c ) {
			if ( false === stripos( (string) $c['name'], 'overseas' ) ) {
				continue;
			}
			$have = array_map( 'strtolower', self::lines( $c['locations'] ) );
			$add  = array();
			foreach ( $gcc as $g ) {
				if ( ! in_array( strtolower( $g ), $have, true ) ) {
					$add[] = $g;
				}
			}
			if ( $add ) {
				$plan[ $i ]['locations'] = trim( $c['locations'] ) . "\n" . implode( "\n", $add );
			}
			foreach ( $c['groups'] as $gi => $g ) {
				if ( empty( $kw[ $g['name'] ] ) ) {
					continue;
				}
				$cur = strtolower( $g['kw'] );
				$ex  = '';
				foreach ( $kw[ $g['name'] ] as $k ) {
					if ( false === strpos( $cur, $k ) ) {
						$ex .= "\n" . $k . ' | phrase';
					}
				}
				$plan[ $i ]['groups'][ $gi ]['kw'] = rtrim( $g['kw'] ) . $ex;
			}
		}
		return $plan;
	}

	public static function gcc_now() {
		self::guard( 'mrsh_adsplan_gcc' );
		update_option( self::OPT, self::gcc( self::get() ), false );
		update_option( 'mrsh_adsplan_gcc', 1, false );
		self::back( 'gcc' );
	}

	public static function migrate() {
		if ( get_option( 'mrsh_adsplan_gcc' ) ) {
			return;
		}
		$o = get_option( self::OPT, null );
		if ( is_array( $o ) && $o ) {
			update_option( self::OPT, self::gcc( $o ), false );
		}
		update_option( 'mrsh_adsplan_gcc', 1, false );
	}

	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'migrate' ) );
		add_action( 'admin_post_mrsh_adsplan_gcc', array( __CLASS__, 'gcc_now' ) );
		add_action( 'mrsh_gads_after', array( __CLASS__, 'render' ) );
		add_action( 'admin_post_mrsh_adsplan_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_mrsh_adsplan_reset', array( __CLASS__, 'reset' ) );
		add_action( 'admin_post_mrsh_adsplan_csv', array( __CLASS__, 'csv' ) );
	}

	private static function guard( $n ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.', '', array( 'response' => 403 ) );
		}
		check_admin_referer( $n );
	}

	private static function back( $m ) {
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-gads&plan=' . rawurlencode( $m ) . '#mrsh-plan' ) );
		exit;
	}

	public static function save() {
		self::guard( 'mrsh_adsplan' );
		$in  = isset( $_POST['c'] ) && is_array( $_POST['c'] ) ? wp_unslash( $_POST['c'] ) : array(); // phpcs:ignore
		$out = array();
		foreach ( $in as $c ) {
			if ( ! is_array( $c ) || '' === trim( (string) ( $c['name'] ?? '' ) ) ) {
				continue;
			}
			$row = array(
				'name'      => sanitize_text_field( $c['name'] ),
				'budget'    => preg_replace( '/[^0-9.]/', '', (string) ( $c['budget'] ?? '' ) ),
				'locations' => sanitize_textarea_field( $c['locations'] ?? '' ),
				'languages' => sanitize_textarea_field( $c['languages'] ?? '' ),
				'url'       => esc_url_raw( $c['url'] ?? '' ),
				'negatives' => sanitize_textarea_field( $c['negatives'] ?? '' ),
				'groups'    => array(),
			);
			foreach ( (array) ( $c['groups'] ?? array() ) as $g ) {
				if ( ! is_array( $g ) || '' === trim( (string) ( $g['name'] ?? '' ) ) ) {
					continue;
				}
				$row['groups'][] = array(
					'name' => sanitize_text_field( $g['name'] ),
					'kw'   => sanitize_textarea_field( $g['kw'] ?? '' ),
					'h'    => sanitize_textarea_field( $g['h'] ?? '' ),
					'd'    => sanitize_textarea_field( $g['d'] ?? '' ),
					'url'  => esc_url_raw( $g['url'] ?? '' ),
				);
			}
			$out[] = $row;
		}
		update_option( self::OPT, $out ? $out : self::defaults(), false );
		self::back( 'saved' );
	}

	public static function reset() {
		self::guard( 'mrsh_adsplan_reset' );
		delete_option( self::OPT );
		self::back( 'reset' );
	}

	/** Rows for Google Ads Editor. Returns array( header, rows, problems ). */
	public static function build() {
		$h = array( 'Campaign', 'Campaign Type', 'Campaign Status', 'Campaign Daily Budget', 'Bid Strategy Type', 'Networks', 'Languages', 'Location', 'Ad Group', 'Ad Group Type', 'Ad Group Status', 'Max CPC', 'Keyword', 'Criterion Type', 'Status', 'Ad Type' );
		for ( $i = 1; $i <= 15; $i++ ) {
			$h[] = 'Headline ' . $i;
		}
		for ( $i = 1; $i <= 4; $i++ ) {
			$h[] = 'Description ' . $i;
		}
		$h[]  = 'Final URL';
		$rows = array();
		$bad  = array();
		$row  = function ( $a ) use ( $h ) {
			$r = array_fill_keys( $h, '' );
			foreach ( $a as $k => $v ) {
				$r[ $k ] = $v;
			}
			return array_values( $r );
		};
		foreach ( self::get() as $c ) {
			$n = $c['name'];
			$rows[] = $row( array( 'Campaign' => $n, 'Campaign Type' => 'Search', 'Campaign Status' => 'Paused', 'Campaign Daily Budget' => $c['budget'], 'Bid Strategy Type' => 'Maximize clicks', 'Networks' => 'Google search', 'Languages' => implode( ';', self::lines( $c['languages'] ) ) ) );
			foreach ( self::lines( $c['locations'] ) as $loc ) {
				$rows[] = $row( array( 'Campaign' => $n, 'Location' => $loc ) );
			}
			foreach ( self::lines( $c['negatives'] ) as $k ) {
				$rows[] = $row( array( 'Campaign' => $n, 'Keyword' => $k, 'Criterion Type' => 'Negative Phrase' ) );
			}
			foreach ( $c['groups'] as $g ) {
				$rows[] = $row( array( 'Campaign' => $n, 'Ad Group' => $g['name'], 'Ad Group Type' => 'Standard', 'Ad Group Status' => 'Enabled', 'Max CPC' => '' ) );
				foreach ( self::lines( $g['kw'] ) as $kl ) {
					$p  = array_map( 'trim', explode( '|', $kl, 2 ) );
					$mt = strtolower( $p[1] ?? 'phrase' );
					$ct = 'exact' === $mt ? 'Exact' : ( 'broad' === $mt ? 'Broad' : 'Phrase' );
					$rows[] = $row( array( 'Campaign' => $n, 'Ad Group' => $g['name'], 'Keyword' => $p[0], 'Criterion Type' => $ct, 'Status' => 'Enabled' ) );
				}
				$ad = array( 'Campaign' => $n, 'Ad Group' => $g['name'], 'Ad Type' => 'Responsive search ad', 'Status' => 'Enabled', 'Final URL' => $g['url'] ? $g['url'] : $c['url'] );
				$i  = 0;
				foreach ( self::lines( $g['h'] ) as $t ) {
					if ( mb_strlen( $t ) > 30 ) {
						$bad[] = $n . ' / ' . $g['name'] . ': headline over 30 characters, left out: ' . $t;
						continue;
					}
					if ( ++$i <= 15 ) {
						$ad[ 'Headline ' . $i ] = $t;
					}
				}
				$i = 0;
				foreach ( self::lines( $g['d'] ) as $t ) {
					if ( mb_strlen( $t ) > 90 ) {
						$bad[] = $n . ' / ' . $g['name'] . ': description over 90 characters, left out: ' . $t;
						continue;
					}
					if ( ++$i <= 4 ) {
						$ad[ 'Description ' . $i ] = $t;
					}
				}
				if ( $i < 2 || count( array_filter( array_intersect_key( $ad, array_flip( preg_grep( '/^Headline /', array_keys( $ad ) ) ) ) ) ) < 3 ) {
					$bad[] = $n . ' / ' . $g['name'] . ': a responsive ad needs at least 3 headlines and 2 descriptions.';
				}
				$rows[] = $row( $ad );
			}
		}
		return array( $h, $rows, $bad );
	}

	public static function csv() {
		self::guard( 'mrsh_adsplan_csv' );
		list( $h, $rows ) = self::build();
		nocache_headers();
		header( 'Content-Type: text/csv; charset=UTF-8' );
		header( 'Content-Disposition: attachment; filename="myrishta-google-ads-editor-' . gmdate( 'Ymd' ) . '.csv"' );
		echo "\xEF\xBB\xBF"; // phpcs:ignore
		$f = fopen( 'php://output', 'w' );
		fputcsv( $f, $h );
		foreach ( $rows as $r ) {
			fputcsv( $f, $r );
		}
		fclose( $f ); // phpcs:ignore
		exit;
	}

	public static function render() {
		$plan = self::get();
		$post = esc_url( admin_url( 'admin-post.php' ) );
		list( , $rows, $bad ) = self::build();
		echo '<h2 id="mrsh-plan">Campaign plan, ready to import</h2>';
		if ( isset( $_GET['plan'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success"><p>Done.</p></div>';
		}
		echo '<p>The full plan is below: Pakistan and overseas campaigns, keywords, negative keywords, and ads in English and Urdu. Edit anything, then press <b>Download Google Ads Editor file</b>. In <a href="https://ads.google.com/home/tools/ads-editor/" target="_blank" rel="noopener">Google Ads Editor</a> choose <b>Account &gt; Import &gt; From file</b>: all campaigns, ad groups, keywords and ads are created at once, so nothing is typed by hand. Campaigns are imported <b>Paused</b>; check them and switch them on when ready.</p>';
		echo '<p><i>Google does not allow a website plugin to create campaigns by itself without a separate approved Google Ads developer token, so the file import is the one-step route.</i> The page feed in step 2 is already fully automatic.</p>';
		echo '<form method="post" action="' . $post . '" style="margin:8px 0"><input type="hidden" name="action" value="mrsh_adsplan_csv">' . wp_nonce_field( 'mrsh_adsplan_csv', '_wpnonce', true, false ) . '<button class="button button-primary button-hero">Download Google Ads Editor file (.csv)</button> <span class="description">' . (int) count( $rows ) . ' rows</span></form>'; // phpcs:ignore
		if ( $bad ) {
			echo '<div class="notice notice-warning inline"><p><b>Fix before importing:</b></p><ul style="list-style:disc;margin-left:22px">';
			foreach ( $bad as $b ) {
				echo '<li>' . esc_html( $b ) . '</li>';
			}
			echo '</ul></div>';
		}
		echo '<form method="post" action="' . $post . '"><input type="hidden" name="action" value="mrsh_adsplan_save">' . wp_nonce_field( 'mrsh_adsplan', '_wpnonce', true, false ); // phpcs:ignore
		$ta = function ( $name, $val, $rows = 4 ) {
			return '<textarea name="' . esc_attr( $name ) . '" rows="' . (int) $rows . '" class="large-text" dir="auto" style="font-family:inherit">' . esc_textarea( (string) $val ) . '</textarea>';
		};
		foreach ( $plan as $ci => $c ) {
			$p = 'c[' . $ci . ']';
			echo '<div class="card" style="max-width:none;padding:14px 16px;margin:12px 0"><h3 style="margin-top:0">' . esc_html( $c['name'] ) . '</h3><table class="form-table" role="presentation">';
			echo '<tr><th>Campaign name</th><td><input class="regular-text" name="' . esc_attr( $p ) . '[name]" value="' . esc_attr( $c['name'] ) . '"></td></tr>';
			echo '<tr><th>Daily budget</th><td><input class="small-text" name="' . esc_attr( $p ) . '[budget]" value="' . esc_attr( $c['budget'] ) . '"> <span class="description">in your Google Ads account currency. Start small, raise it when sign-ups arrive.</span></td></tr>';
			echo '<tr><th>Locations</th><td>' . $ta( $p . '[locations]', $c['locations'], 2 ) . '<p class="description">One per line, as Google names them.</p></td></tr>'; // phpcs:ignore
			echo '<tr><th>Languages</th><td>' . $ta( $p . '[languages]', $c['languages'], 2 ) . '</td></tr>'; // phpcs:ignore
			echo '<tr><th>Main page</th><td><input class="large-text" name="' . esc_attr( $p ) . '[url]" value="' . esc_attr( $c['url'] ) . '"></td></tr>';
			echo '<tr><th>Negative keywords</th><td>' . $ta( $p . '[negatives]', $c['negatives'], 4 ) . '<p class="description">One per line. These stop wasted clicks.</p></td></tr>'; // phpcs:ignore
			echo '</table>';
			foreach ( $c['groups'] as $gi => $g ) {
				$q = $p . '[groups][' . $gi . ']';
				echo '<details style="border-top:1px solid #eee;padding:8px 0"' . ( 0 === $gi ? ' open' : '' ) . '><summary style="cursor:pointer;font-weight:600">Ad group: ' . esc_html( $g['name'] ) . '</summary><table class="form-table" role="presentation">';
				echo '<tr><th>Name</th><td><input class="regular-text" name="' . esc_attr( $q ) . '[name]" value="' . esc_attr( $g['name'] ) . '"></td></tr>';
				echo '<tr><th>Keywords</th><td>' . $ta( $q . '[kw]', $g['kw'], 5 ) . '<p class="description">One per line: keyword | phrase  (or exact).</p></td></tr>'; // phpcs:ignore
				echo '<tr><th>Headlines</th><td>' . $ta( $q . '[h]', $g['h'], 6 ) . '<p class="description">Up to 15, each 30 characters or fewer.</p></td></tr>'; // phpcs:ignore
				echo '<tr><th>Descriptions</th><td>' . $ta( $q . '[d]', $g['d'], 3 ) . '<p class="description">Up to 4, each 90 characters or fewer.</p></td></tr>'; // phpcs:ignore
				echo '<tr><th>Page (optional)</th><td><input class="large-text" name="' . esc_attr( $q ) . '[url]" value="' . esc_attr( $g['url'] ) . '"><p class="description">Leave empty to use the campaign main page.</p></td></tr></table></details>';
			}
			echo '</div>';
		}
		echo '<p><button class="button button-primary">Save plan</button></p></form>';
		echo '<form method="post" action="' . $post . '" style="display:inline-block;margin-right:8px"><input type="hidden" name="action" value="mrsh_adsplan_gcc">' . wp_nonce_field( 'mrsh_adsplan_gcc', '_wpnonce', true, false ) . '<button class="button">Add all GCC countries (Saudi, UAE, Qatar, Kuwait, Bahrain, Oman)</button></form>';
		echo '<form method="post" action="' . $post . '" onsubmit="return confirm(\'Put back the original plan?\')"><input type="hidden" name="action" value="mrsh_adsplan_reset">' . wp_nonce_field( 'mrsh_adsplan_reset', '_wpnonce', true, false ) . '<button class="button">Reset to the original plan</button></form>'; // phpcs:ignore
	}
}

MRSH_Adsplan::init();
