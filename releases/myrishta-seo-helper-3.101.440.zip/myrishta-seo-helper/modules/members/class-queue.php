<?php
/**
 * Moderation queue (3.101.107): one page for everything waiting for an admin, oldest first.
 *  - Profiles waiting for approval, reported profiles, verification requests, and chat warnings.
 *  - Buttons reuse the existing approve / verify / decline actions, so nothing is decided twice.
 * Safety prompt (3.101.107): chat and profile messages that ask someone to send money are blocked with a clear
 * reason, and logged here (no message text is stored, only sender, receiver and time).
 * Option: mrsh_chat_flags (last 60 warnings).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Queue {

	/** Returns a message if the text asks for money, otherwise ''. Logs the attempt. */
	public static function money_block( $text, $from = 0, $to = 0 ) {
		$t = (string) $text;
		$re = '/\b(send|transfer|deposit|pay|bhej\w*|dein\w*)\b.{0,40}\b(money|rupees?|rs\.?|paisa|pkr|jazzcash|easypaisa|bank|account|advance|fees?|loan|cash)\b|\b(jazzcash|easypaisa|western union|moneygram|advance payment|paisa bhej)\b/iu';
		if ( ! preg_match( $re, $t ) ) {
			return '';
		}
		$log   = (array) get_option( 'mrsh_chat_flags', array() );
		$log[] = array( 't' => time(), 'from' => (int) $from, 'to' => (int) $to );
		update_option( 'mrsh_chat_flags', array_slice( $log, -60 ), false );
		return 'For your safety, never send or ask for money in chat. Meet family in person, check details yourself and tell the team if someone asks you to pay first.';
	}

	public static function init() {
		add_action( 'admin_post_mrsh_q_clear', array( __CLASS__, 'clear' ) );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 25 );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Queue', 'Queue', 'manage_options', 'mrsh-queue', array( __CLASS__, 'page' ) );
	}

	public static function clear() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'mrsh_q_clear' ) ) {
			wp_die( 'Not allowed.' );
		}
		delete_option( 'mrsh_chat_flags' );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-queue&ok=1' ) );
		exit;
	}

	private static function age( $ts ) {
		return human_time_diff( (int) $ts, time() ) . ' ago';
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) || ! class_exists( 'MRSH_Boost' ) ) {
			return;
		}
		$pend = get_posts( array( 'post_type' => 'listing_type', 'post_status' => array( 'pending', 'pending_approval' ), 'numberposts' => 50, 'orderby' => 'date', 'order' => 'ASC' ) );
		$rep  = get_posts( array( 'post_type' => 'listing_type', 'post_status' => array( 'publish', 'draft' ), 'numberposts' => 50, 'meta_key' => 'mrt_reports', 'meta_compare' => 'EXISTS', 'orderby' => 'modified', 'order' => 'ASC' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		$vr   = get_users( array( 'meta_key' => 'mrt_vreq', 'meta_compare' => 'EXISTS', 'number' => 50, 'orderby' => 'meta_value_num', 'meta_type' => 'NUMERIC', 'order' => 'ASC' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		$flags = array_reverse( (array) get_option( 'mrsh_chat_flags', array() ) );
		$total = count( $pend ) + count( $rep ) + count( $vr ) + count( $flags );

		MRSH_Boost::ui_open( 'Moderation queue', 'Everything that needs a decision, oldest first. Each button does the same thing as on the original page.', 'g-red', 'M12 2 4 5v6c0 5 3.4 9.4 8 11 4.6-1.6 8-6 8-11V5zm-1.1 13.4-3.5-3.5 1.4-1.4 2.1 2.1 4.6-4.6 1.4 1.4z' );
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			MRSH_Boost::ui_ok( 'Cleared.' );
		}
		echo '<div class="mx-stats">' . MRSH_Boost::ui_stat( $total, 'Waiting in total', $total ? '#e11d74' : '#10b981' ) . MRSH_Boost::ui_stat( count( $pend ), 'Profiles to approve', '#f59e0b' ) . MRSH_Boost::ui_stat( count( $rep ), 'Reported profiles', '#ef4444' ) . MRSH_Boost::ui_stat( count( $vr ), 'Verification requests', '#4a69d6' ) . MRSH_Boost::ui_stat( count( $flags ), 'Chat warnings', '#7c3aed' ) . '</div>'; // phpcs:ignore

		// 1. profiles to approve
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">1</span><h2>Profiles to approve</h2></div>';
		if ( ! $pend ) {
			echo '<div class="mx-empty"><div class="bub">&#10003;</div><b>Nothing waiting</b><p>New profiles appear here until you approve them.</p></div>';
		}
		foreach ( $pend as $p ) {
			$url = wp_nonce_url( admin_url( 'admin-post.php?action=mrt_approve&pid=' . $p->ID ), 'mrt_approve' . $p->ID );
			echo '<div class="mx-rep"><div class="who"><b>' . esc_html( $p->post_title ) . '</b> <span class="mx-pill">#' . (int) $p->ID . '</span><div class="why"><span class="mx-pill warn">waiting ' . esc_html( self::age( strtotime( $p->post_date_gmt ) ) ) . '</span></div></div><div class="mx-acts"><a class="mx-btn p s" href="' . esc_url( $url ) . '">Approve</a><a class="mx-btn s" href="' . esc_url( get_edit_post_link( $p->ID ) ) . '">Open</a></div></div>';
		}
		echo '</div>';

		// 2. reported profiles
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">2</span><h2>Reported profiles</h2></div>';
		if ( ! $rep ) {
			echo '<div class="mx-empty"><div class="bub">&#10003;</div><b>No reports</b><p>Reports from members appear here.</p></div>';
		}
		foreach ( $rep as $p ) {
			$n = count( array_filter( (array) get_post_meta( $p->ID, 'mrt_reports', true ) ) );
			echo '<div class="mx-rep"><div class="who"><b>' . esc_html( $p->post_title ) . '</b> <span class="mx-pill bad">' . (int) $n . ' report' . ( 1 === $n ? '' : 's' ) . '</span><div class="why"><span class="mx-pill">' . esc_html( $p->post_status ) . '</span></div></div><div class="mx-acts"><a class="mx-btn s" href="' . esc_url( admin_url( 'admin.php?page=mrsh-reports' ) ) . '">Review reports</a><a class="mx-btn s" href="' . esc_url( get_edit_post_link( $p->ID ) ) . '">Open</a></div></div>';
		}
		echo '</div>';

		// 3. verification requests
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">3</span><h2>Verification requests</h2></div>';
		if ( ! $vr ) {
			echo '<div class="mx-empty"><div class="bub">&#10003;</div><b>No requests</b><p>Members who ask to be verified appear here.</p></div>';
		}
		foreach ( $vr as $u ) {
			$mk = function ( $do ) use ( $u ) {
				return wp_nonce_url( admin_url( 'admin-post.php?action=mrt_vdo&uid=' . $u->ID . '&do=' . $do ), 'mrt_vdo' . $u->ID );
			};
			echo '<div class="mx-rep"><div class="who"><b>' . esc_html( $u->display_name ) . '</b> <span class="mx-pill">asked ' . esc_html( self::age( (int) get_user_meta( $u->ID, 'mrt_vreq', true ) ) ) . '</span></div><div class="mx-acts"><a class="mx-btn p s" href="' . esc_url( $mk( 'yes' ) ) . '">Mark verified</a><a class="mx-btn d s" href="' . esc_url( $mk( 'no' ) ) . '">Decline</a></div></div>';
		}
		echo '</div>';

		// 4. chat warnings
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">4</span><h2>Chat warnings (money requests)</h2></div><p class="mx-sub">These messages were blocked because they asked someone to send money. The text is not kept, only who and when.</p>';
		if ( ! $flags ) {
			echo '<div class="mx-empty"><div class="bub">&#10003;</div><b>No warnings</b><p>Blocked money requests appear here.</p></div>';
		}
		foreach ( array_slice( $flags, 0, 20 ) as $f ) {
			$a = get_userdata( (int) $f['from'] );
			$b = get_userdata( (int) $f['to'] );
			echo '<div class="mx-rep"><div class="who"><b>' . esc_html( $a ? $a->display_name : 'Member #' . (int) $f['from'] ) . '</b> to <b>' . esc_html( $b ? $b->display_name : 'Member #' . (int) $f['to'] ) . '</b><div class="why"><span class="mx-pill warn">' . esc_html( self::age( (int) $f['t'] ) ) . '</span></div></div></div>';
		}
		if ( $flags ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin-top:12px">';
			wp_nonce_field( 'mrsh_q_clear' );
			echo '<input type="hidden" name="action" value="mrsh_q_clear"><button class="mx-btn s">Clear this list</button></form>';
		}
		echo '</div>';

		// 5. photos
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">5</span><h2>Photos</h2></div><p class="mx-sub">Photos removed by the safety check are reviewed on the Photo safety page.</p><div class="mx-acts"><a class="mx-btn p s" href="' . esc_url( admin_url( 'admin.php?page=mrsh-photo-safety' ) ) . '">Open Photo safety</a></div></div>';
		echo '</div>';
	}
}
MRSH_Queue::init();
