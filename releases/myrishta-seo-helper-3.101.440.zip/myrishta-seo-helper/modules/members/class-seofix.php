<?php
/**
 * Broken address monitor (Growth > Broken addresses, 3.101.168).
 * Google sometimes lists addresses that no longer exist (old themes, typos, spaces in a link). Every visit to a missing page is
 * counted here, and one press turns it into a permanent (301) redirect to the right page, so visitors and ranking are not lost.
 * Options: mrsh_404log (path => count, last seen), mrsh_fix_map (path => target path). No tables. Paths only, no visitor data.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Seofix {

	const LOG = 'mrsh_404log';
	const MAP = 'mrsh_fix_map';

	/** Addresses seen in Search Console that no longer exist. Editable on the page. */
	private static function defaults() {
		return array(
			'/daeyes/blue/'                        => '/',
			'/pakistan rishta/free-online-rishta/' => '/pakistan-rishta/',
		);
	}

	public static function map() {
		$m = get_option( self::MAP, null );
		if ( null === $m ) {
			$m = self::defaults();
			add_option( self::MAP, $m, '', 'no' );
		}
		return is_array( $m ) ? $m : array();
	}

	public static function init() {
		add_action( 'template_redirect', array( __CLASS__, 'on_404' ), 1 );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 32 );
		add_action( 'admin_post_mrsh_fix_add', array( __CLASS__, 'add' ) );
		add_action( 'admin_post_mrsh_fix_del', array( __CLASS__, 'del' ) );
		add_action( 'admin_post_mrsh_fix_clear', array( __CLASS__, 'clear' ) );
		add_action( 'admin_post_mrsh_fix_auto', array( __CLASS__, 'act_auto' ) );
	}

	/** Normalised path used as the key: lower case, decoded, one leading and one trailing slash, no query. */
	public static function key( $path ) {
		$p = (string) wp_parse_url( (string) $path, PHP_URL_PATH );
		$p = strtolower( rawurldecode( $p ) );
		$p = '/' . trim( $p, '/' ) . '/';
		return '//' === $p ? '/' : $p;
	}

	private static function safe_target( $t ) {
		$t = trim( (string) $t );
		if ( '' === $t ) {
			return '';
		}
		if ( preg_match( '#^https?://#i', $t ) ) {
			$h = wp_parse_url( $t, PHP_URL_HOST );
			$s = wp_parse_url( home_url(), PHP_URL_HOST );
			if ( ! $h || strtolower( $h ) !== strtolower( (string) $s ) ) {
				return ''; // only this site
			}
			$t = (string) wp_parse_url( $t, PHP_URL_PATH );
		}
		return '/' . ltrim( $t, '/' );
	}

	public static function on_404() {
		if ( ! is_404() || is_admin() ) {
			return;
		}
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : ''; // phpcs:ignore
		$k   = self::key( $uri );
		$map = self::map();
		if ( isset( $map[ $k ] ) && $map[ $k ] ) {
			wp_safe_redirect( home_url( $map[ $k ] ), 301 );
			exit;
		}
		// Old directory pages of the previous theme (countries, castes, jobs...) and old log or feed addresses are gone for good: say 410 so Google drops them quickly.
		if ( preg_match( '#^/(country|caste|education|occupation|religion|features|dagender|dasexuality|dathnicity|daeyes|dahair|dabody|dasmoke|dadrink|dahairlength|log)/#', $k ) || preg_match( '#^/tag/.+/page/\d+/$#', $k ) || preg_match( '#^/listing/[^/]+/feed/$#', $k ) ) {
			status_header( 410 );
			nocache_headers();
			return;
		}
		if ( preg_match( '#\.(js|css|map|png|jpe?g|gif|webp|svg|ico|woff2?|ttf|txt|xml|php|env|zip|sql)/?$#', $k ) || strlen( $k ) > 160 ) {
			return; // scanners and missing assets are not worth listing
		}
		$log = (array) get_option( self::LOG, array() );
		$n   = isset( $log[ $k ]['n'] ) ? (int) $log[ $k ]['n'] : 0;
		$log[ $k ] = array( 'n' => $n + 1, 't' => time() );
		if ( count( $log ) > 200 ) {
			uasort( $log, function ( $a, $b ) {
				return ( $b['t'] ?? 0 ) <=> ( $a['t'] ?? 0 );
			} );
			$log = array_slice( $log, 0, 150, true );
		}
		update_option( self::LOG, $log, false );
	}

	/** Tokens of a slug without filler words, so rishta-in-lahore and rishta-lahore count as the same page. */
	private static function toks( $slug ) {
		$t = array_diff( explode( '-', sanitize_title( $slug ) ), array( '', 'in', 'of', 'the', 'and', 'for', 'a', 'free', 'online', 'pakistan', 'pakistani', 'page', 'new', 'old' ) );
		sort( $t );
		return implode( '-', array_unique( $t ) );
	}

	/** Autopilot: send each missing address to the page it clearly was. Only confident matches; scanner junk is dropped from the list. Returns how many were fixed. */
	public static function auto( $max = 40 ) {
		$log = (array) get_option( self::LOG, array() );
		if ( ! $log ) {
			return 0;
		}
		$pages = get_posts( array( 'post_type' => array( 'page', 'post' ), 'post_status' => 'publish', 'numberposts' => 500, 'suppress_filters' => true ) );
		$by    = array();
		$tk    = array();
		foreach ( $pages as $p ) {
			if ( get_post_meta( $p->ID, '_mrsh_noindex', true ) ) {
				continue;
			}
			$by[ $p->post_name ] = $p;
			$k                   = self::toks( $p->post_name );
			$tk[ $k ]            = isset( $tk[ $k ] ) ? false : $p; // two pages with the same tokens: ambiguous
		}
		$m     = self::map();
		$fixed = 0;
		$alias = array( '/add-profile/' => 'add-listing', '/pricing/' => 'memberships', '/cart/' => 'memberships', '/browse/' => 'latest-profiles', '/rishta-rawalpindi/' => 'rishta-in-rawalpindi' );
		foreach ( $alias as $from => $slug ) {
			if ( isset( $log[ $from ] ) && ! isset( $m[ $from ] ) && get_page_by_path( $slug ) ) {
				$m[ $from ] = '/' . $slug . '/';
				unset( $log[ $from ] );
				$fixed++;
			}
		}
		$junk  = 0;
		foreach ( $log as $path => $v ) {
			if ( $fixed >= $max ) {
				break;
			}
			if ( preg_match( '#(\.|wp-|admin|xmlrpc|cgi|%|\?|eval|passwd|\{|\$|probe|made-up-url)#i', $path ) || preg_match( '#^/(country|caste|education|occupation|religion|features|dagender|dasexuality|dathnicity|daeyes|dahair|dabody|dasmoke|dadrink|dahairlength|log)/#', $path ) || preg_match( '#^/tag/.+/page/\d+/$#', $path ) || preg_match( '#^/listing/[^/]+/feed/$#', $path ) ) {
				unset( $log[ $path ] ); // scanner traffic
				$junk++;
				continue;
			}
			$seg = trim( (string) $path, '/' );
			$seg = false !== strpos( $seg, '/' ) ? substr( $seg, strrpos( $seg, '/' ) + 1 ) : $seg;
			$slug = sanitize_title( rawurldecode( $seg ) );
			if ( '' === $slug || isset( $m[ $path ] ) ) {
				continue;
			}
			$t = null;
			if ( isset( $by[ $slug ] ) ) {
				$t = $by[ $slug ];
			} else {
				$k = self::toks( $slug );
				if ( '' !== $k && ! empty( $tk[ $k ] ) ) {
					$t = $tk[ $k ];
				} else {
					$best = 0;
					$bp   = null;
					foreach ( $by as $sl => $p ) {
						similar_text( $slug, $sl, $pc );
						if ( $pc > $best ) {
							$best = $pc;
							$bp   = $p;
						}
					}
					if ( $best >= 90 ) {
						$t = $bp;
					}
				}
			}
			if ( ! $t ) {
				continue;
			}
			$to = (string) wp_parse_url( get_permalink( $t ), PHP_URL_PATH );
			if ( '' === $to || self::key( $to ) === $path ) {
				continue;
			}
			$m[ $path ] = $to;
			unset( $log[ $path ] );
			$fixed++;
		}
		if ( $fixed ) {
			update_option( self::MAP, $m, false );
		}
		if ( $fixed || $junk ) {
			update_option( self::LOG, $log, false );
		}
		if ( $fixed && class_exists( 'MRSH_Autopilot' ) ) {
			MRSH_Autopilot::log( 'Indexing', 'Redirected ' . $fixed . ' broken address(es) to the page they clearly meant.' );
		}
		return $fixed;
	}

	public static function act_auto() {
		self::guard( 'mrsh_fix_auto' );
		$n = self::auto( 200 );
		self::back( $n ? 'auto' . $n : 'none' );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Broken addresses', 'Broken addresses', 'manage_options', 'mrsh-fix', array( __CLASS__, 'page' ) );
	}

	private static function guard( $nonce ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.', '', array( 'response' => 403 ) );
		}
		check_admin_referer( $nonce );
	}

	private static function back( $m = '1' ) {
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-fix&ok=' . rawurlencode( $m ) ) );
		exit;
	}

	public static function add() {
		self::guard( 'mrsh_fix_add' );
		$from = isset( $_POST['from'] ) ? self::key( sanitize_text_field( wp_unslash( $_POST['from'] ) ) ) : ''; // phpcs:ignore
		$to   = isset( $_POST['to'] ) ? self::safe_target( sanitize_text_field( wp_unslash( $_POST['to'] ) ) ) : ''; // phpcs:ignore
		if ( '' === $to || '/' === $from && '/' === $to ) {
			self::back( 'bad' );
		}
		$m          = self::map();
		$m[ $from ] = $to;
		update_option( self::MAP, $m, false );
		$log = (array) get_option( self::LOG, array() );
		unset( $log[ $from ] );
		update_option( self::LOG, $log, false );
		self::back( 'added' );
	}

	public static function del() {
		self::guard( 'mrsh_fix_del' );
		$from = isset( $_POST['from'] ) ? self::key( sanitize_text_field( wp_unslash( $_POST['from'] ) ) ) : ''; // phpcs:ignore
		$m    = self::map();
		unset( $m[ $from ] );
		update_option( self::MAP, $m, false );
		self::back( 'removed' );
	}

	public static function clear() {
		self::guard( 'mrsh_fix_clear' );
		update_option( self::LOG, array(), false );
		self::back( 'cleared' );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$log = (array) get_option( self::LOG, array() );
		uasort( $log, function ( $a, $b ) {
			return ( $b['n'] ?? 0 ) <=> ( $a['n'] ?? 0 );
		} );
		$map  = self::map();
		$post = admin_url( 'admin-post.php' );
		MRSH_Boost::ui_open( 'Broken addresses', 'Pages that visitors or Google tried to open but do not exist. Send each one to the right page with one press (a permanent 301 redirect).', 'g-red', 'M12 2 1 21h22L12 2zm1 15h-2v-2h2v2zm0-4h-2V9h2v4z' );
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			MRSH_Boost::ui_ok( 'Done.' );
		}
		echo '<div class="card" style="max-width:none;padding:16px;margin:12px 0"><h2 style="margin-top:0">1. Missing pages seen on the site</h2>';
		echo '<form method="post" action="' . esc_url( $post ) . '" style="margin:0 0 10px"><input type="hidden" name="action" value="mrsh_fix_auto">' . wp_nonce_field( 'mrsh_fix_auto', '_wpnonce', true, false ) . '<button class="button button-primary">Fix them automatically</button> <span class="description">Sends every address that clearly matches an existing page to it, and removes scanner junk. The Autopilot does this by itself every hour.</span></form>';
		if ( ! $log ) {
			echo '<p class="description">None yet. A missing page appears here after the first visit to it.</p>';
		}
		foreach ( $log as $p => $v ) {
			echo '<form method="post" action="' . esc_url( $post ) . '" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;padding:8px 0;border-bottom:1px solid #eee"><input type="hidden" name="action" value="mrsh_fix_add">' . wp_nonce_field( 'mrsh_fix_add', '_wpnonce', true, false ) . '<input type="hidden" name="from" value="' . esc_attr( $p ) . '"><code style="flex:1;min-width:200px;word-break:break-all">' . esc_html( $p ) . '</code><span class="description">' . (int) ( $v['n'] ?? 0 ) . ' visits, last ' . esc_html( human_time_diff( (int) ( $v['t'] ?? time() ) ) ) . ' ago</span><input type="text" name="to" placeholder="/page-to-send-them-to/" value="" style="min-width:200px"><button class="button button-primary">Redirect</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		if ( $log ) {
			echo '<form method="post" action="' . esc_url( $post ) . '" style="margin-top:10px"><input type="hidden" name="action" value="mrsh_fix_clear">' . wp_nonce_field( 'mrsh_fix_clear', '_wpnonce', true, false ) . '<button class="button">Clear this list</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</div><div class="card" style="max-width:none;padding:16px;margin:12px 0"><h2 style="margin-top:0">2. Add a redirect by hand</h2><form method="post" action="' . esc_url( $post ) . '" style="display:flex;gap:8px;flex-wrap:wrap"><input type="hidden" name="action" value="mrsh_fix_add">' . wp_nonce_field( 'mrsh_fix_add', '_wpnonce', true, false ) . '<input type="text" name="from" placeholder="/old-address/" style="min-width:240px" required><input type="text" name="to" placeholder="/new-address/" style="min-width:240px" required><button class="button button-primary">Add</button></form><p class="description">Only addresses on this site. Use this for links you see in Google Search Console under Pages > Not found (404).</p></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<div class="card" style="max-width:none;padding:16px;margin:12px 0"><h2 style="margin-top:0">3. Active redirects (' . (int) count( $map ) . ')</h2>';
		foreach ( $map as $from => $to ) {
			echo '<form method="post" action="' . esc_url( $post ) . '" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;padding:6px 0;border-bottom:1px solid #eee"><input type="hidden" name="action" value="mrsh_fix_del">' . wp_nonce_field( 'mrsh_fix_del', '_wpnonce', true, false ) . '<input type="hidden" name="from" value="' . esc_attr( $from ) . '"><code>' . esc_html( $from ) . '</code> &rarr; <code>' . esc_html( $to ) . '</code><button class="button button-small">Remove</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</div></div>';
	}
}
MRSH_Seofix::init();
