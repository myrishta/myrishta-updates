<?php
/**
 * AdSense guard: while the AdSense application is under review, a robot checks every day the things reviewers look at
 * and tells the owner (Inbox + daily report) about anything that could cause a rejection. It only reads and reports:
 * it never edits your content. Checks: live ads.txt, AdSense script and Mediapartners access, the legal pages (and that
 * the privacy policy talks about ads and cookies), thin indexable pages, words that break Google publisher policies,
 * member-profile moderation, https/search visibility, and the Site Kit AdSense status.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_AdsGuard {

	const RES  = 'mrsh_adg_res';
	const SEEN = 'mrsh_adg_seen';

	private static function get( $url ) {
		$r = wp_remote_get( $url, array( 'timeout' => 15, 'redirection' => 3, 'user-agent' => 'Mozilla/5.0 (compatible; MyRishtaGuard)' ) );
		return is_wp_error( $r ) ? array( 0, '' ) : array( (int) wp_remote_retrieve_response_code( $r ), (string) wp_remote_retrieve_body( $r ) );
	}

	/** @return array of array( ok(bool), label, detail, fix link ) */
	public static function run() {
		$c = array();
		// 1. ads.txt live and correct.
		list( $code, $body ) = self::get( home_url( '/ads.txt' ) );
		$c[]                 = array( 200 === $code && false !== stripos( $body, 'google.com, pub-' ), 'ads.txt is live and lists your publisher ID', 200 === $code ? 'Found.' : 'Not reachable (HTTP ' . $code . ').', admin_url( 'admin.php?page=mrads-check' ) );
		// 2. AdSense code on the home page; robots must not block Google's ad crawler.
		list( , $home ) = self::get( home_url( '/' ) );
		$c[]            = array( false !== strpos( $home, 'adsbygoogle.js' ) || false !== strpos( $home, 'google-adsense-account' ), 'AdSense code is on the home page', 'Needed so Google can verify the site.', admin_url( 'admin.php?page=mrads-check' ) );
		list( , $rob )  = self::get( home_url( '/robots.txt' ) );
		$blk            = (bool) preg_match( '/User-agent:\s*(\*|Mediapartners-Google|Googlebot)[^\n]*\n(?:(?!User-agent)[^\n]*\n)*?\s*Disallow:\s*\/\s*(\n|$)/i', $rob . "\n" );
		$c[]            = array( ! $blk, 'Google ad crawler is not blocked in robots.txt', $blk ? 'A rule blocks the whole site for Google.' : 'Open.', admin_url( 'admin.php?page=mrsh-keys' ) );
		// 3. Legal pages, and the privacy policy must talk about ads and cookies.
		foreach ( array( 'Privacy policy' => array( 'privacy-policy', 'privacy' ), 'Terms' => array( 'terms-and-conditions', 'terms' ), 'About' => array( 'about-us' ), 'Contact' => array( 'contact' ), 'Disclaimer' => array( 'disclaimer' ) ) as $l => $slugs ) {
			$p = null;
			foreach ( $slugs as $s ) {
				$p = get_page_by_path( $s );
				if ( $p && 'publish' === $p->post_status ) {
					break;
				}
				$p = null;
			}
			$c[] = array( (bool) $p, $l . ' page is published', $p ? 'Found.' : 'Missing: reviewers look for it.', $p ? get_edit_post_link( $p->ID, 'raw' ) : admin_url( 'post-new.php?post_type=page' ) );
			if ( $p && 'Privacy policy' === $l ) {
				$t   = strtolower( wp_strip_all_tags( $p->post_content ) );
				$ok  = false !== strpos( $t, 'cookie' ) && ( false !== strpos( $t, 'advertis' ) || false !== strpos( $t, 'google' ) );
				$c[] = array( $ok, 'Privacy policy mentions cookies and Google ads', $ok ? 'Yes.' : 'AdSense requires you to say that Google and partners use cookies for ads.', get_edit_post_link( $p->ID, 'raw' ) );
			}
		}
		// 4. Thin indexable content, and policy words, in published posts and pages.
		$posts = get_posts( array( 'post_type' => array( 'post', 'page' ), 'post_status' => 'publish', 'numberposts' => 300, 'suppress_filters' => true ) );
		$thin  = array();
		$risky = array();
		$ni    = class_exists( 'MRSH_Options' ) ? (array) MRSH_Options::get() : array();
		$skip  = array_merge( array( 'contact', 'sitemap', 'blog', 'latest-profiles', 'memberships' ), array_filter( array_map( 'trim', explode( ',', (string) ( $ni['noindex_slugs'] ?? '' ) ) ) ) );
		$re    = '/\b(porn|xxx|escort|sex chat|nude|casino|betting|gambling|jackpot|crack(ed)? software|keygen|buy followers|miracle cure|get rich quick|guaranteed profit)\b/i';
		foreach ( $posts as $p ) {
			$txt = wp_strip_all_tags( strip_shortcodes( (string) $p->post_content ) );
			if ( ! get_post_meta( $p->ID, '_mrsh_noindex', true ) && str_word_count( $txt ) < 150 && ! in_array( $p->post_name, $skip, true ) && self::rendered_words( $p ) < 150 ) {
				$thin[] = $p;
			}
			if ( preg_match( $re, $txt . ' ' . $p->post_title ) ) {
				$risky[] = $p;
			}
		}
		$c[] = array( ! $thin, 'No very short pages open to Google', $thin ? count( $thin ) . ' page(s) under 150 words, e.g. ' . esc_html( $thin[0]->post_title ) . '. Expand them or hide them from search.' : 'None.', $thin ? get_edit_post_link( $thin[0]->ID, 'raw' ) : '' );
		$c[] = array( ! $risky, 'No words that break Google publisher policies', $risky ? 'Check: ' . esc_html( $risky[0]->post_title ) . ( count( $risky ) > 1 ? ' and ' . ( count( $risky ) - 1 ) . ' more' : '' ) . '.' : 'Clean.', $risky ? get_edit_post_link( $risky[0]->ID, 'raw' ) : '' );
		// 5. Member profiles are user content: moderation must be on.
		$mod = class_exists( 'MRSH_AIHub' ) && MRSH_AIHub::ready() && ! empty( MRSH_AIHub::o()['prof'] );
		$c[] = array( $mod, 'New member profiles are screened by the AI', $mod ? 'On.' : 'Turn on the AI Assistant: reviewers want user content moderated.', admin_url( 'admin.php?page=mrsh-ai-hub' ) );
		$c[] = array( '1' === (string) get_option( 'blog_public' ) && 0 === strpos( home_url(), 'https' ), 'Site is on https and open to search engines', 'Required.', admin_url( 'options-reading.php' ) );
		// 6. What Site Kit says about the AdSense site.
		$sk = get_option( 'googlesitekit_adsense_settings' );
		if ( is_array( $sk ) && ! empty( $sk['siteStatus'] ) ) {
			$st  = (string) $sk['siteStatus'];
			$c[] = array( in_array( $st, array( 'ready' ), true ), 'Google AdSense site status: ' . $st, 'ready = approved. "getting-ready" means Google is still reviewing: nothing to do but wait and keep the site clean.', admin_url( 'admin.php?page=googlesitekit-settings' ) );
		}
		update_option( self::RES, array( 't' => time(), 'c' => $c ), false );
		// Tell the owner once per problem.
		$seen = get_option( self::SEEN, array() );
		$seen = is_array( $seen ) ? $seen : array();
		foreach ( $c as $r ) {
			$k = md5( $r[1] );
			if ( ! $r[0] && empty( $seen[ $k ] ) && class_exists( 'MRSH_Attn' ) && false === strpos( $r[1], 'site status' ) ) {
				MRSH_Attn::add( 'adsense', 0, 'AdSense check: ' . $r[1] . '. ' . wp_strip_all_tags( $r[2] ), $r[3] );
				$seen[ $k ] = time();
			} elseif ( $r[0] ) {
				unset( $seen[ $k ] );
			}
		}
		update_option( self::SEEN, $seen, false );
		$bad = count( array_filter( $c, function ( $r ) { return ! $r[0]; } ) );
		if ( class_exists( 'MRSH_Autopilot' ) ) {
			MRSH_Autopilot::log( 'AdSense', $bad ? $bad . ' item(s) could hurt the AdSense review; see the AdSense section.' : 'AdSense check: all clear.' );
		}
		return $c;
	}

	/** Words a visitor really sees: many pages keep their text in the theme or a shortcode, so the saved text alone is misleading. */
	private static function rendered_words( $p ) {
		static $n = 0;
		if ( $n++ > 40 ) {
			return 999; // never slow the check down: assume fine beyond 40 lookups
		}
		$r = wp_remote_get( get_permalink( $p ), array( 'timeout' => 8, 'redirection' => 2, 'headers' => array( 'Cache-Control' => 'no-cache' ) ) );
		if ( is_wp_error( $r ) || 200 !== (int) wp_remote_retrieve_response_code( $r ) ) {
			return 999; // not reachable here: do not raise a false alarm
		}
		$h = (string) wp_remote_retrieve_body( $r );
		if ( preg_match( '~<meta[^>]+name=["\']robots["\'][^>]*noindex~i', $h ) || false !== stripos( (string) wp_remote_retrieve_header( $r, 'x-robots-tag' ), 'noindex' ) ) {
			return 999; // hidden from search already, so Google never judges it
		}
		if ( preg_match( '~<main\b.*?</main>~is', $h, $m ) || preg_match( '~<article\b.*?</article>~is', $h, $m ) ) {
			$h = $m[0];
		}
		$h = preg_replace( '~<(script|style|noscript|svg)\b.*?</\1>~is', ' ', $h );
		return str_word_count( wp_strip_all_tags( $h ) );
	}

	public static function daily() {
		if ( get_option( 'mrsh_adg_day' ) === wp_date( 'Y-m-d' ) ) {
			return;
		}
		update_option( 'mrsh_adg_day', wp_date( 'Y-m-d' ), false );
		try {
			self::run();
		} catch ( \Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement
		}
	}

	public static function summary() {
		$r = get_option( self::RES, array() );
		if ( empty( $r['c'] ) ) {
			return '';
		}
		$bad = array_filter( $r['c'], function ( $x ) { return ! $x[0]; } );
		return $bad ? 'AdSense: ' . count( $bad ) . ' thing(s) to fix before approval (see AI Autopilot page).' : 'AdSense: all checks pass.';
	}

	public static function card() {
		$r = get_option( self::RES, array() );
		echo '<div class="mx-card"><h2 class="mx-h">AdSense approval guard</h2><p class="mx-sub">Checked every day while your AdSense application is under review. It only reports; it never changes your content.</p>';
		if ( empty( $r['c'] ) ) {
			echo '<p class="mx-sub">Not checked yet.</p>';
		} else {
			echo '<div class="mx-tbl"><table class="widefat striped"><tbody>';
			foreach ( $r['c'] as $x ) {
				echo '<tr><td>' . ( $x[0] ? '<span class="mx-pill ok">OK</span>' : '<span class="mx-pill bad">Fix</span>' ) . '</td><td><b>' . esc_html( $x[1] ) . '</b><br><small>' . wp_kses( $x[2], array() ) . '</small></td><td>' . ( ! $x[0] && $x[3] ? '<a class="mx-btn s" href="' . esc_url( $x[3] ) . '">Open</a>' : '' ) . '</td></tr>';
			}
			echo '</tbody></table></div><p class="mx-sub">Last check: ' . esc_html( wp_date( 'd M H:i', (int) $r['t'] ) ) . '</p>';
		}
		echo '<p><a class="mx-btn" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_adg_now' ), 'mrsh_adg' ) ) . '">Check now</a></p></div>';
	}

	public static function now() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'No.' );
		}
		check_admin_referer( 'mrsh_adg' );
		self::run();
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-autopilot&ok=1' ) );
		exit;
	}
}
add_action( 'admin_post_mrsh_adg_now', array( 'MRSH_AdsGuard', 'now' ) );
