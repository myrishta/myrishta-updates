<?php
/**
 * Bounced email handler. When a member's address does not exist ("Address not found"), the mail server sends a
 * "Delivery Status Notification (Failure)" back to the sending mailbox. This reads those messages from the sending
 * mailbox (IMAP, no PHP extension needed), finds the member and applies the action you choose:
 *   flag    - only mark the member so you see it on the Bounced emails page
 *   hide    - take the member's profile off the site (kept as a draft, restored with one button) [default]
 *   delete  - delete the account (never staff)
 * Only hard failures count (address not found, user unknown). Full mailbox, spam blocks and temporary errors are ignored.
 * Addresses that failed are never mailed again until the member changes their address.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Bounce {

	const OPT  = 'mrsh_bounce';
	const LIST = 'mrsh_bounce_list';
	const CRON = 'mrsh_bounce_tick';

	public static function o( $k = null ) {
		$o = array_merge( array( 'on' => 1, 'act' => 'hide', 'need' => 1, 'last' => '', 'msg' => '' ), (array) get_option( self::OPT, array() ) );
		return null === $k ? $o : $o[ $k ];
	}

	public static function init() {
		add_action( self::CRON, array( __CLASS__, 'tick' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 31 );
		foreach ( array( 'save', 'now', 'restore', 'del' ) as $a ) {
			add_action( 'admin_post_mrsh_bounce_' . $a, array( __CLASS__, $a ) );
		}
		add_filter( 'pre_wp_mail', array( __CLASS__, 'suppress' ), 5, 2 );
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::CRON ) ) {
			wp_schedule_event( time() + 300, 'hourly', self::CRON );
		}
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Bounced emails', 'Bounced emails', 'manage_options', 'mrsh-bounce', array( __CLASS__, 'page' ) );
	}

	/* ---------- never mail an address that failed ---------- */

	public static function suppress( $pre, $atts ) {
		if ( null !== $pre || empty( $atts['to'] ) ) {
			return $pre;
		}
		$list = (array) get_option( self::LIST, array() );
		if ( ! $list ) {
			return $pre;
		}
		$to = is_array( $atts['to'] ) ? implode( ',', $atts['to'] ) : (string) $atts['to'];
		if ( ! preg_match_all( '/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i', $to, $m ) || empty( $m[0] ) ) {
			return $pre;
		}
		foreach ( $m[0] as $addr ) {
			if ( ! isset( $list[ strtolower( $addr ) ] ) ) {
				return $pre; // at least one good address: send normally
			}
		}
		return true; // every address is known to bounce: skip quietly
	}

	/* ---------- reading the mailbox ---------- */

	private static function cmd( $fp, &$n, $cmd, &$lit ) {
		$n++;
		$tag = 'B' . $n;
		fwrite( $fp, $tag . ' ' . $cmd . "\r\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$out = '';
		$lit = array();
		while ( ! feof( $fp ) ) {
			$line = fgets( $fp, 8192 ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			if ( false === $line ) {
				break;
			}
			if ( 0 === strpos( $line, $tag . ' ' ) ) {
				return array( (bool) preg_match( '/^' . $tag . ' OK/i', $line ), $out . $line );
			}
			if ( preg_match( '/\{(\d+)\}\r?\n$/', $line, $m ) ) {
				$size = (int) $m[1];
				$buf  = '';
				while ( strlen( $buf ) < $size && ! feof( $fp ) ) {
					$chunk = fread( $fp, min( 8192, $size - strlen( $buf ) ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
					if ( false === $chunk || '' === $chunk ) {
						break;
					}
					$buf .= $chunk;
				}
				$lit[] = $size <= 800000 ? $buf : '';
			}
			$out .= $line;
		}
		return array( false, $out );
	}

	/** array( ok, message, mails ) where mails = array( uid => raw ). Marks fetched messages as read. */
	private static function fetch( $limit = 30 ) {
		$s    = (array) get_option( 'mrsh_smtp', array() );
		$user = (string) ( $s['user'] ?? '' );
		$pass = (string) ( $s['pass'] ?? '' );
		if ( '' === $pass || ! is_email( $user ) ) {
			return array( false, 'The sending mailbox password is not saved yet (Email (SMTP) page).', array() );
		}
		$host = preg_replace( '/^smtp\./', 'imap.', (string) ( $s['host'] ?? 'smtp.hostinger.com' ) );
		$en   = 0;
		$es   = '';
		$fp   = @stream_socket_client( 'ssl://' . $host . ':993', $en, $es, 12, STREAM_CLIENT_CONNECT ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		if ( ! $fp ) {
			return array( false, 'Could not connect to ' . $host . ' (' . $es . ').', array() );
		}
		stream_set_timeout( $fp, 15 );
		fgets( $fp, 4096 ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$n   = 0;
		$lit = array();
		list( $ok ) = self::cmd( $fp, $n, 'LOGIN "' . addcslashes( $user, "\\\"" ) . '" "' . addcslashes( $pass, "\\\"" ) . '"', $lit );
		if ( ! $ok ) {
			fclose( $fp ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			return array( false, 'Login to ' . $user . ' was refused by the mail server.', array() );
		}
		list( $ok ) = self::cmd( $fp, $n, 'SELECT INBOX', $lit );
		if ( ! $ok ) {
			fclose( $fp ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			return array( false, 'Could not open the inbox.', array() );
		}
		list( $ok, $r ) = self::cmd( $fp, $n, 'UID SEARCH UNSEEN OR FROM "mailer-daemon" FROM "postmaster"', $lit );
		$uids = array();
		if ( $ok && preg_match( '/\* SEARCH([0-9 ]*)/', $r, $m ) ) {
			$uids = array_values( array_filter( array_map( 'intval', preg_split( '/\s+/', trim( $m[1] ) ) ) ) );
		}
		$mails = array();
		foreach ( array_slice( $uids, 0, $limit ) as $uid ) {
			list( $ok ) = self::cmd( $fp, $n, 'UID FETCH ' . $uid . ' (BODY.PEEK[])', $lit );
			if ( $ok && ! empty( $lit[0] ) ) {
				$mails[ $uid ] = $lit[0];
			}
		}
		foreach ( array_keys( $mails ) as $uid ) {
			self::cmd( $fp, $n, 'UID STORE ' . $uid . ' +FLAGS (\\Seen)', $lit );
		}
		self::cmd( $fp, $n, 'LOGOUT', $lit );
		fclose( $fp ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		return array( true, count( $uids ) . ' bounce message(s) waiting.', $mails );
	}

	/** array( email, reason ) for a real permanent failure, else null. */
	public static function parse( $raw ) {
		$raw = str_replace( "\r\n", "\n", (string) $raw );
		$hdr = (string) strstr( $raw, "\n\n", true );
		if ( ! preg_match( '/^From:.*(mailer-daemon|postmaster)/im', $hdr ) && ! preg_match( '/^Subject:.*(undeliver|delivery status|failure notice|returned mail|delivery has failed|delivery failure)/im', $hdr ) ) {
			return null;
		}
		$txt = $raw . "\n" . quoted_printable_decode( $raw );
		if ( preg_match_all( '#Content-Transfer-Encoding:\s*base64\s*\n\n([A-Za-z0-9+/=\s]+?)\n\n#i', $raw, $b ) ) {
			foreach ( $b[1] as $blob ) {
				$txt .= "\n" . (string) base64_decode( preg_replace( '/\s+/', '', $blob ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
			}
		}
		$email = '';
		foreach ( array( '/Final-Recipient:\s*rfc822;\s*<?([^\s>;]+@[^\s>;]+)/i', '/X-Failed-Recipients:\s*<?([^\s>,]+@[^\s>,]+)/i', '/(?:wasn\'?t delivered to|delivery to the following recipient[s]? failed[^\n]*\n+\s*)<?([^\s<>]+@[^\s<>]+)/i', '/<([^<>\s]+@[^<>\s]+)>:\s*\n?\s*(?:host|550|user|mailbox|the email)/i' ) as $re ) {
			if ( preg_match( $re, $txt, $m ) && is_email( rtrim( $m[1], '.,;' ) ) ) {
				$email = strtolower( rtrim( $m[1], '.,;' ) );
				break;
			}
		}
		if ( '' === $email ) {
			return null;
		}
		$soft = (bool) preg_match( '/Status:\s*(4\.\d+\.\d+|5\.2\.[12]|5\.7\.\d+|5\.3\.4)|mailbox (is )?full|over quota|quota exceeded|spam|blocked|blacklist|policy|rate limit|temporar|try again/i', $txt );
		$hard = (bool) preg_match( '/Status:\s*5\.1\.\d+|address (not found|couldn.t be found)|user unknown|no such user|does not exist|doesn.t exist|unable to receive mail|recipient (address )?rejected|invalid (recipient|address)|mailbox (not found|unavailable)|unknown recipient|domain (not found|does not exist)|no mx/i', $txt );
		if ( ! $hard || ( $soft && ! preg_match( '/Status:\s*5\.1\.\d+|address not found|user unknown|no such user/i', $txt ) ) ) {
			return null;
		}
		$why = 'Address not found';
		if ( preg_match( '/Diagnostic-Code:[^\n]*\n?[^\n]*/i', $txt, $m ) ) {
			$why = trim( preg_replace( '/\s+/', ' ', substr( $m[0], 0, 160 ) ) );
		}
		return array( $email, $why );
	}

	/* ---------- acting on a failed address ---------- */

	/** Staff are never touched. Members are subscribers who also hold edit_posts (so they can add a profile), so that alone is not staff. */
	private static function protected_user( $u ) {
		if ( array_intersect( (array) $u->roles, array( 'administrator', 'editor', 'author', 'contributor', 'shop_manager' ) ) ) {
			return true;
		}
		return user_can( $u, 'manage_options' ) || user_can( $u, 'edit_others_posts' ) || user_can( $u, 'publish_posts' );
	}

	/** Apply the chosen action to one failed address when its rule is met. Returns the new status text or ''. */
	private static function act( $email, &$row ) {
		$o = self::o();
		$u = get_user_by( 'email', $email );
		if ( ! $u || self::protected_user( $u ) || '' !== (string) $row['done'] || (int) $row['n'] < max( 1, (int) $o['need'] ) ) {
			return '';
		}
		update_user_meta( $u->ID, 'mrsh_mail_bad', time() );
		if ( 'hide' === $o['act'] ) {
			$ids = get_posts( array( 'post_type' => 'listing_type', 'post_status' => 'publish', 'author' => $u->ID, 'numberposts' => 50, 'fields' => 'ids', 'suppress_filters' => true ) );
			foreach ( $ids as $i ) {
				wp_update_post( array( 'ID' => $i, 'post_status' => 'draft' ) );
			}
			update_user_meta( $u->ID, 'mrsh_bounce_hid', $ids );
			return 'hidden';
		}
		if ( 'delete' === $o['act'] ) {
			if ( class_exists( 'MRSH_Autopilot' ) ) {
				MRSH_Autopilot::safe_delete( $u, 'email address bounced' );
			} else {
				require_once ABSPATH . 'wp-admin/includes/user.php';
				wp_delete_user( $u->ID );
			}
			return 'deleted';
		}
		return 'flagged';
	}

	public static function apply( $email, $why ) {
		$list = (array) get_option( self::LIST, array() );
		$was  = isset( $list[ $email ] );
		$row  = array( 'time' => $was ? $list[ $email ]['time'] : time(), 'why' => $why, 'n' => ( $was ? (int) $list[ $email ]['n'] : 0 ) + 1, 'done' => $was ? (string) $list[ $email ]['done'] : '' );
		$row['done'] = self::act( $email, $row ) ?: $row['done'];
		$list[ $email ] = $row;
		update_option( self::LIST, $list, false );
	}

	/** Re-check failed addresses that are still waiting (a rule changed, or a member signed up with that address). */
	public static function pending() {
		$list = (array) get_option( self::LIST, array() );
		$n    = 0;
		foreach ( $list as $email => $row ) {
			$d = self::act( $email, $row );
			if ( $d ) {
				$list[ $email ]['done'] = $d;
				++$n;
			}
		}
		if ( $n ) {
			update_option( self::LIST, $list, false );
		}
		return $n;
	}

	public static function run() {
		if ( ! self::o( 'on' ) ) {
			return 'Switched off.';
		}
		list( $ok, $msg, $mails ) = self::fetch();
		$found = 0;
		if ( $ok ) {
			foreach ( $mails as $raw ) {
				$p = self::parse( $raw );
				if ( $p ) {
					self::apply( $p[0], $p[1] );
					++$found;
				}
			}
			$msg = $found . ' failed address(es) handled. ' . $msg;
		}
		$p = self::pending();
		if ( $p ) {
			$msg .= ' ' . $p . ' member(s) updated.';
		}
		$o        = (array) get_option( self::OPT, array() );
		$o['last'] = wp_date( 'Y-m-d H:i' );
		$o['msg']  = $msg;
		update_option( self::OPT, $o, false );
		return $msg;
	}

	public static function tick() {
		self::run();
	}

	/* ---------- buttons ---------- */

	private static function guard( $a ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( $a );
	}

	private static function back( $m = '' ) {
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-bounce' . ( $m ? '&done=' . rawurlencode( $m ) : '' ) ) );
		exit;
	}

	public static function save() {
		self::guard( 'mrsh_bounce_save' );
		$o        = (array) get_option( self::OPT, array() );
		$o['on']  = empty( $_POST['on'] ) ? 0 : 1; // phpcs:ignore
		$a        = sanitize_key( $_POST['act'] ?? 'hide' ); // phpcs:ignore
		$o['act'] = in_array( $a, array( 'flag', 'hide', 'delete' ), true ) ? $a : 'hide';
		$o['need'] = max( 1, min( 5, (int) ( $_POST['need'] ?? 1 ) ) ); // phpcs:ignore
		update_option( self::OPT, $o, false );
		self::back( 'Saved.' );
	}

	public static function now() {
		self::guard( 'mrsh_bounce_now' );
		self::back( self::run() );
	}

	public static function restore() {
		$e = sanitize_email( rawurldecode( (string) ( $_GET['e'] ?? '' ) ) ); // phpcs:ignore
		self::guard( 'mrsh_bounce_r_' . md5( $e ) );
		$e    = strtolower( $e );
		$list = (array) get_option( self::LIST, array() );
		$u    = get_user_by( 'email', $e );
		if ( $u ) {
			foreach ( (array) get_user_meta( $u->ID, 'mrsh_bounce_hid', true ) as $i ) {
				if ( $i && 'draft' === get_post_status( $i ) ) {
					wp_update_post( array( 'ID' => (int) $i, 'post_status' => 'publish' ) );
				}
			}
			delete_user_meta( $u->ID, 'mrsh_bounce_hid' );
			delete_user_meta( $u->ID, 'mrsh_mail_bad' );
		}
		unset( $list[ $e ] );
		update_option( self::LIST, $list, false );
		self::back( 'Restored. This address will be mailed again.' );
	}

	public static function del() {
		$e = sanitize_email( rawurldecode( (string) ( $_GET['e'] ?? '' ) ) ); // phpcs:ignore
		self::guard( 'mrsh_bounce_d_' . md5( $e ) );
		$u = get_user_by( 'email', $e );
		if ( $u && ! self::protected_user( $u ) ) {
			if ( class_exists( 'MRSH_Autopilot' ) ) {
				MRSH_Autopilot::safe_delete( $u, 'email bounced (removed by owner)' );
			} else {
				require_once ABSPATH . 'wp-admin/includes/user.php';
				wp_delete_user( $u->ID );
			}
			$list                      = (array) get_option( self::LIST, array() );
			$list[ strtolower( $e ) ]['done'] = 'deleted';
			update_option( self::LIST, $list, false );
			self::back( 'Account deleted.' );
		}
		self::back( 'No member account to delete.' );
	}

	/* ---------- page ---------- */

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$o    = self::o();
		$list = (array) get_option( self::LIST, array() );
		$post = esc_url( admin_url( 'admin-post.php' ) );
		$cnt  = array( 'hidden' => 0, 'deleted' => 0, 'wait' => 0 );
		foreach ( $list as $r ) {
			$d = $r['done'] ?? '';
			if ( 'hidden' === $d ) {
				++$cnt['hidden'];
			} elseif ( 'deleted' === $d ) {
				++$cnt['deleted'];
			} else {
				++$cnt['wait'];
			}
		}
		MRSH_Admin::open( 'Bounced emails', 'Reads delivery-failure notices from your sending mailbox and handles members whose email address does not exist.' );
		if ( ! empty( $_GET['done'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( wp_unslash( $_GET['done'] ) ) . '</p></div>'; // phpcs:ignore
		}
		echo '<div class="mrsh-grid mrsh-grid-4">';
		echo MRSH_Admin::stat( 'Failed addresses', count( $list ), 'never mailed again' ); // phpcs:ignore
		echo MRSH_Admin::stat( 'Profiles hidden', (int) $cnt['hidden'], 'one click brings back' ); // phpcs:ignore
		echo MRSH_Admin::stat( 'Accounts deleted', (int) $cnt['deleted'], 'by your rule' ); // phpcs:ignore
		echo MRSH_Admin::stat( 'Automatic reading', $o['on'] ? 'On' : 'Off', $o['last'] ? 'last check ' . $o['last'] : 'not checked yet' ); // phpcs:ignore
		echo '</div>';
		echo '<p class="mrsh-muted">Only permanent failures count; a full inbox or a temporary error is ignored.</p>';

		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Settings</h2></div><form method="post" action="' . $post . '">';
		wp_nonce_field( 'mrsh_bounce_save' );
		echo '<input type="hidden" name="action" value="mrsh_bounce_save">';
		echo '<p><label><input type="checkbox" name="on" value="1"' . checked( $o['on'], 1, false ) . '> Read bounce notices automatically (every hour)</label></p>';
		echo '<p>When an address fails <select name="need">';
		foreach ( array( 1, 2, 3 ) as $n ) {
			echo '<option value="' . $n . '"' . selected( (int) $o['need'], $n, false ) . '>' . $n . ' time' . ( $n > 1 ? 's' : '' ) . '</option>';
		}
		echo '</select> do this:</p><p>';
		foreach ( array( 'flag' => 'Only mark the member (nothing is removed)', 'hide' => 'Hide the member\'s profile from the site (recommended, one button brings it back)', 'delete' => 'Delete the member\'s account' ) as $k => $l ) {
			echo '<label style="display:block;margin:4px 0"><input type="radio" name="act" value="' . esc_attr( $k ) . '"' . checked( $o['act'], $k, false ) . '> ' . esc_html( $l ) . '</label>';
		}
		echo '</p><p class="description">Staff and editors are never touched. Failed addresses are never mailed again until the member changes their address.</p><button class="button button-primary">Save settings</button></form>';
		echo '<form method="post" action="' . $post . '" style="margin-top:10px">';
		wp_nonce_field( 'mrsh_bounce_now' );
		echo '<input type="hidden" name="action" value="mrsh_bounce_now"><button class="button">Check the mailbox now</button> <span class="description">' . ( $o['last'] ? 'Last check ' . esc_html( $o['last'] ) . ': ' . esc_html( $o['msg'] ) : 'Not checked yet.' ) . '</span></form></div>';

		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Failed addresses (' . count( $list ) . ')</h2></div>';
		if ( ! $list ) {
			echo '<p>None yet.</p>';
		} else {
			echo '<div style="overflow-x:auto"><table class="widefat striped mrsh-table"><thead><tr><th>Email</th><th>Member</th><th>Reason</th><th>Times</th><th>Date</th><th>Status</th><th></th></tr></thead><tbody>';
			uasort( $list, function ( $a, $b ) { return (int) $b['time'] <=> (int) $a['time']; } );
			foreach ( $list as $e => $r ) {
				$u    = get_user_by( 'email', $e );
				$st   = array( 'hidden' => 'Profile hidden', 'deleted' => 'Account deleted', 'flagged' => 'Marked' );
				$ru   = wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_bounce_restore&e=' . rawurlencode( $e ) ), 'mrsh_bounce_r_' . md5( $e ) );
				$du   = wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_bounce_del&e=' . rawurlencode( $e ) ), 'mrsh_bounce_d_' . md5( $e ) );
				echo '<tr><td>' . esc_html( $e ) . '</td><td>' . ( $u ? '<a href="' . esc_url( get_edit_user_link( $u->ID ) ) . '">' . esc_html( $u->display_name ) . '</a>' : '<span class="mrsh-muted">not a member</span>' ) . '</td><td>' . esc_html( $r['why'] ) . '</td><td>' . (int) $r['n'] . '</td><td>' . esc_html( wp_date( 'Y-m-d', (int) $r['time'] ) ) . '</td><td>' . MRSH_Admin::badge( 'deleted' === ( $r['done'] ?? '' ) ? 'fail' : ( 'hidden' === ( $r['done'] ?? '' ) ? 'pass' : 'warn' ), $st[ $r['done'] ?? '' ] ?? 'Waiting for the rule' ) . '</td><td style="white-space:nowrap"><a class="button button-small" href="' . esc_url( $ru ) . '">Restore</a>' . ( $u && 'deleted' !== $r['done'] ? ' <a class="button button-small" href="' . esc_url( $du ) . '" onclick="return confirm(\'Delete this account?\')">Delete account</a>' : '' ) . '</td></tr>';
			}
			echo '</tbody></table></div>';
		}
		echo '</div>';
		MRSH_Admin::close();
	}
}
MRSH_Bounce::init();
