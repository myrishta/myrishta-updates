<?php
/**
 * "Write my story for me": a button under the Your story box on the create-profile form.
 * It takes the answers the member has already chosen (age, education, job, city...) and writes a short, honest first
 * draft in English, Urdu or Roman Urdu. The member reads it, changes it and decides. It invents nothing: only the chosen
 * answers are used. With the free AI on it is written by the AI; with AI off, busy or out of quota, a plain template is
 * used, so the button always works. No phone numbers, e-mails or links are ever put in. Six drafts per member per day.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Story {

	const MAX = 6;

	public static function init() {
		if ( class_exists( 'MRSH_Switch' ) && ! MRSH_Switch::on( 'storyhelper' ) ) {
			return;
		}
		add_action( 'wp_ajax_mrsh_story', array( __CLASS__, 'ajax' ) );
		add_action( 'wp_footer', array( __CLASS__, 'js' ), 98 );
		add_action( 'wp_ajax_mrsh_msg', array( __CLASS__, 'msg_ajax' ) );
		add_action( 'wp_footer', array( __CLASS__, 'msg_js' ), 98 );
	}

	/** Polite chat messages. Same rules as the story: nothing invented, no contact details, always editable, works without AI. */
	private static function msg_text( $purpose, $lang ) {
		$t = array(
			'intro'    => array(
				'en'  => 'Assalamu alaikum. I saw your profile and wanted to say hello politely. I would be glad to know you and your family better, with respect.',
				'ur'  => 'السلام علیکم۔ میں نے آپ کی پروفائل دیکھی اور احترام کے ساتھ سلام کرنا چاہا۔ مجھے آپ اور آپ کے گھرانے کو بہتر جاننے کی خوشی ہوگی۔',
				'rur' => 'Assalam o alaikum. Maine aap ki profile dekhi aur izzat ke sath salam karna chaha. Mujhe aap aur aap ke gharane ko behtar jaan kar khushi hogi.',
			),
			'interest' => array(
				'en'  => 'Assalamu alaikum. I liked your profile and I am interested in a rishta. If you are also interested, InshaAllah we can talk through our families.',
				'ur'  => 'السلام علیکم۔ مجھے آپ کی پروفائل پسند آئی ہے اور رشتے میں دلچسپی ہے۔ اگر آپ بھی راضی ہوں تو ان شاء اللہ گھر والوں کے ذریعے بات کر لیتے ہیں۔',
				'rur' => 'Assalam o alaikum. Mujhe aap ki profile pasand aayi hai aur rishte mein dilchaspi hai. Agar aap bhi razi hon to InshaAllah ghar walon ke zariye baat kar lete hain.',
			),
			'family'   => array(
				'en'  => 'Assalamu alaikum. If you agree, my family would like to speak with your family. Please tell me which time suits you.',
				'ur'  => 'السلام علیکم۔ اگر آپ راضی ہوں تو میرے گھر والے آپ کے گھر والوں سے بات کرنا چاہیں گے۔ براہ کرم بتائیں کہ آپ کو کون سا وقت مناسب ہے۔',
				'rur' => 'Assalam o alaikum. Agar aap razi hon to mere ghar wale aap ke ghar walon se baat karna chahein ge. Meharbani karke bataein kaun sa waqt munasib hai.',
			),
			'decline'  => array(
				'en'  => 'Assalamu alaikum. Thank you for your message and your time. I do not think we are a good match, so I politely say no. I wish you the very best, InshaAllah.',
				'ur'  => 'السلام علیکم۔ آپ کے پیغام اور وقت کا شکریہ۔ مجھے لگتا ہے کہ ہمارا رشتہ مناسب نہیں رہے گا، اس لیے احترام کے ساتھ معذرت۔ اللہ آپ کو بہتر نصیب عطا فرمائے۔',
				'rur' => 'Assalam o alaikum. Aap ke paigham aur waqt ka shukriya. Mujhe lagta hai hamara rishta munasib nahi rahe ga, is liye izzat ke sath maazrat. Allah aap ko behtar naseeb ata farmaye.',
			),
			'thanks'   => array(
				'en'  => 'Thank you for your reply and for your time. I appreciate your respect. JazakAllah.',
				'ur'  => 'آپ کے جواب اور وقت کا شکریہ۔ آپ کے احترام کی قدر کرتا/کرتی ہوں۔ جزاک اللہ۔',
				'rur' => 'Aap ke jawab aur waqt ka shukriya. Aap ki izzat ki qadar hai. JazakAllah.',
			),
		);
		return $t[ $purpose ][ $lang ] ?? '';
	}

	public static function msg_ajax() {
		check_ajax_referer( 'mrsh_msg', 'n' );
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'msg' => 'Please log in first.' ) );
		}
		$uid = get_current_user_id();
		$key = 'mrsh_msgw_' . $uid . '_' . wp_date( 'Ymd' );
		$n   = (int) get_transient( $key );
		if ( $n >= 25 ) {
			wp_send_json_error( array( 'msg' => 'You have used today\'s message help. Please write it yourself or try tomorrow.' ) );
		}
		$purposes = array( 'intro' => 'a polite first hello that introduces the sender and says they would like to know the person and the family better', 'interest' => 'a respectful message saying they liked the profile and are interested, and suggesting to continue through the families', 'family' => 'a respectful request that the sender\'s family can speak with the other person\'s family, asking which time suits', 'decline' => 'a kind, polite refusal that thanks the person and wishes them well, with no reasons that could hurt', 'thanks' => 'a short thank-you for the reply and the person\'s time and respect' );
		$p    = sanitize_key( wp_unslash( $_POST['purpose'] ?? '' ) ); // phpcs:ignore
		$lang = in_array( $_POST['lang'] ?? '', array( 'en', 'ur', 'rur' ), true ) ? sanitize_key( wp_unslash( $_POST['lang'] ) ) : 'en'; // phpcs:ignore
		if ( ! isset( $purposes[ $p ] ) ) {
			wp_send_json_error( array( 'msg' => 'Choose what you want to say.' ) );
		}
		set_transient( $key, $n + 1, DAY_IN_SECONDS );
		$hint = trim( wp_strip_all_tags( (string) wp_unslash( $_POST['hint'] ?? '' ) ) ); // phpcs:ignore
		$hint = mb_substr( $hint, 0, 300 );
		$text = '';
		if ( class_exists( 'MRSH_AIHub' ) && MRSH_AIHub::ready() ) {
			$names = array( 'en' => 'simple English', 'ur' => 'simple Urdu in Urdu script', 'rur' => 'simple Roman Urdu (Urdu written in English letters)' );
			$sys   = 'You help a person on a Pakistani matrimonial site write a message to another member. Write 2 to 3 short sentences in ' . $names[ $lang ] . ': ' . $purposes[ $p ] . '. Be respectful and modest, with a natural Islamic greeting. Do not assume the sender\'s or receiver\'s gender. Do not invent facts about either person. No phone numbers, e-mail, links, social accounts, addresses or emojis, and never ask to move the chat to another app. Output only the message.';
			$a     = MRSH_AIHub::ask( $sys, '' !== $hint ? 'The sender already wrote this and wants it improved: ' . $hint : 'Write the message.', 220 );
			if ( ! is_wp_error( $a ) ) {
				$text = trim( wp_strip_all_tags( $a ) );
				$text = preg_replace( '#https?://\S+|www\.\S+|[\w.+-]+@[\w-]+\.[\w.]+|\+?\d[\d\s\-]{7,}\d#u', '', $text );
			}
		}
		$ai = mb_strlen( $text ) >= 15;
		if ( ! $ai ) {
			$text = self::msg_text( $p, $lang );
		}
		wp_send_json_success( array( 'text' => mb_substr( $text, 0, 600 ), 'ai' => $ai ) );
	}

	public static function msg_js() {
		if ( is_admin() || ! is_user_logged_in() ) {
			return;
		}
		?>
<script id="mrsh-msgw-js">
(function(){var box=document.getElementById('mrt-chat');if(!box||box.dataset.mw)return;var ta=box.querySelector('textarea');if(!ta)return;box.dataset.mw=1;
var AJ=<?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>,N=<?php echo wp_json_encode( wp_create_nonce( 'mrsh_msg' ) ); ?>,lang='en';
var w=document.createElement('div');w.style.cssText='margin:6px 0';
var t=document.createElement('button');t.type='button';t.className='chip';t.textContent='✨ Help me write / لکھنے میں مدد';w.appendChild(t);
var p=document.createElement('div');p.hidden=true;p.style.cssText='margin-top:6px;padding:8px;border:1px dashed #c9b9d6;border-radius:12px;background:#faf7fd';
var lr=document.createElement('div');lr.style.cssText='display:flex;gap:6px;margin-bottom:6px';
var L=[['en','English'],['ur','اردو'],['rur','Roman Urdu']];L.forEach(function(x){var b=document.createElement('button');b.type='button';b.className='chip';b.textContent=x[1];b.style.opacity=x[0]===lang?'1':'.55';b.onclick=function(){lang=x[0];[].forEach.call(lr.children,function(c,i){c.style.opacity=L[i][0]===lang?'1':'.55'})};lr.appendChild(b)});p.appendChild(lr);
var m=document.createElement('small');m.className='ml';m.style.cssText='display:block;margin-top:6px';
var P=[['intro','Say hello / سلام اور تعارف'],['interest','Show interest / دلچسپی'],['family','Families talk / گھر والوں کی بات'],['decline','Politely say no / شائستہ انکار'],['thanks','Thank you / شکریہ']];
var pr=document.createElement('div');pr.style.cssText='display:flex;flex-wrap:wrap;gap:6px';
P.forEach(function(x){var b=document.createElement('button');b.type='button';b.className='chip';b.textContent=x[1];b.onclick=function(){this.blur();m.textContent='Writing... / لکھ رہا ہے...';var fd=new FormData();fd.append('action','mrsh_msg');fd.append('n',N);fd.append('lang',lang);fd.append('purpose',x[0]);fd.append('hint',ta.value||'');
fetch(AJ,{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(j){if(j&&j.success){ta.value=j.data.text;ta.dir=lang==='ur'?'rtl':'ltr';ta.dispatchEvent(new Event('input',{bubbles:true}));ta.focus();m.textContent='Added. Read it, change it if you like, then press send. / پڑھ لیں، چاہیں تو بدلیں، پھر بھیجیں۔'}else{m.textContent=(j&&j.data&&j.data.msg)||'Could not write now.'}}).catch(function(){m.textContent='No connection. Please try again.'})};pr.appendChild(b)});
p.appendChild(pr);p.appendChild(m);w.appendChild(p);t.onclick=function(){p.hidden=!p.hidden};
var cp=ta.closest('.cmp')||ta.parentNode;cp.parentNode.insertBefore(w,cp);
})();
</script>
		<?php
	}

	/** Labels that may be used. Contact details and free text are never sent. */
	private static function allowed( $label ) {
		return (bool) preg_match( '/^(profile created by|gender|age|marital status|children|religion|sect|caste|nationalt?y|education|occupation|city|town|city \/ town|country|my body|my hair|my eyes)\b/i', trim( $label ) );
	}

	private static function clean_facts( $raw ) {
		$in  = json_decode( (string) $raw, true );
		$out = array();
		if ( ! is_array( $in ) ) {
			return $out;
		}
		foreach ( $in as $k => $v ) {
			$k = trim( preg_replace( '/\s*[\/*].*$/u', '', wp_strip_all_tags( (string) $k ) ) );
			$v = trim( wp_strip_all_tags( (string) $v ) );
			if ( '' === $k || '' === $v || ! self::allowed( $k ) || mb_strlen( $v ) > 60 || preg_match( '/\d{5,}|@|https?:|www\./i', $v ) || preg_match( '/^(select|prefer not)/i', $v ) ) {
				continue;
			}
			$out[ strtolower( $k ) ] = $v;
		}
		return $out;
	}

	private static function pick( $f, $keys ) {
		foreach ( (array) $keys as $k ) {
			foreach ( $f as $fk => $v ) {
				if ( 0 === strpos( $fk, $k ) ) {
					return $v;
				}
			}
		}
		return '';
	}

	/** Plain draft that needs no AI. */
	private static function template( $f, $lang ) {
		$age  = self::pick( $f, 'age' );
		$g    = strtolower( self::pick( $f, 'gender' ) );
		$mar  = self::pick( $f, 'marital' );
		$edu  = self::pick( $f, 'education' );
		$job  = self::pick( $f, 'occupation' );
		$city = self::pick( $f, array( 'city', 'town' ) );
		if ( 'ur' === $lang || 'rur' === $lang ) {
			$fem = false !== strpos( $g, 'female' );
			$ur  = function ( $s ) {
				return function_exists( 'mrt_bi_find' ) && '' !== mrt_bi_find( $s, true ) ? mrt_bi_find( $s, true ) : $s;
			};
			$p   = array();
			if ( $age ) {
				$p[] = 'میں ' . $age . ' سال ' . ( $fem ? 'کی' : 'کا' ) . ' ہوں';
			} else {
				$p[] = 'میرا تعارف';
			}
			if ( $city ) {
				$p[] = $city . ' سے ہوں';
			}
			if ( $edu ) {
				$p[] = 'میری تعلیم ' . $ur( $edu ) . ' ہے';
			}
			if ( $job ) {
				$p[] = 'اور میں ' . $ur( $job ) . ' ہوں';
			}
			return implode( '، ', $p ) . '۔ میں ایک سمجھدار اور باعزت رشتہ ' . ( $fem ? 'چاہتی' : 'چاہتا' ) . ' ہوں۔';
		}
		$bits = array();
		$who  = 'I am' . ( $age ? ' ' . $age . ' years old' : '' );
		if ( $mar && ! preg_match( '/^prefer/i', $mar ) ) {
			$who .= ' and ' . strtolower( $mar );
		}
		if ( $city ) {
			$who .= ', living in ' . $city;
		}
		$bits[] = $who . '.';
		if ( $edu ) {
			$bits[] = 'My education is ' . $edu . '.';
		}
		if ( $job ) {
			$bits[] = 'My occupation is ' . $job . '.';
		}
		$bits[] = 'I am looking for a respectful and understanding life partner.';
		return implode( ' ', $bits );
	}

	public static function ajax() {
		check_ajax_referer( 'mrsh_story', 'n' );
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'msg' => 'Please log in first.' ) );
		}
		$uid = get_current_user_id();
		$key = 'mrsh_story_' . $uid . '_' . wp_date( 'Ymd' );
		$n   = (int) get_transient( $key );
		if ( $n >= self::MAX ) {
			wp_send_json_error( array( 'msg' => 'You have used today\'s drafts. Please edit the text you have, or try tomorrow.' ) );
		}
		$lang = in_array( $_POST['lang'] ?? '', array( 'en', 'ur', 'rur' ), true ) ? sanitize_key( wp_unslash( $_POST['lang'] ) ) : 'en'; // phpcs:ignore
		$f    = self::clean_facts( wp_unslash( $_POST['facts'] ?? '' ) ); // phpcs:ignore
		if ( count( $f ) < 2 ) {
			wp_send_json_error( array( 'msg' => 'Please fill in a few answers above first (age, education, job, city). Then I can write a draft.' ) );
		}
		set_transient( $key, $n + 1, DAY_IN_SECONDS );
		$by   = strtolower( self::pick( $f, 'profile created' ) );
		$self = '' === $by || 'self' === $by;
		$text = '';
		$ai   = false;
		if ( class_exists( 'MRSH_AIHub' ) && MRSH_AIHub::ready() ) {
			$names = array( 'en' => 'simple English', 'ur' => 'simple Urdu in Urdu script', 'rur' => 'simple Roman Urdu (Urdu written in English letters)' );
			$sys   = 'You write a short profile "about me" for a Pakistani matrimonial site. Write 3 to 4 short sentences in ' . $names[ $lang ] . '. '
				. ( $self ? 'Write in the first person ("I").' : 'Write as the family member who is making the profile (for example "Our son ..." or "My sister ..."), third person about the candidate.' )
				. ' Use ONLY the facts given. Do not invent hobbies, qualities, income, family details, looks or achievements. Do not praise too much. Keep a respectful, modest, honest tone. Mention being open to a respectful partner in one general sentence only. No phone numbers, e-mail, links, names or emojis. Output only the text.';
			$lines = array();
			foreach ( $f as $k => $v ) {
				$lines[] = $k . ': ' . $v;
			}
			$a = MRSH_AIHub::ask( $sys, implode( "\n", $lines ), 300 );
			if ( ! is_wp_error( $a ) ) {
				$text = trim( wp_strip_all_tags( $a ) );
				$text = preg_replace( '#https?://\S+|www\.\S+|[\w.+-]+@[\w-]+\.[\w.]+|\+?\d[\d\s\-]{7,}\d#u', '', $text );
				$ai   = '' !== $text;
			}
		}
		if ( '' === $text || mb_strlen( $text ) < 20 ) {
			$text = self::template( $f, $lang );
			$ai   = false;
		}
		$c = (int) get_option( 'mrsh_story_count', 0 );
		update_option( 'mrsh_story_count', $c + 1, false );
		wp_send_json_success( array( 'text' => mb_substr( $text, 0, 900 ), 'ai' => $ai ) );
	}

	public static function js() {
		if ( is_admin() || ! is_user_logged_in() ) {
			return;
		}
		?>
<script id="mrsh-story-js">
(function(){var ta=document.getElementById('mrt-about');if(!ta||ta.dataset.st)return;ta.dataset.st=1;
var AJ=<?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>,N=<?php echo wp_json_encode( wp_create_nonce( 'mrsh_story' ) ); ?>,lang='en';
var box=document.createElement('div');box.className='mrst';box.style.cssText='margin:10px 0;padding:12px;border:1px dashed #c9b9d6;border-radius:14px;background:#faf7fd';
box.innerHTML='<div style="font-weight:600;margin-bottom:6px">Not sure what to write? / کیا لکھیں سمجھ نہیں آ رہا؟</div><div class="mrst-l" style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:8px"></div><button type="button" class="btn line sm mrst-go">Write a draft for me / میرے لیے مسودہ لکھیں</button> <span class="ml mrst-m" style="display:block;margin-top:6px"></span><div class="mrst-r" hidden style="margin-top:8px"><div class="mrst-t" style="padding:10px;border-radius:10px;background:#fff;border:1px solid #e7e2f3;line-height:1.7"></div><div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:6px"><button type="button" class="btn sm mrst-use">Use this text / یہ متن استعمال کریں</button><button type="button" class="btn line sm mrst-again">Write another / دوسرا لکھیں</button></div><small class="ml" style="display:block;margin-top:4px">Please read it and change anything that is not true. / براہ کرم پڑھیں اور جو درست نہ ہو بدل دیں۔</small></div>';
ta.parentNode.insertBefore(box,ta.nextSibling);
var L=[['en','English'],['ur','اردو'],['rur','Roman Urdu']],lw=box.querySelector('.mrst-l');
L.forEach(function(x){var b=document.createElement('button');b.type='button';b.textContent=x[1];b.className='btn line sm';b.style.width='auto';b.style.flex='1 1 0';b.style.opacity=x[0]===lang?'1':'.55';b.onclick=function(){lang=x[0];[].forEach.call(lw.children,function(c,i){c.style.opacity=L[i][0]===lang?'1':'.55'})};lw.appendChild(b)});
function facts(){var o={};document.querySelectorAll('form.pf label').forEach(function(l){var d=l.parentNode,f=d&&d.querySelector('select,input:not([type=hidden]):not([type=file]):not([type=checkbox]):not([data-phone])');if(!f||f===l||f.type==='tel')return;var k=l.textContent.replace(/\s*\/.*$/,'').replace(/[*]/g,'').trim(),v=(f.value||'').trim();if(k&&v&&v!=='__other')o[k]=v});return o}
var go=box.querySelector('.mrst-go'),msg=box.querySelector('.mrst-m'),res=box.querySelector('.mrst-r'),tx=box.querySelector('.mrst-t');
function run(){msg.textContent='Writing... / لکھ رہا ہے...';go.disabled=true;var fd=new FormData();fd.append('action','mrsh_story');fd.append('n',N);fd.append('lang',lang);fd.append('facts',JSON.stringify(facts()));
fetch(AJ,{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(j){go.disabled=false;if(j&&j.success){msg.textContent='';tx.textContent=j.data.text;tx.dir=lang==='ur'?'rtl':'ltr';res.hidden=false}else{msg.textContent=(j&&j.data&&j.data.msg)||'Could not write now. Please try again.'}}).catch(function(){go.disabled=false;msg.textContent='No connection. Please try again.'})}
go.onclick=run;box.querySelector('.mrst-again').onclick=run;
box.querySelector('.mrst-use').onclick=function(){ta.value=tx.textContent;ta.dispatchEvent(new Event('input',{bubbles:true}));ta.dispatchEvent(new Event('change',{bubbles:true}));ta.focus();msg.textContent='Added. Please read it and edit. / شامل ہو گیا، پڑھ کر ٹھیک کریں۔'}
})();
</script>
		<?php
	}
}
MRSH_Story::init();
