<?php
/**
 * Members who signed up but never made a profile: email (and WhatsApp through your webhook) every 48 hours
 * for 14 days, then the account is removed and the email is blocked from registering again.
 * Off until you press Turn on in the Member manager.
 *
 * @package MyRishta_SEO_Helper
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Noprofile {

	const EVERY = 48; // hours between reminders.
	const DAYS  = 14; // days of reminders, counted from the first one.

	public static function init() {
		add_action( 'mrsh_np_cron', array( __CLASS__, 'cron' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
		add_action( 'admin_post_mrsh_np_toggle', array( __CLASS__, 'toggle' ) );
		add_action( 'admin_post_mrsh_np_run', array( __CLASS__, 'run_now' ) );
		add_filter( 'registration_errors', array( __CLASS__, 'reg_gate' ), 20, 3 );
	}

	public static function schedule() {
		$on   = (int) get_option( 'mrsh_np_auto', 0 );
		$next = wp_next_scheduled( 'mrsh_np_cron' );
		if ( $on && ! $next ) {
			wp_schedule_event( time() + 900, 'twicedaily', 'mrsh_np_cron' );
		} elseif ( ! $on && $next ) {
			wp_unschedule_event( $next, 'mrsh_np_cron' );
		}
	}

	public static function toggle() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_np_toggle' );
		$to = isset( $_POST['to'] ) && 'on' === $_POST['to'] ? 1 : 0; // phpcs:ignore
		update_option( 'mrsh_np_auto', $to, false );
		self::schedule();
		wp_safe_redirect( add_query_arg( 'msg', rawurlencode( $to ? 'No-profile automation is ON. Members without a profile get a reminder every 48 hours for 14 days, then the account is removed and blocked.' : 'No-profile automation is OFF.' ), admin_url( 'admin.php?page=mrsh-desk' ) ) );
		exit;
	}

	public static function run_now() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_np_run' );
		$r = self::cron( true );
		wp_safe_redirect( add_query_arg( 'msg', rawurlencode( 'Done: ' . (int) $r['mail'] . ' reminder(s), ' . (int) $r['gone'] . ' account(s) removed.' ), admin_url( 'admin.php?page=mrsh-desk' ) ) );
		exit;
	}

	/** Emails that were removed: they cannot register again. */
	public static function is_blocked( $email ) {
		$list = (array) get_option( 'mrsh_np_blocked', array() );
		return in_array( sha1( strtolower( trim( (string) $email ) ) ), $list, true );
	}

	public static function reg_gate( $errors, $login = '', $email = '' ) {
		if ( $email && self::is_blocked( $email ) ) {
			$errors->add( 'mrsh_blocked', 'This email cannot be used to register.' );
		}
		return $errors;
	}

	/** Users with no profile at all, who can safely be reminded or removed. */
	public static function candidates() {
		global $wpdb;
		$has = array_map( 'intval', (array) $wpdb->get_col( "SELECT DISTINCT post_author FROM {$wpdb->posts} WHERE post_type = 'listing_type' AND post_status IN ('publish','draft','pending','private','future')" ) ); // phpcs:ignore
		$out = array();
		foreach ( get_users( array( 'number' => 3000, 'fields' => 'all' ) ) as $u ) {
			$id = (int) $u->ID;
			if ( in_array( $id, $has, true ) || user_can( $u, 'manage_options' ) || array_diff( (array) $u->roles, array( 'subscriber' ) ) ) {
				continue;
			}
			if ( get_user_meta( $id, 'mrt_banned', true ) || get_user_meta( $id, 'mrt_plan', true ) || get_user_meta( $id, '_mrsh_id_verified', true ) ) {
				continue;
			}
			if ( strtotime( $u->user_registered . ' UTC' ) > time() - DAY_IN_SECONDS ) {
				continue;
			}
			$out[] = $u;
		}
		return $out;
	}

	private static function send( $u, $subject, $text, $kind, $tpl = null ) {
		$body = "Assalam o Alaikum " . ( $u->display_name ?: $u->user_login ) . ",\n\n" . $text . "\n\n" . get_bloginfo( 'name' );
		if ( class_exists( 'MRSH_Mailq' ) ) {
			MRSH_Mailq::add( $u->user_email, $subject, $body, array( 'kind' => 'noprofile', 'uid' => (int) $u->ID ) );
		} else {
			wp_mail( $u->user_email, $subject, $body );
		}
		$ph = preg_replace( '/\D/', '', (string) get_user_meta( $u->ID, 'mrt_mobile', true ) );
		if ( $ph && class_exists( 'MRSH_WhatsApp' ) ) {
			MRSH_WhatsApp::push( $ph, $text, $kind, array( 'email' => $u->user_email ), $tpl );
		}
	}

	public static function remind_text( $u ) {
		$first = (int) get_user_meta( $u->ID, 'mrsh_np_first', true );
		$left  = $first ? max( 0, (int) ceil( ( self::DAYS * DAY_IN_SECONDS - ( time() - $first ) ) / DAY_IN_SECONDS ) ) : self::DAYS;
		return 'You registered on ' . get_bloginfo( 'name' ) . ' but have not created your rishta profile yet. It is free and takes about 3 minutes: ' . home_url( '/add-listing/' ) . ' . Without a profile your account will be removed in ' . $left . ' day(s).';
	}

	/** Runs twice a day. Returns counts. */
	public static function cron( $manual = false ) {
		$mail = 0;
		$gone = 0;
		$now  = time();
		$log  = (array) get_option( 'mrsh_np_log', array() );
		foreach ( self::candidates() as $u ) {
			if ( $mail + $gone >= 40 ) {
				break;
			}
			$id    = (int) $u->ID;
			$first = (int) get_user_meta( $id, 'mrsh_np_first', true );
			$last  = (int) get_user_meta( $id, 'mrsh_np_last', true );
			if ( ! $first ) {
				self::send( $u, 'Create your free profile on ' . get_bloginfo( 'name' ), self::remind_text( $u ), 'noprofile', array( 'profile', array( $u->display_name ?: $u->user_login, self::DAYS, home_url( '/add-listing/' ) ) ) );
				update_user_meta( $id, 'mrsh_np_first', $now );
				update_user_meta( $id, 'mrsh_np_last', $now );
				update_user_meta( $id, 'mrsh_np_n', 1 );
				$mail++;
			} elseif ( $now - $first >= self::DAYS * DAY_IN_SECONDS ) {
				self::send( $u, 'Your account has been removed', 'Your account on ' . get_bloginfo( 'name' ) . ' has been removed because no profile was created within ' . self::DAYS . ' days of our first reminder, and this email address can no longer be used to register.', 'noprofile_removed', array( 'removed', array( $u->display_name ?: $u->user_login ) ) );
				$list   = (array) get_option( 'mrsh_np_blocked', array() );
				$list[] = sha1( strtolower( trim( $u->user_email ) ) );
				update_option( 'mrsh_np_blocked', array_values( array_unique( $list ) ), false );
				array_unshift( $log, array( 't' => $now, 'n' => $u->display_name, 'e' => $u->user_email ) );
				if ( class_exists( 'MRSH_Autopilot' ) ) {
					MRSH_Autopilot::safe_delete( $u, 'no profile created in time' );
				} else {
					require_once ABSPATH . 'wp-admin/includes/user.php';
					wp_delete_user( $id );
				}
				$gone++;
			} elseif ( $now - $last >= self::EVERY * HOUR_IN_SECONDS ) {
				self::send( $u, 'Reminder: create your free profile', self::remind_text( $u ), 'noprofile', array( 'profile', array( $u->display_name ?: $u->user_login, max( 0, (int) ceil( ( self::DAYS * DAY_IN_SECONDS - ( $now - $first ) ) / DAY_IN_SECONDS ) ), home_url( '/add-listing/' ) ) ) );
				update_user_meta( $id, 'mrsh_np_last', $now );
				update_user_meta( $id, 'mrsh_np_n', (int) get_user_meta( $id, 'mrsh_np_n', true ) + 1 );
				$mail++;
			}
		}
		update_option( 'mrsh_np_log', array_slice( $log, 0, 100 ), false );
		update_option( 'mrsh_np_last_run', array( 'time' => $now, 'mail' => $mail, 'gone' => $gone ), false );
		return array( 'mail' => $mail, 'gone' => $gone );
	}

	/** Small control panel shown in the Member manager. */
	public static function panel() {
		$on   = (int) get_option( 'mrsh_np_auto', 0 );
		$last = get_option( 'mrsh_np_last_run', array() );
		$cand = self::candidates();
		$act  = admin_url( 'admin-post.php' );
		echo '<div class="mx-tabs" style="margin-top:10px;align-items:center"><b>No-profile cleanup: ' . ( $on ? 'ON' : 'OFF' ) . '</b> ';
		echo '<form method="post" action="' . esc_url( $act ) . '" style="display:inline">' . wp_nonce_field( 'mrsh_np_toggle', '_wpnonce', true, false ) . '<input type="hidden" name="action" value="mrsh_np_toggle"><input type="hidden" name="to" value="' . ( $on ? 'off' : 'on' ) . '"><button class="mx-btn s ' . ( $on ? '' : 'p' ) . '">' . ( $on ? 'Turn off' : 'Turn on' ) . '</button></form> ';
		echo '<form method="post" action="' . esc_url( $act ) . '" style="display:inline">' . wp_nonce_field( 'mrsh_np_run', '_wpnonce', true, false ) . '<input type="hidden" name="action" value="mrsh_np_run"><button class="mx-btn s">Run now</button></form> ';
		echo '<span class="description">Members with no profile get an email (and WhatsApp through your webhook) every 48 hours for 14 days. After that the account is removed, a goodbye email is sent and the email address is blocked from registering again. Admins, paid, verified and blocked members are never touched. ' . ( ! empty( $last['time'] ) ? 'Last run: ' . esc_html( human_time_diff( (int) $last['time'] ) ) . ' ago, ' . (int) $last['mail'] . ' sent, ' . (int) $last['gone'] . ' removed.' : '' ) . '</span></div>';
		echo '<details style="margin:8px 0"><summary><b>' . count( $cand ) . ' member(s) without a profile</b> (click to see who will be reminded or removed)</summary><table class="widefat striped" style="margin-top:6px;max-width:900px"><thead><tr><th>Member</th><th>Email</th><th>Reminders</th><th>Removal date</th><th>WhatsApp</th></tr></thead><tbody>';
		foreach ( array_slice( $cand, 0, 200 ) as $u ) {
			$first = (int) get_user_meta( $u->ID, 'mrsh_np_first', true );
			$ph    = preg_replace( '/\D/', '', (string) get_user_meta( $u->ID, 'mrt_mobile', true ) );
			echo '<tr><td><a href="' . esc_url( get_edit_user_link( $u->ID ) ) . '" target="_blank" rel="noopener">' . esc_html( $u->display_name ) . '</a></td><td>' . esc_html( $u->user_email ) . '</td><td>' . (int) get_user_meta( $u->ID, 'mrsh_np_n', true ) . '</td><td>' . ( $first ? esc_html( wp_date( 'j M Y', $first + self::DAYS * DAY_IN_SECONDS ) ) : 'after first reminder' ) . '</td><td>' . ( $ph ? '<a class="button button-small" target="_blank" rel="noopener" href="' . esc_url( 'https://wa.me/' . $ph . '?text=' . rawurlencode( self::remind_text( $u ) ) ) . '">WhatsApp</a>' : '-' ) . '</td></tr>';
		}
		echo '</tbody></table></details>';
		$log = (array) get_option( 'mrsh_np_log', array() );
		if ( $log ) {
			echo '<details style="margin:8px 0"><summary><b>Removed accounts</b> (' . count( $log ) . ')</summary><ul style="margin:6px 0 0 18px">';
			foreach ( array_slice( $log, 0, 30 ) as $l ) {
				echo '<li>' . esc_html( wp_date( 'j M Y', (int) $l['t'] ) . ' - ' . $l['n'] . ' - ' . $l['e'] ) . '</li>';
			}
			echo '</ul></details>';
		}
	}
}

MRSH_Noprofile::init();
