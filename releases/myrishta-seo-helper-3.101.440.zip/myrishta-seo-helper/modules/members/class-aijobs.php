<?php
/**
 * AI Assistant jobs (the work the robot orders from the AI, and the free helpers that need no AI):
 *
 *  reply   Answers support tickets. Simple, safe topics (login, profile, photo, verification) are answered by itself;
 *          anything about money, fraud, reports, threats, refunds or deleting an account only gets a private draft for the owner.
 *  draft   Writes at most one new guide draft per day. It stays a DRAFT until the owner approves it in the Auto-Fixer.
 *  login   (works without AI) A member who fails to log in several times gets a short help email with the reset link.
 *  spell   (works without AI) Spelling hints under text boxes while members type, plus an optional "Improve my text" button.
 *
 * No made-up success stories, reviews or testimonials are ever written. Only guides with practical advice.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_AIJobs {

	const CRON  = 'mrsh_aijobs_tick';
	const STAT  = 'mrsh_aijobs_stat';
	const FAILS = 'mrsh_aijobs_fails';
	const DONE  = 'mrsh_aijobs_done';

	public static function init() {
		add_action( self::CRON, array( __CLASS__, 'tick' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
		add_action( 'wp_login_failed', array( __CLASS__, 'failed' ) );
		add_action( 'wp_login', array( __CLASS__, 'ok' ), 10, 2 );
		add_action( 'wp_footer', array( __CLASS__, 'spell_js' ), 99 );
		add_action( 'wp_ajax_mrsh_ai_polish', array( __CLASS__, 'polish' ) );
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::CRON ) ) {
			wp_schedule_event( time() + 1200, 'hourly', self::CRON );
		}
	}

	public static function stats() {
		$s = get_option( self::STAT, array() );
		$s = array_merge( array( 'answered' => 0, 'helped' => 0, 'polish' => 0, 'meta' => 0 ), is_array( $s ) ? $s : array() );
		$s['drafts'] = count( self::waiting_drafts() );
		return $s;
	}

	private static function inc( $k ) {
		$s       = get_option( self::STAT, array() );
		$s       = is_array( $s ) ? $s : array();
		$s[ $k ] = (int) ( $s[ $k ] ?? 0 ) + 1;
		update_option( self::STAT, $s, false );
	}

	public static function tick() {
		if ( class_exists( 'MRSH_Fixer' ) && ! MRSH_Fixer::o()['on'] ) {
			return;
		}
		self::run_job( 'login', false );
		self::run_job( 'reply', false );
		self::run_job( 'meta', false );
		self::run_job( 'prof', false );
		if ( (int) wp_date( 'G' ) >= 5 ) {
			self::run_job( 'draft', false );
		}
	}

	/** Returns a plain sentence for the admin page. */
	public static function run_job( $job, $manual ) {
		try {
			if ( 'login' === $job ) {
				return self::job_login( $manual );
			}
			if ( 'reply' === $job ) {
				return self::job_reply( $manual );
			}
			if ( 'draft' === $job ) {
				return self::job_draft( $manual );
			}
			if ( 'meta' === $job ) {
				return self::job_meta( $manual );
			}
			if ( 'prof' === $job ) {
				return self::job_prof( $manual );
			}
		} catch ( \Throwable $e ) {
			return 'Job stopped: ' . $e->getMessage();
		}
		return 'Unknown job.';
	}

	/* ---------- login trouble (no AI needed) ---------- */

	public static function failed( $login ) {
		$u = get_user_by( 'login', $login );
		if ( ! $u && is_email( $login ) ) {
			$u = get_user_by( 'email', $login );
		}
		if ( ! $u ) {
			return;
		}
		$f = get_option( self::FAILS, array() );
		$f = is_array( $f ) ? $f : array();
		$r = $f[ $u->ID ] ?? array( 'n' => 0, 't' => 0, 'helped' => 0 );
		if ( time() - (int) $r['t'] > 2 * DAY_IN_SECONDS ) {
			$r['n'] = 0;
		}
		$r['n']        = (int) $r['n'] + 1;
		$r['t']        = time();
		$f[ $u->ID ]   = $r;
		update_option( self::FAILS, array_slice( $f, -300, null, true ), false );
	}

	public static function ok( $login, $user ) {
		$f = get_option( self::FAILS, array() );
		if ( is_array( $f ) && isset( $f[ $user->ID ] ) ) {
			unset( $f[ $user->ID ] );
			update_option( self::FAILS, $f, false );
		}
	}

	private static function job_login( $manual ) {
		if ( ! $manual && ! MRSH_AIHub::o()['login'] ) {
			return 'Login help is off.';
		}
		$f = get_option( self::FAILS, array() );
		if ( ! is_array( $f ) || ! $f ) {
			return 'Nobody is stuck at login right now.';
		}
		$sent = 0;
		foreach ( $f as $uid => $r ) {
			if ( $sent >= 20 ) {
				break;
			}
			if ( (int) $r['n'] < 3 || time() - (int) $r['t'] > 2 * DAY_IN_SECONDS || time() - (int) $r['helped'] < 3 * DAY_IN_SECONDS ) {
				continue;
			}
			$u = get_userdata( (int) $uid );
			if ( ! $u || get_user_meta( $u->ID, 'mrsh_mail_bad', true ) || $u->has_cap( 'manage_options' ) ) {
				continue;
			}
			$subject = 'Trouble signing in to My Rishta? Here is how to fix it';
			$body    = "Assalam o Alaikum " . $u->display_name . ",\n\nWe noticed a few unsuccessful sign-in attempts on your My Rishta account.\n\n"
				. "1. Open " . wp_lostpassword_url() . " and enter your email address. We will send a link to choose a new password.\n"
				. "2. Check the Spam or Promotions folder if the email is not in your inbox after a few minutes.\n"
				. "3. Passwords are case sensitive. Check that Caps Lock is off.\n\n"
				. "Still stuck? Just reply to this email, or write to us from " . home_url( '/contact/' ) . " and a team member will help.\n\n"
				. "If this was not you, no action is needed. Never share your password or codes with anyone.\n\nMy Rishta Pakistan\nThis message was sent automatically.";
			self::mail( $u->user_email, $subject, $body, 'login_help' );
			$f[ $uid ]['helped'] = time();
			++$sent;
			self::inc( 'helped' );
		}
		update_option( self::FAILS, $f, false );
		return $sent ? $sent . ' member(s) received login help.' : 'Nobody needed login help right now.';
	}

	private static function mail( $to, $subject, $body, $kind ) {
		$hdr = array( 'Auto-Submitted: auto-generated' );
		if ( class_exists( 'MRSH_Mailq' ) ) {
			return (bool) MRSH_Mailq::add( $to, $subject, $body, array( 'kind' => $kind, 'headers' => $hdr ) );
		}
		return wp_mail( $to, $subject, $body, $hdr );
	}

	/* ---------- support tickets ---------- */

	private static $safe_titles = array( 'Cannot log in', 'How to get verified', 'Photo problem', 'How to create a profile', 'Change my details', 'Hide my profile' );
	private static $risky       = '/refund|police|fraud|scam|blackmail|threat|harass|abuse|lawyer|court|legal|money|paid|payment|jazzcash|easypaisa|bank|delete|remove my|suicide|kill|die|rape|forced/i';

	private static function job_reply( $manual ) {
		if ( ! MRSH_AIHub::ready() || ( ! $manual && ! MRSH_AIHub::o()['reply'] ) ) {
			return 'Ticket answers are off or the AI has no key.';
		}
		if ( ! class_exists( 'MRSH_Tickets' ) ) {
			return 'The ticket system is not loaded.';
		}
		global $wpdb;
		$done = get_option( self::DONE, array() );
		$done = is_array( $done ) ? $done : array();
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . MRSH_Tickets::t1() . " WHERE status='open' AND ( answered=0 OR updated > answered ) AND updated < %d ORDER BY id ASC LIMIT 10", time() - 45 ) ); // a new question, or the member replied after our answer // phpcs:ignore WordPress.DB
		$auto = 0;
		$draf = 0;
		foreach ( (array) $rows as $t ) {
			if ( isset( $done[ $t->id ] ) ) {
				continue;
			}
			$last = $wpdb->get_row( $wpdb->prepare( 'SELECT id, who, body FROM ' . MRSH_Tickets::t2() . " WHERE ticket_id=%d AND who IN ('user','staff') ORDER BY id DESC LIMIT 1", $t->id ) ); // phpcs:ignore WordPress.DB
			if ( ! $last || 'user' !== $last->who || ( isset( $done[ $t->id ] ) && (int) $done[ $t->id ] >= (int) $last->id ) ) {
				continue; // the last word is ours, or this message was already handled
			}
			$mark = (int) $last->id;
			// How many times the AI already answered this ticket: after 3 rounds a person takes over.
			$rounds = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . MRSH_Tickets::t2() . " WHERE ticket_id=%d AND who='system' AND body LIKE %s", $t->id, 'Answered automatically%' ) ); // phpcs:ignore WordPress.DB
			if ( $rounds >= 3 ) {
				MRSH_Tickets::add_msg( (int) $t->id, 'note', 'The AI answered 3 times already, so this one is left for a person.' );
				$done[ $t->id ] = $mark;
				continue;
			}
			$hist = $wpdb->get_results( $wpdb->prepare( 'SELECT who, body FROM ' . MRSH_Tickets::t2() . " WHERE ticket_id=%d AND who IN ('user','staff') ORDER BY id DESC LIMIT 6", $t->id ) ); // phpcs:ignore WordPress.DB
			$conv = '';
			foreach ( array_reverse( (array) $hist ) as $h ) {
				$conv .= ( 'user' === $h->who ? 'Member: ' : 'We: ' ) . mb_substr( wp_strip_all_tags( (string) $h->body ), 0, 600 ) . "\n\n";
			}
			$text  = mb_substr( wp_strip_all_tags( (string) $last->body ), 0, 1500 );
			$topic = MRSH_Tickets::suggest( $t, $text );
			$full  = class_exists( 'MRSH_Autopilot' ) && MRSH_Autopilot::can( 'tickets' );
			$safe  = $full
				? ! preg_match( self::$risky, $t->subject . ' ' . $text )
				: ( in_array( $topic, self::$safe_titles, true ) && ! preg_match( self::$risky, $t->subject . ' ' . $text ) && 'auto' === MRSH_AIHub::o()['reply_mode'] );
			$sys   = "You answer support messages for My Rishta Pakistan (myrishta.pk), a free, non-profit Pakistani rishta (matrimonial) website.\n"
				. "Rules: reply in the same language and script the member used (English, Urdu or Roman Urdu). Be warm, short (under 110 words) and practical. Use plain text, no markdown.\n"
				. "Useful pages: log in at " . home_url( '/login/' ) . " (use 'Forgot password'), your account at " . home_url( '/my-account/' ) . ", add or edit a profile at " . home_url( '/add-listing/' ) . ", verification badges explained at " . home_url( '/verification-badges/' ) . ", contact us at " . home_url( '/contact/' ) . ".\n"
				. "Never ask for passwords, CNIC numbers, bank details or money. Never promise refunds, approvals, matches or deadlines. Never give legal or medical advice. If you are not sure, say a team member will follow up. Do not invent features. " . ( $full ? "If you cannot answer fully and safely from the facts given, output exactly the single word HUMAN. " : '' ) . "Output only the reply text, no greeting line with a name, no signature.";
			$a = MRSH_AIHub::ask( $sys, "Topic guess: " . ( $topic ?: 'other' ) . "\nSubject: " . $t->subject . "\nConversation so far (oldest first):\n" . $conv . "Answer the member's LAST message.", 400 );
			if ( is_wp_error( $a ) ) {
				if ( in_array( $a->get_error_code(), array( 'cap', 'auth', 'off' ), true ) ) {
					break;
				}
				continue;
			}
			$a = mb_substr( trim( wp_strip_all_tags( $a ) ), 0, 1200 );
			if ( $full && 'HUMAN' === strtoupper( trim( $a, " .\n" ) ) ) {
				MRSH_Tickets::add_msg( (int) $t->id, 'note', 'The AI was not sure how to answer this safely, so it left it for a person.' );
				MRSH_Autopilot::log( 'Tickets', 'Left ticket ' . MRSH_Tickets::code( (int) $t->id ) . ' for a human (AI not sure).' );
				$done[ $t->id ] = $mark;
				continue;
			}
			if ( $safe ) {
				MRSH_Tickets::add_msg( (int) $t->id, 'staff', $a );
				MRSH_Tickets::add_msg( (int) $t->id, 'system', 'Answered automatically by the AI assistant.' );
				$wpdb->update( MRSH_Tickets::t1(), array( 'status' => 'waiting', 'answered' => time() ), array( 'id' => (int) $t->id ) ); // phpcs:ignore WordPress.DB
				self::mail(
					$t->email,
					'[' . MRSH_Tickets::code( (int) $t->id ) . '] Re: ' . $t->subject,
					"Hello " . ( $t->name ?: '' ) . ",\n\n" . $a . "\n\nThis answer was written by our automated assistant. If it did not solve your problem, just reply to this email and a team member will take over. Please keep " . MRSH_Tickets::code( (int) $t->id ) . " in the subject.\n\n--\nMy Rishta Pakistan Support\n" . home_url( '/' ) . "\nNever send money to anyone you meet online.",
					'ticket_ai'
				);
				++$auto;
				self::inc( 'answered' );
				if ( class_exists( 'MRSH_Autopilot' ) ) {
					MRSH_Autopilot::log( 'Tickets', 'Answered ticket ' . MRSH_Tickets::code( (int) $t->id ) . ' (' . ( $topic ?: 'general' ) . ').' );
				}
			} else {
				MRSH_Tickets::add_msg( (int) $t->id, 'note', "AI draft reply (not sent, check it and use it if it is right):\n\n" . $a );
				++$draf;
			}
			$done[ $t->id ] = $mark;
		}
		update_option( self::DONE, array_slice( $done, -500, null, true ), false );
		return $auto || $draf ? $auto . ' answer(s) sent, ' . $draf . ' draft(s) written for you.' : 'No waiting tickets needed an answer.';
	}

	/* ---------- search-result descriptions ---------- */

	private static function job_meta( $manual ) {
		if ( ! MRSH_AIHub::ready() || ( ! $manual && ! MRSH_AIHub::o()['meta'] ) ) {
			return 'Descriptions are off or the AI has no key.';
		}
		$ids = get_posts( array(
			'post_type'        => array( 'post', 'page' ),
			'post_status'      => 'publish',
			'numberposts'      => 5,
			'orderby'          => 'date',
			'order'            => 'DESC',
			'fields'           => 'ids',
			'suppress_filters' => true,
			'meta_query'       => array( 'relation' => 'AND', array( 'key' => '_mrsh_desc', 'compare' => 'NOT EXISTS' ), array( 'key' => '_mrsh_aidesc_tried', 'compare' => 'NOT EXISTS' ) ), // phpcs:ignore WordPress.DB.SlowDBQuery
		) );
		$n = 0;
		foreach ( $ids as $id ) {
			update_post_meta( $id, '_mrsh_aidesc_tried', '1' ); // never retry the same page forever
			$p    = get_post( $id );
			$body = mb_substr( wp_strip_all_tags( strip_shortcodes( (string) $p->post_content ) ), 0, 1400 );
			if ( mb_strlen( $body ) < 120 ) {
				continue;
			}
			$a = MRSH_AIHub::ask( "You write search-result descriptions. Write ONE description of 130 to 155 characters for the page below, in the same language as the page. Say what the reader will learn. No quotes, no emojis, no marketing hype, no claims that are not in the text. Output only the description.", 'Title: ' . $p->post_title . "\nText:\n" . $body, 120 );
			if ( is_wp_error( $a ) ) {
				delete_post_meta( $id, '_mrsh_aidesc_tried' );
				if ( in_array( $a->get_error_code(), array( 'cap', 'auth', 'off' ), true ) ) {
					break;
				}
				continue;
			}
			$a = trim( trim( wp_strip_all_tags( $a ) ), "\"' " );
			if ( mb_strlen( $a ) < 70 || mb_strlen( $a ) > 200 ) {
				continue;
			}
			update_post_meta( $id, '_mrsh_desc', mb_substr( $a, 0, 160 ) );
			do_action( 'litespeed_purge_post', $id );
			++$n;
			self::inc( 'meta' );
		}
		return $n ? $n . ' description(s) written.' : 'No page needed a description.';
	}

	/* ---------- profile text check: warns only ---------- */

	private static function job_prof( $manual ) {
		if ( ! MRSH_AIHub::ready() || ( ! $manual && ! MRSH_AIHub::o()['prof'] ) ) {
			return 'Profile text check is off or the AI has no key.';
		}
		$ids = get_posts( array(
			'post_type'        => 'listing_type',
			'post_status'      => 'publish',
			'numberposts'      => 6,
			'orderby'          => 'date',
			'order'            => 'DESC',
			'fields'           => 'ids',
			'suppress_filters' => true,
			'date_query'       => array( array( 'after' => '3 days ago' ) ),
			'meta_query'       => array( array( 'key' => '_mrsh_ai_chk', 'compare' => 'NOT EXISTS' ) ), // phpcs:ignore WordPress.DB.SlowDBQuery
		) );
		$flag = 0;
		foreach ( $ids as $id ) {
			$p    = get_post( $id );
			$text = mb_substr( wp_strip_all_tags( $p->post_title . "\n" . $p->post_content ), 0, 1500 );
			if ( mb_strlen( $text ) < 30 ) {
				update_post_meta( $id, '_mrsh_ai_chk', 'short' );
				continue;
			}
			$a = MRSH_AIHub::ask( "You review the text of a matrimonial profile for a free rishta website. Reply with ONLY compact JSON: {\"ok\":true|false,\"block\":true|false,\"issues\":[\"short reason\"]}. Set block=true only for sexual or abusive language, hate speech, requests for money or gifts, or an obvious scam or advertisement (not for a phone number alone). Set ok=false only for: phone numbers or other contact details written in the text (shown as [number] or [email]), requests for money or gifts, sexual or abusive language, hate speech, or text that clearly looks like an advertisement or scam. Normal descriptions of family, education, work and expectations are ok.", $text, 150 );
			if ( is_wp_error( $a ) ) {
				if ( in_array( $a->get_error_code(), array( 'cap', 'auth', 'off' ), true ) ) {
					break;
				}
				continue;
			}
			update_post_meta( $id, '_mrsh_ai_chk', '1' );
			if ( preg_match( '/\{.*\}/s', $a, $m ) ) {
				$j = json_decode( $m[0], true );
				if ( is_array( $j ) && isset( $j['ok'] ) && false === $j['ok'] && class_exists( 'MRSH_Attn' ) ) {
					$why = implode( '; ', array_map( 'sanitize_text_field', array_slice( (array) ( $j['issues'] ?? array() ), 0, 3 ) ) );
					MRSH_Attn::add( 'profile_text', (int) $p->post_author, 'Profile text may need a look (' . ( $why ?: 'flagged' ) . '): ' . wp_trim_words( $p->post_title, 6 ), get_edit_post_link( $id, 'raw' ) );
					++$flag;
					if ( ! empty( $j['block'] ) && class_exists( 'MRSH_Autopilot' ) && MRSH_Autopilot::can( 'profiles' ) ) {
						// Retire, never delete: the profile goes back to draft so the owner and the member can review it.
						wp_update_post( array( 'ID' => $id, 'post_status' => 'draft' ) );
						update_post_meta( $id, '_mrsh_ap_paused', time() );
						MRSH_Autopilot::log( 'Profiles', 'Paused profile #' . $id . ' (' . ( $why ?: 'text problem' ) . '). It is kept as a draft.' );
					}
				}
			}
		}
		return $ids ? count( $ids ) . ' profile(s) checked, ' . $flag . ' flagged in your Inbox.' : 'No new profiles to check.';
	}

	/* ---------- one guide draft per day ---------- */

	public static function topics() {
		return array(
			'How to write an honest rishta biodata that families trust',
			'Rishta for working women: how families can talk about career after marriage',
			'How to plan a first rishta meeting at home',
			'Questions a girl\'s family can politely ask about the boy\'s work and family',
			'How to say no to a rishta without hurting anyone',
			'Warning signs of a fake rishta profile and how to check safely',
			'Nikah checklist: documents and arrangements families often forget',
			'Walima planning on a simple budget',
			'Rishta for second marriage: how to start the conversation with family',
			'How to talk about mehr and jahez without conflict',
			'Rishta for overseas Pakistanis: how families can verify a proposal',
			'Rishta in smaller cities: how to widen the search without moving',
			'How to involve a girl or boy in the decision respectfully',
			'Istikhara and decision making: how families balance prayer and practical checks',
			'How to talk about living arrangements before marriage',
			'Engagement (mangni) etiquette for both families',
			'What to wear and bring for a rishta visit',
			'How to handle relatives who pressure you about marriage age',
			'Rishta for doctors and engineers: busy schedules and real expectations',
			'How to protect a daughter\'s privacy when sharing a rishta profile',
			'Managing money talk between two families before the wedding',
			'How to follow up politely after a rishta meeting',
			'Choosing a good photo for a matrimonial profile',
			'How to write a short, warm rishta proposal message',
			'Rishta for divorcees and widows: dignified ways to begin again',
			'How to deal with rejection in the rishta process',
			'Marriage readiness: questions to ask yourself before saying yes',
			'How rishta aunties and online sites can work together',
			'Ramadan and Eid wedding planning tips for families',
			'Joint family or separate home: how to discuss it calmly',
		);
	}

	public static function waiting_drafts() {
		return get_posts( array( 'post_type' => 'post', 'post_status' => 'draft', 'numberposts' => 20, 'fields' => 'ids', 'meta_key' => '_mrsh_ai_draft', 'meta_value' => '1', 'suppress_filters' => true ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
	}

	private static function job_draft( $manual ) {
		if ( ! MRSH_AIHub::ready() || ( ! $manual && ! MRSH_AIHub::o()['draft'] ) ) {
			return 'Guide drafts are off or the AI has no key.';
		}
		if ( ! $manual && wp_date( 'Y-m-d' ) === get_option( 'mrsh_aijobs_draft_day', '' ) ) {
			return 'Today\'s draft is already written.';
		}
		if ( count( self::waiting_drafts() ) >= 3 ) {
			return 'Three drafts are already waiting for you. Approve or delete one first.';
		}
		$used = get_option( 'mrsh_aijobs_topics', array() );
		$used = is_array( $used ) ? $used : array();
		$topic = '';
		foreach ( self::topics() as $t ) {
			if ( in_array( md5( $t ), $used, true ) ) {
				continue;
			}
			global $wpdb;
			if ( $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type='post' AND post_status IN ('publish','draft','pending','private') AND post_title=%s LIMIT 1", $t ) ) ) { // phpcs:ignore WordPress.DB
				continue;
			}
			$topic = $t;
			break;
		}
		if ( '' === $topic ) {
			return 'All built-in topics are used. Add new topics later.';
		}
		$sys = "You write practical guides for My Rishta Pakistan (myrishta.pk), a free non-profit Pakistani rishta website.\n"
			. "Write 600 to 750 words of original, respectful, practical advice in clear English for Pakistani families. Output clean HTML only: <p>, <h2>, <ul><li>. No <h1>, no markdown, no title line.\n"
			. "Rules: do not invent statistics, laws, prices, quotes, names, case studies or success stories. No medical, legal or financial promises. Do not promise results. Do not mention AI. Use 4 to 6 <h2> sections. End with a short <p> inviting the reader to create a free profile at " . home_url( '/add-listing/' ) . ".";
		$a = MRSH_AIHub::ask( $sys, 'Topic: ' . $topic, 1800 );
		if ( is_wp_error( $a ) ) {
			return 'The AI could not write the draft: ' . $a->get_error_message();
		}
		$a = wp_kses_post( preg_replace( '/^```(?:html)?\s*|\s*```$/i', '', $a ) );
		if ( str_word_count( wp_strip_all_tags( $a ) ) < 350 ) {
			return 'The AI draft was too short and was not saved.';
		}
		$admins = get_users( array( 'role' => 'administrator', 'number' => 1, 'fields' => 'ID' ) );
		$cat    = get_term_by( 'slug', 'rishta-guides', 'category' );
		$pid    = wp_insert_post( array( 'post_type' => 'post', 'post_status' => 'draft', 'post_title' => $topic, 'post_content' => $a, 'post_author' => $admins ? (int) $admins[0] : 1, 'post_category' => $cat ? array( (int) $cat->term_id ) : array() ), true );
		if ( is_wp_error( $pid ) || ! $pid ) {
			return 'The draft could not be saved.';
		}
		update_post_meta( $pid, '_mrsh_ai_draft', '1' );
		$used[] = md5( $topic );
		update_option( 'mrsh_aijobs_topics', $used, false );
		update_option( 'mrsh_aijobs_draft_day', wp_date( 'Y-m-d' ), false );
		if ( class_exists( 'MRSH_Fixer' ) ) {
			MRSH_Fixer::ticket( 'draft_' . $pid, 'New guide draft to approve: ' . $topic, 'Read it first: ' . admin_url( 'post.php?post=' . $pid . '&action=edit' ) . ' . Approve to publish it, Skip to leave it as a draft.', 'low', 'needs_approval', 'publish_post:' . $pid );
		}
		return 'Draft written: ' . $topic . '. It waits for your approval.';
	}

	/* ---------- spelling help while typing ---------- */

	public static function spell_js() {
		if ( is_admin() || ! MRSH_AIHub::o()['spell'] ) {
			return;
		}
		$dict = array(
			'teh' => 'the', 'recieve' => 'receive', 'definately' => 'definitely', 'seperate' => 'separate', 'occured' => 'occurred', 'untill' => 'until', 'wich' => 'which', 'becuase' => 'because', 'beleive' => 'believe',
			'goverment' => 'government', 'enviroment' => 'environment', 'adress' => 'address', 'proffesion' => 'profession', 'professon' => 'profession', 'educaton' => 'education', 'eductation' => 'education',
			'marrige' => 'marriage', 'mairrage' => 'marriage', 'maried' => 'married', 'hobbys' => 'hobbies', 'qualfication' => 'qualification', 'qualificaton' => 'qualification', 'bussiness' => 'business', 'buisness' => 'business',
			'sallary' => 'salary', 'familly' => 'family', 'responsable' => 'responsible', 'intrested' => 'interested', 'freindly' => 'friendly', 'frend' => 'friend', 'sincier' => 'sincere', 'honset' => 'honest',
			'relegion' => 'religion', 'religous' => 'religious', 'pakistan' => 'Pakistan', 'lahore' => 'Lahore', 'karachi' => 'Karachi', 'islamabad' => 'Islamabad', 'rawalpindi' => 'Rawalpindi', 'faisalabad' => 'Faisalabad',
			'multan' => 'Multan', 'peshawar' => 'Peshawar', 'quetta' => 'Quetta', 'hyderabad' => 'Hyderabad', 'sialkot' => 'Sialkot', 'gujranwala' => 'Gujranwala', 'engeneer' => 'engineer', 'enginner' => 'engineer',
			'tecaher' => 'teacher', 'techer' => 'teacher', 'dcotor' => 'doctor', 'docter' => 'doctor', 'univeristy' => 'university', 'colege' => 'college',
		);
		$ai = MRSH_AIHub::ready();
		?>
<script>
(function(){
var D=<?php echo wp_json_encode( $dict ); ?>;
var AI=<?php echo $ai && is_user_logged_in() ? 'true' : 'false'; ?>;
var AJ=<?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>,NO=<?php echo wp_json_encode( wp_create_nonce( 'mrsh_ai_polish' ) ); ?>;
function fix(t){return t.replace(/[A-Za-z']+/g,function(w){var k=w.toLowerCase();if(!Object.prototype.hasOwnProperty.call(D,k))return w;var r=D[k];if(r===w)return w;if(r.charAt(0)!==r.charAt(0).toLowerCase())return r;if(w.length>1&&w===w.toUpperCase())return r.toUpperCase();if(w.charAt(0)!==w.charAt(0).toLowerCase())return r.charAt(0).toUpperCase()+r.slice(1);return r})}
function hints(t){var o=[],seen={};(t.match(/[A-Za-z']+/g)||[]).forEach(function(w){var k=w.toLowerCase();if(Object.prototype.hasOwnProperty.call(D,k)&&D[k]!==w&&!seen[k]){seen[k]=1;o.push(w+' → '+D[k])}});return o}
function wire(ta){if(ta.dataset.mrshSp||ta.closest('#wpadminbar')||ta.type==='hidden')return;ta.dataset.mrshSp=1;ta.setAttribute('spellcheck','true');
var box=document.createElement('div');box.style.cssText='font:13px system-ui,sans-serif;margin:4px 0 8px;color:#555;display:none';ta.parentNode.insertBefore(box,ta.nextSibling);var tm;
function show(){var h=hints(ta.value);box.innerHTML='';if(!h.length&&!(AI&&ta.value.length>30)){box.style.display='none';return}box.style.display='block';
if(h.length){var s=document.createElement('span');s.textContent='Did you mean: '+h.slice(0,4).join(', ')+'  ';box.appendChild(s);var b=document.createElement('button');b.type='button';b.textContent='Fix spelling';b.style.cssText='margin-right:8px;padding:2px 10px;border:1px solid #c3c4c7;border-radius:6px;background:#fff;cursor:pointer';b.onclick=function(){ta.value=fix(ta.value);ta.dispatchEvent(new Event('input',{bubbles:true}));show()};box.appendChild(b)}
if(AI&&ta.value.length>30){var p=document.createElement('button');p.type='button';p.textContent='✨ Improve my text';p.style.cssText='padding:2px 10px;border:1px solid #1e6f55;color:#1e6f55;border-radius:6px;background:#fff;cursor:pointer';p.onclick=function(){p.disabled=true;p.textContent='Working...';var f=new FormData();f.append('action','mrsh_ai_polish');f.append('n',NO);f.append('text',ta.value);fetch(AJ,{method:'POST',body:f,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(j){p.disabled=false;p.textContent='✨ Improve my text';if(j&&j.success&&j.data&&j.data.text){if(confirm('Use this improved text?\n\n'+j.data.text)){ta.value=j.data.text;ta.dispatchEvent(new Event('input',{bubbles:true}))}}else{alert((j&&j.data&&j.data.msg)||'Could not improve the text now.')}}).catch(function(){p.disabled=false;p.textContent='✨ Improve my text'})};box.appendChild(p)}}
ta.addEventListener('input',function(){clearTimeout(tm);tm=setTimeout(show,500)});}
function scan(){document.querySelectorAll('textarea').forEach(wire)}
if(document.readyState!=='loading')scan();else document.addEventListener('DOMContentLoaded',scan);
})();
</script>
		<?php
	}

	public static function polish() {
		check_ajax_referer( 'mrsh_ai_polish', 'n' );
		if ( ! is_user_logged_in() || ! MRSH_AIHub::job_on( 'spell' ) ) {
			wp_send_json_error( array( 'msg' => 'Not available.' ) );
		}
		$uid = get_current_user_id();
		$key = 'mrsh_pol_' . $uid . '_' . wp_date( 'Ymd' );
		$n   = (int) get_transient( $key );
		if ( $n >= 8 ) {
			wp_send_json_error( array( 'msg' => 'You have used today\'s text help. Please try again tomorrow.' ) );
		}
		$text = trim( wp_strip_all_tags( (string) wp_unslash( $_POST['text'] ?? '' ) ) ); // phpcs:ignore
		if ( mb_strlen( $text ) < 20 || mb_strlen( $text ) > 1500 ) {
			wp_send_json_error( array( 'msg' => 'Write between 20 and 1500 characters first.' ) );
		}
		set_transient( $key, $n + 1, DAY_IN_SECONDS );
		$a = MRSH_AIHub::ask( "You fix spelling and grammar. Keep the same meaning, language, script (English, Urdu or Roman Urdu) and length. Do not add new claims, contact details, names or praise. Output only the corrected text.", $text, 600 );
		if ( is_wp_error( $a ) ) {
			wp_send_json_error( array( 'msg' => 'Could not improve the text now.' ) );
		}
		self::inc( 'polish' );
		wp_send_json_success( array( 'text' => mb_substr( trim( $a ), 0, 1600 ) ) );
	}
}
MRSH_AIJobs::init();
