<?php
/**
 * Admin Inbox and the red "needs you" numbers.
 * Things members do that the admin should see (plan change or request, verification request, new member,
 * profile waiting for approval) are written to a small log. The Inbox page lists them with a Done button.
 * The red number on the tabs, in the sidebar and in the top admin bar adds the log to the live counters
 * (tickets, reports, payment proofs, photo problems, failed emails ...), so the admin never has to read email.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Attn {

	const OPT  = 'mrsh_attn';
	const SLUG = 'mrsh-inbox';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'migrate' ) );
		if ( is_admin() ) {
			add_action( 'admin_menu', array( __CLASS__, 'menu' ), 19 );
			add_action( 'admin_post_mrsh_attn_do', array( __CLASS__, 'act' ) );
		}
		if ( class_exists( 'MRSH_Master' ) && ! MRSH_Master::on( 'inbox' ) ) {
			return;
		}
		add_action( 'added_user_meta', array( __CLASS__, 'on_meta' ), 10, 4 );
		add_action( 'updated_user_meta', array( __CLASS__, 'on_meta' ), 10, 4 );
		add_action( 'user_register', array( __CLASS__, 'on_register' ), 20 );
		add_action( 'transition_post_status', array( __CLASS__, 'on_post' ), 10, 3 );
		add_action( 'admin_bar_menu', array( __CLASS__, 'bar' ), 90 );
	}

	/** One time: the Inbox is for help requests only. Old member-activity rows are marked done. */
	public static function migrate() {
		if ( get_option( 'mrsh_attn_mig' ) ) {
			return;
		}
		$l = self::load();
		foreach ( $l as $i => $e ) {
			if ( in_array( $e['type'] ?? '', array( 'member', 'plan', 'profile' ), true ) ) {
				$l[ $i ]['done'] = 1;
			}
		}
		update_option( self::OPT, $l, false );
		update_option( 'mrsh_attn_mig', 1, false );
		delete_transient( 'mrsh_cnt' );
	}

	/** New members are handled in the Member manager, not in the Inbox. */
	public static function new_members( $days = 7 ) {
		$l = get_option( 'mrsh_newmem', array() );
		$l = is_array( $l ) ? $l : array();
		$c = time() - $days * DAY_IN_SECONDS;
		return array_values( array_filter( $l, function ( $e ) use ( $c ) {
			return (int) $e['t'] > $c;
		} ) );
	}

	/* ---------- log ---------- */

	private static function load() {
		$l = get_option( self::OPT, array() );
		return is_array( $l ) ? $l : array();
	}

	public static function add( $type, $uid, $text, $link = '' ) {
		$l = self::load();
		foreach ( array_slice( $l, 0, 5 ) as $e ) {
			if ( $e['type'] === $type && (int) $e['uid'] === (int) $uid && ! $e['done'] && time() - (int) $e['t'] < 60 ) {
				return;
			}
		}
		array_unshift( $l, array( 't' => time(), 'type' => $type, 'uid' => (int) $uid, 'text' => mb_substr( (string) $text, 0, 200 ), 'link' => (string) $link, 'done' => 0 ) );
		update_option( self::OPT, array_slice( $l, 0, 300 ), false );
		delete_transient( 'mrsh_cnt' );
	}

	/** Open Inbox items of the given kinds that the AI has not looked at yet. */
	public static function unreviewed( $types, $max = 5 ) {
		$o = array();
		foreach ( self::load() as $e ) {
			if ( empty( $e['done'] ) && empty( $e['ai'] ) && in_array( $e['type'] ?? '', $types, true ) ) {
				$o[] = $e;
				if ( count( $o ) >= $max ) {
					break;
				}
			}
		}
		return $o;
	}

	/** The AI looked at this item (by its time stamp). $close = true when it was a false alarm. */
	public static function reviewed( $t, $close ) {
		$l = self::load();
		foreach ( $l as $i => $e ) {
			if ( (int) $e['t'] === (int) $t ) {
				$l[ $i ]['ai'] = 1;
				if ( $close ) {
					$l[ $i ]['done'] = 1;
				}
			}
		}
		update_option( self::OPT, $l, false );
		delete_transient( 'mrsh_cnt' );
	}

	/** Mark open Inbox items of one kind for one member as done (the robot dealt with them). */
	public static function close( $type, $uid ) {
		$l = self::load();
		$c = false;
		foreach ( $l as $i => $e ) {
			if ( ( $e['type'] ?? '' ) === $type && (int) ( $e['uid'] ?? 0 ) === (int) $uid && empty( $e['done'] ) ) {
				$l[ $i ]['done'] = 1;
				$c               = true;
			}
		}
		if ( $c ) {
			update_option( self::OPT, $l, false );
			delete_transient( 'mrsh_cnt' );
		}
	}

	public static function open_count() {
		$n = 0;
		foreach ( self::load() as $e ) {
			if ( empty( $e['done'] ) ) {
				$n++;
			}
		}
		return $n;
	}

	private static function who( $uid ) {
		$u = get_userdata( (int) $uid );
		return $u ? ( $u->display_name ?: $u->user_login ) : 'A member';
	}

	private static function link_for( $uid, $f = '' ) {
		$u = get_userdata( (int) $uid );
		$a = array( 'page' => 'mrsh-desk' );
		if ( $f ) {
			$a['f'] = $f;
		} elseif ( $u ) {
			$a['q'] = $u->user_email;
		}
		return add_query_arg( $a, admin_url( 'admin.php' ) );
	}

	/* ---------- events ---------- */

	public static function on_meta( $mid, $uid, $key, $val ) {
		if ( ! in_array( $key, array( 'mrt_vreq', 'mrt_plan_req' ), true ) || '' === (string) $val || empty( $val ) ) {
			return;
		}
		if ( get_current_user_id() !== (int) $uid ) {
			return; // only what the member did themselves (an admin testing with their own account counts too)
		}
		$n = self::who( $uid );
		if ( 'mrt_vreq' === $key ) {
			self::add( 'verify', $uid, $n . ' asked to be verified.', self::link_for( $uid ) );
		} elseif ( 'mrt_plan_req' === $key ) {
			if ( class_exists( 'MRSH_Tickets' ) && method_exists( 'MRSH_Tickets', 'kick' ) ) {
				MRSH_Tickets::kick(); // the robot answers within about a minute
			}
			self::add( 'planreq', $uid, $n . ' asked for the ' . (string) $val . ' plan. Check the payment, then approve it.', self::link_for( $uid, 'planreq' ) );
		} else {
			self::add( 'plan', $uid, $n . ' changed to the ' . (string) $val . ' plan.', self::link_for( $uid ) );
		}
	}

	public static function on_register( $uid ) {
		$l = get_option( 'mrsh_newmem', array() );
		$l = is_array( $l ) ? $l : array();
		array_unshift( $l, array( 't' => time(), 'uid' => (int) $uid ) );
		update_option( 'mrsh_newmem', array_slice( $l, 0, 300 ), false );
		delete_transient( 'mrsh_cnt' );
	}

	public static function on_post( $new, $old, $post ) {
		// Profiles waiting for approval are counted in the Member manager already; they no longer fill the Inbox.
	}

	/* ---------- inbox page ---------- */

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Inbox', 'Inbox', 'manage_options', self::SLUG, array( __CLASS__, 'page' ) );
	}

	public static function act() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_attn_do' );
		$do = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
		$l  = self::load();
		if ( 'all' === $do ) {
			foreach ( $l as $i => $e ) {
				$l[ $i ]['done'] = 1;
			}
		} elseif ( 'clear' === $do ) {
			$l = array_values( array_filter( $l, function ( $e ) {
				return empty( $e['done'] );
			} ) );
		} elseif ( 0 === strpos( $do, 'done_' ) ) {
			$t = (int) substr( $do, 5 );
			foreach ( $l as $i => $e ) {
				if ( (int) $e['t'] === $t ) {
					$l[ $i ]['done'] = 1;
				}
			}
		}
		update_option( self::OPT, $l, false );
		delete_transient( 'mrsh_cnt' );
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG ) );
		exit;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		if ( ! class_exists( 'MRSH_Boost' ) ) {
			echo '<div class="wrap"><h1>Inbox</h1><p>The page styles are missing. Reinstall the plugin zip.</p></div>';
			return;
		}
		MRSH_Boost::ui_open( 'Inbox', 'Helpdesk: tickets, plan and verification requests, reports and payment proofs. New members and profile reminders are handled automatically in the Member manager.', 'g-red', 'M4 4h16v10h-4l-2 3h-4l-2-3H4zm0 12h4l2 3h4l2-3h4v4H4z' );
		$c   = MRSH_Tabs::counts();
		$map = self::items();
		echo '<h3>Waiting for you now</h3><div class="mx-tbl"><table class="widefat striped"><thead><tr><th>What</th><th>How many</th><th></th></tr></thead><tbody>';
		$any = false;
		foreach ( $map as $k => $d ) {
			$n = (int) ( $c[ $k ] ?? 0 );
			if ( $n > 0 ) {
				$any = true;
				echo '<tr><td>' . esc_html( $d[0] ) . '</td><td><b class="mrt-n" style="position:static;display:inline-block">' . (int) $n . '</b></td><td><a class="mx-btn s p" href="' . esc_url( admin_url( 'admin.php?page=' . $d[1] ) ) . '">Open</a></td></tr>';
			}
		}
		if ( ! $any ) {
			echo '<tr><td colspan="3">Nothing is waiting. Well done.</td></tr>';
		}
		echo '</tbody></table></div>';

		$l = self::load();
		echo '<h3 style="margin-top:24px">What members did</h3>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_attn_do">';
		wp_nonce_field( 'mrsh_attn_do' );
		echo '<p class="mx-tabs"><button name="do" value="all" class="mx-btn s">Mark all as done</button><button name="do" value="clear" class="mx-btn s">Remove finished items</button></p>';
		echo '<div class="mx-tbl"><table class="widefat striped"><thead><tr><th>When</th><th>Who</th><th>What happened</th><th></th></tr></thead><tbody>';
		if ( ! $l ) {
			echo '<tr><td colspan="4">Nothing yet. Plan requests and verification requests will show here.</td></tr>';
		}
		$ic = array( 'plan' => 'Plan', 'planreq' => 'Plan request', 'verify' => 'Verification', 'member' => 'New member', 'profile' => 'Profile' );
		foreach ( array_slice( $l, 0, 100 ) as $e ) {
			$done = ! empty( $e['done'] );
			echo '<tr' . ( $done ? ' style="opacity:.55"' : '' ) . '><td>' . esc_html( wp_date( 'j M H:i', (int) $e['t'] ) ) . '</td><td>' . self::who_cell( (int) $e['uid'] ) . '</td><td><span class="mx-pill' . ( $done ? ' ok' : ' bad' ) . '">' . esc_html( $ic[ $e['type'] ] ?? $e['type'] ) . '</span> ' . esc_html( $e['text'] ) . '</td><td>';
			if ( ! empty( $e['link'] ) ) {
				echo '<a class="mx-btn s" href="' . esc_url( $e['link'] ) . '">Open</a> ';
			}
			if ( ! $done ) {
				echo '<button name="do" value="done_' . (int) $e['t'] . '" class="mx-btn s p">Done</button>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table></div></form></div>';
	}

	/** Name, email, id, profile link and current plan of the member behind an event. */
	private static function who_cell( $uid ) {
		$u = $uid ? get_userdata( $uid ) : null;
		if ( ! $u ) {
			return '<span class="description">-</span>';
		}
		$p   = class_exists( 'MRSH_Members' ) ? MRSH_Members::my_profile( $uid ) : null;
		$out = '<b>' . esc_html( $u->display_name ?: $u->user_login ) . '</b> <span class="description">#' . (int) $uid . '</span><br><span class="description">' . esc_html( $u->user_email ) . '</span>';
		$pl  = (string) get_user_meta( $uid, 'mrt_plan', true );
		$rq  = (string) get_user_meta( $uid, 'mrt_plan_req', true );
		$out .= '<br><span class="description">Plan: ' . esc_html( $pl ?: 'none' ) . ( $rq ? ' | asked: <b>' . esc_html( $rq ) . '</b>' : '' ) . '</span>';
		if ( $p ) {
			$out .= '<br><a href="' . esc_url( get_permalink( $p->ID ) ) . '" target="_blank" rel="noopener">View profile</a>';
		}
		$out .= ' <a href="' . esc_url( add_query_arg( array( 'page' => 'mrsh-desk', 'q' => $u->user_email ), admin_url( 'admin.php' ) ) ) . '">Member manager</a>';
		return $out;
	}

	/** Counter key => array( label, admin page ). */
	public static function items() {
		return array(
			'mrsh-inbox'    => array( 'Help requests from members (plan requests, verification requests)', self::SLUG ),
			'mrsh-tickets'  => array( 'Support tickets not solved yet', 'mrsh-tickets' ),
			'mrsh-tlate'    => array( 'Support tickets that are LATE', 'mrsh-tickets&f=late' ),
			'mrsh-activity' => array( 'Flagged behaviour to review (abusive words, scam words, contact details)', 'mrsh-activity&fl=open' ),
			'mrsh-desk'     => array( 'Members: plan requests, verification requests, profiles to approve', 'mrsh-desk' ),
			'mrsh-reports'  => array( 'Reported profiles', 'mrsh-reports' ),
			'mrsh-proofs'   => array( 'Payment proofs to check', 'mrsh-proofs' ),
			'mrsh-checks'   => array( 'Selfie and video checks', 'mrsh-checks' ),
			'mrsh-photodiag' => array( 'Photo problems', 'mrsh-photodiag' ),
			'mrsh-mailq'    => array( 'Emails that failed to send', 'mrsh-mailq' ),
		);
	}

	/** Top admin bar: one red number, a list of what is waiting. */
	public static function bar( $bar ) {
		if ( ! current_user_can( 'manage_options' ) || ! class_exists( 'MRSH_Tabs' ) ) {
			return;
		}
		$c     = MRSH_Tabs::counts();
		$total = 0;
		$kids  = array();
		foreach ( self::items() as $k => $d ) {
			$n = (int) ( $c[ $k ] ?? 0 );
			if ( $n > 0 ) {
				if ( 'mrsh-tlate' !== $k ) {
					$total += $n;
				}
				$kids[ $k ] = array( $d[0], $n, $d[1] );
			}
		}
		$title = '<span style="display:inline-flex;align-items:center;gap:6px">Needs you' . ( $total > 0 ? ' <span style="background:#e11d48;color:#fff;border-radius:99px;padding:0 8px;font-weight:700;line-height:18px;min-width:18px;text-align:center;display:inline-block">' . ( $total > 99 ? '99+' : (int) $total ) . '</span>' : '' ) . '</span>';
		$bar->add_node( array( 'id' => 'mrsh-attn', 'title' => $title, 'href' => admin_url( 'admin.php?page=' . self::SLUG ) ) );
		foreach ( $kids as $k => $d ) {
			$bar->add_node( array( 'id' => 'mrsh-attn-' . $k, 'parent' => 'mrsh-attn', 'title' => esc_html( $d[0] ) . ' <b style="color:#ff8a9a">' . (int) $d[1] . '</b>', 'href' => admin_url( 'admin.php?page=' . $d[2] ) ) );
		}
		if ( ! $kids ) {
			$bar->add_node( array( 'id' => 'mrsh-attn-none', 'parent' => 'mrsh-attn', 'title' => 'Nothing is waiting', 'href' => admin_url( 'admin.php?page=' . self::SLUG ) ) );
		}
	}
}
MRSH_Attn::init();
