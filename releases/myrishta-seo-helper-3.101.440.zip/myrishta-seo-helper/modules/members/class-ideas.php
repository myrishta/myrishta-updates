<?php
/**
 * More ideas, part 6: weekly report e-mail, success stories, fake profile check, helper desk, donation page,
 * WhatsApp status card, saved searches with alerts, complete-profile badge, safe meeting guide,
 * city and caste landing pages (English and Urdu), referral link.
 * Settings: option mrsh_ideas. Admin page: Growth > More tools. Helper page: Helper desk.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Ideas {

	const CPT = 'listing_type';

	public static function opt( $k = null ) {
		$o = array_merge( array( 'rep_on' => 1, 'rep_to' => '', 'don_on' => 0, 'don_goal' => 0, 'don_raised' => 0, 'don_text' => '', 'don_acct' => '', 'land_on' => 1 ), (array) get_option( 'mrsh_ideas', array() ) );
		return null === $k ? $o : ( $o[ $k ] ?? '' );
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 31 );
		foreach ( array( 'save', 'report_now', 'story_act', 'helper_act' ) as $a ) {
			add_action( 'admin_post_mrsh_i_' . $a, array( __CLASS__, $a ) );
		}
		add_action( 'admin_post_mrsh_story_send', array( __CLASS__, 'story_send' ) );
		add_action( 'init', array( __CLASS__, 'boot' ), 30 );
		add_action( 'mrsh_weekly_report', array( __CLASS__, 'send_report' ) );
		add_action( 'mrsh_saved_alerts', array( __CLASS__, 'alerts' ) );
		add_action( 'mrsh_matched_made', array( __CLASS__, 'matched_mail' ), 10, 2 );
		add_action( 'mrt_account_extra', array( __CLASS__, 'account_boxes' ) );
		add_action( 'mrt_profile_after', array( __CLASS__, 'profile_share' ) );
		add_action( 'wp_ajax_mrsh_ss_save', array( __CLASS__, 'ss_save' ) );
		add_action( 'wp_ajax_mrsh_ss_del', array( __CLASS__, 'ss_del' ) );
		add_action( 'wp_footer', array( __CLASS__, 'ss_button' ) );
		add_action( 'template_redirect', array( __CLASS__, 'route' ), 1 );
		add_action( 'user_register', array( __CLASS__, 'ref_user' ) );
		add_shortcode( 'mrsh_donate', array( __CLASS__, 'donate_sc' ) );
		add_filter( 'query_vars', function ( $v ) { return array_merge( $v, array( 'mrsh_land', 'mrsh_slug', 'mrsh_ur' ) ); } );
	}

	public static function boot() {
		if ( ! wp_next_scheduled( 'mrsh_weekly_report' ) ) {
			wp_schedule_event( time() + 3600, 'weekly', 'mrsh_weekly_report' );
		}
		if ( ! wp_next_scheduled( 'mrsh_saved_alerts' ) ) {
			wp_schedule_event( time() + 7200, 'daily', 'mrsh_saved_alerts' );
		}
		add_rewrite_rule( '^(ur/)?rishta/(city|caste)/([^/]+)/?$', 'index.php?mrsh_land=$matches[2]&mrsh_slug=$matches[3]&mrsh_ur=$matches[1]', 'top' );
		if ( ! get_page_by_path( 'rishta' ) ) {
			add_rewrite_rule( '^(ur/)?rishta/?$', 'index.php?mrsh_land=index&mrsh_ur=$matches[1]', 'top' );
		}
		if ( get_option( 'mrsh_ideas_rw' ) !== MRSH_VERSION ) {
			update_option( 'mrsh_ideas_rw', MRSH_VERSION, false );
			flush_rewrite_rules( false );
		}
		// Referral cookie.
		if ( isset( $_GET['ref'] ) && ! is_admin() && ! headers_sent() ) { // phpcs:ignore
			$r = absint( $_GET['ref'] ); // phpcs:ignore
			if ( $r && get_userdata( $r ) ) {
				setcookie( 'mrt_ref', (string) $r, time() + 30 * DAY_IN_SECONDS, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN, is_ssl(), true );
			}
		}
		// Safe meeting guide page, once.
		if ( ! get_option( 'mrsh_safe_page' ) && is_admin() && current_user_can( 'manage_options' ) ) {
			update_option( 'mrsh_safe_page', 1, false );
			if ( ! get_page_by_path( 'safe-meeting-guide' ) ) {
				wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => 'safe-meeting-guide', 'post_title' => 'Safe Meeting Guide | محفوظ ملاقات کی رہنمائی', 'post_content' => self::safe_html() ) );
			}
				// No donate page is created: the site is free, with no donations.
		}
	}

	private static function safe_html() {
		return '<h2>Before the first family meeting</h2><ul><li>Meet in a public place such as a restaurant, a family hall or a relative\'s home. Never meet alone in a private place.</li><li>Bring a parent, brother, sister or another trusted adult. Tell them the time and place.</li><li>Check the profile first: ask for a video call and look for the Verified badge.</li><li>Do not send money, bank details or ID card photos before the families have met.</li><li>Keep phone numbers private until both families agree.</li><li>If something feels wrong, leave and use the Report button on the profile.</li></ul>'
			. '<h2 dir="rtl" style="text-align:right">پہلی خاندانی ملاقات سے پہلے</h2><ul dir="rtl" style="text-align:right"><li>کسی عوامی جگہ ملیں، جیسے ریسٹورنٹ، شادی ہال یا کسی رشتے دار کا گھر۔ کبھی کسی نجی جگہ اکیلے نہ ملیں۔</li><li>والدین، بھائی، بہن یا کوئی قابلِ اعتماد بالغ ساتھ لے جائیں اور انہیں وقت اور جگہ بتا دیں۔</li><li>پہلے پروفائل جانچیں: ویڈیو کال کریں اور ویریفائیڈ بیج دیکھیں۔</li><li>ملاقات سے پہلے رقم، بینک کی تفصیل یا شناختی کارڈ کی تصویر نہ بھیجیں۔</li><li>جب تک دونوں خاندان راضی نہ ہوں فون نمبر نجی رکھیں۔</li><li>کچھ غلط لگے تو وہاں سے اٹھ جائیں اور پروفائل پر Report کا بٹن استعمال کریں۔</li></ul>';
	}

	/* ================= admin pages ================= */

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'More tools', 'More tools', 'manage_options', 'mrsh-ideas', array( __CLASS__, 'page' ) );
		add_menu_page( 'Helper desk', 'Helper desk', 'edit_others_posts', 'mrsh-helper', array( __CLASS__, 'helper_page' ), ( class_exists( 'MRSH_Tabs' ) ? MRSH_Tabs::menu_icon( 'clip' ) : 'dashicons-yes-alt' ), 58 );
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_i_save' );
		$p = function ( $k ) { return isset( $_POST[ $k ] ) ? sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) : ''; }; // phpcs:ignore
		update_option( 'mrsh_ideas', array(
			'rep_on' => empty( $_POST['rep_on'] ) ? 0 : 1, 'rep_to' => is_email( $p( 'rep_to' ) ) ? $p( 'rep_to' ) : '',
			'don_on' => empty( $_POST['don_on'] ) ? 0 : 1, 'don_goal' => absint( $p( 'don_goal' ) ), 'don_raised' => absint( $p( 'don_raised' ) ),
			'don_text' => $p( 'don_text' ), 'don_acct' => sanitize_textarea_field( wp_unslash( $_POST['don_acct'] ?? '' ) ), // phpcs:ignore
			'land_on' => empty( $_POST['land_on'] ) ? 0 : 1,
		), false );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-ideas&ok=1' ) );
		exit;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$o = self::opt();
		echo '<div class="wrap"><h1>More tools</h1>';
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success is-dismissible"><p>Done.</p></div>';
		}
		$card = 'background:#fff;border:1px solid #dcdcde;border-radius:14px;padding:6px 18px 14px;margin:14px 0;max-width:900px';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_i_save">';
		wp_nonce_field( 'mrsh_i_save' );
		echo '<div style="' . $card . '"><h2>Weekly report e-mail</h2><p><label><input type="checkbox" name="rep_on" value="1"' . checked( $o['rep_on'], 1, false ) . '> Send a summary every week</label></p><p><label>Send to <input type="email" class="regular-text" name="rep_to" value="' . esc_attr( $o['rep_to'] ) . '" placeholder="' . esc_attr( get_option( 'admin_email' ) ) . '"></label></p></div>';
		echo '<div style="' . $card . '"><h2>Donation page</h2><p>The page <b>/donate/</b> is created for you. It shows your account details and a progress bar.</p><p><label><input type="checkbox" name="don_on" value="1"' . checked( $o['don_on'], 1, false ) . '> Show the donation page</label></p>';
		echo '<p><label>Goal (Rs) <input type="number" name="don_goal" value="' . (int) $o['don_goal'] . '"></label> <label>Received so far (Rs) <input type="number" name="don_raised" value="' . (int) $o['don_raised'] . '"></label></p>';
		echo '<p><label>Short message<br><input type="text" class="large-text" name="don_text" value="' . esc_attr( $o['don_text'] ) . '" placeholder="Help us keep rishta free for every family"></label></p>';
		echo '<p><label>Account details (Easypaisa, JazzCash, bank)<br><textarea class="large-text" rows="4" name="don_acct" placeholder="Easypaisa: 03xx xxxxxxx (Name)">' . esc_textarea( $o['don_acct'] ) . '</textarea></label></p></div>';
		echo '<div style="' . $card . '"><h2>City and caste pages for Google</h2><p><label><input type="checkbox" name="land_on" value="1"' . checked( $o['land_on'], 1, false ) . '> Make pages like <code>/rishta/city/lahore/</code>, <code>/rishta/caste/arain/</code> and the Urdu copies under <code>/ur/rishta/...</code></label></p><p><a href="' . esc_url( home_url( '/rishta/' ) ) . '" target="_blank">Open the index page</a> &middot; <a href="' . esc_url( home_url( '/ur/rishta/' ) ) . '" target="_blank">Urdu index</a>. Add these two addresses in Google Search Console to get them indexed.</p></div>';
		echo '<p><button class="button button-primary button-large">Save</button></p></form>';
		// Report now.
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_i_report_now">' . wp_nonce_field( 'mrsh_i_report_now', '_wpnonce', true, false ) . '<button class="button">Send the weekly report now</button></form>';
		// Stories.
		$q = (array) get_option( 'mrsh_story_queue', array() );
		echo '<div style="' . $card . '"><h2>Success stories waiting</h2>';
		if ( ! $q ) {
			echo '<p>None yet. Members who are marked as matched can send a story from My account.</p>';
		}
		foreach ( $q as $i => $s ) {
			echo '<div style="border-bottom:1px solid #eee;padding:8px 0"><b>' . esc_html( $s['name'] ) . '</b>: ' . esc_html( $s['text'] ) . '<br>';
			foreach ( array( 'approve' => 'Show on home page', 'reject' => 'Reject' ) as $act => $l ) {
				echo '<form method="post" style="display:inline" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_i_story_act"><input type="hidden" name="i" value="' . (int) $i . '"><input type="hidden" name="do" value="' . esc_attr( $act ) . '">' . wp_nonce_field( 'mrsh_i_story_act', '_wpnonce', true, false ) . '<button class="button button-small">' . esc_html( $l ) . '</button></form> ';
			}
			echo '</div>';
		}
		echo '</div>';
		// Fake check.
		echo '<div style="' . $card . '"><h2>Possible fake or double profiles</h2><p class="description">A hint only. Open each profile and decide yourself.</p>';
		$sus = self::suspicious();
		if ( ! $sus ) {
			echo '<p>Nothing suspicious found in the latest 300 profiles.</p>';
		}
		foreach ( $sus as $id => $why ) {
			echo '<p><a href="' . esc_url( get_edit_post_link( $id ) ) . '"><b>' . esc_html( get_the_title( $id ) ) . '</b></a> <span style="color:#b45309">' . esc_html( implode( ', ', $why ) ) . '</span></p>';
		}
		echo '</div>';
		// Referrals.
		global $wpdb;
		$rows = $wpdb->get_results( "SELECT meta_value r, COUNT(*) n FROM {$wpdb->usermeta} WHERE meta_key='mrt_ref' GROUP BY meta_value ORDER BY n DESC LIMIT 10" ); // phpcs:ignore
		echo '<div style="' . $card . '"><h2>Top referrers</h2>';
		if ( ! $rows ) {
			echo '<p>No referrals yet. Members find their link in My account.</p>';
		}
		foreach ( $rows as $r ) {
			$u = get_userdata( (int) $r->r );
			echo '<p>' . esc_html( $u ? $u->display_name : '#' . (int) $r->r ) . ': <b>' . (int) $r->n . '</b> families joined</p>';
		}
		echo '</div></div>';
	}

	/* ================= 1. weekly report ================= */

	public static function report_now() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_i_report_now' );
		self::send_report( true );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-ideas&ok=1' ) );
		exit;
	}

	public static function send_report( $force = false ) {
		$o = self::opt();
		if ( ! $force && empty( $o['rep_on'] ) ) {
			return;
		}
		$since = gmdate( 'Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS );
		$new   = new WP_Query( array( 'post_type' => self::CPT, 'post_status' => array( 'publish', 'pending', 'draft' ), 'date_query' => array( array( 'after' => $since, 'inclusive' => true, 'column' => 'post_date_gmt' ) ), 'posts_per_page' => 300, 'fields' => 'ids', 'no_found_rows' => false ) );
		$ucnt  = count( get_users( array( 'date_query' => array( array( 'after' => $since ) ), 'fields' => 'ID', 'number' => 1000 ) ) );
		$cnt   = wp_count_posts( self::CPT );
		$city  = array();
		foreach ( $new->posts as $id ) {
			foreach ( (array) wp_get_object_terms( $id, 'country' ) as $t ) {
				if ( ! is_wp_error( $t ) && $t->parent ) {
					$city[ $t->name ] = ( $city[ $t->name ] ?? 0 ) + 1;
				}
			}
		}
		arsort( $city );
		$msg  = get_bloginfo( 'name' ) . " weekly report\n\n";
		$msg .= 'New profiles this week: ' . (int) $new->found_posts . "\n";
		$msg .= 'New members this week: ' . $ucnt . "\n";
		$msg .= 'Profiles live now: ' . (int) ( $cnt->publish ?? 0 ) . "\n";
		$msg .= 'Waiting for approval: ' . (int) ( $cnt->pending ?? 0 ) . "\n";
		$msg .= 'Rishtas matched so far: ' . count( (array) get_option( 'mrsh_matched', array() ) ) . "\n";
		$msg .= 'Success stories waiting: ' . count( (array) get_option( 'mrsh_story_queue', array() ) ) . "\n";
		if ( $city ) {
			$msg .= "\nTop cities for new profiles:\n";
			foreach ( array_slice( $city, 0, 5, true ) as $n => $c ) {
				$msg .= "- $n: $c\n";
			}
		}
		$msg .= "\nOpen the Today page: " . admin_url( 'admin.php?page=mrsh-today' ) . "\n";
		wp_mail( $o['rep_to'] ? $o['rep_to'] : get_option( 'admin_email' ), get_bloginfo( 'name' ) . ' weekly report', $msg );
	}

	/* ================= 2. success stories ================= */

	public static function matched_mail( $a, $b ) {
		foreach ( array( $a, $b ) as $pid ) {
			$u = get_userdata( (int) get_post_field( 'post_author', $pid ) );
			if ( $u && is_email( $u->user_email ) ) {
				wp_mail( $u->user_email, 'Mubarak! Share your story', "Mubarak from " . get_bloginfo( 'name' ) . ".\n\nIf you are happy, please share two lines about your rishta in My account, so other families get hope.\n" . home_url( '/my-account/' ) );
			}
		}
	}

	public static function story_send() {
		$uid = get_current_user_id();
		if ( ! $uid ) {
			wp_safe_redirect( home_url( '/my-account/' ) );
			exit;
		}
		check_admin_referer( 'mrsh_story_send' );
		$t = trim( sanitize_textarea_field( wp_unslash( $_POST['story'] ?? '' ) ) ); // phpcs:ignore
		$n = trim( sanitize_text_field( wp_unslash( $_POST['sname'] ?? '' ) ) ); // phpcs:ignore
		if ( strlen( $t ) >= 20 && ! get_transient( 'mrsh_st_' . $uid ) ) {
			$q   = (array) get_option( 'mrsh_story_queue', array() );
			$q[] = array( 'u' => $uid, 'name' => mb_substr( $n ? $n : 'A happy family', 0, 60 ), 'text' => mb_substr( str_replace( '|', '/', $t ), 0, 400 ) );
			update_option( 'mrsh_story_queue', array_slice( $q, -50 ), false );
			set_transient( 'mrsh_st_' . $uid, 1, DAY_IN_SECONDS );
			wp_mail( get_option( 'admin_email' ), 'New success story', 'Open: ' . admin_url( 'admin.php?page=mrsh-ideas' ) );
		}
		wp_safe_redirect( add_query_arg( 'story', 'ok', home_url( '/my-account/' ) ) );
		exit;
	}

	public static function story_act() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_i_story_act' );
		$i = absint( $_POST['i'] ?? 0 ); // phpcs:ignore
		$q = (array) get_option( 'mrsh_story_queue', array() );
		if ( isset( $q[ $i ] ) ) {
			if ( 'approve' === ( $_POST['do'] ?? '' ) ) { // phpcs:ignore
				$st = (array) get_option( 'mrsh_site', array() );
				$st['stories'] = trim( $q[ $i ]['name'] . ' | ' . $q[ $i ]['text'] . "\n" . ( $st['stories'] ?? '' ) );
				update_option( 'mrsh_site', $st, false );
			}
			unset( $q[ $i ] );
			update_option( 'mrsh_story_queue', array_values( $q ), false );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-ideas&ok=1' ) );
		exit;
	}

	/* ================= 3. suspicious profiles ================= */

	public static function suspicious() {
		$c = get_transient( 'mrsh_sus' );
		if ( is_array( $c ) ) {
			return $c;
		}
		$ids = get_posts( array( 'post_type' => self::CPT, 'post_status' => array( 'publish', 'pending' ), 'numberposts' => 300, 'fields' => 'ids' ) );
		$ph  = array();
		$img = array();
		$nm  = array();
		foreach ( $ids as $id ) {
			$p = preg_replace( '/\D+/', '', (string) get_post_meta( $id, 'custom-14', true ) );
			if ( strlen( $p ) >= 9 ) {
				$ph[ substr( $p, -9 ) ][] = $id;
			}
			$tid = get_post_thumbnail_id( $id );
			if ( $tid ) {
				$f = get_attached_file( $tid );
				$k = ( $f && is_readable( $f ) ) ? md5_file( $f ) : 'a' . $tid;
				$img[ $k ][] = $id;
			}
			$nm[ strtolower( trim( get_the_title( $id ) ) ) . '|' . (int) get_post_meta( $id, 'daage', true ) ][] = $id;
		}
		$out = array();
		foreach ( array( 'Same phone number as another profile' => $ph, 'Same main photo as another profile' => $img, 'Same name and age as another profile' => $nm ) as $why => $grp ) {
			foreach ( $grp as $list ) {
				if ( count( $list ) > 1 ) {
					foreach ( $list as $id ) {
						$out[ $id ][] = $why;
					}
				}
			}
		}
		set_transient( 'mrsh_sus', $out, HOUR_IN_SECONDS );
		return $out;
	}

	/* ================= 4. helper desk ================= */

	public static function helper_page() {
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			return;
		}
		echo '<div class="wrap"><h1>Helper desk</h1>';
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success is-dismissible"><p>Done.</p></div>';
		}
		$ids = get_posts( array( 'post_type' => self::CPT, 'post_status' => 'pending', 'numberposts' => 30, 'fields' => 'ids' ) );
		echo '<p>' . count( $ids ) . ' profiles are waiting. Open each one, then press a button.</p>';
		foreach ( $ids as $id ) {
			$img = get_the_post_thumbnail_url( $id, 'thumbnail' );
			echo '<div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap;background:#fff;border:1px solid #dcdcde;border-radius:14px;padding:12px;margin:10px 0;max-width:900px">';
			echo $img ? '<img src="' . esc_url( $img ) . '" width="64" height="64" style="border-radius:12px;object-fit:cover" alt="">' : '<span style="width:64px;height:64px;border-radius:12px;background:#eee;display:inline-block"></span>'; // phpcs:ignore
			echo '<div style="flex:1;min-width:180px"><b>' . esc_html( get_the_title( $id ) ) . '</b>, ' . (int) get_post_meta( $id, 'daage', true ) . '<br><a href="' . esc_url( get_edit_post_link( $id ) ) . '">Open</a> &middot; <a href="' . esc_url( get_permalink( $id ) ) . '" target="_blank">Preview</a></div>';
			foreach ( array( 'approve' => array( 'Approve', 'primary' ), 'photo' => array( 'Ask for a clearer photo', '' ), 'reject' => array( 'Reject', '' ) ) as $act => $l ) {
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_i_helper_act"><input type="hidden" name="pid" value="' . (int) $id . '"><input type="hidden" name="do" value="' . esc_attr( $act ) . '">' . wp_nonce_field( 'mrsh_i_helper_act', '_wpnonce', true, false ) . '<button class="button ' . ( $l[1] ? 'button-' . esc_attr( $l[1] ) : '' ) . '">' . esc_html( $l[0] ) . '</button></form>';
			}
			echo '</div>';
		}
		$log = array_reverse( (array) get_option( 'mrsh_helper_log', array() ) );
		if ( current_user_can( 'manage_options' ) && $log ) {
			echo '<h2>Recent actions</h2><ul>';
			foreach ( array_slice( $log, 0, 30 ) as $l ) {
				echo '<li>' . esc_html( wp_date( 'j M H:i', $l['t'] ) . ' - ' . $l['who'] . ': ' . $l['do'] . ' - ' . get_the_title( $l['pid'] ) ) . '</li>';
			}
			echo '</ul>';
		}
		echo '</div>';
	}

	public static function helper_act() {
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_i_helper_act' );
		$pid = absint( $_POST['pid'] ?? 0 ); // phpcs:ignore
		$do  = sanitize_key( $_POST['do'] ?? '' ); // phpcs:ignore
		if ( $pid && self::CPT === get_post_type( $pid ) ) {
			$au = get_userdata( (int) get_post_field( 'post_author', $pid ) );
			if ( 'approve' === $do ) {
				update_post_meta( $pid, 'mrt_approved', 1 );
				wp_update_post( array( 'ID' => $pid, 'post_status' => 'publish' ) );
			} elseif ( 'reject' === $do ) {
				wp_update_post( array( 'ID' => $pid, 'post_status' => 'draft' ) );
			}
			if ( $au && is_email( $au->user_email ) && in_array( $do, array( 'photo', 'reject' ), true ) ) {
				$m = 'photo' === $do ? "Please add a clear photo of your own face to your profile so families can trust it.\n" : "Your profile was not approved. Please check that your details and photo are real, then save it again.\n";
				wp_mail( $au->user_email, get_bloginfo( 'name' ) . ': about your profile', $m . home_url( '/my-account/' ) );
			}
			$log   = (array) get_option( 'mrsh_helper_log', array() );
			$log[] = array( 't' => time(), 'who' => wp_get_current_user()->display_name, 'do' => $do, 'pid' => $pid );
			update_option( 'mrsh_helper_log', array_slice( $log, -200 ), false );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-helper&ok=1' ) );
		exit;
	}

	/* ================= 5. donation page ================= */

	public static function donate_sc() {
		$o = self::opt();
		if ( empty( $o['don_on'] ) ) {
			return '<p>Thank you for your interest. Donations are not open right now.</p>';
		}
		$goal = (int) $o['don_goal'];
		$got  = (int) $o['don_raised'];
		$pct  = $goal > 0 ? min( 100, (int) round( $got * 100 / $goal ) ) : 0;
		$h    = '<div style="max-width:640px;margin:0 auto;font-size:1.05rem"><p>' . esc_html( $o['don_text'] ? $o['don_text'] : 'My Rishta is free for every family. Your donation pays for hosting, safety checks and the phone app.' ) . '</p>';
		if ( $goal > 0 ) {
			$h .= '<div style="background:#eee;border-radius:99px;height:16px;overflow:hidden"><div style="width:' . $pct . '%;height:100%;background:linear-gradient(90deg,#e11d74,#7c3aed)"></div></div><p><b>Rs ' . number_format_i18n( $got ) . '</b> of Rs ' . number_format_i18n( $goal ) . ' (' . $pct . '%)</p>';
		}
		if ( '' !== trim( (string) $o['don_acct'] ) ) {
			$h .= '<div style="background:#f6e8f0;border-radius:14px;padding:14px 18px"><b>How to donate</b><br>' . nl2br( esc_html( $o['don_acct'] ) ) . '</div>';
		}
		return $h . '<p style="color:#666;font-size:.9rem">Donations are voluntary and never change how a profile is shown. Jazakallah khair.</p></div>';
	}

	/* ================= 13. referral ================= */

	public static function ref_user( $uid ) {
		$r = isset( $_COOKIE['mrt_ref'] ) ? absint( $_COOKIE['mrt_ref'] ) : 0;
		if ( $r && $r !== (int) $uid && get_userdata( $r ) ) {
			update_user_meta( $uid, 'mrt_ref', $r );
		}
	}

	/* ================= account boxes (2, 7, 9, 13) ================= */

	public static function account_boxes( $uid ) {
		global $wpdb;
		// Referral.
		$n = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key='mrt_ref' AND meta_value=%d", $uid ) ); // phpcs:ignore
		$l = add_query_arg( 'ref', $uid, home_url( '/' ) );
		echo '<div class="box" id="mrsh-ref"><h3>Invite families</h3><p class="mut">Share this link. ' . (int) $n . ' families joined through you.</p><p><input type="text" readonly value="' . esc_attr( $l ) . '" style="width:100%" onclick="this.select()"></p><a class="btn sm" target="_blank" rel="noopener" href="' . esc_url( 'https://wa.me/?text=' . rawurlencode( 'Free and safe rishta website for Pakistani families: ' . $l ) ) . '">Share on WhatsApp</a></div>';
		// Safe meeting.
		echo '<div class="box"><h3>Safe meeting guide</h3><p class="mut">Tips for the first family meeting, in English and Urdu.</p><a class="btn sm line" href="' . esc_url( home_url( '/safe-meeting-guide/' ) ) . '">Read the guide</a></div>';
		// Story form.
		$mine = class_exists( 'MRSH_Members' ) ? MRSH_Members::my_profile( $uid ) : null;
		if ( $mine && get_post_meta( $mine->ID, 'mrt_matched', true ) ) {
			echo '<div class="box" id="mrsh-story"><h3>Share your success story</h3>';
			if ( isset( $_GET['story'] ) ) { // phpcs:ignore
				echo '<p><b>Thank you. We will check it and show it on the home page.</b></p>';
			}
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_story_send">' . wp_nonce_field( 'mrsh_story_send', '_wpnonce', true, false ) . '<p><input type="text" name="sname" maxlength="60" placeholder="Names to show, for example Ali and Sara, Lahore" style="width:100%"></p><p><textarea name="story" rows="3" maxlength="400" required placeholder="Two or three lines about how you found each other" style="width:100%"></textarea></p><p><button class="btn">Send</button></p></form></div>';
		}
		// Saved searches: one list, in the Saved searches tab.
	}

	/* ================= 7. saved searches ================= */

	private static function ss_args( $q ) {
		parse_str( $q, $g );
		$args = array( 'post_type' => self::CPT, 'post_status' => 'publish', 'posts_per_page' => 20, 'fields' => 'ids', 'no_found_rows' => true );
		$tax  = array();
		foreach ( $g as $k => $v ) {
			if ( 0 === strpos( $k, 'tax_' ) && taxonomy_exists( substr( $k, 4 ) ) && '' !== $v ) {
				$tax[] = array( 'taxonomy' => substr( $k, 4 ), 'field' => 'slug', 'terms' => sanitize_title( $v ) );
			} elseif ( is_string( $v ) && '' !== $v && taxonomy_exists( $k ) ) {
				$tax[] = array( 'taxonomy' => $k, 'field' => 'slug', 'terms' => sanitize_title( $v ) );
			}
		}
		if ( $tax ) {
			$args['tax_query'] = $tax;
		}
		$min = absint( $g['age_min'] ?? 0 );
		$max = absint( $g['age_max'] ?? 0 );
		if ( $min || $max ) {
			$args['meta_query'] = array( array( 'key' => 'daage', 'value' => array( $min ? $min : 18, $max ? $max : 99 ), 'type' => 'NUMERIC', 'compare' => 'BETWEEN' ) );
		}
		if ( ! empty( $g['s'] ) ) {
			$args['s'] = sanitize_text_field( $g['s'] );
		}
		return $args;
	}

	public static function ss_save() {
		$uid = get_current_user_id();
		if ( ! $uid || ! check_ajax_referer( 'mrt', 'n', false ) ) {
			wp_send_json( array( 'ok' => false, 'msg' => 'Please log in.' ) );
		}
		parse_str( (string) wp_unslash( $_POST['q'] ?? '' ), $g ); // phpcs:ignore
		$keep = array();
		foreach ( $g as $k => $v ) {
			if ( is_string( $v ) && '' !== $v && ( 0 === strpos( $k, 'tax_' ) || in_array( $k, array( 'age_min', 'age_max', 's' ), true ) ) ) {
				$keep[ sanitize_key( $k ) ] = sanitize_text_field( $v );
			}
		}
		if ( ! $keep ) {
			wp_send_json( array( 'ok' => false, 'msg' => 'Choose at least one filter first.' ) );
		}
		$list = array_values( array_filter( (array) get_user_meta( $uid, 'mrt_saved_search', true ), 'is_array' ) );
		if ( count( $list ) >= 5 ) {
			wp_send_json( array( 'ok' => false, 'msg' => 'You can save 5 searches. Remove one in My account.' ) );
		}
		$label = implode( ', ', array_map( function ( $v ) { return ucwords( str_replace( '-', ' ', $v ) ); }, array_values( $keep ) ) );
		$list[] = array( 'q' => 'post_type=listing_type&' . http_build_query( $keep ), 'label' => mb_substr( $label, 0, 70 ), 't' => time() );
		update_user_meta( $uid, 'mrt_saved_search', $list );
		wp_send_json( array( 'ok' => true, 'msg' => 'Saved. We will e-mail you when a new profile fits.' ) );
	}

	public static function ss_del() {
		$uid = get_current_user_id();
		if ( $uid && check_ajax_referer( 'mrt', 'n', false ) ) {
			$list = array_values( array_filter( (array) get_user_meta( $uid, 'mrt_saved_search', true ), 'is_array' ) );
			unset( $list[ absint( $_POST['i'] ?? 0 ) ] ); // phpcs:ignore
			update_user_meta( $uid, 'mrt_saved_search', array_values( $list ) );
		}
		wp_send_json( array( 'ok' => true ) );
	}

	public static function ss_button() {
		if ( is_admin() || ! is_user_logged_in() || ! ( is_post_type_archive( self::CPT ) || ( is_search() && isset( $_GET['post_type'] ) ) ) ) { // phpcs:ignore
			return;
		}
		echo '<button type="button" id="mrsh-ssb" style="position:fixed;right:max(14px,env(safe-area-inset-right,0px));bottom:calc(76px + env(safe-area-inset-bottom,0px));z-index:50;border:0;border-radius:99px;padding:12px 18px;background:#7c3aed;color:#fff;font-weight:700;box-shadow:0 6px 18px rgba(0,0,0,.25);cursor:pointer">Save this search</button><script>document.getElementById("mrsh-ssb").onclick=function(){var b=this,f=new FormData();f.append("action","mrsh_ss_save");f.append("q",location.search.slice(1));f.append("n",(window.MRT||{}).n||"");fetch((window.MRT||{}).ajax||"/wp-admin/admin-ajax.php",{method:"POST",body:f,credentials:"same-origin"}).then(function(r){return r.json()}).then(function(r){var t=document.getElementById("mrt-toast");if(t){t.textContent=r.msg;t.classList.add("show");setTimeout(function(){t.classList.remove("show")},3000)}else{b.textContent=r.msg}})}</script>';
	}

	public static function alerts() {
		global $wpdb;
		$uids = $wpdb->get_col( "SELECT DISTINCT user_id FROM {$wpdb->usermeta} WHERE meta_key='mrt_searches'" ); // phpcs:ignore
		foreach ( $uids as $uid ) {
			$u = get_userdata( (int) $uid );
			if ( ! $u || ! is_email( $u->user_email ) || ( class_exists( 'MRSH_Mem_More5' ) && MRSH_Mem_More5::quiet( (int) $uid ) ) ) {
				continue;
			}
			$list  = array_values( array_filter( (array) get_user_meta( $uid, 'mrt_searches', true ), 'is_array' ) );
			$lines = array();
			foreach ( $list as $k => $s ) {
				$last = (int) ( $s['last'] ?? ( isset( $s['t'] ) ? $s['t'] : strtotime( (string) ( $s['d'] ?? 'now' ) ) ) );
				$a    = self::ss_args( $s['q'] );
				$a['date_query'] = array( array( 'after' => gmdate( 'Y-m-d H:i:s', $last ), 'column' => 'post_date_gmt' ) );
				foreach ( get_posts( $a ) as $pid ) {
					if ( (int) get_post_field( 'post_author', $pid ) !== (int) $uid ) {
						$lines[ $pid ] = get_the_title( $pid ) . ': ' . get_permalink( $pid );
					}
				}
				$list[ $k ]['last'] = time();
			}
			update_user_meta( $uid, 'mrt_searches', $list );
			if ( $lines ) {
				wp_mail( $u->user_email, 'New profiles that fit your search', "New profiles on " . get_bloginfo( 'name' ) . " match your saved search:\n\n" . implode( "\n", array_slice( $lines, 0, 15 ) ) . "\n\nSee all: " . home_url( '/?post_type=listing_type&s=' ) );
			}
		}
	}

	/* ================= 6. WhatsApp status card ================= */

	public static function profile_share( $id ) {
		echo '<p style="text-align:center;margin:14px 0"><a class="btn line" target="_blank" rel="noopener" href="' . esc_url( add_query_arg( 'mrt_status', (int) $id, home_url( '/' ) ) ) . '">Make a WhatsApp status image</a></p>';
	}

	private static function status_page( $id ) {
		$p = get_post( $id );
		if ( ! $p || self::CPT !== $p->post_type || 'publish' !== $p->post_status ) {
			wp_die( 'Profile not found.', '', array( 'response' => 404 ) );
		}
		$bits = array();
		$age  = (int) get_post_meta( $id, 'daage', true );
		if ( $age ) {
			$bits[] = $age . ' years';
		}
		foreach ( array( 'country', 'education', 'occupation' ) as $tx ) {
			$t = wp_get_object_terms( $id, $tx );
			if ( $t && ! is_wp_error( $t ) ) {
				$best = $t[0];
				foreach ( $t as $x ) {
					if ( $x->parent ) {
						$best = $x;
					}
				}
				$bits[] = $best->name;
			}
		}
		$blur  = (bool) apply_filters( 'mrt_blur', false, $id );
		$photo = ( ! $blur && function_exists( 'mrt_photo_source' ) ) ? ( mrt_photo_source( $id, 'large' )[1] ?? '' ) : '';
		$d     = array( 'name' => wp_specialchars_decode( get_the_title( $id ), ENT_QUOTES ), 'bits' => array_map( function ( $b0 ) { return wp_specialchars_decode( (string) $b0, ENT_QUOTES ); }, $bits ), 'photo' => $photo, 'site' => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ), 'url' => get_permalink( $id ), 'host' => wp_parse_url( home_url(), PHP_URL_HOST ) );
		nocache_headers();
		header( 'X-Robots-Tag: noindex, nofollow' );
		header( 'Content-Type: text/html; charset=utf-8' );
		echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Status image</title><style>body{margin:0;font-family:system-ui,sans-serif;background:#f3f1f6;text-align:center;padding:16px}canvas{max-width:100%;height:auto;max-height:70vh;border-radius:18px;box-shadow:0 10px 30px rgba(0,0,0,.2)}.b{display:inline-block;margin:10px 6px;padding:13px 22px;border-radius:99px;border:0;background:#e11d74;color:#fff;font-weight:700;font-size:1rem;text-decoration:none;cursor:pointer}.b.g{background:#16a34a}.b.l{background:#fff;color:#333;border:1px solid #ccc}</style></head><body><canvas id="c" width="1080" height="1920"></canvas><div><button class="b" id="sv">Save image</button><button class="b g" id="sh">Share on WhatsApp</button><a class="b l" href="' . esc_url( get_permalink( $id ) ) . '">Back to profile</a></div><script>var D=' . wp_json_encode( $d ) . ';'; // phpcs:ignore
		echo <<<'JS'
(function(){var c=document.getElementById('c'),x=c.getContext('2d');
function bg(){var g=x.createLinearGradient(0,0,1080,1920);g.addColorStop(0,'#b4195f');g.addColorStop(1,'#5b21b6');x.fillStyle=g;x.fillRect(0,0,1080,1920);x.fillStyle='rgba(255,255,255,.08)';x.beginPath();x.arc(950,150,320,0,7);x.fill();x.beginPath();x.arc(100,1800,380,0,7);x.fill()}
function t(s,px,y,sz,w,col,al){x.font=(w||'700')+' '+sz+'px system-ui,Arial,sans-serif';x.fillStyle=col||'#fff';x.textAlign=al||'center';x.fillText(s,px,y)}
function wrap(s,y,sz,mw){var w=s.split(' '),l='',ls=[];w.forEach(function(a){var n=l?l+' '+a:a;if(x.measureText(n).width>mw&&l){ls.push(l);l=a}else l=n});ls.push(l);ls.forEach(function(q,i){t(q,540,y+i*(sz*1.25),sz)});return y+ls.length*sz*1.25}
function fit(s,y,sz,mw,col){var q=sz;x.font='700 '+q+'px system-ui,Arial,sans-serif';while(q>30&&x.measureText(s).width>mw){q-=2;x.font='700 '+q+'px system-ui,Arial,sans-serif'}if(x.measureText(s).width>mw){while(s.length>4&&x.measureText(s+'...').width>mw)s=s.slice(0,-1);s+='...'}t(s,540,y,q,'700',col)}
function draw(img,fc){bg();fit(D.site,170,54,940,'#ffd9ec');t('Rishta proposal',540,250,42,'500','#fff');
 var cy=720,r=330;x.save();x.beginPath();x.arc(540,cy,r,0,7);x.closePath();x.clip();
 if(img){var cv=Math.max(2*r/img.width,2*r/img.height),s=cv,fx=.5,fy=img.height>img.width*1.05?.3:.4;if(fc&&fc.w){fx=fc.x/img.width;fy=fc.y/img.height;s=Math.min(Math.max(cv,(2*r*.46)/fc.w),cv*2.2)}var w=img.width*s,h=img.height*s,ox=540-fx*w,oy=cy-fy*h;ox=Math.min(540-r,Math.max(540+r-w,ox));oy=Math.min(cy-r,Math.max(cy+r-h,oy));x.drawImage(img,ox,oy,w,h)}else{x.fillStyle='#fff';x.fillRect(540-r,cy-r,2*r,2*r);x.fillStyle='#b4195f';x.font='700 260px system-ui';x.textAlign='center';x.fillText((D.name||'?').charAt(0).toUpperCase(),540,cy+90)}
 x.restore();x.lineWidth=14;x.strokeStyle='#fff';x.beginPath();x.arc(540,cy,r,0,7);x.stroke();
 x.font='800 84px system-ui';var y=wrap(D.name,1190,84,900);
 D.bits.forEach(function(b,i){t(b,540,y+30+i*70,52,'500','#fde7f3')});
 var by=1700;x.fillStyle='#fff';x.beginPath();x.roundRect?x.roundRect(190,by-70,700,110,55):x.rect(190,by-70,700,110);x.fill();t('See full profile at '+D.host,540,by,38,'700','#7c1d54')}
var im=new Image();im.crossOrigin='anonymous';im.onload=function(){draw(im);if(window.FaceDetector){try{new FaceDetector({fastMode:true,maxDetectedFaces:1}).detect(im).then(function(f){if(f&&f[0]){var b=f[0].boundingBox;draw(im,{x:b.x+b.width/2,y:b.y+b.height*.55,w:b.width})}}).catch(function(){})}catch(e){}}};im.onerror=function(){draw(null)};if(D.photo){im.src=D.photo}else draw(null);
function blob(cb){try{c.toBlob(cb,'image/png')}catch(e){cb(null)}}
document.getElementById('sv').onclick=function(){blob(function(b){if(!b){alert('Press and hold the image to save it.');return}var a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='rishta-status.png';document.body.appendChild(a);a.click();a.remove()})};
document.getElementById('sh').onclick=function(){blob(function(b){var txt='Rishta proposal on '+D.site+': '+D.url;if(b&&navigator.canShare&&navigator.canShare({files:[new File([b],'rishta.png',{type:'image/png'})]})){navigator.share({files:[new File([b],'rishta.png',{type:'image/png'})],text:txt}).catch(function(){})}else{window.open('https://wa.me/?text='+encodeURIComponent(txt),'_blank')}})};
})();</script></body></html>
JS;
		exit;
	}

	/* ================= 11 and 12. city and caste pages ================= */

	const UR_CITY = array(
		'lahore' => 'لاہور', 'karachi' => 'کراچی', 'islamabad' => 'اسلام آباد', 'rawalpindi' => 'راولپنڈی', 'faisalabad' => 'فیصل آباد', 'multan' => 'ملتان',
		'peshawar' => 'پشاور', 'quetta' => 'کوئٹہ', 'gujranwala' => 'گوجرانوالہ', 'sialkot' => 'سیالکوٹ', 'hyderabad' => 'حیدرآباد', 'sargodha' => 'سرگودھا',
		'bahawalpur' => 'بہاولپور', 'sukkur' => 'سکھر', 'larkana' => 'لاڑکانہ', 'mardan' => 'مردان', 'abbottabad' => 'ایبٹ آباد', 'gujrat' => 'گجرات',
		'sahiwal' => 'ساہیوال', 'jhelum' => 'جہلم', 'sheikhupura' => 'شیخوپورہ', 'kasur' => 'قصور', 'okara' => 'اوکاڑہ', 'rahim yar khan' => 'رحیم یار خان',
		'dubai' => 'دبئی', 'london' => 'لندن', 'riyadh' => 'ریاض', 'jeddah' => 'جدہ', 'manchester' => 'مانچسٹر', 'toronto' => 'ٹورنٹو',
	);

	private static function lands() {
		$c = get_transient( 'mrsh_lands' );
		if ( is_array( $c ) ) {
			return $c;
		}
		global $wpdb;
		$cities = array();
		$terms  = get_terms( array( 'taxonomy' => 'country', 'hide_empty' => true, 'orderby' => 'count', 'order' => 'DESC', 'number' => 80 ) );
		foreach ( is_wp_error( $terms ) ? array() : $terms as $t ) {
			if ( $t->parent && $t->count >= 1 ) {
				$cities[ $t->slug ] = array( $t->name, (int) $t->count );
			}
		}
		$castes = array();
		$rows   = $wpdb->get_results( "SELECT m.meta_value v, COUNT(*) n FROM {$wpdb->postmeta} m JOIN {$wpdb->posts} p ON p.ID=m.post_id WHERE m.meta_key='custom-20' AND m.meta_value<>'' AND p.post_type='listing_type' AND p.post_status='publish' GROUP BY m.meta_value HAVING n>=2 ORDER BY n DESC LIMIT 60" ); // phpcs:ignore
		foreach ( $rows as $r ) {
			if ( ! preg_match( '/^(others?|prefer)/i', $r->v ) ) {
				$castes[ sanitize_title( $r->v ) ] = array( $r->v, (int) $r->n );
			}
		}
		$out = array( 'city' => $cities, 'caste' => $castes );
		set_transient( 'mrsh_lands', $out, 6 * HOUR_IN_SECONDS );
		return $out;
	}

	public static function route() {
		if ( isset( $_GET['mrt_status'] ) ) { // phpcs:ignore
			self::status_page( absint( $_GET['mrt_status'] ) ); // phpcs:ignore
		}
		$kind = get_query_var( 'mrsh_land' );
		if ( ! $kind || ! self::opt( 'land_on' ) ) {
			return;
		}
		$ur    = (bool) get_query_var( 'mrsh_ur' );
		$slug  = sanitize_title( (string) get_query_var( 'mrsh_slug' ) );
		$lands = self::lands();
		$site  = get_bloginfo( 'name' );
		$base  = home_url( '/' );
		$self  = $ur ? 'ur/' : '';
		$other = $ur ? '' : 'ur/';
		$sub   = 'index' === $kind ? '' : $kind . '/' . $slug . '/';
		$name  = '';
		$q     = array( 'post_type' => self::CPT, 'post_status' => 'publish', 'posts_per_page' => 24, 'no_found_rows' => false );
		if ( 'city' === $kind && isset( $lands['city'][ $slug ] ) ) {
			$name        = $lands['city'][ $slug ][0];
			$q['tax_query'] = array( array( 'taxonomy' => 'country', 'field' => 'slug', 'terms' => $slug ) );
		} elseif ( 'caste' === $kind && isset( $lands['caste'][ $slug ] ) ) {
			$name        = $lands['caste'][ $slug ][0];
			$q['meta_query'] = array( array( 'key' => 'custom-20', 'value' => $name ) );
		} elseif ( 'index' !== $kind ) {
			global $wp_query;
			$wp_query->set_404();
			status_header( 404 );
			return;
		}
		$urn = $ur ? ( self::UR_CITY[ strtolower( $name ) ] ?? $name ) : $name;
		if ( 'index' === $kind ) {
			$title = $ur ? 'شہر اور ذات کے مطابق رشتے | ' . $site : 'Rishta by city and caste | ' . $site;
			$h1    = $ur ? 'شہر اور ذات کے مطابق رشتے' : 'Rishta by city and caste';
			$desc  = $ur ? 'اپنے شہر یا ذات کے مطابق مفت رشتے تلاش کریں۔ خاندانوں کے لیے محفوظ اور مفت۔' : 'Find free rishta profiles by your city or caste. Safe and free for Pakistani families.';
		} elseif ( 'city' === $kind ) {
			$title = $ur ? $urn . ' میں رشتے | مفت رشتہ پروفائل | ' . $site : 'Rishta in ' . $name . ' | Free marriage profiles | ' . $site;
			$h1    = $ur ? $urn . ' میں رشتے' : 'Rishta in ' . $name;
			$desc  = $ur ? $urn . ' کے لڑکے اور لڑکیوں کے رشتے دیکھیں۔ مفت پروفائل، تصدیق شدہ اراکین اور محفوظ رابطہ۔' : 'See rishta profiles of brides and grooms in ' . $name . '. Free profiles, verified members and safe contact for families.';
		} else {
			$title = $ur ? $name . ' رشتے | مفت رشتہ پروفائل | ' . $site : $name . ' rishta | Free marriage profiles | ' . $site;
			$h1    = $ur ? $name . ' رشتے' : $name . ' rishta';
			$desc  = $ur ? $name . ' خاندانوں کے لیے مفت رشتہ پروفائل۔ تصدیق شدہ اراکین اور محفوظ رابطہ۔' : 'Rishta profiles for ' . $name . ' families. Free to join, verified members and safe contact.';
		}
		$canon = $base . $self . 'rishta/' . $sub;
		$alt   = $base . $other . 'rishta/' . $sub;
		$posts = 'index' === $kind ? null : new WP_Query( $q );
		$noidx = ( 'index' !== $kind && ( ! $posts || ! $posts->have_posts() ) );
		if ( 'city' === $kind && ! $noidx ) { // a full written page for the same city already exists: let that page rank
			$cs = sanitize_title( (string) get_query_var( 'mrsh_slug' ) );
			if ( $cs && ( get_page_by_path( 'rishta-in-' . $cs ) || get_page_by_path( 'rishta-' . $cs ) ) ) {
				$noidx = true;
			}
		}
		add_filter( 'pre_get_document_title', function () use ( $title ) { return $title; }, 99 );
		if ( $ur ) {
			add_filter( 'language_attributes', function () { return 'lang="ur" dir="rtl"'; } );
		}
		add_action( 'wp_head', function () use ( $desc, $canon, $alt, $ur, $noidx, $h1, $posts ) {
			echo '<meta name="description" content="' . esc_attr( $desc ) . '"><link rel="canonical" href="' . esc_url( $canon ) . '">';
			echo '<link rel="alternate" hreflang="' . ( $ur ? 'ur' : 'en' ) . '" href="' . esc_url( $canon ) . '"><link rel="alternate" hreflang="' . ( $ur ? 'en' : 'ur' ) . '" href="' . esc_url( $alt ) . '">';
			if ( $noidx ) {
				echo '<meta name="robots" content="noindex,follow">';
			}
			$items = array();
			if ( $posts ) {
				foreach ( $posts->posts as $i => $pp ) {
					$items[] = array( '@type' => 'ListItem', 'position' => $i + 1, 'url' => get_permalink( $pp ) );
				}
			}
			echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@type' => 'CollectionPage', 'name' => $h1, 'description' => $desc, 'url' => $canon, 'inLanguage' => $ur ? 'ur' : 'en', 'mainEntity' => array( '@type' => 'ItemList', 'itemListElement' => $items ) ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>'; // phpcs:ignore
		}, 1 );
		global $wp_query;
		$wp_query->is_404 = false;
		status_header( 200 );
		get_header();
		if ( function_exists( 'mrt_page_hero' ) ) {
			mrt_page_hero( $h1, $desc, 'pin', $ur ? 'رشتے' : 'Rishta' );
		} else {
			echo '<h1>' . esc_html( $h1 ) . '</h1>';
		}
		echo '<main class="pg"' . ( $ur ? ' dir="rtl" style="text-align:right"' : '' ) . '><div class="wrap">';
		if ( 'index' === $kind ) {
			foreach ( array( 'city' => array( 'Cities', 'شہر' ), 'caste' => array( 'Castes', 'ذاتیں' ) ) as $k => $lab ) {
				echo '<h2 class="sec">' . esc_html( $ur ? $lab[1] : $lab[0] ) . '</h2><div class="row">';
				foreach ( $lands[ $k ] as $sl => $v ) {
					$nm = ( $ur && 'city' === $k ) ? ( self::UR_CITY[ strtolower( $v[0] ) ] ?? $v[0] ) : $v[0];
					echo '<a class="chip" href="' . esc_url( $base . $self . 'rishta/' . $k . '/' . $sl . '/' ) . '">' . esc_html( $nm ) . ' (' . (int) $v[1] . ')</a>';
				}
				echo '</div>';
			}
		} else {
			$intro = $ur
				? $h1 . ' ڈھونڈ رہے ہیں؟ یہاں ' . $urn . ' کے خاندانوں کے تازہ پروفائل ہیں۔ رجسٹریشن مفت ہے، فون نمبر نجی رہتے ہیں اور ہر پروفائل کی جانچ کی جاتی ہے۔ پروفائل کھول کر دلچسپی بھیجیں اور خاندان کے ساتھ فیصلہ کریں۔'
				: 'Looking for ' . $h1 . '? Here are recent profiles from ' . $name . ' families. Joining is free, phone numbers stay private and profiles are checked by our team. Open a profile, send interest and decide together with your family.';
			echo '<p style="max-width:760px">' . esc_html( $intro ) . '</p>';
			if ( $posts->have_posts() ) {
				echo '<div class="grid">';
				while ( $posts->have_posts() ) {
					$posts->the_post();
					if ( function_exists( 'mrt_card' ) ) {
						mrt_card();
					}
				}
				wp_reset_postdata();
				echo '</div>';
			} else {
				echo '<p>' . esc_html( $ur ? 'ابھی اس صفحے پر کوئی پروفائل نہیں۔' : 'No profiles here yet. Be the first to add one.' ) . '</p>';
			}
			echo '<p><a class="btn" href="' . esc_url( home_url( '/add-listing/' ) ) . '">' . esc_html( $ur ? 'مفت پروفائل بنائیں' : 'Create a free profile' ) . '</a> <a class="btn line" href="' . esc_url( $base . $self . 'rishta/' ) . '">' . esc_html( $ur ? 'تمام شہر اور ذاتیں' : 'All cities and castes' ) . '</a></p>';
		}
		echo '<p><a href="' . esc_url( $alt ) . '" hreflang="' . ( $ur ? 'en' : 'ur' ) . '">' . ( $ur ? 'English' : 'اردو' ) . '</a></p></div></main>';
		get_footer();
		exit;
	}
}
MRSH_Ideas::init();
