<?php
/**
 * Feature switches (3.101.146): one page with an On/Off toggle for each feature members or visitors can use.
 * Everything defaults to ON, so nothing changes until you switch something off. Off = the feature is really stopped
 * on the website (not only hidden) or its buttons are hidden. Settings pages stay open so you can switch it on again.
 * Option: mrsh_sw (key => 0/1).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Switch {

	const OPT  = 'mrsh_sw';
	const SLUG = 'mrsh-switch';

	/**
	 * key => array( group, label, help, kill-classes, kill-hooks, css selectors, shortcodes to blank )
	 * "kill" removes that class's callbacks from the listed hooks. "css" hides buttons on the website.
	 */
	public static function features() {
		return array(
			// Member tools.
			'agreement'  => array( 'Member tools', 'Agreement letters', 'The printable nikah/agreement letter tool in My account and the print page.', array( 'MRSH_Agreement' ), array( 'mrt_account_extra', 'admin_post_mrsh_agreement', 'template_redirect' ), array(), array() ),
			'chat'       => array( 'Member tools', 'Live chat updates', 'Messages refresh by themselves without reloading. Off = members reload the page to see new messages.', array( 'MRSH_Mem_Chat' ), array( 'wp_ajax_mrsh_chat_poll', 'wp_ajax_mrsh_unread' ), array(), array() ),
			'push'       => array( 'Member tools', 'Phone / browser push alerts', 'Members cannot turn on push notifications. Existing subscriptions stay saved.', array( 'MRSH_Mem_Push' ), array( 'wp_ajax_mrt_push_sub', 'wp_ajax_mrt_notif' ), array(), array() ),
			'family'     => array( 'Member tools', 'Family features', '"Managed by" label and the optional family copy of chats.', array( 'MRSH_Family' ), array( 'mrt_account_extra', 'mrt_profile_after', 'admin_post_mrsh_family', 'mrsh_msg_sent' ), array(), array() ),
			'photocheck' => array( 'Member tools', 'Photo check box', 'The photo check notes shown to members and on profiles.', array( 'MRSH_PhotoCheck' ), array( 'mrt_account_extra', 'mrt_profile_after' ), array(), array() ),
			'match'      => array( 'Member tools', 'Weekly match emails', 'The weekly email with new matches. Match scores and the Matches page stay.', array( 'MRSH_Match' ), array( 'mrsh_weekly_matches' ), array(), array() ),
			'delacct'    => array( 'Member tools', 'Delete my account', 'Lets a member delete their own account (password needed) from My account.', array( 'MRSH_Delacct' ), array( 'mrt_account_extra', 'admin_post_mrsh_delacct' ), array(), array() ),
			'emailchange' => array( 'Member tools', 'Members can change their email', 'Shows the Change email box in My account > Settings. Off (the default) = the email is fixed and only your team can change it.', array(), array(), array(), array() ),
			'pay'        => array( 'Member tools', 'Pay buttons on plans', 'The "Pay with Easypaisa / JazzCash" buttons on the Membership page.', array( 'MRSH_Pay' ), array( 'mrt_plan_pay' ), array(), array() ),
			'geoip'      => array( 'Admin tools', 'Place of each IP in the Activity log', 'Shows city and country next to every IP in the Activity log, using the free ipwho.is service. The IP address is sent to that service. Off = nothing is sent.', array(), array(), array(), array() ),
			'guard'      => array( 'Admin tools', 'Warn about odd logins', 'Flags a login from a new country and an IP used by many accounts. Shows in the Activity log.', array(), array(), array(), array() ),
			'block'      => array( 'Admin tools', 'Block by IP and country', 'Uses the block list in Security and places. Off = nobody is blocked, the list is kept.', array(), array(), array(), array() ),
			'landing'     => array( 'Admin tools', 'Gulf growth pages', 'Publishes guide pages for Pakistanis in Qatar, Bahrain, Oman, Kuwait and Gulf cities (two a day by the Autopilot, or by button).', array(), array(), array(), array() ),
			'autopilot'   => array( 'Admin tools', 'AI Autopilot (full support mode)', 'Lets the AI and robots act on their own: answer safe tickets, send password-reset help, apply keyword phrases and ping search engines hourly. Everything is logged on the AI Autopilot page. Money, legal, safety and deleting members always go to a human.', array(), array(), array(), array() ),
			'concierge'   => array( 'Admin tools', 'Ticket concierge robot', 'Looks after new support tickets every 5 minutes. A request for a Bronze / Silver / Gold package (English, Roman Urdu or Urdu) gets the package at once while plans are free (valid 180 days, member told by email). Simple questions are answered by the AI. Anything it cannot or should not handle (money, safety, paid packages, unclear) is set to In progress and the member is told it is waiting for a human reply. Every step is written in the ticket.', array(), array(), array(), array() ),
			'storyhelper' => array( 'Member tools', 'Write-for-me helpers', 'Two helpers. (1) A button under the Your story box on the profile form, and (2) a Help me write button in the chat with ready messages (hello, interest, families talk, polite no, thank you). The first writes a short first draft from the answers the member already chose (English, Urdu or Roman Urdu). Uses the free AI when it is on, and a plain template when it is not. The member reads and edits it. Six drafts per member per day. Invents nothing, no contact details.', array(), array(), array(), array() ),
			'agentready' => array( 'Admin tools', 'Agent-ready site', 'Makes the site easy for AI assistants: Content-Signal line in robots.txt, dates in the sitemap, a Markdown copy of public pages, small read-only tools for in-browser agents and a public read-only MCP endpoint with its server card. Only public information is used; no member data.', array(), array(), array(), array() ),
			'applite'    => array( 'Admin tools', 'Lite installed app', 'The installed phone app loads a lighter page: no Google Analytics / Ads tags, Ahrefs, Google One Tap, page pre-loading or install tiles. Normal browsers and Google search are not changed.', array(), array(), array(), array() ),
			'daily'      => array( 'Admin tools', 'Daily summary email', 'One email to the admin every morning with new members, tickets, flags and logins from abroad.', array(), array(), array(), array() ),
			'tk_auto'    => array( 'Admin tools', 'Tickets: serious words become high priority', 'A new ticket with words like fraud, police, threat or refund is marked high priority.', array(), array(), array(), array() ),
			'mydata'     => array( 'Member tools', 'My data card (printable copy)', 'The "My data" card in My account. Members open a clean page of their profile and account details and print it. OFF by default.', array(), array(), array(), array() ),
			'pause'      => array( 'Member tools', 'Pause profile / take a break', 'The "Pause profile" button and the "Take a break or close your search" card in My account. OFF by default. A member whose profile is already paused still sees how to bring it back.', array(), array(), array(), array() ),
			'payproof'   => array( 'Member tools', 'Send payment proof box', 'The "Send payment proof" box in My account. OFF by default: turn it on when you start charging for plans. A member who already sent a proof still sees its status.', array(), array(), array(), array() ),
			// Login and sign up.
			'social'     => array( 'Login and sign up', 'Login with Google / Facebook', 'The social login buttons on the login and register pages, and the sign-in route itself.', array( 'MRSH_Mem_Social' ), array( 'init', 'login_form', 'register_form', 'login_form_bottom', 'login_message' ), array(), array( 'mrsh_social_login' ) ),
			// Profile page buttons (hidden with CSS).
			'b_wink'     => array( 'Profile page buttons', 'Wink and Miss buttons', 'Hides Wink and Miss on profiles.', array(), array(), array( '[data-act="wink"]', '[data-act="miss"]' ), array() ),
			'b_hit'      => array( 'Profile page buttons', 'Hit button', 'Hides Hit on profiles.', array(), array(), array( '[data-act="hit"]' ), array() ),
			'b_gift'     => array( 'Profile page buttons', 'Gifts', 'Hides the Gift button and the gift tray.', array(), array(), array( '[data-act="gifttray"]', '[data-act="gift"]', '#mrt-gifts' ), array() ),
			'b_fav'      => array( 'Profile page buttons', 'Shortlist heart', 'Hides the Shortlist button and the heart on profile cards.', array(), array(), array( '[data-act="fav"]', '.hrt' ), array() ),
			'b_share'    => array( 'Profile page buttons', 'Share buttons', 'Hides WhatsApp, Copy link, Facebook, X, Pinterest and LinkedIn on profiles.', array(), array(), array( '.acts2 [data-share]', '.acts2 a[href*="wa.me"]', '.acts2 a[href*="whatsapp"]', '.acts2 a[href*="facebook.com/sharer"]', '.acts2 a[href*="twitter.com/intent"]', '.acts2 a[href*="pinterest.com/pin"]', '.acts2 a[href*="linkedin.com/sharing"]' ), array() ),
			'b_print'    => array( 'Profile page buttons', 'Print biodata', 'Hides Print biodata on profiles.', array(), array(), array( '.acts2 button[onclick*="print"]' ), array() ),
			'b_report'   => array( 'Profile page buttons', 'Report and Block', 'Hides Report and Block on profiles. Not advised: members need a way to report abuse.', array(), array(), array( '.acts2 [data-act="report"]', '.acts2 [data-act="block"]' ), array() ),
			'b_phone'    => array( 'Profile page buttons', 'Ask for phone number', 'Hides the phone request button.', array(), array(), array( '[data-act="phonereq"]' ), array() ),
		);
	}

	public static function on( $k ) {
		$o = get_option( self::OPT, array() );
		if ( in_array( $k, array( 'mydata', 'pause', 'payproof', 'emailchange' ), true ) ) { // these start switched off
			return is_array( $o ) && ! empty( $o[ $k ] );
		}
		return ! ( is_array( $o ) && isset( $o[ $k ] ) && ! $o[ $k ] );
	}

	public static function init() {
		add_action( 'init', array( __CLASS__, 'enforce' ), 0 );
		add_action( 'wp_head', array( __CLASS__, 'css' ), 99 );
		if ( is_admin() ) {
			add_action( 'admin_menu', array( __CLASS__, 'menu' ), 17 );
			add_action( 'admin_post_mrsh_sw_save', array( __CLASS__, 'save' ) );
		}
	}

	/** Remove the callbacks of every switched-off feature. */
	public static function enforce() {
		global $wp_filter;
		foreach ( self::features() as $k => $f ) {
			if ( self::on( $k ) ) {
				continue;
			}
			foreach ( $f[3] as $cls ) {
				foreach ( $f[4] as $hook ) {
					if ( empty( $wp_filter[ $hook ] ) || ! is_object( $wp_filter[ $hook ] ) || empty( $wp_filter[ $hook ]->callbacks ) ) {
						continue;
					}
					foreach ( $wp_filter[ $hook ]->callbacks as $pri => $cbs ) {
						foreach ( $cbs as $id => $cb ) {
							$fn = $cb['function'];
							if ( is_array( $fn ) && isset( $fn[0] ) && ( ( is_string( $fn[0] ) && $fn[0] === $cls ) || ( is_object( $fn[0] ) && get_class( $fn[0] ) === $cls ) ) ) {
								remove_filter( $hook, $fn, $pri );
							}
						}
					}
				}
			}
			foreach ( $f[6] as $tag ) {
				add_shortcode( $tag, '__return_empty_string' );
			}
		}
	}

	/** Hide buttons with CSS on the website. */
	public static function css() {
		$sel = array();
		foreach ( self::features() as $k => $f ) {
			if ( ! self::on( $k ) && $f[5] ) {
				$sel = array_merge( $sel, $f[5] );
			}
		}
		if ( $sel ) {
			echo '<style id="mrsh-sw-css">' . esc_html( implode( ',', $sel ) ) . '{display:none!important}</style>' . "\n";
		}
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Feature switches', 'Feature switches', 'manage_options', self::SLUG, array( __CLASS__, 'page' ) );
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_sw' );
		$p = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.NonceVerification
		$o = array();
		foreach ( self::features() as $k => $f ) {
			$o[ $k ] = empty( $p[ 'sw_' . $k ] ) ? 0 : 1;
		}
		update_option( self::OPT, $o, false );
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&ok=1' ) );
		exit;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		MRSH_Boost::ui_open( 'Feature switches', 'Switch features off for a while and on again later. Everything is on until you change it. Press Save at the bottom.', 'g-blue', 'M4 6h10v2H4zm0 5h16v2H4zm0 5h10v2H4zM17 5a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM8 15a2 2 0 1 1 0 4 2 2 0 0 1 0-4z' );
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			MRSH_Boost::ui_ok( 'Saved. Clear the LiteSpeed cache so visitors see the change now.' );
		}
		$icons = array(
			'Member tools'         => 'M12 12a5 5 0 1 0 0-10 5 5 0 0 0 0 10zm0 2c-4 0-8 2-8 5v3h16v-3c0-3-4-5-8-5z',
			'Login and sign up'    => 'M12 2a5 5 0 0 1 5 5v3h1a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h1V7a5 5 0 0 1 5-5zm0 2a3 3 0 0 0-3 3v3h6V7a3 3 0 0 0-3-3z',
			'Admin tools'          => 'M12 2l9 4v6c0 5-4 9-9 10-5-1-9-5-9-10V6l9-4z',
			'Profile page buttons' => 'M12 21s-8-5.2-8-11a4.5 4.5 0 0 1 8-2.8A4.5 4.5 0 0 1 20 10c0 5.8-8 11-8 11z',
		);
		$by = array();
		$n_on = 0;
		$n_all = 0;
		foreach ( self::features() as $k => $f ) {
			$by[ $f[0] ][ $k ] = $f;
			$n_all++;
			if ( self::on( $k ) ) {
				$n_on++;
			}
		}
		echo '<style>
.sw{--m:#6e1230;--g:#12a375;--l:#e7e7ee;max-width:980px}
.sw-top{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin:4px 0 16px}
.sw-top input[type=search]{flex:1;min-width:200px;border:1px solid var(--l);border-radius:12px;padding:10px 14px;font-size:14px;box-shadow:0 1px 2px rgba(0,0,0,.04)}
.sw-top .b{border:1px solid var(--l);background:#fff;border-radius:12px;padding:9px 14px;font-weight:600;cursor:pointer;color:#333}
.sw-top .b:hover{border-color:var(--m);color:var(--m)}
.sw-sum{display:inline-flex;gap:6px;align-items:center;background:#fff;border:1px solid var(--l);border-radius:999px;padding:7px 14px;font-weight:600}
.sw-sum i{width:9px;height:9px;border-radius:50%;background:var(--g)}
.sw-g{background:#fff;border:1px solid var(--l);border-radius:18px;padding:18px 18px 8px;margin:0 0 16px;box-shadow:0 4px 18px rgba(30,20,60,.05)}
.sw-g h2{display:flex;align-items:center;gap:10px;margin:0 0 10px;font-size:16px;padding:0}
.sw-g h2 .ic{width:34px;height:34px;border-radius:11px;display:grid;place-items:center;background:linear-gradient(135deg,#9b1b4b,var(--m));flex:none}
.sw-g h2 .ic svg{width:18px;height:18px;fill:#fff}
.sw-g h2 small{margin-left:auto;color:#777;font-weight:600;font-size:12px}
.sw-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(290px,1fr));gap:12px;padding-bottom:10px}
.sw-i{display:flex;align-items:flex-start;gap:12px;border:1px solid var(--l);border-radius:14px;padding:14px;background:#fcfcfe;transition:.15s}
.sw-i.off{background:#fff5f6;border-color:#f3c9d0}
.sw-i>div{flex:1;min-width:0}
.sw-i b{display:block;font-size:14px;margin-bottom:3px}
.sw-i .d{display:block;color:#666;font-size:12.5px;line-height:1.45}
.sw-i .st{display:inline-block;margin-top:8px;font-size:11px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;padding:2px 9px;border-radius:999px;background:#e3f7ef;color:#0b7a56}
.sw-i.off .st{background:#fde3e7;color:#a3122e}
.sw-t{position:relative;width:50px;height:28px;flex:none;margin-top:2px}
.sw-t input{position:absolute;inset:0;width:100%;height:100%;opacity:0;margin:0;cursor:pointer;z-index:2}
.sw-t i{position:absolute;inset:0;background:#c9c9d3;border-radius:28px;transition:.2s}
.sw-t i:after{content:"";position:absolute;left:3px;top:3px;width:22px;height:22px;background:#fff;border-radius:50%;box-shadow:0 1px 3px rgba(0,0,0,.3);transition:.2s}
.sw-t input:checked+i{background:var(--g)}
.sw-t input:checked+i:after{left:25px}
.sw-t input:focus-visible+i{outline:3px solid #b9c7ff}
.sw-bar{position:sticky;bottom:0;z-index:5;display:flex;flex-wrap:wrap;gap:10px;align-items:center;background:rgba(255,255,255,.92);backdrop-filter:blur(8px);border:1px solid var(--l);border-radius:16px;padding:12px 14px;box-shadow:0 -4px 20px rgba(0,0,0,.08)}
.sw-bar .save{background:linear-gradient(135deg,#9b1b4b,var(--m));color:#fff;border:0;border-radius:12px;padding:11px 22px;font-weight:700;font-size:14px;cursor:pointer}
.sw-bar a{font-weight:600;text-decoration:none;color:var(--m)}
.sw-bar .hint{color:#777;font-size:12.5px;margin-left:auto}
@media(max-width:600px){.sw-grid{grid-template-columns:1fr}.sw-bar .hint{display:none}}
</style><div class="sw"><form method="post" id="sw-f" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_sw_save">';
		wp_nonce_field( 'mrsh_sw' );
		echo '<div class="sw-top"><input type="search" id="sw-q" placeholder="Search a feature, e.g. gift, login, share"><span class="sw-sum"><i></i><span id="sw-n">' . (int) $n_on . ' of ' . (int) $n_all . ' on</span></span><button type="button" class="b" id="sw-all">Turn all on</button><button type="button" class="b" id="sw-none">Turn all off</button></div>';
		foreach ( $by as $g => $rows ) {
			echo '<section class="sw-g"><h2><span class="ic"><svg viewBox="0 0 24 24"><path d="' . esc_attr( $icons[ $g ] ?? $icons['Member tools'] ) . '"/></svg></span>' . esc_html( $g ) . '<small>' . count( $rows ) . ( 1 === count( $rows ) ? ' switch' : ' switches' ) . '</small></h2><div class="sw-grid">';
			foreach ( $rows as $k => $f ) {
				$on = self::on( $k );
				echo '<div class="sw-i' . ( $on ? '' : ' off' ) . '" data-t="' . esc_attr( strtolower( $f[1] . ' ' . $f[2] ) ) . '"><div><b>' . esc_html( $f[1] ) . '</b><span class="d">' . esc_html( $f[2] ) . '</span><span class="st">' . ( $on ? 'On' : 'Off' ) . '</span></div><label class="sw-t"><input type="checkbox" name="sw_' . esc_attr( $k ) . '" value="1"' . checked( $on, true, false ) . '><i></i></label></div>';
			}
			echo '</div></section>';
		}
		echo '<div class="sw-bar"><button class="save">Save switches</button><a href="' . esc_url( admin_url( 'admin.php?page=mrsh-settings' ) ) . '">All settings</a><a href="' . esc_url( admin_url( 'admin.php?page=mrsh-boost' ) ) . '">Growth boosters</a><span class="hint">Changes apply after you press Save.</span></div></form></div>';
		echo '<script>(function(){var f=document.getElementById("sw-f"),n=document.getElementById("sw-n");function up(){var a=f.querySelectorAll(".sw-t input"),o=0;a.forEach(function(c){var it=c.closest(".sw-i");it.classList.toggle("off",!c.checked);it.querySelector(".st").textContent=c.checked?"On":"Off";if(c.checked)o++});n.textContent=o+" of "+a.length+" on"}f.addEventListener("change",up);document.getElementById("sw-all").onclick=function(){f.querySelectorAll(".sw-t input").forEach(function(c){c.checked=true});up()};document.getElementById("sw-none").onclick=function(){f.querySelectorAll(".sw-t input").forEach(function(c){c.checked=false});up()};document.getElementById("sw-q").addEventListener("input",function(){var q=this.value.toLowerCase();f.querySelectorAll(".sw-i").forEach(function(i){i.style.display=i.dataset.t.indexOf(q)<0?"none":""});f.querySelectorAll(".sw-g").forEach(function(g){g.style.display=g.querySelector(".sw-i:not([style*=none])")?"":"none"})})})();</script></div>';
	}
}
MRSH_Switch::init();
