<?php
/** Site Settings (tabs): everything about how the website looks and what it says, kept under My Rishta SEO. Option: mrsh_site. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Site {

	public static function defaults() {
		return array(
			'logo' => '', 'brand' => '', 'c1' => '', 'c2' => '',
			'ann_on' => 0, 'ann_text' => '', 'ann_link' => '',
			'hero_title' => '', 'hero_text' => '', 'hero_search' => 1,
			's_stats' => 0, 's_browse' => 0, 's_featured' => 1, 's_brides' => 1, 's_grooms' => 1, 's_how' => 1, 's_plans' => 1, 's_stories' => 1, 's_faq' => 1, 's_cta' => 1,
			'per_row' => 4, 'per_page' => 24,
			'about' => '', 'phone' => '', 'email' => '', 'address' => '', 'whatsapp' => '',
			'fb' => '', 'ig' => '', 'yt' => '', 'tt' => '', 'x' => '',
			'photo_host' => '', 'wa_float' => 1, 'tidy_menu' => 1, 'stories' => '', 'faq' => '', 'plans' => '', 'payinfo' => '', 'footer_note' => '',
		);
	}

	public static function get( $k = null ) {
		static $o = null;
		if ( null === $o ) {
			$s = get_option( 'mrsh_site', array() );
			$o = array_merge( self::defaults(), is_array( $s ) ? $s : array() );
		}
		return null === $k ? $o : ( $o[ $k ] ?? '' );
	}

	public static function init() {
		// One time: numbers strip and Browse block are off by default (turn them on in Site Settings > Home page).
		if ( '1' !== get_option( 'mrsh_site_v' ) ) {
			$o = get_option( 'mrsh_site', array() );
			$o = is_array( $o ) ? $o : array();
			$o['s_stats']  = 0;
			$o['s_browse'] = 0;
			update_option( 'mrsh_site', $o, false );
			update_option( 'mrsh_site_v', '1', false );
		}
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 23 );
		add_action( 'admin_post_mrt_site_save', array( __CLASS__, 'save' ) );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Site Settings', 'Site Settings', 'manage_options', 'mrsh-site', array( __CLASS__, 'page' ) );
	}

	private static function tabs() {
		return array( 'design' => 'Look', 'home' => 'Home page', 'footer' => 'Footer and contact', 'content' => 'Stories, FAQ and plans', 'hub' => 'All settings' );
	}

	private static function f( $name, $label, $type = 'text', $help = '' ) {
		$v = self::get( $name );
		echo '<tr><th><label for="f_' . esc_attr( $name ) . '">' . esc_html( $label ) . '</label></th><td>';
		if ( 'check' === $type ) {
			echo '<label><input type="checkbox" id="f_' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '" value="1"' . checked( (int) $v, 1, false ) . '> On</label>';
		} elseif ( 'area' === $type ) {
			echo '<textarea id="f_' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '" rows="5" class="large-text">' . esc_textarea( $v ) . '</textarea>';
		} elseif ( 'num' === $type ) {
			echo '<input type="number" id="f_' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '" value="' . (int) $v . '" min="1" max="100">';
		} elseif ( 'color' === $type ) {
			echo '<input type="text" id="f_' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $v ) . '" placeholder="#0f7a55" maxlength="7" size="9">';
		} else {
			echo '<input type="text" id="f_' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $v ) . '" class="regular-text">';
		}
		echo $help ? ' <span class="description">' . esc_html( $help ) . '</span>' : '';
		echo '</td></tr>';
	}

	public static function page() {
		$tab = isset( $_GET['tab'] ) && isset( self::tabs()[ $_GET['tab'] ] ) ? sanitize_key( $_GET['tab'] ) : 'design'; // phpcs:ignore
		echo '<div class="wrap"><h1>Site Settings</h1>';
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success"><p>Saved. If you use LiteSpeed Cache, click Purge All.</p></div>';
		}
		echo '<div class="mrt-sub">';
		foreach ( self::tabs() as $k => $l ) {
			echo '<a class="' . ( $k === $tab ? 'on' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=mrsh-site&tab=' . $k ) ) . '">' . esc_html( $l ) . '</a>';
		}
		echo '</div>';
		if ( 'hub' === $tab ) {
			self::hub();
			echo '</div>';
			return;
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrt_site_save"><input type="hidden" name="tab" value="' . esc_attr( $tab ) . '">';
		wp_nonce_field( 'mrt_site_save' );
		echo '<table class="form-table">';
		if ( 'design' === $tab ) {
			self::f( 'brand', 'Site name in the header', 'text', 'Leave empty to use the site title.' );
			self::f( 'logo', 'Logo image address', 'text', 'Paste a link from Media Library. Small square image works best.' );
			self::f( 'c1', 'Main colour (optional)', 'color', 'Overrides the chosen interface style. Example #0f7a55' );
			self::f( 'c2', 'Second colour (optional)', 'color', 'Example #b8860b' );
			self::f( 'per_row', 'Profiles per row on computer', 'num', '3 to 6. Four looks best.' );
			self::f( 'per_page', 'Profiles per page in search', 'num' );
			self::f( 'ann_on', 'Announcement bar', 'check' );
			self::f( 'ann_text', 'Announcement text', 'text', 'Example: Free for all Pakistani families' );
			self::f( 'ann_link', 'Announcement link (optional)' );
			self::f( 'tidy_menu', 'Tidy the WordPress menu', 'check', 'Groups post types into Site content and other plugins into Plugins and tools.' );
			self::f( 'photo_host', 'Borrow missing photos from this site', 'text', 'For test copies. Leave empty for automatic: on test.myrishta.pk missing photos are shown from myrishta.pk. Type off to turn it off.' );
			self::f( 'wa_float', 'WhatsApp chat button on every page', 'check', 'Uses the WhatsApp number from Footer and contact.' );
			echo '<tr><th>Interface style</th><td><a href="' . esc_url( admin_url( 'admin.php?page=mrsh-mem' ) ) . '">Choose in Member settings</a></td></tr>';
		} elseif ( 'home' === $tab ) {
			self::f( 'hero_title', 'Main heading', 'text', 'Empty = the SEO home title.' );
			self::f( 'hero_text', 'Text under the heading', 'area' );
			foreach ( array( 'hero_search' => 'Search box in the header', 's_stats' => 'Numbers (profiles, new this week)', 's_browse' => 'Browse by city, education, profession', 's_featured' => 'Featured profiles', 's_brides' => 'New brides', 's_grooms' => 'New grooms', 's_how' => 'How it works', 's_plans' => 'Membership plans', 's_stories' => 'Success stories', 's_faq' => 'Questions and answers', 's_cta' => 'Join banner' ) as $k => $l ) {
				self::f( $k, 'Show: ' . $l, 'check' );
			}
		} elseif ( 'footer' === $tab ) {
			self::f( 'about', 'About text in footer', 'area' );
			self::f( 'phone', 'Phone' );
			self::f( 'email', 'Email' );
			self::f( 'address', 'Address' );
			self::f( 'whatsapp', 'WhatsApp number', 'text', 'With country code, no plus. Example 923001234567' );
			self::f( 'fb', 'Facebook link' );
			self::f( 'ig', 'Instagram link' );
			self::f( 'yt', 'YouTube link' );
			self::f( 'tt', 'TikTok link' );
			self::f( 'x', 'X (Twitter) link' );
			self::f( 'footer_note', 'Small note at the bottom', 'text', 'Example: Never send money to anyone you meet online.' );
		} else {
			self::f( 'stories', 'Success stories', 'area', 'One per line: Name, City | what they say. Only add real stories with permission.' );
			self::f( 'payinfo', 'How to pay for a paid plan', 'area', 'Shown on the Memberships page and in the plan request email. For example: Easypaisa / JazzCash 03xx-xxxxxxx (account name), or bank details. Members pay you directly and you assign the plan in Members.' );
			self::f( 'plans', 'Membership options', 'area', 'One per line: Name | Price | feature; feature; feature. Example: Free | Free | Create profile; Send interest; Messages. Add a colour as a fourth part, for example Gold | Rs 2000 | Priority; Badge | #e0a800. The first plan is the free one and gets no badge. Leave empty to use the built-in Free, Bronze, Silver and Gold plans (prices are examples, change them here). Paid plans are shown as information; members contact you to upgrade.' );
			self::f( 'faq', 'Questions and answers', 'area', 'One per line: Question? | Answer. Also added to Google as FAQ.' );
		}
		echo '</table><p><button class="button button-primary">Save</button></p></form></div>';
	}

	private static function hub() {
		$items = array(
			'myrishta-seo' => 'SEO dashboard', 'mrsh-site' => 'Site Settings (this page)', 'mrsh-mem' => 'Member settings, limits, photos, interface style', 'mrsh-keys' => 'Website keys (reCAPTCHA, Google login, Maps)',
			'mrsh-overview' => 'Overview and approvals', 'mrsh-profiles' => 'Profiles', 'mrsh-users' => 'Members (ban, last seen)', 'mrsh-msgs' => 'Messages', 'mrsh-orders' => 'Orders', 'mrsh-matchdesk' => 'Match Desk', 'mrsh-theme' => 'Theme and App installer',
		);
		echo '<p>Everything for the website is in this menu.</p><ul style="list-style:disc;margin-left:20px">';
		foreach ( $items as $slug => $l ) {
			echo '<li><a href="' . esc_url( admin_url( 'admin.php?page=' . $slug ) ) . '">' . esc_html( $l ) . '</a></li>';
		}
		echo '</ul><p>Backup and restore buttons are on the SEO dashboard.</p>';
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrt_site_save' );
		$tab = isset( $_POST['tab'] ) && isset( self::tabs()[ $_POST['tab'] ] ) ? sanitize_key( $_POST['tab'] ) : 'design';
		$cur = get_option( 'mrsh_site', array() );
		$cur = is_array( $cur ) ? $cur : array();
		$map = array(
			'design'  => array( 'text' => array( 'brand', 'ann_text', 'photo_host' ), 'url' => array( 'logo', 'ann_link' ), 'color' => array( 'c1', 'c2' ), 'num' => array( 'per_row', 'per_page' ), 'check' => array( 'ann_on', 'wa_float', 'tidy_menu' ) ),
			'home'    => array( 'text' => array( 'hero_title' ), 'area' => array( 'hero_text' ), 'check' => array( 'hero_search', 's_stats', 's_browse', 's_featured', 's_brides', 's_grooms', 's_how', 's_plans', 's_stories', 's_faq', 's_cta' ) ),
			'footer'  => array( 'text' => array( 'phone', 'email', 'address', 'whatsapp', 'footer_note' ), 'area' => array( 'about' ), 'url' => array( 'fb', 'ig', 'yt', 'tt', 'x' ) ),
			'content' => array( 'area' => array( 'stories', 'faq', 'plans', 'payinfo' ) ),
		);
		foreach ( $map[ $tab ] as $type => $keys ) {
			foreach ( $keys as $k ) {
				$raw = isset( $_POST[ $k ] ) ? wp_unslash( $_POST[ $k ] ) : '';
				if ( 'check' === $type ) {
					$cur[ $k ] = empty( $_POST[ $k ] ) ? 0 : 1;
				} elseif ( 'num' === $type ) {
					$cur[ $k ] = max( 1, min( 100, absint( $raw ) ) );
				} elseif ( 'url' === $type ) {
					$cur[ $k ] = esc_url_raw( $raw );
				} elseif ( 'color' === $type ) {
					$cur[ $k ] = preg_match( '/^#[0-9a-fA-F]{6}$/', trim( $raw ) ) ? trim( $raw ) : '';
				} elseif ( 'area' === $type ) {
					$cur[ $k ] = sanitize_textarea_field( $raw );
				} else {
					$cur[ $k ] = sanitize_text_field( $raw );
				}
			}
		}
		update_option( 'mrsh_site', $cur, false );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-site&tab=' . $tab . '&ok=1' ) );
		exit;
	}
}
MRSH_Site::init();
