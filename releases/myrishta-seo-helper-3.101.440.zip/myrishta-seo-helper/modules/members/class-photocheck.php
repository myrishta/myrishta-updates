<?php
/**
 * Picture and social checks.
 * 1. Members add an Instagram / Facebook link on My account. The admin opens it and approves: the profile gets a "Social profile checked" badge (the link itself is never shown publicly).
 * 2. Admin page "Photo check": every profile photo with one-click Google Lens, TinEye and Bing reverse image search links.
 * 3. Duplicate photo finder: the same picture file used on two profiles is flagged (file fingerprint, no outside service).
 * 4. "Signed in with Facebook / Google" badge for members who used social login.
 * Nothing is sent to any outside service; the search links just open the search sites in a new tab.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_PhotoCheck {

	const SLUG = 'mrsh-photocheck';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 29 );
		add_action( 'admin_post_mrsh_pc_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_mrsh_pc_act', array( __CLASS__, 'act' ) );
		add_action( 'mrt_account_extra', array( __CLASS__, 'account' ), 46 );
		add_action( 'mrt_profile_after', array( __CLASS__, 'profile' ), 20 );
		add_action( 'save_post_listing_type', array( __CLASS__, 'hash_post' ), 30 );
	}

	/* ---------- link cleaning ---------- */

	private static function clean( $v, $hosts ) {
		$v = trim( (string) $v );
		if ( '' === $v ) {
			return '';
		}
		if ( ! preg_match( '#^https?://#i', $v ) ) {
			$v = 'https://' . ltrim( $v, '/@' );
		}
		$u = esc_url_raw( $v );
		$h = strtolower( (string) wp_parse_url( $u, PHP_URL_HOST ) );
		$h = preg_replace( '/^(www|m|web)\./', '', $h );
		return ( $u && in_array( $h, $hosts, true ) ) ? $u : '';
	}

	private static function ig( $v ) {
		$v = trim( (string) $v );
		if ( preg_match( '/^@?[A-Za-z0-9._]{2,30}$/', $v ) ) { // plain username
			return 'https://www.instagram.com/' . ltrim( $v, '@' ) . '/';
		}
		return self::clean( $v, array( 'instagram.com', 'instagr.am' ) );
	}

	/* ---------- member side ---------- */

	public static function save() {
		$uid = get_current_user_id();
		if ( ! $uid || ! check_admin_referer( 'mrsh_pc_save' ) ) {
			wp_die( 'Not allowed.' );
		}
		$ig = self::ig( wp_unslash( $_POST['ig'] ?? '' ) ); // phpcs:ignore
		$fb = self::clean( wp_unslash( $_POST['fbu'] ?? '' ), array( 'facebook.com', 'fb.com', 'fb.me' ) ); // phpcs:ignore
		if ( $ig !== (string) get_user_meta( $uid, 'mrt_ig', true ) || $fb !== (string) get_user_meta( $uid, 'mrt_fbu', true ) ) {
			delete_user_meta( $uid, 'mrt_soc_ok' ); // changed links need a new check
		}
		update_user_meta( $uid, 'mrt_ig', $ig );
		update_user_meta( $uid, 'mrt_fbu', $fb );
		if ( ( $ig || $fb ) && ! get_user_meta( $uid, 'mrt_soc_ok', true ) ) {
			update_user_meta( $uid, 'mrt_soc_t', time() );
		}
		wp_safe_redirect( add_query_arg( 'm2', 'saved', home_url( '/my-account/' ) ) );
		exit;
	}

	public static function account( $uid ) {
		if ( ! $uid ) {
			return;
		}
		$ig = (string) get_user_meta( $uid, 'mrt_ig', true );
		$fb = (string) get_user_meta( $uid, 'mrt_fbu', true );
		$ok = (bool) get_user_meta( $uid, 'mrt_soc_ok', true );
		echo '<div class="wrap narrow"><div class="box"><h3>Social profile check</h3>';
		if ( $ok ) {
			echo '<p>&#10003; Your social profile is checked. A "Social profile checked" badge shows on your profile.</p>';
		} elseif ( $ig || $fb ) {
			echo '<p class="mut">Thank you. We will open your link and check that the pictures match.</p>';
		} else {
			echo '<p class="mut">Add your Instagram or Facebook link. We check that your pictures are really yours and give you a badge. Your link is never shown to other members.</p>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_pc_save">' . wp_nonce_field( 'mrsh_pc_save', '_wpnonce', true, false )
			. '<p><label>Instagram username or link<br><input type="text" name="ig" maxlength="150" value="' . esc_attr( $ig ) . '" placeholder="@username" style="width:100%"></label></p>'
			. '<p><label>Facebook profile link<br><input type="text" name="fbu" maxlength="200" value="' . esc_attr( $fb ) . '" placeholder="https://facebook.com/your.name" style="width:100%"></label></p>'
			. '<p><button class="btn">Save</button></p></form></div></div>';
	}

	/* ---------- public badges ---------- */

	public static function profile( $pid ) {
		$p = get_post( $pid ? $pid : get_the_ID() );
		if ( ! $p ) {
			return;
		}
		$a = (int) $p->post_author;
		$o = '';
		if ( get_user_meta( $a, 'mrt_soc_ok', true ) ) {
			$o .= '<span class="chip on" style="display:inline-block;margin:4px 6px 4px 0">&#10003; Social profile checked</span>';
		}
		$s = (string) get_user_meta( $a, 'mrt_social', true );
		if ( in_array( $s, array( 'facebook', 'google' ), true ) ) {
			$o .= '<span class="chip" style="display:inline-block;margin:4px 6px 4px 0">' . ( 'facebook' === $s ? 'Signed in with Facebook' : 'Signed in with Google' ) . '</span>';
		}
		if ( $o ) {
			echo '<div class="wrap">' . $o . '</div>'; // phpcs:ignore
		}
	}

	/* ---------- duplicate fingerprint ---------- */

	private static function file_of( $id ) {
		if ( ! function_exists( 'mrt_photo_id' ) ) {
			return '';
		}
		$pid = (int) mrt_photo_id( $id );
		$f   = $pid ? (string) get_attached_file( $pid ) : '';
		return ( $f && file_exists( $f ) ) ? $f : '';
	}

	public static function hash_post( $id ) {
		if ( wp_is_post_revision( $id ) ) {
			return;
		}
		$f = self::file_of( $id );
		if ( $f && filesize( $f ) < 15 * MB_IN_BYTES ) {
			update_post_meta( $id, '_mrt_md5', md5_file( $f ) );
		}
	}

	private static function dupes( $id ) {
		$h = (string) get_post_meta( $id, '_mrt_md5', true );
		if ( '' === $h ) {
			return array();
		}
		return get_posts( array( 'post_type' => 'listing_type', 'post_status' => 'any', 'post__not_in' => array( $id ), 'meta_key' => '_mrt_md5', 'meta_value' => $h, 'posts_per_page' => 5, 'fields' => 'ids', 'no_found_rows' => true ) );
	}

	/* ---------- admin ---------- */

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Photo check', 'Photo check', 'manage_options', self::SLUG, array( __CLASS__, 'page' ) );
	}

	public static function act() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'mrsh_pc_act' ) ) {
			wp_die( 'Not allowed.' );
		}
		$do  = sanitize_key( $_POST['do'] ?? '' ); // phpcs:ignore
		$uid = (int) ( $_POST['uid'] ?? 0 ); // phpcs:ignore
		if ( 'approve' === $do && $uid ) {
			update_user_meta( $uid, 'mrt_soc_ok', time() );
		} elseif ( 'reject' === $do && $uid ) {
			delete_user_meta( $uid, 'mrt_soc_ok' );
			delete_user_meta( $uid, 'mrt_ig' );
			delete_user_meta( $uid, 'mrt_fbu' );
		} elseif ( 'scan' === $do ) {
			$ids = get_posts( array( 'post_type' => 'listing_type', 'post_status' => 'publish', 'posts_per_page' => 100, 'fields' => 'ids', 'no_found_rows' => true, 'meta_query' => array( array( 'key' => '_mrt_md5', 'compare' => 'NOT EXISTS' ) ) ) );
			foreach ( $ids as $i ) {
				self::hash_post( $i );
				if ( '' === (string) get_post_meta( $i, '_mrt_md5', true ) ) {
					update_post_meta( $i, '_mrt_md5', '-' ); // no local file: do not try again
				}
			}
		}
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&done=1' ) );
		exit;
	}

	private static function btn( $do, $uid, $label, $cls = '' ) {
		return '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline-block;margin:0 4px 0 0"><input type="hidden" name="action" value="mrsh_pc_act"><input type="hidden" name="do" value="' . esc_attr( $do ) . '"><input type="hidden" name="uid" value="' . (int) $uid . '">' . wp_nonce_field( 'mrsh_pc_act', '_wpnonce', true, false ) . '<button class="button ' . esc_attr( $cls ) . '">' . esc_html( $label ) . '</button></form>';
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		echo '<div class="wrap"><h1>Photo check</h1>';
		if ( isset( $_GET['done'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success"><p>Done.</p></div>';
		}
		echo '<p>Check that profile pictures are real. The search buttons open Google Lens, TinEye or Bing in a new tab with the picture. If the same face appears on someone else&#39;s social page or a stock site, the picture is probably copied. They only work on the live site (outside services cannot open a private test site).</p>';

		// 1. Social links waiting
		$us = get_users( array( 'meta_query' => array( 'relation' => 'AND', array( 'relation' => 'OR', array( 'key' => 'mrt_ig', 'value' => '', 'compare' => '!=' ), array( 'key' => 'mrt_fbu', 'value' => '', 'compare' => '!=' ) ), array( 'key' => 'mrt_soc_ok', 'compare' => 'NOT EXISTS' ) ), 'number' => 50, 'fields' => array( 'ID', 'display_name' ) ) );
		echo '<h2>Social links waiting for a check (' . count( $us ) . ')</h2>';
		if ( ! $us ) {
			echo '<p>Nothing waiting.</p>';
		} else {
			echo '<table class="widefat striped"><thead><tr><th>Member</th><th>Instagram</th><th>Facebook</th><th>Profile</th><th></th></tr></thead><tbody>';
			foreach ( $us as $u ) {
				$ig = (string) get_user_meta( $u->ID, 'mrt_ig', true );
				$fb = (string) get_user_meta( $u->ID, 'mrt_fbu', true );
				$lp = get_posts( array( 'post_type' => 'listing_type', 'author' => $u->ID, 'post_status' => 'any', 'posts_per_page' => 1, 'fields' => 'ids' ) );
				echo '<tr><td>' . esc_html( $u->display_name ) . '</td><td>' . ( $ig ? '<a href="' . esc_url( $ig ) . '" target="_blank" rel="noopener noreferrer">Open</a>' : '-' ) . '</td><td>' . ( $fb ? '<a href="' . esc_url( $fb ) . '" target="_blank" rel="noopener noreferrer">Open</a>' : '-' ) . '</td><td>' . ( $lp ? '<a href="' . esc_url( get_permalink( $lp[0] ) ) . '" target="_blank">View profile</a>' : '-' ) . '</td><td>' . self::btn( 'approve', $u->ID, 'Approve', 'button-primary' ) . self::btn( 'reject', $u->ID, 'Reject' ) . '</td></tr>'; // phpcs:ignore
			}
			echo '</tbody></table><p class="description">Approve only if the pictures on the social page match the profile pictures. Reject removes the links.</p>';
		}

		// 2. Photos
		echo '<h2>Profile photos</h2><p>' . self::btn( 'scan', 0, 'Scan next 100 profiles for duplicate photos' ) . '</p>'; // phpcs:ignore
		$q = new WP_Query( array( 'post_type' => 'listing_type', 'post_status' => 'publish', 'posts_per_page' => 40, 'no_found_rows' => true ) );
		echo '<table class="widefat striped"><thead><tr><th>Photo</th><th>Profile</th><th>Check on the web</th><th>Duplicate</th></tr></thead><tbody>';
		while ( $q->have_posts() ) {
			$q->the_post();
			$id  = get_the_ID();
			$pid = function_exists( 'mrt_photo_id' ) ? (int) mrt_photo_id( $id ) : 0;
			$th  = $pid ? (string) wp_get_attachment_image_url( $pid, 'thumbnail' ) : '';
			$big = $pid ? ( function_exists( 'mrt_att_url' ) ? mrt_att_url( $pid, 'large' ) : (string) wp_get_attachment_image_url( $pid, 'large' ) ) : '';
			if ( function_exists( 'mrt_remote_url' ) && $th && ! file_exists( (string) get_attached_file( $pid ) ) ) {
				$th = mrt_remote_url( $th );
			}
			$e = rawurlencode( $big );
			echo '<tr><td>' . ( $th ? '<img src="' . esc_url( $th ) . '" width="64" height="64" style="object-fit:cover;border-radius:8px" alt="">' : '-' ) . '</td><td><a href="' . esc_url( get_edit_post_link( $id ) ) . '">' . esc_html( get_the_title() ) . '</a></td><td>'; // phpcs:ignore
			if ( $big ) {
				echo '<a class="button" target="_blank" rel="noopener noreferrer" href="' . esc_url( 'https://lens.google.com/uploadbyurl?url=' . $e ) . '">Google Lens</a> <a class="button" target="_blank" rel="noopener noreferrer" href="' . esc_url( 'https://tineye.com/search?url=' . $e ) . '">TinEye</a> <a class="button" target="_blank" rel="noopener noreferrer" href="' . esc_url( 'https://www.bing.com/images/search?view=detailv2&iss=sbi&q=imgurl:' . $e ) . '">Bing</a>'; // phpcs:ignore
			} else {
				echo 'No photo';
			}
			echo '</td><td>';
			$d = self::dupes( $id );
			if ( $d ) {
				echo '<b style="color:#b32d2e">Same picture on:</b> ';
				foreach ( $d as $x ) {
					echo '<a href="' . esc_url( get_edit_post_link( $x ) ) . '">' . esc_html( get_the_title( $x ) ) . '</a> ';
				}
			} else {
				echo ( '' === (string) get_post_meta( $id, '_mrt_md5', true ) ) ? '<span class="description">Not scanned</span>' : 'No copy found';
			}
			echo '</td></tr>';
		}
		wp_reset_postdata();
		echo '</tbody></table></div>';
	}
}
MRSH_PhotoCheck::init();
