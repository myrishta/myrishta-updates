<?php
/**
 * Auto-Fixer: the robot that watches the site every hour, fixes what is safe to fix by itself,
 * and turns everything else into a ticket.
 *
 * Ticket status:
 *   auto_fixed      the robot fixed it (kept in the list so you can see what happened)
 *   needs_approval  waits for you: one-click Approve / Skip links are emailed, with reminders
 *   needs_claude    needs content or code work: picked up by the daily Claude fixer task
 *   resolved / skipped   closed
 *
 * Nothing here deletes content. The only destructive action (removing the leftover Google review account)
 * always waits for approval. Every automatic step has a manual button on the Auto-Fixer page.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Fixer {

	const OPT    = 'mrsh_fixer';
	const TICKS  = 'mrsh_fixer_tickets';
	const CRON   = 'mrsh_fixer_tick';
	const LAST   = 'mrsh_fixer_last';
	const SLUG   = 'mrsh-fixer';
	const REVIEW = 'google_ads_review';

	public static function o() {
		$o = get_option( self::OPT, array() );
		return array_merge( array( 'on' => 1, 'email' => '', 'autohide' => 1, 'remind_h' => 24, 'max_remind' => 3 ), is_array( $o ) ? $o : array() );
	}

	public static function init() {
		add_action( self::CRON, array( __CLASS__, 'run' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 42 );
		foreach ( array( 'save', 'now', 'tk', 'clear', 'test' ) as $a ) {
			add_action( 'admin_post_mrsh_fixer_' . $a, array( __CLASS__, $a ) );
		}
		add_action( 'admin_post_mrsh_fixer_link', array( __CLASS__, 'link' ) );
		add_action( 'admin_post_nopriv_mrsh_fixer_link', array( __CLASS__, 'link' ) );
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::CRON ) ) {
			wp_schedule_event( time() + 900, 'hourly', self::CRON );
		}
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Auto-Fixer', 'Auto-Fixer', 'manage_options', self::SLUG, array( __CLASS__, 'page' ) );
	}

	/* ---------- tickets ---------- */

	public static function tickets() {
		$t = get_option( self::TICKS, array() );
		return is_array( $t ) ? $t : array();
	}

	private static function save_tickets( $t ) {
		// Keep closed tickets for 30 days, everything else stays.
		foreach ( $t as $id => $r ) {
			if ( in_array( $r['status'], array( 'resolved', 'skipped' ), true ) && time() - (int) $r['updated'] > 30 * DAY_IN_SECONDS ) {
				unset( $t[ $id ] );
			}
		}
		update_option( self::TICKS, array_slice( $t, 0, 200, true ), false );
	}

	private static function id( $key ) {
		return 't' . substr( md5( $key ), 0, 8 );
	}

	/** Create or update a ticket. Returns true when the ticket is new or was reopened. */
	private static function report( $key, $title, $detail, $sev, $status, $act = '' ) {
		$t   = self::tickets();
		$id  = self::id( $key );
		$new = ! isset( $t[ $id ] ) || in_array( $t[ $id ]['status'], array( 'resolved', 'skipped' ), true ) && 'skipped' !== $t[ $id ]['status'];
		if ( isset( $t[ $id ] ) && 'skipped' === $t[ $id ]['status'] ) {
			return false; // the owner said skip: do not nag
		}
		$old = isset( $t[ $id ] ) ? $t[ $id ] : array();
		$t[ $id ] = array(
			'id'      => $id,
			'key'     => $key,
			'title'   => $title,
			'detail'  => $detail,
			'sev'     => $sev,
			'status'  => $status,
			'act'     => $act,
			'created' => $new ? time() : (int) ( $old['created'] ?? time() ),
			'updated' => time(),
			'rem'     => $new ? 0 : (int) ( $old['rem'] ?? 0 ),
			'mailed'  => $new ? 0 : (int) ( $old['mailed'] ?? 0 ),
		);
		self::save_tickets( $t );
		return $new;
	}

	/** For other modules: raise a ticket. Returns true when new. */
	public static function ticket( $key, $title, $detail, $sev, $status, $act = '' ) {
		return self::report( $key, $title, $detail, $sev, $status, $act );
	}

	public static function ticket_resolve( $key ) {
		self::resolve( $key );
	}

	/** The check passes again: close the ticket on its own. */
	private static function resolve( $key ) {
		$t  = self::tickets();
		$id = self::id( $key );
		if ( isset( $t[ $id ] ) && ! in_array( $t[ $id ]['status'], array( 'resolved', 'skipped' ), true ) ) {
			$t[ $id ]['status']  = 'resolved';
			$t[ $id ]['updated'] = time();
			self::save_tickets( $t );
		}
	}

	public static function counts() {
		$c = array( 'approval' => 0, 'claude' => 0, 'auto' => 0, 'open' => 0 );
		foreach ( self::tickets() as $r ) {
			if ( 'needs_approval' === $r['status'] ) {
				++$c['approval'];
				++$c['open'];
			} elseif ( 'needs_claude' === $r['status'] ) {
				++$c['claude'];
				++$c['open'];
			} elseif ( 'auto_fixed' === $r['status'] && time() - (int) $r['updated'] < 7 * DAY_IN_SECONDS ) {
				++$c['auto'];
			}
		}
		return $c;
	}

	/* ---------- helpers ---------- */

	private static function get( $path ) {
		return wp_remote_get( home_url( $path ), array( 'timeout' => 15, 'redirection' => 3, 'user-agent' => 'MyRishta-AutoFixer/1', 'sslverify' => true ) );
	}

	private static function code( $r ) {
		return is_wp_error( $r ) ? 0 : (int) wp_remote_retrieve_response_code( $r );
	}

	private static function purge() {
		do_action( 'litespeed_purge_all' );
	}

	/* ---------- the robot ---------- */

	public static function run() {
		$o = self::o();
		if ( empty( $o['on'] ) ) {
			return array();
		}
		$log = array();
		foreach ( array( 'check_cron', 'check_front', 'check_files', 'check_thin', 'check_mail', 'check_banned', 'check_review_user' ) as $fn ) {
			try {
				self::$fn( $log );
			} catch ( \Throwable $e ) {
				$log[] = $fn . ' stopped: ' . $e->getMessage();
			}
		}
		self::notify();
		update_option( self::LAST, array( 'time' => time(), 'log' => array_slice( $log, 0, 20 ) ), false );
		return $log;
	}

	/** Plugin schedules must exist and must not be stuck. */
	private static function check_cron( &$log ) {
		$need = array( 'mrsh_bounce_tick' => 'hourly', 'mrsh_guard_hourly' => 'hourly', 'mrsh_digest_tick' => 'hourly', 'mrsh_mailq_run' => 'mrsh_5min', 'mrsh_watchdog_run' => 'daily' );
		$fixed = array();
		foreach ( $need as $hook => $rec ) {
			if ( ! wp_next_scheduled( $hook ) ) {
				$sched = wp_get_schedules();
				if ( isset( $sched[ $rec ] ) || in_array( $rec, array( 'hourly', 'daily' ), true ) ) {
					wp_schedule_event( time() + 120, $rec, $hook );
					$fixed[] = $hook;
				}
			}
		}
		if ( $fixed ) {
			self::report( 'cron_missing', 'Missing background jobs were put back', 'Re-scheduled: ' . implode( ', ', $fixed ), 'med', 'auto_fixed' );
			$log[] = 'rescheduled ' . implode( ',', $fixed );
		}
		$late = 0;
		foreach ( (array) _get_cron_array() as $ts => $hooks ) {
			if ( $ts < time() - 1800 ) {
				foreach ( array_keys( (array) $hooks ) as $h ) {
					if ( 0 === strpos( $h, 'mrsh_' ) ) {
						++$late;
					}
				}
			}
		}
		if ( $late ) {
			spawn_cron();
			self::report( 'cron_late', 'Background jobs were running late', $late . ' job(s) were more than 30 minutes overdue. The robot started the job runner.', 'low', 'auto_fixed' );
			$log[] = 'nudged cron (' . $late . ' late)';
		} else {
			self::resolve( 'cron_late' );
		}
	}

	/** The public site must load and show no fatal error. */
	private static function check_front( &$log ) {
		$bad = function () {
			$r = self::get( '/?mrsh_fx=' . time() );
			$b = is_wp_error( $r ) ? '' : wp_remote_retrieve_body( $r );
			return 200 !== self::code( $r ) || false !== stripos( $b, 'critical error on this website' ) || false !== stripos( $b, 'Fatal error:' );
		};
		if ( ! $bad() ) {
			self::resolve( 'front_down' );
			return;
		}
		self::purge();
		sleep( 6 );
		if ( ! $bad() ) {
			self::report( 'front_down', 'Home page showed an error, fixed by clearing the cache', 'The page failed once and loaded after the robot cleared the cache.', 'med', 'auto_fixed' );
			$log[] = 'front fixed by purge';
			return;
		}
		self::report( 'front_down', 'The home page is not loading correctly', 'The home page still shows an error after a cache purge. Check Hostinger status and the error log. The Claude fixer will look at the error log.', 'high', 'needs_claude' );
		$log[] = 'front still down';
	}

	/** ads.txt and the sitemap named in robots.txt must answer. */
	private static function check_files( &$log ) {
		$fail = array();
		$robots = self::get( '/robots.txt' );
		$rb     = is_wp_error( $robots ) ? '' : wp_remote_retrieve_body( $robots );
		$sm     = '';
		if ( preg_match( '#^Sitemap:\s*(\S+)#mi', $rb, $m ) ) {
			$sm = $m[1];
		}
		$ads = self::get( '/ads.txt' );
		$ok_ads = 200 === self::code( $ads ) && false !== stripos( wp_remote_retrieve_body( $ads ), 'google.com' );
		$ok_sm  = true;
		if ( $sm ) {
			$ok_sm = 200 === self::code( wp_remote_get( $sm, array( 'timeout' => 15 ) ) );
		} elseif ( ! $rb ) {
			$ok_sm = false;
		}
		if ( $ok_ads && $ok_sm ) {
			self::resolve( 'files_bad' );
			return;
		}
		flush_rewrite_rules( false );
		self::purge();
		sleep( 4 );
		$ads    = self::get( '/ads.txt' );
		$ok_ads = 200 === self::code( $ads ) && false !== stripos( wp_remote_retrieve_body( $ads ), 'google.com' );
		$ok_sm  = $sm ? 200 === self::code( wp_remote_get( $sm, array( 'timeout' => 15 ) ) ) : $ok_sm;
		if ( $ok_ads && $ok_sm ) {
			self::report( 'files_bad', 'ads.txt or the sitemap was not loading, fixed', 'The robot refreshed the site address rules and both files load now.', 'med', 'auto_fixed' );
			$log[] = 'files fixed by flush';
			return;
		}
		if ( ! $ok_ads ) {
			$fail[] = 'ads.txt';
		}
		if ( ! $ok_sm ) {
			$fail[] = 'sitemap';
		}
		self::report( 'files_bad', implode( ' and ', $fail ) . ' not loading', 'Still failing after refreshing the address rules. ads.txt must contain the Google line and the sitemap must answer 200.', 'high', 'needs_claude' );
		$log[] = 'files still failing: ' . implode( ',', $fail );
	}

	/** New short guides are hidden from Google until they are long enough (AdSense calls them low value). */
	private static function check_thin( &$log ) {
		$o = self::o();
		if ( empty( $o['autohide'] ) || ! class_exists( 'MRSH_Thin' ) || get_transient( 'mrsh_fixer_thin' ) ) {
			return;
		}
		set_transient( 'mrsh_fixer_thin', 1, 5 * HOUR_IN_SECONDS );
		$hid = array();
		foreach ( MRSH_Thin::thin() as $r ) {
			$p = $r[0];
			if ( get_post_meta( $p->ID, '_mrsh_noindex', true ) ) {
				continue;
			}
			update_post_meta( $p->ID, '_mrsh_noindex', '1' );
			update_post_meta( $p->ID, '_mrsh_thin_hid', '1' );
			do_action( 'litespeed_purge_post', $p->ID );
			$hid[] = $p->ID;
		}
		if ( $hid ) {
			$log[] = 'hid thin posts ' . implode( ',', $hid );
		}
		$left = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'numberposts' => 200, 'fields' => 'ids', 'meta_key' => '_mrsh_thin_hid', 'meta_value' => '1', 'suppress_filters' => true ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		if ( $left ) {
			self::report( 'thin_expand', count( $left ) . ' short guide(s) hidden until they are expanded', 'Post IDs: ' . implode( ', ', array_slice( $left, 0, 40 ) ) . '. They stay hidden from Google, the sitemap and ads. The Claude fixer expands them with real advice (350 words or more), then shows them again. You can also expand one yourself on the Thin content page.', 'low', 'needs_claude' );
		} else {
			self::resolve( 'thin_expand' );
		}
	}

	/** The leftover Google review account must not stay on the site forever. Removing it always waits for approval. */
	/** Reads the mail problem log. Many login rejections in a few hours usually mean the host is throttling the mailbox. */
	private static function check_mail( &$log ) {
		$l    = (array) get_option( 'mrsh_smtp_log', array() );
		$auth = 0;
		$all  = 0;
		foreach ( $l as $r ) {
			if ( ! is_array( $r ) || time() - (int) ( $r['t'] ?? 0 ) > 6 * HOUR_IN_SECONDS ) {
				continue;
			}
			++$all;
			if ( preg_match( '/authenticate/i', (string) ( $r['m'] ?? '' ) ) ) {
				++$auth;
			}
		}
		$has_backup = false;
		$rl         = get_option( 'mrsh_relay', array() );
		if ( is_array( $rl ) && ! empty( $rl['providers'] ) ) {
			$has_backup = true;
		}
		if ( $auth >= 3 ) {
			self::report( 'mail_auth', 'The mailbox login was rejected ' . $auth . ' times in 6 hours', 'The host keeps refusing the main mailbox (noreply@myrishta.pk). Members may wait for emails (they are retried automatically, nothing is lost). Fix: in hPanel, Emails, reset that mailbox password, paste it in Email (SMTP) and press the test button. Best long-term fix: add a free backup sender (Brevo) in Email backup senders.', 'high', 'needs_approval' );
		} else {
			self::resolve( 'mail_auth' );
		}
		if ( $all >= 6 && ! $has_backup ) {
			self::report( 'mail_backup', 'No backup email sender is set up', $all . ' mail problems in 6 hours and no backup. A free Brevo account (300 emails a day) takes over when the main mailbox fails. Add it in Email backup senders.', 'med', 'needs_approval' );
		} else {
			self::resolve( 'mail_backup' );
		}
		if ( $all ) {
			$log[] = $all . ' mail problem(s) in the last 6 hours';
		}
	}

	/** A suspended member must stay hidden and signed out. Runs every hour and repairs anything that slipped. */
	private static function check_banned( &$log ) {
		if ( ! class_exists( 'MRSH_Manage' ) ) {
			return;
		}
		foreach ( get_users( array( 'meta_key' => 'mrsh_ban_until', 'meta_compare' => '<', 'meta_value' => time(), 'meta_type' => 'NUMERIC', 'fields' => 'ID', 'number' => 200 ) ) as $uid ) { // phpcs:ignore WordPress.DB.SlowDBQuery
			if ( ! get_user_meta( $uid, 'mrsh_perm_ban', true ) ) {
				delete_user_meta( $uid, 'mrt_banned' );
			}
			delete_user_meta( $uid, 'mrsh_ban_until' );
		}
		$n = 0;
		foreach ( get_users( array( 'meta_key' => 'mrt_banned', 'meta_value' => '1', 'fields' => 'ID', 'number' => 200 ) ) as $uid ) { // phpcs:ignore WordPress.DB.SlowDBQuery
			if ( MRSH_Manage::enforce_ban( (int) $uid ) ) {
				++$n;
			}
		}
		if ( $n ) {
			$log[] = 'hid/signed out ' . $n . ' suspended member(s)';
		}
	}

	private static function check_review_user( &$log ) {
		$u = get_user_by( 'login', self::REVIEW );
		if ( ! $u ) {
			self::resolve( 'review_user' );
			return;
		}
		self::report( 'review_user', 'Delete the leftover Google review account (' . self::REVIEW . ')', 'Google staff used this account to review the site. It has not been needed since the review ended. Approve to delete it. It owns no content that is kept.', 'med', 'needs_approval', 'del_user:' . (int) $u->ID );
	}

	/* ---------- actions that need approval ---------- */

	private static function do_act( $act ) {
		if ( 0 === strpos( $act, 'del_user:' ) ) {
			$id = (int) substr( $act, 9 );
			$u  = get_userdata( $id );
			if ( ! $u || self::REVIEW !== $u->user_login ) {
				return 'That account is already gone.';
			}
			$admins = get_users( array( 'role' => 'administrator', 'fields' => 'ID' ) );
			if ( in_array( $u->ID, array_map( 'intval', $admins ), true ) && count( $admins ) < 2 ) {
				return 'Not deleted: it is the only administrator.';
			}
			require_once ABSPATH . 'wp-admin/includes/user.php';
			$heir = 0;
			foreach ( $admins as $a ) {
				if ( (int) $a !== $id ) {
					$heir = (int) $a;
					break;
				}
			}
			wp_delete_user( $id, $heir ? $heir : null ); // anything it owned moves to an administrator, never deleted
			return 'Account deleted.';
		}
		if ( 0 === strpos( $act, 'demote:' ) ) {
			$id = (int) substr( $act, 7 );
			$u  = get_userdata( $id );
			if ( ! $u || ! in_array( 'administrator', (array) $u->roles, true ) ) {
				return 'That account is no longer an administrator.';
			}
			$admins = get_users( array( 'role' => 'administrator', 'fields' => 'ID' ) );
			if ( count( $admins ) < 2 ) {
				return 'Not changed: it is the only administrator.';
			}
			$u->set_role( 'subscriber' );
			return 'Account changed to a normal member (not deleted).';
		}
		if ( 'secquar' === $act && class_exists( 'MRSH_SecBot' ) ) {
			return MRSH_SecBot::quarantine();
		}
		if ( 0 === strpos( $act, 'publish_post:' ) ) {
			$id = (int) substr( $act, 13 );
			$p  = get_post( $id );
			if ( ! $p || 'draft' !== $p->post_status ) {
				return 'That draft is not waiting any more.';
			}
			if ( class_exists( 'MRSH_Thin' ) && MRSH_Thin::words( $p ) < MRSH_Thin::min() ) {
				return 'Not published: the draft is shorter than the word limit. Edit it first.';
			}
			wp_update_post( array( 'ID' => $id, 'post_status' => 'publish' ) );
			delete_post_meta( $id, '_mrsh_noindex' );
			return 'Published.';
		}
		return 'Done.';
	}

	private static function apply( $id, $do ) {
		$t = self::tickets();
		if ( ! isset( $t[ $id ] ) ) {
			return 'Ticket not found.';
		}
		$r   = $t[ $id ];
		$msg = 'Done.';
		if ( 'approve' === $do ) {
			$msg                 = $r['act'] ? self::do_act( $r['act'] ) : 'Approved.';
			$t[ $id ]['status']  = 'resolved';
		} elseif ( 'skip' === $do ) {
			$t[ $id ]['status'] = 'skipped';
			$msg                = 'Skipped. The robot will not ask again.';
		} elseif ( 'done' === $do ) {
			$t[ $id ]['status'] = 'resolved';
			$msg                = 'Marked as done.';
		} elseif ( 'reopen' === $do ) {
			$t[ $id ]['status'] = $r['act'] ? 'needs_approval' : 'needs_claude';
			$t[ $id ]['rem']    = 0;
			$t[ $id ]['mailed'] = 0;
			$msg                = 'Reopened.';
		}
		$t[ $id ]['updated'] = time();
		self::save_tickets( $t );
		return $msg;
	}

	/* ---------- email with one-click links and reminders ---------- */

	private static function token( $id, $do ) {
		return hash_hmac( 'sha256', $id . '|' . $do, wp_salt( 'auth' ) );
	}

	private static function link_url( $id, $do ) {
		return add_query_arg( array( 'action' => 'mrsh_fixer_link', 't' => $id, 'd' => $do, 'k' => self::token( $id, $do ) ), admin_url( 'admin-post.php' ) );
	}

	/** Owner clicked a link in the email. Works without logging in, for one ticket and one action only, for 14 days. */
	public static function link() {
		$id = sanitize_key( wp_unslash( $_GET['t'] ?? '' ) ); // phpcs:ignore
		$do = sanitize_key( wp_unslash( $_GET['d'] ?? '' ) ); // phpcs:ignore
		$k  = (string) wp_unslash( $_GET['k'] ?? '' ); // phpcs:ignore
		$t  = self::tickets();
		if ( ! in_array( $do, array( 'approve', 'skip', 'done' ), true ) || ! hash_equals( self::token( $id, $do ), $k ) || ! isset( $t[ $id ] ) || time() - (int) $t[ $id ]['created'] > 14 * DAY_IN_SECONDS ) {
			wp_die( 'This link is not valid or has expired. Open the Auto-Fixer page in your dashboard instead.', 'Link expired', array( 'response' => 403 ) );
			return;
		}
		$msg = self::apply( $id, $do );
		wp_die( esc_html( $msg ) . ' You can close this page.', 'MyRishta Auto-Fixer', array( 'response' => 200 ) );
	}

	private static function to() {
		$o = self::o();
		return is_email( $o['email'] ) ? $o['email'] : get_option( 'admin_email' );
	}

	private static function mail( $subject, $lines ) {
		wp_mail( self::to(), $subject, implode( "\n", $lines ) . "\n\n-- MyRishta Auto-Fixer\n" . admin_url( 'admin.php?page=' . self::SLUG ) );
	}

	private static function notify() {
		$o   = self::o();
		$t   = self::tickets();
		$due = array();
		foreach ( $t as $id => $r ) {
			$wait = in_array( $r['status'], array( 'needs_approval' ), true ) || ( 'needs_claude' === $r['status'] && 'high' === $r['sev'] );
			if ( ! $wait ) {
				continue;
			}
			$gap = max( 1, (int) $o['remind_h'] ) * HOUR_IN_SECONDS;
			if ( (int) $r['mailed'] && ( time() - (int) $r['mailed'] < $gap || (int) $r['rem'] >= (int) $o['max_remind'] ) ) {
				if ( (int) $r['rem'] >= (int) $o['max_remind'] && empty( $r['escalated'] ) && class_exists( 'MRSH_Attn' ) ) {
					MRSH_Attn::add( 'fixer', 0, 'Auto-Fixer is waiting for you: ' . $r['title'], admin_url( 'admin.php?page=' . self::SLUG ) );
					$t[ $id ]['escalated'] = 1;
				}
				continue;
			}
			$due[ $id ] = $r;
		}
		if ( ! $due ) {
			update_option( self::TICKS, $t, false );
			return;
		}
		$lines = array( 'These items need you. One tap on a link below is enough.', '' );
		foreach ( $due as $id => $r ) {
			$lines[] = strtoupper( $r['sev'] ) . ': ' . $r['title'];
			$lines[] = $r['detail'];
			if ( 'needs_approval' === $r['status'] ) {
				$lines[] = 'Approve: ' . self::link_url( $id, 'approve' );
				$lines[] = 'Skip (do not ask again): ' . self::link_url( $id, 'skip' );
			} else {
				$lines[] = 'The Claude fixer is looking at it. Mark as done: ' . self::link_url( $id, 'done' );
			}
			$lines[] = '';
			$t[ $id ]['mailed'] = time();
			$t[ $id ]['rem']    = (int) $r['rem'] + 1;
		}
		update_option( self::TICKS, $t, false );
		self::mail( 'MyRishta: ' . count( $due ) . ' item(s) need you', $lines );
	}

	/* ---------- admin handlers ---------- */

	private static function guard( $action ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( $action );
	}

	private static function back( $msg = '' ) {
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . ( $msg ? '&done=' . rawurlencode( $msg ) : '' ) ) );
		exit;
	}

	public static function save() {
		self::guard( 'mrsh_fixer_save' );
		$o = array(
			'on'         => empty( $_POST['on'] ) ? 0 : 1, // phpcs:ignore
			'email'      => sanitize_email( wp_unslash( $_POST['email'] ?? '' ) ), // phpcs:ignore
			'autohide'   => empty( $_POST['autohide'] ) ? 0 : 1, // phpcs:ignore
			'remind_h'   => max( 1, min( 168, (int) ( $_POST['remind_h'] ?? 24 ) ) ), // phpcs:ignore
			'max_remind' => max( 1, min( 10, (int) ( $_POST['max_remind'] ?? 3 ) ) ), // phpcs:ignore
		);
		update_option( self::OPT, $o, false );
		self::back( 'Settings saved.' );
	}

	public static function now() {
		self::guard( 'mrsh_fixer_now' );
		delete_transient( 'mrsh_fixer_thin' );
		$log = self::run();
		self::back( $log ? 'Checked. ' . count( $log ) . ' action(s) taken.' : 'Checked. Everything is fine.' );
	}

	public static function tk() {
		$id = sanitize_key( wp_unslash( $_GET['t'] ?? '' ) ); // phpcs:ignore
		self::guard( 'mrsh_fixer_tk_' . $id );
		$do = sanitize_key( wp_unslash( $_GET['d'] ?? '' ) ); // phpcs:ignore
		if ( ! in_array( $do, array( 'approve', 'skip', 'done', 'reopen' ), true ) ) {
			self::back();
		}
		self::back( self::apply( $id, $do ) );
	}

	public static function clear() {
		self::guard( 'mrsh_fixer_clear' );
		$t = self::tickets();
		foreach ( $t as $id => $r ) {
			if ( in_array( $r['status'], array( 'resolved', 'skipped', 'auto_fixed' ), true ) ) {
				unset( $t[ $id ] );
			}
		}
		update_option( self::TICKS, $t, false );
		self::back( 'Closed tickets cleared.' );
	}

	public static function test() {
		self::guard( 'mrsh_fixer_test' );
		self::mail( 'MyRishta Auto-Fixer test', array( 'This is a test. If you can read it, approval emails will reach you at this address.' ) );
		self::back( 'Test email sent to ' . self::to() . '.' );
	}

	/* ---------- page ---------- */

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$o    = self::o();
		$c    = self::counts();
		$last = get_option( self::LAST, array() );
		$post = esc_url( admin_url( 'admin-post.php' ) );
		$t    = self::tickets();
		uasort( $t, function ( $a, $b ) {
			$rank = array( 'needs_approval' => 0, 'needs_claude' => 1, 'auto_fixed' => 2, 'resolved' => 3, 'skipped' => 4 );
			return array( $rank[ $a['status'] ] ?? 9, -(int) $a['updated'] ) <=> array( $rank[ $b['status'] ] ?? 9, -(int) $b['updated'] );
		} );
		MRSH_Admin::open( 'Auto-Fixer', 'A robot checks the site every hour, fixes what is safe, and sends you a one-tap email for the rest.' );
		if ( ! empty( $_GET['done'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( wp_unslash( $_GET['done'] ) ) . '</p></div>'; // phpcs:ignore
		}
		echo '<div class="mrsh-grid mrsh-grid-4">';
		echo MRSH_Admin::stat( 'Robot', $o['on'] ? 'On' : 'Off', $last ? 'last check ' . human_time_diff( (int) $last['time'] ) . ' ago' : 'first check soon' ); // phpcs:ignore
		echo MRSH_Admin::stat( 'Waiting for you', (int) $c['approval'], 'approve or skip' ); // phpcs:ignore
		echo MRSH_Admin::stat( 'For the Claude fixer', (int) $c['claude'], 'picked up every morning' ); // phpcs:ignore
		echo MRSH_Admin::stat( 'Fixed by the robot', (int) $c['auto'], 'in the last 7 days' ); // phpcs:ignore
		echo '</div>';

		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Tickets</h2></div>';
		echo '<div class="mrsh-actions">';
		foreach ( array( array( 'mrsh_fixer_now', 'Run all checks now', true ), array( 'mrsh_fixer_clear', 'Clear closed tickets', false ), array( 'mrsh_fixer_test', 'Send a test email', false ) ) as $b ) {
			MRSH_Admin::post_button( $b[0], $b[1], $b[2] );
		}
		echo '</div>';
		if ( ! $t ) {
			echo '<p class="mrsh-muted">No tickets. Everything the robot checks is healthy.</p>';
		} else {
			$names = array( 'needs_approval' => array( 'warn', 'Needs your approval' ), 'needs_claude' => array( 'unknown', 'Claude fixer queue' ), 'auto_fixed' => array( 'pass', 'Fixed by robot' ), 'resolved' => array( 'pass', 'Closed' ), 'skipped' => array( 'unknown', 'Skipped' ) );
			$sev   = array( 'high' => 'fail', 'med' => 'warn', 'low' => 'unknown' );
			echo '<div style="overflow-x:auto"><table class="widefat striped mrsh-table"><thead><tr><th>Problem</th><th>Importance</th><th>Status</th><th>Updated</th><th></th></tr></thead><tbody>';
			foreach ( $t as $id => $r ) {
				$u = function ( $d ) use ( $id ) {
					return wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_fixer_tk&t=' . $id . '&d=' . $d ), 'mrsh_fixer_tk_' . $id );
				};
				$btn = '';
				if ( 'needs_approval' === $r['status'] ) {
					$btn = '<a class="button button-primary button-small" href="' . esc_url( $u( 'approve' ) ) . '" onclick="return confirm(\'Approve and run this now?\')">Approve</a> <a class="button button-small" href="' . esc_url( $u( 'skip' ) ) . '">Skip</a>';
				} elseif ( 'needs_claude' === $r['status'] ) {
					$btn = '<a class="button button-small" href="' . esc_url( $u( 'done' ) ) . '">Mark done</a>';
				} elseif ( in_array( $r['status'], array( 'resolved', 'skipped' ), true ) ) {
					$btn = '<a class="button button-small" href="' . esc_url( $u( 'reopen' ) ) . '">Reopen</a>';
				}
				$nm = $names[ $r['status'] ] ?? array( 'unknown', $r['status'] );
				echo '<tr><td><b>' . esc_html( $r['title'] ) . '</b><br><span class="mrsh-muted">' . esc_html( $r['detail'] ) . '</span></td><td>' . MRSH_Admin::badge( $sev[ $r['sev'] ] ?? 'unknown', ucfirst( $r['sev'] ) ) . '</td><td>' . MRSH_Admin::badge( $nm[0], $nm[1] ) . '</td><td>' . esc_html( human_time_diff( (int) $r['updated'] ) ) . ' ago</td><td style="white-space:nowrap">' . $btn . '</td></tr>'; // phpcs:ignore
			}
			echo '</tbody></table></div>';
		}
		echo '</div>';

		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>What the robot does</h2></div><ul class="mrsh-checklist">';
		foreach ( array(
			'Background jobs: puts back any missing schedule and starts the runner when jobs are late.',
			'Site pages: if the home page shows an error it clears the cache and checks again; if it is still broken it raises a high ticket.',
			'ads.txt and sitemap: refreshes the address rules when either stops loading.',
			'Short guides: hides new guides under the word limit from Google, the sitemap and ads (AdSense treats them as low value) until they are expanded.',
			'Leftover Google review account: asks you before deleting it.',
			'Anything it cannot fix goes to the Claude fixer queue. A scheduled Claude task reads that queue every morning and does the content or code work.',
		) as $line ) {
			echo '<li>' . esc_html( $line ) . '</li>';
		}
		echo '</ul></div>';

		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Settings</h2></div><form method="post" action="' . $post . '">';
		wp_nonce_field( 'mrsh_fixer_save' );
		echo '<input type="hidden" name="action" value="mrsh_fixer_save">';
		echo '<p><label><input type="checkbox" name="on" value="1"' . checked( $o['on'], 1, false ) . '> Robot is on (checks every hour)</label></p>';
		echo '<p><label><input type="checkbox" name="autohide" value="1"' . checked( $o['autohide'], 1, false ) . '> Hide new short guides from Google automatically</label></p>';
		echo '<p><label>Send approval emails to <input type="email" name="email" class="regular-text" value="' . esc_attr( $o['email'] ) . '" placeholder="' . esc_attr( get_option( 'admin_email' ) ) . '"></label></p>';
		echo '<p><label>Remind me every <input type="number" name="remind_h" min="1" max="168" value="' . (int) $o['remind_h'] . '" style="width:70px"> hours, up to <input type="number" name="max_remind" min="1" max="10" value="' . (int) $o['max_remind'] . '" style="width:60px"> times, then show it in the Inbox</label></p>';
		echo '<button class="button button-primary">Save settings</button></form></div>';
		MRSH_Admin::close();
	}
}
MRSH_Fixer::init();
