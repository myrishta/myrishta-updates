<?php
/**
 * Security Robot: watches the site every hour and deals with what it safely can.
 *
 * Automatic: switches the Security Shield basics back on, blocks PHP from running inside the uploads folder
 * (and checks that pictures still load afterwards), deletes an exposed debug.log.
 * Tickets (through the Auto-Fixer, with email reminders): a new administrator account, a PHP file hidden in uploads,
 * a backup or secret file reachable from the internet, changed WordPress core files.
 * The AI (if a key is saved) writes a short plain-language security report once a day.
 * Nothing is ever deleted by itself: suspicious files are renamed (quarantined) only after you approve.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_SecBot {

	const OPT   = 'mrsh_secbot';
	const KNOWN = 'mrsh_secbot_admins';
	const LAST  = 'mrsh_secbot_last';
	const CRON  = 'mrsh_secbot_tick';
	const SLUG  = 'mrsh-secbot';

	public static function o() {
		$o = get_option( self::OPT, array() );
		return array_merge( array( 'on' => 1, 'ai' => 1, 'auto' => 1 ), is_array( $o ) ? $o : array() );
	}

	public static function init() {
		add_action( self::CRON, array( __CLASS__, 'scan' ) );
		add_action( 'init', function () {
			if ( ! wp_next_scheduled( self::CRON ) ) {
				wp_schedule_event( time() + 600, 'hourly', self::CRON );
			}
		} );
		if ( is_admin() ) {
			add_action( 'admin_menu', array( __CLASS__, 'menu' ), 44 );
			foreach ( array( 'save', 'now', 'known', 'quar' ) as $a ) {
				add_action( 'admin_post_mrsh_secbot_' . $a, array( __CLASS__, 'h_' . $a ) );
			}
		}
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Security Robot', 'Security Robot', 'manage_options', self::SLUG, array( __CLASS__, 'page' ) );
	}

	private static function fx( $key, $title, $detail, $sev, $status, $act = '' ) {
		if ( class_exists( 'MRSH_Fixer' ) ) {
			MRSH_Fixer::ticket( $key, $title, $detail, $sev, $status, $act );
		}
	}

	private static function ok( $key ) {
		if ( class_exists( 'MRSH_Fixer' ) ) {
			MRSH_Fixer::ticket_resolve( $key );
		}
	}

	/* ---------- the scan ---------- */

	/** Returns a list of rows: array( status pass|warn|fail, title, detail ). */
	public static function scan() {
		$o = self::o();
		if ( empty( $o['on'] ) ) {
			return array();
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 60 ); // phpcs:ignore
		}
		$rows = array();
		try {
			$rows = array_merge( $rows, self::c_basics( $o ), self::c_admins(), self::c_uploads( $o ), self::c_exposed(), self::c_core() );
		} catch ( \Throwable $e ) {
			$rows[] = array( 'warn', 'Scan stopped early', $e->getMessage() );
		}
		$ai = self::ai_report( $rows, $o );
		update_option( self::LAST, array( 't' => time(), 'rows' => $rows, 'ai' => $ai ), false );
		return $rows;
	}

	private static function c_basics( $o ) {
		$rows = array();
		if ( ! empty( $o['auto'] ) && class_exists( 'MRSH_Shield' ) ) {
			$s   = get_option( MRSH_Shield::OPT, array() );
			$s   = is_array( $s ) ? $s : array();
			$fix = array();
			if ( isset( $s['bf_on'] ) && ! $s['bf_on'] ) {
				$s['bf_on'] = 1;
				$fix[]      = 'wrong-password lockout';
			}
			if ( isset( $s['no_file_edit'] ) && ! $s['no_file_edit'] ) {
				$s['no_file_edit'] = 1;
				$fix[]             = 'file editor off';
			}
			if ( isset( $s['pw_min'] ) && (int) $s['pw_min'] < 8 ) {
				$s['pw_min'] = 8;
				$fix[]       = 'password length 8';
			}
			if ( $fix ) {
				update_option( MRSH_Shield::OPT, $s, false );
				self::fx( 'sec_basics', 'Security Robot switched protections back on', implode( ', ', $fix ), 'low', 'auto_fixed' );
				$rows[] = array( 'pass', 'Protections switched back on', implode( ', ', $fix ) );
			}
		}
		$rows[] = is_ssl() ? array( 'pass', 'HTTPS is on', '' ) : array( 'fail', 'The site is not on HTTPS', 'Force SSL in the hosting panel.' );
		$dbg = defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'WP_DEBUG_DISPLAY' ) && WP_DEBUG_DISPLAY;
		$rows[] = $dbg ? array( 'fail', 'Errors are shown to visitors', 'Set WP_DEBUG_DISPLAY to false in wp-config.php.' ) : array( 'pass', 'Errors are hidden from visitors', '' );
		if ( username_exists( 'admin' ) ) {
			$rows[] = array( 'warn', 'An account is named "admin"', 'Attackers try this name first. Create another administrator, then remove it.' );
		} else {
			$rows[] = array( 'pass', 'No account named "admin"', '' );
		}
		$pl = get_site_transient( 'update_plugins' );
		$pn = ! empty( $pl->response ) ? count( (array) $pl->response ) : 0;
		$rows[] = $pn ? array( 'warn', $pn . ' plugin update(s) waiting', 'Updates close known holes. Update from the Plugins page.' ) : array( 'pass', 'All plugins are up to date', '' );
		return $rows;
	}

	private static function c_admins() {
		$rows  = array();
		$ids   = array_map( 'intval', get_users( array( 'role' => 'administrator', 'fields' => 'ID', 'number' => 200 ) ) );
		$known = get_option( self::KNOWN, null );
		if ( ! is_array( $known ) ) {
			update_option( self::KNOWN, $ids, false ); // first run: today's administrators are the trusted ones
			$known = $ids;
		}
		$new = array_diff( $ids, array_map( 'intval', $known ) );
		foreach ( $new as $id ) {
			$u = get_userdata( $id );
			if ( ! $u ) {
				continue;
			}
			self::fx( 'secadm_' . $id, 'New administrator account: ' . $u->user_login, 'A new account with full control appeared (' . $u->user_login . ', created ' . $u->user_registered . '). If you did not create it, approve to change it to a normal member now.', 'high', 'needs_approval', 'demote:' . $id );
			$rows[] = array( 'fail', 'New administrator: ' . $u->user_login, 'Not in your trusted list. Approve the ticket to remove its power, or press "I know these administrators".' );
		}
		foreach ( $known as $k ) {
			if ( in_array( (int) $k, $ids, true ) ) {
				self::ok( 'secadm_' . (int) $k );
			}
		}
		if ( ! $new ) {
			$rows[] = array( 'pass', count( $ids ) . ' administrator account(s), all trusted', '' );
		}
		return $rows;
	}

	private static function php_in_uploads() {
		$base = wp_upload_dir();
		$dir  = $base['basedir'];
		$out  = array();
		if ( ! is_dir( $dir ) ) {
			return $out;
		}
		$t0 = time();
		$n  = 0;
		try {
			$it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ), RecursiveIteratorIterator::LEAVES_ONLY, RecursiveIteratorIterator::CATCH_GET_CHILD );
			foreach ( $it as $f ) {
				if ( ++$n > 60000 || time() - $t0 > 25 ) {
					break;
				}
				$name = strtolower( $f->getFilename() );
				if ( preg_match( '/\.(php\d?|phtml|phar|pht)$/', $name ) ) {
					if ( 'index.php' === $name && $f->getSize() < 80 ) {
						continue; // WordPress "silence is golden" file
					}
					$out[] = substr( $f->getPathname(), strlen( $dir ) + 1 );
				}
			}
		} catch ( \Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement
		}
		return $out;
	}

	private static function c_uploads( $o ) {
		$rows = array();
		$base = wp_upload_dir();
		$ht   = trailingslashit( $base['basedir'] ) . '.htaccess';
		if ( ! empty( $o['auto'] ) && is_dir( $base['basedir'] ) && is_writable( $base['basedir'] ) ) {
			$cur = file_exists( $ht ) ? (string) file_get_contents( $ht ) : '';
			if ( false === strpos( $cur, 'MRSH-NOPHP' ) ) {
				$rule = "\n# MRSH-NOPHP begin\n<FilesMatch \"\\.(php[0-9]?|phtml|phar|pht)$\">\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n</FilesMatch>\n# MRSH-NOPHP end\n";
				file_put_contents( $ht, $cur . $rule ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				// prove pictures still load; if not, undo at once
				$img = get_posts( array( 'post_type' => 'attachment', 'post_mime_type' => 'image', 'numberposts' => 1, 'fields' => 'ids' ) );
				if ( $img ) {
					$u = wp_get_attachment_url( $img[0] );
					$r = wp_remote_head( $u, array( 'timeout' => 10 ) );
					if ( is_wp_error( $r ) || 200 !== (int) wp_remote_retrieve_response_code( $r ) ) {
						if ( '' === $cur ) {
							@unlink( $ht ); // phpcs:ignore
						} else {
							file_put_contents( $ht, $cur ); // phpcs:ignore
						}
						self::fx( 'sec_uphp', 'Could not block PHP in uploads', 'The server did not accept the protection rule, so it was undone. Pictures are fine.', 'low', 'needs_claude' );
						$rows[] = array( 'warn', 'PHP-in-uploads block not accepted by the server', 'Undone. The Claude fixer will look for another way.' );
					} else {
						$rows[] = array( 'pass', 'PHP is blocked inside the uploads folder', 'Added just now; pictures still load.' );
					}
				}
			} else {
				$rows[] = array( 'pass', 'PHP is blocked inside the uploads folder', '' );
			}
		}
		$bad = self::php_in_uploads();
		if ( $bad ) {
			self::fx( 'sec_phpfiles', count( $bad ) . ' PHP file(s) hidden in uploads', 'Uploads should hold pictures and documents only. Files: ' . implode( ', ', array_slice( $bad, 0, 8 ) ) . '. Approve to rename them to .quarantined (nothing is deleted).', 'high', 'needs_approval', 'secquar' );
			$rows[] = array( 'fail', count( $bad ) . ' PHP file(s) in uploads', implode( ', ', array_slice( $bad, 0, 5 ) ) );
		} else {
			self::ok( 'sec_phpfiles' );
			$rows[] = array( 'pass', 'No PHP files hidden in uploads', '' );
		}
		return $rows;
	}

	/** Called by the Auto-Fixer after you approve. */
	public static function quarantine() {
		$base = wp_upload_dir();
		$n    = 0;
		foreach ( self::php_in_uploads() as $rel ) {
			$p = trailingslashit( $base['basedir'] ) . $rel;
			if ( is_file( $p ) && @rename( $p, $p . '.quarantined' ) ) { // phpcs:ignore
				++$n;
			}
		}
		return $n . ' file(s) renamed to .quarantined.';
	}

	private static function c_exposed() {
		$tests = array(
			'/.env'                             => '/=/',
			'/.git/config'                      => '/\[core\]/',
			'/wp-config.php.bak'                => '/DB_PASSWORD/',
			'/wp-config.php~'                   => '/DB_PASSWORD/',
			'/wp-config.old'                    => '/DB_PASSWORD/',
			'/backup.sql'                       => '/CREATE TABLE|INSERT INTO/i',
			'/database.sql'                     => '/CREATE TABLE|INSERT INTO/i',
			'/wp-content/debug.log'             => '/PHP (Warning|Notice|Fatal|Deprecated)|\[\d\d-\w{3}-\d{4}/',
			'/phpinfo.php'                      => '/phpinfo\(\)|PHP Version/',
		);
		$bad = array();
		foreach ( $tests as $path => $re ) {
			$r = wp_remote_get( home_url( $path ), array( 'timeout' => 8, 'redirection' => 0, 'headers' => array( 'Range' => 'bytes=0-3000' ), 'user-agent' => 'MyRishta-SecBot/1' ) );
			if ( is_wp_error( $r ) ) {
				continue;
			}
			$c = (int) wp_remote_retrieve_response_code( $r );
			if ( ( 200 === $c || 206 === $c ) && preg_match( $re, (string) wp_remote_retrieve_body( $r ) ) ) {
				$bad[] = $path;
			}
		}
		$rows = array();
		if ( in_array( '/wp-content/debug.log', $bad, true ) ) {
			$f = WP_CONTENT_DIR . '/debug.log';
			if ( is_file( $f ) && @unlink( $f ) ) { // phpcs:ignore
				$bad = array_diff( $bad, array( '/wp-content/debug.log' ) );
				self::fx( 'sec_debuglog', 'Public debug.log removed', 'The error log was reachable by anyone, so the robot deleted it (it is only a log).', 'medium', 'auto_fixed' );
				$rows[] = array( 'pass', 'Public debug.log was removed', '' );
			}
		}
		if ( $bad ) {
			self::fx( 'sec_exposed', 'Private file(s) reachable from the internet', 'Anyone can open: ' . implode( ', ', $bad ) . '. The Claude fixer must move or delete them and block the path.', 'high', 'needs_claude' );
			$rows[] = array( 'fail', 'Private file(s) are public', implode( ', ', $bad ) );
		} else {
			self::ok( 'sec_exposed' );
			$rows[] = array( 'pass', 'No backup, secret or log file is reachable', '' );
		}
		return $rows;
	}

	private static function c_core() {
		if ( get_transient( 'mrsh_secbot_core' ) ) {
			$l = get_option( self::LAST, array() );
			foreach ( (array) ( $l['rows'] ?? array() ) as $r ) {
				if ( false !== strpos( $r[1], 'WordPress core' ) ) {
					return array( $r );
				}
			}
			return array();
		}
		set_transient( 'mrsh_secbot_core', 1, DAY_IN_SECONDS );
		global $wp_version;
		$r = wp_remote_get( 'https://api.wordpress.org/core/checksums/1.0/?version=' . rawurlencode( $wp_version ) . '&locale=' . rawurlencode( get_locale() ), array( 'timeout' => 20 ) );
		$j = is_wp_error( $r ) ? null : json_decode( wp_remote_retrieve_body( $r ), true );
		if ( empty( $j['checksums'] ) || ! is_array( $j['checksums'] ) ) {
			return array( array( 'warn', 'WordPress core check could not run today', 'The checksum list was not reachable. It tries again tomorrow.' ) );
		}
		$bad = array();
		foreach ( $j['checksums'] as $file => $md5 ) {
			if ( 0 !== strpos( $file, 'wp-admin/' ) && 0 !== strpos( $file, 'wp-includes/' ) ) {
				continue;
			}
			$p = ABSPATH . $file;
			if ( is_file( $p ) && md5_file( $p ) !== $md5 ) {
				$bad[] = $file;
			}
		}
		if ( $bad ) {
			self::fx( 'sec_core', count( $bad ) . ' WordPress core file(s) changed', 'These files differ from the official release: ' . implode( ', ', array_slice( $bad, 0, 8 ) ) . '. This can mean a hack. The Claude fixer will reinstall core files.', 'high', 'needs_claude' );
			return array( array( 'fail', count( $bad ) . ' WordPress core file(s) changed', implode( ', ', array_slice( $bad, 0, 5 ) ) ) );
		}
		self::ok( 'sec_core' );
		return array( array( 'pass', 'WordPress core files match the official release', '' ) );
	}

	/* ---------- AI report ---------- */

	private static function ai_report( $rows, $o ) {
		if ( empty( $o['ai'] ) || ! class_exists( 'MRSH_AIHub' ) || ! MRSH_AIHub::ready() ) {
			return '';
		}
		$prev = get_option( self::LAST, array() );
		if ( ! empty( $prev['ai'] ) && time() - (int) ( $prev['t'] ?? 0 ) < 20 * HOUR_IN_SECONDS && empty( $GLOBALS['mrsh_secbot_force'] ) ) {
			return (string) $prev['ai'];
		}
		$facts = '';
		foreach ( $rows as $r ) {
			$facts .= strtoupper( $r[0] ) . ': ' . $r[1] . ( $r[2] ? ' (' . $r[2] . ')' : '' ) . "\n";
		}
		$ev = 0;
		foreach ( (array) get_option( 'mrsh_shield_log', array() ) as $e ) {
			if ( is_array( $e ) && time() - (int) $e[0] < DAY_IN_SECONDS ) {
				++$ev;
			}
		}
		$facts .= 'Security log events in the last 24 hours: ' . $ev . "\n";
		$a = MRSH_AIHub::ask( 'You are the security assistant of a small non-profit matrimonial website. Write a short plain-English report for a busy, non-technical owner: at most 5 bullet points starting with "- ", say what is fine, what needs attention and what to do first. Use only the facts given, invent nothing. Last line exactly: RISK: low or RISK: medium or RISK: high.', $facts, 350 );
		if ( is_wp_error( $a ) ) {
			return '';
		}
		if ( preg_match( '/RISK:\s*high/i', $a ) ) {
			self::fx( 'sec_ai_high', 'Security report says: high risk', wp_strip_all_tags( $a ), 'high', 'needs_approval' );
		} else {
			self::ok( 'sec_ai_high' );
		}
		return wp_strip_all_tags( $a );
	}

	/* ---------- handlers ---------- */

	private static function guard( $n ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( $n );
	}

	private static function back( $m ) {
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&done=' . rawurlencode( $m ) ) );
		exit;
	}

	public static function h_save() {
		self::guard( 'mrsh_secbot_save' );
		update_option( self::OPT, array(
			'on'   => empty( $_POST['on'] ) ? 0 : 1, // phpcs:ignore
			'ai'   => empty( $_POST['ai'] ) ? 0 : 1, // phpcs:ignore
			'auto' => empty( $_POST['auto'] ) ? 0 : 1, // phpcs:ignore
		), false );
		self::back( 'Saved.' );
	}

	public static function h_now() {
		self::guard( 'mrsh_secbot_now' );
		delete_transient( 'mrsh_secbot_core' );
		$GLOBALS['mrsh_secbot_force'] = 1;
		$rows = self::scan();
		$bad  = 0;
		foreach ( $rows as $r ) {
			if ( 'pass' !== $r[0] ) {
				++$bad;
			}
		}
		self::back( 'Scan finished: ' . count( $rows ) . ' checks, ' . $bad . ' need a look.' );
	}

	public static function h_known() {
		self::guard( 'mrsh_secbot_known' );
		update_option( self::KNOWN, array_map( 'intval', get_users( array( 'role' => 'administrator', 'fields' => 'ID', 'number' => 200 ) ) ), false );
		self::back( 'Today\'s administrators are now trusted.' );
	}

	public static function h_quar() {
		self::guard( 'mrsh_secbot_quar' );
		self::back( self::quarantine() );
	}

	/* ---------- page ---------- */

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$o    = self::o();
		$l    = get_option( self::LAST, array() );
		$rows = (array) ( $l['rows'] ?? array() );
		$pass = 0;
		foreach ( $rows as $r ) {
			if ( 'pass' === $r[0] ) {
				++$pass;
			}
		}
		$tot  = count( $rows );
		$open = 0;
		if ( class_exists( 'MRSH_Fixer' ) ) {
			foreach ( MRSH_Fixer::tickets() as $t ) {
				if ( 0 === strpos( (string) ( $t['key'] ?? '' ), 'sec' ) && in_array( $t['status'], array( 'needs_approval', 'needs_claude' ), true ) ) {
					++$open;
				}
			}
		}
		$post = esc_url( admin_url( 'admin-post.php' ) );
		MRSH_Admin::open( 'Security Robot', 'Watches the site every hour, fixes the safe things by itself and sends tickets for the rest.' );
		if ( ! empty( $_GET['done'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( wp_unslash( $_GET['done'] ) ) . '</p></div>'; // phpcs:ignore
		}
		echo '<div class="mrsh-grid mrsh-grid-4">';
		echo MRSH_Admin::stat( 'Robot', $o['on'] ? 'On' : 'Off', 'scans every hour' ); // phpcs:ignore
		echo MRSH_Admin::stat( 'Checks passing', $tot ? $pass . ' / ' . $tot : '-', $tot ? 'last scan ' . human_time_diff( (int) $l['t'] ) . ' ago' : 'no scan yet' ); // phpcs:ignore
		echo MRSH_Admin::stat( 'Open security tickets', $open, 'see Auto-Fixer' ); // phpcs:ignore
		echo MRSH_Admin::stat( 'AI report', ! empty( $l['ai'] ) ? 'Ready' : 'None', class_exists( 'MRSH_AIHub' ) && MRSH_AIHub::ready() ? 'written daily' : 'needs an AI key' ); // phpcs:ignore
		echo '</div>';

		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Actions</h2></div><div class="mrsh-actions">';
		foreach ( array( 'now' => array( 'Scan now', true ), 'known' => array( 'I know these administrators', false ), 'quar' => array( 'Quarantine PHP files in uploads', false ) ) as $a => $d ) {
			echo '<form method="post" action="' . $post . '" class="mrsh-inline">';
			wp_nonce_field( 'mrsh_secbot_' . $a );
			echo '<input type="hidden" name="action" value="mrsh_secbot_' . esc_attr( $a ) . '"><button class="button' . ( $d[1] ? ' button-primary' : '' ) . '">' . esc_html( $d[0] ) . '</button></form> ';
		}
		if ( class_exists( 'MRSH_Fixer' ) ) {
			echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=mrsh-fixer' ) ) . '">Open tickets</a> ';
		}
		echo '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=mrsh-shield' ) ) . '">Security Shield</a></div></div>';

		if ( ! empty( $l['ai'] ) ) {
			echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>AI security report</h2></div><div style="white-space:pre-line">' . esc_html( $l['ai'] ) . '</div></div>';
		}

		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Last scan</h2></div>';
		if ( ! $rows ) {
			echo '<p class="mrsh-muted">No scan has run yet. Press "Scan now".</p>';
		} else {
			echo '<table class="mrsh-table"><thead><tr><th>Check</th><th>Result</th><th>Detail</th></tr></thead><tbody>';
			foreach ( $rows as $r ) {
				echo '<tr data-attn="' . ( 'pass' === $r[0] ? '0' : '1' ) . '"><td>' . esc_html( $r[1] ) . '</td><td>' . MRSH_Admin::badge( $r[0], 'pass' === $r[0] ? 'OK' : ( 'warn' === $r[0] ? 'Look' : 'Act' ) ) . '</td><td class="mrsh-muted">' . esc_html( $r[2] ) . '</td></tr>'; // phpcs:ignore
			}
			echo '</tbody></table>';
		}
		echo '</div>';

		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Settings</h2></div><form method="post" action="' . $post . '">';
		wp_nonce_field( 'mrsh_secbot_save' );
		echo '<input type="hidden" name="action" value="mrsh_secbot_save">';
		echo '<p><label><input type="checkbox" name="on" value="1"' . checked( $o['on'], 1, false ) . '> Security Robot on</label></p>';
		echo '<p><label><input type="checkbox" name="auto" value="1"' . checked( $o['auto'], 1, false ) . '> Fix safe things by itself (switch Shield basics back on, block PHP in uploads, remove a public debug.log)</label></p>';
		echo '<p><label><input type="checkbox" name="ai" value="1"' . checked( $o['ai'], 1, false ) . '> Let the AI write a daily plain-language report (uses the AI Assistant key; no personal data is sent)</label></p>';
		echo '<button class="button button-primary">Save</button></form></div>';
		MRSH_Admin::close();
	}
}
MRSH_SecBot::init();
