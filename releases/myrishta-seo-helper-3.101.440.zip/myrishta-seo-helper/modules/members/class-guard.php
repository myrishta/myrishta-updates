<?php
/**
 * Security and places (3.101.152):
 * - warns when a member logs in from a new country or from an IP that many accounts share (flags in the Activity log),
 * - login history with places in the Member manager,
 * - block list by IP and by country (admins are never blocked),
 * - a "where members are" report by country and city,
 * - a daily summary email to the admin, and ticket reminders.
 * Places come from MRSH_Act::geo() (free ipwho.is lookup, cached). Switches: Feature switches (geoip, guard, block, daily).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Guard {

	const OPT  = 'mrsh_guard';
	const SLUG = 'mrsh-guard';
	const CRON = 'mrsh_guard_hourly';
	const DAY  = 'mrsh_guard_daily';

	public static function get() {
		$o = get_option( self::OPT, array() );
		return array_merge( array( 'ips' => '', 'ccs' => '', 'shared' => 3 ), is_array( $o ) ? $o : array() );
	}

	private static function on( $k ) {
		return ! class_exists( 'MRSH_Switch' ) || MRSH_Switch::on( $k );
	}

	public static function init() {
		add_action( 'wp_login', array( __CLASS__, 'on_login' ), 20, 2 );
		add_filter( 'authenticate', array( __CLASS__, 'gate' ), 40, 3 );
		add_filter( 'registration_errors', array( __CLASS__, 'gate_reg' ), 10, 1 );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
		add_action( self::CRON, array( __CLASS__, 'hourly' ) );
		add_action( self::DAY, array( __CLASS__, 'daily' ) );
		if ( is_admin() ) {
			add_action( 'admin_menu', array( __CLASS__, 'menu' ), 24 );
			add_action( 'admin_post_mrsh_guard_save', array( __CLASS__, 'save' ) );
			add_action( 'admin_post_mrsh_guard_fill', array( __CLASS__, 'fill' ) );
		}
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::CRON ) ) {
			wp_schedule_event( time() + 300, 'hourly', self::CRON );
		}
		if ( ! wp_next_scheduled( self::DAY ) ) {
			$t = strtotime( 'tomorrow 07:00', current_time( 'timestamp' ) ); // phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp
			wp_schedule_event( $t - (int) ( current_time( 'timestamp' ) - time() ), 'daily', self::DAY ); // phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp
		}
	}

	public static function hourly() {
		if ( class_exists( 'MRSH_Tickets' ) ) {
			MRSH_Tickets::remind_run();
		}
	}

	/* ---------- lists ---------- */

	private static function lines( $s ) {
		return array_values( array_filter( array_map( 'trim', preg_split( '/[\s,;]+/', (string) $s ) ) ) );
	}

	public static function ip_blocked( $ip ) {
		return $ip && in_array( $ip, self::lines( self::get()['ips'] ), true );
	}

	public static function add_ip( $ip ) {
		if ( ! current_user_can( 'manage_options' ) || ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			return 'Not a valid IP.';
		}
		$o   = self::get();
		$all = self::lines( $o['ips'] );
		if ( ! in_array( $ip, $all, true ) ) {
			$all[] = $ip;
		}
		$o['ips'] = implode( "\n", $all );
		update_option( self::OPT, $o, false );
		return 'IP ' . $ip . ' is now blocked from login and sign up.';
	}

	/* ---------- login watch ---------- */

	/** The login watch (place lookup, flag mail) runs after the page has been sent, so a slow lookup can never keep the member waiting. */
	public static function on_login( $login, $user ) {
		if ( ! $user || user_can( $user, 'manage_options' ) || ! class_exists( 'MRSH_Act' ) ) {
			return;
		}
		add_action( 'shutdown', function () use ( $login, $user ) {
			ignore_user_abort( true );
			if ( function_exists( 'litespeed_finish_request' ) ) {
				litespeed_finish_request();
			} elseif ( function_exists( 'fastcgi_finish_request' ) ) {
				fastcgi_finish_request();
			}
			self::watch_login( $login, $user );
		}, 1 );
	}

	public static function watch_login( $login, $user ) {
		$ip = MRSH_Act::ip();
		if ( '' === $ip ) {
			return;
		}
		$uid = (int) $user->ID;
		global $wpdb;
		if ( self::on( 'guard' ) ) {
			// Same IP used by many accounts.
			$n = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(DISTINCT uid) FROM ' . MRSH_Act::tbl() . " WHERE ip=%s AND type='login' AND created > %d", $ip, time() - 30 * DAY_IN_SECONDS ) ); // phpcs:ignore WordPress.DB
			$lim = max( 2, (int) self::get()['shared'] );
			if ( $n >= $lim && ! get_transient( 'mrsh_gs_' . md5( $uid . $ip ) ) ) {
				set_transient( 'mrsh_gs_' . md5( $uid . $ip ), 1, 7 * DAY_IN_SECONDS );
				MRSH_Act::log( $uid, 'login', 0, 0, 'This IP was used by ' . $n . ' different accounts in 30 days (note only, not a flag)', 0, '' );
				self::event( 'shared', $uid, $ip );
			}
		}
		if ( ! self::on( 'geoip' ) ) {
			return;
		}
		$b = 1;
		$g = MRSH_Act::geo( $ip, $b );
		if ( ! $g || empty( $g['cc'] ) ) {
			return;
		}
		$prev = (string) get_user_meta( $uid, 'mrsh_lc', true );
		$when = (int) get_user_meta( $uid, 'mrsh_lt', true );
		if ( self::on( 'guard' ) && $prev && $prev !== $g['cc'] && time() - $when < DAY_IN_SECONDS ) {
			MRSH_Act::log( $uid, 'login', 0, 0, 'Login from ' . $g['place'] . ' (last login was from ' . $prev . ')', 1, 'Login from a new country' );
			self::event( 'newcountry', $uid, $ip );
		} elseif ( 'PK' !== $g['cc'] ) {
			self::event( 'abroad', $uid, $ip );
		}
		update_user_meta( $uid, 'mrsh_lc', $g['cc'] );
		update_user_meta( $uid, 'mrsh_lplace', $g['place'] );
		update_user_meta( $uid, 'mrsh_lt', time() );
	}

	private static function event( $type, $uid, $ip ) {
		$e   = get_option( 'mrsh_guard_ev', array() );
		$e   = is_array( $e ) ? $e : array();
		$e[] = array( time(), $type, (int) $uid, $ip );
		update_option( 'mrsh_guard_ev', array_slice( $e, -300 ), false );
	}

	/* ---------- blocking ---------- */

	private static function blocked_now() {
		if ( ! self::on( 'block' ) || ! class_exists( 'MRSH_Act' ) ) {
			return false;
		}
		$ip = MRSH_Act::ip();
		if ( '' === $ip ) {
			return false;
		}
		if ( self::ip_blocked( $ip ) ) {
			return true;
		}
		$ccs = array_map( 'strtoupper', self::lines( self::get()['ccs'] ) );
		if ( $ccs ) {
			$b = 1;
			$g = MRSH_Act::geo( $ip, $b );
			if ( $g && ! empty( $g['cc'] ) && in_array( $g['cc'], $ccs, true ) ) {
				return true;
			}
		}
		return false;
	}

	public static function gate( $user, $login, $pass ) {
		if ( $user instanceof WP_User && ! user_can( $user, 'manage_options' ) && self::blocked_now() ) {
			return new WP_Error( 'mrsh_blocked', 'Login from your location is not allowed. If this is a mistake, please contact us.' );
		}
		return $user;
	}

	public static function gate_reg( $errors ) {
		if ( self::blocked_now() ) {
			$errors->add( 'mrsh_blocked', 'Sign up from your location is not allowed. If this is a mistake, please contact us.' );
		}
		return $errors;
	}

	/* ---------- bits shown in other screens ---------- */

	/** Under an IP in the Activity log: how many accounts used it, link to filter, Block IP button. */
	public static function ip_tools( $ip ) {
		if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			return '';
		}
		global $wpdb;
		$n   = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(DISTINCT uid) FROM ' . MRSH_Act::tbl() . ' WHERE ip=%s AND created > %d', $ip, time() - 30 * DAY_IN_SECONDS ) ); // phpcs:ignore WordPress.DB
		$out = '';
		if ( $n >= 2 ) {
			$out .= '<br><a href="' . esc_url( admin_url( 'admin.php?page=mrsh-activity&ip=' . rawurlencode( $ip ) ) ) . '"><b>' . $n . ' accounts</b> used this IP</a>';
		}
		if ( self::on( 'block' ) ) {
			$out .= '<br>' . ( self::ip_blocked( $ip ) ? '<span class="mx-pill bad">IP blocked</span>' : '<button name="bip" value="' . esc_attr( $ip ) . '" class="mx-btn s d" onclick="return confirm(\'Block this IP from login and sign up?\')">Block IP</button>' );
		}
		return $out;
	}

	/** Member manager box: last logins with place. */
	public static function history( $uid ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT ip,created FROM ' . MRSH_Act::tbl() . " WHERE uid=%d AND type='login' ORDER BY id DESC LIMIT 8", $uid ) ); // phpcs:ignore WordPress.DB
		$out  = '<p style="margin:8px 0 4px"><b>Where they logged in from</b>';
		if ( ! $rows ) {
			return $out . '<br><span class="description">No login recorded yet.</span></p>';
		}
		$b = 4;
		foreach ( $rows as $r ) {
			$g   = self::on( 'geoip' ) ? MRSH_Act::geo( (string) $r->ip, $b ) : null;
			$cc  = $g && ! empty( $g['cc'] ) ? $g['cc'] : '';
			$out .= '<br>' . esc_html( wp_date( 'j M H:i', (int) $r->created ) ) . ' &middot; ' . esc_html( $r->ip ) . ( $g ? ' &middot; <b>' . esc_html( $g['place'] ) . '</b>' . ( $cc && 'PK' !== $cc ? ' <span class="mx-pill bad">Outside Pakistan</span>' : '' ) : '' );
		}
		return $out . '</p>';
	}

	/* ---------- admin page ---------- */

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Security and places', 'Security and places', 'manage_options', self::SLUG, array( __CLASS__, 'page' ) );
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_guard' );
		$o           = self::get();
		$ips         = array_filter( self::lines( sanitize_textarea_field( wp_unslash( $_POST['ips'] ?? '' ) ) ), function ( $i ) {
			return filter_var( $i, FILTER_VALIDATE_IP );
		} );
		$ccs         = array_filter( array_map( 'strtoupper', self::lines( sanitize_text_field( wp_unslash( $_POST['ccs'] ?? '' ) ) ) ), function ( $c ) {
			return (bool) preg_match( '/^[A-Z]{2}$/', $c );
		} );
		$o['ips']    = implode( "\n", $ips );
		$o['ccs']    = implode( ', ', $ccs );
		$o['shared'] = max( 2, min( 50, absint( $_POST['shared'] ?? 3 ) ) );
		update_option( self::OPT, $o, false );
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&ok=1' ) );
		exit;
	}

	/** Look up the places of members' last logins (up to 25 new addresses per press). */
	public static function fill() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_guard_fill' );
		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT uid, ip, MAX(created) c FROM ' . MRSH_Act::tbl() . " WHERE type='login' AND ip<>'' GROUP BY uid, ip ORDER BY c DESC LIMIT 400" ); // phpcs:ignore WordPress.DB
		$b    = 25;
		$seen = array();
		$done = 0;
		foreach ( $rows as $r ) {
			if ( isset( $seen[ $r->uid ] ) ) {
				continue;
			}
			$g = MRSH_Act::geo( (string) $r->ip, $b );
			if ( $g && ! empty( $g['cc'] ) ) {
				$seen[ $r->uid ] = 1;
				update_user_meta( (int) $r->uid, 'mrsh_lc', $g['cc'] );
				update_user_meta( (int) $r->uid, 'mrsh_lplace', $g['place'] );
				$done++;
			}
			if ( $b <= 0 ) {
				break;
			}
		}
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&filled=' . $done ) );
		exit;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		global $wpdb;
		$o = self::get();
		MRSH_Boost::ui_open( 'Security and places', 'Where members log in from, who to block, and warnings. Warnings appear as red flags in the Activity log.', 'g-red', 'M12 2l9 4v6c0 5-4 9-9 10-5-1-9-5-9-10V6l9-4z' );
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			MRSH_Boost::ui_ok( 'Saved.' );
		}
		if ( isset( $_GET['filled'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			MRSH_Boost::ui_ok( 'Places found for ' . (int) $_GET['filled'] . ' members. Press again to continue if some are missing.' ); // phpcs:ignore WordPress.Security.NonceVerification
		}
		// Report.
		$known = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT user_id) FROM {$wpdb->usermeta} WHERE meta_key='mrsh_lc' AND meta_value<>''" ); // phpcs:ignore WordPress.DB
		$total = (int) count_users()['total_users'];
		$cc    = $wpdb->get_results( "SELECT meta_value v, COUNT(*) n FROM {$wpdb->usermeta} WHERE meta_key='mrsh_lc' AND meta_value<>'' GROUP BY meta_value ORDER BY n DESC LIMIT 15" ); // phpcs:ignore WordPress.DB
		$pl    = $wpdb->get_results( "SELECT meta_value v, COUNT(*) n FROM {$wpdb->usermeta} WHERE meta_key='mrsh_lplace' AND meta_value<>'' GROUP BY meta_value ORDER BY n DESC LIMIT 20" ); // phpcs:ignore WordPress.DB
		echo '<div class="mx-card"><h2>Where members are</h2><p class="description">Based on the place of each member\'s last login. Known for ' . (int) $known . ' of ' . (int) $total . ' accounts.</p>';
		echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px"><div><h3>Countries</h3><table class="widefat striped"><tbody>';
		foreach ( $cc as $r ) {
			$fl = 2 === strlen( $r->v ) ? mb_chr( 0x1F1E6 + ord( $r->v[0] ) - 65, 'UTF-8' ) . mb_chr( 0x1F1E6 + ord( $r->v[1] ) - 65, 'UTF-8' ) . ' ' : '';
			echo '<tr><td>' . esc_html( $fl . $r->v ) . '</td><td><b>' . (int) $r->n . '</b></td></tr>';
		}
		if ( ! $cc ) {
			echo '<tr><td>Nothing yet</td></tr>';
		}
		echo '</tbody></table></div><div><h3>Cities</h3><table class="widefat striped"><tbody>';
		foreach ( $pl as $r ) {
			echo '<tr><td>' . esc_html( $r->v ) . '</td><td><b>' . (int) $r->n . '</b></td></tr>';
		}
		if ( ! $pl ) {
			echo '<tr><td>Nothing yet</td></tr>';
		}
		echo '</tbody></table></div></div><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin-top:12px"><input type="hidden" name="action" value="mrsh_guard_fill">' . wp_nonce_field( 'mrsh_guard_fill', '_wpnonce', true, false ) . '<button class="button mx-btn">Find places for earlier logins</button> <span class="description">Fills the lists above from the Activity log (25 lookups each press).</span></form></div>';
		// Block lists.
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_guard_save">' . wp_nonce_field( 'mrsh_guard', '_wpnonce', true, false );
		echo '<div class="mx-card"><h2>Block list</h2><p class="description">Blocked people cannot log in or register. Admins are never blocked. Turn the whole feature on or off in Feature switches (Block by IP and country).</p><table class="form-table" role="presentation">';
		echo '<tr><th>Blocked IP addresses</th><td><textarea name="ips" rows="5" class="large-text" placeholder="One IP per line">' . esc_textarea( $o['ips'] ) . '</textarea></td></tr>';
		echo '<tr><th>Blocked countries</th><td><input type="text" name="ccs" value="' . esc_attr( $o['ccs'] ) . '" class="regular-text" placeholder="e.g. NG, GH"> <span class="description">Two-letter country codes, separated by commas. Be careful: Pakistani families abroad use these countries too.</span></td></tr>';
		echo '<tr><th>Same-IP warning at</th><td><input type="number" name="shared" min="2" max="50" value="' . (int) $o['shared'] . '" style="width:80px"> accounts <span class="description">Flag a login when this many different accounts used the same IP in 30 days.</span></td></tr>';
		echo '</table><p><button class="button button-primary mx-btn">Save</button></p></div></form></div>';
	}

	/* ---------- daily summary ---------- */

	public static function daily() {
		if ( ! self::on( 'daily' ) ) {
			return;
		}
		global $wpdb;
		$since = time() - DAY_IN_SECONDS;
		$new   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->users} WHERE user_registered > %s", gmdate( 'Y-m-d H:i:s', $since ) ) ); // phpcs:ignore WordPress.DB
		$pend  = (int) ( wp_count_posts( 'listing_type' )->pending ?? 0 );
		$tk    = 0;
		if ( class_exists( 'MRSH_Tickets' ) ) {
			$tk = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . MRSH_Tickets::t1() . " WHERE status IN ('open','progress','waiting')" ); // phpcs:ignore WordPress.DB
		}
		$fl = class_exists( 'MRSH_Act' ) ? (int) MRSH_Act::open_flags() : 0;
		$lg = class_exists( 'MRSH_Act' ) ? (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . MRSH_Act::tbl() . " WHERE type='login' AND created > %d", $since ) ) : 0; // phpcs:ignore WordPress.DB
		$ev = get_option( 'mrsh_guard_ev', array() );
		$ab = 0;
		$nc = 0;
		$sh = 0;
		foreach ( is_array( $ev ) ? $ev : array() as $e ) {
			if ( (int) $e[0] < $since ) {
				continue;
			}
			if ( 'abroad' === $e[1] ) {
				$ab++;
			} elseif ( 'newcountry' === $e[1] ) {
				$nc++;
			} elseif ( 'shared' === $e[1] ) {
				$sh++;
			}
		}
		$body = "Good morning,\n\nYesterday on " . get_bloginfo( 'name' ) . ":\n\n"
			. '- New members: ' . $new . "\n"
			. '- Profiles waiting for approval: ' . $pend . "\n"
			. '- Open support tickets: ' . $tk . "\n"
			. '- Flags to review in the Activity log: ' . $fl . "\n"
			. '- Logins: ' . $lg . "\n"
			. '- Logins from outside Pakistan: ' . $ab . "\n"
			. '- Logins from a new country: ' . $nc . "\n"
			. '- Same-IP warnings: ' . $sh . "\n\n"
			. 'Activity log: ' . admin_url( 'admin.php?page=mrsh-activity' ) . "\nTickets: " . admin_url( 'admin.php?page=mrsh-tickets' ) . "\n\nTurn this email off in Feature switches (Daily summary email).";
		wp_mail( get_option( 'admin_email' ), 'My Rishta daily summary', $body );
	}
}
MRSH_Guard::init();
