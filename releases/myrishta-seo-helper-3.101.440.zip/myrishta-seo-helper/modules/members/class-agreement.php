<?php
/**
 * Agreement letter: a printable A4 letter (English + Urdu) that records what the groom, the bride and their guardians agreed before the nikah,
 * to be attached to the Nikah Nama application at the registrar. Printed on the My Rishta letterhead (header, footer, centre watermark).
 * Everything is typed in the browser and printed from there: when the letter is printed the site keeps the reference, the member, the dates and the typed details (ID numbers shortened).
 * Opens for any logged-in member (their own letter) and for the admin. Also prints a blank letterhead.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Agreement {

	const SLUG = 'mrsh-agreement';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 31 );
		add_action( 'admin_post_mrsh_agreement', array( __CLASS__, 'view' ) );
		add_action( 'mrt_account_extra', array( __CLASS__, 'account' ), 47 );
		add_action( 'mrt_account_extra', array( __CLASS__, 'account_refs' ), 48 );
		add_action( 'admin_post_mrsh_agr_mark', array( __CLASS__, 'mark' ) );
		add_action( 'admin_post_mrsh_agr_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_mrsh_agr_csv', array( __CLASS__, 'csv' ) );
		add_action( 'admin_post_mrsh_agr_opt', array( __CLASS__, 'opt_save' ) );
		add_action( 'template_redirect', array( __CLASS__, 'verify_page' ), 6 );
		add_action( 'template_redirect', array( __CLASS__, 'copy_page' ), 6 );
		add_action( 'mrsh_agr_cron', array( __CLASS__, 'cron' ) );
		add_action( 'init', function () {
			if ( ! wp_next_scheduled( 'mrsh_agr_cron' ) ) {
				wp_schedule_event( time() + 600, 'twicedaily', 'mrsh_agr_cron' );
			}
		} );
	}

	const DBV = '4';

	private static function table() {
		global $wpdb;
		return $wpdb->prefix . 'mrsh_agreements';
	}

	/** Create the table once (and again if it is missing, for example after a restore). */
	private static function install() {
		global $wpdb;
		$t = self::table();
		if ( get_option( 'mrsh_agr_dbv' ) === self::DBV && $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $t ) ) === $t ) { // phpcs:ignore
			return;
		}
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( 'CREATE TABLE ' . $t . ' (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  ref varchar(40) NOT NULL,
  uid bigint(20) unsigned NOT NULL DEFAULT 0,
  created datetime NOT NULL,
  printed datetime DEFAULT NULL,
  status varchar(12) NOT NULL DEFAULT \'issued\',
  stamped datetime DEFAULT NULL,
  note varchar(120) NOT NULL DEFAULT \'\',
  data longtext,
  letter longtext,
  pay longtext,
  remind_at datetime DEFAULT NULL,
  remind_n int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY  (id),
  UNIQUE KEY ref (ref),
  KEY uid (uid)
) ' . $wpdb->get_charset_collate() . ';' );
		update_option( 'mrsh_agr_dbv', self::DBV, false );
	}

	private static function pays( $j ) {
		$a = json_decode( $j, true );
		return is_array( $a ) ? $a : array();
	}

	private static function pay_total( $e ) {
		$t = 0;
		foreach ( $e['p'] as $p ) {
			$t += (float) ( $p['amt'] ?? 0 );
		}
		return $t;
	}

	/** Payment history as a small table with receipt links. */
	private static function pay_html( $e ) {
		if ( empty( $e['p'] ) ) {
			return '';
		}
		$h = '<details open style="margin-top:6px"><summary><b>Payments</b> (total Rs ' . esc_html( number_format_i18n( self::pay_total( $e ) ) ) . ')</summary><table class="widefat" style="margin-top:6px"><thead><tr><th>Date</th><th>Amount</th><th>Method</th><th>Transaction ID</th><th>Note</th><th>Receipt</th></tr></thead><tbody>';
		foreach ( $e['p'] as $p ) {
			$att = '';
			foreach ( (array) ( $p['att'] ?? array() ) as $id ) {
				$u = wp_get_attachment_url( (int) $id );
				if ( $u ) {
					$att .= '<a href="' . esc_url( $u ) . '" target="_blank" rel="noopener">' . ( wp_attachment_is_image( (int) $id ) ? '<img src="' . esc_url( $u ) . '" style="height:38px;border-radius:4px;vertical-align:middle">' : 'File' ) . '</a> ';
				}
			}
			$h .= '<tr><td>' . esc_html( wp_date( 'j M Y H:i', (int) ( $p['t'] ?? 0 ) ) ) . '</td><td>' . ( isset( $p['amt'] ) && '' !== $p['amt'] ? 'Rs ' . esc_html( number_format_i18n( (float) $p['amt'] ) ) : '' ) . '</td><td>' . esc_html( $p['meth'] ?? '' ) . '</td><td>' . esc_html( $p['tid'] ?? '' ) . '</td><td>' . esc_html( $p['note'] ?? '' ) . '</td><td>' . ( $att ?: '-' ) . '</td></tr>';
		}
		return $h . '</tbody></table></details>';
	}

	private static function shape( $r ) {
		return array(
			'id' => (int) $r->id, 'r' => $r->ref, 'u' => (int) $r->uid, 't' => (int) strtotime( $r->created . ' UTC' ), 'st' => $r->status, 'n' => $r->note,
			'at' => $r->stamped ? (int) strtotime( $r->stamped . ' UTC' ) : 0, 'pt' => $r->printed ? (int) strtotime( $r->printed . ' UTC' ) : 0, 'd' => (string) $r->data, 'l' => (string) ( $r->letter ?? '' ), 'p' => self::pays( (string) ( $r->pay ?? '' ) ), 'ra' => ! empty( $r->remind_at ) ? (int) strtotime( $r->remind_at . ' UTC' ) : 0, 'rn' => (int) ( $r->remind_n ?? 0 ),
		);
	}

	/** Save a reference so it can be found later. */
	private static function log_ref( $ref, $uid ) {
		global $wpdb;
		self::install();
		$wpdb->insert( self::table(), array( 'ref' => $ref, 'uid' => (int) $uid, 'created' => gmdate( 'Y-m-d H:i:s' ), 'status' => 'issued' ) ); // phpcs:ignore
	}

	private static function find( $ref ) {
		global $wpdb;
		self::install();
		$r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE ref = %s', $ref ) ); // phpcs:ignore
		return $r ? array( (int) $r->id, self::shape( $r ) ) : null;
	}

	/** Newest first. $uid 0 = everyone. */
	private static function rows( $uid = 0, $limit = 100 ) {
		global $wpdb;
		self::install();
		$sql = 'SELECT * FROM ' . self::table() . ( $uid ? $wpdb->prepare( ' WHERE uid = %d', $uid ) : '' ) . ' ORDER BY id DESC LIMIT ' . (int) $limit; // phpcs:ignore
		return array_map( array( __CLASS__, 'shape' ), (array) $wpdb->get_results( $sql ) ); // phpcs:ignore
	}

	private static function labels() {
		return array(
			'gn' => 'Groom: name', 'gf' => 'Groom: father', 'ga' => 'Groom: age', 'gc' => 'Groom: CNIC', 'gcity' => 'Groom: city',
			'bn' => 'Bride: name', 'bf' => 'Bride: father', 'ba' => 'Bride: age', 'bc' => 'Bride: CNIC', 'bcity' => 'Bride: city',
			'gg' => 'Groom guardian', 'bg' => 'Bride guardian', 'nd' => 'Nikah date', 'np' => 'Place of nikah', 'nr' => 'Registrar / Union Council',
			'hm' => 'Haq Mehr', 'ht' => 'How paid', 'jz' => 'Gifts and jahez', 'res' => 'Residence', 'job' => 'Study / job', 'exp' => 'Walima and expenses',
			'oth' => 'Other conditions', 'w1' => 'Witness 1', 'w2' => 'Witness 2', 'sd' => 'Place and date of signing', 'wa' => 'Contact WhatsApp number',
		);
	}

	/** Shorten ID numbers to their last digits unless the admin chose to keep them. */
	private static function mask( $v ) {
		if ( get_option( 'mrsh_agr_cnic', 1 ) ) {
			return $v;
		}
		return preg_replace( '/\b(\d{5})-?(\d{3})(\d{4})-?(\d)\b/', '*****-***$3-$4', $v );
	}

	/** Called when the member prints: keeps what was typed so the reference can be matched to the letter later. */
	public static function save() {
		if ( ! is_user_logged_in() || ! check_admin_referer( 'mrsh_agr_save' ) ) {
			wp_send_json( array( 'ok' => false ) );
		}
		$ref = sanitize_text_field( wp_unslash( $_POST['ref'] ?? '' ) ); // phpcs:ignore
		$f   = self::find( $ref );
		if ( ! $f || 'rejected' === $f[1]['st'] || ( (int) $f[1]['u'] !== get_current_user_id() && ! current_user_can( 'manage_options' ) ) ) {
			wp_send_json( array( 'ok' => false ) );
		}
		$in  = json_decode( (string) wp_unslash( $_POST['data'] ?? '' ), true ); // phpcs:ignore
		$out = array();
		if ( is_array( $in ) ) {
			foreach ( self::labels() as $k => $l ) {
				if ( isset( $in[ $k ] ) && '' !== trim( (string) $in[ $k ] ) ) {
					$out[ $k ] = self::mask( mb_substr( sanitize_textarea_field( (string) $in[ $k ] ), 0, 1500 ) );
				}
			}
		}
		global $wpdb;
		$row = array( 'data' => wp_json_encode( $out, JSON_UNESCAPED_UNICODE ), 'letter' => self::mask( mb_substr( sanitize_textarea_field( wp_unslash( $_POST['letter'] ?? '' ) ), 0, 40000 ) ) ); // phpcs:ignore
		if ( ! empty( $_POST['p'] ) ) { // phpcs:ignore
			$row['printed'] = gmdate( 'Y-m-d H:i:s' );
			if ( empty( $f[1]['pt'] ) ) {
				do_action( 'mrsh_agreement_printed', $f[1]['r'], (int) $f[1]['u'] );
			}
		}
		$wpdb->update( self::table(), $row, array( 'id' => $f[0] ) ); // phpcs:ignore
		wp_send_json( array( 'ok' => true ) );
	}

	public static function opt_save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_agr_opt' );
		update_option( 'mrsh_agr_cnic', empty( $_POST['cnic'] ) ? 0 : 1, false ); // phpcs:ignore
		update_option( 'mrsh_agr_pay_info', sanitize_textarea_field( wp_unslash( $_POST['payinfo'] ?? '' ) ), false ); // phpcs:ignore
		update_option( 'mrsh_agr_wa_hook', esc_url_raw( trim( wp_unslash( $_POST['wahook'] ?? '' ) ) ), false ); // phpcs:ignore
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG ) );
		exit;
	}

	/** Admin: mark a letter as stamped and signed (payment received), or undo. */
	public static function mark() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_agr_mark' );
		$f = self::find( sanitize_text_field( wp_unslash( $_POST['ref'] ?? '' ) ) ); // phpcs:ignore
		if ( $f ) {
			global $wpdb;
			$do  = sanitize_key( $_POST['do'] ?? '' ); // phpcs:ignore
			if ( 'rejected' === $f[1]['st'] ) {
				wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&q=' . rawurlencode( $f[1]['r'] ) ) ); // closed: no more actions
				exit;
			}
			if ( 'reject' === $do ) {
				if ( 'stamped' !== $f[1]['st'] ) {
					$wpdb->update( self::table(), array( 'status' => 'rejected', 'note' => 'Rejected due to MY RISHTA PAKISTAN policy' ), array( 'id' => $f[0] ) ); // phpcs:ignore
					self::notify( $f[1], 'rejected' );
				}
				wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&q=' . rawurlencode( $f[1]['r'] ) ) );
				exit;
			}
			$pay = $f[1]['p'];
			$amt = preg_replace( '/[^0-9.]/', '', (string) ( $_POST['amt'] ?? '' ) ); // phpcs:ignore
			$tid = sanitize_text_field( wp_unslash( $_POST['tid'] ?? '' ) ); // phpcs:ignore
			$pn  = sanitize_text_field( wp_unslash( $_POST['pnote'] ?? '' ) ); // phpcs:ignore
			$att = array();
			if ( ! empty( $_FILES['rcpt']['name'] ) ) {
				require_once ABSPATH . 'wp-admin/includes/file.php';
				require_once ABSPATH . 'wp-admin/includes/image.php';
				require_once ABSPATH . 'wp-admin/includes/media.php';
				$names = (array) $_FILES['rcpt']['name']; // phpcs:ignore
				foreach ( $names as $i => $nm ) {
					if ( '' === $nm || ! empty( $_FILES['rcpt']['error'][ $i ] ) ) { // phpcs:ignore
						continue;
					}
					$_FILES['mrsh_one'] = array( 'name' => $nm, 'type' => $_FILES['rcpt']['type'][ $i ], 'tmp_name' => $_FILES['rcpt']['tmp_name'][ $i ], 'error' => 0, 'size' => $_FILES['rcpt']['size'][ $i ] ); // phpcs:ignore
					$id = media_handle_upload( 'mrsh_one', 0 );
					if ( ! is_wp_error( $id ) ) {
						$att[] = (int) $id;
					}
				}
			}
			if ( in_array( $do, array( 'stamp', 'pay' ), true ) && ( '' !== $amt || '' !== $tid || '' !== $pn || $att ) ) {
				$pay[] = array( 't' => time(), 'amt' => $amt, 'meth' => sanitize_text_field( wp_unslash( $_POST['meth'] ?? '' ) ), 'tid' => $tid, 'note' => $pn, 'att' => $att, 'by' => get_current_user_id() ); // phpcs:ignore
			}
			$row = array( 'pay' => wp_json_encode( $pay ) );
			$err = '';
			if ( 'stamp' === $do && ! self::has_data( $f[1] ) ) {
				$do  = 'pay';
				$err = '&err=empty';
			}
			if ( 'stamp' === $do || 'undo' === $do ) {
				$on  = 'stamp' === $do;
				$row = array_merge( $row, array( 'status' => $on ? 'stamped' : 'issued', 'stamped' => $on ? gmdate( 'Y-m-d H:i:s' ) : null ) );
			}
			$row['note'] = mb_substr( sanitize_text_field( wp_unslash( $_POST['note'] ?? '' ) ), 0, 120 ); // phpcs:ignore
			$wpdb->update( self::table(), $row, array( 'id' => $f[0] ) ); // phpcs:ignore
			if ( 'stamp' === $do && 'stamped' !== $f[1]['st'] ) {
				$g = self::find( $f[1]['r'] );
				if ( $g ) {
					self::deliver( $g[1] );
				}
			}
		}
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&q=' . rawurlencode( (string) ( $f ? $f[1]['r'] : '' ) ) . ( isset( $err ) ? $err : '' ) ) );
		exit;
	}

	/** Secure link to the signed copy (only people who get the link can open it). */
	public static function copy_url( $ref ) {
		return add_query_arg( array( 'mrt_agr_copy' => $ref, 'k' => substr( hash_hmac( 'sha256', $ref, wp_salt( 'auth' ) ), 0, 20 ) ), home_url( '/' ) );
	}

	private static function copy_html( $e, $name ) {
		$d    = json_decode( (string) $e['d'], true );
		$body = '' !== trim( $e['l'] ) ? esc_html( $e['l'] ) : '';
		if ( '' === $body && is_array( $d ) ) {
			foreach ( self::labels() as $k => $l ) {
				if ( ! empty( $d[ $k ] ) ) {
					$body .= esc_html( $l . ': ' . $d[ $k ] ) . "\n";
				}
			}
		}
		$at = wp_date( 'j F Y', (int) $e['at'] );
		return '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Signed letter ' . esc_html( $e['r'] ) . '</title><style>@page{size:A4;margin:14mm}*{box-sizing:border-box}body{margin:0;background:#eee;font-family:Georgia,"Noto Nastaliq Urdu",serif;color:#1a1a1a}.bar{background:#6e1230;color:#fff;padding:10px 16px;text-align:center;font-family:system-ui,sans-serif}.bar button{margin-left:10px;padding:8px 18px;border:0;border-radius:8px;background:#fff;color:#6e1230;font-weight:700;cursor:pointer}.pg{max-width:210mm;margin:14px auto;background:#fff;padding:16mm;box-shadow:0 4px 18px rgba(0,0,0,.15)}.hd{display:flex;justify-content:space-between;border-bottom:3px double #9b1b4b;padding-bottom:8px;margin-bottom:12px}.hd b{color:#6e1230;font-size:1.3rem}.hd small{color:#666}pre{white-space:pre-wrap;font:inherit;font-size:11pt;line-height:1.5;margin:0}.sl{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;margin-top:18px;padding-top:12px;border-top:1px solid #ccc;break-inside:avoid}.stp{transform:rotate(-8deg)}.sgn{border-bottom:2px solid #1e3a8a}.fn{font:10pt system-ui,sans-serif;color:#555;margin-top:10px}@media print{body{background:#fff}.bar{display:none}.pg{box-shadow:none;margin:0;padding:0;max-width:none}}</style></head><body><div class="bar">Signed copy &middot; reference ' . esc_html( $e['r'] ) . ' <button onclick="window.print()">Download / Save as PDF</button></div><div class="pg"><div class="hd"><div><b>' . esc_html( $name ) . '</b><br><small>Agreement letter</small></div><div style="text-align:right"><small>Reference<br><b style="font-size:1rem">' . esc_html( $e['r'] ) . '</b></small></div></div><pre>' . $body . '</pre><div class="sl"><div>' . self::stamp_svg( $at ) . '</div><div style="text-align:center">' . self::sign_svg() . '<div class="fn">Stamped and digitally signed on ' . esc_html( $at ) . '</div></div></div><div class="fn">Check this letter: ' . esc_html( preg_replace( '#^https?://#', '', home_url( '/?mrt_agr=' ) ) ) . esc_html( $e['r'] ) . '. This letter records what the families agreed. It does not replace the Nikah Nama and is not legal advice.</div></div></body></html>';
	}

	public static function copy_page() {
		if ( empty( $_GET['mrt_agr_copy'] ) ) { // phpcs:ignore
			return;
		}
		$ref = strtoupper( preg_replace( '/[^A-Za-z0-9\-]/', '', wp_unslash( $_GET['mrt_agr_copy'] ) ) ); // phpcs:ignore
		$k   = (string) ( $_GET['k'] ?? '' ); // phpcs:ignore
		$f   = $ref ? self::find( $ref ) : null;
		if ( ! $f || 'stamped' !== $f[1]['st'] || ! hash_equals( substr( hash_hmac( 'sha256', $ref, wp_salt( 'auth' ) ), 0, 20 ), $k ) ) {
			wp_die( 'This signed copy link is not valid.', 'Not found', array( 'response' => 404 ) );
		}
		self::view( $f[1]['r'] );
		exit;
	}

	/** WhatsApp number as digits with country code (03xx... becomes 923xx...). */
	private static function wa_num( $uid, $typed = '' ) {
		$n = preg_replace( '/\D/', '', (string) $typed );
		if ( '' === $n ) {
			$n = preg_replace( '/\D/', '', (string) get_user_meta( $uid, 'mrt_mobile', true ) );
		}
		if ( '' === $n ) {
			return '';
		}
		if ( 0 === strpos( $n, '00' ) ) {
			$n = substr( $n, 2 );
		} elseif ( 0 === strpos( $n, '0' ) ) {
			$n = '92' . substr( $n, 1 );
		}
		return $n;
	}

	public static function wa_text( $e ) {
		return 'Assalam o Alaikum. Your agreement letter ' . $e['r'] . ' from ' . get_bloginfo( 'name' ) . ' is now stamped and digitally signed. Open or save the PDF: ' . self::copy_url( $e['r'] );
	}

	/** Real PDF file path when the server has wkhtmltopdf, else ''. */
	private static function make_pdf( $e ) {
		return ''; // the signed copy is the real letter page; the member saves it as PDF from there.
		if ( ! function_exists( 'shell_exec' ) || in_array( 'shell_exec', array_map( 'trim', explode( ',', (string) ini_get( 'disable_functions' ) ) ), true ) ) {
			return '';
		}
		$bin = trim( (string) @shell_exec( 'command -v wkhtmltopdf 2>/dev/null' ) ); // phpcs:ignore
		if ( ! $bin ) {
			return '';
		}
		$dir = get_temp_dir();
		$in  = $dir . 'mrsh-' . wp_generate_password( 8, false ) . '.html';
		$out = $dir . 'Letter-' . $e['r'] . '.pdf';
		file_put_contents( $in, str_replace( 'class="bar"', 'class="bar" style="display:none"', self::copy_html( $e, get_bloginfo( 'name' ) ) ) ); // phpcs:ignore
		@shell_exec( escapeshellarg( $bin ) . ' --quiet --enable-local-file-access --print-media-type ' . escapeshellarg( $in ) . ' ' . escapeshellarg( $out ) . ' 2>&1' ); // phpcs:ignore
		@unlink( $in ); // phpcs:ignore
		return ( is_file( $out ) && filesize( $out ) > 1000 ) ? $out : '';
	}

	public static function pdf_url( $ref ) {
		return add_query_arg( 'dl', '1', self::copy_url( $ref ) );
	}

	/** Paid: email the signed copy (PDF attached when the server can make one) and ping the optional WhatsApp webhook. */
	private static function deliver( $e ) {
		$u = get_userdata( (int) $e['u'] );
		if ( ! $u ) {
			return;
		}
		$url   = self::copy_url( $e['r'] );
		$name  = get_bloginfo( 'name' );
		$files = array();
		$tmp   = null;
		$tmp = self::make_pdf( $e );
		if ( $tmp ) {
			$files[] = $tmp;
		}
		$msg = "Assalam o Alaikum " . $u->display_name . ",\n\nThank you. Your payment is received and your agreement letter (reference " . $e['r'] . ") is now stamped and digitally signed by " . $name . ".\n\n" . ( $files ? "The signed PDF is attached. You can also open it here:\n" : "Open your signed copy here and press Download / Save as PDF:\n" ) . $url . "\n\nAnyone can confirm the reference at " . home_url( '/?mrt_agr=' ) . $e['r'] . "\n\n" . $name;
		$ok  = wp_mail( $u->user_email, 'Your signed agreement letter ' . $e['r'], $msg, array(), $files );
		if ( $tmp && is_file( $tmp ) ) {
			@unlink( $tmp ); // phpcs:ignore
		}
		update_option( 'mrsh_agr_last_delivery', array( 'ref' => $e['r'], 'mail' => $ok ? 'sent' : 'failed', 'pdf' => $files ? 'attached' : 'link only', 't' => time() ), false );
		if ( class_exists( 'MRSH_WhatsApp' ) ) {
			MRSH_WhatsApp::push( self::wa_num( (int) $e['u'], self::typed( $e, 'wa' ) ), self::wa_text( $e ), 'signed', array( 'link' => $url, 'reference' => $e['r'], 'email' => $u->user_email ), array( 'signed', array( $u->display_name, $e['r'], $url ) ) );
		}
	}

	const LIFE = 30; // days a letter reference stays open for payment.
	const EVERY = 48; // hours between reminders.

	private static function pay_info() {
		$i = trim( (string) get_option( 'mrsh_agr_pay_info' ) );
		return $i ? $i : 'Please contact us to complete the payment.';
	}

	/** Letters not paid yet and typed in: remind every 48 hours, expire after 30 days. */
	public static function cron() {
		global $wpdb;
		self::install();
		$rows = $wpdb->get_results( "SELECT * FROM " . self::table() . " WHERE status = 'issued' ORDER BY id ASC LIMIT 500" ); // phpcs:ignore
		$now  = time();
		foreach ( (array) $rows as $r ) {
			$e   = self::shape( $r );
			$age = $now - (int) $e['t'];
			if ( $age >= self::LIFE * DAY_IN_SECONDS ) {
				$wpdb->update( self::table(), array( 'status' => 'expired', 'note' => 'Expired: not paid within ' . self::LIFE . ' days' ), array( 'id' => $e['id'] ) ); // phpcs:ignore
				if ( self::has_data( $e ) ) {
					self::notify( $e, 'expired' );
				}
				continue;
			}
			if ( ! self::has_data( $e ) ) {
				continue;
			}
			$last = $e['ra'] ? $e['ra'] : $e['t'];
			if ( $now - $last >= self::EVERY * HOUR_IN_SECONDS ) {
				self::notify( $e, 'reminder' );
				$wpdb->update( self::table(), array( 'remind_at' => gmdate( 'Y-m-d H:i:s' ), 'remind_n' => $e['rn'] + 1 ), array( 'id' => $e['id'] ) ); // phpcs:ignore
			}
		}
	}

	public static function reminder_text( $e, $kind ) {
		$name = get_bloginfo( 'name' );
		$left = max( 0, (int) ceil( ( self::LIFE * DAY_IN_SECONDS - ( time() - (int) $e['t'] ) ) / DAY_IN_SECONDS ) );
		if ( 'rejected' === $kind ) {
			return 'Your agreement letter ' . $e['r'] . ' from ' . $name . ' was rejected due to MY RISHTA PAKISTAN policy. The reference is closed and the letter is NOT authenticated.';
		}
		if ( 'expired' === $kind ) {
			return 'Your agreement letter ' . $e['r'] . ' from ' . $name . ' has expired because payment was not received within ' . self::LIFE . ' days. The reference is cancelled and the letter is NOT authenticated. If you still need it, please contact us.';
		}
		return 'Reminder: your agreement letter ' . $e['r'] . ' from ' . $name . ' is not authenticated yet. It becomes valid only after payment and our stamp. ' . $left . ' day(s) left; after that the reference is cancelled. ' . self::pay_info() . ' Open your letter: ' . add_query_arg( 'ref', $e['r'], self::link() );
	}

	private static function notify( $e, $kind ) {
		$u = get_userdata( (int) $e['u'] );
		if ( ! $u ) {
			return;
		}
		$txt = self::reminder_text( $e, $kind );
		wp_mail( $u->user_email, ( 'rejected' === $kind ? 'Letter reference rejected: ' : ( 'expired' === $kind ? 'Letter reference expired: ' : 'Payment reminder: ' ) ) . $e['r'], "Assalam o Alaikum " . $u->display_name . ",\n\n" . $txt . "\n\n" . get_bloginfo( 'name' ) );
		if ( 'rejected' !== $kind && class_exists( 'MRSH_WhatsApp' ) ) {
			$left = max( 0, (int) ceil( ( self::LIFE * DAY_IN_SECONDS - ( time() - (int) $e['t'] ) ) / DAY_IN_SECONDS ) );
			MRSH_WhatsApp::push( self::wa_num( (int) $e['u'], self::typed( $e, 'wa' ) ), $txt, $kind, array( 'reference' => $e['r'], 'email' => $u->user_email ), 'expired' === $kind ? array( 'expired', array( $u->display_name, $e['r'] ) ) : array( 'pay', array( $u->display_name, $e['r'], $left, add_query_arg( 'ref', $e['r'], self::link() ) ) ) );
		}
	}

	/** Digital blue stamp (inline SVG). */
	public static function stamp_svg( $date = '' ) {
		$d = esc_html( $date );
		return '<svg class="stp" viewBox="0 0 220 220" width="150" height="150" role="img" aria-label="Digital stamp"><defs><path id="arcT" d="M30,110 a80,80 0 1,1 160,0"/><path id="arcB" d="M26,110 a84,84 0 0,0 168,0"/></defs><g fill="none" stroke="#1d4ed8" stroke-width="4"><circle cx="110" cy="110" r="102"/><circle cx="110" cy="110" r="94" stroke-width="1.5"/><circle cx="110" cy="110" r="62" stroke-width="2"/></g><g fill="#1d4ed8" font-family="Georgia,serif" font-weight="700" text-anchor="middle"><text font-size="17" letter-spacing="2"><textPath href="#arcT" startOffset="50%">MY RISHTA PAKISTAN</textPath></text><text font-size="14" letter-spacing="3"><textPath href="#arcB" startOffset="50%" side="right">VERIFIED &#9733; MYRISHTA.PK</textPath></text><text x="110" y="100" font-size="15" letter-spacing="2">RECEIVED</text><text x="110" y="122" font-size="19">&#10003; STAMPED</text><text x="110" y="144" font-size="11" font-weight="400">' . $d . '</text></g></svg>';
	}

	/** Digital signature graphic. */
	public static function sign_svg() {
		return '<svg class="sgn" viewBox="0 0 360 110" width="280" height="86" role="img" aria-label="Digital signature"><path d="M12 72 C60 20 90 20 80 62 C74 92 118 30 140 52 C158 70 170 56 196 50 C226 44 250 66 306 40" fill="none" stroke="#1e3a8a" stroke-width="2.6" stroke-linecap="round"/><text x="12" y="52" font-family="\'Brush Script MT\',\'Segoe Script\',\'Snell Roundhand\',cursive" font-size="34" fill="#1e3a8a" transform="rotate(-4 12 52)">My Rishta Pakistan</text><text x="12" y="100" font-family="Georgia,serif" font-size="10" letter-spacing="2" fill="#1e3a8a">MY RISHTA PAKISTAN &middot; DIGITALLY SIGNED</text></svg>';
	}

	/** Public check: anyone (for example the registrar) can open /?mrt_agr=REF and see if the reference is real. */
	public static function verify_page() {
		if ( ! isset( $_GET['mrt_agr'] ) ) { // phpcs:ignore
			return;
		}
		$raw = strtoupper( preg_replace( '/[^A-Za-z0-9\-]/', '', wp_unslash( $_GET['mrt_agr'] ) ) ); // phpcs:ignore
		$ref = $raw;
		if ( $ref && 0 !== strpos( $ref, 'MR-' ) && preg_match( '/^\d{8}-[A-Z0-9]{4}$/', $ref ) ) {
			$ref = 'MR-' . $ref;
		}
		$f = $ref ? self::find( $ref ) : null;
		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		header( 'X-Robots-Tag: noindex, nofollow' );
		$name = esc_html( get_bloginfo( 'name' ) );
		$card = '<div class="card hint"><div class="ic">&#128269;</div><h2>Enter the reference number</h2><p>You will find it at the bottom of the letter, for example <b>MR-20260101-AB12</b>.</p></div>';
		if ( $raw && $f ) {
			$e  = $f[1];
			$st = 'stamped' === $e['st'];
			if ( 'rejected' === $e['st'] ) {
				$card = '<div class="card bad"><div class="badge">&#10007; Rejected &middot; Not valid</div><div class="grid"><div><span>Reference</span><b>' . esc_html( $e['r'] ) . '</b></div><div><span>Letter made on</span><b>' . esc_html( wp_date( 'j F Y', (int) $e['t'] ) ) . '</b></div><div><span>Status</span><b class="w">Rejected</b></div></div><p>This letter was <b>rejected due to MY RISHTA PAKISTAN policy</b>. It is <b>not valid</b>.</p></div>';
			} elseif ( 'expired' === $e['st'] ) {
				$card = '<div class="card bad"><div class="badge">&#9888; Expired &middot; Not authenticated</div><div class="grid"><div><span>Reference</span><b>' . esc_html( $e['r'] ) . '</b></div><div><span>Letter made on</span><b>' . esc_html( wp_date( 'j F Y', (int) $e['t'] ) ) . '</b></div><div><span>Status</span><b class="w">Cancelled</b></div></div><p>This reference was cancelled because it was not authenticated within ' . self::LIFE . ' days. The letter is <b>not valid</b>.</p></div>';
			} else {
			$card = '<div class="card ok"><div class="badge">&#10003; Reference found</div><div class="grid"><div><span>Reference</span><b>' . esc_html( $e['r'] ) . '</b></div><div><span>Letter made on</span><b>' . esc_html( wp_date( 'j F Y', (int) $e['t'] ) ) . '</b></div><div><span>Stamp and signature</span><b class="' . ( $st ? 'g' : 'w' ) . '">' . ( $st ? 'Yes &middot; ' . esc_html( wp_date( 'j F Y', (int) $e['at'] ) ) : 'Not yet' ) . '</b></div></div>';
			if ( $st ) {
				$card .= '<div class="seal">' . self::stamp_svg( wp_date( 'j M Y', (int) $e['at'] ) ) . '<div class="sg">' . self::sign_svg() . '<small>Authorised signature &middot; ' . $name . '</small></div></div>';
			} else {
				$card .= '<p class="wait">This letter has been made but our stamp and signature are not added yet.</p>';
			}
			$card .= '<p class="fine">This only confirms the reference. The site does not keep the content of the letter and is not a party to the agreement.</p></div>';
			}
		} elseif ( $raw ) {
			$card = '<div class="card bad"><div class="badge">&#10007; Reference not found</div><p>No letter with the reference <b>' . esc_html( $raw ) . '</b> was made with ' . $name . '.</p><p>Check the number for typing mistakes (letter O and number 0 look alike). If it is still not found, treat the letter as not verified.</p></div>';
		}
		$css = '*{box-sizing:border-box}body{margin:0;font-family:system-ui,-apple-system,Segoe UI,sans-serif;background:linear-gradient(160deg,#fdf3f6,#f3f6ff);color:#2b1a22;line-height:1.55;min-height:100vh}.top{background:linear-gradient(135deg,#6e1230,#9b1b4b);color:#fff;text-align:center;padding:26px 16px 58px}.top h1{margin:0;font-size:1.35rem;letter-spacing:.3px}.top p{margin:6px 0 0;opacity:.85;font-size:.92rem}.wrap{max-width:620px;margin:-38px auto 40px;padding:0 16px}form{background:#fff;border-radius:16px;box-shadow:0 10px 30px rgba(110,18,48,.15);padding:18px;display:flex;gap:10px;flex-wrap:wrap}label{width:100%;font-weight:600;font-size:.9rem;color:#6e1230}input[type=text]{flex:1 1 220px;min-width:0;padding:14px 16px;font-size:1.05rem;border:2px solid #e5d3da;border-radius:12px;text-transform:uppercase;letter-spacing:1px;outline:0}input[type=text]:focus{border-color:#9b1b4b;box-shadow:0 0 0 4px rgba(155,27,75,.12)}button{padding:14px 26px;border:0;border-radius:12px;background:linear-gradient(135deg,#9b1b4b,#6e1230);color:#fff;font-size:1rem;font-weight:700;cursor:pointer}button:hover{filter:brightness(1.1)}.card{margin-top:18px;background:#fff;border-radius:16px;padding:22px;box-shadow:0 6px 22px rgba(0,0,0,.08);border-top:6px solid #cbd5e1}.card.ok{border-top-color:#059669}.card.bad{border-top-color:#dc2626}.card.hint{text-align:center;color:#555}.ic{font-size:2rem}.card h2{margin:.2em 0}.badge{display:inline-block;font-weight:700;padding:6px 14px;border-radius:99px;margin-bottom:14px}.ok .badge{background:#d1fae5;color:#065f46}.bad .badge{background:#fee2e2;color:#991b1b}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px}.grid div{background:#faf5f7;border-radius:12px;padding:10px 14px}.grid span{display:block;font-size:.75rem;text-transform:uppercase;letter-spacing:1px;color:#8a6a76}.grid b{font-size:.95rem;overflow-wrap:anywhere}.grid{grid-template-columns:repeat(auto-fit,minmax(190px,1fr))}.g{color:#059669}.w{color:#b45309}.seal{display:flex;align-items:center;justify-content:center;gap:18px;flex-wrap:wrap;margin:20px 0 6px;padding:16px;border:2px dashed #bfdbfe;border-radius:14px;background:#f5f9ff}.stp{transform:rotate(-8deg);opacity:.93;filter:drop-shadow(0 1px 0 rgba(29,78,216,.25));max-width:100%}.sg{text-align:center;max-width:100%}.sg svg{max-width:100%;height:auto;border-bottom:2px solid #1e3a8a}.sg small{display:block;color:#475569;margin-top:6px}.wait{background:#fffbeb;color:#92400e;padding:10px 14px;border-radius:10px}.fine{color:#777;font-size:.82rem;margin-bottom:0}';
		echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>Check letter reference</title><style>' . $css . '</style></head><body><div class="top"><h1>' . $name . ' &middot; Check a letter</h1><p>Confirm that an agreement letter reference is genuine</p></div><div class="wrap"><form method="get" action="' . esc_url( home_url( '/' ) ) . '"><label for="r">Letter reference number</label><input type="text" id="r" name="mrt_agr" value="' . esc_attr( $raw ) . '" placeholder="MR-YYYYMMDD-XXXX" autocomplete="off" required><button type="submit">Check</button></form>' . $card . '</div></body></html>'; // phpcs:ignore
		exit;
	}

	/** The member's own recent references. */
	public static function account_refs( $uid ) {
		if ( ! $uid || ( class_exists( 'MRSH_Switch' ) && ! MRSH_Switch::on( 'agreement' ) ) ) {
			return;
		}
		$mine = self::rows( (int) $uid, 5 );
		if ( ! $mine ) {
			return;
		}
		echo '<div class="wrap narrow"><div class="box"><h3>My letter references</h3><p class="mut">Keep the reference with your copy. The Nikah registrar can check any reference on the page below.</p><ul style="list-style:none;padding:0;margin:0">';
		foreach ( $mine as $e ) {
			$st = 'stamped' === $e['st'];
			echo '<li style="padding:10px 0;border-bottom:1px solid var(--line,#eee)"><b>' . esc_html( $e['r'] ) . '</b> <span class="mut">' . esc_html( wp_date( 'j M Y', (int) $e['t'] ) ) . '</span><br>' . ( $st ? '<span class="pill pv">Stamped and signed</span>' : ( 'rejected' === $e['st'] ? '<span class="pill" style="background:#fee2e2;color:#991b1b">Rejected due to MY RISHTA PAKISTAN policy</span>' : ( 'expired' === $e['st'] ? '<span class="pill" style="background:#fee2e2;color:#991b1b">Expired &middot; not authenticated</span>' : '<span class="pill ps">Waiting for our stamp</span>' ) ) ) . ' &nbsp; ' . ( 'rejected' === $e['st'] ? '' : '<a class="btn sm" href="' . esc_url( add_query_arg( 'ref', $e['r'], self::link() ) ) . '" target="_blank" rel="noopener">Open letter</a> <a class="btn sm" href="' . esc_url( home_url( '/?mrt_agr=' . rawurlencode( $e['r'] ) ) ) . '" target="_blank" rel="noopener">Check reference</a>' . ( $st ? ' <a class="btn sm" href="' . esc_url( self::pdf_url( $e['r'] ) ) . '" target="_blank" rel="noopener" download>Download PDF</a>' : '' ) ) . '</li>';
		}
		echo '</ul></div></div>';
	}

	public static function link( $mode = 'letter' ) {
		return add_query_arg( array( 'action' => 'mrsh_agreement', 'm' => $mode ), admin_url( 'admin-post.php' ) );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Agreement letter', 'Agreement', 'manage_options', self::SLUG, array( __CLASS__, 'page' ) );
	}

	public static function account( $uid ) {
		if ( ! $uid || ( class_exists( 'MRSH_Switch' ) && ! MRSH_Switch::on( 'agreement' ) ) ) {
			return;
		}
		echo '<div class="wrap narrow"><div class="box"><h3>Agreement letter for the Nikah Registrar</h3><p class="mut">When both families have agreed, print a letter that records what was agreed (haq mehr, residence, conditions). Both sides sign it and it is attached with the Nikah Nama at the registrar. Nothing you type is saved on this website.</p><p><a class="btn" target="_blank" href="' . esc_url( self::link() ) . '">Make the agreement letter</a></p></div></div>'; // phpcs:ignore
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		echo '<div class="wrap"><h1>Agreement letter</h1><p style="max-width:760px">A printable A4 letter in English and Urdu that records what the groom, the bride and their guardians agreed before the nikah. Both sides sign it, and it is attached with the Nikah Nama application at the Nikah Registrar, so the agreed terms can be shown later if a legal question comes up. It prints on the My Rishta letterhead with the header, footer and a watermark in the middle of every page.</p>';
		echo '<p><a class="button button-primary button-hero" target="_blank" href="' . esc_url( self::link() ) . '">Make an agreement letter</a> &nbsp; <a class="button" target="_blank" href="' . esc_url( self::link( 'blank' ) ) . '">Print a blank letterhead</a></p>';
		echo '<ul style="list-style:disc;margin-left:20px;max-width:760px"><li>Fill in the boxes on the left; the letter on the right updates as you type. Press Print, choose A4 and tick &quot;Background graphics&quot; (or Save as PDF).</li><li>Members can open the same tool from their My account page and print their own letter.</li><li>Nothing typed is stored on the website. CNIC numbers are only printed on the paper.</li><li>Choose from three letterhead styles (classic, modern band, minimal) and switch the watermark on or off.</li></ul>';
		echo '<div class="notice notice-warning inline" style="max-width:760px"><p><b>Please note.</b> This letter records the understanding of the two families. It does not replace the Nikah Nama and is not legal advice. Read it with the registrar or a lawyer before signing. Do not add terms that are against the law (for example demands for dowry, or rights taken away from the wife or husband).</p></div></div>';
		self::admin_list();
	}

	/** True when the member typed something into the letter. */
	private static function has_data( $e ) {
		$d = json_decode( (string) $e['d'], true );
		return ( is_array( $d ) && count( array_filter( $d, function ( $v ) { return '' !== trim( (string) $v ); } ) ) > 0 );
	}

	private static function typed( $e, $k ) {
		$d = json_decode( (string) $e['d'], true );
		return ( is_array( $d ) && isset( $d[ $k ] ) ) ? (string) $d[ $k ] : '';
	}

	/** Admin: every saved field of every letter as a CSV file. */
	public static function csv() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_agr_csv' );
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="letters-' . gmdate( 'Y-m-d' ) . '.csv"' );
		$o = fopen( 'php://output', 'w' ); // phpcs:ignore
		fwrite( $o, "\xEF\xBB\xBF" ); // phpcs:ignore
		$lab = self::labels();
		fputcsv( $o, array_merge( array( 'Reference', 'Member', 'Member email', 'Made', 'Printed', 'Status', 'Stamped on', 'Note', 'Total paid (Rs)', 'Payments' ), array_values( $lab ), array( 'Full letter text' ) ) ); // phpcs:ignore
		foreach ( self::rows( 0, 5000 ) as $e ) {
			$u = get_userdata( (int) $e['u'] );
			$d = json_decode( (string) $e['d'], true );
			$d = is_array( $d ) ? $d : array();
			$r = array( $e['r'], $u ? $u->display_name : '', $u ? $u->user_email : '', wp_date( 'Y-m-d H:i', (int) $e['t'] ), $e['pt'] ? wp_date( 'Y-m-d H:i', (int) $e['pt'] ) : '', $e['st'], $e['at'] ? wp_date( 'Y-m-d', (int) $e['at'] ) : '', $e['n'], self::pay_total( $e ), implode( ' | ', array_map( function ( $p ) { return wp_date( 'Y-m-d', (int) $p['t'] ) . ' Rs ' . ( $p['amt'] ?? '' ) . ' ' . ( $p['meth'] ?? '' ) . ' ' . ( $p['tid'] ?? '' ); }, $e['p'] ) ) );
			foreach ( $lab as $k => $l ) {
				$r[] = isset( $d[ $k ] ) ? $d[ $k ] : '';
			}
			$r[] = $e['l'];
			fputcsv( $o, $r ); // phpcs:ignore
		}
		fclose( $o ); // phpcs:ignore
		exit;
	}

	private static function summary( $e ) {
		$g = self::typed( $e, 'gn' );
		$b = self::typed( $e, 'bn' );
		if ( '' === $g . $b ) {
			return '';
		}
		$x = array_filter( array( self::typed( $e, 'nd' ) ? 'Nikah ' . self::typed( $e, 'nd' ) : '', self::typed( $e, 'hm' ) ? 'Mehr ' . self::typed( $e, 'hm' ) : '', self::typed( $e, 'wa' ) ? 'WA ' . self::typed( $e, 'wa' ) : '' ) );
		return '<br><span style="color:#6e1230">' . esc_html( ( $g ?: '?' ) . ' &amp; ' . ( $b ?: '?' ) ) . '</span>' . ( $x ? '<br><small>' . esc_html( implode( ' · ', $x ) ) . '</small>' : '' );
	}

	private static function details( $e ) {
		$d = json_decode( (string) $e['d'], true );
		if ( ( ! is_array( $d ) || ! $d ) && '' === trim( $e['l'] ) ) {
			return '<br><small>Opened, nothing typed yet</small>';
		}
		$h = '<details style="margin-top:4px"><summary>' . ( $e['pt'] ? 'Details (printed ' . esc_html( wp_date( 'j M Y H:i', (int) $e['pt'] ) ) . ')' : 'Details (typed, not printed yet)' ) . '</summary><table class="widefat" style="margin-top:6px">';
		foreach ( self::labels() as $k => $l ) {
			if ( isset( $d[ $k ] ) ) {
				$h .= '<tr><td style="width:170px"><b>' . esc_html( $l ) . '</b></td><td>' . nl2br( esc_html( $d[ $k ] ) ) . '</td></tr>';
			}
		}
		$h .= '</table>';
		if ( '' !== trim( $e['l'] ) ) {
			$h .= '<details style="margin-top:6px"><summary>Full letter text</summary><div style="white-space:pre-wrap;background:#fafafa;border:1px solid #e5e7eb;border-radius:8px;padding:10px;max-height:360px;overflow:auto;font-size:12.5px">' . esc_html( $e['l'] ) . '</div></details>';
		}
		return $h . '</details>';
	}

	private static function admin_list() {
		$q   = isset( $_GET['q'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_GET['q'] ) ) ) : ''; // phpcs:ignore
		$all = self::rows( 0, 500 );
		echo '' . ( isset( $_GET['err'] ) ? '<div class="notice notice-error"><p>Not stamped: this letter has no details typed yet. The payment was saved. Stamp it after the member fills in the letter.</p></div>' : '' ) . '<h2>Find a letter by reference</h2><p><a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_agr_csv' ), 'mrsh_agr_csv' ) ) . '">Download all letters (CSV / Excel)</a></p><form method="get" style="margin:8px 0"><input type="hidden" name="page" value="' . esc_attr( self::SLUG ) . '"><input type="text" name="q" value="' . esc_attr( $q ) . '" placeholder="MR-20261110-ABCD" style="width:240px"> <button class="button button-primary">Find</button> ' . ( $q ? '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG ) ) . '">Show all</a>' : '' ) . '</form>';
		echo '<p class="description" style="max-width:760px">Each letter gets a reference when it is opened. The list shows who made it and when. After payment is received and you stamp and sign the printed letter, press <b>Mark stamped</b>. Anyone can check a reference at <code>' . esc_html( home_url( '/?mrt_agr=' ) ) . 'REFERENCE</code>. Everything typed in the letter is saved as it is typed (and the full letter text when it is printed), and you can open it with Details. ID numbers are shortened unless you choose to keep them.</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin:8px 0"><input type="hidden" name="action" value="mrsh_agr_opt">' . wp_nonce_field( 'mrsh_agr_opt', '_wpnonce', true, false ) . '<label><input type="checkbox" name="cnic" value="1"' . checked( (int) get_option( 'mrsh_agr_cnic', 1 ), 1, false ) . '> Keep full ID (CNIC) numbers. Off = only the last digits are kept.</label><br><label>Payment details sent in reminders (account / JazzCash number)<br><textarea name="payinfo" rows="2" style="width:420px">' . esc_textarea( (string) get_option( 'mrsh_agr_pay_info' ) ) . '</textarea></label><br><label>Automatic WhatsApp (optional): webhook address from Zapier / Make <input type="url" name="wahook" value="' . esc_attr( (string) get_option( 'mrsh_agr_wa_hook' ) ) . '" style="width:340px"></label> <button class="button">Save</button></form><p class="description" style="max-width:760px">When you press <b>Mark stamped</b>, the member is emailed the signed letter (PDF attached when this server can make one, otherwise a secure link with a Download / Save as PDF button). The <b>Send on WhatsApp</b> button beside each stamped letter opens WhatsApp with the message and link ready. With a webhook above, WhatsApp is sent automatically through your Zapier / Make WhatsApp connection. Unpaid letters (with details typed) get an email and a webhook message every 48 hours; after 30 days without payment the reference is cancelled and shows Expired, not authenticated.' . ( ( $d = get_option( 'mrsh_agr_last_delivery' ) ) ? ' Last delivery: ' . esc_html( $d['ref'] . ' - email ' . $d['mail'] . ', PDF ' . $d['pdf'] ) . '.' : '' ) . '</p>';
		echo '<table class="widefat striped"><thead><tr><th>Reference</th><th>Member</th><th>Made</th><th>Status</th><th></th></tr></thead><tbody>';
		$n = 0;
		foreach ( $all as $e ) {
			if ( $q && false === stripos( $e['r'], $q ) ) {
				continue;
			}
			if ( ++$n > 100 ) {
				break;
			}
			$u = get_userdata( (int) $e['u'] );
			echo '<tr><td><b>' . esc_html( $e['r'] ) . '</b>' . self::summary( $e ) . self::pay_html( $e ) . self::details( $e ) . '</td><td>' . ( $u ? '<a href="' . esc_url( get_edit_user_link( $u->ID ) ) . '">' . esc_html( $u->display_name ) . '</a> <small>' . esc_html( $u->user_email ) . '</small>' : '#' . (int) $e['u'] ) . '</td><td>' . esc_html( wp_date( 'j M Y H:i', (int) $e['t'] ) ) . '</td><td>' . ( 'stamped' === $e['st'] ? '<b style="color:#047857">Stamped ' . esc_html( wp_date( 'j M Y', (int) $e['at'] ) ) . '</b>' . ( $e['n'] ? '<br><small>' . esc_html( $e['n'] ) . '</small>' : '' ) . '<br><a class="button button-small" target="_blank" href="' . esc_url( self::copy_url( $e['r'] ) ) . '">Signed PDF</a> ' . ( self::wa_num( (int) $e['u'], self::typed( $e, 'wa' ) ) ? '<a class="button button-small" target="_blank" href="' . esc_url( 'https://wa.me/' . self::wa_num( (int) $e['u'], self::typed( $e, 'wa' ) ) . '?text=' . rawurlencode( self::wa_text( $e ) ) ) . '">Send on WhatsApp</a>' : '<small>(no mobile number)</small>' ) : ( 'rejected' === $e['st'] ? '<b style="color:#b91c1c">Rejected</b><br><small>Rejected due to MY RISHTA PAKISTAN policy</small>' : ( 'expired' === $e['st'] ? '<b style="color:#b91c1c">Expired</b>' : 'Issued' . ( self::has_data( $e ) && self::wa_num( (int) $e['u'], self::typed( $e, 'wa' ) ) ? '<br><a class="button button-small" target="_blank" href="' . esc_url( 'https://wa.me/' . self::wa_num( (int) $e['u'], self::typed( $e, 'wa' ) ) . '?text=' . rawurlencode( self::reminder_text( $e, 'reminder' ) ) ) . '">WhatsApp reminder</a>' : '' ) . ( $e['rn'] ? '<br><small>' . (int) $e['rn'] . ' reminder(s), last ' . esc_html( wp_date( 'j M', (int) $e['ra'] ) ) . '</small>' : '' ) ) ) ) . '</td><td>' . ( 'rejected' === $e['st'] ? '<b style="color:#b91c1c">Closed. No more actions.</b>' : '<form method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:grid;gap:4px;min-width:230px"><input type="hidden" name="action" value="mrsh_agr_mark"><input type="hidden" name="ref" value="' . esc_attr( $e['r'] ) . '">' . wp_nonce_field( 'mrsh_agr_mark', '_wpnonce', true, false ) . '<div style="display:flex;gap:4px"><input type="text" name="amt" placeholder="Amount Rs" style="width:90px"><select name="meth"><option>JazzCash</option><option>Easypaisa</option><option>Bank</option><option>Cash</option><option>Other</option></select></div><input type="text" name="tid" placeholder="Transaction ID"><input type="text" name="pnote" placeholder="Payment note"><input type="file" name="rcpt[]" multiple accept="image/*,application/pdf"><input type="text" name="note" placeholder="Short status note" maxlength="80" value="' . esc_attr( $e['n'] ) . '"><div style="display:flex;gap:4px;flex-wrap:wrap">' . ( 'stamped' === $e['st'] ? '<button class="button" name="do" value="undo">Undo stamp</button>' : '<button class="button button-primary" name="do" value="stamp">Mark Paid + stamp</button>' ) . '<button class="button" name="do" value="pay">Save payment only</button>' . ( 'stamped' === $e['st'] ? '' : '<button class="button" style="color:#b91c1c;border-color:#b91c1c" name="do" value="reject" onclick="return confirm(\'Reject this letter? It is closed for good: no more actions.\')">Reject</button>' ) . '</div></form>' ) . '</td></tr>';
		}
		if ( ! $n ) {
			echo '<tr><td colspan="5">' . ( $q ? 'No letter with this reference.' : 'No letters yet.' ) . '</td></tr>';
		}
		echo '</tbody></table>';
	}

	public static function view( $tok = '' ) {
		if ( class_exists( 'MRSH_Switch' ) && ! MRSH_Switch::on( 'agreement' ) ) {
			wp_die( 'The agreement letter is switched off.' );
		}
		$share = is_string( $tok ) && '' !== $tok;
		if ( $share ) {
			$_GET['ref'] = $tok; // phpcs:ignore
			unset( $_GET['m'] ); // phpcs:ignore
		}
		if ( ! $share && ! is_user_logged_in() ) {
			wp_safe_redirect( wp_login_url( self::link() ) );
			exit;
		}
		$mode = ( isset( $_GET['m'] ) && 'blank' === $_GET['m'] ) ? 'blank' : 'letter'; // phpcs:ignore
		$org  = class_exists( 'MRSH_Options' ) ? MRSH_Options::org() : array( 'line' => 'Shahdara, Lahore', 'phone' => '', 'email' => '' );
		$base = MRSH_URL . 'assets/logos/';
		$v    = '?v=' . MRSH_VERSION;
		$ref  = '';
		$stamped = false;
		$expired = false;
		$rejected = false;
		$pre     = null;
		$want    = isset( $_GET['ref'] ) ? sanitize_text_field( wp_unslash( $_GET['ref'] ) ) : ''; // phpcs:ignore
		$have    = ( 'letter' === $mode && $want ) ? self::find( $want ) : null;
		if ( $have && ( $share || (int) $have[1]['u'] === get_current_user_id() || current_user_can( 'manage_options' ) ) ) {
			$ref     = $have[1]['r'];
			$stamped = 'stamped' === $have[1]['st'] && self::has_data( $have[1] );
			$expired = in_array( $have[1]['st'], array( 'expired', 'rejected' ), true );
			$rejected = 'rejected' === $have[1]['st'];
			$pre     = json_decode( (string) $have[1]['d'], true );
			$stat    = $have[1];
		} elseif ( 'letter' === $mode ) {
			$key = 'mrsh_agr_' . get_current_user_id();
			$ref = (string) get_transient( $key );
			if ( ! $ref ) {
				$ref = 'MR-' . gmdate( 'Ymd' ) . '-' . strtoupper( wp_generate_password( 4, false ) );
				set_transient( $key, $ref, 30 * MINUTE_IN_SECONDS );
				self::log_ref( $ref, get_current_user_id() );
			}
		} else {
			$ref = 'BLANK';
		}
		nocache_headers();
		header( 'Content-Type: text/html; charset=utf-8' );
		header( 'X-Robots-Tag: noindex, nofollow' );
		$cfg = array( 'base' => $base, 'v' => $v, 'ref' => $ref, 'blank' => 'blank' === $mode, 'today' => gmdate( 'd / m / Y' ), 'save' => admin_url( 'admin-post.php' ), 'nonce' => wp_create_nonce( 'mrsh_agr_save' ), 'pre' => is_array( $pre ) ? $pre : null, 'stamped' => $stamped, 'autoprint' => $share && ! empty( $_GET['dl'] ) );
		?><!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow">
<title><?php echo 'blank' === $mode ? 'Letterhead' : 'Agreement letter'; ?> - My Rishta Pakistan</title>
<style>
:root{--g1:#12a375;--g2:#7c3aed;--ink:#1d1d1f;--mut:#6b7280;--line:#e5e7eb}
*{box-sizing:border-box}body{margin:0;font-family:Inter,system-ui,-apple-system,"Segoe UI",Arial,sans-serif;background:#eef0f4;color:var(--ink)}
.app{display:grid;grid-template-columns:380px minmax(0,1fr);min-height:100vh}.share .panel{display:none}.share .app{display:block}.sbar{background:#6e1230;color:#fff;padding:10px 16px;text-align:center;font-family:system-ui,sans-serif;position:sticky;top:0;z-index:20}.sbar button{margin-left:10px;padding:8px 18px;border:0;border-radius:8px;background:#fff;color:#6e1230;font-weight:700;cursor:pointer}
.panel{background:#fff;border-right:1px solid var(--line);padding:18px 18px 40px;overflow:auto;max-height:100vh;position:sticky;top:0}
.panel h1{font-size:1.15rem;margin:0 0 4px}.panel p.s{margin:0 0 14px;color:var(--mut);font-size:.85rem}
.panel h2{font-size:.78rem;text-transform:uppercase;letter-spacing:.08em;color:var(--g2);margin:18px 0 8px;border-top:1px solid var(--line);padding-top:14px}
.panel label{display:block;font-size:.8rem;font-weight:600;margin:8px 0 3px}
.panel input,.panel select,.panel textarea{width:100%;border:1px solid #d6d9e0;border-radius:10px;padding:9px 11px;font:inherit;font-size:.9rem;background:#fafbfc}
.panel input:focus,.panel select:focus,.panel textarea:focus{outline:2px solid #c4b5fd;background:#fff}
.row2{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.btns{display:flex;gap:8px;flex-wrap:wrap;margin:12px 0}.btn{border:0;border-radius:12px;padding:11px 16px;font-weight:700;cursor:pointer;background:linear-gradient(135deg,var(--g1),var(--g2));color:#fff;font-size:.92rem}
.btn.l{background:#fff;color:var(--ink);border:1px solid #d6d9e0}
.note{font-size:.78rem;color:var(--mut);background:#fff7ed;border:1px solid #fed7aa;border-radius:10px;padding:8px 10px;margin-top:12px}
.stage{padding:24px;display:flex;justify-content:center;overflow:auto}
.paper{width:210mm;min-height:297mm;background:#fff;box-shadow:0 10px 40px rgba(16,24,40,.18);position:relative}
.bg{position:absolute;inset:0;background-size:210mm 297mm;background-repeat:repeat-y;background-position:top left;pointer-events:none}
#fx{display:none}.pgn{position:absolute;right:12mm;text-align:right;font:600 8.5pt/1 system-ui,Tahoma,sans-serif;color:#555;background:rgba(255,255,255,.85);padding:1mm 2mm;border-radius:1mm;z-index:3;pointer-events:none}.fxc{position:absolute;left:0;width:210mm;height:297mm;pointer-events:none;z-index:0}
.fx .wm,.fxc .wm{position:absolute;left:50%;top:50%;width:150mm;height:150mm;transform:translate(-50%,-50%);background:url(<?php echo esc_url( $base . 'watermark-mark.png' . $v ); ?>) center/contain no-repeat}
.nowm .wm{display:none}
.vt{position:absolute;top:50%;writing-mode:vertical-rl;color:#d40000;white-space:nowrap;line-height:1.2}
.vt.en{left:6.5mm;font-size:7.4pt;transform:translateY(-50%) rotate(180deg)}
.vt.ur{color:#d40000;left:11.5mm;font-size:8.4pt;direction:rtl;transform:translateY(-50%);font-family:"Noto Nastaliq Urdu","Jameel Noori Nastaleeq","Noto Naskh Arabic",Tahoma,serif}
.pgsp{display:block}
.paper table.sheet{width:100%;border-collapse:collapse;position:relative;z-index:1}
.paper td{padding:0}
.sp-t{height:46mm}.sp-b{height:26mm}
.body{padding:0 18mm;font-size:10.4pt;line-height:1.42;color:#111}
.body h3{font-family:Georgia,"Times New Roman",serif;font-size:17pt;margin:0 0 1mm;text-align:center}
.ur{direction:rtl;font-family:"Noto Nastaliq Urdu","Jameel Noori Nastaleeq","Noto Naskh Arabic","Segoe UI",Tahoma,serif;font-size:10.6pt;line-height:1.9;color:#222}
.body .sub{text-align:center;color:#555;font-size:9.6pt;margin-bottom:3mm}
.body .ref{display:flex;justify-content:space-between;font-size:9.4pt;color:#444;margin-bottom:3mm;border-bottom:1px solid #ddd;padding-bottom:2mm}
.sec{font-weight:700;font-size:10.6pt;margin:4mm 0 1.5mm;display:flex;justify-content:space-between;gap:8px;border-bottom:1.5px solid #7c3aed;padding-bottom:.6mm}
.sec .ur{font-size:10.4pt;line-height:1.5}
.party{display:grid;grid-template-columns:1fr 1fr;gap:5mm}.party>div{border:1px solid #d9dce3;border-radius:2mm;padding:2.4mm 3mm}
.party b.t{display:block;color:#7c3aed;font-size:9.4pt;margin-bottom:1mm}
.kv{display:grid;grid-template-columns:34mm 1fr;gap:.6mm 3mm;font-size:9.8pt}.kv span:nth-child(odd){color:#555}
.v{border-bottom:1px dotted #888;min-height:4.6mm;display:inline-block;min-width:25mm;font-weight:600;color:#111}
.cl{display:grid;grid-template-columns:7mm 1fr;gap:0 2mm;margin:1.4mm 0;page-break-inside:avoid}
.cl .n{font-weight:700;color:#7c3aed}.cl .en{font-size:10pt}
.terms .kv{grid-template-columns:44mm 1fr}.terms .v{min-width:60mm}
.free{border:1px solid #d9dce3;border-radius:2mm;padding:2mm 3mm;min-height:17mm;white-space:pre-wrap;font-size:9.8pt}
.sign{display:grid;grid-template-columns:repeat(2,1fr);gap:8mm 6mm;margin-top:6mm;page-break-inside:avoid}
.sign div{border-top:1px solid #333;padding-top:1mm;font-size:9.2pt;min-height:16mm}.sign small{color:#555;display:block}
.blk{page-break-inside:avoid;break-inside:avoid}.stamp{margin-top:5mm;border:1px dashed #999;border-radius:2mm;padding:2mm 3mm;font-size:9pt;color:#555;min-height:17mm;page-break-inside:avoid}
.fine{font-size:8.2pt;color:#555;line-height:1.35;margin-top:4mm;page-break-inside:avoid}.fine .ur{font-size:8.8pt;line-height:1.7}
@media(max-width:900px){.app{grid-template-columns:1fr}.panel{position:static;max-height:none}.stage{padding:10px}.paper{transform-origin:top left}}
@media print{
 @page{size:A4;margin:0}
 html,body{background:#fff}.sbar{display:none!important}.panel{display:none}.app{display:block}.stage{padding:0;display:block;overflow:visible}
 .paper{box-shadow:none;width:210mm;min-height:0}
 *{-webkit-print-color-adjust:exact;print-color-adjust:exact}
 .bg{position:fixed;inset:0;width:210mm;height:297mm;background-size:100% 100%;background-repeat:no-repeat}
 #fx{display:block;position:fixed;left:0;top:0;width:210mm;height:297mm;z-index:0}.fxc,.pgsp{display:none!important}
 thead.sp{display:table-header-group}tfoot.sp{display:table-footer-group}
}
</style></head><body class="<?php echo $share ? 'share' : ''; ?>">
<?php if ( $share ) : ?><div class="sbar">Signed letter &middot; <?php echo esc_html( $ref ); ?> <button type="button" onclick="window.print()">Download / Save as PDF</button></div><?php endif; ?>
<div class="app">
<form class="panel" onsubmit="return false" autocomplete="off">
 <h1><?php echo 'blank' === $mode ? 'Letterhead' : 'Agreement letter'; ?></h1>
 <p class="s"><?php echo 'blank' === $mode ? 'Choose a style and print. Write or type on it.' : 'Fill in the boxes. The letter updates as you type. What you type is saved on the website under this letter\'s reference (ID numbers are shortened).'; ?></p>
 <?php if ( 'blank' !== $mode ) : ?><label style="font-weight:500;background:#f5f3ff;border:1px solid #ddd6fe;border-radius:10px;padding:9px 10px"><input type="checkbox" id="ack" style="width:auto"> I have read section 5. I understand that the website only introduced the families, is not a party, has not checked any information and takes no responsibility for this letter. I am responsible for the truth of what is written.</label><p id="ackmsg" style="color:#b32d2e;font-size:.82rem;margin:4px 0 0" hidden>Please tick the box above before printing.</p><?php endif; ?>
 <div class="btns"><button class="btn" type="button" id="prt">Print / Save as PDF</button><button class="btn l" type="button" id="clr">Clear</button></div>
 <h2>Letterhead</h2>
 <label>Style<select id="style"><option value="classic">Classic (logo and line)</option><option value="modern">Modern (colour band)</option><option value="minimal">Minimal (centred)</option></select></label>
 <label><input type="checkbox" id="wm" checked style="width:auto"> Watermark in the middle of every page</label>
<?php if ( 'blank' !== $mode ) : ?>
 <h2>Groom (dulha)</h2>
 <label>Full name<input data-i="gn"></label><div class="row2"><div><label>Father's name<input data-i="gf"></label></div><div><label>Age<input data-i="ga" inputmode="numeric"></label></div></div>
 <div class="row2"><div><label>CNIC (printed only)<input data-i="gc" placeholder="00000-0000000-0"></label></div><div><label>City<input data-i="gcity"></label></div></div>
 <h2>Bride (dulhan)</h2>
 <label>Full name<input data-i="bn"></label><div class="row2"><div><label>Father's name<input data-i="bf"></label></div><div><label>Age<input data-i="ba" inputmode="numeric"></label></div></div>
 <div class="row2"><div><label>CNIC (printed only)<input data-i="bc" placeholder="00000-0000000-0"></label></div><div><label>City<input data-i="bcity"></label></div></div>
 <h2>Guardians (wali)</h2>
 <label>Groom's guardian (name, relation)<input data-i="gg" placeholder="Name, father / brother"></label>
 <label>Bride's guardian (name, relation)<input data-i="bg" placeholder="Name, father / brother"></label>
 <h2>Nikah</h2>
 <div class="row2"><div><label>Nikah date<input data-i="nd" placeholder="dd / mm / yyyy"></label></div><div><label>Place of nikah<input data-i="np"></label></div></div>
 <label>Nikah Registrar / Union Council<input data-i="nr"></label>
 <h2>Agreed terms</h2>
 <div class="row2"><div><label>Haq Mehr amount<input data-i="hm" placeholder="Rs."></label></div><div><label>How it is paid<select data-i="ht"><option value="">Choose</option><option>Prompt (at nikah)</option><option>Deferred (later)</option><option>Part prompt, part deferred</option></select></label></div></div>
 <label>Gifts and jahez<select data-i="jz" id="jz"><option value="a">No dowry demanded; any gift is willing</option><option value="b">Gifts are listed in the special conditions</option></select></label>
 <label>Where they will live<input data-i="res"></label>
 <label>Study / job after marriage<input data-i="job"></label>
 <label>Walima and other expenses<input data-i="exp" placeholder="Who pays what"></label>
 <label>Other agreed conditions (one per line)<textarea data-i="oth" rows="5"></textarea></label>
 <h2>Witnesses</h2>
 <label>Witness 1 (name, CNIC)<input data-i="w1"></label><label>Witness 2 (name, CNIC)<input data-i="w2"></label>
 <label>Place and date of signing<input data-i="sd"></label>
 <label>Your WhatsApp number (not printed; we send the signed PDF here)<input data-i="wa" type="tel" placeholder="03xx-xxxxxxx"></label>
 <div class="note"><b>Please read.</b> This letter records what the families agreed. It does not replace the Nikah Nama and is not legal advice. Show it to the Nikah Registrar or a lawyer before signing. Do not include anything against the law.</div>
<?php endif; ?>
</form>
<div class="stage"><div class="paper" id="paper">
 <div class="bg" id="bg"></div><div class="fx" id="fx"><div class="wm"></div><?php if ( 'blank' !== $mode && ! $stamped ) : ?><div class="vt en"><?php echo $rejected ? 'REJECTED due to MY RISHTA PAKISTAN policy. This letter is not valid.' : ( $expired ? 'EXPIRED - NOT AUTHENTICATED. This reference is cancelled.' : 'This letter is only valid after it is authenticated.' ); ?></div><div class="vt ur"><?php echo $rejected ? 'مائی رشتہ پاکستان کی پالیسی کے تحت مسترد۔ یہ خط درست نہیں۔' : ( $expired ? 'منسوخ - مستند نہیں۔ یہ ریفرنس نمبر ختم ہو چکا ہے۔' : 'یہ خط صرف مستند (تصدیق) ہونے کے بعد ہی درست ہوگا۔' ); ?></div><?php endif; ?></div>
 <table class="sheet"><thead class="sp"><tr><td><div class="sp-t" id="spt"></div></td></tr></thead><tfoot class="sp"><tr><td><div class="sp-b"></div></td></tr></tfoot><tbody><tr><td>
<?php if ( 'blank' === $mode ) : ?>
 <div class="body" style="min-height:200mm"></div>
<?php else : ?>
 <div class="body">
  <h3>Marriage Agreement Letter</h3>
  <div class="ur" style="text-align:center;font-size:13pt;margin-bottom:1mm">شادی کے متعلق باہمی اتفاق نامہ</div>
  <div class="sub">To be attached with the Nikah Nama application at the Nikah Registrar's office<br><span class="ur">نکاح رجسٹرار کے دفتر میں نکاح نامے کے ساتھ لف کرنے کے لیے</span></div>
  <div class="ref"><span>Ref: <b id="ref"></b></span><span>Date: <b id="today"></b></span></div>
  <p style="margin:0 0 1mm">This letter records what the groom, the bride and their families discussed and agreed before the nikah.</p>
  <p class="ur" style="margin:0 0 2mm">یہ خط ان باتوں کا ریکارڈ ہے جو دولہا، دلہن اور ان کے گھر والوں کے درمیان نکاح سے پہلے طے پائیں۔</p>

  <div class="sec"><span>1. The two parties</span><span class="ur">۱۔ دونوں فریق</span></div>
  <div class="party"><div><b class="t">Groom / دولہا</b><div class="kv"><span>Name</span><span class="v" data-o="gn"></span><span>Father</span><span class="v" data-o="gf"></span><span>Age / City</span><span class="v"><i data-o="ga"></i> <i data-o="gcity"></i></span><span>CNIC</span><span class="v" data-o="gc"></span><span>Guardian</span><span class="v" data-o="gg"></span></div></div>
  <div><b class="t">Bride / دلہن</b><div class="kv"><span>Name</span><span class="v" data-o="bn"></span><span>Father</span><span class="v" data-o="bf"></span><span>Age / City</span><span class="v"><i data-o="ba"></i> <i data-o="bcity"></i></span><span>CNIC</span><span class="v" data-o="bc"></span><span>Guardian</span><span class="v" data-o="bg"></span></div></div></div>

  <div class="sec"><span>2. The nikah</span><span class="ur">۲۔ نکاح</span></div>
  <div class="kv" style="grid-template-columns:34mm 1fr 30mm 1fr"><span>Date</span><span class="v" data-o="nd"></span><span>Place</span><span class="v" data-o="np"></span><span>Registrar</span><span class="v" style="grid-column:2/5" data-o="nr"></span></div>

  <div class="sec"><span>3. What was agreed</span><span class="ur">۳۔ طے شدہ باتیں</span></div>
  <div class="terms"><div class="kv"><span>Haq Mehr / حق مہر</span><span class="v"><i data-o="hm"></i> &nbsp; <i data-o="ht"></i></span><span>Residence / رہائش</span><span class="v" data-o="res"></span><span>Study, job / تعلیم، ملازمت</span><span class="v" data-o="job"></span><span>Walima, expenses / اخراجات</span><span class="v" data-o="exp"></span></div>
  <div style="margin-top:2mm;font-weight:600;font-size:9.6pt">Other agreed conditions / دیگر طے شدہ شرائط</div><div class="free" data-o="oth" data-block="1"></div></div>

  <div class="sec"><span>4. Declarations</span><span class="ur">۴۔ اقرار</span></div>
  <div class="cl"><span class="n">1</span><div><div class="en">Both parties are adults and agree to this marriage freely, without pressure or force.</div><div class="ur">دونوں فریق بالغ ہیں اور بغیر کسی دباؤ یا زبردستی کے اپنی خوشی سے اس شادی پر راضی ہیں۔</div></div></div>
  <div class="cl"><span class="n">2</span><div><div class="en">What was told to each other about name, age, education, job, income, health, earlier marriages and children is true. Hiding facts or giving false information can be raised later before the proper authority.</div><div class="ur">نام، عمر، تعلیم، ملازمت، آمدن، صحت، پہلی شادی اور بچوں کے متعلق جو کچھ ایک دوسرے کو بتایا گیا وہ سچ ہے۔ غلط بیانی یا حقائق چھپانے کا معاملہ بعد میں متعلقہ ادارے کے سامنے اٹھایا جا سکتا ہے۔</div></div></div>
  <div class="cl"><span class="n">3</span><div><div class="en">Haq Mehr is the right of the bride. It is fixed as written above and will be entered in the Nikah Nama.</div><div class="ur">حق مہر دلہن کا حق ہے۔ یہ اوپر لکھے مطابق طے ہے اور نکاح نامے میں درج کیا جائے گا۔</div></div></div>
  <div class="cl" id="jza"><span class="n">4</span><div><div class="en">No dowry (jahez) was demanded by either side. Any gift is given willingly.</div><div class="ur">کسی فریق نے جہیز کا مطالبہ نہیں کیا۔ جو تحفہ دیا جائے وہ اپنی خوشی سے ہوگا۔</div></div></div>
  <div class="cl" id="jzb" hidden><span class="n">4</span><div><div class="en">Gifts are listed in the conditions above. They stay the property of the person they are given to. No dowry was demanded.</div><div class="ur">تحائف اوپر شرائط میں درج ہیں اور جس کو دیے جائیں وہ اسی کی ملکیت رہیں گے۔ جہیز کا کوئی مطالبہ نہیں کیا گیا۔</div></div></div>
  <div class="cl"><span class="n">5</span><div><div class="en">The agreed conditions above are to be written in the special conditions part of the Nikah Nama wherever the law allows, so that they can be relied on later.</div><div class="ur">اوپر طے شدہ شرائط جہاں قانون اجازت دے نکاح نامے کے خصوصی شرائط والے حصے میں درج کرائی جائیں تاکہ بعد میں ان پر انحصار کیا جا سکے۔</div></div></div>
  <div class="cl"><span class="n">6</span><div><div class="en">If a disagreement comes up, both families will first sit together with respect. If it cannot be solved, the legal route open to them (Union Council or Family Court) will be used. Nothing in this letter takes away any right that Islamic law or the laws of Pakistan give to the husband or the wife.</div><div class="ur">اختلاف کی صورت میں پہلے دونوں خاندان عزت کے ساتھ مل بیٹھ کر حل کریں گے۔ حل نہ ہو تو قانونی راستہ (یونین کونسل یا فیملی کورٹ) اختیار کیا جائے گا۔ اس خط کی کوئی بات اسلامی قانون یا پاکستان کے قوانین کے دیے ہوئے کسی حق کو کم نہیں کرتی۔</div></div></div>
  <div class="cl"><span class="n">7</span><div><div class="en">The groom, the bride and each guardian keep a signed copy. One signed copy is given to the Nikah Registrar.</div><div class="ur">دولہا، دلہن اور ہر ولی کے پاس دستخط شدہ کاپی رہے گی۔ ایک دستخط شدہ کاپی نکاح رجسٹرار کو دی جائے گی۔</div></div></div>

    <div><div class="sec"><span>5. Disclaimer and responsibility of the parties</span><span class="ur">۵۔ دستبرداری اور فریقین کی ذمہ داری</span></div>
  <div class="cl"><span class="n">1</span><div><div class="en">My Rishta Pakistan (MyRishta.pk), its owners, volunteers, staff and partners give a free introduction service only. They are not a matchmaker, guarantor, agent, witness, adviser or a party to this agreement.</div><div class="ur">مائی رشتہ پاکستان (MyRishta.pk)، اس کے مالکان، رضاکار، عملہ اور شراکت دار صرف مفت تعارف کی سہولت دیتے ہیں۔ وہ رشتہ کروانے والے، ضامن، ایجنٹ، گواہ، مشیر یا اس معاہدے کے فریق نہیں ہیں۔</div></div></div>
  <div class="cl"><span class="n">2</span><div><div class="en">This letter is made only from information typed by the parties themselves. The website has not checked identity, age, marital status, character, income, health, education or any document.</div><div class="ur">یہ خط فریقین کی اپنی لکھی ہوئی معلومات سے بنایا گیا ہے۔ ویب سائٹ نے شناخت، عمر، ازدواجی حیثیت، کردار، آمدن، صحت، تعلیم یا کسی دستاویز کی تصدیق نہیں کی۔</div></div></div>
  <div class="cl"><span class="n">3</span><div><div class="en">Each party and guardian alone is responsible for the truth of the profile and of everything written in this letter. If any information is false, hidden or misleading, all civil and criminal responsibility lies only with the person who gave it, and not with the website.</div><div class="ur">پروفائل اور اس خط میں دی گئی معلومات کے سچ ہونے کی ذمہ داری صرف متعلقہ فریق اور ولی پر ہے۔ جھوٹی، چھپائی گئی یا گمراہ کن معلومات کی صورت میں ہر قسم کی دیوانی اور فوجداری ذمہ داری اسی شخص پر ہوگی، ویب سائٹ پر نہیں۔</div></div></div>
  <div class="cl"><span class="n">4</span><div><div class="en">To the fullest extent the law allows, the website, its owners, volunteers and staff are not liable for any loss, damage, dispute, separation, divorce or claim arising from the marriage, this letter or its use. The parties and guardians agree not to make any claim against them.</div><div class="ur">قانون کی اجازت کی حد تک ویب سائٹ، اس کے مالکان، رضاکار اور عملہ شادی، اس خط یا اس کے استعمال سے پیدا ہونے والے کسی نقصان، تنازعے، علیحدگی، طلاق یا دعوے کے ذمہ دار نہیں ہوں گے۔ فریقین اور ان کے ولی ان کے خلاف کوئی دعویٰ نہ کرنے پر متفق ہیں۔</div></div></div>
  <div class="cl"><span class="n">5</span><div><div class="en">If a claim is made against the website, or it has to pay any cost, because of false information or misuse of this letter, the party responsible for it will pay.</div><div class="ur">اگر غلط معلومات یا اس خط کے غلط استعمال کی وجہ سے ویب سائٹ کے خلاف کوئی دعویٰ ہو یا خرچ آئے تو اس کی ادائیگی متعلقہ فریق کرے گا۔</div></div></div>
  <div class="cl"><span class="n">6</span><div><div class="en">This letter is not issued or approved by any court, government office or registrar, and it is not legal advice. The parties are told to take their own independent legal advice. If this letter and the Nikah Nama differ, the Nikah Nama is followed.</div><div class="ur">یہ خط کسی عدالت، حکومتی ادارے یا رجسٹرار کا جاری کردہ نہیں اور قانونی مشورہ نہیں۔ فریقین کو اپنا آزاد قانونی مشورہ لینے کی ہدایت ہے۔ اس خط اور نکاح نامے میں فرق ہو تو نکاح نامہ مقدم ہوگا۔</div></div></div>
  <div class="cl"><span class="n">7</span><div><div class="en">A copy of the details typed here is kept on the website only to check the reference number (ID numbers are shortened). Keeping the signed copies safe is the duty of the parties.</div><div class="ur">یہاں لکھی گئی معلومات کی ایک کاپی صرف حوالہ نمبر کی جانچ کے لیے ویب سائٹ پر رکھی جاتی ہے (شناختی کارڈ نمبر مختصر کر دیے جاتے ہیں)۔ دستخط شدہ کاپیاں سنبھال کر رکھنا فریقین کی ذمہ داری ہے۔</div></div></div>
  <div class="cl"><span class="n">8</span><div><div class="en">If any part of this letter cannot be enforced, the other parts stay in force. This letter is made under the laws of Pakistan.</div><div class="ur">اگر اس خط کا کوئی حصہ قانوناً قابلِ نفاذ نہ ہو تو باقی حصے برقرار رہیں گے۔ یہ خط پاکستان کے قوانین کے تحت ہے۔</div></div></div>
  </div>

  <div class="blk"><div class="sec"><span>6. Signatures</span><span class="ur">۶۔ دستخط</span></div>
  <div style="font-size:9pt;margin:1mm 0 2mm">By signing, each person confirms that they have read and understood sections 4 and 5.<span class="ur" style="display:block;font-size:9.4pt">دستخط کر کے ہر شخص تصدیق کرتا ہے کہ اس نے حصہ ۴ اور ۵ پڑھ اور سمجھ لیا ہے۔</span></div>
  <div class="sign">
   <div>Groom / دولہا<small data-o="gn"></small></div><div>Bride / دلہن<small data-o="bn"></small></div>
   <div>Groom's guardian / دولہا کا ولی<small data-o="gg"></small></div><div>Bride's guardian / دلہن کا ولی<small data-o="bg"></small></div>
   <div>Witness 1 / گواہ ۱<small data-o="w1"></small></div><div>Witness 2 / گواہ ۲<small data-o="w2"></small></div>
  </div>
  <div style="margin-top:3mm;font-size:9.6pt">Place and date / مقام اور تاریخ: <span class="v" style="min-width:70mm" data-o="sd"></span></div>
  <?php if ( $stamped && ! empty( $stat ) ) : $sd = wp_date( 'j F Y', (int) $stat['at'] ); ?>
  <div class="stamp" style="border:0;background:none;padding:0;margin-top:8mm;min-height:0;position:relative;pointer-events:none;display:flex;align-items:flex-end;justify-content:space-between;gap:6mm"><div style="margin-left:6mm;mix-blend-mode:multiply"><?php echo self::stamp_svg( $sd ); // phpcs:ignore ?></div><div style="text-align:center;margin-right:6mm"><div style="mix-blend-mode:multiply"><?php echo self::sign_svg(); // phpcs:ignore ?></div><div style="font-size:8pt;color:#1e3a8a;margin-top:1mm">Authenticated &middot; stamped and digitally signed on <?php echo esc_html( $sd ); ?></div><div class="ur" dir="rtl" style="font-size:8.6pt;color:#1e3a8a">مستند · مہر اور ڈیجیٹل دستخط کی تاریخ: <?php echo esc_html( $sd ); ?></div></div></div>
  <?php else : ?>
  <div class="stamp">Received by the Nikah Registrar / نکاح رجسٹرار نے وصول کیا: <br>Name, stamp and date / نام، مہر اور تاریخ</div>
  <?php endif; ?>
  <div class="fine">Letter made with the free My Rishta Pakistan tool (MyRishta.pk). Reference: <span id="ref2"></span><?php if ( 'blank' !== $mode ) : ?> &middot; Check: <?php echo esc_html( preg_replace( '#^https?://#', '', home_url( '/?mrt_agr=' ) ) ); ?><span id="ref3"></span><?php endif; ?></div></div>
 </div></div>
<?php endif; ?>
 </td></tr></tbody></table>
</div></div>
</div>
<script>
(function(){
var C=<?php echo wp_json_encode( $cfg ); ?>;
var heads={classic:44,modern:42,minimal:58},foots={classic:26,modern:24,minimal:26};
function $(s){return document.querySelector(s)}function $$(s){return [].slice.call(document.querySelectorAll(s))}
function style(){paginate();var s=$('#style').value;$('#bg').style.backgroundImage='url('+C.base+'letterhead-a4-'+s+'.png'+C.v+')';$('#spt').style.height=heads[s]+'mm';var f=$('.sp-b');if(f)f.style.height=foots[s]+'mm';try{localStorage.setItem('mrsh_ag_style',s)}catch(e){}}
function wm(){$('#paper').classList.toggle('nowm',!$('#wm').checked);var f=$('#fx');if(f)f.classList.toggle('nowm',!$('#wm').checked)}
var SEL='.body > h3, .body > .ur, .body > .sub, .body > .ref, .body > p, .body .sec, .party, .terms > div, .body > .kv, .cl, .blk';
function mm(v){return v*96/25.4}
var pt;function paginate(){clearTimeout(pt);pt=setTimeout(doPage,60)}
function doPage(){
 var paper=$('#paper');$$('.pgsp').forEach(function(e){e.remove()});$$('.fxc,.pgn').forEach(function(e){e.remove()});
 var s=$('#style').value,P=mm(297),H=mm(heads[s]),F=mm(foots[s]),pr=paper.getBoundingClientRect();
 var atoms=$$(SEL).filter(function(e){var b=e.closest('.blk');return !b||b===e});
 for(var i=0;i<atoms.length;i++){
  var e=atoms[i],r=e.getBoundingClientRect(),t=r.top-paper.getBoundingClientRect().top,h=r.height,need=h;
  if(e.classList.contains('sec')&&atoms[i+1]){need+=atoms[i+1].getBoundingClientRect().height+mm(3)}
  var pg=Math.floor(t/P),end=pg*P+P-F;
  if(t+need>end&&need<P-H-F){var sp=document.createElement('div');sp.className='pgsp';sp.style.height=((pg+1)*P+H-t)+'px';e.parentNode.insertBefore(sp,e)}
 }
 var tb=paper.querySelector('table.sheet').getBoundingClientRect().height,pages=Math.max(1,Math.ceil((tb)/P-0.02));
 paper.style.minHeight=(pages*297)+'mm';
 if(!C.blank){for(var q=0;q<pages;q++){var n=document.createElement('div');n.className='pgn';n.style.top=(q*297+10)+'mm';n.textContent='Page '+(q+1)+' of '+pages+' / صفحہ '+(q+1)+' از '+pages;paper.appendChild(n)}}
 var fx=$('#fx');if(fx&&pages>=1){for(var k=0;k<pages;k++){var c=document.createElement('div');c.className='fxc';c.style.top=(k*297)+'mm';c.innerHTML=fx.innerHTML;paper.appendChild(c)}}
}
window.addEventListener('beforeprint',function(){sv(1);$$('.pgsp').forEach(function(e){e.style.display='none'})});
window.addEventListener('afterprint',paginate);
var svt=0,svq=null;window.addEventListener('pagehide',function(){if(svq){clearTimeout(svq);svq=null;sv(0)}});
function sv(p){if(C.blank||!C.nonce||C.stamped)return;if(!p&&Date.now()-svt<1500)return;svt=Date.now();var d={};$$('[data-i]').forEach(function(e){d[e.getAttribute('data-i')]=e.value});var b=document.querySelector('#paper .body'),f=new FormData();f.append('action','mrsh_agr_save');f.append('_wpnonce',C.nonce);f.append('ref',C.ref);f.append('data',JSON.stringify(d));f.append('letter',b?b.innerText:'');if(p)f.append('p','1');try{if(navigator.sendBeacon)navigator.sendBeacon(C.save,f);else fetch(C.save,{method:'POST',body:f,credentials:'same-origin',keepalive:true})}catch(e){}}
function sv2(){clearTimeout(svq);svq=setTimeout(function(){sv(0)},2500)}
function fill(){
 paginate();$$('[data-i]').forEach(function(el){var k=el.getAttribute('data-i');$$('[data-o="'+k+'"]').forEach(function(o){var t=el.value;o.textContent=t;if(o.getAttribute('data-block')&&!t)o.textContent=''})});
 var j=$('#jz');if(j&&$('#jza')){$('#jza').hidden=j.value!=='a';$('#jzb').hidden=j.value!=='b'}
}
var r=$('#ref');if(r)r.textContent=C.ref;var r2=$('#ref2');if(r2)r2.textContent=C.ref;var r3=$('#ref3');if(r3)r3.textContent=C.ref;var t=$('#today');if(t)t.textContent=C.today;
$('#prt').addEventListener('click',function(){var k=$('#ack');if(k&&!k.checked){$('#ackmsg').hidden=false;k.focus();return}sv(1);window.print()});
$('#style').addEventListener('change',style);$('#wm').addEventListener('change',wm);
$$('.panel input,.panel select,.panel textarea').forEach(function(e){e.addEventListener('input',function(){fill();sv2()});e.addEventListener('change',function(){fill();sv2()})});
$('#clr').addEventListener('click',function(){$$('[data-i]').forEach(function(e){if(e.tagName==='SELECT')e.selectedIndex=0;else e.value=''});fill()});
try{var s=localStorage.getItem('mrsh_ag_style');if(s&&heads[s])$('#style').value=s}catch(e){}
if(C.pre){$$('[data-i]').forEach(function(e){var k=e.getAttribute('data-i');if(C.pre[k]!==undefined)e.value=C.pre[k]})}
if(C.autoprint){window.addEventListener('load',function(){setTimeout(function(){window.print()},900)})}
if(C.stamped){$$('[data-i]').forEach(function(e){e.readOnly=true;if(e.tagName==='SELECT')e.disabled=true})}
style();wm();fill();
paginate();window.addEventListener('load',paginate);if(document.fonts&&document.fonts.ready)document.fonts.ready.then(paginate);
})();
</script></body></html><?php
		exit;
	}
}
MRSH_Agreement::init();
