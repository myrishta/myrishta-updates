<?php
/**
 * Member ideas, part 5: profile strength coach, rishta calendar with reminders, safe-meet share, dua card after a meeting,
 * family view (read-only shortlist link with votes), voice introduction (approved by admin), photo privacy levels,
 * quiet hours, mutual-interest alert, polite reply buttons, match reasons on a profile, and a printable family card.
 * Member data lives in user meta: mrt_cal, mrt_fam_tok, mrt_fam_votes, mrt_voice_intro, mrt_voice_ok, mrt_photo_priv,
 * mrt_quiet, mrt_mutual_new, mrt_polite. Guest forms use a token, not a nonce (page caching).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Mem_More5 {

	const CPT = 'listing_type';

	public static function init() {
		add_action( 'mrt_account_extra', array( __CLASS__, 'account' ), 55 );
		add_action( 'mrt_profile_after', array( __CLASS__, 'profile' ), 20 );
		add_action( 'template_redirect', array( __CLASS__, 'routes' ), 1 );
		add_action( 'admin_post_mrsh_cal_add', array( __CLASS__, 'cal_add' ) );
		add_action( 'admin_post_mrsh_cal_del', array( __CLASS__, 'cal_del' ) );
		add_action( 'admin_post_mrsh_fam', array( __CLASS__, 'fam_post' ) );
		add_action( 'admin_post_nopriv_mrsh_fam_vote', array( __CLASS__, 'fam_vote' ) );
		add_action( 'admin_post_mrsh_fam_vote', array( __CLASS__, 'fam_vote' ) );
		add_action( 'admin_post_mrsh_voice_intro', array( __CLASS__, 'voice_post' ) );
		add_action( 'admin_post_mrsh_priv', array( __CLASS__, 'priv_post' ) );
		add_action( 'admin_post_mrsh_polite', array( __CLASS__, 'polite_post' ) );
		add_action( 'wp_ajax_mrsh_mutual_seen', array( __CLASS__, 'mutual_seen' ) );
		add_action( 'wp_ajax_mrsh_photoreq', array( __CLASS__, 'photoreq' ) );
		add_action( 'wp_footer', array( __CLASS__, 'photoreq_js' ), 86 );
		add_action( 'added_post_meta', array( __CLASS__, 'on_interest' ), 10, 4 );
		add_action( 'updated_post_meta', array( __CLASS__, 'on_interest' ), 10, 4 );
		add_action( 'wp_footer', array( __CLASS__, 'mutual_modal' ), 80 );
		add_action( 'mrsh_growth_daily', array( __CLASS__, 'remind' ) );
		add_filter( 'mrt_blur', array( __CLASS__, 'blur' ), 10, 2 );
	}

	/* ---------- small helpers ---------- */

	private static function back( $k, $v = '1', $hash = '' ) {
		wp_safe_redirect( add_query_arg( $k, $v, home_url( '/my-account/' ) ) . $hash );
		exit;
	}

	private static function mine( $uid = 0 ) {
		return class_exists( 'MRSH_Members' ) ? MRSH_Members::my_profile( $uid ) : null;
	}

	private static function terms( $id, $tax ) {
		if ( ! taxonomy_exists( $tax ) ) {
			return '';
		}
		$n = wp_get_object_terms( $id, $tax, array( 'fields' => 'names' ) );
		return is_wp_error( $n ) || ! $n ? '' : implode( ', ', array_slice( $n, 0, 2 ) );
	}

	private static function clean( $s, $max = 80 ) {
		$s = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( (string) $s ) ) );
		$s = preg_replace( '#https?://\S+|www\.\S+#i', '', $s );
		return function_exists( 'mb_substr' ) ? mb_substr( $s, 0, $max ) : substr( $s, 0, $max );
	}

	/* ---------- quiet hours (used by MRSH_Members::notify) ---------- */

	public static function quiet( $uid ) {
		$q = (array) get_user_meta( $uid, 'mrt_quiet', true );
		if ( empty( $q['on'] ) ) {
			return false;
		}
		$h    = (int) wp_date( 'G' );
		$from = (int) ( $q['from'] ?? 22 );
		$to   = (int) ( $q['to'] ?? 7 );
		return $from > $to ? ( $h >= $from || $h < $to ) : ( $h >= $from && $h < $to );
	}

	/* ---------- photo privacy ---------- */

	public static function blur( $blur, $pid ) {
		$author = (int) get_post_field( 'post_author', $pid );
		$me     = get_current_user_id();
		if ( ! $author || $author === $me || current_user_can( 'edit_others_posts' ) ) {
			return $blur;
		}
		$lvl = (string) get_user_meta( $author, 'mrt_photo_priv', true );
		if ( ! $lvl || 'all' === $lvl ) {
			return $blur;
		}
		if ( ! $me ) {
			return true;
		}
		if ( 'verified' === $lvl ) {
			return get_user_meta( $me, 'ppt_verified', true ) ? $blur : true;
		}
		// accepted: the owner has written to this member
		$q = new WP_Query( array( 'post_type' => 'ppt_message', 'post_status' => 'publish', 'posts_per_page' => 1, 'fields' => 'ids', 'no_found_rows' => true, 'author' => $author,
			'meta_query' => array( array( 'key' => 'msg_stick', 'value' => '[' . $me . '][' . $author . ']' ) ) ) ); // phpcs:ignore
		return $q->have_posts() ? $blur : true;
	}

	public static function priv_post() {
		$uid = get_current_user_id();
		if ( ! $uid || ! check_admin_referer( 'mrsh_priv' ) ) {
			wp_safe_redirect( home_url( '/my-account/' ) );
			exit;
		}
		$l = isset( $_POST['lvl'] ) ? sanitize_key( $_POST['lvl'] ) : 'all'; // phpcs:ignore
		update_user_meta( $uid, 'mrt_photo_priv', in_array( $l, array( 'all', 'accepted', 'verified' ), true ) ? $l : 'all' );
		update_user_meta( $uid, 'mrt_quiet', array( 'on' => empty( $_POST['q_on'] ) ? 0 : 1, 'from' => min( 23, absint( $_POST['q_from'] ?? 22 ) ), 'to' => min( 23, absint( $_POST['q_to'] ?? 7 ) ) ) ); // phpcs:ignore
		self::back( 'm5', 'saved', '#mrsh-priv' );
	}

	/* ---------- account page ---------- */

	public static function account( $uid ) {
		if ( ! $uid ) {
			return;
		}
		$p = self::mine( $uid );
		echo '<div class="wrap narrow" id="mrsh-m5">';
		if ( isset( $_GET['m5'] ) ) { // phpcs:ignore
			$m = array( 'saved' => 'Saved.', 'cal' => 'Added to your calendar.', 'bad' => 'That did not work. Check the details and try again.', 'voice' => 'Thank you. Your voice introduction will appear after we listen to it.', 'sent' => 'Your reply was sent.' );
			echo '<div class="note2">' . esc_html( $m[ $_GET['m5'] ] ?? 'Done.' ) . '</div>'; // phpcs:ignore
		}
		self::box_calendar( $uid );
		self::box_family( $uid );
		self::box_voice( $uid );
		self::box_privacy( $uid );
		echo '</div>';
	}

	/** The profile strength ring, shown by the theme right under the Your profile card. */
	public static function strength_card( $uid ) {
		self::box_strength( $uid, self::mine( $uid ) );
	}

	private static function box_strength( $uid, $p ) {
		echo '<div class="box" id="mrsh-strength"><h3>Profile strength</h3>';
		if ( ! $p ) {
			echo '<p>Create your profile first to see your strength.</p></div>';
			return;
		}
		$ph = count( get_children( array( 'post_parent' => $p->ID, 'post_type' => 'attachment', 'post_mime_type' => 'image', 'numberposts' => 6, 'fields' => 'ids' ) ) );
		$ph = max( $ph, has_post_thumbnail( $p ) ? 1 : 0 );
		$steps = array(
			array( 20, $ph >= 1, 'Add a clear photo', 'add-profile' ),
			array( 10, $ph >= 3, 'Add two more photos', 'add-profile' ),
			array( 15, strlen( wp_strip_all_tags( $p->post_content ) ) >= 60, 'Write a few lines about yourself and your family', 'add-profile' ),
			array( 10, '' !== self::terms( $p->ID, 'education' ), 'Add your education', 'add-profile' ),
			array( 10, '' !== self::terms( $p->ID, 'occupation' ), 'Add your work', 'add-profile' ),
			array( 10, (bool) get_user_meta( $uid, 'mrt_selfie_ok', true ), 'Do the selfie check to get the verified badge', '' ),
			array( 10, (bool) get_user_meta( $uid, 'mrt_voice_intro', true ), 'Record a short voice introduction', '#mrsh-voice' ),
			array( 10, (bool) get_user_meta( $uid, 'mrt_wali', true ), 'Add a guardian contact line', '' ),
			array( 5, (bool) get_user_meta( $uid, 'mrt_video_url', true ), 'Add a video introduction', '' ),
		);
		$tot  = 0;
		$next = null;
		foreach ( $steps as $s ) {
			if ( $s[1] ) {
				$tot += $s[0];
			} elseif ( ! $next ) {
				$next = $s;
			}
		}
		$tot = min( 100, $tot );
		update_post_meta( $p->ID, 'mrt_complete', $tot >= 100 ? 1 : 0 );
		$r    = 52;
		$circ = 2 * M_PI * $r;
		$off  = $circ * ( 1 - $tot / 100 );
		$lvl  = $tot >= 90 ? array( 'Excellent', '#0a7a3d' ) : ( $tot >= 60 ? array( 'Good', '#12a375' ) : ( $tot >= 35 ? array( 'Getting there', '#d97706' ) : array( 'Just started', '#dc2626' ) ) );
		echo '<style>.ps-wrap{display:flex;gap:22px;align-items:center;flex-wrap:wrap}.ps-ring{position:relative;width:132px;height:132px;flex:none}.ps-ring svg{width:132px;height:132px;transform:rotate(-90deg)}.ps-ring .tr{stroke:#f1e4ea}.ps-ring .pr{stroke-linecap:round;transition:stroke-dashoffset 1s ease}.ps-ring b{position:absolute;inset:0;display:grid;place-items:center;font-size:1.9rem;font-weight:800;letter-spacing:-.5px;color:#2b1a22}.ps-ring b small{display:block;font-size:.7rem;font-weight:700;letter-spacing:.4px;margin-top:-18px;color:#8a6a76}.ps-body{flex:1;min-width:220px}.ps-lv{display:inline-block;font-size:.78rem;font-weight:800;padding:4px 12px;border-radius:99px;color:#fff;margin-bottom:8px}.ps-steps{list-style:none;margin:10px 0 12px;padding:0;display:grid;gap:6px}.ps-steps li{display:flex;gap:9px;align-items:center;font-size:.86rem;color:#3a2a31}.ps-steps li i{flex:none;width:18px;height:18px;border-radius:50%;display:grid;place-items:center;font-style:normal;font-size:.65rem;font-weight:800;background:#d1fae5;color:#047857}.ps-steps li.no i{background:#f3e8ec;color:#b08a98}.ps-steps li.no{color:#6b5a62}.ps-steps li em{margin-left:auto;font-style:normal;font-size:.74rem;font-weight:700;color:#9b1b4b}@media(max-width:480px){.ps-wrap{justify-content:center;text-align:center}.ps-steps li{text-align:left}}@media(prefers-reduced-motion:reduce){.ps-ring .pr{transition:none}}</style>';
		echo '<div class="ps-wrap"><div class="ps-ring" role="img" aria-label="Profile strength ' . (int) $tot . ' percent"><svg viewBox="0 0 120 120"><defs><linearGradient id="psg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="' . esc_attr( $lvl[1] ) . '"/><stop offset="1" stop-color="#9b1b4b"/></linearGradient></defs><circle class="tr" cx="60" cy="60" r="' . (int) $r . '" fill="none" stroke-width="11"/><circle class="pr" cx="60" cy="60" r="' . (int) $r . '" fill="none" stroke="url(#psg)" stroke-width="11" stroke-dasharray="' . esc_attr( round( $circ, 2 ) ) . '" stroke-dashoffset="' . esc_attr( round( $off, 2 ) ) . '"/></svg><b>' . (int) $tot . '%</b></div><div class="ps-body"><span class="ps-lv" style="background:' . esc_attr( $lvl[1] ) . '">' . esc_html( $lvl[0] ) . '</span>';
		echo '<ul class="ps-steps">';
		foreach ( $steps as $s ) {
			echo '<li class="' . ( $s[1] ? 'ok' : 'no' ) . '"><i>' . ( $s[1] ? '&#10003;' : '+' ) . '</i><span>' . esc_html( $s[2] ) . '</span>' . ( $s[1] ? '' : '<em>+' . (int) $s[0] . '%</em>' ) . '</li>';
		}
		echo '</ul>';
		if ( $next ) {
			$href = $next[3] ? ( 0 === strpos( $next[3], '#' ) ? $next[3] : home_url( '/' . $next[3] . '/' ) ) : '';
			echo ( class_exists( 'MRSH_Helper' ) ? MRSH_Helper::cta( 'btn sm' ) . ' ' : '' );
			echo ( $href ? '<a class="btn sm" href="' . esc_url( $href ) . '">Do the next step (+' . (int) $next[0] . '%)</a> ' : '' );
		} else {
			echo '<p style="margin:0 0 8px"><b>Your profile is complete. Masha Allah.</b></p>';
		}
		echo '<a class="btn sm line" target="_blank" href="' . esc_url( add_query_arg( 'mrt_card', $p->ID, home_url( '/' ) ) ) . '">Family card (print or share)</a></div></div></div>';
	}

	/* ---------- calendar ---------- */

	private static function cal( $uid ) {
		$c = get_user_meta( $uid, 'mrt_cal', true );
		return is_array( $c ) ? $c : array();
	}

	private static function box_calendar( $uid ) {
		$cal   = self::cal( $uid );
		$today = wp_date( 'Y-m-d' );
		usort( $cal, function ( $a, $b ) { return strcmp( $a['d'] . $a['t'], $b['d'] . $b['t'] ); } );
		echo '<div class="box" id="mrsh-cal"><h3>Rishta calendar</h3><p class="ml">Write down family meetings. We send an email reminder the day before.</p>';
		foreach ( $cal as $e ) {
			$past = $e['d'] < $today;
			$ts   = strtotime( $e['d'] . ' ' . ( $e['t'] ? $e['t'] : '12:00' ) );
			$dt   = gmdate( 'Ymd\THis', $ts );
			$gc   = add_query_arg( array( 'action' => 'TEMPLATE', 'text' => 'Rishta meeting: ' . $e['who'], 'dates' => $dt . '/' . gmdate( 'Ymd\THis', $ts + 7200 ), 'details' => $e['n'], 'location' => $e['pl'] ), 'https://calendar.google.com/calendar/render' );
			$sh   = 'https://wa.me/?text=' . rawurlencode( 'Assalam o Alaikum. Rishta meeting with ' . $e['who'] . ' on ' . wp_date( 'l j F', strtotime( $e['d'] ) ) . ( $e['t'] ? ' at ' . $e['t'] : '' ) . ( $e['pl'] ? ' at ' . $e['pl'] : '' ) . '. Please keep us in your prayers.' );
			$del  = wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_cal_del&i=' . rawurlencode( $e['i'] ) ), 'mrsh_cal_del' );
			echo '<div style="border:1px solid var(--line,#e5e7eb);border-radius:14px;padding:12px;margin:10px 0' . ( $past ? ';opacity:.8' : '' ) . '"><b>' . esc_html( wp_date( 'D j M Y', strtotime( $e['d'] ) ) ) . ( $e['t'] ? ' &middot; ' . esc_html( $e['t'] ) : '' ) . '</b><br>' . esc_html( $e['who'] ) . ( $e['pl'] ? ' &middot; ' . esc_html( $e['pl'] ) : '' ) . ( $e['n'] ? '<br><small>' . esc_html( $e['n'] ) . '</small>' : '' );
			echo '<p style="margin:10px 0 0;display:flex;gap:6px;flex-wrap:wrap"><a class="btn sm line" target="_blank" rel="noopener" href="' . esc_url( $gc ) . '">Add to Google Calendar</a><a class="btn sm line" target="_blank" rel="noopener" href="' . esc_url( $sh ) . '">Share with a relative</a><a class="btn sm line" href="' . esc_url( $del ) . '">Delete</a></p>';
			if ( $past && $e['d'] >= wp_date( 'Y-m-d', strtotime( '-14 days' ) ) ) {
				echo '<p class="note2" style="margin:10px 0 0"><b>After the meeting:</b> Pray two rakat nafl and make istikhara. Talk with your family. Reply to the other family within a few days with respect, yes or no.</p>';
			}
			echo '</div>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_cal_add">' . wp_nonce_field( 'mrsh_cal_add', '_wpnonce', true, false ) . '<div class="g2"><div><label>Date</label><input type="date" name="d" required min="' . esc_attr( $today ) . '"></div><div><label>Time</label><input type="time" name="t"></div><div><label>Meeting with (family name)</label><input name="who" maxlength="80" required></div><div><label>Place</label><input name="pl" maxlength="80"></div></div><label>Note (optional)</label><input name="n" maxlength="120"><p><button class="btn">Add to calendar</button></p></form></div>';
	}

	public static function cal_add() {
		$uid = get_current_user_id();
		if ( ! $uid || ! check_admin_referer( 'mrsh_cal_add' ) ) {
			self::back( 'm5', 'bad' );
		}
		$d = isset( $_POST['d'] ) ? sanitize_text_field( wp_unslash( $_POST['d'] ) ) : ''; // phpcs:ignore
		$t = isset( $_POST['t'] ) ? sanitize_text_field( wp_unslash( $_POST['t'] ) ) : ''; // phpcs:ignore
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) || ( $t && ! preg_match( '/^\d{2}:\d{2}$/', $t ) ) ) {
			self::back( 'm5', 'bad', '#mrsh-cal' );
		}
		$who = self::clean( wp_unslash( $_POST['who'] ?? '' ), 80 ); // phpcs:ignore
		if ( '' === $who ) {
			self::back( 'm5', 'bad', '#mrsh-cal' );
		}
		$c   = self::cal( $uid );
		$c[] = array( 'i' => wp_generate_password( 8, false ), 'd' => $d, 't' => $t, 'who' => $who, 'pl' => self::clean( wp_unslash( $_POST['pl'] ?? '' ), 80 ), 'n' => self::clean( wp_unslash( $_POST['n'] ?? '' ), 120 ) ); // phpcs:ignore
		update_user_meta( $uid, 'mrt_cal', array_slice( $c, -30 ) );
		self::back( 'm5', 'cal', '#mrsh-cal' );
	}

	public static function cal_del() {
		$uid = get_current_user_id();
		if ( $uid && check_admin_referer( 'mrsh_cal_del' ) ) {
			$i = isset( $_GET['i'] ) ? sanitize_text_field( wp_unslash( $_GET['i'] ) ) : ''; // phpcs:ignore
			update_user_meta( $uid, 'mrt_cal', array_values( array_filter( self::cal( $uid ), function ( $e ) use ( $i ) { return $e['i'] !== $i; } ) ) );
		}
		self::back( 'm5', 'saved', '#mrsh-cal' );
	}

	/** Day-before reminder email (runs in the daily job). */
	public static function remind() {
		$tom = wp_date( 'Y-m-d', strtotime( '+1 day' ) );
		foreach ( get_users( array( 'meta_key' => 'mrt_cal', 'fields' => array( 'ID', 'user_email', 'display_name' ) ) ) as $u ) { // phpcs:ignore
			$c   = self::cal( $u->ID );
			$hit = array();
			foreach ( $c as $k => $e ) {
				if ( $e['d'] === $tom && empty( $e['r'] ) ) {
					$hit[]       = $e;
					$c[ $k ]['r'] = 1;
				}
			}
			if ( $hit && $u->user_email ) {
				$body = "Assalam o Alaikum " . $u->display_name . ",\n\nA reminder for tomorrow:\n";
				foreach ( $hit as $e ) {
					$body .= '- ' . $e['who'] . ( $e['t'] ? ' at ' . $e['t'] : '' ) . ( $e['pl'] ? ', ' . $e['pl'] : '' ) . "\n";
				}
				$body .= "\nTell your family where, when and with whom you are meeting. Never send money before the families have met.\n" . home_url( '/my-account/#mrsh-cal' );
				wp_mail( $u->user_email, 'Reminder: rishta meeting tomorrow', $body );
				update_user_meta( $u->ID, 'mrt_cal', $c );
			}
		}
	}

	/* ---------- family view ---------- */

	private static function token( $uid, $make = false ) {
		$t = (string) get_user_meta( $uid, 'mrt_fam_tok', true );
		if ( ! $t && $make ) {
			$t = wp_generate_password( 24, false );
			update_user_meta( $uid, 'mrt_fam_tok', $t );
		}
		return $t;
	}

	private static function box_family( $uid ) {
		$t = self::token( $uid );
		echo '<div class="box" id="mrsh-fam"><h3>Family view</h3><p class="ml">Share a read-only link of your shortlist. Your parents and siblings can vote Yes, Maybe or No without an account. Phone numbers are never shown.</p>';
		$fc = count( array_filter( array_map( 'intval', (array) get_user_meta( $uid, 'favorite', true ) ) ) );
		echo $fc ? '<p class="ml"><b>' . (int) $fc . '</b> profile(s) in your shortlist will be shown (up to 30).</p>' : '<p class="note2">Your shortlist is empty, so your family will see nothing yet. Open profiles and tap <b>Shortlist</b> on the ones you like first.</p>';
		if ( $t ) {
			$url = home_url( '/?mrt_family=' . $t );
			echo '<p><input type="text" readonly value="' . esc_attr( $url ) . '" onclick="this.select()"></p><p style="display:flex;gap:6px;flex-wrap:wrap"><a class="btn sm" target="_blank" rel="noopener" href="' . esc_url( 'https://wa.me/?text=' . rawurlencode( 'Assalam o Alaikum. Please look at my rishta shortlist and give your opinion: ' . $url ) ) . '">Send on WhatsApp</a><button type="button" class="btn sm line" onclick="navigator.clipboard.writeText(\'' . esc_js( $url ) . '\');this.textContent=\'Copied\'">Copy link</button>';
			foreach ( array( 'reset' => 'New link', 'off' => 'Turn off' ) as $k => $l ) {
				echo '<a class="btn sm line" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_fam&do=' . $k ), 'mrsh_fam' ) ) . '">' . esc_html( $l ) . '</a>';
			}
			echo '</p>';
			$votes = (array) get_user_meta( $uid, 'mrt_fam_votes', true );
			if ( $votes ) {
				echo '<h4>Family votes</h4><ul style="list-style:none;padding:0;margin:0">';
				foreach ( $votes as $pid => $v ) {
					$cnt = array( 'yes' => 0, 'maybe' => 0, 'no' => 0 );
					foreach ( (array) $v as $vv ) {
						$vk = is_array( $vv ) ? (string) ( $vv['v'] ?? '' ) : (string) $vv;
						if ( isset( $cnt[ $vk ] ) ) {
							$cnt[ $vk ]++;
						}
					}
					$yes = $cnt['yes'];
					$maybe = $cnt['maybe'];
					$no = $cnt['no'];
					echo '<li style="padding:6px 0;border-bottom:1px solid var(--line,#eee)"><a href="' . esc_url( get_permalink( (int) $pid ) ) . '">' . esc_html( get_the_title( (int) $pid ) ) . '</a>: <b style="color:#10b981">' . (int) $yes . ' yes</b>, ' . (int) $maybe . ' maybe, <span style="color:#ef4444">' . (int) $no . ' no</span></li>';
				}
				echo '</ul>';
			}
		} else {
			echo '<p><a class="btn" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_fam&do=reset' ), 'mrsh_fam' ) ) . '">Create my family link</a></p>';
		}
		echo '</div>';
	}

	public static function fam_post() {
		$uid = get_current_user_id();
		if ( ! $uid || ! check_admin_referer( 'mrsh_fam' ) ) {
			self::back( 'm5', 'bad' );
		}
		if ( 'off' === ( $_GET['do'] ?? '' ) ) { // phpcs:ignore
			delete_user_meta( $uid, 'mrt_fam_tok' );
		} else {
			delete_user_meta( $uid, 'mrt_fam_tok' );
			self::token( $uid, true );
		}
		self::back( 'm5', 'saved', '#mrsh-fam' );
	}

	public static function fam_vote() {
		$tok = isset( $_POST['tok'] ) ? sanitize_text_field( wp_unslash( $_POST['tok'] ) ) : ''; // phpcs:ignore
		$u   = $tok ? get_users( array( 'meta_key' => 'mrt_fam_tok', 'meta_value' => $tok, 'number' => 1, 'fields' => 'ID' ) ) : array(); // phpcs:ignore
		$back = home_url( '/?mrt_family=' . rawurlencode( $tok ) );
		if ( ! $u || ( isset( $_POST['hp'] ) && '' !== $_POST['hp'] ) ) { // phpcs:ignore
			wp_safe_redirect( $back );
			exit;
		}
		$ipk = 'mrt_fv_' . md5( function_exists( 'mrt_ip' ) ? mrt_ip() : '0' );
		$n   = (int) get_transient( $ipk );
		if ( $n > 40 ) {
			wp_safe_redirect( $back );
			exit;
		}
		set_transient( $ipk, $n + 1, HOUR_IN_SECONDS );
		$pid  = absint( $_POST['pid'] ?? 0 ); // phpcs:ignore
		$v    = in_array( $_POST['v'] ?? '', array( 'yes', 'maybe', 'no' ), true ) ? $_POST['v'] : ''; // phpcs:ignore
		$name = self::clean( wp_unslash( $_POST['name'] ?? '' ), 30 ); // phpcs:ignore
		$fav  = array_map( 'intval', (array) get_user_meta( $u[0], 'favorite', true ) );
		if ( $pid && $v && '' !== $name && in_array( $pid, $fav, true ) ) {
			$all = (array) get_user_meta( $u[0], 'mrt_fam_votes', true );
			$cur = isset( $all[ $pid ] ) ? (array) $all[ $pid ] : array();
			$cur[ strtolower( $name ) ] = array( 'n' => $name, 'v' => $v );
			$all[ $pid ] = array_slice( $cur, -12 );
			update_user_meta( $u[0], 'mrt_fam_votes', $all );
		}
		wp_safe_redirect( $back . '#p' . $pid );
		exit;
	}

	/* ---------- voice introduction ---------- */

	private static function box_voice( $uid ) {
		$rel = (string) get_user_meta( $uid, 'mrt_voice_intro', true );
		$st  = (string) get_user_meta( $uid, 'mrt_voice_ok', true );
		echo '<div class="box" id="mrsh-voice"><h3>Voice introduction</h3><p class="ml">Record about 30 seconds in Urdu: who you are, your family and what you look for. Do not say phone numbers.</p>';
		if ( $rel ) {
			$up = wp_get_upload_dir();
			echo '<audio controls preload="none" style="width:100%" src="' . esc_url( trailingslashit( $up['baseurl'] ) . $rel ) . '"></audio><p class="ml">' . ( 'yes' === $st ? 'Shown on your profile.' : 'Waiting for our team to listen.' ) . '</p>';
		}
		echo '<form method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_voice_intro">' . wp_nonce_field( 'mrsh_voice_intro', '_wpnonce', true, false ) . '<input type="file" name="voice" accept="audio/*" capture required><p class="ml">Tap the box on your phone to record. Up to 2 MB.</p><p><button class="btn">' . ( $rel ? 'Replace' : 'Send' ) . ' voice</button>' . ( $rel ? ' <button class="btn line" name="rm" value="1" formnovalidate>Remove</button>' : '' ) . '</p></form></div>';
	}

	public static function voice_post() {
		$uid = get_current_user_id();
		if ( ! $uid || ! check_admin_referer( 'mrsh_voice_intro' ) ) {
			self::back( 'm5', 'bad' );
		}
		$up  = wp_get_upload_dir();
		$old = (string) get_user_meta( $uid, 'mrt_voice_intro', true );
		$del = function () use ( $old, $up ) {
			if ( $old ) {
				$f = trailingslashit( $up['basedir'] ) . $old;
				if ( is_file( $f ) && 0 === strpos( (string) realpath( $f ), (string) realpath( $up['basedir'] ) ) ) {
					wp_delete_file( $f );
				}
			}
		};
		if ( ! empty( $_POST['rm'] ) ) { // phpcs:ignore
			$del();
			delete_user_meta( $uid, 'mrt_voice_intro' );
			delete_user_meta( $uid, 'mrt_voice_ok' );
			self::back( 'm5', 'saved', '#mrsh-voice' );
		}
		if ( empty( $_FILES['voice']['name'] ) || (int) $_FILES['voice']['size'] > 2 * MB_IN_BYTES ) { // phpcs:ignore
			self::back( 'm5', 'bad', '#mrsh-voice' );
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		$r = wp_handle_upload( $_FILES['voice'], array( 'test_form' => false, 'mimes' => array( 'mp3' => 'audio/mpeg', 'm4a' => 'audio/mp4', 'ogg|oga' => 'audio/ogg', 'webm' => 'audio/webm', 'wav' => 'audio/wav', 'aac' => 'audio/aac', 'mp4' => 'video/mp4' ), // phpcs:ignore
			'unique_filename_callback' => function ( $d, $n, $ext ) { return 'voice-' . wp_generate_password( 20, false ) . $ext; } ) );
		if ( ! empty( $r['error'] ) || empty( $r['file'] ) ) {
			self::back( 'm5', 'bad', '#mrsh-voice' );
		}
		$del();
		update_user_meta( $uid, 'mrt_voice_intro', ltrim( substr( $r['file'], strlen( $up['basedir'] ) ), '/\\' ) );
		update_user_meta( $uid, 'mrt_voice_ok', 'wait' );
		do_action( 'mrsh_voice_waiting', $uid );
		self::back( 'm5', 'voice', '#mrsh-voice' );
	}

	/* ---------- privacy + quiet hours ---------- */

	private static function box_privacy( $uid ) {
		$lvl = (string) get_user_meta( $uid, 'mrt_photo_priv', true );
		$q   = (array) get_user_meta( $uid, 'mrt_quiet', true );
		echo '<div class="box" id="mrsh-priv"><h3>Privacy and quiet hours</h3><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_priv">' . wp_nonce_field( 'mrsh_priv', '_wpnonce', true, false ) . '<label>Who can see my photos?</label><select name="lvl">';
		foreach ( array( 'all' => 'Every member', 'verified' => 'Only verified members', 'accepted' => 'Only members I have written to' ) as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $lvl ? $lvl : 'all', $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select><p><label><input type="checkbox" name="q_on" value="1"' . checked( ! empty( $q['on'] ), true, false ) . '> Quiet hours: no email or app alerts</label></p><div class="g2"><div><label>From (hour)</label><select name="q_from">';
		for ( $h = 0; $h < 24; $h++ ) {
			echo '<option value="' . $h . '"' . selected( (int) ( $q['from'] ?? 22 ), $h, false ) . '>' . sprintf( '%02d:00', $h ) . '</option>';
		}
		echo '</select></div><div><label>To (hour)</label><select name="q_to">';
		for ( $h = 0; $h < 24; $h++ ) {
			echo '<option value="' . $h . '"' . selected( (int) ( $q['to'] ?? 7 ), $h, false ) . '>' . sprintf( '%02d:00', $h ) . '</option>';
		}
		echo '</select></div></div><p><button class="btn">Save</button></p></form></div>';
	}

	/* ---------- profile page extras ---------- */

	public static function profile( $id ) {
		$author = (int) get_post_field( 'post_author', $id );
		// voice introduction
		$rel = $author ? (string) get_user_meta( $author, 'mrt_voice_intro', true ) : '';
		if ( $rel && 'yes' === get_user_meta( $author, 'mrt_voice_ok', true ) && ! apply_filters( 'mrt_blur', false, $id ) ) {
			$up = wp_get_upload_dir();
			echo '<div class="wrap narrow"><div class="box"><h3>Listen to my introduction</h3><audio controls preload="none" style="width:100%" src="' . esc_url( trailingslashit( $up['baseurl'] ) . $rel ) . '"></audio></div></div>';
		}
		$me = get_current_user_id();
		if ( ! $me || $me === $author ) {
			return;
		}
		// why it fits
		if ( class_exists( 'MRSH_Match' ) ) {
			$pm = MRSH_Match::pct_for_viewer( get_post( $id ) );
			if ( $pm && ! empty( $pm[1] ) ) {
				echo '<div class="wrap narrow"><div class="box"><h3>Why this profile fits you</h3><p style="display:flex;gap:6px;flex-wrap:wrap;margin:0">';
				foreach ( array_slice( (array) $pm[1], 0, 6 ) as $r ) {
					echo '<span class="chip on">' . esc_html( $r ) . '</span>';
				}
				echo '</p></div></div>';
			}
		}
		// polite reply
		$mine = self::mine( $me );
		if ( $mine && in_array( $author, array_map( 'intval', (array) get_post_meta( $mine->ID, 'mrt_interests', true ) ), true ) ) {
			$done = (array) get_user_meta( $me, 'mrt_polite', true );
			if ( empty( $done[ $author ] ) ) {
				echo '<div class="wrap narrow"><div class="box"><h3>They sent you an interest</h3><p class="ml">Reply politely with one tap, so they are not left waiting.</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:flex;gap:8px;flex-wrap:wrap"><input type="hidden" name="action" value="mrsh_polite"><input type="hidden" name="to" value="' . (int) $author . '"><input type="hidden" name="pid" value="' . (int) $id . '">' . wp_nonce_field( 'mrsh_polite', '_wpnonce', true, false );
				foreach ( array( 'yes' => 'Yes, let us talk', 'time' => 'I need a little time', 'no' => 'Thank you, not a match' ) as $k => $l ) {
					echo '<button class="btn sm' . ( 'yes' === $k ? '' : ' line' ) . '" name="r" value="' . esc_attr( $k ) . '">' . esc_html( $l ) . '</button>';
				}
				echo '</form></div></div>';
			}
		}
	}

	public static function polite_post() {
		$me = get_current_user_id();
		if ( ! $me || ! check_admin_referer( 'mrsh_polite' ) ) {
			wp_safe_redirect( home_url( '/' ) );
			exit;
		}
		$to  = absint( $_POST['to'] ?? 0 ); // phpcs:ignore
		$pid = absint( $_POST['pid'] ?? 0 ); // phpcs:ignore
		$r   = sanitize_key( $_POST['r'] ?? '' ); // phpcs:ignore
		$tx  = array(
			'yes'  => 'Assalam o Alaikum. Thank you for your interest. I would like to talk. Please write to me.',
			'time' => 'Assalam o Alaikum. Thank you for your interest. I need a little time to think and will reply soon, InshaAllah.',
			'no'   => 'Assalam o Alaikum. Thank you for your interest. I am sorry, I do not think we are a match. I wish you the very best, InshaAllah.',
		);
		if ( $to && isset( $tx[ $r ] ) && class_exists( 'MRSH_Members' ) ) {
			MRSH_Members::send( $me, $to, $tx[ $r ], $pid );
			MRSH_Members::notify( $to, 'msg' );
			$d        = (array) get_user_meta( $me, 'mrt_polite', true );
			$d[ $to ] = $r;
			update_user_meta( $me, 'mrt_polite', $d );
		}
		wp_safe_redirect( $pid ? get_permalink( $pid ) : home_url( '/my-account/' ) );
		exit;
	}


	/* ---------- request to view a photo ---------- */

	public static function photoreq() {
		$me = get_current_user_id();
		if ( ! $me || ! wp_verify_nonce( isset( $_POST['n'] ) ? sanitize_text_field( wp_unslash( $_POST['n'] ) ) : '', 'mrt' ) ) { // phpcs:ignore
			wp_send_json( array( 'ok' => false, 'msg' => 'Please log in first.', 'login' => true ) );
		}
		$pid = absint( $_POST['pid'] ?? 0 ); // phpcs:ignore
		$to  = $pid && self::CPT === get_post_type( $pid ) ? (int) get_post_field( 'post_author', $pid ) : 0;
		if ( ! $to || $to === $me ) {
			wp_send_json( array( 'ok' => false, 'msg' => 'This is not possible.' ) );
		}
		$done = (array) get_user_meta( $me, 'mrt_photoreq', true );
		if ( in_array( $pid, $done, true ) ) {
			wp_send_json( array( 'ok' => true, 'msg' => 'You already asked. We told them.' ) );
		}
		$k = 'mrt_pr_' . $me;
		$n = (int) get_transient( $k );
		if ( $n >= 10 ) {
			wp_send_json( array( 'ok' => false, 'msg' => 'Daily limit reached. Try again tomorrow.' ) );
		}
		set_transient( $k, $n + 1, DAY_IN_SECONDS );
		$mine = self::mine( $me );
		$name = $mine ? get_the_title( $mine ) : 'A member';
		if ( class_exists( 'MRSH_Members' ) ) {
			MRSH_Members::send( $me, $to, 'Assalam o Alaikum. I would like to see your photo. Could you please add or share it? Thank you.', $pid );
			MRSH_Members::notify( $to, 'msg' );
		}
		$done[] = $pid;
		update_user_meta( $me, 'mrt_photoreq', array_slice( $done, -200 ) );
		$cnt = (int) get_post_meta( $pid, 'mrt_photoreq_n', true );
		update_post_meta( $pid, 'mrt_photoreq_n', $cnt + 1 );
		wp_send_json( array( 'ok' => true, 'msg' => 'Request sent. ' . $name . ' asked to see the photo.' ) );
	}

	public static function photoreq_js() {
		echo '<script>(function(){document.addEventListener("click",function(e){var b=e.target.closest("[data-photoreq]");if(!b)return;e.preventDefault();e.stopPropagation();var M=window.MRT||{};if(!M.in){location.href=M.login||"/wp-login.php";return}if(b.classList.contains("done"))return;var x=new XMLHttpRequest();x.open("POST",M.ajax||"/wp-admin/admin-ajax.php",true);x.setRequestHeader("Content-Type","application/x-www-form-urlencoded");x.onload=function(){try{var r=JSON.parse(x.responseText);if(r.login){location.href=M.login||"/wp-login.php";return}if(r.ok){b.classList.add("done");b.textContent="Request sent"}var t=document.getElementById("mrt-toast");if(t){t.textContent=r.msg;t.classList.add("show");setTimeout(function(){t.classList.remove("show")},2600)}else{alert(r.msg)}}catch(er){}};x.send("action=mrsh_photoreq&pid="+encodeURIComponent(b.getAttribute("data-photoreq"))+"&n="+encodeURIComponent(M.n||""))},true)})();</script>';
	}

	/* ---------- mutual interest ---------- */

	public static function on_interest( $mid, $post_id, $key, $val ) {
		if ( 'mrt_interests' !== $key || self::CPT !== get_post_type( $post_id ) || ! is_array( $val ) || ! $val ) {
			return;
		}
		$b  = (int) get_post_field( 'post_author', $post_id );
		$x  = (int) end( $val );
		$xp = $x ? self::mine( $x ) : null;
		if ( ! $b || ! $xp || $x === $b ) {
			return;
		}
		if ( ! in_array( $b, array_map( 'intval', (array) get_post_meta( $xp->ID, 'mrt_interests', true ) ), true ) ) {
			return;
		}
		foreach ( array( $b => $xp->ID, $x => $post_id ) as $uid => $other ) {
			$n = (array) get_user_meta( $uid, 'mrt_mutual_new', true );
			if ( ! in_array( $other, $n, true ) ) {
				$n[] = $other;
				update_user_meta( $uid, 'mrt_mutual_new', $n );
				$u = get_userdata( $uid );
				if ( $u && $u->user_email && ! self::quiet( $uid ) ) {
					wp_mail( $u->user_email, 'They like you too - ' . get_bloginfo( 'name' ), "Assalam o Alaikum,\n\nGood news. You and " . get_the_title( $other ) . " have both shown interest in each other. You can now write to each other:\n" . get_permalink( $other ) );
				}
			}
		}
	}

	public static function mutual_modal() {
		$uid = get_current_user_id();
		if ( ! $uid ) {
			return;
		}
		$n = array_values( array_filter( (array) get_user_meta( $uid, 'mrt_mutual_new', true ) ) );
		if ( ! $n || ! get_post( $n[0] ) ) {
			return;
		}
		$id = (int) $n[0];
		echo '<div id="mrt-mut" style="position:fixed;inset:0;z-index:100000;background:rgba(15,15,30,.6);display:grid;place-items:center;padding:16px"><div style="background:#fff;color:#111;border-radius:24px;max-width:380px;width:100%;padding:26px;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,.4)"><div style="font-size:46px">&#128150;</div><h2 style="margin:6px 0">They like you too</h2><p>You and <b>' . esc_html( get_the_title( $id ) ) . '</b> have both shown interest. Say Salam and start the conversation.</p><p style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap"><a class="btn" href="' . esc_url( get_permalink( $id ) ) . '" data-mut="1">Open profile and message</a><button type="button" class="btn line" data-mut="0">Later</button></p></div></div>';
		echo '<script>(function(){var m=document.getElementById("mrt-mut");function s(){var x=new XMLHttpRequest();x.open("POST",' . wp_json_encode( admin_url( 'admin-ajax.php' ) ) . ',true);x.setRequestHeader("Content-Type","application/x-www-form-urlencoded");x.send("action=mrsh_mutual_seen&n=' . esc_js( wp_create_nonce( 'mrsh_mutual' ) ) . '")}m.querySelectorAll("[data-mut]").forEach(function(b){b.addEventListener("click",function(e){s();if(b.getAttribute("data-mut")==="0"){e.preventDefault();m.remove()}})})})();</script>';
	}

	public static function mutual_seen() {
		$uid = get_current_user_id();
		if ( $uid && wp_verify_nonce( isset( $_POST['n'] ) ? sanitize_text_field( wp_unslash( $_POST['n'] ) ) : '', 'mrsh_mutual' ) ) { // phpcs:ignore
			delete_user_meta( $uid, 'mrt_mutual_new' );
		}
		wp_send_json_success();
	}

	/* ---------- public routes: family page and printable family card ---------- */

	public static function routes() {
		if ( isset( $_GET['mrt_family'] ) ) { // phpcs:ignore
			self::page_family( sanitize_text_field( wp_unslash( $_GET['mrt_family'] ) ) ); // phpcs:ignore
		}
		if ( isset( $_GET['mrt_card'] ) ) { // phpcs:ignore
			self::page_card( absint( $_GET['mrt_card'] ) ); // phpcs:ignore
		}
	}

	private static function shell( $title, $body ) {
		nocache_headers();
		header( 'X-Robots-Tag: noindex, nofollow' );
		header( 'Content-Type: text/html; charset=utf-8' );
		echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>' . esc_html( $title ) . '</title><style>body{margin:0;font:16px/1.6 system-ui,sans-serif;background:#f4f5fa;color:#1f2937}.w{max-width:640px;margin:0 auto;padding:16px}.c{background:#fff;border-radius:20px;box-shadow:0 2px 12px rgba(20,30,60,.08);overflow:hidden;margin:14px 0}.c img{width:100%;aspect-ratio:4/3;object-fit:cover;display:block}.c .b{padding:14px 16px}.c h2{margin:0 0 2px;font-size:1.2rem}.m{color:#667085;font-size:.9rem}.r{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}button,.bt{border:0;border-radius:12px;padding:11px 16px;font:inherit;font-weight:700;cursor:pointer;background:#e11d74;color:#fff;text-decoration:none;display:inline-block}button.g{background:#10b981}button.y{background:#f59e0b}button.n{background:#ef4444}.bt.l{background:#fff;color:#e11d74;border:1px solid #e11d74}input[type=text]{width:100%;box-sizing:border-box;padding:12px;border:1px solid #d1d5db;border-radius:12px;font:inherit}dl{margin:10px 0 0}dl div{display:flex;justify-content:space-between;gap:12px;border-top:1px dashed #e5e7eb;padding:6px 0}dt{color:#667085}dd{margin:0;font-weight:600;text-align:right}@media print{.no{display:none}body{background:#fff}.c{box-shadow:none;border:1px solid #ccc}}</style></head><body><div class="w">' . $body . '</div></body></html>'; // phpcs:ignore
		exit;
	}

	private static function photo_url( $id, $size = 'large' ) {
		if ( function_exists( 'mrt_photo_source' ) ) {
			$s = mrt_photo_source( $id, $size );
			return $s[1] ?? '';
		}
		return (string) get_the_post_thumbnail_url( $id, $size );
	}

	private static function facts( $id ) {
		$age = get_post_meta( $id, 'daage', true );
		$out = array();
		foreach ( array( 'Lives in' => 'country', 'Education' => 'education', 'Work' => 'occupation', 'Status' => 'maritalstatus', 'Religion' => 'religion', 'Sect' => 'sect', 'Caste' => 'caste' ) as $l => $t ) {
			$v = self::terms( $id, $t );
			if ( $v ) {
				$out[ $l ] = $v;
			}
		}
		return array( $age, $out );
	}

	private static function page_family( $tok ) {
		$u = $tok ? get_users( array( 'meta_key' => 'mrt_fam_tok', 'meta_value' => $tok, 'number' => 1 ) ) : array(); // phpcs:ignore
		if ( ! $u ) {
			status_header( 404 );
			self::shell( 'Link not found', '<div class="c"><div class="b"><h2>This link is not active</h2><p class="m">Ask the member for a new link.</p></div></div>' );
		}
		$u    = $u[0];
		$fav  = array_values( array_filter( array_map( 'intval', (array) get_user_meta( $u->ID, 'favorite', true ) ) ) );
		$all  = (array) get_user_meta( $u->ID, 'mrt_fam_votes', true );
		$body = '<h1 style="font-size:1.4rem">Shortlist of ' . esc_html( $u->display_name ) . '</h1><p class="m">Please look and give your opinion. Phone numbers are private.</p><p><input type="text" id="fn" maxlength="30" placeholder="Your name, e.g. Mother or Brother Ali"></p>';
		$shown = 0;
		foreach ( array_slice( $fav, 0, 30 ) as $pid ) {
			$p = get_post( $pid );
			if ( ! $p || 'publish' !== $p->post_status || self::CPT !== $p->post_type ) {
				continue;
			}
			$shown++;
			list( $age, $f ) = self::facts( $pid );
			$img = ( 'all' === ( get_user_meta( (int) $p->post_author, 'mrt_photo_priv', true ) ?: 'all' ) ) ? self::photo_url( $pid, 'medium_large' ) : '';
			$body .= '<div class="c" id="p' . $pid . '">' . ( $img ? '<img src="' . esc_url( $img ) . '" alt="" loading="lazy" referrerpolicy="no-referrer">' : '' ) . '<div class="b"><h2>' . esc_html( $p->post_title ) . ( $age ? ', ' . esc_html( $age ) : '' ) . '</h2><dl>';
			foreach ( $f as $l => $v ) {
				$body .= '<div><dt>' . esc_html( $l ) . '</dt><dd>' . esc_html( $v ) . '</dd></div>';
			}
			$body .= '</dl>';
			$vv = isset( $all[ $pid ] ) ? (array) $all[ $pid ] : array();
			if ( $vv ) {
				$body .= '<p class="m" style="margin:10px 0 0">';
				foreach ( $vv as $x ) {
					$body .= esc_html( $x['n'] ) . ': <b>' . esc_html( $x['v'] ) . '</b> &nbsp; ';
				}
				$body .= '</p>';
			}
			$body .= '<form class="r" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" onsubmit="var n=document.getElementById(\'fn\').value.trim();if(!n){alert(\'Please write your name first\');return false}this.name.value=n;localStorage.setItem(\'mrt_fn\',n)"><input type="hidden" name="action" value="mrsh_fam_vote"><input type="hidden" name="tok" value="' . esc_attr( $tok ) . '"><input type="hidden" name="pid" value="' . $pid . '"><input type="hidden" name="name" value=""><input type="text" name="hp" value="" style="display:none" tabindex="-1" autocomplete="off"><button class="g" name="v" value="yes">Yes</button><button class="y" name="v" value="maybe">Maybe</button><button class="n" name="v" value="no">No</button></form></div></div>';
		}
		if ( ! $shown ) {
			$body .= '<div class="c"><div class="b"><p>The shortlist is empty for now.</p><p class="m">The member needs to tap Shortlist on profiles first. Refresh this page after that.</p></div></div>';
		}
		$body .= '<script>try{var s=localStorage.getItem("mrt_fn");if(s)document.getElementById("fn").value=s}catch(e){}</script>';
		self::shell( 'Family shortlist', $body );
	}

	private static function page_card( $id ) {
		$p = $id ? get_post( $id ) : null;
		if ( ! is_user_logged_in() || ! $p || self::CPT !== $p->post_type || ( (int) $p->post_author !== get_current_user_id() && ! current_user_can( 'edit_others_posts' ) ) ) {
			status_header( 403 );
			self::shell( 'Not allowed', '<div class="c"><div class="b"><h2>Please log in</h2><p class="m">Only the owner of a profile can open its family card.</p><a class="bt" href="' . esc_url( wp_login_url( home_url( '/?mrt_card=' . $id ) ) ) . '">Log in</a></div></div>' );
		}
		list( $age, $f ) = self::facts( $id );
		$img  = self::photo_url( $id, 'large' );
		$txt  = self::clean( $p->post_content, 300 );
		$link = get_permalink( $id );
		$body = '<div class="c">' . ( $img ? '<img src="' . esc_url( $img ) . '" alt="" referrerpolicy="no-referrer">' : '' ) . '<div class="b"><h2>' . esc_html( $p->post_title ) . ( $age ? ', ' . esc_html( $age ) : '' ) . '</h2><dl>';
		foreach ( $f as $l => $v ) {
			$body .= '<div><dt>' . esc_html( $l ) . '</dt><dd>' . esc_html( $v ) . '</dd></div>';
		}
		$body .= '</dl>' . ( $txt ? '<p style="margin:12px 0 0">' . esc_html( $txt ) . '</p>' : '' ) . '<p class="m" style="margin:12px 0 0">' . esc_html( get_bloginfo( 'name' ) ) . ' &middot; ' . esc_html( preg_replace( '#^https?://#', '', $link ) ) . '<br>Contact only through the website. No phone number is shown.</p></div></div>';
		$body .= '<p class="r no"><button onclick="window.print()">Print or save as PDF</button><a class="bt l" target="_blank" rel="noopener" href="' . esc_url( 'https://wa.me/?text=' . rawurlencode( 'Assalam o Alaikum. My rishta profile: ' . $link ) ) . '">Share on WhatsApp</a><a class="bt l" href="' . esc_url( home_url( '/my-account/' ) ) . '">Back</a></p>';
		self::shell( 'Family card', $body );
	}
}
MRSH_Mem_More5::init();
