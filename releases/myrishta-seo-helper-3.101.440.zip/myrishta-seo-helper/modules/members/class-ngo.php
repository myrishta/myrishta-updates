<?php
/**
 * "Our work" page: mission, principles, safety measures, live numbers and a media kit.
 * Only facts the site can prove. Numbers come from the site itself and change by themselves.
 *
 * @package MyRishta_SEO_Helper
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Ngo {

	public static function init() {
		add_shortcode( 'mrsh_ngo', array( __CLASS__, 'render' ) );
		add_action( 'init', array( __CLASS__, 'make_page' ), 40 );
	}

	/** Creates the page once. Edit or delete it freely afterwards; it is not made again. */
	public static function make_page() {
		if ( get_option( 'mrsh_ngo_page' ) ) {
			return;
		}
		update_option( 'mrsh_ngo_page', 1, false );
		if ( get_page_by_path( 'our-work' ) ) {
			return;
		}
		wp_insert_post( array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_title'   => 'Our Work: A Free, Non-Profit Rishta Service',
			'post_name'    => 'our-work',
			'post_content' => '[mrsh_ngo]',
		) );
	}

	private static function stat( $n, $label ) {
		return $n > 0 ? '<div class="ngo-s"><b>' . esc_html( number_format_i18n( $n ) ) . '</b><span>' . esc_html( $label ) . '</span></div>' : '';
	}

	public static function render() {
		$site  = get_bloginfo( 'name' ) ?: 'My Rishta Pakistan';
		$mail  = function_exists( 'mrt_site' ) ? (string) mrt_site( 'email', '' ) : '';
		$mail  = $mail ?: 'support@myrishta.pk';
		$prof  = (int) ( wp_count_posts( 'listing_type' )->publish ?? 0 );
		$posts = (int) ( wp_count_posts( 'post' )->publish ?? 0 );
		$u     = count_users();
		$mem   = (int) ( $u['total_users'] ?? 0 );
		$logo  = MRSH_URL . 'assets/logos/';
		$o     = '<style>.ngo h2{margin:28px 0 10px}.ngo-g{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px}.ngo-c{background:var(--card,#fff);border:1px solid var(--line,#e5e7eb);border-radius:18px;padding:16px}.ngo-c h3{margin:0 0 6px;font-size:1.05rem}.ngo-c p{margin:0;color:var(--mut,#5b6270)}.ngo-st{display:flex;flex-wrap:wrap;gap:12px;margin:14px 0}.ngo-s{flex:1 1 140px;background:linear-gradient(135deg,#6e1230,#9a1d43);color:#fff;border-radius:18px;padding:16px;text-align:center}.ngo-s b{display:block;font-size:1.8rem;line-height:1.1}.ngo-s span{font-size:.85rem;opacity:.9}.ngo-k{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px}.ngo-k a{display:block;text-align:center;border:1px solid var(--line,#e5e7eb);border-radius:14px;padding:10px;background:#fff;text-decoration:none}.ngo-k img{max-width:100%;height:80px;object-fit:contain}.ngo-k a:nth-child(3){background:#6e1230;color:#fff}.ngo-bp{background:var(--soft,#f6f7f9);border-radius:16px;padding:16px;margin:10px 0}.ngo-sw{display:inline-block;width:18px;height:18px;border-radius:5px;vertical-align:middle;margin:0 4px 0 10px;border:1px solid rgba(0,0,0,.15)}</style>';
		$o    .= '<div class="ngo">';
		$o    .= '<p class="lead">' . esc_html( $site ) . ' is a free rishta service run by a non-profit organization in Lahore. We help Pakistani families in Pakistan and abroad look for a suitable match in a safe, private and respectful way, without fees and without agents.</p>';
		$o    .= '<p lang="ur" dir="rtl">مائی رشتہ پاکستان لاہور میں ایک غیر منافع بخش ادارے کی طرف سے چلائی جانے والی مفت رشتہ سروس ہے۔ ہم پاکستانی خاندانوں کو محفوظ، نجی اور باعزت طریقے سے رشتہ تلاش کرنے میں مدد دیتے ہیں۔</p>';
		$st    = self::stat( $mem, 'registered members' ) . self::stat( $prof, 'profiles' ) . self::stat( $posts, 'free guides' );
		if ( $st ) {
			$o .= '<div class="ngo-st">' . $st . '</div>';
		}
		$o    .= '<h2>What we do</h2><div class="ngo-g">'
			. '<div class="ngo-c"><h3>Free profiles</h3><p>Creating a profile, searching and sending interest are free. We do not sell phone numbers or contact details.</p></div>'
			. '<div class="ngo-c"><h3>Family first</h3><p>Members can name a guardian and say who manages the profile. Meetings are encouraged in public places with elders present.</p></div>'
			. '<div class="ngo-c"><h3>Free guides</h3><p>Plain-language guides on biodata, first meetings, safety, and how to search by city, in English and Urdu.</p></div>'
			. '<div class="ngo-c"><h3>Support for overseas families</h3><p>Pages and guides for Pakistani families in the UK, USA, Canada, UAE and Saudi Arabia.</p></div></div>';
		$o    .= '<h2>How we keep members safe</h2><ul>'
			. '<li>Phone numbers stay private. Contact happens through the site first.</li>'
			. '<li>Email confirmation and an optional selfie check help reduce fake profiles.</li>'
			. '<li>Every profile has a Report button. Reports are read by our team.</li>'
			. '<li>Messages are checked for abusive words and for requests for money, and we warn or remove members who break the rules.</li>'
			. '<li>We tell every member: never send money or ID photos to someone you have not met with your family.</li></ul>';
		$o    .= '<p>Read our <a href="' . esc_url( home_url( '/safe-meeting-guide/' ) ) . '">safe meeting guide</a>, <a href="' . esc_url( home_url( '/privacy-policy/' ) ) . '">privacy policy</a> and <a href="' . esc_url( home_url( '/terms-and-conditions/' ) ) . '">terms</a>.</p>';
		$o    .= '<h2>Our principles</h2><div class="ngo-g">'
			. '<div class="ngo-c"><h3>No fees from families</h3><p>We do not take money to arrange a match, and we do not use agents.</p></div>'
			. '<div class="ngo-c"><h3>Honest information</h3><p>We publish only real member stories, with permission. We never invent testimonials.</p></div>'
			. '<div class="ngo-c"><h3>Respect for everyone</h3><p>Every family is welcome, whatever their city, sect, caste or income.</p></div></div>';
		$o    .= '<h2>Media kit</h2><p>Journalists and partners are welcome to use these logos and the text below.</p><div class="ngo-k">';
		foreach ( array( 'logo-horizontal.png' => 'Logo, horizontal', 'logo-vertical.png' => 'Logo, square', 'logo-horizontal-white.png' => 'Logo, white', 'og-image-1200x630.png' => 'Share image' ) as $f => $l ) {
			$o .= '<a href="' . esc_url( $logo . $f ) . '" target="_blank" rel="noopener"><img src="' . esc_url( $logo . $f ) . '" alt="' . esc_attr( $site . ' ' . $l ) . '" loading="lazy" width="200" height="80"><br>' . esc_html( $l ) . '</a>';
		}
		$o    .= '</div><div class="ngo-bp"><b>About ' . esc_html( $site ) . ' (short text)</b><br>' . esc_html( $site ) . ' (myrishta.pk) is a free rishta service run by a non-profit organization in Shahdara, Lahore. It helps Pakistani families in Pakistan and overseas find a suitable match with privacy, family involvement and safety checks, and without agents or fees from families.</div>';
		$o    .= '<p><b>Brand colours</b><span class="ngo-sw" style="background:#6e1230"></span>Maroon #6E1230<span class="ngo-sw" style="background:#c9962f"></span>Gold #C9962F<span class="ngo-sw" style="background:#12a375"></span>Green #12A375</p>';
		$o    .= '<h2>Media and partnerships</h2><p>For interviews, partnerships or volunteering, write to <a href="mailto:' . esc_attr( $mail ) . '">' . esc_html( $mail ) . '</a> or use the <a href="' . esc_url( home_url( '/contact/' ) ) . '">contact page</a>. Want to help families directly? See <a href="' . esc_url( home_url( '/volunteer/' ) ) . '">volunteer with us</a>.</p>';
		$o    .= '</div>';
		return $o;
	}
}

MRSH_Ngo::init();
