<?php
/** Creates the pages that the newer member features need (biodata, checklist, report history ...) so a plain upgrade is complete without any manual page setup. Existing pages are never changed. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Pages {

	/** slug => array( title, shortcode, noindex ) */
	public static function wanted() {
		return array(
			'my-biodata'      => array( 'My biodata', '[mrt_biodata]', 1 ),
			'get-started'     => array( 'Quick start checklist', '[mrt_checklist]', 1 ),
			'my-reports'      => array( 'My report history', '[mrt_my_reports]', 1 ),
			'blocked-profiles' => array( 'Blocked profiles', '[mrt_my_blocks]', 1 ),
			'trusted-contact' => array( 'Trusted contact', '[mrt_trusted_contact]', 1 ),
			'recover-account' => array( 'Recover my account', '[mrt_recover]', 1 ),
			'scam-alerts'     => array( 'Scam alerts', '[mrt_scam_alerts]', 0 ),
			'city-groups'     => array( 'City groups', '[mrt_city_groups]', 0 ),
			'site-statistics' => array( 'Site statistics', '[mrt_stats]', 0 ),
		);
	}

	public static function init() {
		if ( ! is_admin() ) {
			return;
		}
		add_action( 'admin_init', array( __CLASS__, 'auto' ) );
		add_action( 'admin_post_mrsh_make_pages', array( __CLASS__, 'button' ) );
	}

	/** Runs once after each upgrade, for administrators only. */
	public static function auto() {
		if ( ! current_user_can( 'manage_options' ) || get_option( 'mrsh_pages_ver' ) === MRSH_VERSION || ( class_exists( 'MRSH_Feat' ) && ! MRSH_Feat::on( 'pages' ) ) ) {
			return;
		}
		self::make();
		update_option( 'mrsh_pages_ver', MRSH_VERSION, false );
	}

	/** Create every missing page. Returns the number created. */
	public static function make() {
		global $wpdb;
		$made = 0;
		foreach ( self::wanted() as $slug => $w ) {
			if ( get_page_by_path( $slug, OBJECT, 'page' ) ) {
				continue;
			}
			// Skip if any published page already carries this shortcode (the owner made it by hand).
			$tag = trim( $w[1], '[]' );
			$has = $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type='page' AND post_status IN ('publish','draft','private') AND post_content LIKE %s LIMIT 1", '%[' . $wpdb->esc_like( $tag ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			if ( $has ) {
				continue;
			}
			$id = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => $w[0], 'post_name' => $slug, 'post_content' => $w[1] ), true );
			if ( $id && ! is_wp_error( $id ) ) {
				if ( $w[2] ) {
					update_post_meta( $id, '_mrsh_noindex', '1' );
				}
				++$made;
			}
		}
		return $made;
	}

	public static function button() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_make_pages' );
		$n = self::make();
		set_transient( 'mrsh_notice_' . get_current_user_id(), array( $n ? sprintf( 'Created %d missing page(s).', $n ) : 'Nothing to create: every page already exists.', 'success' ), 60 );
		MRSH_Admin::back( 'myrishta-seo-backup' );
	}
}

MRSH_Pages::init();
