<?php
/**
 * Membership plans page: change names, prices, features and colours, choose the highlighted plan,
 * or show every plan as free. Saves into the same Site Settings value the theme already reads (mrsh_site > plans).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Plans {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 27 );
		add_action( 'admin_post_mrsh_plans_save', array( __CLASS__, 'save' ) );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Membership plans', 'Membership plans', 'manage_options', 'mrsh-plans', array( __CLASS__, 'page' ) );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$plans = function_exists( 'mrt_plans' ) ? mrt_plans() : array();
		$free  = (int) get_option( 'mrsh_plans_free', 0 );
		$hot   = (string) get_option( 'mrsh_plans_hot', '' );
		echo '<div class="wrap"><h1>Membership plans</h1>';
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success is-dismissible"><p>Saved. Open the Membership page on your website to see it.</p></div>';
		}
		echo '<p>Change the names, prices and what each plan includes. Leave a name empty to remove that plan. The first plan is the one every new member starts on.</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_plans_save">';
		wp_nonce_field( 'mrsh_plans_save' );
		echo '<p><label style="font-size:15px"><input type="checkbox" name="free" value="1"' . checked( $free, 1, false ) . '> <b>Make everything free</b> (every plan shows "Free" as its price and the payment note is hidden)</label></p>';
		echo '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:16px;max-width:1300px">';
		for ( $i = 0; $i < 6; $i++ ) {
			$p   = $plans[ $i ] ?? array( '', '', array(), '' );
			$col = $p[3] ? $p[3] : '#12a375';
			echo '<div style="background:#fff;border:1px solid #dcdcde;border-top:4px solid ' . esc_attr( $col ) . ';border-radius:14px;padding:16px;box-shadow:0 1px 3px rgba(0,0,0,.06)">';
			echo '<h3 style="margin:0 0 10px">Plan ' . (int) ( $i + 1 ) . '</h3>';
			echo '<p style="margin:0 0 8px"><label>Name<br><input type="text" class="widefat" name="n[' . $i . ']" value="' . esc_attr( $p[0] ) . '" placeholder="Example: Gold"></label></p>';
			echo '<p style="margin:0 0 8px"><label>Price<br><input type="text" class="widefat" name="pr[' . $i . ']" value="' . esc_attr( $p[1] ) . '" placeholder="Rs 1,500 or Free"></label></p>';
			echo '<p style="margin:0 0 8px"><label>What is included (one per line)<br><textarea class="widefat" rows="5" name="f[' . $i . ']">' . esc_textarea( implode( "\n", (array) $p[2] ) ) . '</textarea></label></p>';
			echo '<p style="margin:0 0 8px"><label>Colour <input type="color" name="c[' . $i . ']" value="' . esc_attr( preg_match( '/^#[0-9a-f]{6}$/i', $p[3] ) ? $p[3] : '#12a375' ) . '"></label> ';
			echo '<label style="margin-left:12px"><input type="radio" name="hot" value="' . $i . '"' . checked( ( '' !== $p[0] && 0 === strcasecmp( $p[0], $hot ) ), true, false ) . '> Highlight as most popular</label></p>';
			echo '</div>';
		}
		echo '</div><p><label><input type="radio" name="hot" value="-1"' . checked( '' === $hot, true, false ) . '> No highlighted plan (the last of three or more is used)</label></p>';
		echo '<p><button class="button button-primary button-large">Save plans</button> <a class="button" href="' . esc_url( home_url( '/' ) ) . '" target="_blank">Open website</a></p></form>';
		echo '<p class="description">Payment instructions for paid plans are on Design > Look and content > Content tab ("How to pay").</p></div>';
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_plans_save' );
		$clean = function ( $v ) { return trim( str_replace( array( '|', ';' ), array( '/', ',' ), sanitize_text_field( (string) $v ) ) ); };
		$n     = isset( $_POST['n'] ) ? (array) wp_unslash( $_POST['n'] ) : array(); // phpcs:ignore
		$pr    = isset( $_POST['pr'] ) ? (array) wp_unslash( $_POST['pr'] ) : array(); // phpcs:ignore
		$f     = isset( $_POST['f'] ) ? (array) wp_unslash( $_POST['f'] ) : array(); // phpcs:ignore
		$c     = isset( $_POST['c'] ) ? (array) wp_unslash( $_POST['c'] ) : array(); // phpcs:ignore
		$lines = array();
		$hot   = '';
		$hi    = isset( $_POST['hot'] ) ? (int) $_POST['hot'] : -1; // phpcs:ignore
		foreach ( $n as $i => $name ) {
			$name = $clean( $name );
			if ( '' === $name ) {
				continue;
			}
			$feat = array();
			foreach ( preg_split( '/\r\n|\r|\n/', (string) ( $f[ $i ] ?? '' ) ) as $x ) {
				$x = $clean( $x );
				if ( '' !== $x ) {
					$feat[] = $x;
				}
			}
			$col     = isset( $c[ $i ] ) && preg_match( '/^#[0-9a-f]{6}$/i', $c[ $i ] ) ? $c[ $i ] : '';
			$lines[] = $name . ' | ' . ( '' !== $clean( $pr[ $i ] ?? '' ) ? $clean( $pr[ $i ] ) : 'Free' ) . ' | ' . implode( '; ', $feat ) . ( $col ? ' | ' . $col : '' );
			if ( (int) $i === $hi ) {
				$hot = $name;
			}
		}
		$st          = (array) get_option( 'mrsh_site', array() );
		$st['plans'] = implode( "\n", $lines );
		update_option( 'mrsh_site', $st, false );
		update_option( 'mrsh_plans_free', empty( $_POST['free'] ) ? 0 : 1, false ); // phpcs:ignore
		update_option( 'mrsh_plans_hot', $hot, false );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-plans&ok=1' ) );
		exit;
	}
}
MRSH_Plans::init();
