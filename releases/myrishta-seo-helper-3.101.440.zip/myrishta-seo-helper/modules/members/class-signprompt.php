<?php
/**
 * Sign in / sign up prompt (3.101.168).
 * Google's own One Tap box (from Site Kit) already shows to visitors who are signed in to Google, but Google hides it for a while after one
 * close and never shows it to people who are not signed in to Google in that browser. This adds a small bottom card for logged out visitors:
 * "Continue with Google" (the site's own Google login, which also creates the account for new members). It appears a few seconds after the
 * page opens, can be closed, and stays closed for 7 days. Never shown to members, on the login / account / add-profile pages, or when Google login is off.
 * Switch: Growth > Social login page has the Google keys; this card has its own on/off option `mrsh_signprompt` (on by default).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Signprompt {

	const OPT = 'mrsh_signprompt';

	public static function on() {
		$o = get_option( self::OPT, null );
		return null === $o ? true : (bool) $o;
	}

	public static function init() {
		add_action( 'wp_footer', array( __CLASS__, 'card' ), 60 );
		// Google's own One Tap box opens by itself the moment a page loads and can freeze a phone. Our card replaces it and waits for the visitor to scroll.
		add_filter( 'option_googlesitekit_sign-in-with-google_settings', function ( $v ) {
			if ( is_array( $v ) && ! is_admin() && self::on() && class_exists( 'MRSH_Mem_Social' ) && MRSH_Mem_Social::ready( 'google' ) ) {
				$v['oneTapEnabled'] = false;
			}
			return $v;
		} );
		add_action( 'admin_post_mrsh_signprompt', array( __CLASS__, 'save' ) );
		add_filter( 'mrsh_social_extra_note', array( __CLASS__, 'note' ) );
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.', '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'mrsh_signprompt' );
		update_option( self::OPT, isset( $_POST['on'] ) ? 1 : 0, false );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-social&ok=1' ) );
		exit;
	}

	public static function note( $h ) {
		return $h . '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin:14px 0"><input type="hidden" name="action" value="mrsh_signprompt">' . wp_nonce_field( 'mrsh_signprompt', '_wpnonce', true, false ) . '<label><input type="checkbox" name="on" value="1"' . checked( self::on(), true, false ) . '> Show the "Continue with Google" card to visitors who are not logged in</label> <button class="button">Save</button></form>';
	}

	private static function skip() {
		if ( is_user_logged_in() || is_admin() || is_404() || ! self::on() ) {
			return true;
		}
		if ( ! class_exists( 'MRSH_Mem_Social' ) || ! MRSH_Mem_Social::ready( 'google' ) ) {
			return true;
		}
		$p = isset( $_SERVER['REQUEST_URI'] ) ? strtolower( (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH ) ) : ''; // phpcs:ignore
		foreach ( array( 'my-account', 'wp-login', 'add-listing', 'register', 'memberships', 'recover-account', 'privacy', 'terms', 'delete', 'data-deletion', 'checkout' ) as $s ) {
			if ( false !== strpos( $p, $s ) ) {
				return true;
			}
		}
		return false;
	}

	public static function card() {
		if ( self::skip() ) {
			return;
		}
		$to  = isset( $_SERVER['REQUEST_URI'] ) ? home_url( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : home_url( '/' ); // phpcs:ignore
		$url = add_query_arg( array( 'mrsh_social' => 'google', 'to' => $to ), home_url( '/' ) );
		$g   = '<svg viewBox="0 0 48 48" width="20" height="20" aria-hidden="true"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.1C12.4 13.6 17.7 9.5 24 9.5z"/><path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.6 5.9c4.4-4.1 7-10.1 7-17.6z"/><path fill="#FBBC05" d="M10.5 28.7c-.5-1.4-.8-3-.8-4.7s.3-3.2.8-4.7l-7.9-6.1C.9 16.400 0 20.100 0 24s.9 7.600 2.600 10.800l7.900-6.100z"/><path fill="#34A853" d="M24 48c6.500 0 11.900-2.100 15.900-5.800l-7.600-5.900c-2.100 1.400-4.900 2.300-8.300 2.300-6.300 0-11.600-4.100-13.500-9.800l-7.900 6.100C6.500 42.600 14.600 48 24 48z"/></svg>';
		?>
<div id="mrsh-sp" role="dialog" aria-label="Sign in or sign up" hidden>
<style>
#mrsh-sp{position:fixed;z-index:99990;left:50%;bottom:calc(14px + env(safe-area-inset-bottom,0px));transform:translate(-50%,24px);opacity:0;transition:.35s;width:min(440px,calc(100vw - 24px));background:#fff;border:1px solid #efe3e7;border-radius:20px;box-shadow:0 18px 50px rgba(59,10,25,.28);padding:16px 18px;font-family:inherit;color:#2b2433}
#mrsh-sp.on{opacity:1;transform:translate(-50%,0)}
@media(max-width:760px){#mrsh-sp{bottom:calc(78px + env(safe-area-inset-bottom,0px))}}
#mrsh-sp b{display:block;font-size:1.02rem;margin:0 26px 3px 0}
#mrsh-sp span.d{display:block;font-size:.88rem;color:#6b6168;margin-bottom:12px}
#mrsh-sp a.go{display:flex;align-items:center;justify-content:center;gap:10px;min-height:46px;border:1.5px solid #e4d6db;border-radius:14px;background:#fff;color:#2b2433;font-weight:700;text-decoration:none}
#mrsh-sp a.go:hover{border-color:#9b1b4b}
#mrsh-sp button{position:absolute;top:8px;right:10px;width:30px;height:30px;border:0;border-radius:50%;background:transparent;color:#8a7c80;font-size:20px;line-height:1;cursor:pointer}
#mrsh-sp small{display:block;margin-top:10px;text-align:center;font-size:.8rem;color:#6b6168}#mrsh-sp small a{color:#6e1230;font-weight:700}
</style>
<button type="button" aria-label="Close" data-x>&times;</button>
<b>Sign in or sign up, free</b>
<span class="d">One tap with Google. New here? Your account is made for you.</span>
<a class="go" rel="nofollow" href="<?php echo esc_url( $url ); ?>"><?php echo $g; // phpcs:ignore ?><span>Continue with Google</span></a>
<small>or <a href="<?php echo esc_url( function_exists( 'mrt_link' ) ? mrt_link( 'myaccount', '/my-account/' ) : home_url( '/my-account/' ) ); ?>">use email or mobile number</a></small>
</div>
<script>
(function(){var k='mrsh_sp_x',e=document.getElementById('mrsh-sp');if(!e)return;
try{if(Date.now()-(+localStorage.getItem(k)||0)<6048e5)return}catch(x){}
(window.mrtLate||function(k,f){setTimeout(f,15000)})('sp',function(){e.hidden=false;requestAnimationFrame(function(){e.classList.add('on')})});
e.querySelector('[data-x]').onclick=function(){e.classList.remove('on');setTimeout(function(){e.hidden=true},400);try{localStorage.setItem(k,Date.now())}catch(x){}};
})();
</script>
		<?php
	}
}
MRSH_Signprompt::init();
