<?php
/**
 * Match making: compatibility score (0-100), partner preferences, "matches for you", "who matches both ways",
 * "why this match" reasons, and an optional weekly email with new matches.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Match {

	/** field => array( taxonomy, post meta key, label, weight, preference key ) */
	public static function dims() {
		return array(
			'religion' => array( 'religion', 'custom-18', 'Religion', 20 ),
			'sect'     => array( 'sect', 'custom-19', 'Sect', 10 ),
			'caste'    => array( 'caste', 'custom-20', 'Caste', 8 ),
			'marital'  => array( 'maritalstatus', 'custom-15', 'Marital status', 10 ),
			'edu'      => array( 'education', 'custom-2322', 'Education', 10 ),
			'job'      => array( 'occupation', 'custom-24', 'Occupation', 4 ),
			'nation'   => array( 'nationality', 'custom-21', 'Nationality', 8 ),
		);
	}

	public static function init() {
		add_action( 'admin_post_mrt_save_pref', array( __CLASS__, 'save_pref' ) );
		add_action( 'mrsh_weekly_matches', array( __CLASS__, 'weekly' ) );
		add_action( 'init', function () {
			if ( ! wp_next_scheduled( 'mrsh_weekly_matches' ) ) {
				wp_schedule_event( time() + DAY_IN_SECONDS, 'weekly', 'mrsh_weekly_matches' );
			}
		} );
		add_filter( 'cron_schedules', function ( $s ) {
			if ( empty( $s['weekly'] ) ) {
				$s['weekly'] = array( 'interval' => WEEK_IN_SECONDS, 'display' => 'Weekly' );
			}
			return $s;
		} );
	}

	public static function val( $id, $tax, $key ) {
		if ( taxonomy_exists( $tax ) ) {
			$n = wp_get_object_terms( $id, $tax, array( 'fields' => 'names', 'number' => 1 ) );
			if ( ! is_wp_error( $n ) && $n ) {
				return (string) $n[0];
			}
		}
		return trim( (string) get_post_meta( $id, $key, true ) );
	}

	public static function gender( $id ) {
		$g = strtolower( self::val( $id, 'dagender', 'key4' ) );
		if ( false !== strpos( $g, 'female' ) ) {
			return 'Female';
		}
		return false !== strpos( $g, 'male' ) ? 'Male' : '';
	}

	public static function pref( $uid ) {
		$p = get_user_meta( $uid, 'mrt_pref', true );
		return is_array( $p ) ? $p : array();
	}

	/** Age window the person is looking for. */
	public static function age_range( $post, $pref ) {
		$age = (int) get_post_meta( $post->ID, 'daage', true );
		$g   = self::gender( $post->ID );
		if ( ! empty( $pref['age_min'] ) || ! empty( $pref['age_max'] ) ) {
			return array( max( 18, (int) ( $pref['age_min'] ?? 18 ) ), min( 80, (int) ( $pref['age_max'] ?? 80 ) ) );
		}
		if ( ! $age ) {
			return array( 18, 80 );
		}
		return 'Male' === $g ? array( max( 18, $age - 8 ), $age + 2 ) : array( max( 18, $age - 3 ), $age + 9 );
	}

	/** Score of candidate $b for member profile $a. Returns array( percent, reasons[], dealbreaker ). */
	public static function score( $a, $b, $pref = null ) {
		$pref = null === $pref ? self::pref( (int) $a->post_author ) : $pref;
		$ga   = self::gender( $a->ID );
		$gb   = self::gender( $b->ID );
		if ( $ga && $gb && $ga === $gb ) {
			return array( 0, array(), true );
		}
		$pts = 0;
		$max = 0;
		$why = array();
		// Age (25 points).
		$max += 25;
		list( $lo, $hi ) = self::age_range( $a, $pref );
		$ab = (int) get_post_meta( $b->ID, 'daage', true );
		if ( $ab ) {
			if ( $ab >= $lo && $ab <= $hi ) {
				$pts += 25;
				$why[] = 'Age ' . $ab . ' fits your range';
			} elseif ( $ab >= $lo - 3 && $ab <= $hi + 3 ) {
				$pts += 12;
			}
		} else {
			$pts += 8;
		}
		foreach ( self::dims() as $k => $d ) {
			$max += $d[3];
			$mine   = self::val( $a->ID, $d[0], $d[1] );
			$theirs = self::val( $b->ID, $d[0], $d[1] );
			if ( '' === $theirs ) {
				$pts += (int) round( $d[3] * 0.3 );
				continue;
			}
			$want = ! empty( $pref[ $k ] ) ? (array) $pref[ $k ] : array();
			if ( 'marital' === $k && ! $want ) {
				$want = array(); // any status unless chosen
				$pts += (int) round( $d[3] * 0.6 );
				continue;
			}
			if ( $want ) {
				if ( in_array( $theirs, $want, true ) ) {
					$pts += $d[3];
					$why[] = $d[2] . ': ' . $theirs;
				}
			} elseif ( '' !== $mine && 0 === strcasecmp( $mine, $theirs ) ) {
				$pts += $d[3];
				$why[] = 'Same ' . strtolower( $d[2] ) . ': ' . $theirs;
			} elseif ( '' === $mine ) {
				$pts += (int) round( $d[3] * 0.4 );
			}
		}
		// Country / city (10).
		$max += 10;
		$ca = wp_get_object_terms( $a->ID, 'country', array( 'fields' => 'names', 'number' => 1 ) );
		$cb = wp_get_object_terms( $b->ID, 'country', array( 'fields' => 'names', 'number' => 1 ) );
		if ( ! is_wp_error( $ca ) && ! is_wp_error( $cb ) && $ca && $cb ) {
			$wc = ! empty( $pref['country'] ) ? (array) $pref['country'] : array();
			if ( ( $wc && in_array( $cb[0], $wc, true ) ) || ( ! $wc && $ca[0] === $cb[0] ) ) {
				$pts += 10;
				$why[] = 'Lives in ' . $cb[0];
			}
		} else {
			$pts += 4;
		}
		// Bonus: has photo, verified.
		$max += 5;
		if ( has_post_thumbnail( $b ) ) {
			$pts += 3;
		}
		if ( get_post_meta( $b->ID, 'mrsh_verified', true ) ) {
			$pts += 2;
			$why[] = 'Verified profile';
		}
		return array( (int) min( 100, round( 100 * $pts / max( 1, $max ) ) ), array_slice( $why, 0, 4 ), false );
	}

	/** Candidate pool for profile $a. */
	private static function pool( $a, $pref, $limit = 150 ) {
		$ga   = self::gender( $a->ID );
		$want = 'Male' === $ga ? 'Female' : ( 'Female' === $ga ? 'Male' : '' );
		list( $lo, $hi ) = self::age_range( $a, $pref );
		$args = array(
			'post_type' => 'listing_type', 'post_status' => 'publish', 'posts_per_page' => $limit, 'post__not_in' => array( $a->ID ),
			'author__not_in' => array( (int) $a->post_author ), 'no_found_rows' => true, 'orderby' => 'date', 'order' => 'DESC',
			'meta_query' => array( array( 'key' => 'daage', 'value' => array( max( 18, $lo - 3 ), $hi + 3 ), 'type' => 'NUMERIC', 'compare' => 'BETWEEN' ) ),
		);
		if ( $want ) {
			$args['tax_query'] = array( array( 'taxonomy' => 'dagender', 'field' => 'name', 'terms' => $want ) );
		}
		return get_posts( $args );
	}

	/** Best matches for a profile: array of array( post, percent, reasons ). Cached for 3 hours. */
	public static function best( $a, $n = 12, $min = 0 ) {
		$min = $min ? $min : (int) MRSH_Manage::get()['minpct'];
		$ck = 'mrt_best_' . $a->ID . '_' . $n;
		$c  = get_transient( $ck );
		if ( is_array( $c ) ) {
			return $c;
		}
		$pref = self::pref( (int) $a->post_author );
		$hid  = (array) get_user_meta( (int) $a->post_author, 'mrt_hidden', true );
		$out  = array();
		foreach ( self::pool( $a, $pref ) as $b ) {
			if ( in_array( $b->ID, $hid, true ) ) {
				continue;
			}
			$s = self::score( $a, $b, $pref );
			if ( ! $s[2] && $s[0] >= $min ) {
				$out[] = array( 'post' => $b, 'pct' => $s[0], 'why' => $s[1] );
			}
		}
		usort( $out, function ( $x, $y ) {
			return $y['pct'] <=> $x['pct'];
		} );
		$out = array_slice( $out, 0, $n );
		set_transient( $ck, $out, 3 * HOUR_IN_SECONDS );
		return $out;
	}

	/** Matches in both directions: they fit you and you fit them. */
	public static function mutual( $a, $n = 8 ) {
		$out = array();
		foreach ( self::best( $a, 40, 55 ) as $m ) {
			$back = self::score( $m['post'], $a );
			if ( $back[0] >= 55 ) {
				$m['back'] = $back[0];
				$out[]     = $m;
			}
		}
		return array_slice( $out, 0, $n );
	}

	public static function pct_for_viewer( $b ) {
		$uid = get_current_user_id();
		if ( ! $uid ) {
			return null;
		}
		$a = MRSH_Members::my_profile( $uid );
		if ( ! $a || $a->ID === $b->ID ) {
			return null;
		}
		$s = self::score( $a, $b );
		return $s[2] ? null : array( $s[0], $s[1] );
	}

	/** Terms offered on the preferences form. */
	public static function options( $tax ) {
		$t = taxonomy_exists( $tax ) ? get_terms( array( 'taxonomy' => $tax, 'hide_empty' => false, 'number' => 80, 'fields' => 'names' ) ) : array();
		return is_wp_error( $t ) ? array() : $t;
	}

	public static function save_pref() {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( wp_login_url() );
			exit;
		}
		check_admin_referer( 'mrt_save_pref' );
		$uid = get_current_user_id();
		$p   = array(
			'age_min' => isset( $_POST['age_min'] ) ? max( 0, min( 80, absint( $_POST['age_min'] ) ) ) : 0,
			'age_max' => isset( $_POST['age_max'] ) ? max( 0, min( 80, absint( $_POST['age_max'] ) ) ) : 0,
		);
		foreach ( array_merge( array_keys( self::dims() ), array( 'country' ) ) as $k ) {
			$v = isset( $_POST['pf'][ $k ] ) ? array_map( 'sanitize_text_field', array_map( 'wp_unslash', (array) $_POST['pf'][ $k ] ) ) : array();
			$p[ $k ] = array_values( array_filter( $v ) );
		}
		$p['digest'] = empty( $_POST['digest'] ) ? 0 : 1;
		update_user_meta( $uid, 'mrt_pref', $p );
		$mine = MRSH_Members::my_profile( $uid );
		if ( $mine ) {
			foreach ( array( 12, 40 ) as $n ) {
				delete_transient( 'mrt_best_' . $mine->ID . '_' . $n );
			}
		}
		wp_safe_redirect( add_query_arg( array( 'tab' => 'matches', 'ok' => 1 ), function_exists( 'mrt_link' ) ? mrt_link( 'myaccount', '/my-account/' ) : home_url( '/my-account/' ) ) );
		exit;
	}

	/** Weekly email: top 5 new matches (names and percent only; no phone or photo), once a week, opt-out in preferences. */
	public static function weekly() {
		$users = get_users( array( 'fields' => array( 'ID', 'user_email' ), 'number' => 400, 'meta_key' => 'mrt_pref', 'meta_compare' => 'NOT EXISTS' ) );
		$users = array_merge( $users, get_users( array( 'fields' => array( 'ID', 'user_email' ), 'number' => 400, 'meta_key' => 'mrt_pref', 'meta_compare' => 'EXISTS' ) ) );
		$sent  = 0;
		foreach ( $users as $u ) {
			if ( $sent >= 200 ) {
				break;
			}
			$pref = self::pref( $u->ID );
			if ( ! MRSH_Manage::get()['digest'] ) {
				return;
			}
			if ( isset( $pref['digest'] ) && ! $pref['digest'] ) {
				continue;
			}
			$a = MRSH_Members::my_profile( $u->ID );
			if ( ! $a || 'publish' !== $a->post_status ) {
				continue;
			}
			$seen = (array) get_user_meta( $u->ID, 'mrt_digest_seen', true );
			$list = array();
			foreach ( self::best( $a, 20, 60 ) as $m ) {
				if ( ! in_array( $m['post']->ID, $seen, true ) ) {
					$list[] = $m;
				}
				if ( count( $list ) >= 5 ) {
					break;
				}
			}
			if ( ! $list ) {
				continue;
			}
			$body = "Assalam o Alaikum,\n\nNew matches for you on " . get_bloginfo( 'name' ) . ":\n\n";
			foreach ( $list as $m ) {
				$body  .= $m['pct'] . '% match - ' . get_the_title( $m['post'] ) . ' - ' . get_permalink( $m['post'] ) . "\n";
				$seen[] = $m['post']->ID;
			}
			$body .= "\nTurn this email off any time in My account > Matches > Preferences.\nNever send money to anyone you meet online.\n";
			wp_mail( $u->user_email, 'New matches for you', $body );
			update_user_meta( $u->ID, 'mrt_digest_seen', array_slice( array_unique( $seen ), -200 ) );
			$sent++;
		}
	}
}
MRSH_Match::init();
