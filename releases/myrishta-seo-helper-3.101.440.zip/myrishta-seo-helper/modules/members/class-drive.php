<?php
/**
 * Google Drive backup upload. Connects with Google OAuth (scope drive.file: the plugin can only see files it created),
 * sends every finished full backup to a Drive folder in 5 MB pieces (resumable, safe for very large zips),
 * keeps the newest N copies, and shows progress on the Full backup page. No extra plugin is needed.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Drive {

	const OPT = 'mrsh_drive';
	const TOK = 'mrsh_drive_tok';
	const JOB = 'mrsh_drive_job';
	const LOG = 'mrsh_drive_log';
	const FID = 'mrsh_drive_folder';
	const CH  = 5242880; // 5 MiB, a multiple of 256 KiB as Google requires.

	public static function o( $k = null ) {
		$o = array_merge( array( 'use_login' => 1, 'client_id' => '', 'client_secret' => '', 'folder' => 'MyRishta backups', 'keep' => 7, 'when' => 'auto' ), (array) get_option( self::OPT, array() ) );
		return null === $k ? $o : ( $o[ $k ] ?? null );
	}

	public static function init() {
		add_action( 'mrsh_fb_done', array( __CLASS__, 'on_backup' ), 10, 2 );
		add_action( 'mrsh_drive_cron', array( __CLASS__, 'cron' ) );
		foreach ( array( 'save', 'connect', 'cb', 'disconnect', 'send' ) as $a ) {
			add_action( 'admin_post_mrsh_drive_' . $a, array( __CLASS__, $a ) );
		}
		add_action( 'wp_ajax_mrsh_drive_step', array( __CLASS__, 'ajax_step' ) );
		add_action( 'wp_ajax_mrsh_drive_test', array( __CLASS__, 'ajax_test' ) );
	}

	/* ---------------------------------------------------------------- credentials and tokens */
	public static function creds() {
		$o = self::o();
		$own = (string) $o['client_id'];
		$own_ok = false !== stripos( $own, '.apps.googleusercontent.com' ) && '' !== (string) $o['client_secret'];
		if ( ( ! empty( $o['use_login'] ) || ! $own_ok ) && class_exists( 'MRSH_Keys' ) ) {
			$k = MRSH_Keys::get();
			if ( ! empty( $k['google_id'] ) && ! empty( $k['google_secret'] ) ) {
				return array( $k['google_id'], $k['google_secret'] );
			}
		}
		return array( (string) $o['client_id'], (string) $o['client_secret'] );
	}

	public static function redirect_uri() {
		return admin_url( 'admin-post.php?action=mrsh_drive_cb' );
	}

	private static function tok() {
		return (array) get_option( self::TOK, array() );
	}

	public static function connected() {
		$t = self::tok();
		return ! empty( $t['refresh'] ) && empty( $t['bad'] );
	}

	private static function guard( $n ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( $n );
	}

	private static function back( $msg ) {
		wp_safe_redirect( add_query_arg( 'msg', rawurlencode( $msg ), admin_url( 'admin.php?page=mrsh-fullbackup' ) ) . '#mrsh-drive' );
		exit;
	}

	private static function access_token() {
		$c = get_transient( 'mrsh_drive_at' );
		if ( $c ) {
			return $c;
		}
		$t = self::tok();
		list( $id, $sec ) = self::creds();
		if ( empty( $t['refresh'] ) || ! $id || ! $sec ) {
			self::$tokerr = ( ! $id || ! $sec ) ? 'nocreds' : 'norefresh';
			return false;
		}
		$r = wp_remote_post( 'https://oauth2.googleapis.com/token', array( 'timeout' => 20, 'body' => array( 'client_id' => $id, 'client_secret' => $sec, 'refresh_token' => $t['refresh'], 'grant_type' => 'refresh_token' ) ) );
		if ( is_wp_error( $r ) ) {
			self::$tokerr = 'net: ' . $r->get_error_message();
			return false;
		}
		$j = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( empty( $j['access_token'] ) ) {
			self::$tokerr = (string) ( $j['error'] ?? 'unknown' );
		}
		if ( ! empty( $j['access_token'] ) ) {
			set_transient( 'mrsh_drive_at', $j['access_token'], max( 60, (int) ( $j['expires_in'] ?? 3600 ) - 120 ) );
			if ( ! empty( $t['bad'] ) ) {
				unset( $t['bad'] );
				update_option( self::TOK, $t, false );
			}
			return $j['access_token'];
		}
		if ( 'invalid_grant' === ( $j['error'] ?? '' ) ) {
			$t['bad'] = 1; // the owner must connect again
			update_option( self::TOK, $t, false );
			self::log( '', 0, false, 'Google no longer accepts the saved connection. Press Connect again.' );
		}
		return false;
	}

	/** One Drive API call. Returns array( status code, decoded body, response ). */
	private static function api( $method, $url, $args = array() ) {
		$at = self::access_token();
		if ( ! $at ) {
			return array( 0, array( 'error' => 'Not connected to Google Drive.' ), null );
		}
		$args['method']  = $method;
		$args['timeout'] = $args['timeout'] ?? 30;
		$args['headers'] = array_merge( array( 'Authorization' => 'Bearer ' . $at ), (array) ( $args['headers'] ?? array() ) );
		$r = wp_remote_request( $url, $args );
		if ( is_wp_error( $r ) ) {
			return array( 0, array( 'error' => $r->get_error_message() ), null );
		}
		$code = (int) wp_remote_retrieve_response_code( $r );
		if ( 401 === $code ) {
			delete_transient( 'mrsh_drive_at' );
		}
		return array( $code, json_decode( wp_remote_retrieve_body( $r ), true ), $r );
	}

	/* ---------------------------------------------------------------- connect / disconnect / settings */
	public static function save() {
		self::guard( 'mrsh_drive_save' );
		$o = self::o();
		$o['use_login'] = ! empty( $_POST['use_login'] ) ? 1 : 0;
		$id  = isset( $_POST['client_id'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['client_id'] ) ) ) : '';
		$sec = isset( $_POST['client_secret'] ) ? trim( (string) wp_unslash( $_POST['client_secret'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$sec = preg_replace( '/[^A-Za-z0-9_\-\.]/', '', $sec );
		if ( '' !== $id ) {
			$o['client_id'] = $id;
		}
		if ( '' !== $sec ) {
			$o['client_secret'] = $sec;
		}
		$f = isset( $_POST['folder'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['folder'] ) ) ) : '';
		$o['folder'] = '' !== $f ? mb_substr( $f, 0, 80 ) : 'MyRishta backups';
		$o['keep']   = max( 1, min( 60, (int) ( $_POST['keep'] ?? 7 ) ) );
		$w = isset( $_POST['when'] ) ? sanitize_key( wp_unslash( $_POST['when'] ) ) : 'auto';
		$o['when'] = in_array( $w, array( 'auto', 'all', 'off' ), true ) ? $w : 'auto';
		update_option( self::OPT, $o, false );
		delete_option( self::FID );
		self::back( 'Google Drive settings saved.' );
	}

	public static function connect() {
		self::guard( 'mrsh_drive_connect' );
		list( $id, $sec ) = self::creds();
		if ( ! $id || ! $sec ) {
			self::back( 'Enter the Google Client ID and secret first (or save them under Website keys).' );
		}
		$state = wp_generate_password( 24, false, false );
		set_transient( 'mrsh_drive_state_' . get_current_user_id(), $state, 15 * MINUTE_IN_SECONDS );
		$u = add_query_arg( array(
			'client_id'     => $id,
			'redirect_uri'  => self::redirect_uri(),
			'response_type' => 'code',
			'scope'         => 'openid email https://www.googleapis.com/auth/drive.file',
			'access_type'   => 'offline',
			'prompt'        => 'consent',
			'state'         => $state,
		), 'https://accounts.google.com/o/oauth2/v2/auth' );
		wp_redirect( $u ); // phpcs:ignore WordPress.Security.SafeRedirect
		exit;
	}

	public static function cb() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		$st = isset( $_GET['state'] ) ? sanitize_text_field( wp_unslash( $_GET['state'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$ok = get_transient( 'mrsh_drive_state_' . get_current_user_id() );
		delete_transient( 'mrsh_drive_state_' . get_current_user_id() );
		if ( ! $ok || ! hash_equals( (string) $ok, $st ) ) {
			self::back( 'The Google connection could not be checked (state mismatch). Please press Connect again.' );
		}
		if ( ! empty( $_GET['error'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			self::back( 'Google said: ' . sanitize_text_field( wp_unslash( $_GET['error'] ) ) );
		}
		$code = isset( $_GET['code'] ) ? sanitize_text_field( wp_unslash( $_GET['code'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		list( $id, $sec ) = self::creds();
		$r = wp_remote_post( 'https://oauth2.googleapis.com/token', array( 'timeout' => 20, 'body' => array( 'code' => $code, 'client_id' => $id, 'client_secret' => $sec, 'redirect_uri' => self::redirect_uri(), 'grant_type' => 'authorization_code' ) ) );
		if ( is_wp_error( $r ) ) {
			self::back( 'Could not reach Google. Try again.' );
		}
		$j = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( empty( $j['refresh_token'] ) ) {
			self::back( 'Google did not give a long-lasting permission. Remove the app at myaccount.google.com/permissions and connect again. ' . ( $j['error_description'] ?? '' ) );
		}
		$email = '';
		if ( ! empty( $j['access_token'] ) ) {
			$ui = wp_remote_get( 'https://openidconnect.googleapis.com/v1/userinfo', array( 'timeout' => 15, 'headers' => array( 'Authorization' => 'Bearer ' . $j['access_token'] ) ) );
			if ( ! is_wp_error( $ui ) ) {
				$u = json_decode( wp_remote_retrieve_body( $ui ), true );
				$email = (string) ( $u['email'] ?? '' );
			}
			set_transient( 'mrsh_drive_at', $j['access_token'], max( 60, (int) ( $j['expires_in'] ?? 3600 ) - 120 ) );
		}
		update_option( self::TOK, array( 'refresh' => $j['refresh_token'], 'email' => $email, 'at' => time() ), false );
		delete_option( self::FID );
		self::back( 'Connected to Google Drive' . ( $email ? ' as ' . $email : '' ) . '.' );
	}

	public static function disconnect() {
		self::guard( 'mrsh_drive_disconnect' );
		$t = self::tok();
		if ( ! empty( $t['refresh'] ) ) {
			wp_remote_post( 'https://oauth2.googleapis.com/revoke', array( 'timeout' => 10, 'body' => array( 'token' => $t['refresh'] ) ) );
		}
		delete_option( self::TOK );
		delete_option( self::JOB );
		delete_option( self::FID );
		delete_transient( 'mrsh_drive_at' );
		self::back( 'Disconnected from Google Drive. Backups already in Drive were left there.' );
	}

	/* ---------------------------------------------------------------- queue and upload */
	public static function on_backup( $path, $auto ) {
		$w = self::o( 'when' );
		if ( ! self::connected() || 'off' === $w || ( 'auto' === $w && ! $auto ) ) {
			return;
		}
		self::queue( $path );
	}

	public static function queue( $path ) {
		if ( ! is_file( $path ) || ! filesize( $path ) ) {
			return false;
		}
		update_option( self::JOB, array( 'file' => $path, 'name' => basename( $path ), 'size' => (int) filesize( $path ), 'session' => '', 'offset' => 0, 'tries' => 0, 'start' => time() ), false );
		if ( ! wp_next_scheduled( 'mrsh_drive_cron' ) ) {
			wp_schedule_single_event( time() + 5, 'mrsh_drive_cron' );
		}
		return true;
	}

	public static function cron() {
		$r = self::step( time() + 45 );
		if ( empty( $r['done'] ) && empty( $r['fail'] ) && get_option( self::JOB ) ) {
			wp_schedule_single_event( time() + 20, 'mrsh_drive_cron' );
		}
	}

	private static function log( $name, $size, $ok, $msg ) {
		$l   = (array) get_option( self::LOG, array() );
		$l[] = array( time(), $name, (int) $size, (bool) $ok, $msg );
		update_option( self::LOG, array_slice( $l, -20 ), false );
	}

	private static $why = array();
	private static $tokerr = '';

	private static function folder_id() {
		$f = get_option( self::FID );
		$n = (string) self::o( 'folder' );
		if ( is_array( $f ) && ( $f['n'] ?? '' ) === $n && ! empty( $f['id'] ) ) {
			list( $c, $j ) = self::api( 'GET', 'https://www.googleapis.com/drive/v3/files/' . rawurlencode( $f['id'] ) . '?fields=id,trashed' );
			if ( 200 === $c && empty( $j['trashed'] ) ) {
				return $f['id'];
			}
		}
		$q = "name='" . str_replace( array( '\\', "'" ), array( '\\\\', "\\'" ), $n ) . "' and mimeType='application/vnd.google-apps.folder' and trashed=false";
		list( $c, $j ) = self::api( 'GET', add_query_arg( array( 'q' => $q, 'fields' => 'files(id)', 'pageSize' => 1 ), 'https://www.googleapis.com/drive/v3/files' ) );
		$id = ( 200 === $c && ! empty( $j['files'][0]['id'] ) ) ? $j['files'][0]['id'] : '';
		self::$why = array( $c, $j );
		if ( ! $id ) {
			list( $c, $j ) = self::api( 'POST', 'https://www.googleapis.com/drive/v3/files?fields=id', array( 'headers' => array( 'Content-Type' => 'application/json; charset=UTF-8' ), 'body' => wp_json_encode( array( 'name' => $n, 'mimeType' => 'application/vnd.google-apps.folder' ) ) ) );
			$id = ( 200 === $c && ! empty( $j['id'] ) ) ? $j['id'] : '';
			self::$why = array( $c, $j );
		}
		if ( $id ) {
			update_option( self::FID, array( 'n' => $n, 'id' => $id ), false );
		}
		return $id;
	}

	/** Send pieces until the time budget ends. Returns array( done, pct, msg ). */
	public static function step( $deadline ) {
		$j = get_option( self::JOB );
		if ( ! is_array( $j ) ) {
			return array( 'done' => true, 'pct' => 100, 'msg' => 'Nothing to send.' );
		}
		$fail = function ( $m ) use ( $j ) {
			self::log( $j['name'], $j['size'], false, $m );
			delete_option( self::JOB );
			return array( 'fail' => true, 'pct' => 0, 'msg' => $m );
		};
		if ( ! is_file( $j['file'] ) ) {
			return $fail( 'The backup file is gone.' );
		}
		if ( ! self::connected() ) {
			return $fail( 'Not connected to Google Drive.' );
		}
		if ( empty( $j['session'] ) ) {
			$fid = self::folder_id();
			if ( ! $fid ) {
				return $fail( 'Could not open the Drive folder. Check the Drive API is enabled for your Google project.' );
			}
			$r = self::api( 'POST', 'https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable', array(
				'headers' => array( 'Content-Type' => 'application/json; charset=UTF-8', 'X-Upload-Content-Type' => 'application/zip', 'X-Upload-Content-Length' => (string) $j['size'] ),
				'body'    => wp_json_encode( array( 'name' => $j['name'], 'parents' => array( $fid ) ) ),
			) );
			$loc = $r[2] ? wp_remote_retrieve_header( $r[2], 'location' ) : '';
			if ( 200 !== $r[0] || ! $loc ) {
				$j['tries']++;
				update_option( self::JOB, $j, false );
				if ( $j['tries'] > 6 ) {
					return $fail( 'Google would not start the upload: ' . ( $r[1]['error']['message'] ?? $r[1]['error'] ?? 'error ' . $r[0] ) );
				}
				return array( 'pct' => 0, 'msg' => 'Waiting to retry the start of the upload...' );
			}
			$j['session'] = $loc;
			$j['offset']  = 0;
			update_option( self::JOB, $j, false );
		}
		$fh = fopen( $j['file'], 'rb' );
		if ( ! $fh ) {
			return $fail( 'The backup file could not be read.' );
		}
		// After an error, ask Google how much it already has.
		if ( $j['tries'] > 0 ) {
			$s = wp_remote_request( $j['session'], array( 'method' => 'PUT', 'timeout' => 30, 'headers' => array( 'Content-Length' => '0', 'Content-Range' => 'bytes */' . $j['size'] ), 'body' => '' ) );
			if ( ! is_wp_error( $s ) ) {
				$sc = (int) wp_remote_retrieve_response_code( $s );
				if ( 308 === $sc ) {
					$rg = wp_remote_retrieve_header( $s, 'range' );
					$j['offset'] = ( $rg && preg_match( '/-(\d+)$/', $rg, $m ) ) ? (int) $m[1] + 1 : 0;
				} elseif ( 404 === $sc || 410 === $sc ) {
					$j['session'] = '';
					$j['offset']  = 0;
					update_option( self::JOB, $j, false );
					fclose( $fh );
					return array( 'pct' => 0, 'msg' => 'The upload session expired. Starting again...' );
				}
			}
		}
		while ( time() < $deadline && $j['offset'] < $j['size'] ) {
			$len = min( self::CH, $j['size'] - $j['offset'] );
			fseek( $fh, $j['offset'] );
			$data = fread( $fh, $len ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			$end  = $j['offset'] + strlen( $data ) - 1;
			$r    = wp_remote_request( $j['session'], array( 'method' => 'PUT', 'timeout' => 120, 'headers' => array( 'Content-Range' => 'bytes ' . $j['offset'] . '-' . $end . '/' . $j['size'] ), 'body' => $data ) );
			unset( $data );
			if ( is_wp_error( $r ) ) {
				$j['tries']++;
				break;
			}
			$c = (int) wp_remote_retrieve_response_code( $r );
			if ( 200 === $c || 201 === $c ) {
				fclose( $fh );
				$b = json_decode( wp_remote_retrieve_body( $r ), true );
				self::log( $j['name'], $j['size'], true, 'Uploaded to Google Drive.' );
				delete_option( self::JOB );
				self::keep_newest();
				delete_transient( 'mrsh_drive_list' );
				return array( 'done' => true, 'pct' => 100, 'msg' => 'Uploaded ' . $j['name'] . ' to Google Drive.', 'id' => $b['id'] ?? '' );
			}
			if ( 308 === $c ) {
				$rg = wp_remote_retrieve_header( $r, 'range' );
				$j['offset'] = ( $rg && preg_match( '/-(\d+)$/', $rg, $m ) ) ? (int) $m[1] + 1 : $j['offset'];
				$j['tries']  = 0;
				update_option( self::JOB, $j, false );
				continue;
			}
			if ( 401 === $c ) {
				delete_transient( 'mrsh_drive_at' );
			}
			$j['tries']++;
			if ( 403 === $c || 400 === $c ) {
				$msg = json_decode( wp_remote_retrieve_body( $r ), true );
				fclose( $fh );
				return $fail( 'Google refused the upload: ' . ( $msg['error']['message'] ?? 'error ' . $c ) );
			}
			break;
		}
		fclose( $fh );
		if ( $j['tries'] > 8 ) {
			return $fail( 'The upload kept failing. Check the connection and your Drive space, then send it again.' );
		}
		update_option( self::JOB, $j, false );
		$pct = $j['size'] ? (int) floor( $j['offset'] / $j['size'] * 100 ) : 0;
		return array( 'pct' => min( 99, $pct ), 'msg' => 'Sending to Google Drive: ' . $pct . '%' . ( $j['tries'] ? ' (retrying)' : '' ) );
	}

	/** Keep only the newest N backup files in the Drive folder. */
	private static function keep_newest() {
		$fid = self::folder_id();
		if ( ! $fid ) {
			return;
		}
		list( $c, $j ) = self::api( 'GET', add_query_arg( array( 'q' => "'" . $fid . "' in parents and trashed=false", 'orderBy' => 'createdTime desc', 'fields' => 'files(id,name)', 'pageSize' => 200 ), 'https://www.googleapis.com/drive/v3/files' ) );
		if ( 200 !== $c || empty( $j['files'] ) ) {
			return;
		}
		$keep = max( 1, (int) self::o( 'keep' ) );
		foreach ( array_slice( $j['files'], $keep ) as $f ) {
			if ( 0 === strpos( (string) $f['name'], 'mrsh-backup-' ) ) {
				self::api( 'DELETE', 'https://www.googleapis.com/drive/v3/files/' . rawurlencode( $f['id'] ) );
			}
		}
	}

	private static function drive_list() {
		$c = get_transient( 'mrsh_drive_list' );
		if ( is_array( $c ) ) {
			return $c;
		}
		$fid = self::folder_id();
		$out = array();
		if ( $fid ) {
			list( $code, $j ) = self::api( 'GET', add_query_arg( array( 'q' => "'" . $fid . "' in parents and trashed=false", 'orderBy' => 'createdTime desc', 'fields' => 'files(id,name,size,createdTime)', 'pageSize' => 50 ), 'https://www.googleapis.com/drive/v3/files' ) );
			if ( 200 === $code ) {
				$out = (array) ( $j['files'] ?? array() );
			}
		}
		$res = array( 'fid' => $fid, 'files' => $out );
		set_transient( 'mrsh_drive_list', $res, 2 * MINUTE_IN_SECONDS );
		return $res;
	}

	/* ---------------------------------------------------------------- manual send, ajax */
	public static function send() {
		self::guard( 'mrsh_drive_send' );
		if ( ! self::connected() ) {
			self::back( 'Connect Google Drive first.' );
		}
		$all  = class_exists( 'MRSH_FullBackup' ) ? MRSH_FullBackup::backups() : array();
		$name = isset( $_POST['file'] ) ? basename( sanitize_text_field( wp_unslash( $_POST['file'] ) ) ) : '';
		if ( '' === $name && $all ) {
			$name = (string) key( $all ); // newest first
		}
		if ( ! $name || ! isset( $all[ $name ] ) ) {
			self::back( 'No backup was found to send. Make a backup first.' );
		}
		self::queue( MRSH_FullBackup::dir() . '/' . $name );
		self::back( 'Sending ' . $name . ' to Google Drive. Keep this page open to watch the progress.' );
	}

	public static function ajax_step() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'msg' => 'Not allowed.' ), 403 );
		}
		check_ajax_referer( 'mrsh_drive_ajax', 'n' );
		wp_send_json_success( self::step( time() + 40 ) );
	}

	public static function ajax_test() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'msg' => 'Not allowed.' ), 403 );
		}
		check_ajax_referer( 'mrsh_drive_ajax', 'n' );
		if ( ! self::connected() ) {
			wp_send_json_success( array( 'ok' => false, 'msg' => 'Not connected yet.' ) );
		}
		$fid = self::folder_id();
		if ( ! $fid ) {
			$c   = (int) ( self::$why[0] ?? 0 );
			$e   = self::$why[1]['error'] ?? array();
			$gm  = is_array( $e ) ? (string) ( $e['message'] ?? '' ) : (string) $e;
			$rs  = is_array( $e ) && ! empty( $e['errors'][0]['reason'] ) ? (string) $e['errors'][0]['reason'] : '';
			$tip = 'Google accepted the sign-in but the Drive folder could not be opened.';
			if ( self::$tokerr ) {
				$te = self::$tokerr;
				if ( 'nocreds' === $te ) {
					$tip = 'The Google Client ID or Client secret is empty. Fill them in Website keys (Google login), or untick the box and type them here, then Disconnect and connect again.';
				} elseif ( 'norefresh' === $te ) {
					$tip = 'Google did not give a long-lived permission. Press Disconnect, then Connect again.';
				} elseif ( 'invalid_client' === $te ) {
					$tip = 'Google says the Client ID or Client secret is wrong (invalid_client). Copy them again from Google Cloud, Credentials, into Website keys, then Disconnect and connect again.';
				} elseif ( 'invalid_grant' === $te ) {
					$tip = 'Google no longer accepts the saved connection (invalid_grant). Press Disconnect, then Connect again.';
				} else {
					$tip = 'Could not get a Drive access token from Google (' . mb_substr( $te, 0, 120 ) . '). Press Disconnect and connect again.';
				}
				wp_send_json_success( array( 'ok' => false, 'msg' => $tip ) );
			}
			if ( 'accessNotConfigured' === $rs || false !== stripos( $gm, 'has not been used' ) || false !== stripos( $gm, 'disabled' ) ) {
				$tip .= ' The Google Drive API is off in the Google project that owns your Client ID. Turn it on there (APIs & Services, Library, Google Drive API, Enable), wait a minute and test again.';
			} elseif ( 'insufficientPermissions' === $rs || 403 === $c || 401 === $c ) {
				$tip .= ' Google did not give Drive permission. Press Disconnect, then connect again and tick the Drive permission box on the Google screen.';
			} else {
				$tip .= ' Check that the Google Drive API is on in the same Google project as your Client ID.';
			}
			wp_send_json_success( array( 'ok' => false, 'msg' => $tip . ( $c ? ' (Google said ' . $c . ( $gm ? ': ' . mb_substr( $gm, 0, 160 ) : '' ) . ')' : '' ) ) );
		}
		list( $c, $j ) = self::api( 'GET', 'https://www.googleapis.com/drive/v3/about?fields=storageQuota' );
		$q = $j['storageQuota'] ?? array();
		$free = ( ! empty( $q['limit'] ) && isset( $q['usage'] ) ) ? size_format( max( 0, (float) $q['limit'] - (float) $q['usage'] ) ) . ' free' : '';
		wp_send_json_success( array( 'ok' => true, 'msg' => 'Connected. The Drive folder is ready.' . ( $free ? ' ' . $free . ' in this Google account.' : '' ) ) );
	}

	/* ---------------------------------------------------------------- the panel on the Full backup page */
	public static function panel() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		try {
			self::render();
		} catch ( \Throwable $e ) {
			if ( class_exists( 'MRSH_Safe' ) ) {
				MRSH_Safe::log_ex( $e, 'MRSH_Drive::panel' );
			}
		}
	}

	private static function render() {
		$o   = self::o();
		$t   = self::tok();
		$on  = self::connected();
		$bad = ! empty( $t['bad'] );
		$job = get_option( self::JOB );
		$ap  = esc_url( admin_url( 'admin-post.php' ) );
		list( $id, $sec ) = self::creds();
		$hasown = '' !== (string) $o['client_id'] && '' !== (string) $o['client_secret'];
		echo '<style>#mrsh-drive{max-width:1040px;margin:18px 0}#mrsh-drive *{box-sizing:border-box}.dv-hero{display:flex;flex-wrap:wrap;gap:14px;align-items:center;background:linear-gradient(135deg,#1a73e8,#34a853);color:#fff;border-radius:16px;padding:18px 22px}.dv-hero h2{margin:0;color:#fff;font-size:20px;padding:0;border:0}.dv-hero p{margin:4px 0 0;opacity:.92}.dv-hero .l{flex:1 1 320px}.dv-pill{display:inline-block;background:rgba(255,255,255,.2);border:1px solid rgba(255,255,255,.45);border-radius:99px;padding:5px 14px;font-weight:600}.dv-c{background:#fff;border:1px solid #e4e7f1;border-radius:16px;padding:18px 20px;margin:14px 0;box-shadow:0 1px 2px rgba(17,24,39,.04)}.dv-c h3{margin:0 0 4px;font-size:15px}.dv-c .d{margin:0 0 12px;color:#646970}.dv-f{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px}.dv-f label{display:flex;flex-direction:column;gap:4px;font-weight:600;font-size:13px}.dv-f input,.dv-f select{border-radius:10px;padding:8px 10px;font-weight:400}.dv-b{display:flex;flex-wrap:wrap;gap:8px;margin:12px 0 0;align-items:center}.dv-bar{height:12px;border-radius:99px;background:#e8eaf0;overflow:hidden;margin:8px 0}.dv-bar i{display:block;height:100%;background:linear-gradient(90deg,#1a73e8,#34a853);width:0;transition:width .4s}.dv-cp{display:flex;gap:8px;align-items:center;background:#fafbfd;border:1px solid #eceef6;border-radius:10px;padding:8px 10px;margin:0 0 8px}.dv-cp code{flex:1;min-width:0;overflow-wrap:anywhere;background:none;padding:0}.dv-tb{width:100%;border-collapse:collapse}.dv-tb td,.dv-tb th{text-align:left;padding:7px 8px;border-top:1px solid #f0f0f1;font-size:13px}.dv-ok{color:#0b5a3f}.dv-no{color:#b42318}</style>';
		echo '<div id="mrsh-drive"><div class="dv-hero"><div class="l"><h2>Automatic backup to Google Drive</h2><p>Every full backup is copied to your Google Drive by itself, in small pieces so even very large backups arrive safely.</p></div><span class="dv-pill">' . ( $bad ? 'Reconnect needed' : ( $on ? 'Connected' . ( ! empty( $t['email'] ) ? ': ' . esc_html( $t['email'] ) : '' ) : 'Not connected' ) ) . '</span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		if ( is_array( $job ) ) {
			$pct = $job['size'] ? (int) floor( $job['offset'] / $job['size'] * 100 ) : 0;
			echo '<div class="dv-c"><h3>Sending now: ' . esc_html( $job['name'] ) . '</h3><div class="dv-bar"><i id="dv-bar" style="width:' . (int) $pct . '%"></i></div><p id="dv-msg" class="d" style="margin:0">Sending to Google Drive: ' . (int) $pct . '%. Keep this page open to speed it up; it also continues by itself.</p></div>';
		}

		// Connect.
		echo '<div class="dv-c"><h3>1. Connect your Google account</h3>';
		if ( ! $on || $bad ) {
			echo '<p class="d">One-time setup in Google Cloud (about 5 minutes). You can use the same Google project as your Google login.</p><ol style="margin:0 0 12px 18px"><li>Open <b>console.cloud.google.com</b> &gt; your project &gt; <b>APIs &amp; Services &gt; Library</b> &gt; turn on <b>Google Drive API</b>.</li><li>Open <b>OAuth consent screen</b> (Google Auth Platform) and set the status to <b>In production</b>. In "Testing" Google stops the connection after 7 days.</li><li>Open <b>Credentials</b> &gt; your OAuth client &gt; add this under <b>Authorised redirect URIs</b>, then save:</li></ol><div class="dv-cp"><code id="dv-uri">' . esc_html( self::redirect_uri() ) . '</code><button type="button" class="button" id="dv-copy">Copy</button></div>';
		}
		echo '<form method="post" action="' . $ap . '" class="dv-f" style="margin-top:6px"><input type="hidden" name="action" value="mrsh_drive_save">';
		wp_nonce_field( 'mrsh_drive_save' );
		echo '<label style="grid-column:1/-1;flex-direction:row;align-items:center;gap:8px;font-weight:600"><input type="checkbox" name="use_login" value="1"' . checked( ! empty( $o['use_login'] ), true, false ) . '> Use the Google login Client ID and secret from Website keys</label>';
		echo '<label>Client ID (only if not using the box above)<input type="text" name="client_id" autocomplete="off" placeholder="' . esc_attr( $hasown ? 'saved' : 'not set' ) . '"></label><label>Client secret<input type="password" name="client_secret" autocomplete="off" placeholder="' . esc_attr( $hasown ? 'saved' : 'not set' ) . '"></label>';
		echo '<label>Drive folder name<input type="text" name="folder" value="' . esc_attr( $o['folder'] ) . '"></label><label>Keep the newest copies in Drive<input type="number" name="keep" min="1" max="60" value="' . (int) $o['keep'] . '"></label>';
		echo '<label>Send to Drive<select name="when"><option value="auto"' . selected( $o['when'], 'auto', false ) . '>Every automatic backup</option><option value="all"' . selected( $o['when'], 'all', false ) . '>Every backup (automatic and manual)</option><option value="off"' . selected( $o['when'], 'off', false ) . '>Only when I press Send</option></select></label>';
		echo '<div class="dv-b" style="grid-column:1/-1"><button class="button button-primary">Save Drive settings</button></div></form>';
		echo '<div class="dv-b">';
		if ( ! $on || $bad ) {
			echo '<form method="post" action="' . $ap . '">';
			wp_nonce_field( 'mrsh_drive_connect' );
			echo '<input type="hidden" name="action" value="mrsh_drive_connect"><button class="button button-primary button-large"' . ( ( $id && $sec ) ? '' : ' disabled title="Save the Client ID and secret first"' ) . '>' . ( $bad ? 'Connect again' : 'Connect Google Drive' ) . '</button></form>';
		} else {
			echo '<button type="button" class="button" id="dv-test">Test connection</button><span id="dv-test-r"></span><form method="post" action="' . $ap . '" onsubmit="return confirm(\'Disconnect Google Drive? Backups already in Drive stay there.\')">';
			wp_nonce_field( 'mrsh_drive_disconnect' );
			echo '<input type="hidden" name="action" value="mrsh_drive_disconnect"><button class="button">Disconnect</button></form>';
		}
		echo '</div></div>';

		if ( $on ) {
			$list = class_exists( 'MRSH_FullBackup' ) ? MRSH_FullBackup::backups() : array();
			echo '<div class="dv-c"><h3>2. Send a backup now</h3><p class="d">Backups on this site that you can copy to Drive.</p>';
			if ( ! $list ) {
				echo '<p>No backup on this site yet. Make one above, and it is sent to Drive automatically.</p>';
			} else {
				echo '<table class="dv-tb"><tr><th>Backup</th><th>Made</th><th></th></tr>';
				foreach ( array_slice( $list, 0, 6, true ) as $n => $r ) {
					echo '<tr><td>' . esc_html( $n ) . '</td><td>' . esc_html( wp_date( 'j M Y, g:i a', (int) $r['t'] ) ) . '</td><td><form method="post" action="' . $ap . '" style="margin:0">'; // phpcs:ignore
					wp_nonce_field( 'mrsh_drive_send' );
					echo '<input type="hidden" name="action" value="mrsh_drive_send"><input type="hidden" name="file" value="' . esc_attr( $n ) . '"><button class="button">Send to Drive</button></form></td></tr>';
				}
				echo '</table>';
			}
			$dl = self::drive_list();
			echo '</div><div class="dv-c"><h3>3. What is in your Drive folder</h3>';
			if ( empty( $dl['fid'] ) ) {
				echo '<p class="d">The folder will be created at the first upload.</p>';
			} else {
				echo '<p class="d"><a href="' . esc_url( 'https://drive.google.com/drive/folders/' . rawurlencode( $dl['fid'] ) ) . '" target="_blank" rel="noopener">Open the folder in Google Drive</a>. To restore from Drive: download the file, then use "Upload a backup to restore" above.</p>';
				if ( ! $dl['files'] ) {
					echo '<p>The folder is empty.</p>';
				} else {
					echo '<table class="dv-tb"><tr><th>File</th><th>Size</th><th>Uploaded</th></tr>';
					foreach ( $dl['files'] as $f ) {
						echo '<tr><td>' . esc_html( $f['name'] ) . '</td><td>' . esc_html( size_format( (float) ( $f['size'] ?? 0 ) ) ) . '</td><td>' . esc_html( wp_date( 'j M Y, g:i a', strtotime( (string) $f['createdTime'] ) ) ) . '</td></tr>';
					}
					echo '</table>';
				}
			}
			echo '</div>';
		}

		$log = array_reverse( (array) get_option( self::LOG, array() ) );
		if ( $log ) {
			echo '<div class="dv-c"><h3>Upload history</h3><table class="dv-tb"><tr><th>When</th><th>File</th><th>Result</th></tr>';
			foreach ( array_slice( $log, 0, 8 ) as $l ) {
				echo '<tr><td>' . esc_html( wp_date( 'j M, g:i a', (int) $l[0] ) ) . '</td><td>' . esc_html( $l[1] ? $l[1] . ' (' . size_format( (float) $l[2] ) . ')' : '-' ) . '</td><td class="' . ( $l[3] ? 'dv-ok' : 'dv-no' ) . '">' . esc_html( $l[4] ) . '</td></tr>';
			}
			echo '</table></div>';
		}
		echo '</div>';
		echo '<script>window.MRSH_DV=' . wp_json_encode( array( 'ajax' => admin_url( 'admin-ajax.php' ), 'n' => wp_create_nonce( 'mrsh_drive_ajax' ), 'run' => is_array( $job ) ) ) . ';</script>';
		echo '<script>';
		echo <<<'JS'
(function(){var D=window.MRSH_DV||{};function $(i){return document.getElementById(i)}
var c=$('dv-copy');if(c)c.onclick=function(){var t=$('dv-uri').textContent;var d=function(){c.textContent='Copied';setTimeout(function(){c.textContent='Copy'},1400)};if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t).then(d,d)}else d()};
function post(a,cb){var f=new FormData();f.append('action',a);f.append('n',D.n);fetch(D.ajax,{method:'POST',body:f,credentials:'same-origin'}).then(function(r){return r.json()}).then(cb).catch(function(){cb(null)})}
var t=$('dv-test');if(t)t.onclick=function(){t.disabled=true;post('mrsh_drive_test',function(r){t.disabled=false;var o=$('dv-test-r');var d=r&&r.data;o.className=d&&d.ok?'dv-ok':'dv-no';o.textContent=' '+(d?(d.ok?'✓ ':'✗ ')+d.msg:'The check could not run.')})};
if(D.run){(function loop(){post('mrsh_drive_step',function(r){var d=r&&r.data;if(!d){setTimeout(loop,6000);return}var b=$('dv-bar'),m=$('dv-msg');if(b)b.style.width=(d.pct||0)+'%';if(m)m.textContent=d.msg||'';if(d.done||d.fail){setTimeout(function(){location.reload()},1200)}else setTimeout(loop,1500)})})()}})();
JS;
		echo '</script>';
	}
}

MRSH_Drive::init();
