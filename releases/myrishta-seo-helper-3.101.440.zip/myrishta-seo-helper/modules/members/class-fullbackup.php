<?php
/**
 * Full backup and restore: database + all media (uploads) + theme (+ plugins, optional) in one zip.
 * Works in small steps so big sites do not time out. Daily automatic backup, old backups deleted after N days.
 * Restore brings back database, pictures and theme, and fixes web addresses when the site moved.
 * Files live in wp-content/mrsh-backups-XXXX/ (closed to the web) and are downloaded through the admin page.
 * Options: mrsh_fb (settings), mrsh_fb_dir (folder name), mrsh_fb_lock.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_FullBackup {

	const OPT = 'mrsh_fb';

	public static function opt( $k = null ) {
		$o = array_merge( array( 'auto' => 1, 'days' => 10, 'themes' => 1, 'plugins' => 0 ), (array) get_option( self::OPT, array() ) );
		return null === $k ? $o : $o[ $k ];
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 32 );
		add_action( 'admin_post_mrsh_fb_start', array( __CLASS__, 'start' ) );
		add_action( 'admin_post_mrsh_fb_download', array( __CLASS__, 'download' ) );
		add_action( 'admin_post_mrsh_fb_delete', array( __CLASS__, 'delete' ) );
		add_action( 'admin_post_mrsh_fb_save', array( __CLASS__, 'save' ) );
		add_action( 'wp_ajax_mrsh_fb_step', array( __CLASS__, 'ajax' ) );
		add_action( 'wp_ajax_nopriv_mrsh_fb_step', array( __CLASS__, 'ajax' ) );
		add_action( 'mrsh_fb_daily', array( __CLASS__, 'daily' ) );
		add_action( 'mrsh_fb_cron', array( __CLASS__, 'cron' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ), 41 );
	}

	/* ================= folders and job files ================= */

	public static function dir() {
		// Prefer a folder that already exists: a restore replaces the options table, so the saved name can change mid-job.
		$have = (array) glob( WP_CONTENT_DIR . '/mrsh-backups-*', GLOB_ONLYDIR );
		sort( $have );
		$name = $have ? basename( $have[0] ) : get_option( 'mrsh_fb_dir' );
		if ( ! $name ) {
			$name = 'mrsh-backups-' . substr( wp_generate_password( 20, false, false ), 0, 12 );
			update_option( 'mrsh_fb_dir', $name, false );
		}
		$d = WP_CONTENT_DIR . '/' . $name;
		if ( ! is_dir( $d ) ) {
			wp_mkdir_p( $d );
		}
		if ( is_dir( $d ) && ! file_exists( $d . '/.htaccess' ) ) {
			file_put_contents( $d . '/.htaccess', "Require all denied\nDeny from all\n" ); // phpcs:ignore
			file_put_contents( $d . '/index.html', '' ); // phpcs:ignore
		}
		return $d;
	}

	private static function jobfile( $id ) {
		return self::dir() . '/job-' . preg_replace( '/[^a-z0-9]/', '', $id ) . '.json';
	}

	private static function load( $id ) {
		$f = self::jobfile( $id );
		if ( ! is_readable( $f ) ) {
			return null;
		}
		$j = json_decode( (string) file_get_contents( $f ), true ); // phpcs:ignore
		return is_array( $j ) ? $j : null;
	}

	private static function saved( $j ) {
		file_put_contents( self::jobfile( $j['id'] ), wp_json_encode( $j ), LOCK_EX ); // phpcs:ignore
	}

	private static function budget() {
		$max = (int) ini_get( 'max_execution_time' );
		return microtime( true ) + ( $max > 0 ? max( 4, min( 12, $max - 8 ) ) : 12 );
	}

	/* ================= admin page ================= */

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Full backup and restore', 'Full backup and restore', 'manage_options', 'mrsh-fullbackup', array( __CLASS__, 'page' ) );
	}

	private static function size( $b ) {
		return size_format( (float) $b, 1 );
	}

	public static function backups() {
		$out = array();
		foreach ( (array) glob( self::dir() . '/mrsh-backup-*.zip' ) as $f ) {
			$out[ basename( $f ) ] = array( 't' => filemtime( $f ), 's' => filesize( $f ) );
		}
		uasort( $out, function ( $a, $b ) { return $b['t'] <=> $a['t']; } );
		return $out;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$o    = self::opt();
		$list = self::backups();
		$free = @disk_free_space( WP_CONTENT_DIR ); // phpcs:ignore
		$nonce = wp_create_nonce( 'mrsh_fb' );
		echo '<div class="wrap"><h1>Full backup and restore</h1>';
		if ( ! class_exists( 'ZipArchive' ) ) {
			echo '<div class="notice notice-error"><p>The server has no ZipArchive. Ask your host to turn on the PHP zip extension.</p></div>';
		}
		if ( isset( $_GET['msg'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-info is-dismissible"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['msg'] ) ) ) . '</p></div>'; // phpcs:ignore
		}
		$card = 'background:#fff;border:1px solid #dcdcde;border-radius:14px;padding:6px 18px 16px;margin:14px 0;max-width:980px';
		echo '<p style="max-width:900px">One zip file holds the <b>database</b>, <b>all pictures and media</b>, and your theme. Restore brings everything back, so no photo is lost.</p>';
		echo '<div style="' . $card . '"><h2>Back up now</h2><p>Free space on the server: <b>' . ( $free ? esc_html( self::size( $free ) ) : 'unknown' ) . '</b>. The backups keep growing with your pictures, so also download one now and then to your own computer.</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" id="mrsh-fb-form"><input type="hidden" name="action" value="mrsh_fb_start"><input type="hidden" name="kind" value="backup">' . wp_nonce_field( 'mrsh_fb_start', '_wpnonce', true, false ) . '<button class="button button-primary button-hero">Back up everything now</button></form>';
		echo '<div id="mrsh-fb-prog" hidden style="margin-top:14px"><div style="background:#eee;border-radius:99px;height:18px;overflow:hidden"><div id="mrsh-fb-bar" style="width:0;height:100%;background:linear-gradient(90deg,#e11d74,#7c3aed);transition:width .4s"></div></div><p id="mrsh-fb-msg"><b>Starting...</b></p><p class="description">Keep this page open. It works in small steps and continues until it finishes.</p></div></div>';
		// Settings.
		echo '<div style="' . $card . '"><h2>Automatic backup</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_fb_save">' . wp_nonce_field( 'mrsh_fb_save', '_wpnonce', true, false );
		echo '<p><label><input type="checkbox" name="auto" value="1"' . checked( $o['auto'], 1, false ) . '> Make a full backup every day at about 3 in the morning</label></p>';
		echo '<p><label>Delete backups older than <input type="number" min="1" max="365" name="days" value="' . (int) $o['days'] . '" style="width:70px"> days (the newest backup is always kept)</label></p>';
		echo '<p><label><input type="checkbox" name="themes" value="1"' . checked( $o['themes'], 1, false ) . '> Include the themes</label> &nbsp; <label><input type="checkbox" name="plugins" value="1"' . checked( $o['plugins'], 1, false ) . '> Include the plugins (bigger file)</label></p>';
		echo '<p><button class="button button-primary">Save</button></p><p class="description">The daily backup runs through WordPress scheduled tasks, so it needs some visitors on the site, or a real cron job on your host.</p></form></div>';
		// List.
		echo '<div style="' . $card . '"><h2>Your backups</h2>';
		if ( ! $list ) {
			echo '<p>No backup yet.</p>';
		} else {
			echo '<div style="overflow-x:auto"><table class="widefat striped"><thead><tr><th>Date</th><th>Size</th><th>File</th><th></th></tr></thead><tbody>';
			foreach ( $list as $n => $r ) {
				$dl = wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_fb_download&f=' . rawurlencode( $n ) ), 'mrsh_fb_dl' );
				echo '<tr><td>' . esc_html( wp_date( 'j M Y H:i', $r['t'] ) ) . '</td><td>' . esc_html( self::size( $r['s'] ) ) . '</td><td><code>' . esc_html( $n ) . '</code></td><td style="white-space:nowrap"><a class="button" href="' . esc_url( $dl ) . '">Download</a> ';
				echo '<button type="button" class="button" data-restore="' . esc_attr( $n ) . '">Restore</button> ';
				echo '<form method="post" style="display:inline" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_fb_delete"><input type="hidden" name="f" value="' . esc_attr( $n ) . '">' . wp_nonce_field( 'mrsh_fb_delete', '_wpnonce', true, false ) . '<button class="button">Delete</button></form></td></tr>';
			}
			echo '</tbody></table></div>';
		}
		echo '<p class="description">A backup downloaded from another site, or one uploaded by FTP into this folder, also appears here: <code>wp-content/' . esc_html( (string) get_option( 'mrsh_fb_dir' ) ) . '/</code> (name it <code>mrsh-backup-something.zip</code>).</p>';
		echo '<h3>Upload a backup to restore</h3><form method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_fb_start"><input type="hidden" name="kind" value="upload">' . wp_nonce_field( 'mrsh_fb_start', '_wpnonce', true, false ) . '<input type="file" name="zip" accept=".zip"> <button class="button">Upload</button> <span class="description">Your host may limit uploads to ' . esc_html( size_format( wp_max_upload_size() ) ) . '. For bigger files use FTP.</span></form></div>';
		if ( class_exists( 'MRSH_Drive' ) ) {
			MRSH_Drive::panel();
		}
		// Restore box.
		echo '<div id="mrsh-fb-rbox" hidden style="' . $card . ';border-color:#dc2626"><h2 style="color:#b91c1c">Restore <span id="mrsh-fb-rname"></span></h2><p><b>This replaces your whole database, your pictures and your theme with the backup.</b> Anything newer than the backup is lost, including new members. A safety copy of the current database is made first. You will have to log in again after it finishes, with the username and password from the time of the backup.</p><p><label>Type <b>RESTORE</b> to continue <input type="text" id="mrsh-fb-ok" autocomplete="off" style="width:120px"></label> <button type="button" class="button button-primary" id="mrsh-fb-go" disabled>Start restore</button></p></div>';
		echo '</div>';
		echo '<script>(function(){var N=' . wp_json_encode( $nonce ) . ',A=' . wp_json_encode( admin_url( 'admin-ajax.php' ) ) . ',P=' . wp_json_encode( admin_url( 'admin-post.php' ) ) . ';';
		echo <<<'JS'
function $(i){return document.getElementById(i)}
function run(job,tok){var pr=$('mrsh-fb-prog');pr.hidden=false;pr.scrollIntoView({behavior:'smooth',block:'center'});
 function step(){var f=new FormData();f.append('action','mrsh_fb_step');f.append('job',job);f.append('tok',tok);
  fetch(A,{method:'POST',body:f,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(r){
   if(!r||r.err){$('mrsh-fb-msg').innerHTML='<b style="color:#b91c1c">'+((r&&r.err)||'Stopped')+'</b> You can press the button again; it continues.';return}
   $('mrsh-fb-bar').style.width=Math.max(2,r.pct)+'%';$('mrsh-fb-msg').innerHTML='<b>'+r.msg+'</b>';
   if(r.done){$('mrsh-fb-bar').style.width='100%';if(r.next){location.href=r.next}else{setTimeout(function(){location.href=location.pathname+'?page=mrsh-fullbackup&msg='+encodeURIComponent(r.final||'Finished.')},1200)}}
   else setTimeout(step,300)}).catch(function(){setTimeout(step,3000)})}
 step()}
function begin(kind,file,cb){var f=new FormData();f.append('action','mrsh_fb_start');f.append('kind',kind);f.append('ajax','1');f.append('_wpnonce',cb);if(file)f.append('file',file);
 fetch(P,{method:'POST',body:f,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(r){if(r.err){alert(r.err);return}run(r.job,r.tok)})}
var fm=$('mrsh-fb-form');if(fm)fm.addEventListener('submit',function(e){e.preventDefault();this.querySelector('button').disabled=true;begin('backup','',this.querySelector('[name=_wpnonce]').value)});
var cur='';document.querySelectorAll('[data-restore]').forEach(function(b){b.onclick=function(){cur=b.getAttribute('data-restore');$('mrsh-fb-rname').textContent=cur;$('mrsh-fb-rbox').hidden=false;$('mrsh-fb-rbox').scrollIntoView({behavior:'smooth'})}});
var ok=$('mrsh-fb-ok');if(ok)ok.oninput=function(){$('mrsh-fb-go').disabled=ok.value.trim()!=='RESTORE'};
var go=$('mrsh-fb-go');if(go)go.onclick=function(){go.disabled=true;begin('restore',cur,(fm?fm.querySelector('[name=_wpnonce]').value:''))};
JS;
		echo '})();</script>';
		if ( isset( $_GET['restorefile'] ) ) { // phpcs:ignore
			echo '<script>document.addEventListener("DOMContentLoaded",function(){var b=document.querySelector("[data-restore=\"' . esc_js( sanitize_file_name( wp_unslash( $_GET['restorefile'] ) ) ) . '\"]");if(b)b.click()})</script>'; // phpcs:ignore
		}
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_fb_save' );
		update_option( self::OPT, array(
			'auto'    => empty( $_POST['auto'] ) ? 0 : 1,
			'days'    => max( 1, min( 365, absint( $_POST['days'] ?? 10 ) ) ), // phpcs:ignore
			'themes'  => empty( $_POST['themes'] ) ? 0 : 1,
			'plugins' => empty( $_POST['plugins'] ) ? 0 : 1,
		), false );
		wp_clear_scheduled_hook( 'mrsh_fb_daily' );
		self::schedule();
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-fullbackup&msg=' . rawurlencode( 'Saved.' ) ) );
		exit;
	}

	public static function schedule() {
		if ( self::opt( 'auto' ) && ! wp_next_scheduled( 'mrsh_fb_daily' ) ) {
			try {
				$t = ( new DateTime( 'tomorrow 03:00', wp_timezone() ) )->getTimestamp();
			} catch ( \Exception $e ) {
				$t = time() + DAY_IN_SECONDS;
			}
			wp_schedule_event( $t, 'daily', 'mrsh_fb_daily' );
		}
		if ( ! self::opt( 'auto' ) && wp_next_scheduled( 'mrsh_fb_daily' ) ) {
			wp_clear_scheduled_hook( 'mrsh_fb_daily' );
		}
	}

	public static function download() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_fb_dl' );
		$n = basename( sanitize_file_name( wp_unslash( $_GET['f'] ?? '' ) ) ); // phpcs:ignore
		$f = self::dir() . '/' . $n;
		if ( 0 !== strpos( $n, 'mrsh-backup-' ) || ! is_readable( $f ) ) {
			wp_die( 'File not found.' );
		}
		while ( ob_get_level() ) {
			ob_end_clean();
		}
		nocache_headers();
		header( 'Content-Type: application/zip' );
		header( 'Content-Disposition: attachment; filename="' . $n . '"' );
		header( 'Content-Length: ' . filesize( $f ) );
		readfile( $f ); // phpcs:ignore
		exit;
	}

	public static function delete() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_fb_delete' );
		$n = basename( sanitize_file_name( wp_unslash( $_POST['f'] ?? '' ) ) ); // phpcs:ignore
		$f = self::dir() . '/' . $n;
		if ( 0 === strpos( $n, 'mrsh-backup-' ) && is_file( $f ) ) {
			unlink( $f ); // phpcs:ignore
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-fullbackup&msg=' . rawurlencode( 'Deleted.' ) ) );
		exit;
	}

	/* ================= start a job ================= */

	private static function lock_ok( $id ) {
		$l = get_option( 'mrsh_fb_lock' );
		if ( is_array( $l ) && $l['id'] !== $id && time() - (int) $l['t'] < 600 ) {
			return false;
		}
		update_option( 'mrsh_fb_lock', array( 'id' => $id, 't' => time() ), false );
		return true;
	}

	public static function start() {
		$ajax = ! empty( $_POST['ajax'] ); // phpcs:ignore
		$fail = function ( $m ) use ( $ajax ) {
			if ( $ajax ) {
				wp_send_json( array( 'err' => $m ) );
			}
			wp_safe_redirect( admin_url( 'admin.php?page=mrsh-fullbackup&msg=' . rawurlencode( $m ) ) );
			exit;
		};
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_fb_start' );
		if ( ! class_exists( 'ZipArchive' ) ) {
			$fail( 'The PHP zip extension is missing on this server.' );
		}
		$kind = sanitize_key( $_POST['kind'] ?? 'backup' ); // phpcs:ignore
		if ( 'upload' === $kind ) {
			if ( empty( $_FILES['zip']['tmp_name'] ) || ! is_uploaded_file( $_FILES['zip']['tmp_name'] ) ) { // phpcs:ignore
				$fail( 'Choose a zip file first.' );
			}
			$name = 'mrsh-backup-uploaded-' . gmdate( 'Ymd-His' ) . '.zip';
			if ( ! move_uploaded_file( $_FILES['zip']['tmp_name'], self::dir() . '/' . $name ) ) { // phpcs:ignore
				$fail( 'The file could not be saved.' );
			}
			$z = new ZipArchive();
			if ( true !== $z->open( self::dir() . '/' . $name ) || false === $z->locateName( 'manifest.json' ) ) {
				@unlink( self::dir() . '/' . $name ); // phpcs:ignore
				$fail( 'That is not a My Rishta backup.' );
			}
			$z->close();
			wp_safe_redirect( admin_url( 'admin.php?page=mrsh-fullbackup&restorefile=' . rawurlencode( $name ) ) );
			exit;
		}
		$id = strtolower( wp_generate_password( 12, false, false ) );
		if ( ! self::lock_ok( $id ) ) {
			$fail( 'Another backup or restore is running. Wait a few minutes.' );
		}
		$tok = wp_generate_password( 32, false, false );
		if ( 'restore' === $kind ) {
			$f = basename( sanitize_file_name( wp_unslash( $_POST['file'] ?? '' ) ) ); // phpcs:ignore
			if ( 0 !== strpos( $f, 'mrsh-backup-' ) || ! is_file( self::dir() . '/' . $f ) ) {
				$fail( 'Backup file not found.' );
			}
			$j = self::new_restore( $id, $tok, $f );
			if ( is_string( $j ) ) {
				$fail( $j );
			}
		} else {
			$j = self::new_backup( $id, $tok, false );
		}
		self::saved( $j );
		if ( $ajax ) {
			wp_send_json( array( 'job' => $id, 'tok' => $tok ) );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-fullbackup' ) );
		exit;
	}

	/* ================= ajax driver ================= */

	public static function ajax() {
		$id  = preg_replace( '/[^a-z0-9]/', '', strtolower( (string) ( $_POST['job'] ?? '' ) ) ); // phpcs:ignore
		$tok = (string) ( $_POST['tok'] ?? '' ); // phpcs:ignore
		$j   = $id ? self::load( $id ) : null;
		if ( ! $j || ! hash_equals( (string) $j['tok'], $tok ) ) {
			wp_send_json( array( 'err' => 'This job was not found.' ) );
		}
		@ignore_user_abort( true ); // phpcs:ignore
		@set_time_limit( 60 ); // phpcs:ignore
		wp_send_json( self::run( $j, self::budget() ) );
	}

	public static function cron( $id ) {
		$j = self::load( (string) $id );
		if ( ! $j ) {
			return;
		}
		@set_time_limit( 120 ); // phpcs:ignore
		$r = self::run( $j, microtime( true ) + 25 );
		if ( empty( $r['done'] ) && empty( $r['err'] ) ) {
			wp_schedule_single_event( time() + 15, 'mrsh_fb_cron', array( (string) $id ) );
		}
	}

	public static function daily() {
		if ( ! self::opt( 'auto' ) || ! class_exists( 'ZipArchive' ) ) {
			return;
		}
		self::retention();
		$id = strtolower( wp_generate_password( 12, false, false ) );
		if ( ! self::lock_ok( $id ) ) {
			return;
		}
		$j = self::new_backup( $id, wp_generate_password( 32, false, false ), true );
		self::saved( $j );
		wp_schedule_single_event( time() + 5, 'mrsh_fb_cron', array( $id ) );
	}

	public static function retention() {
		$days = (int) self::opt( 'days' );
		$all  = self::backups();
		$i    = 0;
		foreach ( $all as $n => $r ) {
			++$i;
			if ( $i > 1 && $r['t'] < time() - $days * DAY_IN_SECONDS ) {
				@unlink( self::dir() . '/' . $n ); // phpcs:ignore
			}
		}
		foreach ( (array) glob( self::dir() . '/{tmp-*,job-*,pre-restore-*}', GLOB_BRACE ) as $f ) {
			if ( is_file( $f ) && filemtime( $f ) < time() - max( 2, $days ) * DAY_IN_SECONDS ) {
				@unlink( $f ); // phpcs:ignore
			}
		}
	}

	private static function run( $j, $deadline ) {
		try {
			update_option( 'mrsh_fb_lock', array( 'id' => $j['id'], 't' => time() ), false );
			$r = 'restore' === $j['type'] ? self::restore_step( $j, $deadline ) : self::backup_step( $j, $deadline );
			if ( ! empty( $r['done'] ) ) {
				delete_option( 'mrsh_fb_lock' );
				@unlink( self::jobfile( $j['id'] ) ); // phpcs:ignore
			}
			return $r;
		} catch ( \Throwable $e ) {
			if ( class_exists( 'MRSH_Safe', false ) ) {
				MRSH_Safe::log_ex( $e, 'full backup' );
			}
			return array( 'err' => 'Problem: ' . $e->getMessage() );
		}
	}

	/* ================= backup ================= */

	private static function new_backup( $id, $tok, $auto ) {
		global $wpdb;
		$tables = $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $wpdb->prefix ) . '%' ) );
		$up     = wp_upload_dir();
		$inc    = array();
		$inc['uploads'] = $up['basedir'];
		if ( self::opt( 'themes' ) ) {
			$inc['themes'] = get_theme_root();
		}
		if ( self::opt( 'plugins' ) ) {
			$inc['plugins'] = WP_PLUGIN_DIR;
		}
		$d = self::dir();
		return array(
			'id' => $id, 'tok' => $tok, 'type' => 'backup', 'auto' => $auto, 'stage' => 'db', 'started' => time(),
			'tables' => array_values( $tables ), 'ti' => 0, 'off' => 0, 'last' => null, 'tstart' => false, 'rows' => 0,
			'sql' => $d . '/tmp-' . $id . '.sql', 'zip' => $d . '/tmp-' . $id . '.zip', 'list' => $d . '/tmp-' . $id . '.list',
			'inc' => $inc, 'queue' => array(), 'lo' => 0, 'files' => 0, 'bytes' => 0, 'qi' => null,
		);
	}

	private static function backup_step( $j, $deadline ) {
		if ( 'db' === $j['stage'] ) {
			$r = self::dump_step( $j, $deadline );
			self::saved( $r['job'] );
			unset( $r['job'] );
			return $r;
		}
		if ( 'list' === $j['stage'] ) {
			if ( null === $j['qi'] ) {
				foreach ( $j['inc'] as $label => $base ) {
					$j['queue'][] = array( $label, $base );
				}
				$j['qi'] = 1;
			}
			$h = fopen( $j['list'], 'ab' ); // phpcs:ignore
			while ( $j['queue'] && microtime( true ) < $deadline ) {
				list( $label, $dir ) = array_shift( $j['queue'] );
				$base = $j['inc'][ $label ];
				foreach ( (array) @scandir( $dir ) as $e ) { // phpcs:ignore
					if ( '.' === $e || '..' === $e ) {
						continue;
					}
					$p = $dir . '/' . $e;
					if ( is_link( $p ) ) {
						continue;
					}
					if ( is_dir( $p ) ) {
						if ( in_array( $e, array( 'cache', 'node_modules', '.git' ), true ) || 0 === strpos( $e, 'mrsh-backups' ) ) {
							continue;
						}
						$j['queue'][] = array( $label, $p );
					} elseif ( is_file( $p ) && is_readable( $p ) && '.DS_Store' !== $e && filesize( $p ) < 1500 * MB_IN_BYTES ) {
						if ( 'plugins' === $label && 0 === strpos( substr( $p, strlen( $base ) + 1 ), 'myrishta-seo-helper/' ) ) {
							// keep our own plugin: it is re-installed from your zip, but include it too
						}
						fwrite( $h, $label . '/' . ltrim( substr( $p, strlen( $base ) ), '/' ) . "\n" ); // phpcs:ignore
						++$j['files'];
					}
				}
			}
			fclose( $h ); // phpcs:ignore
			if ( ! $j['queue'] ) {
				$j['stage'] = 'zip';
			}
			self::saved( $j );
			return array( 'pct' => 22, 'msg' => 'Looking at your files... ' . (int) $j['files'] . ' found' );
		}
		if ( 'zip' === $j['stage'] ) {
			$z = new ZipArchive();
			if ( true !== $z->open( $j['zip'], ZipArchive::CREATE ) ) {
				return array( 'err' => 'Could not create the zip file. Check free space.' );
			}
			$h = fopen( $j['list'], 'rb' ); // phpcs:ignore
			fseek( $h, (int) $j['lo'] );
			$n = 0;
			$b = 0;
			$store = array( 'jpg', 'jpeg', 'png', 'webp', 'gif', 'mp4', 'mp3', 'zip', 'gz', 'woff2', 'avif', 'webm', 'ogg', 'pdf' );
			while ( ( $line = fgets( $h ) ) !== false ) { // phpcs:ignore
				$rel = rtrim( $line, "\r\n" );
				$j['lo'] += strlen( $line );
				if ( '' === $rel ) {
					continue;
				}
				$lab = strstr( $rel, '/', true );
				$sub = substr( strstr( $rel, '/' ), 1 );
				$abs = isset( $j['inc'][ $lab ] ) ? $j['inc'][ $lab ] . '/' . $sub : '';
				if ( $abs && is_readable( $abs ) ) {
					$z->addFile( $abs, $rel );
					if ( in_array( strtolower( pathinfo( $rel, PATHINFO_EXTENSION ) ), $store, true ) ) {
						$z->setCompressionName( $rel, ZipArchive::CM_STORE );
					}
					$b += (int) filesize( $abs );
					++$n;
				}
				if ( $n >= 400 || $b > 60 * MB_IN_BYTES || microtime( true ) > $deadline - 6 ) {
					break;
				}
			}
			$eof = feof( $h );
			fclose( $h ); // phpcs:ignore
			$z->close();
			$j['bytes'] += $b;
			if ( $eof ) {
				$j['stage'] = 'finish';
			}
			self::saved( $j );
			$pct = $j['files'] ? 22 + (int) round( 70 * min( 1, $j['lo'] / max( 1, filesize( $j['list'] ) ) ) ) : 92;
			return array( 'pct' => $pct, 'msg' => 'Adding pictures and files... ' . self::size( $j['bytes'] ) . ' so far' );
		}
		// Finish: database, manifest, final name.
		$z = new ZipArchive();
		if ( true !== $z->open( $j['zip'], ZipArchive::CREATE ) ) {
			return array( 'err' => 'Could not finish the zip file.' );
		}
		$z->addFile( $j['sql'], 'db.sql' );
		$z->addFromString( 'manifest.json', wp_json_encode( array(
			'v' => 1, 'plugin' => MRSH_VERSION, 'wp' => get_bloginfo( 'version' ), 'home' => home_url(), 'siteurl' => site_url(), 'prefix' => $GLOBALS['wpdb']->prefix,
			'time' => gmdate( 'c' ), 'has' => array_keys( $j['inc'] ), 'files' => (int) $j['files'], 'auto' => (bool) $j['auto'],
		) ) );
		$z->close();
		$final = self::dir() . '/mrsh-backup-' . gmdate( 'Ymd-His' ) . '-' . ( $j['auto'] ? 'auto-' : '' ) . substr( $j['id'], 0, 6 ) . '.zip';
		rename( $j['zip'], $final ); // phpcs:ignore
		@unlink( $j['sql'] ); // phpcs:ignore
		@unlink( $j['list'] ); // phpcs:ignore
		self::retention();
		update_option( 'mrsh_fb_last', array( 't' => time(), 's' => filesize( $final ), 'auto' => (bool) $j['auto'] ), false );
		do_action( 'mrsh_fb_done', $final, (bool) $j['auto'] );
		return array( 'done' => true, 'pct' => 100, 'msg' => 'Backup finished: ' . self::size( filesize( $final ) ), 'final' => 'Backup finished: ' . basename( $final ) . ' (' . self::size( filesize( $final ) ) . '). Old backups were cleaned up.' );
	}

	/** Write the database as one SQL statement per line. Returns progress and the updated job. */
	private static function dump_step( $j, $deadline, $into = 'db' ) {
		global $wpdb;
		$h = fopen( $j['sql'], 'ab' ); // phpcs:ignore
		if ( 0 === (int) $j['ti'] && 0 === (int) $j['off'] && ! $j['tstart'] && null === $j['last'] ) {
			ftruncate( $h, 0 );
			fwrite( $h, "-- My Rishta backup\n" ); // phpcs:ignore
		}
		$total = max( 1, count( $j['tables'] ) );
		while ( $j['ti'] < count( $j['tables'] ) && microtime( true ) < $deadline ) {
			$t = $j['tables'][ $j['ti'] ];
			if ( ! $j['tstart'] ) {
				$cr = $wpdb->get_row( 'SHOW CREATE TABLE `' . esc_sql( $t ) . '`', ARRAY_N );
				fwrite( $h, 'DROP TABLE IF EXISTS `' . $t . "`;\n" . preg_replace( '/\s*\n\s*/', ' ', (string) ( $cr[1] ?? '' ) ) . ";\n" ); // phpcs:ignore
				$j['tstart'] = true;
				$j['last']   = null;
				$j['off']    = 0;
				$keys        = $wpdb->get_results( 'SHOW KEYS FROM `' . esc_sql( $t ) . "` WHERE Key_name='PRIMARY'", ARRAY_A );
				$j['pk']     = '';
				if ( 1 === count( (array) $keys ) ) {
					$col = $wpdb->get_row( 'SHOW COLUMNS FROM `' . esc_sql( $t ) . '` LIKE \'' . esc_sql( $keys[0]['Column_name'] ) . '\'', ARRAY_A );
					if ( $col && preg_match( '/int/i', $col['Type'] ) ) {
						$j['pk'] = $keys[0]['Column_name'];
					}
				}
			}
			if ( $j['pk'] ) {
				$sql = 'SELECT * FROM `' . esc_sql( $t ) . '` WHERE `' . esc_sql( $j['pk'] ) . '` > ' . (int) ( $j['last'] ?? 0 ) . ' ORDER BY `' . esc_sql( $j['pk'] ) . '` ASC LIMIT 300';
			} else {
				$sql = 'SELECT * FROM `' . esc_sql( $t ) . '` LIMIT ' . (int) $j['off'] . ',300';
			}
			$rows = $wpdb->get_results( $sql, ARRAY_A );
			if ( ! $rows ) {
				++$j['ti'];
				$j['tstart'] = false;
				$j['last']   = null;
				$j['off']    = 0;
				continue;
			}
			$vals = array();
			foreach ( $rows as $r ) {
				$one = array();
				foreach ( $r as $v ) {
					$one[] = null === $v ? 'NULL' : "'" . $wpdb->_real_escape( (string) $v ) . "'";
				}
				$vals[] = '(' . implode( ',', $one ) . ')';
			}
			fwrite( $h, 'INSERT INTO `' . $t . '` VALUES ' . implode( ',', $vals ) . ";\n" ); // phpcs:ignore
			$j['rows'] += count( $rows );
			if ( $j['pk'] ) {
				$j['last'] = (int) end( $rows )[ $j['pk'] ];
			}
			$j['off'] += count( $rows );
			if ( count( $rows ) < 300 ) {
				++$j['ti'];
				$j['tstart'] = false;
				$j['last']   = null;
				$j['off']    = 0;
			}
		}
		fclose( $h ); // phpcs:ignore
		$done = $j['ti'] >= count( $j['tables'] );
		if ( $done ) {
			$j['stage'] = 'db' === $into ? 'list' : 'next';
		}
		return array( 'job' => $j, 'pct' => (int) round( 20 * $j['ti'] / $total ), 'msg' => 'Saving the database... ' . (int) $j['rows'] . ' rows' );
	}

	/* ================= restore ================= */

	private static function new_restore( $id, $tok, $file ) {
		global $wpdb;
		$z = new ZipArchive();
		$p = self::dir() . '/' . $file;
		if ( true !== $z->open( $p ) ) {
			return 'The backup file cannot be opened.';
		}
		$mj = $z->getFromName( 'manifest.json' );
		$m  = $mj ? json_decode( $mj, true ) : null;
		if ( ! is_array( $m ) || false === $z->locateName( 'db.sql' ) ) {
			return 'This backup is incomplete (no manifest or database).';
		}
		if ( ( $m['prefix'] ?? '' ) !== $wpdb->prefix ) {
			return 'The backup uses the database prefix "' . $m['prefix'] . '" but this site uses "' . $wpdb->prefix . '". Set $table_prefix = \'' . $m['prefix'] . '\'; in wp-config.php first, then try again.';
		}
		$names = array();
		for ( $i = 0; $i < $z->numFiles; $i++ ) {
			$n = $z->getNameIndex( $i );
			if ( preg_match( '#^(uploads|themes|plugins)/.+[^/]$#', $n ) && false === strpos( $n, '..' ) ) {
				$names[] = $n;
			}
		}
		$z->close();
		$d    = self::dir();
		$tabs = $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $wpdb->prefix ) . '%' ) );
		return array(
			'id' => $id, 'tok' => $tok, 'type' => 'restore', 'stage' => 'safety', 'file' => $file, 'manifest' => $m,
			'tables' => array_values( $tabs ), 'ti' => 0, 'off' => 0, 'last' => null, 'tstart' => false, 'rows' => 0,
			'sql' => $d . '/pre-restore-' . gmdate( 'Ymd-His' ) . '.sql', 'names' => $names, 'ni' => 0, 'ro' => 0, 'rl' => 0, 'si' => 0,
			'dbfile' => $d . '/tmp-restore-' . $id . '.sql', 'fixed' => 0,
		);
	}

	private static function restore_step( $j, $deadline ) {
		global $wpdb;
		$z = new ZipArchive();
		$p = self::dir() . '/' . $j['file'];
		if ( 'safety' === $j['stage'] ) {
			$r = self::dump_step( $j, $deadline, 'safety' );
			$j = $r['job'];
			if ( 'next' === $j['stage'] ) {
				$j['stage'] = 'files';
			}
			self::saved( $j );
			return array( 'pct' => min( 10, $r['pct'] / 8 ), 'msg' => 'Saving a safety copy of the current database... ' . (int) $j['rows'] . ' rows' );
		}
		if ( 'files' === $j['stage'] ) {
			if ( true !== $z->open( $p ) ) {
				return array( 'err' => 'The backup file cannot be opened.' );
			}
			$up   = wp_upload_dir();
			$base = array( 'uploads' => $up['basedir'], 'themes' => get_theme_root(), 'plugins' => WP_PLUGIN_DIR );
			$n    = 0;
			while ( $j['ni'] < count( $j['names'] ) && microtime( true ) < $deadline - 2 && $n < 500 ) {
				$name = $j['names'][ $j['ni'] ];
				++$j['ni'];
				$lab = strstr( $name, '/', true );
				$sub = substr( strstr( $name, '/' ), 1 );
				if ( 'plugins' === $lab && 0 === strpos( $sub, 'myrishta-seo-helper/' ) ) {
					continue; // never overwrite the running plugin
				}
				$dest = $base[ $lab ] . '/' . $sub;
				wp_mkdir_p( dirname( $dest ) );
				$in = $z->getStream( $name );
				if ( $in ) {
					$out = fopen( $dest, 'wb' ); // phpcs:ignore
					if ( $out ) {
						stream_copy_to_stream( $in, $out );
						fclose( $out ); // phpcs:ignore
					}
					fclose( $in ); // phpcs:ignore
				}
				++$n;
			}
			$z->close();
			if ( $j['ni'] >= count( $j['names'] ) ) {
				$j['stage'] = 'dbprep';
			}
			self::saved( $j );
			return array( 'pct' => 10 + (int) round( 40 * $j['ni'] / max( 1, count( $j['names'] ) ) ), 'msg' => 'Bringing back pictures and files... ' . (int) $j['ni'] . ' of ' . count( $j['names'] ) );
		}
		if ( 'dbprep' === $j['stage'] ) {
			if ( true !== $z->open( $p ) ) {
				return array( 'err' => 'The backup file cannot be opened.' );
			}
			$in  = $z->getStream( 'db.sql' );
			$out = fopen( $j['dbfile'], 'wb' ); // phpcs:ignore
			if ( ! $in || ! $out ) {
				return array( 'err' => 'Could not unpack the database.' );
			}
			stream_copy_to_stream( $in, $out );
			fclose( $in ); // phpcs:ignore
			fclose( $out ); // phpcs:ignore
			$z->close();
			$j['stage'] = 'db';
			self::saved( $j );
			return array( 'pct' => 52, 'msg' => 'Database unpacked. Starting to import...' );
		}
		if ( 'db' === $j['stage'] ) {
			$h = fopen( $j['dbfile'], 'rb' ); // phpcs:ignore
			fseek( $h, (int) $j['ro'] );
			$cnt = 0;
			$wpdb->suppress_errors( true );
			while ( ( $line = fgets( $h ) ) !== false ) { // phpcs:ignore
				$j['ro'] += strlen( $line );
				$line = rtrim( $line, "\r\n" );
				if ( '' === $line || 0 === strpos( $line, '--' ) ) {
					continue;
				}
				$wpdb->query( $line ); // phpcs:ignore
				++$cnt;
				if ( microtime( true ) > $deadline - 2 ) {
					break;
				}
			}
			$eof  = feof( $h );
			$size = max( 1, filesize( $j['dbfile'] ) );
			fclose( $h ); // phpcs:ignore
			if ( $eof ) {
				$j['stage'] = 'urls';
				$j['ur']    = array( 'ti' => 0, 'last' => 0 );
			}
			self::saved( $j );
			return array( 'pct' => 52 + (int) round( 36 * min( 1, $j['ro'] / $size ) ), 'msg' => 'Importing the database... ' . (int) round( 100 * min( 1, $j['ro'] / $size ) ) . '%' );
		}
		if ( 'urls' === $j['stage'] ) {
			$old = array_unique( array_filter( array( untrailingslashit( (string) $j['manifest']['home'] ), untrailingslashit( (string) $j['manifest']['siteurl'] ) ) ) );
			$new = untrailingslashit( home_url() );
			$old = array_values( array_filter( $old, function ( $o ) use ( $new ) { return $o !== $new; } ) );
			$tabs = array( 'options', 'posts', 'postmeta', 'usermeta', 'termmeta', 'comments', 'commentmeta' );
			if ( ! $old ) {
				$j['stage'] = 'finish';
			} else {
				$u = $j['ur'];
				while ( $u['ti'] < count( $tabs ) && microtime( true ) < $deadline - 2 ) {
					$t  = $wpdb->prefix . $tabs[ $u['ti'] ];
					$pk = self::pk( $t );
					if ( ! $pk ) {
						++$u['ti'];
						$u['last'] = 0;
						continue;
					}
					$cols = self::textcols( $t );
					$rows = $wpdb->get_results( 'SELECT `' . esc_sql( $pk ) . '`,' . implode( ',', array_map( function ( $c ) { return '`' . esc_sql( $c ) . '`'; }, $cols ) ) . ' FROM `' . esc_sql( $t ) . '` WHERE `' . esc_sql( $pk ) . '` > ' . (int) $u['last'] . ' ORDER BY `' . esc_sql( $pk ) . '` ASC LIMIT 200', ARRAY_A );
					if ( ! $rows ) {
						++$u['ti'];
						$u['last'] = 0;
						continue;
					}
					foreach ( $rows as $r ) {
						$upd = array();
						foreach ( $cols as $c ) {
							$v = (string) $r[ $c ];
							if ( '' === $v ) {
								continue;
							}
							foreach ( $old as $o ) {
								if ( false !== strpos( $v, $o ) ) {
									$nv = self::swap( $v, $old, $new );
									if ( $nv !== $v ) {
										$upd[ $c ] = $nv;
									}
									break;
								}
							}
						}
						if ( $upd ) {
							$wpdb->update( $t, $upd, array( $pk => $r[ $pk ] ) );
							++$j['fixed'];
						}
						$u['last'] = (int) $r[ $pk ];
					}
				}
				$j['ur'] = $u;
				if ( $u['ti'] >= count( $tabs ) ) {
					$j['stage'] = 'finish';
				}
			}
			self::saved( $j );
			if ( 'finish' !== $j['stage'] ) {
				return array( 'pct' => 92, 'msg' => 'Fixing web addresses... ' . (int) $j['fixed'] . ' changed' );
			}
		}
		// Finish.
		@unlink( $j['dbfile'] ); // phpcs:ignore
		delete_option( 'mrsh_flushed_ver' );
		delete_option( 'mrsh_fb_lock' );
		wp_cache_flush();
		return array( 'done' => true, 'pct' => 100, 'msg' => 'Restore finished.', 'final' => 'Restore finished. Please log in again with the username and password from the time of the backup.', 'next' => wp_login_url() );
	}

	private static function pk( $t ) {
		global $wpdb;
		$k = $wpdb->get_results( 'SHOW KEYS FROM `' . esc_sql( $t ) . "` WHERE Key_name='PRIMARY'", ARRAY_A );
		return 1 === count( (array) $k ) ? $k[0]['Column_name'] : '';
	}

	private static function textcols( $t ) {
		global $wpdb;
		$out = array();
		foreach ( (array) $wpdb->get_results( 'SHOW COLUMNS FROM `' . esc_sql( $t ) . '`', ARRAY_A ) as $c ) {
			if ( preg_match( '/char|text/i', $c['Type'] ) ) {
				$out[] = $c['Field'];
			}
		}
		return $out;
	}

	/** Replace the old address by the new one, also inside serialized data. */
	public static function swap( $v, $old, $new ) {
		if ( is_serialized( $v ) ) {
			$u = @unserialize( $v, array( 'allowed_classes' => false ) ); // phpcs:ignore
			if ( false !== $u || 'b:0;' === $v ) {
				return serialize( self::swap_deep( $u, $old, $new ) ); // phpcs:ignore
			}
		}
		return str_replace( $old, $new, $v );
	}

	private static function swap_deep( $x, $old, $new ) {
		if ( is_string( $x ) ) {
			return self::swap( $x, $old, $new );
		}
		if ( is_array( $x ) ) {
			$o = array();
			foreach ( $x as $k => $v ) {
				$o[ is_string( $k ) ? str_replace( $old, $new, $k ) : $k ] = self::swap_deep( $v, $old, $new );
			}
			return $o;
		}
		return $x;
	}
}
MRSH_FullBackup::init();
