<?php
/**
 * One-click "Connect LinkedIn" for Auto ads. Enter the LinkedIn app's Client ID and Secret once,
 * press Connect, approve on LinkedIn: the access token and your author ID are saved automatically.
 *
 * @package MyRishta_SEO_Helper
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Connect {
	const APP = 'mrsh_li_app';

	public static function init() {
		add_action( 'admin_post_mrsh_li_save', array( __CLASS__, 'save_app' ) );
		add_action( 'admin_post_mrsh_li_go', array( __CLASS__, 'go' ) );
		add_action( 'admin_post_mrsh_li_cb', array( __CLASS__, 'callback' ) );
		add_action( 'admin_post_mrsh_li_off', array( __CLASS__, 'off' ) );
	}

	private static function app() {
		return array_merge( array( 'id' => '', 'secret' => '' ), (array) get_option( self::APP, array() ) );
	}

	public static function redirect_uri() {
		return admin_url( 'admin-post.php?action=mrsh_li_cb' );
	}

	private static function guard( $n ) {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( $n ) ) {
			wp_die( 'Not allowed.' );
		}
	}

	private static function back( $arg ) {
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-autoads&' . $arg ) );
		exit;
	}

	public static function save_app() {
		self::guard( 'mrsh_li_save' );
		$old = self::app();
		$id  = sanitize_text_field( wp_unslash( $_POST['li_id'] ?? '' ) ); // phpcs:ignore
		$sec = trim( sanitize_text_field( wp_unslash( $_POST['li_secret'] ?? '' ) ) ); // phpcs:ignore
		update_option( self::APP, array( 'id' => $id, 'secret' => '' !== $sec ? $sec : $old['secret'] ), false );
		self::back( 'ok=1' );
	}

	public static function go() {
		self::guard( 'mrsh_li_go' );
		$a = self::app();
		if ( ! $a['id'] || ! $a['secret'] ) {
			self::back( 'err=' . rawurlencode( 'Save the LinkedIn Client ID and Client Secret first.' ) );
		}
		$st = wp_generate_password( 24, false );
		set_transient( 'mrsh_list_' . $st, get_current_user_id(), 10 * MINUTE_IN_SECONDS );
		$u = add_query_arg( array( 'response_type' => 'code', 'client_id' => $a['id'], 'redirect_uri' => self::redirect_uri(), 'state' => $st, 'scope' => 'openid profile w_member_social' ), 'https://www.linkedin.com/oauth/v2/authorization' );
		wp_redirect( $u ); // phpcs:ignore WordPress.Security.SafeRedirect -- fixed LinkedIn address
		exit;
	}

	public static function callback() {
		$st   = sanitize_text_field( wp_unslash( $_GET['state'] ?? '' ) ); // phpcs:ignore
		$code = sanitize_text_field( wp_unslash( $_GET['code'] ?? '' ) ); // phpcs:ignore
		$who  = $st ? (int) get_transient( 'mrsh_list_' . $st ) : 0;
		if ( ! current_user_can( 'manage_options' ) || ! $who || $who !== get_current_user_id() || ! $code ) {
			self::back( 'err=' . rawurlencode( 'LinkedIn connection was cancelled or expired. Please try again.' ) );
		}
		delete_transient( 'mrsh_list_' . $st );
		$a = self::app();
		$r = wp_remote_post( 'https://www.linkedin.com/oauth/v2/accessToken', array( 'timeout' => 20, 'body' => array( 'grant_type' => 'authorization_code', 'code' => $code, 'redirect_uri' => self::redirect_uri(), 'client_id' => $a['id'], 'client_secret' => $a['secret'] ) ) );
		$d = is_wp_error( $r ) ? array() : (array) json_decode( wp_remote_retrieve_body( $r ), true );
		if ( empty( $d['access_token'] ) ) {
			self::back( 'err=' . rawurlencode( 'LinkedIn did not give access. Check the Client ID, the secret and the redirect address in the LinkedIn app.' ) );
		}
		$tok = (string) $d['access_token'];
		$u   = wp_remote_get( 'https://api.linkedin.com/v2/userinfo', array( 'timeout' => 20, 'headers' => array( 'Authorization' => 'Bearer ' . $tok ) ) );
		$ui  = is_wp_error( $u ) ? array() : (array) json_decode( wp_remote_retrieve_body( $u ), true );
		if ( empty( $ui['sub'] ) ) {
			self::back( 'err=' . rawurlencode( 'Connected, but your LinkedIn ID could not be read. Add the product "Sign In with LinkedIn using OpenID Connect" to the app and try again.' ) );
		}
		$cf = (array) get_option( 'mrsh_ads_ch', array() );
		$cf['linkedin'] = array_merge( (array) ( $cf['linkedin'] ?? array() ), array( 'on' => 1, 'author' => 'urn:li:person:' . sanitize_text_field( $ui['sub'] ), 'token' => $tok ) );
		update_option( 'mrsh_ads_ch', $cf, false );
		update_option( 'mrsh_li_meta', array( 'name' => sanitize_text_field( $ui['name'] ?? '' ), 'exp' => time() + (int) ( $d['expires_in'] ?? 5184000 ) ), false );
		self::back( 'ok=1' );
	}

	public static function off() {
		self::guard( 'mrsh_li_off' );
		$cf = (array) get_option( 'mrsh_ads_ch', array() );
		unset( $cf['linkedin'] );
		update_option( 'mrsh_ads_ch', $cf, false );
		delete_option( 'mrsh_li_meta' );
		self::back( 'ok=1' );
	}

	/** Card shown at the top of the "More channels" area. */
	public static function card() {
		$a    = self::app();
		$cf   = (array) get_option( 'mrsh_ads_ch', array() );
		$meta = (array) get_option( 'mrsh_li_meta', array() );
		$have = ! empty( $cf['linkedin']['token'] );
		$exp  = (int) ( $meta['exp'] ?? 0 );
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">+</span><h2>Connect LinkedIn (one click)</h2></div>';
		if ( $have ) {
			$left = $exp ? (int) floor( ( $exp - time() ) / DAY_IN_SECONDS ) : 0;
			echo '<p class="mx-sub">Connected' . ( ! empty( $meta['name'] ) ? ' as <b>' . esc_html( $meta['name'] ) . '</b>' : '' ) . '.' . ( $exp ? ( $left > 0 ? ' The connection lasts about ' . (int) $left . ' more days; press Reconnect before then.' : ' The connection has probably expired. Press Reconnect.' ) : '' ) . '</p>';
		} else {
			echo '<p class="mx-sub">Save your LinkedIn app Client ID and Secret once, then press Connect and approve on LinkedIn. No tokens to copy.</p>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:grid;gap:8px;max-width:460px"><input type="hidden" name="action" value="mrsh_li_save">';
		wp_nonce_field( 'mrsh_li_save' );
		echo '<label class="t">Client ID<br><input type="text" name="li_id" value="' . esc_attr( $a['id'] ) . '" autocomplete="off" class="widefat"></label>';
		echo '<label class="t">Client Secret' . ( $a['secret'] ? ' (saved; leave empty to keep)' : '' ) . '<br><input type="password" name="li_secret" value="" autocomplete="new-password" class="widefat"></label>';
		echo '<button class="mx-btn">Save app details</button></form>';
		echo '<div class="mx-acts" style="margin-top:12px"><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'mrsh_li_go' );
		echo '<input type="hidden" name="action" value="mrsh_li_go"><button class="mx-btn p">' . ( $have ? 'Reconnect LinkedIn' : 'Connect LinkedIn' ) . '</button></form>';
		if ( $have ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( 'mrsh_li_off' );
			echo '<input type="hidden" name="action" value="mrsh_li_off"><button class="mx-btn d">Disconnect</button></form>';
		}
		echo '</div><p class="mx-note">In the LinkedIn app, open Auth and add this address under Authorized redirect URLs: <code>' . esc_html( self::redirect_uri() ) . '</code>. The app needs the products Share on LinkedIn and Sign In with LinkedIn using OpenID Connect.</p></div>';
	}
}

MRSH_Connect::init();
