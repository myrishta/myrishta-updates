<?php
/** Feature switchboard: every newer feature can be turned on or off from one admin page, so a live site can be upgraded in small steps and any step undone in one click. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Feat {

	const OPT = 'mrsh_feat';

	/** key => array( label, what it does, risk note ) */
	public static function all() {
		return array(
			'palette'  => array( 'Colour themes', 'Visitors can pick Rose, Mint, Sky, Warm, Dark or Auto in the footer.', 'Looks only' ),
			'textsize' => array( 'Large text button', 'An "A+ Large text" button in the footer.', 'Looks only' ),
			'safety'   => array( 'Safety reminder', 'A short "stay safe" note shown once to each visitor.', 'Looks only' ),
			'reports'  => array( 'Report and block history', 'Members see their reports and blocked profiles; blocked profiles are hidden from their lists.', 'Member data (adds notes to member accounts)' ),
			'biodata'  => array( 'Printable biodata', 'The [mrt_biodata] page: one-page A4 biodata for the member.', 'Low' ),
			'checklist' => array( 'Quick start checklist', 'The [mrt_checklist] page.', 'Low' ),
			'alerts'   => array( 'Scam alerts page', 'The [mrt_scam_alerts] page.', 'Low' ),
			'cities'   => array( 'City groups page', 'The [mrt_city_groups] page.', 'Low' ),
			'stats'    => array( 'Public statistics page', 'The [mrt_stats] page.', 'Low' ),
			'recover'  => array( 'Trusted contact and account recovery', 'The [mrt_trusted_contact] and [mrt_recover] pages.', 'Sends emails to members' ),
			'views'    => array( 'Profile view counts and weekly email', 'Counts profile views and sends members a weekly summary.', 'Sends emails to members' ),
			'pages'    => array( 'Create the new pages automatically', 'After an upgrade, creates any missing page for the features above.', 'Adds pages to the site' ),
			'secrets'  => array( 'Encrypt saved keys and passwords', 'Saved API keys and passwords are stored encrypted with the site secret key. Turn on only after taking a full backup.', 'Changes saved data' ),
		);
	}

	private static function is_test() {
		$h = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		return 0 === strpos( $h, 'test.' );
	}

	/** Is a feature on? Off by default on the live site, on by default on test.* sites. */
	public static function on( $key ) {
		$o = get_option( self::OPT, array() );
		if ( is_array( $o ) && array_key_exists( $key, $o ) ) {
			return (bool) $o[ $key ];
		}
		return self::is_test();
	}

	public static function init() {
		if ( ! is_admin() ) {
			return;
		}
		add_action( 'admin_menu', function () {
			add_submenu_page( 'myrishta-seo', 'Features', 'Features', 'manage_options', 'mrsh-features', array( __CLASS__, 'page' ) );
		}, 30 );
		add_action( 'admin_post_mrsh_feat_save', array( __CLASS__, 'save' ) );
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_feat_save' );
		$all = array_keys( self::all() );
		$o   = array();
		$bulk = isset( $_POST['bulk'] ) ? sanitize_key( wp_unslash( $_POST['bulk'] ) ) : '';
		foreach ( $all as $k ) {
			if ( 'on' === $bulk ) {
				$o[ $k ] = 1;
			} elseif ( 'off' === $bulk ) {
				$o[ $k ] = 0;
			} else {
				$o[ $k ] = ! empty( $_POST['f'][ $k ] ) ? 1 : 0;
			}
		}
		update_option( self::OPT, $o, false );
		do_action( 'litespeed_purge_all' );
		set_transient( 'mrsh_notice_' . get_current_user_id(), array( 'Features saved. Clear your page cache if a change does not show.', 'success' ), 60 );
		MRSH_Admin::back( 'mrsh-features' );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		MRSH_Admin::open( 'Features', 'Turn the newer features on one at a time. Each switch can be undone in one click.' );
		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Feature switches</h2></div>';
		echo '<p class="mrsh-muted">On a live site every switch starts <b>off</b>, so installing the new version changes nothing until you turn a feature on. Test sites start with everything on. Always take a full backup before turning on a feature marked "Changes saved data" or "Sends emails".</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_feat_save">';
		wp_nonce_field( 'mrsh_feat_save' );
		echo '<table class="widefat striped" style="max-width:980px"><tbody>';
		foreach ( self::all() as $k => $r ) {
			echo '<tr><td style="width:60px"><label><input type="checkbox" name="f[' . esc_attr( $k ) . ']" value="1"' . checked( self::on( $k ), true, false ) . '> On</label></td><td><b>' . esc_html( $r[0] ) . '</b><br><span class="mrsh-muted">' . esc_html( $r[1] ) . '</span></td><td style="width:230px"><em>' . esc_html( $r[2] ) . '</em></td></tr>';
		}
		echo '</tbody></table><p><button class="button button-primary" type="submit">Save</button> <button class="button" type="submit" name="bulk" value="on">Turn all on</button> <button class="button" type="submit" name="bulk" value="off">Turn all off</button></p></form></div>';
		MRSH_Admin::close();
	}
}

MRSH_Feat::init();
