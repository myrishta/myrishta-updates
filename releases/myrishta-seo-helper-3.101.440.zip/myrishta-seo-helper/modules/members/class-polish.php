<?php
/**
 * Apple / Samsung polish: home-screen icons (iPhone, iPad, Samsung One UI adaptive), iOS launch screens, notch safe areas,
 * squircle icon tiles, comfortable tap sizes, focus rings, standalone-app feel, app badge for unread messages, reading progress.
 * Only active when the My Rishta theme is the active theme. Switch off with the "mrsh_polish" filter.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Mem_Polish {

	public static function init() {
		add_action( 'wp_head', array( __CLASS__, 'head' ), 4 );
		add_action( 'wp_head', array( __CLASS__, 'css' ), 98 );
		add_action( 'wp_footer', array( __CLASS__, 'js' ), 60 );
	}

	private static function on() {
		return 'myrishta' === get_template() && apply_filters( 'mrsh_polish', true );
	}

	public static function u( $f ) {
		return MRSH_URL . 'assets/pwa/' . $f . '?v=' . MRSH_VERSION;
	}

	public static function head() {
		if ( ! self::on() ) {
			return;
		}
		echo '<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"><meta name="format-detection" content="telephone=no"><meta name="color-scheme" content="light">';
		echo '<meta name="theme-color" media="(prefers-color-scheme: light)" content="#ffffff"><meta name="theme-color" media="(prefers-color-scheme: dark)" content="#ffffff">';
		echo '<meta name="msapplication-TileColor" content="#01411c"><meta name="msapplication-TileImage" content="' . esc_url( self::u( 'icon-192.png' ) ) . '">';
		foreach ( array( 180, 167, 152, 120 ) as $s ) {
			echo '<link rel="apple-touch-icon" sizes="' . (int) $s . 'x' . (int) $s . '" href="' . esc_url( self::u( 'icon-' . $s . '.png' ) ) . '">';
		}
		if ( ! has_site_icon() ) { // the drawn logo as a sharp browser-tab icon (a Site icon set in Customize still wins)
			echo '<link rel="icon" type="image/svg+xml" href="' . esc_url( MRSH_URL . 'assets/favicon.svg?v=' . MRSH_VERSION ) . '"><link rel="icon" type="image/x-icon" href="' . esc_url( MRSH_URL . 'assets/favicon.ico?v=' . MRSH_VERSION ) . '">';
		}
		echo '<link rel="icon" type="image/png" sizes="192x192" href="' . esc_url( self::u( 'icon-192.png' ) ) . '">';
		// iOS launch screens: device width, height, pixel ratio.
		$sp = array(
			array( 390, 844, 3, 1170, 2532 ), array( 393, 852, 3, 1179, 2556 ), array( 430, 932, 3, 1290, 2796 ), array( 428, 926, 3, 1284, 2778 ),
			array( 375, 667, 2, 750, 1334 ), array( 414, 896, 2, 828, 1792 ), array( 375, 812, 3, 1125, 2436 ), array( 414, 896, 3, 1242, 2688 ),
			array( 834, 1194, 2, 1668, 2388 ), array( 1024, 1366, 2, 2048, 2732 ),
		);
		foreach ( $sp as $d ) {
			echo '<link rel="apple-touch-startup-image" media="(device-width:' . (int) $d[0] . 'px) and (device-height:' . (int) $d[1] . 'px) and (-webkit-device-pixel-ratio:' . (int) $d[2] . ') and (orientation:portrait)" href="' . esc_url( self::u( 'splash-' . $d[3] . 'x' . $d[4] . '.png' ) ) . '">';
		}
		echo "\n";
	}

	public static function css() {
		if ( ! self::on() ) {
			return;
		}
		$c = <<<'CSS'
html{-webkit-text-size-adjust:100%;-webkit-tap-highlight-color:transparent;text-rendering:optimizeLegibility;-webkit-font-smoothing:antialiased}
body{padding-left:env(safe-area-inset-left);padding-right:env(safe-area-inset-right)}
.site-head{padding-top:env(safe-area-inset-top)}
.mbar{padding-bottom:calc(env(safe-area-inset-bottom) + 2px)!important}
#mrt-toast,.wafloat,.wa-float{margin-bottom:env(safe-area-inset-bottom)}
:focus-visible{outline:3px solid color-mix(in srgb,var(--brand,#e11d74) 55%,transparent);outline-offset:2px;border-radius:8px}
a,button,.btn,.chip{touch-action:manipulation}
.mbar a,.tabs a{min-height:44px}
/* Apple squircle icon tiles (iOS 7+ continuous corner) */
.gi,.ib,.feat>i,.feat>.ic{border-radius:22.37%!important;box-shadow:0 1px 2px rgba(0,0,0,.08),inset 0 1px 0 rgba(255,255,255,.35)}
.mbar svg,.nav svg,.gi svg{stroke-linejoin:round;stroke-linecap:round}
/* One UI: soft pill highlight behind the active bottom tab */
.mbar a.on,.mbar a.cur,.mbar a[aria-current]{position:relative}
.mbar a.on::before,.mbar a.cur::before,.mbar a[aria-current]::before{content:"";position:absolute;top:2px;left:50%;width:56px;height:30px;transform:translateX(-50%);border-radius:999px;background:color-mix(in srgb,var(--brand,#e11d74) 14%,transparent);z-index:-1}
.mbar a{z-index:0}
.card .ph{overflow:hidden}
.card .ph img{transition:transform .35s}
.card:hover .ph img{transform:scale(1.04)}
::selection{background:color-mix(in srgb,var(--brand,#e11d74) 25%,transparent)}
@supports(scrollbar-width:thin){*{scrollbar-width:thin}}
@media(display-mode:standalone){html,body{overscroll-behavior-y:none}.nav a,.mbar a,.btn,.chip,h1,h2,h3{-webkit-user-select:none;user-select:none}a{-webkit-touch-callout:none}}
#mr-prog{position:fixed;top:0;left:0;height:3px;width:0;background:linear-gradient(90deg,var(--brand,#e11d74),var(--s,#7c3aed));z-index:99;transition:width .1s}
@media(prefers-reduced-motion:reduce){*,*::before,*::after{animation-duration:.01ms!important;transition-duration:.01ms!important;scroll-behavior:auto!important}}
CSS;
		echo '<style id="mrsh-polish">' . $c . "</style>\n"; // phpcs:ignore
	}

	public static function js() {
		if ( ! self::on() ) {
			return;
		}
		?>
<script>
(function(){
/* reading progress on articles */
if(document.body.classList.contains('single-post')||document.querySelector('article.post,.article')){var p=document.createElement('div');p.id='mr-prog';document.body.appendChild(p);
addEventListener('scroll',function(){var h=document.documentElement,m=h.scrollHeight-h.clientHeight;p.style.width=(m>0?Math.min(100,h.scrollTop/m*100):0)+'%'},{passive:true});}
/* app icon badge (Android / Samsung / desktop PWA, iOS 16.4+ installed app) mirrors unread messages */
function setB(n){try{if(n>0&&navigator.setAppBadge)navigator.setAppBadge(n);else if(navigator.clearAppBadge)navigator.clearAppBadge()}catch(e){}}
var C=window.MRT;if(C&&C.in&&C.ajax){var go=function(){if(document.hidden)return;var f=new FormData();f.append('action','mrsh_unread');f.append('n',C.n);
fetch(C.ajax,{method:'POST',body:f,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(r){if(r&&r.ok)setB(r.unread|0)}).catch(function(){})};
go();setInterval(go,60000);document.addEventListener('visibilitychange',go)}
})();
</script>
		<?php
	}
}
MRSH_Mem_Polish::init();
