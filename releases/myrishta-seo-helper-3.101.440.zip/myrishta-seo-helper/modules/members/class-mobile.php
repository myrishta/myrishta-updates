<?php
/**
 * Mobile number sign in (3.101.107).
 *  1. Log in with a mobile number and password in the normal login box (no SMS needed).
 *  2. Log in or sign up with a one-time code sent by SMS. Needs an SMS service: the address template is set on
 *     My Rishta SEO > Social login. Without it the code option stays hidden.
 *  3. A member who comes from Facebook or SMS without an email can add one later (banner on My account).
 * Numbers are saved as digits with the country code, for example 923001234567, in user meta mrt_mobile.
 * Staff and administrators can never sign in with a code. Codes: 6 digits, 10 minutes, 5 tries, rate limited.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Mobile {

	const OPT = 'mrsh_mobile';

	public static function get( $k = null ) {
		$o = array_merge( array( 'otp_on' => 0, 'mode' => 'sms', 'url' => '', 'body' => '', 'signup' => 1, 'fb_key' => '', 'fb_domain' => '', 'fb_project' => '' ), (array) get_option( self::OPT, array() ) );
		return null === $k ? $o : ( $o[ $k ] ?? '' );
	}

	public static function mode() {
		return 'firebase' === self::get( 'mode' ) ? 'firebase' : 'sms';
	}

	public static function otp_ready() {
		if ( ! self::get( 'otp_on' ) ) {
			return false;
		}
		return 'firebase' === self::mode() ? (bool) ( self::get( 'fb_key' ) && self::get( 'fb_project' ) ) : (bool) self::get( 'url' );
	}

	/** Public settings the browser needs for Firebase phone sign in (the web key is public by design). */
	public static function fb_public() {
		if ( 'firebase' !== self::mode() ) {
			return null;
		}
		$p = (string) self::get( 'fb_project' );
		return array( 'apiKey' => (string) self::get( 'fb_key' ), 'projectId' => $p, 'authDomain' => (string) ( self::get( 'fb_domain' ) ?: $p . '.firebaseapp.com' ) );
	}

	/** Digits with country code, or '' when it does not look like a phone number. Pakistan numbers: 0300..., 300..., +92 300... */
	public static function norm( $n ) {
		$d = preg_replace( '/\D+/', '', (string) $n );
		if ( 0 === strpos( $d, '0092' ) ) {
			$d = substr( $d, 2 );
		}
		if ( preg_match( '/^03\d{9}$/', $d ) ) {
			$d = '92' . substr( $d, 1 );
		} elseif ( preg_match( '/^3\d{9}$/', $d ) ) {
			$d = '92' . $d;
		}
		return ( strlen( $d ) >= 10 && strlen( $d ) <= 15 && '0' !== $d[0] ) ? $d : '';
	}

	public static function user_by( $n ) {
		if ( '' === $n ) {
			return null;
		}
		$u = get_users( array( 'meta_key' => 'mrt_mobile', 'meta_value' => $n, 'number' => 1 ) ); // phpcs:ignore
		return $u ? $u[0] : null;
	}

	public static function init() {
		add_filter( 'authenticate', array( __CLASS__, 'by_mobile' ), 15, 3 );
		add_filter( 'authenticate', array( __CLASS__, 'friendly' ), 30, 3 );
		add_action( 'admin_init', array( __CLASS__, 'migrate' ) );
		add_action( 'admin_post_mrsh_mobile_backfill', array( __CLASS__, 'backfill_now' ) );
		add_action( 'wp_ajax_nopriv_mrsh_otp_send', array( __CLASS__, 'send' ) );
		add_action( 'wp_ajax_mrsh_otp_send', array( __CLASS__, 'send' ) );
		add_action( 'wp_ajax_nopriv_mrsh_otp_check', array( __CLASS__, 'check' ) );
		add_action( 'wp_ajax_mrsh_otp_check', array( __CLASS__, 'check' ) );
		add_action( 'wp_ajax_nopriv_mrsh_fb_login', array( __CLASS__, 'fb_login' ) );
		add_action( 'wp_ajax_mrsh_fb_login', array( __CLASS__, 'fb_login' ) );
		add_action( 'admin_post_mrsh_set_email', array( __CLASS__, 'set_email' ) );
		add_action( 'admin_post_mrsh_mobile_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_mrsh_mobile_link', array( __CLASS__, 'link_profiles' ) );
		add_action( 'admin_post_mrsh_mobile_test', array( __CLASS__, 'test_sms' ) );
	}

	/** Meta keys where a phone number may sit without being saved as mrt_mobile. */
	private static function phone_keys() {
		return array( 'mrt_phone_v', 'mrt_phone', 'billing_phone', 'phone', 'whatsapp', 'mrt_whatsapp' );
	}

	/** Every way a number can be written, so a stored 0303... also matches 92303... */
	private static function variants( $n ) {
		$v = array( $n, '+' . $n );
		if ( 0 === strpos( $n, '92' ) ) {
			$v[] = '0' . substr( $n, 2 );
			$v[] = substr( $n, 2 );
		}
		return $v;
	}

	/** Find a member from whatever they typed: mobile number, email, user name, or full name (only when exactly one member has it). */
	public static function find( $ident ) {
		$ident = trim( (string) $ident );
		if ( '' === $ident ) {
			return null;
		}
		if ( is_email( $ident ) ) {
			$u = get_user_by( 'email', $ident );
			return $u ? $u : null;
		}
		$u = get_user_by( 'login', $ident );
		if ( $u ) {
			return $u;
		}
		if ( preg_match( '/^[+0-9\s().\-]{9,20}$/', $ident ) ) {
			$n = self::norm( $ident );
			if ( '' === $n ) {
				return null;
			}
			$u = self::user_by( $n );
			if ( $u ) {
				return $u;
			}
			foreach ( self::phone_keys() as $k ) {
				$f = get_users( array( 'meta_key' => $k, 'meta_value' => '', 'meta_compare' => '!=', 'fields' => 'ID', 'number' => 0, 'count_total' => false, 'meta_query' => array( array( 'key' => $k, 'value' => self::variants( $n ), 'compare' => 'IN' ) ) ) ); // phpcs:ignore
				if ( 1 === count( (array) $f ) ) {
					return get_user_by( 'id', (int) $f[0] );
				}
			}
			return null;
		}
		if ( strlen( $ident ) >= 3 && false === strpos( $ident, '@' ) ) {
			$f = get_users( array( 'search' => $ident, 'search_columns' => array( 'display_name' ), 'number' => 3, 'fields' => 'all' ) );
			$f = array_values( array_filter( (array) $f, function ( $x ) use ( $ident ) {
				return 0 === strcasecmp( trim( $x->display_name ), $ident ) && ! user_can( $x, 'manage_options' ) && ! user_can( $x, 'edit_others_posts' );
			} ) );
			if ( 1 === count( $f ) ) {
				return $f[0];
			}
		}
		return null;
	}

	/** The normal login box also accepts a mobile number, or the member's full name, as the user name. */
	public static function by_mobile( $user, $username, $password ) {
		$ident = trim( (string) $username );
		if ( $user instanceof WP_User || '' === $ident || '' === (string) $password || is_email( $ident ) || username_exists( $ident ) ) {
			return $user;
		}
		$u = self::find( $ident );
		if ( ! $u ) {
			return $user;
		}
		$r = wp_authenticate_username_password( null, $u->user_login, $password );
		if ( $r instanceof WP_User ) {
			$n = self::norm( $ident );
			if ( $n && preg_match( '/^[+0-9\s().\-]{9,20}$/', $ident ) && ! get_user_meta( $r->ID, 'mrt_mobile', true ) && ! self::user_by( $n ) ) {
				update_user_meta( $r->ID, 'mrt_mobile', $n ); // next time the number works at once
			}
			return $r;
		}
		return $user;
	}

	/** A clear message when a number or name is not found, instead of the confusing "unknown username". */
	public static function friendly( $user, $username, $password ) {
		$ident = trim( (string) $username );
		if ( ! is_wp_error( $user ) || '' === $ident || is_email( $ident ) || ! in_array( $user->get_error_code(), array( 'invalid_username', 'invalid_email' ), true ) ) {
			return $user;
		}
		$lost = esc_url( wp_lostpassword_url() );
		if ( preg_match( '/^[+0-9\s().\-]{9,20}$/', $ident ) ) {
			return new WP_Error( 'mrsh_nomobile', 'We could not find an account with that mobile number. Please log in with the email you signed up with, or <a href="' . $lost . '">reset your password</a>. If you signed up with a number, use the same number you registered with.' );
		}
		return new WP_Error( 'mrsh_noname', 'Please log in with your <b>email address</b> (or your mobile number) and your password. A name alone is not enough. Forgot it? <a href="' . $lost . '">Reset your password</a>.' );
	}

	/** Save the number from each member's profile so mobile log in works for everyone. Returns how many were added. */
	public static function backfill() {
		global $wpdb;
		$rows = $wpdb->get_results( "SELECT p.post_author a, m.meta_value v FROM {$wpdb->postmeta} m JOIN {$wpdb->posts} p ON p.ID=m.post_id WHERE p.post_type='listing_type' AND m.meta_key IN ('custom-14','phone','mrt_phone','whatsapp') AND m.meta_value<>'' LIMIT 20000" ); // phpcs:ignore
		$add  = 0;
		$seen = array();
		foreach ( (array) $rows as $r ) {
			$uid = (int) $r->a;
			$n   = self::norm( $r->v );
			if ( ! $uid || '' === $n || isset( $seen[ $uid ] ) || get_user_meta( $uid, 'mrt_mobile', true ) || self::user_by( $n ) ) {
				continue;
			}
			$u = get_user_by( 'id', $uid );
			if ( ! $u || user_can( $u, 'manage_options' ) || user_can( $u, 'edit_others_posts' ) ) {
				continue;
			}
			update_user_meta( $uid, 'mrt_mobile', $n );
			$seen[ $uid ] = 1;
			$add++;
		}
		return $add;
	}

	public static function backfill_now() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.', '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'mrsh_mobile_backfill' );
		$n = self::backfill();
		wp_safe_redirect( add_query_arg( 'msg', rawurlencode( (int) $n . ' member phone number(s) saved. They can now log in with their mobile.' ), admin_url( 'admin.php?page=mrsh-shield' ) ) );
		exit;
	}

	public static function migrate() {
		if ( get_option( 'mrsh_mobile_fill' ) ) {
			return;
		}
		update_option( 'mrsh_mobile_fill', self::backfill(), false );
	}

	/* ---------- one-time code ---------- */

	private static function ip() {
		return function_exists( 'mrt_ip' ) ? mrt_ip() : (string) ( $_SERVER['REMOTE_ADDR'] ?? '0' ); // phpcs:ignore
	}

	private static function sms( $to, $msg ) {
		$url = (string) self::get( 'url' );
		if ( '' === $url ) {
			return false;
		}
		$rep  = array( '{to}' => rawurlencode( $to ), '{msg}' => rawurlencode( $msg ) );
		$body = (string) self::get( 'body' );
		$args = array( 'timeout' => 15 );
		if ( '' !== $body ) {
			$args['body']    = strtr( $body, array( '{to}' => $to, '{msg}' => $msg ) );
			$args['headers'] = array( 'Content-Type' => 'application/x-www-form-urlencoded' );
			$r               = wp_remote_post( strtr( $url, $rep ), $args );
		} else {
			$r = wp_remote_get( strtr( $url, $rep ), $args );
		}
		$c = is_wp_error( $r ) ? 0 : (int) wp_remote_retrieve_response_code( $r );
		return $c >= 200 && $c < 300;
	}

	public static function send() {
		if ( ! self::otp_ready() ) {
			wp_send_json_error( 'Mobile code sign in is not switched on.' );
		}
		$n = self::norm( wp_unslash( $_POST['m'] ?? '' ) ); // phpcs:ignore
		if ( '' === $n ) {
			wp_send_json_error( 'Enter a valid mobile number, for example 0300 1234567.' );
		}
		$ik = 'mrsh_otpi_' . md5( self::ip() );
		$nk = 'mrsh_otpn_' . $n;
		if ( (int) get_transient( $ik ) >= 10 || (int) get_transient( $nk ) >= 3 ) {
			wp_send_json_error( 'Too many codes requested. Please wait an hour.' );
		}
		// Daily cap for the whole site, so spreading requests across many addresses cannot run up SMS charges.
		$dk = 'mrsh_otpd_' . gmdate( 'Ymd' );
		if ( (int) get_transient( $dk ) >= (int) apply_filters( 'mrsh_otp_daily_cap', 300 ) ) {
			wp_send_json_error( 'Code sign in is busy right now. Please use your email and password, or try again tomorrow.' );
		}
		set_transient( $dk, (int) get_transient( $dk ) + 1, DAY_IN_SECONDS );
		$u = self::user_by( $n );
		if ( ! $u && ! self::get( 'signup' ) ) {
			wp_send_json_error( 'New sign ups by mobile are closed. Please sign up with email.' );
		}
		// Staff never get a code by SMS. The reply is the same as for everyone else, so it does not reveal who is staff.
		if ( $u && ( user_can( $u, 'manage_options' ) || user_can( $u, 'edit_others_posts' ) ) ) {
			wp_send_json_success( array() );
		}
		$code = (string) wp_rand( 100000, 999999 );
		set_transient( $nk, (int) get_transient( $nk ) + 1, HOUR_IN_SECONDS );
		set_transient( $ik, (int) get_transient( $ik ) + 1, HOUR_IN_SECONDS );
		set_transient( 'mrsh_otpc_' . $n, array( 'h' => wp_hash_password( $code ), 'tries' => 0 ), 10 * MINUTE_IN_SECONDS );
		$name = function_exists( 'mrt_site' ) ? (string) mrt_site( 'name', get_bloginfo( 'name' ) ) : get_bloginfo( 'name' );
		if ( ! self::sms( $n, $code . ' is your ' . $name . ' code. It is valid for 10 minutes. Do not share it.' ) ) {
			wp_send_json_error( 'The code could not be sent. Please try again later or use email.' );
		}
		wp_send_json_success( array() ); // same reply for new and existing numbers, so the list of members cannot be checked
	}

	public static function check() {
		$n    = self::norm( wp_unslash( $_POST['m'] ?? '' ) ); // phpcs:ignore
		$code = preg_replace( '/\D+/', '', (string) wp_unslash( $_POST['c'] ?? '' ) ); // phpcs:ignore
		$st   = $n ? get_transient( 'mrsh_otpc_' . $n ) : false;
		if ( ! $st || strlen( $code ) !== 6 ) {
			wp_send_json_error( 'The code is wrong or expired. Ask for a new code.' );
		}
		if ( (int) $st['tries'] >= 5 ) {
			delete_transient( 'mrsh_otpc_' . $n );
			wp_send_json_error( 'Too many wrong tries. Ask for a new code.' );
		}
		if ( ! wp_check_password( $code, $st['h'] ) ) {
			$st['tries']++;
			set_transient( 'mrsh_otpc_' . $n, $st, 10 * MINUTE_IN_SECONDS );
			wp_send_json_error( 'That code is not right. Please check and try again.' );
		}
		delete_transient( 'mrsh_otpc_' . $n );
		self::finish( $n );
	}

	/** The number is proven (SMS code or Firebase). Log the member in, or create the account. Ends the request. */
	private static function finish( $n ) {
		$u   = self::user_by( $n );
		$new = false;
		if ( $u && ( user_can( $u, 'manage_options' ) || user_can( $u, 'edit_others_posts' ) ) ) {
			wp_send_json_error( 'Staff accounts must log in with a password.' );
		}
		if ( ! $u ) {
			if ( ! self::get( 'signup' ) ) {
				wp_send_json_error( 'New sign ups by mobile are closed.' );
			}
			$login = 'm' . $n;
			$host  = (string) wp_parse_url( home_url(), PHP_URL_HOST );
			$uid   = wp_create_user( $login, wp_generate_password( 32 ), 'm' . $n . '@noemail.' . $host );
			if ( is_wp_error( $uid ) ) {
				wp_send_json_error( 'Could not create your account. Please try again.' );
			}
			update_user_meta( $uid, 'mrt_mobile', $n );
			update_user_meta( $uid, 'mrt_need_email', 1 );
			wp_update_user( array( 'ID' => $uid, 'display_name' => 'Member ' . substr( $n, -4 ) ) );
			$u   = get_user_by( 'id', $uid );
			$new = true;
		}
		update_user_meta( $u->ID, 'mrt_mobile_ok', 1 );
		wp_set_current_user( $u->ID );
		wp_set_auth_cookie( $u->ID, true );
		do_action( 'wp_login', $u->user_login, $u );
		$to = $new ? ( function_exists( 'mrt_link' ) ? mrt_link( 'add', '/add-listing/' ) : home_url( '/add-listing/' ) ) : ( function_exists( 'mrt_link' ) ? mrt_link( 'myaccount', '/my-account/' ) : home_url( '/my-account/' ) );
		wp_send_json_success( array( 'to' => $to ) );
	}

	/** Firebase phone sign in: the browser sends the Firebase ID token, Google confirms it and gives back the phone number. */
	public static function fb_login() {
		if ( 'firebase' !== self::mode() || ! self::otp_ready() ) {
			wp_send_json_error( 'Mobile sign in is not switched on.' );
		}
		$ik = 'mrsh_fbi_' . md5( self::ip() );
		if ( (int) get_transient( $ik ) >= 20 ) {
			wp_send_json_error( 'Too many tries. Please wait an hour.' );
		}
		set_transient( $ik, (int) get_transient( $ik ) + 1, HOUR_IN_SECONDS );
		$t = sanitize_text_field( wp_unslash( $_POST['t'] ?? '' ) ); // phpcs:ignore
		if ( strlen( $t ) < 100 || strlen( $t ) > 4000 ) {
			wp_send_json_error( 'Could not check the code. Please try again.' );
		}
		$r = wp_remote_post( 'https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=' . rawurlencode( (string) self::get( 'fb_key' ) ), array( 'timeout' => 15, 'headers' => array( 'Content-Type' => 'application/json' ), 'body' => wp_json_encode( array( 'idToken' => $t ) ) ) );
		$d = is_wp_error( $r ) ? array() : (array) json_decode( wp_remote_retrieve_body( $r ), true );
		$p = (string) ( $d['users'][0]['phoneNumber'] ?? '' );
		$n = self::norm( $p );
		if ( '' === $n ) {
			wp_send_json_error( 'The phone number could not be confirmed. Please try again.' );
		}
		self::finish( $n );
	}

	/* ---------- add an email later ---------- */

	public static function banner() {
		$uid = get_current_user_id();
		if ( ! $uid || ! get_user_meta( $uid, 'mrt_need_email', true ) ) {
			return '';
		}
		$h  = '<form class="box mrsh-needmail" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:flex;flex-wrap:wrap;gap:10px;align-items:center;border-radius:18px;padding:14px 16px;background:#fff8e6;box-shadow:0 0 0 1px #fde7a6;margin:0 0 14px"><b>Add your email</b><span style="flex:1 1 220px;color:#6b7280;font-size:.9rem">It lets you recover your account and receive match and message alerts.</span>';
		$h .= '<input type="hidden" name="action" value="mrsh_set_email">' . wp_nonce_field( 'mrsh_set_email', '_wpnonce', true, false ) . '<input type="email" name="email" required placeholder="name@example.com" style="min-height:42px;border-radius:12px;border:1px solid #d9dbe8;padding:0 12px"><button class="btn" style="min-height:42px">Save email</button></form>';
		return $h;
	}

	public static function set_email() {
		$uid = get_current_user_id();
		$bk  = function_exists( 'mrt_link' ) ? mrt_link( 'myaccount', '/my-account/' ) : home_url( '/my-account/' );
		if ( ! $uid || ! check_admin_referer( 'mrsh_set_email' ) ) {
			wp_die( 'Not allowed.' );
		}
		$em = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) ); // phpcs:ignore
		if ( ! is_email( $em ) || ( email_exists( $em ) && (int) email_exists( $em ) !== $uid ) ) {
			wp_safe_redirect( add_query_arg( 'mail', 'bad', $bk ) );
			exit;
		}
		wp_update_user( array( 'ID' => $uid, 'user_email' => $em ) );
		delete_user_meta( $uid, 'mrt_need_email' );
		wp_safe_redirect( $bk );
		exit;
	}

	/* ---------- admin ---------- */

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'mrsh_mobile_save' ) ) {
			wp_die( 'Not allowed.' );
		}
		$o = (array) get_option( self::OPT, array() );
		if ( ! empty( $_POST['url'] ) ) { // phpcs:ignore
			$o['url'] = esc_url_raw( wp_unslash( $_POST['url'] ) ); // phpcs:ignore
		}
		if ( ! empty( $_POST['clear'] ) ) { // phpcs:ignore
			$o['url']  = '';
			$o['body'] = '';
		}
		if ( ! empty( $_POST['body'] ) ) { // phpcs:ignore
			$o['body'] = sanitize_text_field( wp_unslash( $_POST['body'] ) ); // phpcs:ignore
		}
		$o['mode']       = ( isset( $_POST['mode'] ) && 'firebase' === $_POST['mode'] ) ? 'firebase' : 'sms'; // phpcs:ignore
		$o['fb_key']     = ! empty( $_POST['fb_key'] ) ? sanitize_text_field( wp_unslash( $_POST['fb_key'] ) ) : ( $o['fb_key'] ?? '' ); // phpcs:ignore
		$o['fb_project'] = isset( $_POST['fb_project'] ) ? sanitize_key( wp_unslash( $_POST['fb_project'] ) ) : ( $o['fb_project'] ?? '' ); // phpcs:ignore
		$o['fb_domain']  = isset( $_POST['fb_domain'] ) ? preg_replace( '#^https?://|/.*$#', '', sanitize_text_field( wp_unslash( $_POST['fb_domain'] ) ) ) : ( $o['fb_domain'] ?? '' ); // phpcs:ignore
		$o['otp_on'] = empty( $_POST['otp_on'] ) ? 0 : 1; // phpcs:ignore
		$o['signup'] = empty( $_POST['signup'] ) ? 0 : 1; // phpcs:ignore
		update_option( self::OPT, $o, false );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-social&ok=1' ) );
		exit;
	}

	public static function test_sms() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'mrsh_mobile_test' ) ) {
			wp_die( 'Not allowed.' );
		}
		$n  = self::norm( wp_unslash( $_POST['to'] ?? '' ) ); // phpcs:ignore
		$ok = $n && self::sms( $n, 'Test message from your website. Mobile codes are working.' );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-social&sms=' . ( $ok ? 'ok' : 'fail' ) ) );
		exit;
	}

	/** Copies each profile's phone number to its owner so the member can log in with it. Skips numbers used twice. */
	public static function link_profiles() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'mrsh_mobile_link' ) ) {
			wp_die( 'Not allowed.' );
		}
		$done = 0;
		$ids  = get_posts( array( 'post_type' => 'listing_type', 'post_status' => array( 'publish', 'draft' ), 'numberposts' => 3000, 'fields' => 'ids', 'no_found_rows' => true ) );
		foreach ( $ids as $pid ) {
			$ph = class_exists( 'MRSH_Members' ) ? (string) MRSH_Members::phone_of( $pid ) : '';
			$n  = self::norm( $ph );
			$au = (int) get_post_field( 'post_author', $pid );
			if ( '' === $n || ! $au || get_user_meta( $au, 'mrt_mobile', true ) || self::user_by( $n ) || user_can( $au, 'edit_others_posts' ) ) {
				continue;
			}
			update_user_meta( $au, 'mrt_mobile', $n );
			$done++;
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-social&linked=' . $done ) );
		exit;
	}
}
MRSH_Mobile::init();
