<?php
/**
 * Admin page "Profile Helper" (a tab in the Members hub): numbers, switches, AI and speech checks, coach calendar and messages,
 * members list with manual buttons, log. Modern plugin design (hero, cards, stat tiles, badges). Every automation has a manual button.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_HelperAdmin {

	const SLUG = 'mrsh-helper';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 44 );
		add_action( 'admin_post_mrsh_ph_save', array( __CLASS__, 'act_save' ) );
		add_action( 'admin_post_mrsh_ph_do', array( __CLASS__, 'act_do' ) );
		add_action( 'admin_post_mrsh_ph_pause', array( __CLASS__, 'act_pause' ) );
		add_action( 'admin_post_mrsh_ph_csv', array( __CLASS__, 'act_csv' ) );
		add_action( 'admin_post_mrsh_ph_bulk', array( __CLASS__, 'act_bulk' ) );
		add_action( 'admin_post_mrsh_ph_privacy', array( __CLASS__, 'act_privacy' ) );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Profile Helper', 'Profile Helper', 'manage_options', self::SLUG, array( __CLASS__, 'page' ) );
	}

	private static function back( $msg ) {
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&msg=' . rawurlencode( $msg ) ) );
		exit;
	}

	private static function guard( $a ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'No access.' );
		}
		check_admin_referer( $a );
	}

	/* ---------- actions ---------- */

	public static function act_save() {
		self::guard( 'mrsh_ph_save' );
		$p = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.NonceVerification
		$o = MRSH_Helper::get();
		$who = isset( $p['who'] ) ? sanitize_key( $p['who'] ) : 'admins';
		$o['who'] = in_array( $who, array( 'nobody', 'admins', 'all' ), true ) ? $who : 'admins';
		foreach ( array( 'speak', 'ques', 'type', 'hands', 'stt', 'ai', 'paid', 'coach', 'announce', 'banner', 'push', 'wiz' ) as $k ) {
			$o[ $k ] = empty( $p[ 'sw_' . $k ] ) ? 0 : 1;
		}
		$o['quiet_from'] = max( 0, min( 23, (int) ( $p['quiet_from'] ?? 22 ) ) );
		$o['quiet_to']   = max( 0, min( 23, (int) ( $p['quiet_to'] ?? 9 ) ) );
		$o['gap_h']      = max( 1, min( 240, (int) ( $p['gap_h'] ?? 36 ) ) );
		$o['life']       = max( 1, min( 30, (int) ( $p['life'] ?? 6 ) ) );
		$o['budget']     = max( 20, min( 5000, (int) ( $p['budget'] ?? 400 ) ) );
		update_option( MRSH_Helper::OPT, $o, false );
		if ( ! empty( $p['str'] ) && is_array( $p['str'] ) ) {
			$d = MRSH_Helper::default_strings();
			$s = array();
			foreach ( $p['str'] as $k => $v ) {
				$k = sanitize_key( $k );
				$v = sanitize_textarea_field( $v );
				if ( isset( $d[ $k ] ) && '' !== trim( $v ) && $v !== $d[ $k ] ) {
					$s[ $k ] = $v;
				}
			}
			update_option( MRSH_Helper::STR, $s, false );
		}
		MRSH_Helper::log( 'admin', 'Settings saved (who=' . $o['who'] . ')' );
		self::back( 'Saved. Clear the LiteSpeed cache so visitors see the change.' );
	}

	public static function act_do() {
		self::guard( 'mrsh_ph_do' );
		$op  = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : ''; // phpcs:ignore
		$uid = isset( $_POST['uid'] ) ? (int) $_POST['uid'] : 0; // phpcs:ignore
		$o   = MRSH_Helper::get();
		switch ( $op ) {
			case 'run':
				if ( 'all' !== $o['who'] ) { // preview mode: show who WOULD get a message, send nothing
					$pl = MRSH_Coach::plan( 200 );
					self::back( 'Preview only: the helper is not on for everyone, so nothing was sent. ' . count( $pl ) . ' member(s) would get a message now. Set "Who sees the helper" to Everyone first.' );
				}
				$n = MRSH_Coach::run( true );
				self::back( 'Coach ran now: ' . $n . ' message(s) sent.' );
				break;
			case 'pause':
				$o['paused'] = 1;
				update_option( MRSH_Helper::OPT, $o, false );
				self::back( 'Coach paused. Nothing will be sent until you press Resume.' );
				break;
			case 'resume':
				$o['paused'] = 0;
				update_option( MRSH_Helper::OPT, $o, false );
				delete_transient( 'mrsh_coach_bounce_pause' );
				self::back( 'Coach resumed.' );
				break;
			case 'reset':
				delete_option( MRSH_Helper::CNT );
				delete_option( 'mrsh_ph_day' );
				delete_option( MRSH_Coach::STATS );
				delete_option( 'mrsh_aib_helper' );
				self::back( 'Counters reset.' );
				break;
			case 'resetlog':
				delete_option( MRSH_Helper::LOG );
				self::back( 'Log cleared.' );
				break;
			case 'test_mail':
				$c  = isset( $_POST['code'] ) ? sanitize_text_field( wp_unslash( $_POST['code'] ) ) : 'A-1'; // phpcs:ignore
				$ok = MRSH_Coach::send_test( wp_get_current_user(), $c );
				self::back( $ok ? 'Test email sent to ' . wp_get_current_user()->user_email : 'The test email could not be sent. Check Email delivery.' );
				break;
			case 'test_ai':
				$r = MRSH_AIHub::ask( 'Reply with the single word OK.', 'ping', 10, array( 'budget' => 'helper', 'cap' => (int) $o['budget'], 'free_only' => true ) );
				self::back( is_wp_error( $r ) ? 'AI test failed: ' . $r->get_error_message() : 'AI test passed: the free pool answered "' . mb_substr( trim( $r ), 0, 30 ) . '".' );
				break;
			case 'test_stt':
				self::back( self::test_stt() );
				break;
			case 'invite':
				$ok = $uid && MRSH_Coach::invite( $uid );
				self::back( $ok ? 'Invitation sent to member #' . $uid : 'Not sent: the member is complete, stopped, or has no valid email.' );
				break;
			case 'mpause':
				update_user_meta( $uid, 'mrsh_coach_stop', time() );
				self::back( 'Coach paused for member #' . $uid );
				break;
			case 'mresume':
				delete_user_meta( $uid, 'mrsh_coach_stop' );
				self::back( 'Coach resumed for member #' . $uid );
				break;
			case 'mreset':
				foreach ( array( 'mrsh_coach_n', 'mrsh_coach_A', 'mrsh_coach_B', 'mrsh_coach_C', 'mrsh_coach_last', 'mrsh_coach_ann', 'mrsh_coach_push_t', 'mrsh_coach_code', 'mrsh_coach_stop' ) as $k ) {
					delete_user_meta( $uid, $k );
				}
				self::back( 'Message count reset for member #' . $uid );
				break;
			case 'news_start':
				if ( 'all' !== $o['who'] ) {
					self::back( 'Not started: set "Who sees the helper" to Everyone first, so members land on the helper.' );
				}
				$ns = MRSH_Coach::news_state();
				$ns['on'] = 1;
				$ns['started'] = $ns['started'] ?: time();
				update_option( MRSH_Coach::NEWS, $ns, false );
				MRSH_Helper::log( 'news', 'News started by the owner' );
				self::back( 'News started. It goes out 40 emails an hour (never 22:00 to 09:00) to everyone who has not left the newsletter.' );
				break;
			case 'news_stop':
				$ns = MRSH_Coach::news_state();
				$ns['on'] = 0;
				update_option( MRSH_Coach::NEWS, $ns, false );
				self::back( 'News stopped. Nothing more will be sent until you press Start again.' );
				break;
			case 'news_test':
				list( $sj, $tx, $ht ) = MRSH_Coach::news_mail( wp_get_current_user() );
				self::back( wp_mail( wp_get_current_user()->user_email, '[Test] ' . $sj, $ht, array( 'Content-Type: text/html; charset=UTF-8' ) ) ? 'News test sent to ' . wp_get_current_user()->user_email : 'The test could not be sent.' );
				break;
			case 'tpl':
				self::save_tpl();
				break;
			case 'tpl_reset':
				delete_option( MRSH_Coach::TPL );
				self::back( 'Messages are back to the standard wording.' );
				break;
		}
		self::back( 'Nothing to do.' );
	}

	private static function save_tpl() {
		$d = MRSH_Coach::default_tpl();
		$s = array();
		$p = isset( $_POST['tpl'] ) && is_array( $_POST['tpl'] ) ? wp_unslash( $_POST['tpl'] ) : array(); // phpcs:ignore
		foreach ( $p as $k => $v ) {
			if ( ! isset( $d[ $k ] ) || ! is_array( $v ) ) {
				continue;
			}
			foreach ( array( 's', 'b', 'e', 'btn' ) as $f ) {
				$x = isset( $v[ $f ] ) ? sanitize_textarea_field( $v[ $f ] ) : '';
				if ( '' !== trim( $x ) && $x !== $d[ $k ][ $f ] ) {
					$s[ $k ][ $f ] = $x;
				}
			}
		}
		update_option( MRSH_Coach::TPL, $s, false );
		self::back( 'Messages saved.' );
	}

	/** Sends one second of silence to Groq whisper to see that the key and the service work. */
	private static function test_stt() {
		$key = class_exists( 'MRSH_AIHub' ) ? trim( (string) ( MRSH_AIHub::o()['pool']['groq']['key'] ?? '' ) ) : '';
		if ( '' === $key ) {
			return 'Speech test: no Groq key is saved in AI Assistant (free pool). Add one to turn on the server speech fallback.';
		}
		$rate = 8000;
		$pcm  = str_repeat( "\x00\x00", $rate ); // one second of silence, 16-bit mono
		$wav  = 'RIFF' . pack( 'V', 36 + strlen( $pcm ) ) . 'WAVEfmt ' . pack( 'VvvVVvv', 16, 1, 1, $rate, $rate * 2, 2, 16 ) . 'data' . pack( 'V', strlen( $pcm ) ) . $pcm;
		$b    = wp_generate_password( 20, false );
		$body = '';
		foreach ( array( 'model' => 'whisper-large-v3-turbo', 'language' => 'ur', 'response_format' => 'json' ) as $k => $v ) {
			$body .= "--$b\r\nContent-Disposition: form-data; name=\"$k\"\r\n\r\n$v\r\n";
		}
		$body .= "--$b\r\nContent-Disposition: form-data; name=\"file\"; filename=\"t.wav\"\r\nContent-Type: audio/wav\r\n\r\n" . $wav . "\r\n--$b--\r\n";
		$r = wp_remote_post( 'https://api.groq.com/openai/v1/audio/transcriptions', array( 'timeout' => 30, 'headers' => array( 'Authorization' => 'Bearer ' . $key, 'Content-Type' => 'multipart/form-data; boundary=' . $b ), 'body' => $body ) );
		if ( is_wp_error( $r ) ) {
			return 'Speech test failed: ' . $r->get_error_message();
		}
		$c = (int) wp_remote_retrieve_response_code( $r );
		return 200 === $c ? 'Speech test passed: Groq whisper answered.' : 'Speech test failed: Groq answered HTTP ' . $c . '.';
	}

	/** One click from the owner's summary email. */
	public static function act_pause() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Log in as the site owner first.' );
		}
		check_admin_referer( 'mrsh_ph_pause' );
		$o           = MRSH_Helper::get();
		$o['paused'] = 1;
		update_option( MRSH_Helper::OPT, $o, false );
		self::back( 'Coach paused.' );
	}

	public static function act_bulk() {
		self::guard( 'mrsh_ph_bulk' );
		$ids = isset( $_POST['ids'] ) ? array_map( 'intval', (array) $_POST['ids'] ) : array(); // phpcs:ignore
		$n   = 0;
		foreach ( array_slice( $ids, 0, 60 ) as $id ) {
			if ( $id > 0 && MRSH_Coach::invite( $id ) ) {
				$n++;
			}
		}
		self::back( $n . ' invitation(s) sent.' );
	}

	public static function act_csv() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'No access.' );
		}
		check_admin_referer( 'mrsh_ph_csv' );
		$c = MRSH_Helper::counters();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=profile-helper-funnel.csv' );
		$f = fopen( 'php://output', 'w' );
		fputcsv( $f, array( 'step', 'members' ) );
		foreach ( self::funnel_steps() as $k => $l ) {
			fputcsv( $f, array( $l, (int) ( $c[ 'scr_' . $k ] ?? 0 ) ) );
		}
		fputcsv( $f, array() );
		fputcsv( $f, array( 'message', 'sent', 'opened', 'saved' ) );
		foreach ( MRSH_Coach::stats() as $k => $v ) {
			fputcsv( $f, array( $k, $v[0], $v[1], $v[2] ) );
		}
		fclose( $f );
		exit;
	}

	public static function act_privacy() {
		self::guard( 'mrsh_ph_privacy' );
		$pid = 17745;
		$p   = get_post( $pid );
		if ( ! $p || false !== strpos( $p->post_content, 'mrsh-ph-privacy' ) ) {
			self::back( $p ? 'The Privacy Policy already has the Profile Helper wording.' : 'Privacy Policy page 17745 was not found.' );
		}
		$add = '<div class="mrsh-ph-privacy"><h2>Voice help (optional)</h2><p>If you use the voice option, your browser\'s speech service converts what you say into text; we do not record or store your audio. If your browser has no speech service, a short recording is sent to a speech-to-text provider (Groq) for transcription and is deleted immediately afterwards. The text is sent, with phone numbers, email addresses and ID numbers removed, to an AI service that sorts it into the profile form (our free AI services: Groq, Google Gemini, OpenRouter, Cerebras, Mistral, GitHub Models, NVIDIA). You always review the result before anything is saved. You can use the form without voice or AI.</p>'
			. '<h2>آواز کے ذریعے مدد (اختیاری)</h2><p dir="rtl">اگر آپ آواز کا طریقہ استعمال کریں تو آپ کے براؤزر کی اسپیچ سروس آپ کی بات کو متن میں بدلتی ہے؛ ہم آپ کی آواز ریکارڈ یا محفوظ نہیں کرتے۔ اگر آپ کے براؤزر میں اسپیچ سروس نہ ہو تو ایک مختصر ریکارڈنگ متن بنانے کے لیے ایک اسپیچ ٹو ٹیکسٹ سروس (Groq) کو بھیجی جاتی ہے اور فوراً مٹا دی جاتی ہے۔ یہ متن، فون نمبر، ای میل اور شناختی نمبر ہٹانے کے بعد، ایک اے آئی سروس کو بھیجا جاتا ہے جو اسے پروفائل فارم میں ترتیب دیتی ہے۔ کچھ بھی محفوظ ہونے سے پہلے نتیجہ آپ خود دیکھتے ہیں۔ آپ آواز یا اے آئی کے بغیر بھی فارم بھر سکتے ہیں۔</p></div>';
		wp_update_post( array( 'ID' => $pid, 'post_content' => $p->post_content . "\n" . $add ) );
		self::back( 'Privacy Policy updated. Clear the cache.' );
	}

	/* ---------- numbers ---------- */

	private static function funnel_steps() {
		return array(
			'start' => 'Opened the helper', 'who' => 'Who is it for', 'gender' => 'Boy or girl', 'mode' => 'Chose a way', 'speak' => 'Spoke',
			'check' => 'Check screen', 'about' => 'About me', 'photo' => 'Photo', 'save' => 'Pressed save', 'done' => 'Saved',
		);
	}

	/** One scan of all members: stage per member. Cached for 10 minutes. */
	public static function scan( $fresh = false ) {
		$c = get_transient( 'mrsh_ph_scan' );
		if ( ! $fresh && is_array( $c ) ) {
			return $c;
		}
		$out = array();
		$ids = get_users( array( 'fields' => 'ID', 'number' => 3000, 'orderby' => 'registered', 'order' => 'DESC' ) );
		foreach ( $ids as $id ) {
			$u  = get_userdata( $id );
			$st = MRSH_Coach::stage( $u );
			$out[ (int) $id ] = array( 's' => $st['stage'], 'r' => strtotime( $u->user_registered . ' UTC' ) );
		}
		set_transient( 'mrsh_ph_scan', $out, 10 * MINUTE_IN_SECONDS );
		return $out;
	}

	private static function pill( $text, $cls = '' ) {
		return '<span class="mx-pill ' . esc_attr( $cls ) . '">' . esc_html( $text ) . '</span>';
	}

	private static function form_btn( $op, $label, $cls = '', $extra = '', $confirm = '' ) {
		return '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline"' . ( $confirm ? ' onsubmit="return confirm(' . esc_attr( wp_json_encode( $confirm ) ) . ')"' : '' ) . '><input type="hidden" name="action" value="mrsh_ph_do"><input type="hidden" name="op" value="' . esc_attr( $op ) . '">' . wp_nonce_field( 'mrsh_ph_do', '_wpnonce', true, false ) . $extra . '<button class="mx-btn ' . esc_attr( $cls ) . '" type="submit">' . esc_html( $label ) . '</button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	/* ---------- the page ---------- */

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$o     = MRSH_Helper::get();
		$c     = MRSH_Helper::counters();
		$scan  = self::scan( ! empty( $_GET['fresh'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$cnt   = array( 'A' => 0, 'B' => 0, 'C' => 0, 'D' => 0, 'X' => 0 );
		foreach ( $scan as $r ) {
			$cnt[ $r['s'] ]++;
		}
		$starts = MRSH_Helper::day_sum( 'starts', 7 );
		$saves  = MRSH_Helper::day_sum( 'saves', 7 );
		$speech = (int) ( $c['mode_speak'] ?? 0 );
		$modes  = $speech + (int) ( $c['mode_ques'] ?? 0 ) + (int) ( $c['mode_type'] ?? 0 );
		$voice  = $modes ? round( 100 * $speech / $modes ) : 0;
		$aiuse  = MRSH_AIHub::own_used( 'helper' );

		MRSH_Boost::ui_open( 'Profile Helper', 'Members speak or answer simple questions in Urdu and the profile form fills itself. A coach sends short, kind reminders. Everything here has a manual button.', 'g-gold', 'M12 14a3 3 0 0 0 3-3V5a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3zm5-3a5 5 0 0 1-10 0H5a7 7 0 0 0 6 6.9V21h2v-3.1A7 7 0 0 0 19 11z' );
		echo '<style>.mx .ph-tbl{width:100%;border-collapse:collapse}.mx .ph-tbl td,.mx .ph-tbl th{padding:9px 8px;border-top:1px solid #eef0f6;text-align:left;font-size:13.5px;vertical-align:top}.mx textarea.ph{width:100%;min-height:64px;border-radius:12px;border:1px solid #d9dbe8;padding:10px 12px;font-size:14px}.mx .ph-two{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:16px}.mx .ph-pre{background:#f5f3ff;border-radius:16px;padding:14px 16px;font-size:16px;line-height:2;direction:rtl;text-align:right;box-shadow:inset 0 0 0 1px #e9d5ff}.mx .ph-fun{display:grid;grid-template-columns:150px 1fr 60px;gap:10px;align-items:center;margin:6px 0;font-size:13.5px}.mx .ph-sw{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:14px}</style>';
		if ( isset( $_GET['msg'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			MRSH_Boost::ui_ok( sanitize_text_field( wp_unslash( $_GET['msg'] ) ) );
		}

		// hero badges and quick buttons
		echo '<div class="mx-card"><div class="mx-acts">';
		echo self::pill( 'Helper: ' . ( 'all' === $o['who'] ? 'on for everyone' : ( 'admins' === $o['who'] ? 'admins only (preview)' : 'off' ) ), 'all' === $o['who'] ? 'ok' : ( 'admins' === $o['who'] ? 'warn' : 'bad' ) ); // phpcs:ignore
		echo self::pill( 'Coach: ' . ( $o['paused'] ? 'paused' : ( $o['coach'] ? ( MRSH_Coach::live() ? 'running' : 'waiting for helper on for everyone' ) : 'off' ) ), $o['paused'] || ! $o['coach'] ? 'bad' : ( MRSH_Coach::live() ? 'ok' : 'warn' ) ); // phpcs:ignore
		echo self::pill( 'AI: ' . ( MRSH_AIHub::ready() ? 'ready' : 'no key' ), MRSH_AIHub::ready() ? 'ok' : 'bad' ); // phpcs:ignore
		echo self::pill( 'Old step wizard: ' . ( $o['wiz'] ? 'kept as fallback' : 'off' ), $o['wiz'] ? 'ok' : 'warn' ); // phpcs:ignore
		echo '</div><div class="mx-acts" style="margin-top:14px">';
		echo '<a class="mx-btn p" target="_blank" rel="noopener" href="' . esc_url( add_query_arg( array( 'helper' => 1, 'preview' => 1 ), home_url( '/add-listing/' ) ) ) . '">Open helper as a member (saves nothing)</a>';
		echo self::form_btn( 'test_mail', 'Send test email to me' ); // phpcs:ignore
		echo self::form_btn( 'run', 'Run coach now', '', '', 'Send the reminders that are due right now?' ); // phpcs:ignore
		echo $o['paused'] ? self::form_btn( 'resume', 'Resume coach' ) : self::form_btn( 'pause', 'Pause coach', 'd' ); // phpcs:ignore
		echo '<a class="mx-btn" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_ph_csv' ), 'mrsh_ph_csv' ) ) . '">Export funnel as CSV</a>';
		echo '<a class="mx-btn" href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG . '&fresh=1' ) ) . '">Refresh numbers</a>';
		echo '</div></div>';

		// six tiles
		echo '<div class="mx-stats">'
			. MRSH_Boost::ui_stat( $cnt['A'], 'Members with no profile', '#e11d48' ) // phpcs:ignore
			. MRSH_Boost::ui_stat( $cnt['B'], 'Unfinished profiles', '#f59e0b' )
			. MRSH_Boost::ui_stat( $starts, 'Started the helper (7 days)', '#4a69d6' )
			. MRSH_Boost::ui_stat( $saves, 'Saved with the helper (7 days)', '#139a86' )
			. MRSH_Boost::ui_stat( $voice . '%', 'Chose voice', '#7c3aed' )
			. MRSH_Boost::ui_stat( $aiuse . ' / ' . (int) $o['budget'], 'AI calls today', '#0ea5e9' )
			. '</div>';

		// funnel
		echo '<div class="mx-card"><div class="mx-h"><h2>Where members stop</h2></div><p class="mx-sub">How many members reached each screen (each member counted once).</p>';
		$max = max( 1, (int) ( $c['scr_start'] ?? 0 ) );
		foreach ( self::funnel_steps() as $k => $l ) {
			$n = (int) ( $c[ 'scr_' . $k ] ?? 0 );
			echo '<div class="ph-fun"><span>' . esc_html( $l ) . '</span><div class="mx-bar"><i style="width:' . (int) min( 100, round( 100 * $n / $max ) ) . '%"></i></div><b>' . (int) $n . '</b></div>';
		}
		$new = 0;
		$old = 0;
		$ids = array_keys( $scan );
		foreach ( $ids as $i => $id ) {
			if ( 'A' === $scan[ $id ]['s'] ) {
				$i < 155 ? $new++ : $old++;
			}
		}
		echo '<p class="mx-note">Sign-up date comparison, members with no profile: <b>' . (int) $new . '</b> of the newest 155 sign-ups, <b>' . (int) $old . '</b> of the earlier ones.</p></div>';

		// switches
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_ph_save">' . wp_nonce_field( 'mrsh_ph_save', '_wpnonce', true, false ); // phpcs:ignore
		echo '<div class="mx-card"><div class="mx-h"><h2>Switches</h2></div><p class="mx-sub">Rollback in one step: set "Who sees the helper" to Nobody. The old form is then shown to everyone.</p>';
		echo '<div class="mx-f" style="max-width:340px;margin-bottom:16px"><label class="t">Who sees the helper</label><select name="who">';
		foreach ( array( 'nobody' => 'Nobody', 'admins' => 'Admins only (preview)', 'all' => 'Everyone' ) as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $o['who'], $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select></div><div class="ph-sw">';
		$sw = array(
			'speak' => 'Speak (voice)', 'ques' => 'Questions mode', 'type' => 'Typing', 'hands' => 'Hands-free questions', 'stt' => 'Server speech fallback',
			'ai' => 'AI filling', 'paid' => 'Use the paid AI when no free one answers', 'coach' => 'Coach emails', 'announce' => 'One-time announcement', 'banner' => 'In-site banner', 'push' => 'Web push', 'wiz' => 'Keep the old step wizard (fallback)',
		);
		foreach ( $sw as $k => $l ) {
			echo '<label class="mx-sw"><input type="checkbox" name="sw_' . esc_attr( $k ) . '" value="1"' . checked( ! empty( $o[ $k ] ), true, false ) . '><span class="tr"></span><span class="lb">' . esc_html( $l ) . '</span></label>';
		}
		echo '</div><div class="mx-grid" style="margin-top:18px">';
		$num = array( 'quiet_from' => 'Quiet hours start (Pakistan hour)', 'quiet_to' => 'Quiet hours end (Pakistan hour)', 'gap_h' => 'Hours between messages', 'life' => 'Most messages per member', 'budget' => 'AI calls per day (helper budget)' );
		foreach ( $num as $k => $l ) {
			echo '<div class="mx-f"><label class="t">' . esc_html( $l ) . '</label><input type="number" name="' . esc_attr( $k ) . '" value="' . (int) $o[ $k ] . '"></div>';
		}
		echo '</div></div>';

		// strings
		echo '<div class="mx-card"><div class="mx-h"><h2>Helper wording (Urdu)</h2></div><p class="mx-sub">Every sentence the member sees. Leave a box as it is to keep the standard wording; clear it to restore it.</p><details><summary class="mx-btn s">Show all sentences</summary><div style="margin-top:12px">';
		$cur = MRSH_Helper::strings();
		foreach ( MRSH_Helper::default_strings() as $k => $v ) {
			echo '<div class="mx-f" style="margin-bottom:10px"><label class="t">' . esc_html( $k ) . '</label><textarea class="ph" dir="rtl" name="str[' . esc_attr( $k ) . ']">' . esc_textarea( $cur[ $k ] ) . '</textarea></div>';
		}
		echo '</div></details></div>';
		echo '<div class="mx-card"><div class="mx-acts"><button class="mx-btn p" type="submit">Save</button></div></div></form>';

		// AI and speech
		$ch   = MRSH_AIHub::chain();
		$errs = get_option( 'mrsh_aihub_err', array() );
		$errs = is_array( $errs ) ? $errs : array();
		$use  = get_option( 'mrsh_aihub_use', array() );
		$prov = is_array( $use ) && ! empty( $use['p'] ) ? array_keys( $use['p'], max( $use['p'] ) ) : array();
		echo '<div class="mx-card"><div class="mx-h"><h2>AI and speech</h2></div><p class="mx-sub">The helper tries the free AI pool first, on its own daily budget. If none answers and the switch "Use the paid AI" is on, the paid account answers.</p><table class="ph-tbl"><tr><th>Service</th><th>State</th></tr>';
		$free = 0;
		foreach ( $ch as $id => $cfg ) {
			if ( 'main' === $id ) {
				echo '<tr><td>' . esc_html( $cfg['label'] ) . '</td><td>' . self::pill( ! empty( $o['paid'] ) ? 'paid account: last fallback' : 'paid account: not used by the helper', 'warn' ) . '</td></tr>'; // phpcs:ignore
				continue;
			}
			$free++;
			echo '<tr><td>' . esc_html( $cfg['label'] ) . '</td><td>' . ( isset( $errs[ $id ] ) ? self::pill( 'last error: ' . $errs[ $id ][1], 'bad' ) : self::pill( 'ok', 'ok' ) ) . ( in_array( $id, $prov, true ) ? ' ' . self::pill( 'most used today', 'ok' ) : '' ) . '</td></tr>'; // phpcs:ignore
		}
		if ( ! $free ) {
			echo '<tr><td colspan="2">' . self::pill( 'No free service has a key yet. Add one in AI Assistant.', 'bad' ) . '</td></tr>'; // phpcs:ignore
		}
		echo '</table><p class="mx-note">Calls today: ' . (int) $aiuse . ' of ' . (int) $o['budget'] . ' · Speech uploads today: ' . (int) MRSH_Helper::day_sum( 'stt', 1 ) . '</p><div class="mx-acts" style="margin-top:12px">'
			. self::form_btn( 'test_ai', 'Test AI now' ) . self::form_btn( 'test_stt', 'Test speech now' ) // phpcs:ignore
			. '<a class="mx-btn" href="' . esc_url( admin_url( 'admin.php?page=mrsh-ai-hub' ) ) . '">Open AI Assistant</a></div></div>';

		// news to subscribers
		$ns = MRSH_Coach::news_state();
		$left = count( MRSH_Coach::news_audience( 3000 ) );
		echo '<div class="mx-card"><div class="mx-h"><h2>News to subscribers</h2></div><p class="mx-sub">One email, "New: make your profile by speaking Urdu", to every member who has not left the newsletter. 40 an hour, never at night, stops by itself when everyone has it.</p><div class="mx-acts">'
			. self::pill( $ns['on'] ? 'sending' : ( $ns['started'] ? 'stopped or finished' : 'not started' ), $ns['on'] ? 'ok' : 'warn' ) . self::pill( (int) $ns['sent'] . ' sent' ) . self::pill( $left . ' still to get it' ) // phpcs:ignore
			. '</div><div class="mx-acts" style="margin-top:12px">' . self::form_btn( 'news_test', 'Send news test to me' )
			. ( $ns['on'] ? self::form_btn( 'news_stop', 'Stop sending', 'd' ) : self::form_btn( 'news_start', 'Start sending to subscribers', 'p', '', 'Send the news to ' . $left . ' member(s), 40 an hour?' ) ) . '</div></div>'; // phpcs:ignore
		// coach
		self::coach_card();

		// members
		self::members_card( $scan );

		// log and tickets
		self::log_card();

		echo '<div class="mx-card"><div class="mx-h"><h2>More</h2></div><div class="mx-acts">'
			. '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_ph_privacy">' . wp_nonce_field( 'mrsh_ph_privacy', '_wpnonce', true, false ) . '<button class="mx-btn" type="submit">Add the helper wording to the Privacy Policy</button></form>' // phpcs:ignore
			. self::form_btn( 'reset', 'Reset counters', 'd', '', 'Reset all helper and coach counters?' ) // phpcs:ignore
			. '<a class="mx-btn" href="' . esc_url( admin_url( 'admin.php?page=mrsh-nudge&old=1' ) ) . '">Old reminder settings</a></div><p class="mx-note">The old reminder robots stay on, but skip anyone the coach messaged in the last 36 hours. Turn them off once the coach has run one clean day.</p></div>';
		echo '</div>';
	}

	private static function coach_card() {
		$s   = MRSH_Coach::stats();
		$tpl = MRSH_Coach::tpl();
		$def = MRSH_Coach::default_tpl();
		echo '<div class="mx-card"><div class="mx-h"><h2>Coach</h2></div><p class="mx-sub">One robot, one calendar. Stage A (no profile): day 1, 3, 7, 14. Stage B (unfinished): 2 days after last activity, then every 5 days, up to 3. Stage C: email not confirmed. Stage D: nothing. Quiet hours and the 36-hour rule apply to every channel.</p>';
		echo '<table class="ph-tbl"><tr><th>Message</th><th>Sent</th><th>Opened</th><th>Saved</th><th></th></tr>';
		foreach ( $tpl as $k => $m ) {
			$v = $s[ $k ] ?? array( 0, 0, 0 );
			echo '<tr><td><b>' . esc_html( $k ) . '</b></td><td>' . (int) $v[0] . '</td><td>' . (int) $v[1] . '</td><td>' . (int) $v[2] . '</td><td>' . self::form_btn( 'test_mail', 'Send test to me', 's', '<input type="hidden" name="code" value="' . esc_attr( $k ) . '">' ) . '</td></tr>'; // phpcs:ignore
		}
		foreach ( array( 'banner', 'push-1' ) as $k ) {
			$v = $s[ $k ] ?? array( 0, 0, 0 );
			echo '<tr><td><b>' . esc_html( $k ) . '</b></td><td>' . (int) $v[0] . '</td><td>' . (int) $v[1] . '</td><td>' . (int) $v[2] . '</td><td></td></tr>';
		}
		echo '</table>';
		echo '<details style="margin-top:14px"><summary class="mx-btn s">Edit the messages</summary><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin-top:12px"><input type="hidden" name="action" value="mrsh_ph_do"><input type="hidden" name="op" value="tpl">' . wp_nonce_field( 'mrsh_ph_do', '_wpnonce', true, false ); // phpcs:ignore
		foreach ( $tpl as $k => $m ) {
			echo '<div class="ph-two" style="margin-bottom:16px"><div><b>' . esc_html( $k ) . '</b>';
			foreach ( array( 's' => 'Subject', 'b' => 'Message (Urdu)', 'e' => 'English line', 'btn' => 'Button' ) as $f => $l ) {
				echo '<label class="t" style="display:block;margin:8px 0 3px;font-size:12px;font-weight:600">' . esc_html( $l ) . '</label><textarea class="ph" style="min-height:' . ( 'b' === $f ? 90 : 40 ) . 'px" dir="' . ( 'e' === $f ? 'ltr' : 'rtl' ) . '" name="tpl[' . esc_attr( $k ) . '][' . esc_attr( $f ) . ']">' . esc_textarea( $m[ $f ] ) . '</textarea>';
			}
			echo '</div><div><label class="t" style="font-weight:600;font-size:12px">Preview (as the member sees it)</label><div class="ph-pre"><b>' . esc_html( strtr( $m['s'], array( '{missing}' => 'صاف تصویر', '{missing_en}' => 'a clear photo' ) ) ) . '</b><br>' . esc_html( strtr( $m['b'], array( '{missing}' => 'صاف تصویر', '{missing_en}' => 'a clear photo' ) ) ) . '<br><span style="display:inline-block;background:#7c3aed;color:#fff;border-radius:10px;padding:2px 16px;margin-top:6px">' . esc_html( $m['btn'] ) . '</span></div><p class="mx-note">{missing} is replaced by what the profile still lacks.</p></div></div>';
		}
		echo '<div class="mx-acts"><button class="mx-btn p" type="submit">Save messages</button></div></form>' . self::form_btn( 'tpl_reset', 'Back to the standard wording', 'd', '', 'Restore all messages?' ) . '</details></div>'; // phpcs:ignore
	}

	private static function members_card( $scan ) {
		echo '<div class="mx-card"><div class="mx-h"><h2>Members</h2></div><p class="mx-sub">Newest members who are not finished (stage A, B or C). Invite sends the right message now, ignoring the calendar but not the stop rules.</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_ph_bulk">' . wp_nonce_field( 'mrsh_ph_bulk', '_wpnonce', true, false ); // phpcs:ignore
		echo '<div class="mx-tbl"><table class="ph-tbl"><tr><th></th><th>Member</th><th>Stage</th><th>Last screen</th><th>Sent</th><th>Buttons</th></tr>';
		$n = 0;
		foreach ( $scan as $id => $r ) {
			if ( ! in_array( $r['s'], array( 'A', 'B', 'C' ), true ) ) {
				continue;
			}
			if ( ++$n > 40 ) {
				break;
			}
			$u    = get_userdata( $id );
			$stop = get_user_meta( $id, 'mrsh_coach_stop', true );
			$sent = (int) get_user_meta( $id, 'mrsh_coach_n', true );
			$last = (string) get_user_meta( $id, 'mrsh_ph_last', true );
			$cls  = array( 'A' => 'bad', 'B' => 'warn', 'C' => '' );
			echo '<tr><td><input type="checkbox" name="ids[]" value="' . (int) $id . '"></td><td>' . esc_html( $u->display_name ?: $u->user_login ) . '<br><small>#' . (int) $id . ' · ' . esc_html( wp_date( 'j M Y', $r['r'] ) ) . '</small></td><td>' . self::pill( $r['s'], $cls[ $r['s'] ] ) . ( $stop ? ' ' . self::pill( 'paused', 'bad' ) : '' ) . '</td><td>' . esc_html( $last ?: 'not started' ) . '</td><td>' . (int) $sent . '</td><td class="mx-acts">'; // phpcs:ignore
			$hid = '<input type="hidden" name="uid" value="' . (int) $id . '">';
			echo self::form_btn( 'invite', 'Invite now', 's', $hid ) . self::form_btn( $stop ? 'mresume' : 'mpause', $stop ? 'Resume' : 'Pause', 's', $hid ) . self::form_btn( 'mreset', 'Reset count', 's', $hid ); // phpcs:ignore
			echo '<a class="mx-btn s" target="_blank" rel="noopener" href="' . esc_url( add_query_arg( array( 'helper' => 1, 'preview' => 1 ), home_url( '/add-listing/' ) ) ) . '">Open as member</a></td></tr>';
		}
		if ( ! $n ) {
			echo '<tr><td colspan="6">Nobody is waiting.</td></tr>';
		}
		echo '</table></div><div class="mx-acts" style="margin-top:12px"><button class="mx-btn p" type="submit">Invite selected</button></div></form></div>';
	}

	private static function log_card() {
		$l   = get_option( MRSH_Helper::LOG, array() );
		$l   = is_array( $l ) ? array_reverse( $l ) : array();
		$tk  = array( 'ai_key' => 'AI key problem', 'ph_stt' => 'Speech failing', 'ph_ai' => 'AI filling failing', 'ph_bounce' => 'Many bounced emails' );
		$brief = "Please look at the Profile Helper on myrishta.pk (plugin myrishta-seo-helper, theme myrishta, no extra plugins). Last events:\n";
		foreach ( array_slice( $l, 0, 20 ) as $e ) {
			$brief .= wp_date( 'Y-m-d H:i', $e['t'] ) . ' ' . $e['k'] . ' ' . $e['m'] . "\n";
		}
		echo '<div class="mx-card"><div class="mx-h"><h2>Log and tickets</h2></div><p class="mx-sub">The last 50 events. Tickets open by themselves in Tickets: ' . esc_html( implode( ', ', $tk ) ) . '.</p>';
		echo '<div class="mx-acts" style="margin-bottom:10px"><button class="mx-btn s" type="button" onclick="var t=document.getElementById(\'ph-brief\');t.select();document.execCommand(\'copy\');this.textContent=\'Copied\'">Copy brief for Claude</button><a class="mx-btn s" href="' . esc_url( admin_url( 'admin.php?page=mrsh-tickets' ) ) . '">Open Tickets</a>' . self::form_btn( 'resetlog', 'Clear log', 's d' ) . '</div>'; // phpcs:ignore
		echo '<textarea id="ph-brief" class="ph" readonly style="position:absolute;left:-9999px">' . esc_textarea( $brief ) . '</textarea>';
		echo '<table class="ph-tbl">';
		foreach ( array_slice( $l, 0, 50 ) as $e ) {
			echo '<tr><td style="width:150px">' . esc_html( wp_date( 'j M H:i', $e['t'] ) ) . '</td><td style="width:90px">' . self::pill( $e['k'] ) . '</td><td>' . esc_html( $e['m'] ) . '</td></tr>'; // phpcs:ignore
		}
		if ( ! $l ) {
			echo '<tr><td>No events yet.</td></tr>';
		}
		echo '</table></div>';
	}
}

MRSH_HelperAdmin::init();
