<?php
/**
 * Lite mode for the installed phone app (3.101.275+).
 * When the site runs as the installed app (start link ?pwa=1, or the cookie mr_app that the page sets itself in app mode), the page is
 * sent without things an app user never needs and that slow a phone on a weak connection: Google Analytics / Ads / AdSense tags,
 * Ahrefs, Google One Tap, background page pre-loading (speculation rules), structured data and the "install the app" tiles.
 * Normal browser visitors and search engines are NOT touched. Lite pages are never stored in the public page cache.
 * Switch: "Lite installed app" in Feature switches (on by default).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Lite {

	public static function init() {
		add_action( 'template_redirect', array( __CLASS__, 'start' ), 0 );
		add_action( 'wp_head', array( __CLASS__, 'detect' ), 0 );
	}

	public static function is_app() {
		if ( is_admin() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || is_feed() || 'myrishta' !== get_template() ) {
			return false;
		}
		if ( class_exists( 'MRSH_Switch' ) && ! MRSH_Switch::on( 'applite' ) ) {
			return false;
		}
		return isset( $_GET['pwa'] ) || ( isset( $_COOKIE['mr_app'] ) && '1' === $_COOKIE['mr_app'] ); // phpcs:ignore
	}

	/** In the page: remember "I am the installed app" in a cookie (and forget it in a normal browser tab). */
	public static function detect() {
		if ( 'myrishta' !== get_template() || ( class_exists( 'MRSH_Switch' ) && ! MRSH_Switch::on( 'applite' ) ) ) {
			return;
		}
		echo '<script id="mrt-app-detect">(function(){try{var s=(window.matchMedia&&matchMedia("(display-mode: standalone)").matches)||navigator.standalone===true;var h=document.documentElement;if(s){h.className+=" mrapp";if(document.cookie.indexOf("mr_app=1")<0)document.cookie="mr_app=1;path=/;max-age=31536000;samesite=lax"}else if(document.cookie.indexOf("mr_app=1")>=0&&location.search.indexOf("pwa=1")<0){document.cookie="mr_app=;path=/;max-age=0;samesite=lax"}}catch(e){}})();</script>' . "\n";
	}

	public static function start() {
		if ( ! self::is_app() ) {
			return;
		}
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		header( 'X-LiteSpeed-Cache-Control: no-cache' );
		ob_start( array( __CLASS__, 'strip' ) );
	}

	public static function strip( $h ) {
		if ( ! is_string( $h ) || false === stripos( $h, '</html>' ) ) {
			return $h;
		}
		$bad = 'googletagmanager|google-analytics|gtag\(|googlesitekit|siwg|ahrefs|googlesyndication|doubleclick|accounts\.google\.com\/gsi|adtrafficquality|adsbygoogle|speculationrules|application\/ld\+json';
		$n   = preg_replace_callback(
			'#<script\b[^>]*>.*?</script>#is',
			function ( $m ) use ( $bad ) {
				return preg_match( '#' . $bad . '#i', $m[0] ) ? '' : $m[0];
			},
			$h
		);
		if ( is_string( $n ) ) {
			$h = $n;
		}
		$n = preg_replace( '#<link\b[^>]*(dns-prefetch|preconnect|prefetch|prerender)[^>]*(googletagmanager|googlesyndication|google-analytics|doubleclick|ahrefs)[^>]*>#i', '', $h );
		if ( is_string( $n ) ) {
			$h = $n;
		}
		$css = '<style id="mrt-lite">.mrapp #mrt-install,.mrapp .instsheet,.mrapp [href*="pwa=1"].feat,.mrapp .hero .pill,.mrapp .trust{display:none!important}</style>';
		return preg_replace( '#</head>#i', $css . '</head>', $h, 1 );
	}
}
MRSH_Lite::init();
