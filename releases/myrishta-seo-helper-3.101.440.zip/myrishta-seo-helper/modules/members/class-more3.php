<?php
/**
 * Redirects page (one switch for every old-address redirect, plus a plain list of what exists),
 * saved admin replies with copy buttons, and shortlist folders for members' favourites.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Mem_More3 {

	const FOLDERS = array( 'family' => 'Show family', 'maybe' => 'Maybe', 'top' => 'Top choice' );

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 29 );
		add_action( 'admin_post_mrsh_m3_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_mrsh_folder', array( __CLASS__, 'folder_post' ) );
		add_action( 'mrt_account_extra', array( __CLASS__, 'folders' ), 50 );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Redirects and replies', 'Redirects and replies', 'manage_options', 'mrsh-m3', array( __CLASS__, 'page' ) );
	}

	public static function page() {
		$on = '0' !== (string) get_option( 'mrsh_redirects', '1' );
		echo '<div class="wrap"><h1>Redirects and saved replies</h1>';
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success is-dismissible"><p>Saved.</p></div>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_m3_save">';
		wp_nonce_field( 'mrsh_m3_save' );
		echo '<h2>Old address redirects</h2><p><label><input type="checkbox" name="redir" value="1"' . checked( $on, true, false ) . '> <b>Redirect old addresses</b> (301)</label></p><p class="description">Turn this off if you do not want the website to redirect any page. The pages below then simply open as normal pages.</p>';
		echo '<table class="widefat striped" style="max-width:860px"><thead><tr><th>Address</th><th>Goes to</th><th>Controlled by the switch</th></tr></thead><tbody>';
		$rows = array(
			array( '/registration/, /login/, /forgot-password/, /profile/ (old form pages)', 'Add profile / login / lost password / My account, only if the old form plugin is not installed', 'Yes' ),
			array( '/privacy/ and /terms/', '/privacy-policy/ and /terms-and-conditions/', 'Yes' ),
			array( 'Old category and tag addresses', 'The matching category or tag, else /blog/', 'Yes' ),
			array( '/sitemap.xml, /sitemap_index.xml', '/wp-sitemap.xml (also needs the sitemap option in SEO settings)', 'Yes' ),
			array( '/app (no slash)', '/app/', 'No' ),
			array( 'www.domain/app/', 'domain/app/ (the app needs the main address)', 'No' ),
			array( '/?author=1 (when logged out)', 'Home page, so login names stay hidden', 'No' ),
			array( 'Logged-in members who must verify by WhatsApp or two-step', 'The verification page, only when you require verification', 'No' ),
			array( 'Google / Facebook login (to their sign-in page and back)', 'Needed for the login to work', 'No' ),
			array( 'After a form (contact, profile, coupon, proof, story)', 'Back to the same page with a message', 'No' ),
		);
		foreach ( $rows as $r ) {
			echo '<tr data-attn="0"><td>' . esc_html( $r[0] ) . '</td><td>' . esc_html( $r[1] ) . '</td><td>' . esc_html( $r[2] ) . '</td></tr>';
		}
		echo '</tbody></table><p class="description">The My Rishta theme does not redirect any public page. Pages such as /top-listings/, /categories/, /country-list/, /callback/ and /chatroom/ open directly with their own content.</p>';
		echo '<h2>Saved replies</h2><p class="description">Write one reply per line. Use the Copy button when you answer a member by email or WhatsApp.</p><textarea name="replies" rows="8" class="large-text">' . esc_textarea( (string) get_option( 'mrsh_replies', "Assalam o Alaikum, thank you for contacting My Rishta Pakistan. We will look into this today, InshaAllah.\nYour profile is live. Please add a clear photo and more details to get better matches.\nFor your safety please never send money to anyone you meet online. Report such profiles to us." ) ) . '</textarea><p><button class="button button-primary">Save</button></p></form>';
		$l = array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) get_option( 'mrsh_replies', '' ) ) ) );
		if ( $l ) {
			echo '<h3>Copy</h3>';
			foreach ( $l as $i => $t ) {
				echo '<p style="max-width:760px;background:#fff;border:1px solid #e3e3e8;border-radius:12px;padding:10px 14px"><span id="rp' . (int) $i . '">' . esc_html( $t ) . '</span><br><button type="button" class="button" onclick="navigator.clipboard.writeText(document.getElementById(\'rp' . (int) $i . '\').textContent);this.textContent=\'Copied\'">Copy</button></p>';
			}
		}
		echo '</div>';
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_m3_save' );
		update_option( 'mrsh_redirects', empty( $_POST['redir'] ) ? '0' : '1', false ); // phpcs:ignore
		update_option( 'mrsh_replies', sanitize_textarea_field( wp_unslash( $_POST['replies'] ?? '' ) ), false ); // phpcs:ignore
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-m3&ok=1' ) );
		exit;
	}

	/* ---------- shortlist folders ---------- */

	public static function folder_post() {
		$uid = get_current_user_id();
		$bk  = home_url( '/my-account/' );
		if ( ! $uid || ! check_admin_referer( 'mrsh_folder' ) ) {
			wp_safe_redirect( $bk );
			exit;
		}
		$fav = array_map( 'intval', (array) get_user_meta( $uid, 'favorite', true ) );
		$map = (array) get_user_meta( $uid, 'mrt_fav_folder', true );
		foreach ( (array) ( $_POST['f'] ?? array() ) as $pid => $f ) { // phpcs:ignore
			$pid = absint( $pid );
			$f   = sanitize_key( $f );
			if ( in_array( $pid, $fav, true ) ) {
				if ( isset( self::FOLDERS[ $f ] ) ) {
					$map[ $pid ] = $f;
				} else {
					unset( $map[ $pid ] );
				}
			}
		}
		update_user_meta( $uid, 'mrt_fav_folder', $map );
		wp_safe_redirect( add_query_arg( 'fold', 'ok', $bk ) . '#mrsh-folders' );
		exit;
	}

	public static function folders( $uid ) {
		if ( ! $uid ) {
			return;
		}
		$fav = array_values( array_filter( array_map( 'intval', (array) get_user_meta( $uid, 'favorite', true ) ) ) );
		if ( ! $fav ) {
			return;
		}
		$map  = (array) get_user_meta( $uid, 'mrt_fav_folder', true );
		$show = isset( $_GET['folder'] ) ? sanitize_key( $_GET['folder'] ) : ''; // phpcs:ignore
		echo '<div class="wrap narrow"><div class="box" id="mrsh-folders"><h3>My shortlist folders</h3>';
		if ( isset( $_GET['fold'] ) ) { // phpcs:ignore
			echo '<p class="note2">Saved.</p>';
		}
		echo '<p>';
		echo '<a class="chip' . ( '' === $show ? ' on' : '' ) . '" href="' . esc_url( remove_query_arg( 'folder' ) . '#mrsh-folders' ) . '">All (' . (int) count( $fav ) . ')</a> ';
		foreach ( self::FOLDERS as $k => $l ) {
			$n = count( array_filter( $fav, function ( $p ) use ( $map, $k ) { return ( $map[ $p ] ?? '' ) === $k; } ) );
			echo '<a class="chip' . ( $show === $k ? ' on' : '' ) . '" href="' . esc_url( add_query_arg( 'folder', $k ) . '#mrsh-folders' ) . '">' . esc_html( $l ) . ' (' . (int) $n . ')</a> ';
		}
		echo '</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_folder">' . wp_nonce_field( 'mrsh_folder', '_wpnonce', true, false ) . '<ul style="list-style:none;padding:0;margin:0">';
		foreach ( $fav as $pid ) {
			$p = get_post( $pid );
			if ( ! $p || 'publish' !== $p->post_status || ( $show && ( $map[ $pid ] ?? '' ) !== $show ) ) {
				continue;
			}
			echo '<li style="display:flex;gap:10px;align-items:center;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--line,#eee)"><a href="' . esc_url( get_permalink( $p ) ) . '">' . esc_html( get_the_title( $p ) ) . '</a><select name="f[' . (int) $pid . ']"><option value="">No folder</option>';
			foreach ( self::FOLDERS as $k => $l ) {
				echo '<option value="' . esc_attr( $k ) . '"' . selected( $map[ $pid ] ?? '', $k, false ) . '>' . esc_html( $l ) . '</option>';
			}
			echo '</select></li>';
		}
		echo '</ul><p><button class="btn">Save folders</button></p></form></div></div>';
	}
}
MRSH_Mem_More3::init();
