<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<style>
#mrg{--bg:#f7f6f9;--card:#fff;--fg:#1d1a26;--mut:#625d72;--line:#e5e1ec;--brand:#b4195f;--brand2:#7c3aed;--soft:#f6e8f0;--ok:#16794a;--warn:#a15c07;--warnbg:#fff4e0;--code:#f0edf5;--f-en:system-ui,-apple-system,"Segoe UI",sans-serif;--f-ur:"Noto Naskh Arabic","Jameel Noori Nastaleeq",serif;color:var(--fg);font-family:var(--f-en);line-height:1.6;font-size:15px;max-width:900px}
#mrg .bar{position:static}
#mrg header.top h1{font-size:1.9rem}
#mrg .wrap{max-width:860px;margin:0 auto}
#mrg header.top{padding:28px 0 10px}
#mrg header.top h1{font-size:clamp(1.6rem,5vw,2.3rem);line-height:1.2;margin:0 0 6px;text-wrap:balance;letter-spacing:-.02em}
#mrg header.top p{margin:0;color:var(--mut)}
#mrg header.top .ur{font-family:var(--f-ur);font-size:1.2rem;margin-top:6px}
#mrg .bar{position:sticky;top:env(safe-area-inset-top,0px);z-index:5;background:var(--bg);padding:10px 0;border-bottom:1px solid var(--line)}
#mrg .seg{display:inline-flex;border:1px solid var(--line);border-radius:12px;overflow:hidden;background:var(--card)}
#mrg .seg button{font:inherit;font-weight:600;border:0;background:transparent;color:var(--fg);padding:9px 18px;cursor:pointer;min-height:44px}
#mrg .seg button[aria-pressed="true"]{background:var(--brand);color:#fff}
#mrg .seg button:focus-visible,#mrg a:focus-visible,#mrg summary:focus-visible{outline:3px solid var(--brand2);outline-offset:2px}
#mrg .seg .u{font-family:var(--f-ur);font-size:1.05rem}
#mrg nav.toc{margin:18px 0;display:grid;grid-template-columns:repeat(auto-fill,minmax(230px,1fr));gap:8px}
#mrg nav.toc a{display:block;padding:10px 12px;border:1px solid var(--line);border-radius:10px;background:var(--card);color:var(--fg);text-decoration:none;font-weight:500;min-width:0}
#mrg nav.toc a:hover{border-color:var(--brand)}
#mrg nav.toc a span{display:block}
#mrg nav.toc a .u{font-family:var(--f-ur);color:var(--mut);font-size:1rem}
#mrg section.g{background:var(--card);border:1px solid var(--line);border-radius:16px;padding:20px;margin:16px 0;scroll-margin-top:80px}
#mrg section.g>h2{margin:0 0 4px;font-size:1.25rem;letter-spacing:-.01em;text-wrap:balance}
#mrg .path{display:inline-block;background:var(--soft);color:var(--brand);font-weight:600;font-size:.82rem;border-radius:99px;padding:3px 12px;margin:4px 0 10px}
#mrg .en,#mrg .ur{min-width:0}
#mrg .ur{direction:rtl;text-align:right;font-family:var(--f-ur);font-size:1.12rem;line-height:2}
#mrg .ur h2{font-family:var(--f-ur)}
#mrg .both .ur{border-top:1px dashed var(--line);margin-top:14px;padding-top:12px}
#mrg .mode-en .ur,#mrg .mode-ur .en{display:none}
#mrg ol,#mrg ul{padding-inline-start:1.3em;margin:8px 0}
#mrg li{margin:4px 0}
#mrg b{font-weight:600}
#mrg code,#mrg .k{background:var(--code);border-radius:6px;padding:1px 7px;font-size:.92em;font-family:ui-monospace,Menlo,Consolas,monospace;direction:ltr;unicode-bidi:embed}
#mrg .note{background:var(--warnbg);color:var(--fg);border-radius:10px;padding:10px 14px;margin:10px 0;border:1px solid color-mix(in srgb,var(--warn) 40%,transparent)}
#mrg .note b{color:var(--warn)}
#mrg .tip{background:var(--soft);border-radius:10px;padding:10px 14px;margin:10px 0}
#mrg table{border-collapse:collapse;width:100%}
#mrg .tw{overflow-x:auto;margin:10px 0}
#mrg th,#mrg td{border-bottom:1px solid var(--line);padding:8px 10px;text-align:start;vertical-align:top}
#mrg th{font-size:.8rem;text-transform:uppercase;letter-spacing:.06em;color:var(--mut)}
#mrg .ur th{text-transform:none;letter-spacing:0;font-size:.95rem}
#mrg footer{color:var(--mut);font-size:.85rem;margin-top:24px}
#mrg section.g{padding:16px}
#mrg .seg button{padding:9px 12px}
#mrg *{scroll-behavior:auto!important}
</style>
<div id="mrg">

<header class="top">
  <h1>My Rishta Admin Guide</h1>
  <p>How to run your rishta website day by day. Version 3.99 of the plugin and theme.</p>
  <p class="ur" dir="rtl">ویب سائٹ چلانے کی رہنمائی: ایڈمن کے لیے، اردو اور انگریزی میں۔</p>
</header>

<div class="bar">
  <div class="seg" role="group" aria-label="Language">
    <button type="button" data-m="both" aria-pressed="true">English + <span class="u">اردو</span></button>
    <button type="button" data-m="en" aria-pressed="false">English</button>
    <button type="button" data-m="ur" aria-pressed="false" class="u">اردو</button>
  </div>
</div>

<nav class="toc" aria-label="Contents">
  <a href="#start"><span>1. First time setup</span><span class="u">۱۔ پہلی بار سیٹ اپ</span></a>
  <a href="#daily"><span>2. Every day: Today page</span><span class="u">۲۔ روزانہ: آج کا صفحہ</span></a>
  <a href="#profiles"><span>3. Profiles and members</span><span class="u">۳۔ پروفائل اور ممبرز</span></a>
  <a href="#safety"><span>4. Quality and safety</span><span class="u">۴۔ معیار اور حفاظت</span></a>
  <a href="#brand"><span>5. Names, logo, colours</span><span class="u">۵۔ نام، لوگو، رنگ</span></a>
  <a href="#look"><span>6. Look and content</span><span class="u">۶۔ شکل اور مواد</span></a>
  <a href="#plans"><span>7. Plans and payment</span><span class="u">۷۔ پلان اور ادائیگی</span></a>
  <a href="#app"><span>8. Phone app and Urdu</span><span class="u">۸۔ موبائل ایپ اور اردو</span></a>
  <a href="#members"><span>9. What members can do</span><span class="u">۹۔ ممبرز کیا کر سکتے ہیں</span></a>
  <a href="#backup"><span>10. Backup and new host</span><span class="u">۱۰۔ بیک اپ اور نیا ہوسٹ</span></a>
  <a href="#fix"><span>11. If something goes wrong</span><span class="u">۱۱۔ مسئلہ ہو تو</span></a>
</nav>

<main id="main" class="both">

<section class="g" id="start">
  <div class="en"><h2>1. First time setup</h2><span class="path">Dashboard &gt; New installation</span>
    <ol>
      <li>Upload the plugin zip (Plugins &gt; Add New &gt; Upload) and activate it. Upload the theme zip (Appearance &gt; Themes &gt; Add New &gt; Upload) and activate it. Both zips must have the <b>same version number</b>.</li>
      <li>If you are moving from another host, restore your backup first.</li>
      <li>Open <b>New installation</b>. Each line is green when it is ready. Press <b>Set up my new site now</b>. It creates the profile form, dropdown lists, countries and cities, pages, main menu and web addresses. It never deletes anything.</li>
      <li>To bring your settings from the old site, import the settings file on the same page. Passwords and keys are not in that file; enter them again under <b>Site settings &gt; Website keys</b>.</li>
    </ol>
    <div class="tip">Do the steps on your test site first. Only then repeat them on the live site.</div></div>
  <div class="ur" dir="rtl"><h2>۱۔ پہلی بار سیٹ اپ</h2><span class="path">Dashboard &gt; New installation</span>
    <ol>
      <li>پلگ اِن کی زپ فائل اپ لوڈ کر کے ایکٹیویٹ کریں، پھر تھیم کی زپ فائل بھی اپ لوڈ کر کے ایکٹیویٹ کریں۔ دونوں فائلوں کا <b>ورژن نمبر ایک ہی</b> ہونا چاہیے۔</li>
      <li>اگر آپ نئے ہوسٹ پر جا رہے ہیں تو پہلے اپنا بیک اپ ریسٹور کریں۔</li>
      <li><b>New installation</b> کھولیں۔ جو لائن تیار ہو وہ سبز ہو جاتی ہے۔ <b>Set up my new site now</b> دبائیں۔ یہ پروفائل فارم، ڈراپ ڈاؤن فہرستیں، ممالک اور شہر، صفحات، مین مینو اور ویب ایڈریس بنا دیتا ہے۔ یہ کچھ بھی ڈیلیٹ نہیں کرتا۔</li>
      <li>پرانی سائٹ کی سیٹنگز لانے کے لیے اسی صفحے پر سیٹنگز فائل امپورٹ کریں۔ پاس ورڈ اور کیز اس فائل میں نہیں ہوتیں، انہیں <b>Site settings &gt; Website keys</b> میں دوبارہ لکھیں۔</li>
    </ol>
    <div class="tip">پہلے ٹیسٹ سائٹ پر یہ سب کر کے دیکھیں، پھر لائیو سائٹ پر کریں۔</div></div>
</section>

<section class="g" id="daily">
  <div class="en"><h2>2. Every day: the Today page</h2><span class="path">Dashboard &gt; Today</span>
    <p>Open this page once a day. It shows what needs you.</p>
    <ul>
      <li><b>Profiles to check:</b> new or reported profiles. Press <b>Approve</b>, <b>Approve and verify</b> (adds the verified badge), <b>Hide</b>, or <b>View</b>.</li>
      <li><b>Voice introductions:</b> listen, then approve or reject.</li>
      <li><b>Selfie and video checks:</b> the number waiting. Open <b>Growth &gt; Selfie and video checks</b> to review them.</li>
      <li><b>Quick reply:</b> type a short message. <code>{name}</code> becomes the member's name. You can send it by WhatsApp.</li>
    </ul>
    <div class="note"><b>Watch:</b> the safety rules can hold a good profile by mistake. If you see good profiles here, approve them and relax the rules (section 4).</div></div>
  <div class="ur" dir="rtl"><h2>۲۔ روزانہ: آج کا صفحہ</h2><span class="path">Dashboard &gt; Today</span>
    <p>دن میں ایک بار یہ صفحہ کھولیں۔ یہاں وہ سب کچھ ہے جس پر آپ کی توجہ چاہیے۔</p>
    <ul>
      <li><b>چیک کرنے والے پروفائل:</b> نئے یا رپورٹ شدہ پروفائل۔ <b>Approve</b> (منظور)، <b>Approve and verify</b> (منظور اور ویریفائیڈ بیج)، <b>Hide</b> (چھپائیں) یا <b>View</b> (دیکھیں) دبائیں۔</li>
      <li><b>آواز کا تعارف:</b> سنیں، پھر منظور یا رد کریں۔</li>
      <li><b>سیلفی اور ویڈیو چیک:</b> انتظار میں موجود تعداد۔ دیکھنے کے لیے <b>Growth &gt; Selfie and video checks</b> کھولیں۔</li>
      <li><b>فوری جواب:</b> مختصر پیغام لکھیں۔ <code>{name}</code> کی جگہ ممبر کا نام آ جاتا ہے۔ آپ اسے واٹس ایپ پر بھیج سکتے ہیں۔</li>
    </ul>
    <div class="note"><b>خیال رکھیں:</b> حفاظتی اصول کبھی کبھی اچھے پروفائل بھی روک لیتے ہیں۔ ایسا ہو تو انہیں منظور کریں اور اصول نرم کریں (حصہ ۴)۔</div></div>
</section>

<section class="g" id="profiles">
  <div class="en"><h2>3. Profiles and members</h2><span class="path">Members and matches</span>
    <div class="tw"><table><thead><tr><th>Page</th><th>Use it to</th></tr></thead><tbody>
      <tr><td>Overview</td><td>See totals and pending approvals.</td></tr>
      <tr><td>Profiles</td><td>Search, edit, approve, hide or delete profiles. Select several and use the <b>Bulk actions</b> menu (approve, verify, hide).</td></tr>
      <tr><td>Members</td><td>Ban a member, see last seen, set the membership plan.</td></tr>
      <tr><td>Messages</td><td>Read reported conversations.</td></tr>
      <tr><td>Match Desk</td><td>Suggest matches by hand and mark a match as <b>matched</b>.</td></tr>
      <tr><td>Photo safety</td><td>Check photos that may break the rules.</td></tr>
      <tr><td>Profile reminders</td><td>Nudge members who have not finished their profile.</td></tr>
    </tbody></table></div>
    <div class="tip">You can give a helper the role <b>Moderator</b> (Users &gt; edit user). A moderator can approve and hide profiles but cannot change settings.</div></div>
  <div class="ur" dir="rtl"><h2>۳۔ پروفائل اور ممبرز</h2><span class="path">Members and matches</span>
    <div class="tw"><table><thead><tr><th>صفحہ</th><th>کس کام کے لیے</th></tr></thead><tbody>
      <tr><td>Overview</td><td>کل تعداد اور منظوری کے منتظر پروفائل دیکھیں۔</td></tr>
      <tr><td>Profiles</td><td>پروفائل تلاش، ایڈٹ، منظور، چھپانا یا ڈیلیٹ کریں۔ کئی منتخب کر کے <b>Bulk actions</b> سے ایک ساتھ منظور، ویریفائی یا چھپائیں۔</td></tr>
      <tr><td>Members</td><td>ممبر بین کریں، آخری بار آن لائن دیکھیں، ممبرشپ پلان سیٹ کریں۔</td></tr>
      <tr><td>Messages</td><td>رپورٹ شدہ گفتگو پڑھیں۔</td></tr>
      <tr><td>Match Desk</td><td>ہاتھ سے رشتے تجویز کریں اور رشتہ طے ہونے پر <b>matched</b> لکھیں۔</td></tr>
      <tr><td>Photo safety</td><td>اصول توڑنے والی ممکنہ تصاویر دیکھیں۔</td></tr>
      <tr><td>Profile reminders</td><td>ادھورا پروفائل رکھنے والوں کو یاد دہانی بھیجیں۔</td></tr>
    </tbody></table></div>
    <div class="tip">مددگار کو <b>Moderator</b> کا رول دیں (Users &gt; edit user)۔ موڈریٹر پروفائل منظور اور چھپا سکتا ہے مگر سیٹنگز نہیں بدل سکتا۔</div></div>
</section>

<section class="g" id="safety">
  <div class="en"><h2>4. Quality and safety</h2><span class="path">Members and matches &gt; Quality and safety</span>
    <ul>
      <li><b>Rules:</b> choose what holds a profile for checking (phone numbers or links in the text, bad words, reports). Edit the word list here.</li>
      <li><b>Duplicates:</b> finds profiles with the same name or phone number.</li>
      <li><b>Matched tracker:</b> list of rishtas that were made through the site.</li>
      <li><b>Export settings:</b> downloads all your settings in one file (without keys). Keep a copy after every big change.</li>
      <li><b>Urdu check:</b> opens a page where untranslated English words are listed so you can report them.</li>
    </ul>
    <div class="note"><b>Privacy:</b> phone numbers are never shown on public pages. Members see them only where the site allows it.</div></div>
  <div class="ur" dir="rtl"><h2>۴۔ معیار اور حفاظت</h2><span class="path">Members and matches &gt; Quality and safety</span>
    <ul>
      <li><b>اصول:</b> طے کریں کہ کون سا پروفائل چیک کے لیے روکا جائے (متن میں فون نمبر یا لنک، نامناسب الفاظ، رپورٹس)۔ الفاظ کی فہرست بھی یہیں بدلیں۔</li>
      <li><b>ڈپلیکیٹ:</b> ایک جیسے نام یا فون نمبر والے پروفائل ڈھونڈتا ہے۔</li>
      <li><b>طے شدہ رشتے:</b> سائٹ کے ذریعے بننے والے رشتوں کی فہرست۔</li>
      <li><b>Export settings:</b> آپ کی تمام سیٹنگز ایک فائل میں ڈاؤن لوڈ ہوتی ہیں (کیز کے بغیر)۔ ہر بڑی تبدیلی کے بعد ایک کاپی رکھیں۔</li>
      <li><b>اردو چیک:</b> ایک صفحہ کھلتا ہے جس میں بغیر ترجمہ انگریزی الفاظ دکھائے جاتے ہیں تاکہ آپ بتا سکیں۔</li>
    </ul>
    <div class="note"><b>پرائیویسی:</b> فون نمبر عوامی صفحات پر کبھی نہیں دکھائے جاتے۔</div></div>
</section>

<section class="g" id="brand">
  <div class="en"><h2>5. Names, logo and colours</h2><span class="path">Site settings &gt; Brand and names</span>
    <p>This page lets the same plugin run any website.</p>
    <ul>
      <li>Set the <b>full name</b>, <b>short name</b>, <b>domain</b> and <b>e-mail</b>. The old names are replaced on every page, in e-mails and in the phone app.</li>
      <li>Add your own words in the box, one per line, like <code>rishta =&gt; nikah</code>. With <b>Match capital and small letters</b> ticked, "Rishta" and "RISHTA" change too.</li>
      <li>Choose a <b>logo</b> from the Media Library, the <b>main</b> and <b>second colour</b>, phone, WhatsApp, e-mail and address.</li>
      <li>Use <b>Try it</b> at the bottom to see the result before you save.</li>
    </ul>
    <div class="tip">Urdu translations are separate. If you use the plugin for another country or language, translate the new words yourself.</div></div>
  <div class="ur" dir="rtl"><h2>۵۔ نام، لوگو اور رنگ</h2><span class="path">Site settings &gt; Brand and names</span>
    <p>اس صفحے کی وجہ سے ایک ہی پلگ اِن کسی بھی ویب سائٹ کے لیے چل سکتا ہے۔</p>
    <ul>
      <li><b>پورا نام</b>، <b>مختصر نام</b>، <b>ڈومین</b> اور <b>ای میل</b> لکھیں۔ پرانے نام ہر صفحے، ای میل اور موبائل ایپ میں بدل جاتے ہیں۔</li>
      <li>ڈبے میں اپنے الفاظ ایک ایک لائن میں لکھیں، جیسے <code>rishta =&gt; nikah</code>۔ <b>Match capital and small letters</b> پر نشان ہو تو "Rishta" اور "RISHTA" بھی بدل جاتے ہیں۔</li>
      <li>میڈیا لائبریری سے <b>لوگو</b> چنیں، <b>مرکزی</b> اور <b>دوسرا رنگ</b>، فون، واٹس ایپ، ای میل اور پتہ لکھیں۔</li>
      <li>محفوظ کرنے سے پہلے نیچے <b>Try it</b> سے نتیجہ دیکھ لیں۔</li>
    </ul>
    <div class="tip">اردو ترجمے الگ ہیں۔ کسی اور ملک یا زبان کے لیے استعمال کریں تو نئے الفاظ کا ترجمہ خود لکھیں۔</div></div>
</section>

<section class="g" id="look">
  <div class="en"><h2>6. Look and content</h2><span class="path">Design &gt; Look and content, Theme Options</span>
    <ul>
      <li><b>Design tab:</b> site name beside the logo, profiles per row on computer (3 to 6, four looks best), profiles per page, announcement bar.</li>
      <li><b>Home tab:</b> main title and text, and which sections show (search, stats, featured, brides, grooms, how it works, plans, stories, FAQ).</li>
      <li><b>Footer tab:</b> phone, e-mail, address, social links and the about text.</li>
      <li><b>Content tab:</b> success stories, FAQ and the "How to pay" message.</li>
      <li><b>Theme Options:</b> fonts, more colours and layout. <b>Photos:</b> image size and speed. <b>Import content:</b> copy pages and posts from another site.</li>
    </ul>
    <div class="tip">A photo is hidden if the member chose a private photo. The card then shows <b>Private photo</b> and a <b>Request photo</b> button.</div></div>
  <div class="ur" dir="rtl"><h2>۶۔ شکل اور مواد</h2><span class="path">Design &gt; Look and content, Theme Options</span>
    <ul>
      <li><b>Design ٹیب:</b> لوگو کے ساتھ سائٹ کا نام، کمپیوٹر پر ایک قطار میں پروفائل (۳ سے ۶، چار بہتر ہے)، ایک صفحے پر پروفائل، اعلان کی پٹی۔</li>
      <li><b>Home ٹیب:</b> مرکزی عنوان اور متن، اور کون سے حصے دکھانے ہیں (تلاش، اعداد، نمایاں، دلہنیں، دولہے، طریقہ، پلان، کہانیاں، سوالات)۔</li>
      <li><b>Footer ٹیب:</b> فون، ای میل، پتہ، سوشل لنک اور تعارفی متن۔</li>
      <li><b>Content ٹیب:</b> کامیابی کی کہانیاں، سوالات اور "ادائیگی کا طریقہ" کا پیغام۔</li>
      <li><b>Theme Options:</b> فونٹ، مزید رنگ اور ترتیب۔ <b>Photos:</b> تصویر کا سائز اور رفتار۔ <b>Import content:</b> دوسری سائٹ سے صفحات اور پوسٹس کاپی کریں۔</li>
    </ul>
    <div class="tip">اگر ممبر نے تصویر نجی رکھی ہو تو کارڈ پر <b>Private photo</b> اور <b>Request photo</b> کا بٹن آتا ہے۔</div></div>
</section>

<section class="g" id="plans">
  <div class="en"><h2>7. Plans and payment</h2><span class="path">Site settings &gt; Membership plans, Online payment</span>
    <ol>
      <li><b>Membership plans:</b> change each plan's name, price, features and colour. Tick <b>Make everything free</b> to show "Free" on all plans. Pick which plan gets the "Most popular" ribbon.</li>
      <li><b>Online payment:</b> create a payment link in your Easypaisa, JazzCash or Google Pay / card gateway account, paste it here (it must start with <code>https://</code>) and tick the box. Buttons "Pay with ..." appear on paid plans.</li>
      <li>The member pays on the gateway page. The money goes to your own account. Then they send a screenshot from <b>My account</b>.</li>
      <li>Open <b>Growth &gt; Payment proofs</b>, check the screenshot against your gateway account, then set the plan in <b>Members</b> and press <b>Done</b>.</li>
    </ol>
    <div class="note"><b>Remember:</b> the plan does not change by itself after payment. You set it by hand after you see the money in your account.</div></div>
  <div class="ur" dir="rtl"><h2>۷۔ پلان اور ادائیگی</h2><span class="path">Site settings &gt; Membership plans, Online payment</span>
    <ol>
      <li><b>Membership plans:</b> ہر پلان کا نام، قیمت، سہولتیں اور رنگ بدلیں۔ تمام پلان مفت دکھانے کے لیے <b>Make everything free</b> پر نشان لگائیں۔ جس پلان پر "Most popular" کا ربن لگانا ہو اسے چنیں۔</li>
      <li><b>Online payment:</b> اپنے ایزی پیسہ، جاز کیش یا گوگل پے / کارڈ گیٹ وے اکاؤنٹ میں ادائیگی کا لنک بنائیں، یہاں پیسٹ کریں (لنک <code>https://</code> سے شروع ہو) اور خانے پر نشان لگائیں۔ پیڈ پلان پر "Pay with ..." کے بٹن آ جائیں گے۔</li>
      <li>ممبر گیٹ وے کے صفحے پر ادائیگی کرتا ہے۔ رقم سیدھی آپ کے اکاؤنٹ میں جاتی ہے۔ اس کے بعد وہ <b>My account</b> سے اسکرین شاٹ بھیجتا ہے۔</li>
      <li><b>Growth &gt; Payment proofs</b> کھولیں، اسکرین شاٹ کو اپنے گیٹ وے اکاؤنٹ سے ملائیں، پھر <b>Members</b> میں پلان سیٹ کریں اور <b>Done</b> دبائیں۔</li>
    </ol>
    <div class="note"><b>یاد رکھیں:</b> ادائیگی کے بعد پلان خود نہیں بدلتا۔ رقم اپنے اکاؤنٹ میں دیکھ کر آپ خود پلان سیٹ کرتے ہیں۔</div></div>
</section>

<section class="g" id="app">
  <div class="en"><h2>8. Phone app and Urdu</h2><span class="path">Design &gt; Theme and app</span>
    <ul>
      <li>The app opens at <code>yoursite/app/</code>. Members tap <b>Add to Home screen</b> in the browser to install it.</li>
      <li>The app and website show <b>Urdu by default</b> for phones set to Urdu and for the installed app. Anyone can switch with the language button, or open <code>?lang=ur</code> or <code>?lang=en</code> after the address.</li>
      <li>Admin pages for the app: <b>Site settings &gt; Notifications</b> (push messages) and <b>Ads and app promotion</b>.</li>
      <li>If an English word is left in Urdu mode, use the <b>Urdu check</b> button in Quality and safety and send me the list.</li>
    </ul></div>
  <div class="ur" dir="rtl"><h2>۸۔ موبائل ایپ اور اردو</h2><span class="path">Design &gt; Theme and app</span>
    <ul>
      <li>ایپ <code>yoursite/app/</code> پر کھلتی ہے۔ ممبرز براؤزر میں <b>Add to Home screen</b> دبا کر اسے انسٹال کرتے ہیں۔</li>
      <li>جن فونز کی زبان اردو ہو اور انسٹال شدہ ایپ میں سائٹ <b>پہلے سے اردو</b> میں کھلتی ہے۔ کوئی بھی زبان کے بٹن سے بدل سکتا ہے، یا ایڈریس کے بعد <code>?lang=ur</code> یا <code>?lang=en</code> لکھ سکتا ہے۔</li>
      <li>ایپ کے ایڈمن صفحات: <b>Site settings &gt; Notifications</b> (پش پیغامات) اور <b>Ads and app promotion</b>۔</li>
      <li>اردو میں کوئی انگریزی لفظ رہ جائے تو Quality and safety میں <b>Urdu check</b> بٹن دبائیں اور فہرست مجھے بھیجیں۔</li>
    </ul></div>
</section>

<section class="g" id="members">
  <div class="en"><h2>9. What members can do</h2><span class="path">Useful to know when you answer questions</span>
    <ul>
      <li>Create a free profile, add their own caste and city or village, upload photos, and a short voice introduction.</li>
      <li>Send interest and messages. Phone numbers and links are blocked in messages.</li>
      <li>Choose who sees their photos: everyone, verified members only, or accepted members only.</li>
      <li>Set quiet hours for notifications, and see a profile strength meter on My account.</li>
      <li>Share a <b>family view</b> link so parents can vote on a profile, and print a single profile as a card.</li>
      <li>Ask for a photo with <b>Request photo</b> when a profile has none or keeps it private.</li>
    </ul></div>
  <div class="ur" dir="rtl"><h2>۹۔ ممبرز کیا کر سکتے ہیں</h2><span class="path">سوالات کے جواب دیتے وقت کام آئے گا</span>
    <ul>
      <li>مفت پروفائل بنائیں، اپنی ذات اور شہر یا گاؤں خود لکھیں، تصاویر اور مختصر آواز کا تعارف شامل کریں۔</li>
      <li>دلچسپی اور پیغام بھیجیں۔ پیغامات میں فون نمبر اور لنک بند ہیں۔</li>
      <li>تصاویر کون دیکھے: سب، صرف ویریفائیڈ ممبرز، یا صرف قبول شدہ ممبرز۔</li>
      <li>اطلاعات کے لیے خاموش اوقات مقرر کریں، اور My account پر پروفائل کی مضبوطی کا میٹر دیکھیں۔</li>
      <li><b>فیملی ویو</b> لنک شیئر کریں تاکہ والدین پروفائل پر رائے دیں، اور ایک پروفائل کا کارڈ پرنٹ کریں۔</li>
      <li>جس پروفائل میں تصویر نہ ہو یا نجی ہو اس پر <b>Request photo</b> سے تصویر مانگیں۔</li>
    </ul></div>
</section>

<section class="g" id="backup">
  <div class="en"><h2>10. Backup and a new host</h2><span class="path">Dashboard &gt; Backup and restore</span>
    <ol>
      <li>Make a backup of the whole site each week and keep a copy on your computer. Also use <b>Export settings</b>.</li>
      <li>To move: install WordPress on the new host, install the plugin and theme, restore the backup, open <b>New installation</b>, press the button, import the settings file, then enter your keys again.</li>
      <li>Check every line on <b>New installation</b> is green and open the home page, a profile, My account and the app.</li>
    </ol></div>
  <div class="ur" dir="rtl"><h2>۱۰۔ بیک اپ اور نیا ہوسٹ</h2><span class="path">Dashboard &gt; Backup and restore</span>
    <ol>
      <li>ہر ہفتے پوری سائٹ کا بیک اپ بنائیں اور ایک کاپی اپنے کمپیوٹر میں رکھیں۔ <b>Export settings</b> بھی استعمال کریں۔</li>
      <li>منتقل کرنے کے لیے: نئے ہوسٹ پر WordPress انسٹال کریں، پلگ اِن اور تھیم انسٹال کریں، بیک اپ ریسٹور کریں، <b>New installation</b> کھول کر بٹن دبائیں، سیٹنگز فائل امپورٹ کریں، پھر اپنی کیز دوبارہ لکھیں۔</li>
      <li>دیکھ لیں کہ <b>New installation</b> کی ہر لائن سبز ہے، اور ہوم پیج، ایک پروفائل، My account اور ایپ کھول کر چیک کریں۔</li>
    </ol></div>
</section>

<section class="g" id="fix">
  <div class="en"><h2>11. If something goes wrong</h2>
    <div class="tw"><table><thead><tr><th>Problem</th><th>What to do</th></tr></thead><tbody>
      <tr><td>"Critical error" after installing</td><td>Using FTP or the host's File Manager, rename the folder <code>wp-content/plugins/myrishta-seo-helper</code> to anything else. The site opens again. Then send me the error text from the admin e-mail.</td></tr>
      <tr><td>"No valid plugins were found"</td><td>You uploaded the wrong zip. The plugin zip contains one folder <code>myrishta-seo-helper</code>; the theme zip contains <code>myrishta</code>.</td></tr>
      <tr><td>Photos not showing</td><td>Open <b>Design &gt; Photos</b>, check the photo address, and make sure the files exist in <code>wp-content/uploads</code>.</td></tr>
      <tr><td>Profile form is empty</td><td>Open <b>New installation</b> and press the button.</td></tr>
      <tr><td>Changes do not show</td><td>Clear the cache plugin or host cache, then refresh the phone app.</td></tr>
      <tr><td>Good profiles are held back</td><td>Relax the rules in <b>Quality and safety</b>.</td></tr>
    </tbody></table></div>
    <div class="note"><b>Always</b> test a new version on the test site first and keep a backup before you update the live site.</div></div>
  <div class="ur" dir="rtl"><h2>۱۱۔ اگر کچھ خراب ہو جائے</h2>
    <div class="tw"><table><thead><tr><th>مسئلہ</th><th>کیا کریں</th></tr></thead><tbody>
      <tr><td>انسٹال کے بعد "Critical error"</td><td>FTP یا ہوسٹ کے فائل مینیجر میں فولڈر <code>wp-content/plugins/myrishta-seo-helper</code> کا نام بدل دیں۔ سائٹ دوبارہ کھل جائے گی۔ پھر ایڈمن ای میل میں آنے والی غلطی کا متن مجھے بھیجیں۔</td></tr>
      <tr><td>"No valid plugins were found"</td><td>غلط زپ اپ لوڈ ہوئی۔ پلگ اِن کی زپ میں ایک فولڈر <code>myrishta-seo-helper</code> ہوتا ہے، تھیم کی زپ میں <code>myrishta</code>۔</td></tr>
      <tr><td>تصاویر نظر نہیں آ رہیں</td><td><b>Design &gt; Photos</b> کھولیں، تصویر کا ایڈریس دیکھیں، اور تسلی کریں کہ فائلیں <code>wp-content/uploads</code> میں موجود ہیں۔</td></tr>
      <tr><td>پروفائل فارم خالی ہے</td><td><b>New installation</b> کھول کر بٹن دبائیں۔</td></tr>
      <tr><td>تبدیلی نظر نہیں آتی</td><td>کیش پلگ اِن یا ہوسٹ کیش صاف کریں، پھر موبائل ایپ ریفریش کریں۔</td></tr>
      <tr><td>اچھے پروفائل روکے جا رہے ہیں</td><td><b>Quality and safety</b> میں اصول نرم کریں۔</td></tr>
    </tbody></table></div>
    <div class="note"><b>ہمیشہ</b> نیا ورژن پہلے ٹیسٹ سائٹ پر آزمائیں اور لائیو سائٹ اپ ڈیٹ کرنے سے پہلے بیک اپ رکھیں۔</div></div>
</section>

<footer>Menu names are shown in English exactly as they appear in your WordPress admin. Plugin and theme version 3.99.</footer>

</div>
<script>

(function(){
  var main=document.getElementById('main'),btns=document.querySelectorAll('.seg button');
  function set(m){
    main.className=m==='both'?'both':'mode-'+m;
    btns.forEach(function(b){b.setAttribute('aria-pressed',b.getAttribute('data-m')===m?'true':'false');});
    try{localStorage.setItem('mrg-lang',m);}catch(e){}
  }
  btns.forEach(function(b){b.addEventListener('click',function(){set(b.getAttribute('data-m'));});});
  var s=null;try{s=localStorage.getItem('mrg-lang');}catch(e){}
  if(s==='en'||s==='ur'||s==='both')set(s);
})();

</script>
