<?php
/**
 * Content import: copies blog posts, pages and their pictures from the live site into this site's own database
 * and uploads folder, so a backup of this site is complete and restores on any hosting without hotlinks.
 * Safe to run again: items already copied (same live ID) or with the same address are skipped.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Mem_Import {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 22 );
		add_action( 'wp_ajax_mrsh_import_batch', array( __CLASS__, 'batch' ) );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Import content', 'Import content', 'manage_options', 'mrsh-import', array( __CLASS__, 'page' ) );
	}

	private static function get( $host, $path ) {
		$r = wp_remote_get( 'https://' . $host . '/wp-json/wp/v2/' . $path, array( 'timeout' => 25 ) );
		if ( is_wp_error( $r ) || 200 !== (int) wp_remote_retrieve_response_code( $r ) ) {
			return null;
		}
		$d = json_decode( wp_remote_retrieve_body( $r ), true );
		return is_array( $d ) ? $d : null;
	}

	private static function image( $url, $post_id ) {
		if ( ! $url || 0 !== strpos( $url, 'http' ) ) {
			return 0;
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$id = media_sideload_image( esc_url_raw( $url ), $post_id, null, 'id' );
		return is_wp_error( $id ) ? 0 : (int) $id;
	}

	/** Copies one item. Returns 'new', 'skip' or 'fail'. */
	private static function copy( $host, $type, $it ) {
		global $wpdb;
		$src  = (int) $it['id'];
		$slug = sanitize_title( $it['slug'] );
		$dup  = $wpdb->get_var( $wpdb->prepare( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_mrsh_src_id' AND meta_value=%s LIMIT 1", $type . $src ) ); // phpcs:ignore WordPress.DB
		if ( $dup || get_page_by_path( $slug, OBJECT, $type ) ) {
			return 'skip';
		}
		$html = isset( $it['content']['rendered'] ) ? $it['content']['rendered'] : '';
		$id   = wp_insert_post( array(
			'post_type'    => $type,
			'post_status'  => 'publish',
			'post_title'   => wp_strip_all_tags( html_entity_decode( $it['title']['rendered'], ENT_QUOTES, 'UTF-8' ) ),
			'post_name'    => $slug,
			'post_content' => wp_kses_post( $html ),
			'post_excerpt' => wp_strip_all_tags( isset( $it['excerpt']['rendered'] ) ? $it['excerpt']['rendered'] : '' ),
			'post_date'    => isset( $it['date'] ) ? $it['date'] : current_time( 'mysql' ),
		), true );
		if ( is_wp_error( $id ) || ! $id ) {
			return 'fail';
		}
		update_post_meta( $id, '_mrsh_src_id', $type . $src );
		if ( 'post' === $type && ! empty( $it['categories'] ) ) {
			$names = array();
			foreach ( (array) $it['categories'] as $c ) {
				$t = self::get( $host, 'categories/' . (int) $c . '?_fields=name' );
				if ( $t && ! empty( $t['name'] ) ) {
					$names[] = wp_strip_all_tags( $t['name'] );
				}
			}
			if ( $names ) {
				wp_set_object_terms( $id, $names, 'category' );
			}
		}
		if ( ! empty( $it['featured_media'] ) ) {
			$m = self::get( $host, 'media/' . (int) $it['featured_media'] . '?_fields=source_url' );
			if ( $m && ! empty( $m['source_url'] ) ) {
				$a = self::image( $m['source_url'], $id );
				if ( $a ) {
					set_post_thumbnail( $id, $a );
				}
			}
		}
		return 'new';
	}

	public static function batch() {
		check_ajax_referer( 'mrsh_import' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'No permission' );
		}
		$host = MRSH_Mem_Photos::host();
		if ( ! $host ) {
			wp_send_json_error( 'No live site found. Set Photo host in Site settings.' );
		}
		@set_time_limit( 120 ); // phpcs:ignore
		$type = 'page' === ( $_POST['type'] ?? '' ) ? 'page' : 'post';
		$pg   = max( 1, (int) ( $_POST['pg'] ?? 1 ) );
		$list = self::get( $host, ( 'page' === $type ? 'pages' : 'posts' ) . '?per_page=5&page=' . $pg . '&_fields=id,slug,title,content,excerpt,date,categories,featured_media' );
		if ( null === $list ) {
			wp_send_json_success( array( 'done' => true, 'new' => 0, 'skip' => 0, 'fail' => 0 ) );
		}
		$c = array( 'new' => 0, 'skip' => 0, 'fail' => 0 );
		foreach ( $list as $it ) {
			$c[ self::copy( $host, $type, $it ) ]++;
		}
		$c['done'] = count( $list ) < 5;
		wp_send_json_success( $c );
	}

	public static function page() {
		$host = MRSH_Mem_Photos::host();
		$n    = wp_create_nonce( 'mrsh_import' );
		echo '<div class="wrap"><h1>Import content from the live site</h1>';
		if ( ! $host ) {
			echo '<p>No live site found. Set <b>Photo host</b> in Site settings first.</p></div>';
			return;
		}
		echo '<p>Copies blog posts and pages (with their pictures) from <b>' . esc_html( $host ) . '</b> into this site, so a backup of this site is complete. Items already here are skipped, so you can press the buttons again.</p>';
		echo '<p><button class="button button-primary" id="mi-post">Import blog posts</button> <button class="button" id="mi-page">Import pages</button> <button class="button" id="mi-all">Import both</button></p><pre id="mi-log" style="background:#fff;border:1px solid #ddd;padding:12px;max-width:640px;min-height:80px"></pre></div>';
		?>
<script>
(function(){
var log=document.getElementById('mi-log'),busy=false,N=<?php echo wp_json_encode( $n ); ?>;
function say(t){log.textContent+=t+"\n";}
function run(type){return new Promise(function(res){var pg=1,tot={new:0,skip:0,fail:0};
function go(){var f=new FormData();f.append('action','mrsh_import_batch');f.append('_ajax_nonce',N);f.append('type',type);f.append('pg',pg);
fetch(ajaxurl,{method:'POST',body:f,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(j){
if(!j.success){say('Stopped: '+j.data);return res();}
['new','skip','fail'].forEach(function(k){tot[k]+=j.data[k]});say(type+' page '+pg+': '+j.data.new+' new, '+j.data.skip+' already here, '+j.data.fail+' failed');
if(j.data.done){say('Finished '+type+'s: '+tot.new+' new, '+tot.skip+' skipped, '+tot.fail+' failed');return res();}pg++;go();
}).catch(function(){say('Network problem, press the button again to continue.');res();});}
go();});}
function start(list){if(busy)return;busy=true;list.reduce(function(p,t){return p.then(function(){return run(t)})},Promise.resolve()).then(function(){busy=false;say('Done.');});}
document.getElementById('mi-post').onclick=function(){start(['post'])};
document.getElementById('mi-page').onclick=function(){start(['page'])};
document.getElementById('mi-all').onclick=function(){start(['post','page'])};
})();
</script>
		<?php
	}
}
MRSH_Mem_Import::init();
