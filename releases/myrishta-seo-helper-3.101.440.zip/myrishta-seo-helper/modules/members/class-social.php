<?php
/**
 * Social login: Continue with Google and Continue with Facebook (OAuth 2.0 code flow, server side).
 * Google uses the Client ID and secret from My Rishta SEO > Website keys (the ones migrated from DA10).
 * Facebook keys are entered on My Rishta SEO > Social login. Buttons stay hidden until the keys exist.
 * Safety: state check, verified email only, no social login for administrators, new accounts can be switched off.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Mem_Social {

	const OPT = 'mrsh_social';

	public static function get( $k = null ) {
		$o = array_merge( array( 'fb_id' => '', 'fb_secret' => '', 'signup' => 1, 'google_on' => 1, 'fb_on' => 1 ), (array) get_option( self::OPT, array() ) );
		return null === $k ? $o : ( $o[ $k ] ?? '' );
	}

	private static function google() {
		$k = class_exists( 'MRSH_Keys' ) ? MRSH_Keys::get() : array();
		return array( (string) ( $k['google_id'] ?? '' ), (string) ( $k['google_secret'] ?? '' ) );
	}

	public static function ready( $p ) {
		if ( 'google' === $p ) {
			$g = self::google();
			return $g[0] && $g[1] && self::get( 'google_on' );
		}
		return self::get( 'fb_id' ) && self::get( 'fb_secret' ) && self::get( 'fb_on' );
	}

	public static function init() {
		add_action( 'init', array( __CLASS__, 'route' ), 1 );
		add_action( 'login_form', array( __CLASS__, 'buttons_echo' ) );
		add_action( 'register_form', array( __CLASS__, 'buttons_echo' ) );
		add_filter( 'login_form_bottom', array( __CLASS__, 'buttons_html' ) );
		add_shortcode( 'mrsh_social_login', array( __CLASS__, 'buttons_html' ) );
		add_filter( 'login_message', array( __CLASS__, 'msg' ) );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 30 );
		add_action( 'admin_post_mrsh_social_save', array( __CLASS__, 'save' ) );
	}

	public static function cb( $p ) {
		return add_query_arg( 'mrsh_social', $p . '_cb', home_url( '/' ) );
	}

	private static function css() {
		return '.mrsh-soc{margin:18px 0 0}.mrsh-soc .dv{display:flex;align-items:center;gap:12px;color:#8a90a2;font-size:.82rem;margin:0 0 12px}.mrsh-soc .dv:before,.mrsh-soc .dv:after{content:"";flex:1;height:1px;background:#e6e8f3}'
			. '.mrsh-soc a.sb,.mrsh-soc button.sb{display:flex;align-items:center;justify-content:center;gap:11px;width:100%;min-height:50px;margin:0 0 10px;padding:0 18px;border-radius:15px;font:inherit;font-weight:650;font-size:.98rem;text-decoration:none;cursor:pointer;background:#fff;color:#1f2330;border:1px solid #dcdfea;box-shadow:0 1px 2px rgba(17,24,39,.05);transition:transform .12s,box-shadow .15s,border-color .15s}'
			. '.mrsh-soc .sb:hover{transform:translateY(-1px);box-shadow:0 8px 18px rgba(40,30,90,.12);border-color:#c4a8f7;text-decoration:none}.mrsh-soc .sb svg{width:22px;height:22px;flex:none}'
			. '.mrsh-soc .sb.fb{background:#1877f2;border-color:#1877f2;color:#fff}.mrsh-soc .sb.fb:hover{border-color:#1877f2;filter:brightness(.95)}'
			. '.mrsh-soc .mp{display:none;margin:2px 0 10px;padding:16px;border-radius:16px;background:linear-gradient(160deg,#faf7ff,#fff);box-shadow:inset 0 0 0 1px #e9e0fb}.mrsh-soc .mp.on{display:block}'
			. '.mrsh-soc .mp label{display:block;margin:0 0 6px;font-weight:600;font-size:.85rem}.mrsh-soc .mp input{width:100%;min-height:48px;border-radius:13px;border:1px solid #d9dce8;padding:0 14px;font:inherit;font-size:1rem;background:#fff;margin:0 0 10px}'
			. '.mrsh-soc .mp .go{width:100%;min-height:48px;border:0;border-radius:13px;font:inherit;font-weight:700;color:#fff;cursor:pointer;background:linear-gradient(135deg,#9b1b4b,#6e1230)}.mrsh-soc .mp .go[disabled]{opacity:.6}'
			. '.mrsh-soc .mp .ms{min-height:20px;margin:8px 0 0;font-size:.88rem;color:#667085}.mrsh-soc .mp .ms.bad{color:#b42318}';
	}

	public static function buttons_html( $x = '' ) {
		static $n = 0;
		$dest = isset( $_GET['redirect_to'] ) ? esc_url_raw( wp_unslash( $_GET['redirect_to'] ) ) : ''; // phpcs:ignore
		$ico  = array(
			'google'   => '<svg viewBox="0 0 48 48" aria-hidden="true"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.1C12.4 13.6 17.7 9.5 24 9.5z"/><path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.6 5.9c4.4-4.1 7-10.1 7-17.6z"/><path fill="#FBBC05" d="M10.5 28.7c-.5-1.4-.8-3-.8-4.7s.3-3.2.8-4.7l-7.9-6.1C.9 16.4 0 20.1 0 24s.9 7.6 2.6 10.8l7.9-6.1z"/><path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.6-5.9c-2.1 1.4-4.8 2.3-8.3 2.3-6.3 0-11.6-4.2-13.5-9.9l-7.9 6.1C6.5 42.6 14.6 48 24 48z"/></svg>',
			'facebook' => '<svg viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M13.5 21v-7.5h2.6l.4-3h-3V8.6c0-.9.3-1.5 1.600-1.500h1.500V4.400c-.3 0-1.200-.1-2.200-.1-2.300 0-3.800 1.400-3.800 3.900v2.300H8v3h2.600V21z"/></svg>',
			'mobile'   => '<svg viewBox="0 0 24 24" fill="#7c3aed" aria-hidden="true"><path d="M8 2h8a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2zm4 17.500a1.100 1.100 0 1 0 0-2.200 1.100 1.100 0 0 0 0 2.200zM8 5v11h8V5z"/></svg>',
		);
		$out = '';
		foreach ( array( 'google' => 'Continue with Google', 'facebook' => 'Continue with Facebook' ) as $p => $l ) {
			if ( self::ready( $p ) ) {
				$u    = add_query_arg( array( 'mrsh_social' => $p, 'to' => $dest ), home_url( '/' ) );
				$out .= '<a class="sb' . ( 'facebook' === $p ? ' fb' : '' ) . '" href="' . esc_url( $u ) . '" rel="nofollow">' . $ico[ $p ] . '<span>' . esc_html( $l ) . '</span></a>'; // phpcs:ignore
			}
		}
		$mob = class_exists( 'MRSH_Mobile' ) && MRSH_Mobile::otp_ready();
		if ( $mob ) {
			$id   = 'mrsh-mp' . ( ++$n );
			$out .= '<button type="button" class="sb" data-mp="' . esc_attr( $id ) . '">' . $ico['mobile'] . '<span>Continue with mobile number</span></button>'; // phpcs:ignore
			$out .= '<div class="mp" id="' . esc_attr( $id ) . '"><div class="s1"><label for="' . esc_attr( $id ) . 'm">Your mobile number</label><input type="tel" id="' . esc_attr( $id ) . 'm" inputmode="tel" autocomplete="tel" placeholder="0300 1234567"><button type="button" class="go" data-send>Send code</button></div>';
			$out .= '<div class="s2" hidden><label for="' . esc_attr( $id ) . 'c">6 digit code from SMS</label><input type="text" id="' . esc_attr( $id ) . 'c" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="123456"><button type="button" class="go" data-check>Log in</button></div><p class="ms" role="status"></p><p class="ms" style="margin:0;font-size:.8rem">New number? An account is made for you.</p></div>';
		}
		if ( '' === $out ) {
			return is_string( $x ) ? $x : '';
		}
		$h = '<div class="mrsh-soc">' . ( 1 === $n || ! $mob ? '<style>' . self::css() . '</style>' : '' ) . '<div class="dv"><span>or continue with</span></div>' . $out . '</div>';
		if ( $mob ) {
			$h .= '<script>(function(){var u=' . wp_json_encode( admin_url( 'admin-ajax.php' ) ) . ';document.querySelectorAll("[data-mp]").forEach(function(b){if(b.__mp)return;b.__mp=1;var p=document.getElementById(b.getAttribute("data-mp")),m=p.querySelector("input[type=tel]"),c=p.querySelector("input[inputmode=numeric]"),s1=p.querySelector(".s1"),s2=p.querySelector(".s2"),ms=p.querySelector(".ms"),sb=p.querySelector("[data-send]"),cb=p.querySelector("[data-check]");'
				. 'function say(t,bad){ms.textContent=t;ms.className="ms"+(bad?" bad":"")}function post(a,d){var f=new FormData();f.append("action",a);for(var k in d)f.append(k,d[k]);return fetch(u,{method:"POST",body:f,credentials:"same-origin"}).then(function(r){return r.json()})}'
. 'var fb=' . wp_json_encode( class_exists( 'MRSH_Mobile' ) ? MRSH_Mobile::fb_public() : null ) . ',cf=null,vr=null;function ld(src,cb){var e=document.createElement("script");e.src=src;e.onload=cb;document.head.appendChild(e)}'
				. 'function fbl(cb){if(window.firebase&&firebase.auth)return cb();ld("https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js",function(){ld("https://www.gstatic.com/firebasejs/10.12.2/firebase-auth-compat.js",cb)})}'
				. 'function pn(v){var d=String(v).replace(/\D+/g,"");if(/^0092/.test(d))d=d.slice(2);if(/^03\d{9}$/.test(d))d="92"+d.slice(1);else if(/^3\d{9}$/.test(d))d="92"+d;return "+"+d}'
				. 'function fsend(){fbl(function(){try{if(!firebase.apps.length)firebase.initializeApp(fb);if(!vr)vr=new firebase.auth.RecaptchaVerifier(sb,{size:"invisible"});firebase.auth().signInWithPhoneNumber(pn(m.value),vr).then(function(r){cf=r;sb.disabled=false;s1.hidden=true;s2.hidden=false;c.focus();say("Code sent. It arrives in a few seconds.")}).catch(function(e){sb.disabled=false;try{vr.clear();vr=null}catch(x){}say(e&&e.code=="auth/invalid-phone-number"?"That number does not look right.":e&&e.code=="auth/too-many-requests"?"Too many tries. Please wait a while.":"The code could not be sent. Try again later or use email.",1)})}catch(e){sb.disabled=false;say("The code could not be sent.",1)}})}'
				. 'function fcheck(){if(!cf){say("Ask for a new code.",1);cb.disabled=false;return}cf.confirm(c.value).then(function(r){return r.user.getIdToken()}).then(function(t){return post("mrsh_fb_login",{t:t})}).then(function(r){if(r.success){say("Welcome! Opening your account...");location.href=r.data.to}else{cb.disabled=false;say(r.data||"Wrong code.",1)}}).catch(function(){cb.disabled=false;say("That code is not right.",1)})}'
				
				. '[m,c].forEach(function(i){i.addEventListener("keydown",function(e){if(e.key==="Enter"){e.preventDefault();(i===m?sb:cb).click()}})});'
				. 'b.onclick=function(){p.classList.toggle("on");if(p.classList.contains("on"))m.focus()};'
				. 'sb.onclick=function(){sb.disabled=true;say("Sending code...");if(fb)return fsend();post("mrsh_otp_send",{m:m.value}).then(function(r){sb.disabled=false;if(r.success){s1.hidden=true;s2.hidden=false;c.focus();say("Code sent. It arrives in a few seconds.")}else say(r.data||"Could not send.",1)}).catch(function(){sb.disabled=false;say("Network problem. Try again.",1)})};'
				. 'cb.onclick=function(){cb.disabled=true;say("Checking...");if(fb)return fcheck();post("mrsh_otp_check",{m:m.value,c:c.value}).then(function(r){if(r.success){say("Welcome! Opening your account...");location.href=r.data.to}else{cb.disabled=false;say(r.data||"Wrong code.",1)}}).catch(function(){cb.disabled=false;say("Network problem. Try again.",1)})}'
				. '})})();</script>';
		}
		return is_string( $x ) ? $x . $h : $out;
	}

	public static function buttons_echo() {
		echo self::buttons_html( '' ); // phpcs:ignore -- built here with escaped parts
	}

	/* ---------- flow ---------- */

	public static function route() {
		$r = isset( $_GET['mrsh_social'] ) ? sanitize_key( $_GET['mrsh_social'] ) : ''; // phpcs:ignore
		if ( ! $r ) {
			return;
		}
		$p = str_replace( '_cb', '', $r );
		if ( ! in_array( $p, array( 'google', 'facebook' ), true ) || ! self::ready( $p ) ) {
			wp_safe_redirect( wp_login_url() );
			exit;
		}
		'_cb' === substr( $r, -3 ) ? self::callback( $p ) : self::start( $p );
	}

	private static function start( $p ) {
		$state = wp_generate_password( 24, false );
		$to    = isset( $_GET['to'] ) ? esc_url_raw( wp_unslash( $_GET['to'] ) ) : ''; // phpcs:ignore
		set_transient( 'mrsh_st_' . $state, array( 'p' => $p, 'to' => wp_validate_redirect( $to, '' ) ), 10 * MINUTE_IN_SECONDS );
		if ( 'google' === $p ) {
			$g   = self::google();
			$url = add_query_arg( array( 'client_id' => $g[0], 'redirect_uri' => self::cb( 'google' ), 'response_type' => 'code', 'scope' => 'openid email profile', 'state' => $state, 'prompt' => 'select_account' ), 'https://accounts.google.com/o/oauth2/v2/auth' );
		} else {
			$url = add_query_arg( array( 'client_id' => self::get( 'fb_id' ), 'redirect_uri' => self::cb( 'facebook' ), 'state' => $state, 'scope' => 'email,public_profile' ), 'https://www.facebook.com/v19.0/dialog/oauth' );
		}
		wp_redirect( $url ); // phpcs:ignore WordPress.Security.SafeRedirect -- fixed Google / Facebook address
		exit;
	}

	private static function fail( $msg ) {
		wp_safe_redirect( add_query_arg( 'mrsh_social_err', rawurlencode( $msg ), wp_login_url() ) );
		exit;
	}

	private static function callback( $p ) {
		$ip = function_exists( 'mrt_ip' ) ? mrt_ip() : '0';
		$lk = 'mrsh_soc_' . md5( $ip );
		if ( (int) get_transient( $lk ) >= 20 ) {
			self::fail( 'Too many tries. Please wait a while.' );
		}
		set_transient( $lk, (int) get_transient( $lk ) + 1, HOUR_IN_SECONDS );
		$state = sanitize_text_field( wp_unslash( $_GET['state'] ?? '' ) ); // phpcs:ignore
		$code  = sanitize_text_field( wp_unslash( $_GET['code'] ?? '' ) ); // phpcs:ignore
		$st    = $state ? get_transient( 'mrsh_st_' . $state ) : false;
		if ( ! $st || $st['p'] !== $p || ! $code ) {
			self::fail( 'Login was cancelled or expired. Please try again.' );
		}
		delete_transient( 'mrsh_st_' . $state );
		$fid = '';
		if ( 'google' === $p ) {
			$g = self::google();
			$t = wp_remote_post( 'https://oauth2.googleapis.com/token', array( 'timeout' => 15, 'body' => array( 'code' => $code, 'client_id' => $g[0], 'client_secret' => $g[1], 'redirect_uri' => self::cb( 'google' ), 'grant_type' => 'authorization_code' ) ) );
			$d = is_wp_error( $t ) ? array() : (array) json_decode( wp_remote_retrieve_body( $t ), true );
			if ( empty( $d['access_token'] ) ) {
				self::fail( 'Google login failed.' );
			}
			$u  = wp_remote_get( 'https://openidconnect.googleapis.com/v1/userinfo', array( 'timeout' => 15, 'headers' => array( 'Authorization' => 'Bearer ' . $d['access_token'] ) ) );
			$i  = is_wp_error( $u ) ? array() : (array) json_decode( wp_remote_retrieve_body( $u ), true );
			$ok = ! empty( $i['email'] ) && ! empty( $i['email_verified'] );
			$em = $ok ? sanitize_email( $i['email'] ) : '';
			$nm = sanitize_text_field( $i['name'] ?? '' );
		} else {
			$t = wp_remote_get( add_query_arg( array( 'client_id' => self::get( 'fb_id' ), 'client_secret' => self::get( 'fb_secret' ), 'redirect_uri' => self::cb( 'facebook' ), 'code' => $code ), 'https://graph.facebook.com/v19.0/oauth/access_token' ), array( 'timeout' => 15 ) );
			$d = is_wp_error( $t ) ? array() : (array) json_decode( wp_remote_retrieve_body( $t ), true );
			if ( empty( $d['access_token'] ) ) {
				self::fail( 'Facebook login failed.' );
			}
			$u  = wp_remote_get( add_query_arg( array( 'fields' => 'id,name,email', 'access_token' => $d['access_token'] ), 'https://graph.facebook.com/me' ), array( 'timeout' => 15 ) );
			$i  = is_wp_error( $u ) ? array() : (array) json_decode( wp_remote_retrieve_body( $u ), true );
			$em  = ! empty( $i['email'] ) ? sanitize_email( $i['email'] ) : '';
			$nm  = sanitize_text_field( $i['name'] ?? '' );
			$fid = preg_replace( '/\D+/', '', (string) ( $i['id'] ?? '' ) );
		}
		$user = null;
		$new  = false;
		if ( ! empty( $fid ) ) { // a returning Facebook member is found by Facebook id, even with no email
			$f = get_users( array( 'meta_key' => 'mrt_fb_id', 'meta_value' => $fid, 'number' => 1 ) ); // phpcs:ignore
			$user = $f ? $f[0] : null;
		}
		if ( ! $user && is_email( $em ) ) {
			$user = get_user_by( 'email', $em );
		}
		if ( ! $user && ! is_email( $em ) && empty( $fid ) ) {
			self::fail( 'We could not get your details from ' . ucfirst( $p ) . '. Please sign up with email.' );
		}
		if ( $user ) {
			if ( user_can( $user, 'manage_options' ) || user_can( $user, 'edit_others_posts' ) ) {
				self::fail( 'Staff accounts must log in with a password.' );
			}
		} else {
			if ( ! self::get( 'signup' ) ) {
				self::fail( 'New sign ups with ' . ucfirst( $p ) . ' are closed. Please sign up with email.' );
			}
			$noem = ! is_email( $em );
			if ( $noem ) { // Facebook gave no email: make the account anyway and ask for an email later
				$em = 'fb' . $fid . '@noemail.' . (string) wp_parse_url( home_url(), PHP_URL_HOST );
			}
			$base  = $noem ? 'fb' . $fid : sanitize_user( strstr( $em, '@', true ), true );
			$login = $base ? $base : 'member';
			while ( username_exists( $login ) ) {
				$login = $base . wp_rand( 100, 99999 );
			}
			if ( class_exists( 'MRSH_Noprofile' ) && MRSH_Noprofile::is_blocked( $em ) ) {
				self::fail( 'This email cannot be used to register.' );
			}
			$uid = wp_create_user( $login, wp_generate_password( 32 ), $em );
			if ( is_wp_error( $uid ) ) {
				self::fail( 'Could not create your account. Please try again.' );
			}
			wp_update_user( array( 'ID' => $uid, 'display_name' => $nm ? $nm : $login, 'first_name' => $nm ) );
			if ( $noem ) {
				update_user_meta( $uid, 'mrt_need_email', 1 );
			}
			$user = get_user_by( 'id', $uid );
			$new  = true;
		}
		if ( ! empty( $fid ) ) {
			update_user_meta( $user->ID, 'mrt_fb_id', $fid );
		}
		update_user_meta( $user->ID, 'mrt_social', $p );
		wp_set_current_user( $user->ID );
		wp_set_auth_cookie( $user->ID, true );
		// Signed in with Google or Facebook: that is already a verified sign-in, so do not ask for the second step.
		if ( ! class_exists( 'MRSH_TwoFactor' ) || ! empty( MRSH_TwoFactor::settings()['social_skip'] ) ) {
			$GLOBALS['mrsh_2fa_pass'] = 'mrsh2fa_done';
		}
		do_action( 'wp_login', $user->user_login, $user );
		$to = ( $st['to'] && ! $new ) ? $st['to'] : ( $new ? ( function_exists( 'mrt_link' ) ? mrt_link( 'add', '/add-listing/' ) : home_url( '/add-listing/' ) ) : ( function_exists( 'mrt_link' ) ? mrt_link( 'myaccount', '/my-account/' ) : home_url( '/my-account/' ) ) );
		wp_safe_redirect( $to );
		exit;
	}

	/* ---------- admin ---------- */

	public static function msg( $m ) {
		if ( ! empty( $_GET['mrsh_social_err'] ) ) { // phpcs:ignore
			$m .= '<div id="login_error" class="notice notice-error"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['mrsh_social_err'] ) ) ) . '</p></div>'; // phpcs:ignore
		}
		return $m;
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Social login', 'Social login', 'manage_options', 'mrsh-social', array( __CLASS__, 'page' ) );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$g  = self::ready( 'google' );
		$f  = self::ready( 'facebook' );
		$mo = class_exists( 'MRSH_Mobile' );
		$mr = $mo && MRSH_Mobile::otp_ready();
		MRSH_Boost::ui_open( 'Social login and mobile number', 'Let members sign in or sign up with Google, Facebook or a mobile number. Returning members are recognised automatically; new ones get an account.', '', 'M16 11a4 4 0 1 0-8 0 4 4 0 0 0 8 0zM4 21a8 8 0 0 1 16 0z' );
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			MRSH_Boost::ui_ok( 'Saved.' );
		}
		echo apply_filters( 'mrsh_social_extra_note', '' ); // phpcs:ignore -- built with escaped parts
		if ( isset( $_GET['sms'] ) ) { // phpcs:ignore
			MRSH_Boost::ui_ok( 'ok' === $_GET['sms'] ? 'Test message sent. Check your phone.' : 'The test message was not accepted by the SMS service. Check the address.' ); // phpcs:ignore
		}
		if ( isset( $_GET['linked'] ) ) { // phpcs:ignore
			MRSH_Boost::ui_ok( (int) $_GET['linked'] . ' members can now log in with the phone number from their profile.' ); // phpcs:ignore
		}
		$pill = function ( $ok, $yes, $no ) {
			return '<span class="mx-pill ' . ( $ok ? 'ok' : 'warn' ) . '">' . esc_html( $ok ? $yes : $no ) . '</span>';
		};
		echo '<div class="mx-stats">' . MRSH_Boost::ui_stat( $g ? 'On' : 'Off', 'Google', $g ? '#10b981' : '#9ca3af' ) . MRSH_Boost::ui_stat( $f ? 'On' : 'Off', 'Facebook', $f ? '#1877f2' : '#9ca3af' ) . MRSH_Boost::ui_stat( 'On', 'Mobile number + password', '#7c3aed' ) . MRSH_Boost::ui_stat( $mr ? 'On' : 'Off', 'Mobile code by SMS', $mr ? '#e11d74' : '#9ca3af' ) . '</div>'; // phpcs:ignore

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_social_save">';
		wp_nonce_field( 'mrsh_social_save' );
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">1</span><h2>Google and Facebook</h2></div><p class="mx-sub">The buttons show on the login page and the Create profile page as soon as the keys are saved.</p>';
		echo '<p>' . $pill( $g, 'Google is ready', 'Google needs keys' ) . ' ' . ( $g ? '' : '<a href="' . esc_url( admin_url( 'admin.php?page=mrsh-keys' ) ) . '">Add the Client ID and secret in Website keys</a>' ) . '</p>'; // phpcs:ignore
		echo '<div class="mx-grid"><div class="mx-f"><label class="t" for="fbid">Facebook App ID</label><input type="text" id="fbid" name="fb_id" value="' . esc_attr( self::get( 'fb_id' ) ) . '" autocomplete="off"></div><div class="mx-f"><label class="t" for="fbs">Facebook App secret</label><input type="password" id="fbs" name="fb_secret" value="" autocomplete="off" placeholder="' . ( self::get( 'fb_secret' ) ? 'Saved. Leave empty to keep.' : '' ) . '"></div></div>';
		echo '<div class="mx-grid" style="margin-top:16px">';
		foreach ( array( 'google_on' => 'Show the Google button', 'fb_on' => 'Show the Facebook button', 'signup' => 'Allow new accounts through social login' ) as $k => $l ) {
			echo '<div class="mx-f"><label class="mx-sw"><input type="checkbox" name="' . esc_attr( $k ) . '" value="1"' . checked( (int) self::get( $k ), 1, false ) . '><span class="tr"></span><span class="lb">' . esc_html( $l ) . '</span></label></div>';
		}
		echo '</div><p class="mx-note">Staff and administrator accounts can never use social login. Only emails verified by Google are accepted. If Facebook gives no email, the account is still made and the member is asked to add an email later.</p>';
		echo '<p style="margin:16px 0 0"><button class="mx-btn p">Save</button></p></div></form>';

		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">2</span><h2>Addresses to paste in the consoles</h2></div><p class="mx-sub">Copy these exactly. They use your current site address; when you move to the live address, paste the new ones too.</p>';
		echo '<div class="mx-f"><label class="t">Google Cloud > Credentials > your OAuth client > Authorised redirect URIs</label><input type="text" readonly value="' . esc_attr( self::cb( 'google' ) ) . '" onclick="this.select()"></div><div class="mx-f" style="margin-top:12px"><label class="t">Facebook for Developers > Facebook Login > Settings > Valid OAuth Redirect URIs</label><input type="text" readonly value="' . esc_attr( self::cb( 'facebook' ) ) . '" onclick="this.select()"></div></div>';

		if ( $mo ) {
			$m = MRSH_Mobile::get();
			echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">3</span><h2>Mobile number</h2></div><p class="mx-sub"><b>Mobile number + password</b> works now and costs nothing: members type their number instead of an email in the normal login box. <b>Mobile code by SMS</b> lets members log in or sign up with a one-time code, but needs an SMS service that charges per message.</p>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_mobile_save">';
			wp_nonce_field( 'mrsh_mobile_save' );
			echo '<div class="mx-grid"><div class="mx-f"><label class="mx-sw"><input type="checkbox" name="otp_on" value="1"' . checked( ! empty( $m['otp_on'] ), true, false ) . '><span class="tr"></span><span class="lb">Show "Continue with mobile number"</span></label></div><div class="mx-f"><label class="mx-sw"><input type="checkbox" name="signup" value="1"' . checked( ! empty( $m['signup'] ), true, false ) . '><span class="tr"></span><span class="lb">Allow new accounts by mobile</span></label></div></div>';
			echo '<div class="mx-f" style="margin-top:16px"><label class="t">How the code is sent</label><div class="mx-chips"><label class="mx-chip" style="--d:#f59e0b"><input type="radio" name="mode" value="firebase"' . checked( MRSH_Mobile::mode(), 'firebase', false ) . '><span>Google Firebase</span></label><label class="mx-chip" style="--d:#6b7280"><input type="radio" name="mode" value="sms"' . checked( MRSH_Mobile::mode(), 'sms', false ) . '><span>My own SMS service address</span></label></div></div>';
			echo '<div class="mx-card" style="margin:16px 0 0;background:#fffbeb;box-shadow:0 0 0 1px #fde7a6"><b>Google Firebase and cost</b><p class="mx-sub" style="margin:6px 0 10px">Firebase sends the code for you, and the page does the rest. Be careful: according to the Firebase pricing page, phone sign in is not on the free Spark plan. It needs the pay-as-you-go Blaze plan (a billing card), SMS is billed per message, and new projects must switch on Pakistan in the SMS region policy. Firebase has free <b>test phone numbers</b> for trying it. Set a low budget alert in Google Cloud before using it for real members.</p>';
			echo '<div class="mx-grid"><div class="mx-f"><label class="t" for="fbk">Firebase Web API key</label><input type="text" id="fbk" name="fb_key" value="" autocomplete="off" placeholder="' . ( $m['fb_key'] ? 'Saved. Leave empty to keep.' : 'AIza...' ) . '"></div><div class="mx-f"><label class="t" for="fbp">Firebase project ID</label><input type="text" id="fbp" name="fb_project" value="' . esc_attr( $m['fb_project'] ) . '" placeholder="my-rishta-12345"></div><div class="mx-f"><label class="t" for="fbd">Auth domain (optional)</label><input type="text" id="fbd" name="fb_domain" value="' . esc_attr( $m['fb_domain'] ) . '" placeholder="my-rishta-12345.firebaseapp.com"></div></div><p class="mx-note">In Firebase Console: Authentication > Sign-in method > Phone > Enable; Settings > Authorized domains > add this site address; SMS region policy > allow Pakistan.</p></div>';
			echo '<div class="mx-f" style="margin-top:16px"><label class="t" for="smsu">SMS service address</label><input type="text" id="smsu" name="url" value="" autocomplete="off" placeholder="' . ( $m['url'] ? 'Saved. Leave empty to keep.' : 'https://your-sms-service/send?key=YOUR_KEY&to={to}&text={msg}' ) . '"><span class="hint">Use {to} for the number (with country code, like 923001234567) and {msg} for the text. The address is kept private and never shown again.</span></div>';
			echo '<div class="mx-f" style="margin-top:12px"><label class="t" for="smsb">Message body (only if your SMS service wants a POST)</label><input type="text" id="smsb" name="body" value="" autocomplete="off" placeholder="' . ( $m['body'] ? 'Saved. Leave empty to keep.' : 'to={to}&text={msg}&key=YOUR_KEY' ) . '"></div>';
			echo '<p style="margin:16px 0 0" class="mx-acts"><button class="mx-btn p">Save mobile settings</button><label style="margin:0"><input type="checkbox" name="clear" value="1"> Remove the saved SMS address</label></p></form>';
			if ( $mr ) {
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin-top:14px" class="mx-acts"><input type="hidden" name="action" value="mrsh_mobile_test">';
				wp_nonce_field( 'mrsh_mobile_test' );
				echo '<input type="text" name="to" placeholder="Your mobile, 0300 1234567" style="max-width:240px;height:44px;border-radius:13px"><button class="mx-btn">Send a test message</button></form>';
			}
			echo '<p class="mx-note">Members who already have a phone number on their profile can use it to log in after you press the button below. Numbers used by two members are skipped.</p>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( 'mrsh_mobile_link' );
			echo '<input type="hidden" name="action" value="mrsh_mobile_link"><button class="mx-btn">Link profile phone numbers to logins</button></form></div>';
		}
		echo '<div class="mx-card"><p class="mx-sub" style="margin:0">To show the buttons on any page, add the shortcode <code>[mrsh_social_login]</code>.</p></div></div>';
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_social_save' );
		$o = (array) get_option( self::OPT, array() );
		$o['fb_id'] = sanitize_text_field( wp_unslash( $_POST['fb_id'] ?? '' ) ); // phpcs:ignore
		if ( ! empty( $_POST['fb_secret'] ) ) { // phpcs:ignore
			$o['fb_secret'] = sanitize_text_field( wp_unslash( $_POST['fb_secret'] ) ); // phpcs:ignore
		}
		foreach ( array( 'google_on', 'fb_on', 'signup' ) as $k ) {
			$o[ $k ] = empty( $_POST[ $k ] ) ? 0 : 1; // phpcs:ignore
		}
		update_option( self::OPT, $o, false );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-social&ok=1' ) );
		exit;
	}
}
MRSH_Mem_Social::init();
