<?php
/**
 * Google Ads support: tag, conversion tracking, automatic page feed and a readiness check.
 * Everything is generated from the site itself, so Google picks up new pages without any editing.
 *
 * @package MyRishta_SEO_Helper
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Gads {

	const OPT = 'mrsh_gads';

	public static function get() {
		return array_merge( array( 'id' => '', 'l_signup' => '', 'l_profile' => '', 'l_msg' => '', 'remarket' => 1, 'feed_posts' => 1, 'delay' => 1 ), (array) get_option( self::OPT, array() ) );
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 30 );
		add_action( 'admin_post_mrsh_gads_save', array( __CLASS__, 'save' ) );
		add_action( 'wp_head', array( __CLASS__, 'tag' ), 3 );
		add_action( 'wp_footer', array( __CLASS__, 'fire' ), 99 );
		add_action( 'user_register', function ( $uid ) { update_user_meta( $uid, 'mrsh_conv', 'signup' ); } );
		add_action( 'mrsh_msg_sent', function ( $id, $from ) { if ( ! get_user_meta( (int) $from, 'mrsh_conv_msg', true ) ) { update_user_meta( (int) $from, 'mrsh_conv', 'msg' ); update_user_meta( (int) $from, 'mrsh_conv_msg', 1 ); } }, 10, 2 );
		add_action( 'transition_post_status', function ( $new, $old, $p ) { if ( 'publish' === $new && 'publish' !== $old && 'listing_type' === $p->post_type && ! get_user_meta( (int) $p->post_author, 'mrsh_conv_prof', true ) ) { update_user_meta( (int) $p->post_author, 'mrsh_conv', 'profile' ); update_user_meta( (int) $p->post_author, 'mrsh_conv_prof', 1 ); } }, 10, 3 );
		add_action( 'init', array( __CLASS__, 'feed' ) );
	}

	private static function id() {
		$i = strtoupper( trim( (string) self::get()['id'] ) );
		return preg_match( '/^AW-\d{6,14}$/', $i ) ? $i : '';
	}

	/** Loads the Google tag from script code, so the speed module's delay does not hold it back. */
	public static function tag() {
		$id = self::id();
		if ( ! $id || is_admin() ) {
			return;
		}
		$cfg = self::get()['remarket'] ? "gtag('config','" . $id . "');" : "gtag('config','" . $id . "',{'allow_ad_personalization_signals':false});";
		$src = 'https://www.googletagmanager.com/gtag/js?id=' . esc_js( $id );
		// Delayed: the 200 KB Google file loads on the first touch, scroll or click, or after 5 seconds. Events are queued in dataLayer meanwhile, so no conversion is lost.
		$ld  = ! empty( self::get()['delay'] )
			? '(function(){var l=0,e=["touchstart","scroll","mousemove","keydown","click"];function go(){if(l)return;l=1;e.forEach(function(x){removeEventListener(x,go)});var s=document.createElement("script");s.async=true;s.src="' . $src . '";document.head.appendChild(s)}e.forEach(function(x){addEventListener(x,go,{passive:true})});setTimeout(go,5000)})();'
			: '(function(){var s=document.createElement("script");s.async=true;s.src="' . $src . '";document.head.appendChild(s)})();';
		echo '<script data-no-optimize="1" data-mrsh-ads="1">window.dataLayer=window.dataLayer||[];window.gtag=window.gtag||function(){dataLayer.push(arguments)};gtag("js",new Date());' . $cfg . $ld . '</script>' . "\n"; // phpcs:ignore
	}

	/** One-time conversion events, fired on the next page the member sees. */
	public static function fire() {
		$id = self::id();
		$uid = get_current_user_id();
		if ( ! $id || ! $uid ) {
			return;
		}
		$c = (string) get_user_meta( $uid, 'mrsh_conv', true );
		if ( ! $c ) {
			return;
		}
		delete_user_meta( $uid, 'mrsh_conv' );
		$o   = self::get();
		$map = array( 'signup' => array( 'l_signup', 'sign_up' ), 'profile' => array( 'l_profile', 'generate_lead' ), 'msg' => array( 'l_msg', 'contact' ) );
		if ( ! isset( $map[ $c ] ) ) {
			return;
		}
		$js = 'gtag("event","' . $map[ $c ][1] . '");';
		if ( ! empty( $o[ $map[ $c ][0] ] ) && preg_match( '/^[\w\-]{6,40}$/', $o[ $map[ $c ][0] ] ) && ! preg_match( '/^(GTM|AW|G|UA)-/i', $o[ $map[ $c ][0] ] ) ) {
			$js .= 'gtag("event","conversion",{"send_to":"' . esc_js( $id . '/' . $o[ $map[ $c ][0] ] ) . '"});';
		}
		echo '<script data-no-optimize="1" data-mrsh-ads="1">window.gtag&&(function(){' . $js . '})();</script>'; // phpcs:ignore
	}

	/* ---------- automatic page feed (CSV that Google Ads fetches on a schedule) ---------- */

	public static function feed_url() {
		return add_query_arg( 'mrsh_pagefeed', substr( md5( wp_salt( 'auth' ) . 'pf' ), 0, 12 ), home_url( '/' ) );
	}

	public static function feed() {
		if ( empty( $_GET['mrsh_pagefeed'] ) || ! hash_equals( substr( md5( wp_salt( 'auth' ) . 'pf' ), 0, 12 ), (string) $_GET['mrsh_pagefeed'] ) ) { // phpcs:ignore
			return;
		}
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		echo "Page URL,Custom label\n";
		$types = self::get()['feed_posts'] ? array( 'page', 'post' ) : array( 'page' );
		$skip  = array( 'my-account', 'add-listing', 'login', 'register', 'cart', 'checkout', 'recover-account', 'thank-you' );
		$q     = new WP_Query( array( 'post_type' => $types, 'post_status' => 'publish', 'posts_per_page' => 500, 'no_found_rows' => true, 'orderby' => 'modified', 'order' => 'DESC' ) );
		$rows  = array( array( home_url( '/' ), 'Rishta;Home' ) );
		foreach ( $q->posts as $p ) {
			if ( in_array( $p->post_name, $skip, true ) || ( class_exists( 'MRSH_Standalone' ) && isset( MRSH_Standalone::dupes()[ $p->post_name ] ) ) || str_word_count( wp_strip_all_tags( $p->post_content ) ) < 120 ) {
				continue;
			}
			$rows[] = array( get_permalink( $p ), ( 'post' === $p->post_type ? 'Guide' : 'Page' ) . ';' . sanitize_title( $p->post_name ) );
		}
		foreach ( $rows as $r ) {
			echo '"' . str_replace( '"', '""', $r[0] ) . '","' . str_replace( '"', '""', $r[1] ) . "\"\n"; // phpcs:ignore
		}
		exit;
	}

	/* ---------- admin ---------- */

	/** Logos, pictures and ready-made text that Google Ads asks for. All come from the site itself. */
	private static function assets() {
		$img = array(
			array( 'logo-horizontal.png', 'Landscape logo 4:1 (1200 x 300)' ),
			array( 'logo-vertical.png', 'Square logo 1:1 (1200 x 1200)' ),
			array( 'ads-landscape-1200x628.png', 'Landscape image 1.91:1 (1200 x 628)' ),
			array( 'ads-square-1200x1200.png', 'Square image 1:1 (1200 x 1200)' ),
			array( 'ads-portrait-960x1200.png', 'Portrait image 4:5 (960 x 1200)' ),
		);
		echo '<h2>4. Logos, pictures and text (ready)</h2><p>In Performance Max choose <b>Add from your website</b> and Google collects these by itself. You can also paste any address below. No member photos are used.</p><div style="display:flex;flex-wrap:wrap;gap:14px">';
		foreach ( $img as $i ) {
			$u = MRSH_URL . 'assets/logos/' . $i[0];
			echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:10px;width:230px"><img src="' . esc_url( $u ) . '" alt="" style="max-width:100%;height:110px;object-fit:contain;background:#f6f7f7"><br><b>' . esc_html( $i[1] ) . '</b><input readonly class="large-text" onclick="this.select()" value="' . esc_attr( $u ) . '"></div>';
		}
		echo '</div>';
		$name = get_bloginfo( 'name' ) ? get_bloginfo( 'name' ) : 'My Rishta Pakistan';
		$txt  = array(
			'Business name (max 25)' => array( 'My Rishta Pakistan' ),
			'Headlines (max 30)'     => array( 'Free Rishta in Pakistan', 'Find a Rishta Online', 'Create a Free Profile', 'Family Friendly Rishta Site', 'Verified Profiles', 'Private and Safe Rishta', 'Start Free Today' ),
			'Long headlines (max 90)' => array( 'Free rishta website for Pakistani families. Create your profile in 3 minutes.', 'Search rishta by city, education and profession. Safe, private and free to join.' ),
			'Descriptions (max 90)'  => array( 'Free to join. Verified profiles. Phone numbers stay private until you decide.', 'Pakistani families and individuals looking for a suitable rishta. Join free.' ),
			'Call to action'         => array( 'Sign up', 'Learn more' ),
		);
		echo '<table class="widefat striped" style="margin-top:14px;max-width:900px"><tbody>';
		foreach ( $txt as $k => $v ) {
			echo '<tr><th style="width:190px">' . esc_html( $k ) . '</th><td>';
			foreach ( $v as $t ) {
				echo '<div>' . esc_html( $t ) . ' <span class="description">(' . (int) mb_strlen( $t ) . ')</span></div>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table><p class="description">Tip: also keep "Automatically created assets" and "Final URL expansion" switched on in Google Ads, so Google writes extra ads from your pages.</p>';
	}


	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Google Ads', 'Google Ads', 'manage_options', 'mrsh-gads', array( __CLASS__, 'page' ) );
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'mrsh_gads' ) ) {
			wp_die( 'Not allowed.' );
		}
		$o = array();
		foreach ( array( 'id', 'l_signup', 'l_profile', 'l_msg' ) as $k ) {
			$o[ $k ] = sanitize_text_field( wp_unslash( $_POST[ $k ] ?? '' ) ); // phpcs:ignore
		}
		// A conversion label is only the part after the slash (like abcDEF123). Keep the part after any slash, and drop anything that is not a label (for example a name typed or auto-filled by the browser).
		foreach ( array( 'l_signup', 'l_profile', 'l_msg' ) as $k ) {
			$v = trim( (string) $o[ $k ] );
			if ( false !== strpos( $v, '/' ) ) {
				$v = trim( substr( $v, strrpos( $v, '/' ) + 1 ) );
			}
			$o[ $k ] = ( preg_match( '/^[\w\-]{6,40}$/', $v ) && ! preg_match( '/^(GTM|AW|G|UA)-/i', $v ) ) ? $v : ''; // a Tag Manager, Analytics or Ads ID is not a conversion label
		}
		$o['remarket']   = empty( $_POST['remarket'] ) ? 0 : 1; // phpcs:ignore
		$o['delay']      = empty( $_POST['delay'] ) ? 0 : 1; // phpcs:ignore
		$o['feed_posts'] = empty( $_POST['feed_posts'] ) ? 0 : 1; // phpcs:ignore
		update_option( self::OPT, $o, false );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-gads&ok=1' ) );
		exit;
	}

	public static function page() {
		$o = self::get();
		$h = wp_remote_head( home_url( '/' ), array( 'timeout' => 8 ) );
		$chk = array(
			array( 'Site uses https', 0 === strpos( home_url(), 'https://' ) ),
			array( 'Search engines and Google Ads can read the site (Settings > Reading)', (bool) get_option( 'blog_public' ) ),
			array( 'Privacy policy page exists', (bool) get_page_by_path( 'privacy-policy' ) ),
			array( 'Contact page exists', (bool) get_page_by_path( 'contact' ) ),
			array( 'About page exists', (bool) get_page_by_path( 'about-us' ) ),
			array( 'Home page answers normally', ! is_wp_error( $h ) && 200 === (int) wp_remote_retrieve_response_code( $h ) ),
			array( 'Google Ads ID saved', (bool) self::id() ),
		);
		echo '<div class="wrap"><h1>Google Ads</h1>';
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success"><p>Saved.</p></div>';
		}
		echo '<p>Set this up once. Google then reads the site by itself: new guides and pages are picked up without any editing here.</p>';
		echo '<h2>1. Connect your account</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_gads_save">' . wp_nonce_field( 'mrsh_gads', '_wpnonce', true, false ); // phpcs:ignore
		echo '<table class="form-table"><tr><th>Google Ads ID</th><td><input name="id" value="' . esc_attr( $o['id'] ) . '" placeholder="AW-123456789" class="regular-text"><p class="description">In Google Ads: Goals > Conversions > your tag. It looks like AW-123456789.</p></td></tr>';
		echo '<tr><th>Sign-up conversion label</th><td><input name="l_signup" value="' . esc_attr( $o['l_signup'] ) . '" class="regular-text"><p class="description">Optional. The part after the slash in AW-123/abcDEF. Counts every new account.</p></td></tr>';
		echo '<tr><th>Profile created label</th><td><input name="l_profile" value="' . esc_attr( $o['l_profile'] ) . '" class="regular-text"></td></tr>';
		echo '<tr><th>First message label</th><td><input name="l_msg" value="' . esc_attr( $o['l_msg'] ) . '" class="regular-text"></td></tr>';
		echo '<tr><th>Page speed</th><td><label><input type="checkbox" name="delay" value="1"' . checked( ! empty( $o['delay'] ), true, false ) . '> Load the Google tag after the visitor\'s first touch or scroll (or 5 seconds). Faster pages; conversions are still counted.</label></td></tr>';
		echo '<tr><th>Remarketing</th><td><label><input type="checkbox" name="remarket" value="1"' . checked( $o['remarket'], 1, false ) . '> Let Google show ads again to visitors (needs a cookie notice)</label></td></tr>';
		echo '<tr><th>Guides in the page feed</th><td><label><input type="checkbox" name="feed_posts" value="1"' . checked( $o['feed_posts'], 1, false ) . '> Include blog guides as well as pages</label></td></tr></table><p><button class="button button-primary">Save</button></p></form>';
		echo '<h2>2. Automatic page feed</h2><p>Copy this address. In Google Ads: Assets > Page feeds (or Performance Max > Page feed) > Scheduled upload > paste it, set Daily. It lists only pages with enough text and updates itself.</p><p><input readonly class="large-text" onclick="this.select()" value="' . esc_attr( self::feed_url() ) . '"></p>';
		echo '<h2>3. Readiness check</h2><ul>';
		foreach ( $chk as $c ) {
			echo '<li>' . ( $c[1] ? '&#9989; ' : '&#10060; ' ) . esc_html( $c[0] ) . '</li>';
		}
		echo '</ul>';
		self::assets();
		do_action( 'mrsh_gads_after' );
		echo '<h2>5. Suggested two month plan</h2><ol><li>Performance Max or Dynamic Search Ads with the page feed (Google writes ads from your pages).</li><li>Target Pakistan; add the cities where most members live.</li><li>Goal: sign-up. Start with a small daily budget, then raise it on the days with the lowest cost per sign-up.</li><li>Keep the homepage, add-profile page and safe-meeting guide as the main landing pages.</li></ol>';
		if ( class_exists( 'MRSH_AdsTools' ) ) {
			MRSH_AdsTools::panel( 'gads' );
		}
		echo '<p class="description">Ads policy: no guarantees of a match, no fake stories or photos. The site already follows this.</p></div>';
	}
}

MRSH_Gads::init();
