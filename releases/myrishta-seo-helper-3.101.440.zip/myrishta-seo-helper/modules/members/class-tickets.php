<?php
/**
 * Support tickets.
 *  - A member or visitor fills the form ([mrsh_support]) or emails the support mailbox: a ticket is created.
 *  - The sender gets an email with the ticket number and the promise "within 48 hours" (the hours can be changed).
 *  - The admin answers from Tickets in the admin menu; the answer is emailed to the sender, who can simply reply.
 *  - Emails to the support mailbox are read over IMAP every 5 minutes (no PHP IMAP extension needed).
 * All mail goes through MRSH_Mailq, so it is retried and rate limited.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Tickets {

	const OPT   = 'mrsh_tk_set';
	const DBV   = 'mrsh_tk_db';
	const SLUG  = 'mrsh-tickets';
	const CRON  = 'mrsh_tk_poll';

	public static function defaults() {
		return array(
			'hours'   => 48,
			'mailbox' => 'support@myrishta.pk',
			'host'    => 'imap.hostinger.com',
			'port'    => 993,
			'pass'    => '',
			'imap'    => 0,
			'autoclose' => 5,
			'notify'  => '',
			'last'    => 0,
			'lastmsg' => '',
			'ignore'  => "facebookmail.com\nfacebook.com\ninstagram.com\nlinkedin.com\ntwitter.com\nx.com\nyoutube.com\ngoogle.com\naccounts.google.com\ntiktok.com\npinterest.com\nhostinger.com\nmetricool.com",
		);
	}

	public static function get() {
		$o = get_option( self::OPT, array() );
		$o = array_merge( self::defaults(), is_array( $o ) ? $o : array() );
		if ( defined( 'MRSH_TK_PASS' ) && MRSH_TK_PASS ) {
			$o['pass'] = MRSH_TK_PASS;
		}
		return $o;
	}

	private static function put( $k, $v ) {
		$o       = get_option( self::OPT, array() );
		$o       = is_array( $o ) ? $o : array();
		$o[ $k ] = $v;
		update_option( self::OPT, $o, false );
	}

	public static function t1() {
		global $wpdb;
		return $wpdb->prefix . 'mrsh_tickets';
	}

	public static function t2() {
		global $wpdb;
		return $wpdb->prefix . 'mrsh_ticket_msgs';
	}

	public static function init() {
		add_filter( 'cron_schedules', function ( $s ) {
			if ( ! isset( $s['mrsh_5min'] ) ) {
				$s['mrsh_5min'] = array( 'interval' => 300, 'display' => 'Every 5 minutes' );
			}
			return $s;
		} );
		add_action( 'init', array( __CLASS__, 'install' ), 5 );
		add_shortcode( 'mrsh_support', array( __CLASS__, 'shortcode' ) );
		add_action( 'admin_post_nopriv_mrsh_tk_new', array( __CLASS__, 'public_new' ) );
		add_action( 'admin_post_mrsh_tk_new', array( __CLASS__, 'public_new' ) );
		add_action( self::CRON, array( __CLASS__, 'tick' ), 5 );
		add_action( self::CRON, array( __CLASS__, 'poll' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
		if ( is_admin() ) {
			add_action( 'admin_menu', array( __CLASS__, 'menu' ), 20 );
			add_action( 'admin_post_mrsh_tk_act', array( __CLASS__, 'act' ) );
			add_action( 'admin_post_mrsh_tk_csv', array( __CLASS__, 'csv' ) );
		}
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::CRON ) ) {
			wp_schedule_event( time() + 120, 'mrsh_5min', self::CRON );
		}
	}

	public static function install() {
		if ( (int) get_option( self::DBV, 0 ) >= 1 ) {
			return;
		}
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$cs = $wpdb->get_charset_collate();
		dbDelta( 'CREATE TABLE ' . self::t1() . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(120) NOT NULL DEFAULT '',
			email VARCHAR(190) NOT NULL DEFAULT '',
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			subject VARCHAR(250) NOT NULL DEFAULT '',
			category VARCHAR(40) NOT NULL DEFAULT '',
			status VARCHAR(12) NOT NULL DEFAULT 'open',
			priority VARCHAR(8) NOT NULL DEFAULT 'normal',
			source VARCHAR(10) NOT NULL DEFAULT 'form',
			created INT UNSIGNED NOT NULL DEFAULT 0,
			updated INT UNSIGNED NOT NULL DEFAULT 0,
			due INT UNSIGNED NOT NULL DEFAULT 0,
			answered INT UNSIGNED NOT NULL DEFAULT 0,
			warned TINYINT NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			KEY status (status),
			KEY email (email)
		) $cs;" );
		dbDelta( 'CREATE TABLE ' . self::t2() . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			ticket_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			who VARCHAR(8) NOT NULL DEFAULT 'user',
			body MEDIUMTEXT NULL,
			mid VARCHAR(190) NOT NULL DEFAULT '',
			created INT UNSIGNED NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			KEY ticket_id (ticket_id),
			KEY mid (mid)
		) $cs;" );
		update_option( self::DBV, 1, false );
	}

	public static function code( $id ) {
		return 'MR-' . ( 1000 + (int) $id );
	}

	private static function id_from_code( $s ) {
		if ( preg_match( '/MR-(\d{4,7})/i', (string) $s, $m ) ) {
			return max( 0, (int) $m[1] - 1000 );
		}
		return 0;
	}

	private static function clean_line( $s ) {
		return trim( preg_replace( '/[\r\n\t]+/', ' ', wp_strip_all_tags( (string) $s ) ) );
	}

	/* ---------- mail helpers ---------- */

	private static function mailbox() {
		$m = self::get()['mailbox'];
		return is_email( $m ) ? $m : 'support@myrishta.pk';
	}

	private static function queue( $to, $subject, $body, $kind = 'ticket' ) {
		$hdr = array( 'Reply-To: My Rishta Support <' . self::mailbox() . '>', 'Auto-Submitted: auto-generated' );
		if ( 'ticket_staff' === $kind ) {
			$hdr = array( 'Reply-To: My Rishta Support <' . self::mailbox() . '>' );
		}
		if ( class_exists( 'MRSH_Mailq' ) ) {
			return (bool) MRSH_Mailq::add( $to, $subject, $body, array( 'kind' => $kind, 'headers' => $hdr ) );
		}
		return wp_mail( $to, $subject, $body, $hdr );
	}

	private static function sig() {
		return "\n\n--\nMy Rishta Pakistan Support\n" . home_url( '/' ) . "\nNever send money to anyone you meet online.";
	}

	/* ---------- creating tickets ---------- */

	public static function create( $name, $email, $subject, $body, $source = 'form', $cat = '', $uid = 0 ) {
		global $wpdb;
		self::install();
		$now  = time();
		$hrs  = max( 1, (int) self::get()['hours'] );
		$ok   = $wpdb->insert( self::t1(), array(
			'name'     => mb_substr( self::clean_line( $name ), 0, 120 ),
			'email'    => sanitize_email( $email ),
			'user_id'  => (int) $uid,
			'subject'  => mb_substr( self::clean_line( $subject ), 0, 240 ) ?: 'Support request',
			'category' => mb_substr( sanitize_key( $cat ), 0, 40 ),
			'status'   => 'open',
			'priority' => 'normal',
			'source'   => $source,
			'created'  => $now,
			'updated'  => $now,
			'due'      => $now + $hrs * HOUR_IN_SECONDS,
		) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		if ( ! $ok ) {
			return 0;
		}
		$id = (int) $wpdb->insert_id;
		delete_transient( 'mrsh_cnt' );
		self::add_msg( $id, 'user', $body );
		if ( ( ! class_exists( 'MRSH_Switch' ) || MRSH_Switch::on( 'tk_auto' ) ) && preg_match( '/\b(fraud|scam|cheat(ed|ing)?|police|fia|cyber ?crime|blackmail|harass(ed|ment)?|threat(en|ened|s)?|court|lawyer|legal action|refund|stolen|fake profile|hacked)\b/i', $subject . ' ' . $body ) ) {
			$wpdb->update( self::t1(), array( 'priority' => 'high' ), array( 'id' => $id ) ); // phpcs:ignore WordPress.DB
			self::add_msg( $id, 'system', 'Marked high priority automatically: the message contains a serious word (fraud, police, threat, refund and similar).' );
		}
		$t  = self::row( $id );
		$cd = self::code( $id );
		self::queue(
			$t->email,
			'[' . $cd . '] We received your message',
			"Hello " . ( $t->name ?: '' ) . ",\n\nThank you for contacting My Rishta Pakistan. Your support ticket number is " . $cd . ".\n\nWe will solve it within " . $hrs . " hours. You do not need to send it again.\n\nTo add more details, just reply to this email and keep the number " . $cd . " in the subject.\n\nYour message:\n" . wp_trim_words( $body, 60 ) . self::sig()
		);
		$nt = self::get()['notify'];
		$nt = is_email( $nt ) ? $nt : get_option( 'admin_email' );
		if ( is_email( $nt ) ) {
			self::queue( $nt, '[' . $cd . '] New ticket: ' . $t->subject, "A new support ticket arrived.\n\nFrom: " . $t->name . ' <' . $t->email . ">\nSubject: " . $t->subject . "\nVia: " . $source . "\nDue: " . wp_date( 'j M Y H:i', (int) $t->due ) . "\n\n" . wp_trim_words( $body, 80 ) . "\n\nOpen it: " . admin_url( 'admin.php?page=' . self::SLUG . '&t=' . $id ), 'ticket_admin' );
		}
		return $id;
	}

	public static function add_msg( $tid, $who, $body, $mid = '' ) {
		global $wpdb;
		$wpdb->insert( self::t2(), array(
			'ticket_id' => (int) $tid,
			'who'       => $who,
			'body'      => mb_substr( (string) $body, 0, 20000 ),
			'mid'       => mb_substr( (string) $mid, 0, 190 ),
			'created'   => time(),
		) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->update( self::t1(), array( 'updated' => time() ), array( 'id' => (int) $tid ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		if ( 'user' === $who ) {
			self::kick();
		}
	}

	/** A member just wrote: run the robots again in about a minute instead of waiting for the next 5-minute round. */
	public static function kick() {
		$n = wp_next_scheduled( self::CRON );
		if ( ! $n || $n > time() + 75 ) {
			wp_schedule_single_event( time() + 60, self::CRON );
		}
	}

	public static function row( $id ) {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::t1() . ' WHERE id=%d', $id ) ); // phpcs:ignore WordPress.DB
	}

	/* ---------- public form ---------- */

	public static function shortcode() {
		$u    = wp_get_current_user();
		$done = isset( $_GET['tk'] ) ? sanitize_text_field( wp_unslash( $_GET['tk'] ) ) : ''; // phpcs:ignore
		$err  = isset( $_GET['tkerr'] ) ? sanitize_text_field( wp_unslash( $_GET['tkerr'] ) ) : ''; // phpcs:ignore
		$hrs  = max( 1, (int) self::get()['hours'] );
		ob_start();
		echo '<div class="mrsh-tk" style="max-width:640px;margin:0 auto">';
		if ( $done ) {
			echo '<div style="padding:16px;border-radius:12px;background:#ecfdf5;border:1px solid #a7f3d0"><b>Thank you. Your ticket number is ' . esc_html( $done ) . '.</b><br>We will solve it within ' . (int) $hrs . ' hours. We also sent this number to your email (check spam if you do not see it).</div>';
		} else {
			if ( $err ) {
				echo '<div style="padding:12px;border-radius:12px;background:#fef3f2;border:1px solid #fda29b;margin-bottom:12px">' . esc_html( $err ) . '</div>';
			}
			echo '<p>Tell us what you need. We reply within ' . (int) $hrs . ' hours.</p>';
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:grid;gap:10px">';
			echo '<input type="hidden" name="action" value="mrsh_tk_new">';
			wp_nonce_field( 'mrsh_tk_new', '_tk' );
			echo '<input type="text" name="website" value="" tabindex="-1" autocomplete="off" style="position:absolute;left:-9999px" aria-hidden="true">';
			echo '<label>Your name<br><input type="text" name="name" required maxlength="100" value="' . esc_attr( $u->exists() ? $u->display_name : '' ) . '" style="width:100%;padding:10px;border:1px solid #d1d5db;border-radius:10px"></label>';
			echo '<label>Your email<br><input type="email" name="email" required maxlength="150" value="' . esc_attr( $u->exists() ? $u->user_email : '' ) . '" style="width:100%;padding:10px;border:1px solid #d1d5db;border-radius:10px"></label>';
			echo '<label>What is it about?<br><select name="cat" style="width:100%;padding:10px;border:1px solid #d1d5db;border-radius:10px"><option value="account">My account or password</option><option value="profile">My profile or photo</option><option value="plan">Membership plan or payment</option><option value="report">Report a profile or a scam</option><option value="other">Something else</option></select></label>';
			echo '<label>Subject<br><input type="text" name="subject" required maxlength="150" style="width:100%;padding:10px;border:1px solid #d1d5db;border-radius:10px"></label>';
			echo '<label>Your message<br><textarea name="message" rows="6" required maxlength="5000" style="width:100%;padding:10px;border:1px solid #d1d5db;border-radius:10px"></textarea></label>';
			if ( class_exists( 'MRSH_Captcha' ) ) {
				MRSH_Captcha::widget();
			}
			echo '<button type="submit" style="padding:12px 20px;border:0;border-radius:12px;background:#e11d74;color:#fff;font-weight:700;cursor:pointer">Send</button>';
			echo '</form>';
		}
		if ( is_user_logged_in() ) {
			global $wpdb;
			$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT id,subject,status,created FROM ' . self::t1() . ' WHERE user_id=%d OR email=%s ORDER BY id DESC LIMIT 10', $u->ID, $u->user_email ) ); // phpcs:ignore WordPress.DB
			if ( $rows ) {
				echo '<h3 style="margin-top:24px">Your tickets</h3><ul>';
				foreach ( $rows as $r ) {
					echo '<li><b>' . esc_html( self::code( $r->id ) ) . '</b> ' . esc_html( $r->subject ) . ' - ' . esc_html( self::status_label( $r->status ) ) . ' (' . esc_html( wp_date( 'j M Y', (int) $r->created ) ) . ')</li>';
				}
				echo '</ul>';
			}
		}
		echo '</div>';
		return ob_get_clean();
	}

	public static function public_new() {
		$back = wp_get_referer() ? remove_query_arg( array( 'tk', 'tkerr' ), wp_get_referer() ) : home_url( '/' );
		if ( ! isset( $_POST['_tk'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_tk'] ) ), 'mrsh_tk_new' ) ) {
			wp_safe_redirect( add_query_arg( 'tkerr', rawurlencode( 'The page expired. Please reload and send again.' ), $back ) );
			exit;
		}
		if ( class_exists( 'MRSH_Master' ) && ! MRSH_Master::on( 'ticket_form' ) ) {
			wp_safe_redirect( add_query_arg( 'tkerr', rawurlencode( 'Tickets are switched off right now. Please email us instead.' ), $back ) );
			exit;
		}
		if ( class_exists( 'MRSH_Captcha' ) && ! MRSH_Captcha::ok() ) {
			wp_safe_redirect( add_query_arg( 'tkerr', rawurlencode( 'Please tick "I am not a robot" and send again.' ), $back ) );
			exit;
		}
		if ( ! empty( $_POST['website'] ) ) { // honeypot
			wp_safe_redirect( $back );
			exit;
		}
		$name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		$mail = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		$sub  = isset( $_POST['subject'] ) ? sanitize_text_field( wp_unslash( $_POST['subject'] ) ) : '';
		$msg  = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';
		$cat  = isset( $_POST['cat'] ) ? sanitize_key( wp_unslash( $_POST['cat'] ) ) : '';
		if ( ! is_email( $mail ) || strlen( $msg ) < 10 || '' === $sub || '' === $name ) {
			wp_safe_redirect( add_query_arg( 'tkerr', rawurlencode( 'Please fill every box with a real email address and a message of at least 10 characters.' ), $back ) );
			exit;
		}
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		$k1 = 'mrsh_tk_ip_' . md5( $ip );
		$k2 = 'mrsh_tk_em_' . md5( strtolower( $mail ) );
		if ( (int) get_transient( $k1 ) >= 5 || (int) get_transient( $k2 ) >= 3 ) {
			wp_safe_redirect( add_query_arg( 'tkerr', rawurlencode( 'Too many messages in a short time. Please wait an hour and try again.' ), $back ) );
			exit;
		}
		set_transient( $k1, (int) get_transient( $k1 ) + 1, HOUR_IN_SECONDS );
		set_transient( $k2, (int) get_transient( $k2 ) + 1, HOUR_IN_SECONDS );
		$id = self::create( $name, $mail, $sub, $msg, is_user_logged_in() ? 'member' : 'form', $cat, get_current_user_id() );
		if ( ! $id ) {
			wp_safe_redirect( add_query_arg( 'tkerr', rawurlencode( 'Sorry, something went wrong. Please email ' . self::mailbox() . ' instead.' ), $back ) );
			exit;
		}
		wp_safe_redirect( add_query_arg( 'tk', rawurlencode( self::code( $id ) ), $back ) );
		exit;
	}

	/* ---------- reading the support mailbox (IMAP) ---------- */

	private static function imap_cmd( $fp, &$n, $cmd, &$lit ) {
		$n++;
		$tag = 'A' . $n;
		fwrite( $fp, $tag . ' ' . $cmd . "\r\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$out = '';
		$lit = array();
		while ( ! feof( $fp ) ) {
			$line = fgets( $fp, 8192 ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			if ( false === $line ) {
				break;
			}
			if ( 0 === strpos( $line, $tag . ' ' ) ) {
				return array( preg_match( '/^' . $tag . ' OK/i', $line ) ? true : false, $out . $line );
			}
			if ( preg_match( '/\{(\d+)\}\r?\n$/', $line, $m ) ) {
				$size = (int) $m[1];
				$buf  = '';
				while ( strlen( $buf ) < $size && ! feof( $fp ) ) {
					$chunk = fread( $fp, min( 8192, $size - strlen( $buf ) ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
					if ( false === $chunk || '' === $chunk ) {
						break;
					}
					$buf .= $chunk;
				}
				if ( $size <= 1500000 ) {
					$lit[] = $buf;
				} else {
					$lit[] = '';
				}
				$out .= $line;
				continue;
			}
			$out .= $line;
		}
		return array( false, $out );
	}

	/** Returns array( ok(bool), message(string), mails(array of raw strings) ). */
	private static function imap_fetch( $limit, $mark ) {
		$s = self::get();
		if ( '' === $s['pass'] || ! is_email( $s['mailbox'] ) ) {
			return array( false, 'The mailbox password is not saved yet.', array() );
		}
		$en = 0;
		$es = '';
		$fp = @stream_socket_client( 'ssl://' . $s['host'] . ':' . (int) $s['port'], $en, $es, 12, STREAM_CLIENT_CONNECT ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
		if ( ! $fp ) {
			return array( false, 'Could not connect to ' . $s['host'] . ':' . (int) $s['port'] . ' (' . $es . ').', array() );
		}
		stream_set_timeout( $fp, 15 );
		fgets( $fp, 4096 ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		$n   = 0;
		$lit = array();
		list( $ok, $r ) = self::imap_cmd( $fp, $n, 'LOGIN "' . addcslashes( $s['mailbox'], "\\\"" ) . '" "' . addcslashes( $s['pass'], "\\\"" ) . '"', $lit );
		if ( ! $ok ) {
			fclose( $fp ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			return array( false, 'Login refused by the mail server. If this mailbox has 2-step login, create an app password in Hostinger and use it here.', array() );
		}
		list( $ok, $r ) = self::imap_cmd( $fp, $n, 'SELECT INBOX', $lit );
		if ( ! $ok ) {
			fclose( $fp ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			return array( false, 'Could not open the inbox.', array() );
		}
		list( $ok, $r ) = self::imap_cmd( $fp, $n, 'UID SEARCH UNSEEN', $lit );
		$uids = array();
		if ( $ok && preg_match( '/\* SEARCH([0-9 ]*)/', $r, $m ) ) {
			$uids = array_values( array_filter( array_map( 'intval', preg_split( '/\s+/', trim( $m[1] ) ) ) ) );
		}
		$total = count( $uids );
		$mails = array();
		foreach ( array_slice( $uids, 0, $limit ) as $uid ) {
			list( $ok, $r ) = self::imap_cmd( $fp, $n, 'UID FETCH ' . $uid . ' (BODY.PEEK[])', $lit );
			if ( $ok && ! empty( $lit[0] ) ) {
				$mails[] = array( $uid, $lit[0] );
			}
			if ( $mark ) {
				self::imap_cmd( $fp, $n, 'UID STORE ' . $uid . ' +FLAGS (\\Seen)', $lit );
			}
		}
		self::imap_cmd( $fp, $n, 'LOGOUT', $lit );
		fclose( $fp ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		return array( true, $total . ' unread in the mailbox.', $mails );
	}

	private static function dec_header( $v ) {
		$v = preg_replace( "/\r?\n[ \t]+/", ' ', (string) $v );
		if ( function_exists( 'iconv_mime_decode' ) ) {
			$d = @iconv_mime_decode( $v, 2, 'UTF-8' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			if ( false !== $d ) {
				return trim( $d );
			}
		}
		return trim( $v );
	}

	private static function split_mime( $raw ) {
		$raw = str_replace( "\r\n", "\n", $raw );
		$p   = strpos( $raw, "\n\n" );
		if ( false === $p ) {
			return array( array(), $raw );
		}
		$head = substr( $raw, 0, $p );
		$body = substr( $raw, $p + 2 );
		$head = preg_replace( "/\n[ \t]+/", ' ', $head );
		$h    = array();
		foreach ( explode( "\n", $head ) as $line ) {
			if ( false !== ( $c = strpos( $line, ':' ) ) ) { // phpcs:ignore WordPress.CodeAnalysis.AssignmentInCondition
				$k = strtolower( trim( substr( $line, 0, $c ) ) );
				if ( ! isset( $h[ $k ] ) ) {
					$h[ $k ] = trim( substr( $line, $c + 1 ) );
				}
			}
		}
		return array( $h, $body );
	}

	private static function decode_part( $h, $body ) {
		$enc = strtolower( $h['content-transfer-encoding'] ?? '' );
		if ( 'base64' === $enc ) {
			$body = base64_decode( $body ); // phpcs:ignore
		} elseif ( 'quoted-printable' === $enc ) {
			$body = quoted_printable_decode( $body );
		}
		$ct = $h['content-type'] ?? '';
		if ( preg_match( '/charset="?([\w\-]+)/i', $ct, $m ) && 0 !== strcasecmp( $m[1], 'utf-8' ) && function_exists( 'mb_convert_encoding' ) ) {
			$c = @mb_convert_encoding( $body, 'UTF-8', $m[1] ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
			if ( false !== $c ) {
				$body = $c;
			}
		}
		return $body;
	}

	private static function text_of( $h, $body, $depth = 0 ) {
		$ct = strtolower( $h['content-type'] ?? 'text/plain' );
		if ( 0 === strpos( $ct, 'multipart/' ) && $depth < 4 && preg_match( '/boundary="?([^";]+)"?/i', $h['content-type'] ?? '', $m ) ) {
			$plain = '';
			$html  = '';
			foreach ( explode( '--' . $m[1], $body ) as $part ) {
				$part = ltrim( $part, "\n" );
				if ( '' === trim( $part ) || 0 === strpos( $part, '--' ) ) {
					continue;
				}
				list( $ph, $pb ) = self::split_mime( $part );
				$pct = strtolower( $ph['content-type'] ?? 'text/plain' );
				if ( false !== strpos( strtolower( $ph['content-disposition'] ?? '' ), 'attachment' ) ) {
					continue;
				}
				$t = self::text_of( $ph, $pb, $depth + 1 );
				if ( 0 === strpos( $pct, 'text/html' ) ) {
					$html .= $t;
				} elseif ( '' !== trim( $t ) ) {
					$plain .= $t;
				}
			}
			return '' !== trim( $plain ) ? $plain : $html;
		}
		$t = self::decode_part( $h, $body );
		if ( false !== strpos( $ct, 'text/html' ) ) {
			$t = wp_strip_all_tags( preg_replace( '#<(br|/p|/div|/li|/h[1-6])[^>]*>#i', "\n", $t ) );
			$t = html_entity_decode( $t, ENT_QUOTES, 'UTF-8' );
		} elseif ( 0 !== strpos( $ct, 'text/' ) ) {
			return '';
		}
		return $t;
	}

	private static function strip_quote( $t ) {
		$t   = str_replace( "\r", '', $t );
		$out = array();
		foreach ( explode( "\n", $t ) as $l ) {
			if ( preg_match( '/^(On .{5,120}wrote:|-{2,}\s*Original Message|From:\s.+@.+|_{5,})/i', trim( $l ) ) ) {
				break;
			}
			if ( '>' === substr( ltrim( $l ), 0, 1 ) ) {
				continue;
			}
			$out[] = $l;
		}
		$s = trim( implode( "\n", $out ) );
		$s = preg_replace( "/\n{3,}/", "\n\n", $s );
		return mb_substr( $s, 0, 6000 );
	}

	/** True when the sender's address or domain is on the ignore list in the settings. */
	private static function ignored( $addr ) {
		$dom = substr( strrchr( $addr, '@' ), 1 );
		foreach ( preg_split( '/[\s,]+/', strtolower( (string) self::get()['ignore'] ) ) as $x ) {
			$x = trim( $x );
			if ( '' === $x ) {
				continue;
			}
			if ( $x === $addr || $x === $dom || ( '' !== $dom && substr( $dom, -strlen( '.' . $x ) ) === '.' . $x ) ) {
				return true;
			}
		}
		return false;
	}

	private static function handle_mail( $raw ) {
		global $wpdb;
		list( $h, $body ) = self::split_mime( $raw );
		$from = self::dec_header( $h['from'] ?? '' );
		if ( ! preg_match( '/([A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,})/i', $from, $m ) ) {
			return 'skip';
		}
		$addr = strtolower( $m[1] );
		$nm   = trim( preg_replace( '/<[^>]*>/', '', $from ), " \"'" );
		$auto = strtolower( ( $h['auto-submitted'] ?? 'no' ) );
		$prec = strtolower( ( $h['precedence'] ?? '' ) );
		if ( isset( $h['list-unsubscribe'] ) || isset( $h['list-id'] ) || self::ignored( $addr ) || preg_match( '/^(notification|notifications|notify|news|newsletter|info|updates|alerts?|mailer|bounce|donotreply|do-not-reply|no_reply)[+.\-_@]/i', $addr ) || ( 'no' !== $auto && '' !== $auto ) || in_array( $prec, array( 'bulk', 'junk', 'list' ), true ) || isset( $h['x-autoreply'] ) || preg_match( '/mailer-daemon|postmaster|no-?reply@/i', $addr ) || strtolower( $addr ) === strtolower( self::mailbox() ) ) {
			return 'skip';
		}
		$subj = self::dec_header( $h['subject'] ?? '' );
		$mid  = trim( (string) ( $h['message-id'] ?? '' ), '<> ' );
		if ( $mid && (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . self::t2() . ' WHERE mid=%s', $mid ) ) ) { // phpcs:ignore WordPress.DB
			return 'skip';
		}
		$text = self::strip_quote( self::text_of( $h, $body ) );
		if ( '' === $text ) {
			$text = '(no text in the email)';
		}
		$tid = self::id_from_code( $subj );
		$t   = $tid ? self::row( $tid ) : null;
		if ( $t && strtolower( $t->email ) === $addr ) {
			self::add_msg( $tid, 'user', $text, $mid );
			$wpdb->update( self::t1(), array( 'status' => 'open', 'warned' => 0, 'due' => time() + max( 1, (int) self::get()['hours'] ) * HOUR_IN_SECONDS ), array( 'id' => $tid ) ); // phpcs:ignore WordPress.DB
			delete_transient( 'mrsh_cnt' );
			return 'reply';
		}
		$u  = get_user_by( 'email', $addr );
		$id = self::create( $nm ?: $addr, $addr, preg_replace( '/^(re|fw|fwd):\s*/i', '', $subj ), $text, 'email', 'email', $u ? $u->ID : 0 );
		if ( $id && $mid ) {
			$wpdb->update( self::t2(), array( 'mid' => mb_substr( $mid, 0, 190 ) ), array( 'ticket_id' => $id ) ); // phpcs:ignore WordPress.DB
		}
		return $id ? 'new' : 'skip';
	}

	public static function poll( $manual = false ) {
		$s = self::get();
		if ( ! $manual && empty( $s['imap'] ) ) {
			return null;
		}
		if ( get_transient( 'mrsh_tk_lock' ) ) {
			return null;
		}
		set_transient( 'mrsh_tk_lock', 1, 120 );
		list( $ok, $msg, $mails ) = self::imap_fetch( 10, true );
		$new = 0;
		$rep = 0;
		foreach ( $mails as $mm ) {
			$r = self::handle_mail( $mm[1] );
			if ( 'new' === $r ) {
				$new++;
			} elseif ( 'reply' === $r ) {
				$rep++;
			}
		}
		self::put( 'last', time() );
		self::put( 'lastmsg', ( $ok ? 'OK. ' : 'Problem: ' ) . $msg . ( $ok ? ' New tickets: ' . $new . ', replies added: ' . $rep . '.' : '' ) );
		self::sla();
		delete_transient( 'mrsh_tk_lock' );
		return $ok ? array( $new, $rep, $msg ) : $msg;
	}

	/** Warn the admin once when an open ticket is 12 hours from its deadline or already late. */
	/** Tickets whose "remind me" time has come: reopen them and email the admin. */
	public static function remind_run() {
		$rem = get_option( 'mrsh_tk_rem', array() );
		if ( ! is_array( $rem ) || ! $rem ) {
			return;
		}
		global $wpdb;
		$ch = false;
		foreach ( $rem as $tid => $ts ) {
			if ( (int) $ts > time() ) {
				continue;
			}
			$t = self::row( (int) $tid );
			unset( $rem[ $tid ] );
			$ch = true;
			if ( ! $t || 'solved' === $t->status ) {
				continue;
			}
			$wpdb->update( self::t1(), array( 'status' => 'open' ), array( 'id' => (int) $tid ) ); // phpcs:ignore WordPress.DB
			self::add_msg( (int) $tid, 'system', 'Reminder: this ticket was reopened because the reminder time came.' );
			$nt = self::get()['notify'];
			$nt = is_email( $nt ) ? $nt : get_option( 'admin_email' );
			if ( is_email( $nt ) ) {
				self::queue( $nt, '[' . self::code( (int) $tid ) . '] Reminder: ' . $t->subject, 'Your reminder for this ticket is due.' . "\n\n" . admin_url( 'admin.php?page=' . self::SLUG . '&t=' . (int) $tid ) );
			}
		}
		if ( $ch ) {
			update_option( 'mrsh_tk_rem', $rem, false );
		}
	}

	private static function sla() {
		global $wpdb;
		self::remind_run();
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM " . self::t1() . " WHERE status IN ('open','progress') AND warned=0 AND due < %d LIMIT 20", time() + 12 * HOUR_IN_SECONDS ) ); // phpcs:ignore WordPress.DB
		$nt   = self::get()['notify'];
		$nt   = is_email( $nt ) ? $nt : get_option( 'admin_email' );
		foreach ( $rows as $r ) {
			if ( is_email( $nt ) ) {
				self::queue( $nt, '[' . self::code( $r->id ) . '] Deadline is close: ' . $r->subject, "This ticket is due " . wp_date( 'j M Y H:i', (int) $r->due ) . ".\n\nOpen it: " . admin_url( 'admin.php?page=' . self::SLUG . '&t=' . (int) $r->id ), 'ticket_admin' );
			}
			$wpdb->update( self::t1(), array( 'warned' => 1 ), array( 'id' => (int) $r->id ) ); // phpcs:ignore WordPress.DB
		}
	}

	/* ---------- admin ---------- */

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Tickets', 'Tickets', 'manage_options', self::SLUG, array( __CLASS__, 'page' ) );
	}

	public static function status_label( $s ) {
		$m = array( 'open' => 'Open', 'progress' => 'In progress', 'waiting' => 'Waiting for member', 'solved' => 'Solved' );
		return $m[ $s ] ?? ucfirst( (string) $s );
	}

	private static function due_text( $t ) {
		if ( 'solved' === $t->status ) {
			return 'Solved';
		}
		$d = (int) $t->due - time();
		return $d >= 0 ? 'Due in ' . human_time_diff( time(), (int) $t->due ) : 'LATE by ' . human_time_diff( (int) $t->due, time() );
	}

	const TPL = 'mrsh_tk_tpl';

	/** Ready-made templates. Placeholders: {name} member name, {ticket} ticket number, {site} site name, {hours} hours to solve. */
	public static function ready_templates() {
		return array(
			array( 'Thanks, solved', "Thank you for writing to us. We have looked into this and it is now solved. If you need anything else, just reply to this message.\n\nJazakallah khair." ),
			array( 'Need more details', "Thank you for contacting us. Please reply with a few more details (your profile name or number and a short description of the problem) so we can help you quickly." ),
			array( 'Delete my account', "Thank you for your message. Please visit our website and log in to your account. Under My account, open \"Delete my account\", enter your password and confirm. If you cannot log in, reply to this message from the same email address and we will remove the account for you." ),
			array( 'Profile approved', "Good news: your profile has been checked and approved. It is now visible on the website. Please keep your details and photo up to date for better replies." ),
			array( 'Photo problem', "Thank you for your profile. We could not accept your photo because it was not clear or did not follow our guidelines. Please upload a recent, clear photo of yourself and we will review it again." ),
			array( 'Payment proof received', "Thank you. We have received your payment proof and will check it shortly. Your plan will be updated as soon as it is confirmed." ),
			array( 'Plan activated', "Your payment is confirmed and your plan is now active. You can see it under My account. Thank you for supporting {site}." ),
			array( 'Payment proof unclear', "We could not confirm your payment because the proof is unclear or the details do not match. Please send a clear screenshot or photo showing the amount, date and transaction number, and we will check it again." ),
			array( 'How to create a profile', "Creating a profile is free and takes about 3 minutes. Log in, open Add profile, fill in your details, add a clear photo and press Submit. We check every profile before it is shown, usually within {hours} hours." ),
			array( 'Cannot log in', "Please use the Forgot password link on the login page and we will email you a new password link. Check your spam or junk folder too. If it still does not work, reply with the email address you registered with." ),
			array( 'How to get verified', "To get the verified badge, request verification from My account and send the clear photo or selfie we ask for. We check it privately and delete it after checking. Verified profiles get more trust from families." ),
			array( 'Hide my profile', "We have paused your profile at your request, so it is no longer shown. Reply to this message any time and we will show it again. Your details are kept private." ),
			array( 'Report received', "Thank you for telling us. We take reports seriously. We are checking the profile and will take action if it breaks our rules. Please do not share money or private details with anyone while we check." ),
			array( 'Never send money', "Please be careful: never send money to anyone you meet online, even if they say it is for a visa, a gift, a fee or an emergency. {site} is free and never asks for money for matches. If someone asked you for money, reply with their profile name and we will act." ),
			array( 'Phone numbers are private', "Your phone number is not shown to other members. Families contact you through the site, and you decide who gets your details. You can change what is shown from My account." ),
			array( 'Service is free', "{site} is a free rishta service. Basic profiles, messages and matches are free. Paid plans are optional and only add extra features. If someone asked you for money outside the site, please tell us." ),
			array( 'Change my details', "You can change your details yourself: log in, open My account, then Edit profile, and save. If a field is locked (for example your date of birth), reply with the correct value and a short reason and we will update it." ),
			array( 'Profile needs changes', "Thank you for your profile. We could not approve it yet. Please remove phone numbers, social media names or links from the text, check that the details are true, and save it again. We will review it right away." ),
			array( 'Sorry for the delay', "Sorry for the delay in replying. We are a small volunteer team and your message is important to us. We are working on it and will answer as soon as we can." ),
			array( 'Closing, no reply', "We have not heard back from you, so we are marking ticket {ticket} as solved. If you still need help, just reply to this message and we will open it again." ),
		);
	}

	/** Fast reply templates: array of array( title, text ). Placeholders: {name} {ticket} {site} {hours}. */
	public static function templates() {
		$t = get_option( self::TPL, null );
		if ( ! is_array( $t ) ) {
			$t = array_slice( self::ready_templates(), 0, 12 );
		}
		return $t;
	}

	/** Title of the template that probably fits this ticket, judged by its words. */
	public static function suggest( $t, $text = '' ) {
		$h   = strtolower( $t->subject . ' ' . $text );
		$map = array(
			'Delete my account'     => '/delete (my )?account|remove (my )?account|close (my )?account/',
			'Payment proof received' => '/payment|paid|jazzcash|easypaisa|bank transfer|receipt|screenshot of/',
			'Cannot log in'         => '/log ?in|password|cannot open|can\'t open|otp|code not/',
			'How to get verified'   => '/verif|blue tick|badge|selfie/',
			'Hide my profile'       => '/hide|pause|deactivate|disable (my )?profile/',
			'Photo problem'         => '/photo|picture|image/',
			'Report received'       => '/report|fake|fraud|scam|harass|abuse|blackmail/',
			'How to create a profile' => '/create (a )?profile|add profile|new profile|how (do|to)|register/',
			'Change my details'     => '/change|edit|update|wrong (age|city|name)/',
		);
		foreach ( $map as $title => $re ) {
			if ( preg_match( $re, $h ) ) {
				return $title;
			}
		}
		return '';
	}

	/** Fill the placeholders of a template for one ticket. */
	public static function fill( $text, $t ) {
		return str_replace( array( '{name}', '{ticket}', '{site}', '{hours}' ), array( $t && $t->name ? $t->name : 'there', $t ? self::code( $t->id ) : '', get_bloginfo( 'name' ), (int) self::get()['hours'] ), $text );
	}

	/** Runs every 5 minutes: closes tickets the member left unanswered for N days (once an hour). */
	public static function tick() {
		if ( get_transient( 'mrsh_tk_house' ) ) {
			return;
		}
		set_transient( 'mrsh_tk_house', 1, HOUR_IN_SECONDS );
		$days = (int) self::get()['autoclose'];
		if ( $days < 1 ) {
			return;
		}
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::t1() . " WHERE status='waiting' AND answered > 0 AND answered < %d AND updated < %d LIMIT 20", time() - $days * DAY_IN_SECONDS, time() - $days * DAY_IN_SECONDS ) ); // phpcs:ignore WordPress.DB
		foreach ( $rows as $r ) {
			$wpdb->update( self::t1(), array( 'status' => 'solved' ), array( 'id' => (int) $r->id ) ); // phpcs:ignore WordPress.DB
			self::add_msg( (int) $r->id, 'system', 'Closed automatically: the member did not reply for ' . $days . ' days.' );
			self::queue( $r->email, '[' . self::code( $r->id ) . '] Ticket closed', "Hello " . ( $r->name ?: '' ) . ",\n\nWe have not heard back from you, so we are marking ticket " . self::code( $r->id ) . " as solved. If you still need help, just reply to this email and we will open it again." . self::sig(), 'ticket_staff' );
		}
		if ( $rows ) {
			delete_transient( 'mrsh_cnt' );
		}
	}

	/** Download all tickets (or the current filter) as CSV. */
	public static function csv() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_tk_csv' );
		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT * FROM ' . self::t1() . ' ORDER BY id DESC LIMIT 5000' ); // phpcs:ignore WordPress.DB
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=tickets-' . gmdate( 'Y-m-d' ) . '.csv' );
		$o = fopen( 'php://output', 'w' );
		fwrite( $o, "\xEF\xBB\xBF" );
		fputcsv( $o, array( 'Ticket', 'Name', 'Email', 'Subject', 'Status', 'Priority', 'Via', 'Created', 'Answered' ) );
		foreach ( $rows as $r ) {
			fputcsv( $o, array( self::code( $r->id ), $r->name, $r->email, $r->subject, $r->status, $r->priority, $r->source, wp_date( 'Y-m-d H:i', (int) $r->created ), $r->answered ? wp_date( 'Y-m-d H:i', (int) $r->answered ) : '' ) );
		}
		fclose( $o ); // phpcs:ignore
		exit;
	}

	public static function act() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_tk_act' );
		global $wpdb;
		delete_transient( 'mrsh_cnt' );
		$do   = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
		$tid  = isset( $_POST['tid'] ) ? absint( $_POST['tid'] ) : 0;
		$back = admin_url( 'admin.php?page=' . self::SLUG );
		$msg  = 'Done.';
		if ( 'save_set' === $do ) {
			$s = get_option( self::OPT, array() );
			$s = is_array( $s ) ? $s : array();
			$s['hours']   = max( 1, min( 720, absint( $_POST['hours'] ?? 48 ) ) );
			$s['mailbox'] = sanitize_email( wp_unslash( $_POST['mailbox'] ?? '' ) );
			$s['host']    = sanitize_text_field( wp_unslash( $_POST['host'] ?? 'imap.hostinger.com' ) );
			$s['port']    = max( 1, min( 65535, absint( $_POST['port'] ?? 993 ) ) );
			$s['imap']    = empty( $_POST['imap'] ) ? 0 : 1;
			$s['autoclose'] = max( 0, min( 60, absint( $_POST['autoclose'] ?? 5 ) ) );
			$s['notify']  = sanitize_email( wp_unslash( $_POST['notify'] ?? '' ) );
			$s['ignore']  = isset( $_POST['ignore'] ) ? sanitize_textarea_field( wp_unslash( $_POST['ignore'] ) ) : '';
			$pw           = isset( $_POST['pass'] ) ? (string) wp_unslash( $_POST['pass'] ) : ''; // phpcs:ignore
			if ( '' !== $pw ) {
				$s['pass'] = $pw;
			}
			update_option( self::OPT, array_merge( self::defaults(), $s ), false );
			$msg = 'Settings saved.';
		} elseif ( 'check' === $do ) {
			$r   = self::poll( true );
			$msg = is_array( $r ) ? 'Mailbox read. New tickets: ' . $r[0] . ', replies added: ' . $r[1] . '. ' . $r[2] : ( $r ? (string) $r : 'Busy, try again in a minute.' );
		} elseif ( 'tpl_add' === $do ) {
			$ti = isset( $_POST['ttitle'] ) ? sanitize_text_field( wp_unslash( $_POST['ttitle'] ) ) : '';
			$tx = isset( $_POST['text'] ) ? sanitize_textarea_field( wp_unslash( $_POST['text'] ) ) : '';
			if ( '' === $ti || '' === trim( $tx ) ) {
				$msg = 'Write the reply text and give the template a name first.';
			} else {
				$all   = self::templates();
				$all[] = array( mb_substr( $ti, 0, 40 ), $tx );
				update_option( self::TPL, array_slice( $all, -40 ), false );
				$msg = 'Template saved.';
			}
			if ( $tid ) {
				$back = add_query_arg( 't', $tid, $back );
			}
		} elseif ( 'tpl_ready' === $do ) {
			$all   = self::templates();
			$have  = array_map( function ( $x ) {
				return strtolower( $x[0] );
			}, $all );
			$added = 0;
			foreach ( self::ready_templates() as $rt ) {
				if ( ! in_array( strtolower( $rt[0] ), $have, true ) && count( $all ) < 40 ) {
					$all[] = $rt;
					$added++;
				}
			}
			update_option( self::TPL, array_values( $all ), false );
			$msg = $added ? $added . ' ready template(s) added.' : 'All ready templates are already in your list.';
		} elseif ( 'tpl_edit' === $do ) {
			$all = self::templates();
			$i   = isset( $_POST['ti'] ) ? absint( $_POST['ti'] ) : -1;
			$ti  = isset( $_POST['ttitle'] ) ? sanitize_text_field( wp_unslash( $_POST['ttitle'] ) ) : '';
			$tx  = isset( $_POST['text'] ) ? sanitize_textarea_field( wp_unslash( $_POST['text'] ) ) : '';
			if ( isset( $all[ $i ] ) && '' !== $ti && '' !== trim( $tx ) ) {
				$all[ $i ] = array( mb_substr( $ti, 0, 40 ), $tx );
				update_option( self::TPL, array_values( $all ), false );
				$msg = 'Template saved.';
			} else {
				$msg = 'The name and text cannot be empty.';
			}
		} elseif ( 'bulk' === $do ) {
			$ids = isset( $_POST['ids'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['ids'] ) ) : array();
			$act = isset( $_POST['bulk'] ) ? sanitize_key( wp_unslash( $_POST['bulk'] ) ) : '';
			$n   = 0;
			foreach ( array_filter( $ids ) as $bid ) {
				if ( in_array( $act, array( 'open', 'progress', 'waiting', 'solved' ), true ) ) {
					$n += (int) $wpdb->update( self::t1(), array( 'status' => $act ), array( 'id' => $bid ) ); // phpcs:ignore WordPress.DB
				} elseif ( in_array( $act, array( 'high', 'normal' ), true ) ) {
					$n += (int) $wpdb->update( self::t1(), array( 'priority' => $act ), array( 'id' => $bid ) ); // phpcs:ignore WordPress.DB
				}
			}
			$msg = $n ? $n . ' ticket(s) updated.' : 'Tick some tickets and choose an action first.';
		} elseif ( 'tpl_del' === $do ) {
			$all = self::templates();
			$i   = isset( $_POST['ti'] ) ? absint( $_POST['ti'] ) : -1;
			if ( isset( $all[ $i ] ) ) {
				unset( $all[ $i ] );
				update_option( self::TPL, array_values( $all ), false );
				$msg = 'Template removed.';
			}
		} elseif ( $tid && self::row( $tid ) ) {
			$t = self::row( $tid );
			if ( 'reply' === $do || 'reply_solve' === $do || 'reply_wait' === $do ) {
				$text = isset( $_POST['text'] ) ? sanitize_textarea_field( wp_unslash( $_POST['text'] ) ) : '';
				if ( '' === trim( $text ) ) {
					$msg = 'Write a reply first.';
				} else {
					$text = self::fill( $text, $t );
					self::add_msg( $tid, 'staff', $text );
					$st = 'reply_solve' === $do ? 'solved' : ( 'reply_wait' === $do ? 'waiting' : 'progress' );
					$wpdb->update( self::t1(), array( 'status' => $st, 'answered' => time() ), array( 'id' => $tid ) ); // phpcs:ignore WordPress.DB
					self::queue( $t->email, '[' . self::code( $tid ) . '] Re: ' . $t->subject, "Hello " . ( $t->name ?: '' ) . ",\n\n" . $text . "\n\n" . ( 'solved' === $st ? "We have marked this ticket as solved. If you still need help, reply to this email and we will open it again." : "You can reply to this email to continue. Please keep " . self::code( $tid ) . " in the subject." ) . self::sig(), 'ticket_staff' );
					$msg = 'Reply queued for sending to ' . $t->email . '.';
				}
			} elseif ( 'note' === $do ) {
				$text = isset( $_POST['text'] ) ? sanitize_textarea_field( wp_unslash( $_POST['text'] ) ) : '';
				if ( '' !== trim( $text ) ) {
					self::add_msg( $tid, 'note', $text );
					$msg = 'Private note saved. The member does not see it.';
				}
			} elseif ( in_array( $do, array( 'open', 'progress', 'waiting', 'solved' ), true ) ) {
				$wpdb->update( self::t1(), array( 'status' => $do ), array( 'id' => $tid ) ); // phpcs:ignore WordPress.DB
				$msg = 'Status changed.';
			} elseif ( 'remind_1' === $do || 'remind_3' === $do || 'remind_7' === $do || 'remind_off' === $do ) {
				$rem = get_option( 'mrsh_tk_rem', array() );
				$rem = is_array( $rem ) ? $rem : array();
				if ( 'remind_off' === $do ) {
					unset( $rem[ $tid ] );
					$msg = 'Reminder removed.';
				} else {
					$rem[ $tid ] = time() + (int) substr( $do, 7 ) * DAY_IN_SECONDS;
					$msg = 'Reminder set for ' . wp_date( 'j M H:i', $rem[ $tid ] ) . '.';
				}
				update_option( 'mrsh_tk_rem', $rem, false );
			} elseif ( 'priority' === $do ) {
				$wpdb->update( self::t1(), array( 'priority' => 'high' === $t->priority ? 'normal' : 'high' ), array( 'id' => $tid ) ); // phpcs:ignore WordPress.DB
				$msg = 'Priority changed.';
			}
			$back = add_query_arg( 't', $tid, $back );
		}
		wp_safe_redirect( add_query_arg( 'msg', rawurlencode( $msg ), $back ) );
		exit;
	}

	/** Modern look for the ticket screens (scoped under .mx so nothing else changes). */
	private static function tk_css() {
		return '
.mx .tk-av{flex:none;width:40px;height:40px;border-radius:14px;display:grid;place-items:center;color:#fff;font-weight:700;font-size:15px;background:linear-gradient(135deg,#7c3aed,#e11d74)}
.mx .tk-av.sm{width:30px;height:30px;border-radius:10px;font-size:12px}
.mx .tk-st{display:inline-flex;align-items:center;gap:6px;border-radius:999px;padding:3px 11px;font-size:12px;font-weight:700;background:#eef0f6;color:#475569}
.mx .tk-st:before{content:"";width:7px;height:7px;border-radius:50%;background:currentColor}
.mx .tk-st.open{background:#fdf2f8;color:#be185d}.mx .tk-st.progress{background:#f3e8ff;color:#7e22ce}.mx .tk-st.waiting{background:#fffbeb;color:#b45309}.mx .tk-st.solved{background:#ecfdf5;color:#047857}
.mx .tk-due{display:inline-block;border-radius:999px;padding:3px 10px;font-size:12px;font-weight:700;background:#f1f5f9;color:#475569}.mx .tk-due.late{background:#fef2f2;color:#b91c1c}.mx .tk-due.ok{background:#ecfdf5;color:#047857}
.mx .tk-hi{display:inline-block;margin-left:6px;border-radius:999px;padding:2px 8px;font-size:11px;font-weight:800;background:#fee2e2;color:#b91c1c}
.mx .tk-tbl{display:grid;gap:10px;margin:12px 0}
.mx .tk-row{display:grid;grid-template-columns:28px minmax(0,1.2fr) minmax(0,2fr) auto auto auto;gap:14px;align-items:center;background:#fff;border-radius:18px;padding:12px 16px;box-shadow:0 1px 3px rgba(17,24,39,.07),0 0 0 1px rgba(17,24,39,.04);transition:box-shadow .15s,transform .15s}
.mx .tk-row:hover{box-shadow:0 8px 22px rgba(124,58,237,.14),0 0 0 1px #d8c6fb;transform:translateY(-1px)}
.mx .tk-row.late{box-shadow:0 1px 3px rgba(17,24,39,.07),0 0 0 1px #fecaca}
.mx .tk-who{display:flex;gap:10px;align-items:center;min-width:0}.mx .tk-who b,.mx .tk-sub b{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.mx .tk-who small,.mx .tk-sub small{display:block;color:#6b7280;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mx .tk-sub{min-width:0}
.mx .tk-head{display:flex;gap:14px;align-items:flex-start;flex-wrap:wrap}.mx .tk-head h2{margin:0 0 6px;font-size:20px;line-height:1.3;letter-spacing:-.01em}
.mx .tk-meta{display:flex;flex-wrap:wrap;gap:8px;align-items:center;color:#475569;font-size:13px}
.mx .tk-thread{display:flex;flex-direction:column;gap:14px;margin:18px 0}
.mx .tk-msg{display:flex;gap:10px;max-width:86%}.mx .tk-msg.staff{align-self:flex-end;flex-direction:row-reverse}.mx .tk-msg.system{align-self:center;max-width:100%}
.mx .tk-b{border-radius:18px;padding:12px 16px;line-height:1.55;background:#f5f3ff;color:#1f2937;min-width:0;overflow-wrap:anywhere}
.mx .tk-msg.staff .tk-b{background:linear-gradient(135deg,#ecfdf5,#e0f7ef);border-top-right-radius:6px}.mx .tk-msg.user .tk-b{border-top-left-radius:6px}
.mx .tk-msg.note .tk-b{background:#fffbeb;box-shadow:inset 0 0 0 1px #fde68a}
.mx .tk-msg.system .tk-b{background:#f1f5f9;color:#64748b;font-size:12.5px;padding:6px 14px;border-radius:999px}
.mx .tk-t{display:block;font-size:11.5px;color:#6b7280;margin-bottom:3px;font-weight:600}
.mx .tk-comp{margin-top:6px;border-radius:20px;background:#f8f7ff;padding:16px;box-shadow:inset 0 0 0 1px #e9e3ff}
.mx .tk-lbl{display:block;font-size:12px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;color:#7c3aed;margin:0 0 8px}
.mx .tk-chips{display:flex;gap:8px;overflow-x:auto;padding:2px 2px 10px;scrollbar-width:thin}
.mx .tk-chip{flex:none;border:0;cursor:pointer;border-radius:999px;padding:8px 14px;font-size:13px;font-weight:700;background:#fff;color:#4b5563;box-shadow:0 0 0 1px #ddd6fe;transition:all .15s}
.mx .tk-chip:hover{background:#f3e8ff;color:#7c3aed}.mx .tk-chip.sug{color:#fff;background:linear-gradient(135deg,#e11d74,#7c3aed);box-shadow:0 6px 16px rgba(124,58,237,.3)}
.mx .tk-ta{width:100%;min-height:130px;border:0;border-radius:16px;padding:14px 16px;font:inherit;line-height:1.55;background:#fff;box-shadow:0 0 0 1px #ddd6fe;resize:vertical}.mx .tk-ta:focus{outline:0;box-shadow:0 0 0 2px #7c3aed}
.mx .tk-bar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:12px 0 0}
.mx .tk-bar input[type=text]{height:36px;border-radius:11px;border:1px solid #d9dbe8;padding:0 12px;width:170px}
.mx .mx-tabs input[type=search],.mx .mx-tabs select{height:38px;border-radius:11px;border:1px solid #d9dbe8;padding:0 12px;background:#fff;font:inherit;font-size:13px;min-width:0}
.mx .tk-sec{display:flex;flex-wrap:wrap;gap:8px 18px;margin-top:14px;padding-top:14px;border-top:1px dashed #ddd6fe}.mx .tk-sec>div{display:flex;flex-wrap:wrap;gap:6px;align-items:center}.mx .tk-sec b{font-size:12px;color:#6b7280;text-transform:uppercase;letter-spacing:.05em;margin-right:4px}
@media(max-width:900px){.mx .tk-row{grid-template-columns:24px minmax(0,1fr) auto;grid-template-areas:"c w b" "c s s" "c d a"}.mx .tk-row>:nth-child(1){grid-area:c;align-self:start;margin-top:10px}.mx .tk-row>:nth-child(2){grid-area:w}.mx .tk-row>:nth-child(3){grid-area:s}.mx .tk-row>:nth-child(4){grid-area:b}.mx .tk-row>:nth-child(5){grid-area:d}.mx .tk-row>:nth-child(6){grid-area:a;justify-self:end}.mx .tk-msg{max-width:100%}}
';
	}

	private static function initials( $name ) {
		$name = trim( (string) $name );
		if ( '' === $name ) {
			return '?';
		}
		$p = preg_split( '/\s+/', $name );
		return strtoupper( mb_substr( $p[0], 0, 1 ) . ( isset( $p[1] ) ? mb_substr( $p[1], 0, 1 ) : '' ) );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		self::install();
		if ( ! class_exists( 'MRSH_Boost' ) ) {
			echo '<div class="wrap"><h1>Tickets</h1><p>The page styles are missing. Reinstall the plugin zip.</p></div>';
			return;
		}
		global $wpdb;
		MRSH_Boost::ui_open( 'Tickets', 'Every email or form message from a member becomes a ticket with a number and a ' . (int) self::get()['hours'] . ' hour deadline. Reply here and the answer is emailed to the member.', 'g-blue', 'M4 4h16v4a2 2 0 0 0 0 4v4H4v-4a2 2 0 0 0 0-4zm4 3v2h8V7zm0 4v2h5v-2z' );
		echo '<style>' . self::tk_css() . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( isset( $_GET['msg'] ) ) { // phpcs:ignore
			MRSH_Boost::ui_ok( sanitize_text_field( wp_unslash( $_GET['msg'] ) ) ); // phpcs:ignore
		}
		$tid = isset( $_GET['t'] ) ? absint( $_GET['t'] ) : 0; // phpcs:ignore
		if ( $tid && self::row( $tid ) ) {
			self::view( $tid );
		} else {
			self::lister();
			self::settings();
		}
		echo '</div>';
	}

	private static function form_open() {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_tk_act">';
		wp_nonce_field( 'mrsh_tk_act' );
	}

	private static function lister() {
		global $wpdb;
		$f  = isset( $_GET['f'] ) ? sanitize_key( $_GET['f'] ) : 'active'; // phpcs:ignore
		$q  = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : ''; // phpcs:ignore
		$pg = isset( $_GET['pg'] ) ? max( 1, absint( $_GET['pg'] ) ) : 1; // phpcs:ignore
		$n  = array(
			'open'  => (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . self::t1() . " WHERE status='open'" ), // phpcs:ignore WordPress.DB
			'prog'  => (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . self::t1() . " WHERE status='progress'" ), // phpcs:ignore WordPress.DB
			'late'  => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM " . self::t1() . " WHERE status IN ('open','progress') AND due < %d", time() ) ), // phpcs:ignore WordPress.DB
			'solv'  => (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . self::t1() . " WHERE status='solved'" ), // phpcs:ignore WordPress.DB
		);
		$lk = function ( $flt, $html ) {
			return '<a href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG . '&f=' . $flt ) ) . '" style="display:block;text-decoration:none;color:inherit">' . $html . '</a>';
		};
		echo '<div class="mx-stats">' . $lk( 'open', MRSH_Boost::ui_stat( $n['open'], 'Open', '#e11d74' ) ) . $lk( 'progress', MRSH_Boost::ui_stat( $n['prog'], 'In progress', '#7c3aed' ) ) . $lk( 'late', MRSH_Boost::ui_stat( $n['late'], 'Late', '#e11d48' ) ) . $lk( 'solved', MRSH_Boost::ui_stat( $n['solv'], 'Solved (closed)', '#10b981' ) ) . '</div>'; // phpcs:ignore
		echo '<div class="mx-tabs">';
		foreach ( array( 'active' => 'Not solved yet', 'solved' => 'Closed / solved (' . $n['solv'] . ')', 'all' => 'All tickets' ) as $k => $l ) {
			echo '<a class="mx-btn ' . ( $f === $k ? 'p' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG . '&f=' . $k ) ) . '">' . esc_html( $l ) . '</a>';
		}
		echo '</div>';
		$where = '1=1';
		$args  = array();
		if ( 'active' === $f ) {
			$where = "status IN ('open','progress','waiting')";
		} elseif ( 'late' === $f ) {
			$where = "status IN ('open','progress') AND due < " . (int) time();
		} elseif ( in_array( $f, array( 'open', 'progress', 'waiting', 'solved' ), true ) ) {
			$where = $wpdb->prepare( 'status=%s', $f );
		}
		if ( '' !== $q ) {
			$like  = '%' . $wpdb->esc_like( $q ) . '%';
			$where .= $wpdb->prepare( ' AND (subject LIKE %s OR email LIKE %s OR name LIKE %s)', $like, $like, $like );
		}
		$per   = 25;
		$total = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::t1() . ' WHERE ' . $where ); // phpcs:ignore WordPress.DB
		$rows  = $wpdb->get_results( 'SELECT * FROM ' . self::t1() . ' WHERE ' . $where . " ORDER BY (priority='high') DESC, due ASC LIMIT " . (int) $per . ' OFFSET ' . (int) ( ( $pg - 1 ) * $per ) ); // phpcs:ignore WordPress.DB
		$base  = admin_url( 'admin.php?page=' . self::SLUG );
		echo '<form method="get" class="mx-tabs"><input type="hidden" name="page" value="' . esc_attr( self::SLUG ) . '"><input type="search" name="q" value="' . esc_attr( $q ) . '" placeholder="Name, email or subject"> <select name="f">';
		foreach ( array( 'active' => 'Not solved yet', 'late' => 'Late', 'open' => 'Open', 'progress' => 'In progress', 'waiting' => 'Waiting for member', 'solved' => 'Solved', 'all' => 'All' ) as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $f, $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select> <button class="mx-btn p s">Show</button> <span class="mx-msg" style="margin:0">' . (int) $total . ' tickets</span></form>';
		self::form_open();
		echo '<input type="hidden" name="do" value="bulk"><div class="tk-tbl">';
		if ( ! $rows ) {
			echo '<div class="mx-card" style="text-align:center;color:#6b7280">No tickets here. Nice and quiet.</div>';
		}
		foreach ( $rows as $r ) {
			$late = 'solved' !== $r->status && (int) $r->due < time();
			echo '<div class="tk-row' . ( $late ? ' late' : '' ) . '"><input type="checkbox" class="mrsh-tkc" name="ids[]" value="' . (int) $r->id . '">';
			echo '<div class="tk-who"><span class="tk-av sm">' . esc_html( self::initials( $r->name ) ) . '</span><span style="min-width:0"><b>' . esc_html( $r->name ?: 'No name' ) . '</b><small>' . esc_html( $r->email ) . '</small></span></div>';
			echo '<div class="tk-sub"><b>' . esc_html( self::code( $r->id ) ) . ' &middot; ' . esc_html( $r->subject ) . '</b><small>via ' . esc_html( $r->source ) . '</small></div>';
			echo '<div><span class="tk-st ' . esc_attr( $r->status ) . '">' . esc_html( self::status_label( $r->status ) ) . '</span>' . ( 'high' === $r->priority ? '<span class="tk-hi">HIGH</span>' : '' ) . '</div>';
			echo '<div><span class="tk-due ' . ( 'solved' === $r->status ? 'ok' : ( $late ? 'late' : '' ) ) . '">' . esc_html( self::due_text( $r ) ) . '</span></div>';
			echo '<a class="mx-btn s p" href="' . esc_url( add_query_arg( 't', (int) $r->id, $base ) ) . '">Open</a></div>';
		}
		echo '</div>';
		echo '<p class="mx-tabs" style="margin-top:10px"><b>With the ticked tickets:</b> <select name="bulk"><option value="">Choose...</option><option value="solved">Mark solved</option><option value="progress">Mark in progress</option><option value="waiting">Mark waiting for member</option><option value="open">Reopen</option><option value="high">Mark high priority</option><option value="normal">Normal priority</option></select> <button class="mx-btn p s" type="submit">Apply</button> <label style="font-size:13px"><input type="checkbox" onclick="document.querySelectorAll(\'.mrsh-tkc\').forEach(function(c){c.checked=this.checked}.bind(this))"> Tick all</label> <a class="mx-btn s" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_tk_csv' ), 'mrsh_tk_csv' ) ) . '">Download all tickets (CSV)</a></p></form>';
		$pages = max( 1, (int) ceil( $total / $per ) );
		if ( $pages > 1 ) {
			echo '<div class="mx-tabs" style="margin-top:12px">';
			for ( $i = 1; $i <= min( $pages, 20 ); $i++ ) {
				echo '<a class="mx-btn s' . ( $i === $pg ? ' p' : '' ) . '" href="' . esc_url( add_query_arg( array( 'f' => $f, 'q' => $q, 'pg' => $i ), $base ) ) . '">' . (int) $i . '</a>';
			}
			echo '</div>';
		}
	}

	private static function view( $tid ) {
		global $wpdb;
		$t    = self::row( $tid );
		$msgs = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::t2() . ' WHERE ticket_id=%d ORDER BY id ASC', $tid ) ); // phpcs:ignore WordPress.DB
		$u    = $t->user_id ? get_userdata( (int) $t->user_id ) : get_user_by( 'email', $t->email );
		echo '<p><a class="mx-btn s" href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG ) ) . '">&larr; All tickets</a></p>';
		echo '<div class="mx-card"><div class="tk-head"><span class="tk-av">' . esc_html( self::initials( $t->name ) ) . '</span><div style="min-width:0;flex:1"><h2>' . esc_html( self::code( $tid ) ) . ' &middot; ' . esc_html( $t->subject ) . '</h2><div class="tk-meta"><b>' . esc_html( $t->name ) . '</b><span>' . esc_html( $t->email ) . '</span><span class="tk-st ' . esc_attr( $t->status ) . '">' . esc_html( self::status_label( $t->status ) ) . '</span><span class="tk-due ' . ( 'solved' === $t->status ? 'ok' : ( (int) $t->due < time() ? 'late' : '' ) ) . '">' . esc_html( self::due_text( $t ) ) . '</span>' . ( 'high' === $t->priority ? '<span class="tk-hi">HIGH</span>' : '' ) . '<span>via ' . esc_html( $t->source ) . '</span></div>';
		if ( $u ) {
			$pl = (string) get_user_meta( $u->ID, 'mrt_plan', true );
			$pr = class_exists( 'MRSH_Members' ) ? MRSH_Members::my_profile( $u->ID ) : null;
			echo '<div class="tk-meta" style="margin-top:8px"><span class="tk-st" style="background:#eef2ff;color:#4338ca">Member since ' . esc_html( wp_date( 'j M Y', strtotime( $u->user_registered . ' UTC' ) ) ) . '</span><span class="tk-st" style="background:#fff7ed;color:#c2410c">Plan: ' . esc_html( $pl ?: 'none' ) . '</span>' . ( $pr ? '<a href="' . esc_url( get_permalink( $pr->ID ) ) . '" target="_blank" rel="noopener">View profile</a>' : '<span>No profile yet</span>' ) . '<a href="' . esc_url( admin_url( 'admin.php?page=mrsh-desk&q=' . rawurlencode( $t->email ) ) ) . '">Member manager</a></div>';
		} else {
			echo '<div class="tk-meta" style="margin-top:8px"><span>This email is not a registered member.</span></div>';
		}
		echo '</div></div><div class="tk-thread">';
		$who = array( 'user' => 'Member', 'staff' => 'You (sent)', 'note' => 'Private note', 'system' => 'System' );
		foreach ( $msgs as $m ) {
			$nm = 'user' === $m->who ? ( $t->name ?: 'Member' ) : ( $who[ $m->who ] ?? $m->who );
			if ( 'system' === $m->who ) {
				echo '<div class="tk-msg system"><div class="tk-b">' . esc_html( $m->body ) . ' &middot; ' . esc_html( wp_date( 'j M H:i', (int) $m->created ) ) . '</div></div>';
				continue;
			}
			echo '<div class="tk-msg ' . esc_attr( $m->who ) . '"><span class="tk-av sm"' . ( 'staff' === $m->who ? ' style="background:linear-gradient(135deg,#10b981,#047857)"' : ( 'note' === $m->who ? ' style="background:linear-gradient(135deg,#f59e0b,#d97706)"' : '' ) ) . '>' . esc_html( 'user' === $m->who ? self::initials( $t->name ) : ( 'staff' === $m->who ? 'ME' : 'N' ) ) . '</span><div class="tk-b"><span class="tk-t">' . esc_html( $nm ) . ' &middot; ' . esc_html( wp_date( 'j M Y H:i', (int) $m->created ) ) . '</span>' . nl2br( esc_html( $m->body ) ) . '</div></div>';
		}
		echo '</div>';
		self::form_open();
		echo '<div class="tk-comp"><span class="tk-lbl">Quick replies</span><div class="tk-chips">';
		$first = $msgs ? (string) $msgs[0]->body : '';
		$sug   = self::suggest( $t, $first );
		foreach ( self::templates() as $i => $tp ) {
			$is = $sug && $sug === $tp[0];
			echo '<button type="button" class="tk-chip mrsh-tpl' . ( $is ? ' sug' : '' ) . '" data-i="' . (int) $i . '">' . ( $is ? '&#10024; ' : '' ) . esc_html( $tp[0] ) . '</button>';
		}
		echo '</div><script>window.mrshTpl=' . wp_json_encode( array_map( function ( $x ) { return $x[1]; }, self::templates() ) ) . ';window.mrshName=' . wp_json_encode( $t->name ? $t->name : '' ) . ';window.mrshCode=' . wp_json_encode( self::code( $tid ) ) . ';window.mrshSite=' . wp_json_encode( get_bloginfo( 'name' ) ) . ';window.mrshHrs=' . (int) self::get()['hours'] . ';document.addEventListener("click",function(e){var b=e.target.closest(".mrsh-tpl");if(!b)return;var a=document.querySelector("textarea[name=text]");a.value=window.mrshTpl[b.dataset.i].replace(/\{name\}/g,window.mrshName||"there").replace(/\{ticket\}/g,window.mrshCode).replace(/\{site\}/g,window.mrshSite).replace(/\{hours\}/g,window.mrshHrs);a.focus()})</script>';
		echo '<input type="hidden" name="tid" value="' . (int) $tid . '"><textarea name="text" class="tk-ta" placeholder="Write your answer to the member, or a private note"></textarea><div class="tk-bar">';
		echo '<button type="submit" name="do" value="reply_solve" class="mx-btn p">Send and mark solved</button>';
		foreach ( array( 'reply' => 'Send (keep open)', 'reply_wait' => 'Send, wait for member', 'note' => 'Private note' ) as $k => $l ) {
			echo '<button type="submit" name="do" value="' . esc_attr( $k ) . '" class="mx-btn s">' . esc_html( $l ) . '</button>';
		}
		echo '<input type="text" name="ttitle" placeholder="Template name"> <button type="submit" name="do" value="tpl_add" class="mx-btn s">Save as template</button></div>';
		$rm = get_option( 'mrsh_tk_rem', array() );
		echo '<div class="tk-sec"><div><b>Status</b>';
		foreach ( array( 'open' => 'Open', 'progress' => 'In progress', 'waiting' => 'Waiting', 'solved' => 'Solved' ) as $k => $l ) {
			echo '<button type="submit" name="do" value="' . esc_attr( $k ) . '" class="mx-btn s">' . esc_html( $l ) . '</button>';
		}
		echo '</div><div><b>Remind me</b><button type="submit" name="do" value="remind_1" class="mx-btn s">Tomorrow</button><button type="submit" name="do" value="remind_3" class="mx-btn s">3 days</button><button type="submit" name="do" value="remind_7" class="mx-btn s">1 week</button>';
		if ( is_array( $rm ) && isset( $rm[ $tid ] ) ) {
			echo '<span class="tk-st waiting">' . esc_html( wp_date( 'j M H:i', (int) $rm[ $tid ] ) ) . '</span><button type="submit" name="do" value="remind_off" class="mx-btn s">Remove</button>';
		}
		echo '</div><div><button type="submit" name="do" value="priority" class="mx-btn s d">' . ( 'high' === $t->priority ? 'Normal priority' : 'Mark high priority' ) . '</button></div></div></div></form></div>';
	}

	private static function settings() {
		$s = self::get();
		echo '<div class="mx-card"><h2>Settings</h2><p class="mx-sub">Emails sent to the support mailbox become tickets automatically. The form on the website works without any setting: put <code>[mrsh_support]</code> on a page.</p>';
		self::form_open();
		echo '<input type="hidden" name="do" value="save_set"><table class="form-table">';
		echo '<tr><th>Hours to solve</th><td><input type="number" name="hours" min="1" max="720" value="' . (int) $s['hours'] . '" style="width:90px"> <span class="description">This number is written in the confirmation email.</span></td></tr>';
		echo '<tr><th>Notify me at</th><td><input type="email" name="notify" value="' . esc_attr( $s['notify'] ) . '" class="regular-text" placeholder="' . esc_attr( get_option( 'admin_email' ) ) . '"> <span class="description">New tickets and tickets near the deadline. Empty means the site admin email.</span></td></tr>';
		echo '<tr><th>Read the support mailbox</th><td><label><input type="checkbox" name="imap" value="1"' . checked( $s['imap'], 1, false ) . '> On (checks every 5 minutes)</label></td></tr>';
		echo '<tr><th>Close unanswered tickets</th><td><input type="number" name="autoclose" min="0" max="60" value="' . (int) $s['autoclose'] . '" style="width:80px"> days <span class="description">A ticket in "Waiting for member" is closed (and the member told) if they do not reply. 0 turns it off.</span></td></tr>';
		echo '<tr><th>Mailbox address</th><td><input type="email" name="mailbox" value="' . esc_attr( $s['mailbox'] ) . '" class="regular-text"></td></tr>';
		echo '<tr><th>Mail server (IMAP)</th><td><input type="text" name="host" value="' . esc_attr( $s['host'] ) . '" class="regular-text"> port <input type="number" name="port" value="' . (int) $s['port'] . '" style="width:80px"></td></tr>';
		echo '<tr><th>Mailbox password</th><td><input type="password" name="pass" value="" autocomplete="new-password" class="regular-text" placeholder="' . ( '' !== $s['pass'] ? '(saved, leave empty to keep)' : '' ) . '"> <span class="description">If the mailbox has 2-step login, use an app password from Hostinger.</span></td></tr>';
		echo '<tr><th>Never make a ticket from</th><td><textarea name="ignore" rows="6" class="regular-text">' . esc_textarea( $s['ignore'] ) . '</textarea><br><span class="description">One domain or address per line (social networks, newsletters, hosting notices). Mail with an unsubscribe link or sent by no-reply and notification addresses is already ignored automatically.</span></td></tr>';
		echo '</table><p class="mx-tabs"><button type="submit" class="mx-btn p s">Save</button> <button type="submit" name="do" value="check" class="mx-btn s">Read the mailbox now</button></p></form>';
		echo '<h3 style="margin-top:18px">Fast reply templates</h3><p class="description">These appear above the reply box on every ticket, and the best fit for the member\'s words is highlighted. Placeholders: <code>{name}</code> member name, <code>{ticket}</code> ticket number, <code>{site}</code> site name, <code>{hours}</code> hours to solve. Add new ones from a ticket with "Save text as template".</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin:8px 0"><input type="hidden" name="action" value="mrsh_tk_act"><input type="hidden" name="do" value="tpl_ready">' . wp_nonce_field( 'mrsh_tk_act', '_wpnonce', true, false ) . '<button class="mx-btn p s">Add all ready templates (' . count( self::ready_templates() ) . ')</button> <span class="description">Adds the ones you do not have yet. Your own are kept.</span></form>';
		foreach ( self::templates() as $i => $tp ) {
			echo '<details style="border:1px solid #e5e5ee;border-radius:10px;padding:8px 12px;margin:8px 0;max-width:760px"><summary><b>' . esc_html( $tp[0] ) . '</b></summary><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin-top:8px"><input type="hidden" name="action" value="mrsh_tk_act"><input type="hidden" name="ti" value="' . (int) $i . '">' . wp_nonce_field( 'mrsh_tk_act', '_wpnonce', true, false ) . '<input type="text" name="ttitle" value="' . esc_attr( $tp[0] ) . '" style="width:100%;max-width:300px"><br><textarea name="text" rows="5" style="width:100%;margin-top:6px">' . esc_textarea( $tp[1] ) . '</textarea><p class="mx-tabs"><button name="do" value="tpl_edit" class="mx-btn p s">Save changes</button> <button name="do" value="tpl_del" class="mx-btn s d" onclick="return confirm(\'Remove this template?\')">Remove</button></p></form></details>';
		}
		if ( $s['last'] ) {
			echo '<p class="description">Last check: ' . esc_html( wp_date( 'j M H:i', (int) $s['last'] ) ) . ' - ' . esc_html( $s['lastmsg'] ) . '</p>';
		}
		echo '</div>';
	}
}
MRSH_Tickets::init();
