<?php
/**
 * Extra working tools for the four ad and Google pages: Google Ads, MyRishta Ads, Auto ads, Google Business Profile.
 * Everything here runs inside the site (no outside services, no extra plugin).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_AdsTools {

	private static $css_done = false;

	/** Print one tools block. $which = gads | gbp | ads | auto */
	public static function panel( $which ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		try {
			self::css();
			switch ( $which ) {
				case 'gads':
					self::p_gads();
					break;
				case 'gbp':
					self::p_gbp();
					break;
				case 'ads':
					self::p_ads();
					break;
				case 'auto':
					self::p_auto();
					break;
			}
			self::js();
		} catch ( \Throwable $e ) {
			if ( class_exists( 'MRSH_Safe' ) ) {
				MRSH_Safe::log_ex( $e, 'MRSH_AdsTools::' . $which );
			}
		}
	}

	private static function css() {
		if ( self::$css_done ) {
			return;
		}
		self::$css_done = true;
		echo '<style>
.at{max-width:1040px;margin:18px 0}
.at-hd{display:flex;align-items:center;gap:10px;margin:22px 0 10px}
.at-hd h2{margin:0;padding:0!important;border:0!important;font-size:18px}
.at-hd i{font-style:normal;background:linear-gradient(135deg,#7c3aed,#e11d74);color:#fff;border-radius:99px;font-size:11px;font-weight:700;padding:3px 10px;letter-spacing:.04em}
.at-c{background:#fff;border:1px solid #e4e7f1;border-radius:16px;padding:18px 20px;margin:0 0 14px;box-shadow:0 1px 2px rgba(17,24,39,.04)}
.at-c h3{margin:0 0 4px;font-size:15px}
.at-c .d{margin:0 0 12px;color:#646970}
.at-g{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin:0 0 12px}
.at-t{background:#f6f8f7;border:1px solid #e3e8e6;border-radius:12px;padding:12px 14px}
.at-t b{display:block;font-size:24px;line-height:1.1;color:#0b5a3f}.at-t span{font-size:12px;color:#646970}
.at-f{display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end;margin:0 0 12px}
.at-f label{display:flex;flex-direction:column;gap:4px;font-size:12px;font-weight:600;color:#4b5563}
.at-f input,.at-f select{min-width:140px;border-radius:10px;padding:8px 10px}
.at-l{display:grid;gap:6px;margin:0 0 10px}
.at-r{display:flex;gap:10px;align-items:center;background:#fafbfd;border:1px solid #eceef6;border-radius:10px;padding:8px 10px}
.at-r .tx{flex:1;min-width:0;overflow-wrap:anywhere;font-size:13.5px}
.at-r .n{font-size:11px;font-weight:700;border-radius:99px;padding:2px 8px;background:#eaf6f0;color:#0b5a3f;white-space:nowrap}
.at-r .n.x{background:#fde8e8;color:#b42318}
.at-ck{display:flex;gap:10px;align-items:flex-start;padding:8px 0;border-top:1px solid #f0f0f1}
.at-ck:first-of-type{border-top:0}.at-ck .ic{flex:none;width:22px;height:22px;border-radius:50%;display:grid;place-items:center;font-size:13px;font-weight:700;color:#fff}
.at-ck .ic.ok{background:#0f7a55}.at-ck .ic.no{background:#d92d20}.at-ck .ic.mid{background:#f59e0b}
.at-ck small{display:block;color:#646970}
.at-sp{display:flex;align-items:flex-end;gap:3px;height:46px;margin:8px 0 4px}.at-sp i{flex:1;background:#7c3aed;border-radius:3px 3px 0 0;min-height:3px;opacity:.85}
.at-bar{height:8px;border-radius:99px;background:#eceef6;overflow:hidden}.at-bar i{display:block;height:100%;background:#0f7a55}.at-bar i.over{background:#d92d20}
.at-cap{width:100%;min-height:110px;border-radius:12px;font:inherit;padding:10px 12px}
.at-pre{white-space:pre-wrap;background:#fafbfd;border:1px solid #eceef6;border-radius:10px;padding:10px 12px;font-size:13.5px;margin:0 0 8px}
.at-b{display:flex;flex-wrap:wrap;gap:8px;margin:8px 0}
.at-out{font-size:15px;margin-top:6px}.at-out b{color:#0b5a3f}
.at textarea.code{width:100%;font-family:monospace;font-size:12.5px;border-radius:10px}
</style>';
	}

	private static function hd( $title, $badge = 'NEW' ) {
		echo '<div class="at-hd"><h2>' . esc_html( $title ) . '</h2><i>' . esc_html( $badge ) . '</i></div>';
	}

	private static function row_ck( $state, $title, $hint = '' ) {
		$sym = 'ok' === $state ? '&#10003;' : ( 'no' === $state ? '!' : '&bull;' );
		echo '<div class="at-ck"><span class="ic ' . esc_attr( $state ) . '">' . $sym . '</span><div><b>' . esc_html( $title ) . '</b>' . ( $hint ? '<small>' . esc_html( $hint ) . '</small>' : '' ) . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	private static function cities() {
		return array( 'Lahore', 'Karachi', 'Islamabad', 'Rawalpindi', 'Faisalabad', 'Multan', 'Peshawar', 'Gujranwala', 'Sialkot', 'Hyderabad' );
	}

	/** Last 14 days of new members and published profiles. */
	private static function results() {
		global $wpdb;
		$since = gmdate( 'Y-m-d', time() - 14 * DAY_IN_SECONDS );
		$u     = $wpdb->get_results( $wpdb->prepare( "SELECT DATE(user_registered) d, COUNT(*) n FROM {$wpdb->users} WHERE user_registered >= %s GROUP BY d", $since ), OBJECT_K ); // phpcs:ignore
		$p     = $wpdb->get_results( $wpdb->prepare( "SELECT DATE(post_date_gmt) d, COUNT(*) n FROM {$wpdb->posts} WHERE post_type = 'listing_type' AND post_status = 'publish' AND post_date_gmt >= %s GROUP BY d", $since ), OBJECT_K ); // phpcs:ignore
		$days  = array();
		$us    = 0;
		$ps    = 0;
		for ( $i = 13; $i >= 0; $i-- ) {
			$d  = gmdate( 'Y-m-d', time() - $i * DAY_IN_SECONDS );
			$a  = isset( $u[ $d ] ) ? (int) $u[ $d ]->n : 0;
			$b  = isset( $p[ $d ] ) ? (int) $p[ $d ]->n : 0;
			$us += $a;
			$ps += $b;
			$days[ $d ] = $a;
		}
		$us7 = array_sum( array_slice( $days, -7 ) );
		return array( 'users14' => $us, 'users7' => $us7, 'profiles14' => $ps, 'days' => $days );
	}

	/* ------------------------------------------------------------------ Google Ads */
	private static function p_gads() {
		$r   = self::results();
		$mx  = max( 1, max( $r['days'] ) );
		$sp  = '';
		foreach ( $r['days'] as $d => $n ) {
			$sp .= '<i title="' . esc_attr( $d . ': ' . $n ) . '" style="height:' . max( 6, (int) round( $n / $mx * 100 ) ) . '%"></i>';
		}
		echo '<div class="at">';
		self::hd( 'Google Ads toolbox' );
		echo '<div class="at-c"><h3>Real results on your site</h3><p class="d">New members and new live profiles, counted from your own site (not from Google). Compare with the sign-ups Google Ads reports to see if tracking is correct.</p><div class="at-g"><div class="at-t"><b>' . (int) $r['users7'] . '</b><span>New members, 7 days</span></div><div class="at-t"><b>' . (int) $r['users14'] . '</b><span>New members, 14 days</span></div><div class="at-t"><b>' . (int) $r['profiles14'] . '</b><span>New live profiles, 14 days</span></div></div><div class="at-sp" title="New members per day, 14 days">' . $sp . '</div></div>'; // phpcs:ignore
		echo '<div class="at-c"><h3>Campaign link builder</h3><p class="d">Adds tracking to any address so Google Analytics shows which ad brought the visitor. Copy the result into your ad final URL.</p><div class="at-f" id="at-utm"><label>Page address<input type="url" class="u" value="' . esc_attr( home_url( '/' ) ) . '" style="min-width:280px"></label><label>Source<input class="s" value="google"></label><label>Medium<input class="m" value="cpc"></label><label>Campaign<input class="c" value="rishta-pk"></label><label>Keyword (optional)<input class="k" value=""></label></div><div class="at-r"><span class="tx" id="at-utm-out"></span><button type="button" class="button" data-cp="#at-utm-out">Copy</button></div></div>'; // phpcs:ignore
		$opts = '';
		foreach ( self::cities() as $c ) {
			$opts .= '<option>' . esc_html( $c ) . '</option>';
		}
		echo '<div class="at-c"><h3>Ad text maker (Responsive Search Ad)</h3><p class="d">Ready headlines (max 30 characters) and descriptions (max 90). The counter turns red if a line is too long. Pick the city you are targeting.</p><div class="at-f"><label>City<select id="at-city">' . $opts . '</select></label><button type="button" class="button" data-cp-all="#at-hl">Copy all headlines</button><button type="button" class="button" data-cp-all="#at-ds">Copy all descriptions</button></div><div class="at-l" id="at-hl"></div><div class="at-l" id="at-ds"></div><p class="d">No promises of a match, no fake stories or photos. Review Google\'s current policy before you submit.</p></div>'; // phpcs:ignore
		echo '<div class="at-c"><h3>Keywords and negative keywords</h3><p class="d">Start with these. Negative keywords stop wasted clicks. Check each list against your own plan before pasting into Google Ads.</p><div class="at-f"><label>City<select id="at-kcity">' . $opts . '</select></label><label>Match type<select id="at-kmt"><option value="b">Broad</option><option value="p" selected>"Phrase"</option><option value="e">[Exact]</option></select></label></div><div class="at-b"><b>Keywords</b><button type="button" class="button" data-cp="#at-kw">Copy keywords</button><b style="margin-left:14px">Negative</b><button type="button" class="button" data-cp="#at-neg">Copy negatives</button></div><textarea class="code" id="at-kw" rows="9" readonly></textarea><textarea class="code" id="at-neg" rows="6" readonly style="margin-top:8px"></textarea></div>'; // phpcs:ignore
		echo '<div class="at-c"><h3>Budget and cost calculator</h3><p class="d">Change the numbers to see what a month might cost. Use your real figures after two weeks of data.</p><div class="at-f" id="at-bud"><label>Daily budget (PKR)<input type="number" class="b" value="1500" min="100"></label><label>Cost per click (PKR)<input type="number" class="c" value="25" min="1"></label><label>Visitors who sign up (%)<input type="number" class="s" value="8" min="0" max="100" step="0.5"></label><label>Sign-ups who make a profile (%)<input type="number" class="p" value="60" min="0" max="100"></label></div><div class="at-g" id="at-bud-out"></div></div>'; // phpcs:ignore
		echo '<div class="at-c"><h3>Before you start: policy checklist</h3><p class="d">Tick each one when it is true. The ticks are remembered in this browser.</p><div id="at-pol"></div></div>';
		echo '</div>';
	}

	/* ------------------------------------------------------------------ Business Profile */
	private static function fetch_home() {
		$k = 'mrsh_at_home';
		$h = get_transient( $k );
		if ( false === $h ) {
			$r = wp_remote_get( home_url( '/' ), array( 'timeout' => 12, 'redirection' => 3, 'user-agent' => 'MyRishta-check' ) );
			$h = is_wp_error( $r ) ? '' : (string) wp_remote_retrieve_body( $r );
			set_transient( $k, $h, 10 * MINUTE_IN_SECONDS );
		}
		return $h;
	}

	private static function p_gbp() {
		$g     = class_exists( 'MRSH_Gbp' ) ? MRSH_Gbp::get() : array();
		$name  = trim( (string) ( $g['name'] ?? '' ) ) ?: get_bloginfo( 'name' );
		$phone = preg_replace( '/\D+/', '', (string) ( $g['phone'] ?? '' ) );
		$html  = self::fetch_home();
		$plain = html_entity_decode( wp_strip_all_tags( $html ), ENT_QUOTES, 'UTF-8' );
		$digits = preg_replace( '/\D+/', '', $plain );
		$revu  = class_exists( 'MRSH_Gbp' ) ? MRSH_Gbp::review_url() : '';
		echo '<div class="at">';
		self::hd( 'Business Profile tools' );
		echo '<div class="at-c"><h3>Is your business information the same everywhere?</h3><p class="d">Google trusts a profile more when the name, phone and links on your website match it. This checks your public home page right now.</p>';
		self::row_ck( '' !== $html ? ( false !== stripos( $plain, $name ) ? 'ok' : 'no' ) : 'mid', 'Business name "' . $name . '" appears on the home page', '' === $html ? 'Could not open the home page just now. Try again in a minute.' : 'Use the exact same name in Google Business Profile.' );
		self::row_ck( $phone ? ( '' !== $html && false !== strpos( $digits, substr( $phone, -9 ) ) ? 'ok' : 'no' ) : 'mid', 'Phone number shown on the website', $phone ? 'Looked for ' . $g['phone'] . ' on the home page.' : 'Add your phone in the business details above.' );
		self::row_ck( false !== stripos( $html, 'application/ld+json' ) && ( false !== stripos( $html, 'Organization' ) || false !== stripos( $html, 'LocalBusiness' ) ) ? 'ok' : 'no', 'Business data (schema) is on the page', 'Helps Google link the website to the profile.' );
		self::row_ck( $revu ? 'ok' : 'no', 'Review link is set', $revu ? 'Members and visitors can reach your Google review form.' : 'Add your Google Place ID or review link in the details above.' );
		foreach ( array( 'contact' => 'Contact page', 'about-us' => 'About page', 'privacy-policy' => 'Privacy page' ) as $slug => $lbl ) {
			$pg = get_page_by_path( $slug );
			self::row_ck( $pg && 'publish' === $pg->post_status ? 'ok' : 'mid', $lbl . ' exists', 'A real contact and about page make the profile look genuine.' );
		}
		echo '<p style="margin:10px 0 0"><a class="button" href="' . esc_url( add_query_arg( 'mrsh_recheck', '1' ) ) . '" onclick="">Check again</a></p></div>'; // phpcs:ignore
		echo '<div class="at-c"><h3>Ask for reviews</h3><p class="d">Send this to families after a good result. Honest reviews only: never pay for reviews or write them for someone.</p><div class="at-f"><label>Name<input id="at-rn" placeholder="Ahmed sahib" style="min-width:200px"></label><label>Language<select id="at-rl"><option value="en">English</option><option value="ur">Urdu</option></select></label><button type="button" class="button button-primary" id="at-rwa">Open in WhatsApp</button><button type="button" class="button" data-cp="#at-rt">Copy message</button></div><div class="at-pre" id="at-rt"></div>' . ( $revu ? '' : '<p class="d"><b>Set your review link above first</b>, then the message includes it.</p>' ) . '</div>'; // phpcs:ignore
		echo '<div class="at-c"><h3>Four-week post plan</h3><p class="d">Three posts a week keeps the profile active. Copy each post, add a real photo, and publish it on the day shown.</p><div id="at-plan"></div></div>';
		echo '<div class="at-c"><h3>Profile completeness</h3><p class="d">Tick what you have done. Remembered in this browser.</p><div class="at-bar"><i id="at-pcbar" style="width:0"></i></div><p class="d" id="at-pcn" style="margin:6px 0 10px"></p><div id="at-pc"></div></div>';
		echo '</div>';
		$GLOBALS['mrsh_at_data'] = array( 'review' => $revu, 'name' => $name );
	}

	/* ------------------------------------------------------------------ MyRishta Ads */
	private static function p_ads() {
		$k = 'mrsh_at_ready';
		$d = get_transient( $k );
		if ( ! is_array( $d ) ) {
			$posts = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'numberposts' => 300, 'fields' => 'ids', 'no_found_rows' => true ) );
			$long  = 0;
			foreach ( $posts as $pid ) {
				if ( str_word_count( wp_strip_all_tags( (string) get_post_field( 'post_content', $pid ) ) ) >= 400 ) {
					$long++;
				}
			}
			$thin = 0;
			$pgs  = get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 'numberposts' => 100, 'fields' => 'ids', 'no_found_rows' => true ) );
			foreach ( $pgs as $pid ) {
				if ( str_word_count( wp_strip_all_tags( (string) get_post_field( 'post_content', $pid ) ) ) < 120 ) {
					$thin++;
				}
			}
			$d = array( 'posts' => count( $posts ), 'long' => $long, 'thin' => $thin, 'pages' => count( $pgs ) );
			set_transient( $k, $d, HOUR_IN_SECONDS );
		}
		$has = static function ( $slugs ) {
			foreach ( (array) $slugs as $s ) {
				$p = get_page_by_path( $s );
				if ( $p && 'publish' === $p->post_status ) {
					return true;
				}
			}
			return false;
		};
		$lines = class_exists( 'MRSH_Tools' ) ? count( array_filter( explode( "\n", MRSH_Tools::ads_txt_body() ) ) ) : 0;
		echo '<div class="at">';
		self::hd( 'Ad network approval checklist' );
		echo '<div class="at-c"><h3>Is the site ready for AdSense and other networks?</h3><p class="d">Networks check these before approving a site. Fix every red item first.</p>';
		self::row_ck( $d['posts'] >= 15 ? 'ok' : 'no', 'At least 15 published guides (you have ' . (int) $d['posts'] . ')', 'Networks want real, useful content.' );
		self::row_ck( $d['long'] >= 10 ? 'ok' : ( $d['long'] > 0 ? 'mid' : 'no' ), 'Guides with 400+ words: ' . (int) $d['long'] . ' (aim for 10 or more)', 'Short pages are weak for approval.' );
		self::row_ck( 0 === $d['thin'] ? 'ok' : 'mid', 'Pages with very little text: ' . (int) $d['thin'], 'Thin pages can be hidden from ads in the box above.' );
		self::row_ck( $has( array( 'privacy-policy', 'privacy' ) ) ? 'ok' : 'no', 'Privacy policy page', 'Required by every ad network.' );
		self::row_ck( $has( array( 'terms', 'terms-and-conditions', 'terms-of-service' ) ) ? 'ok' : 'mid', 'Terms page' );
		self::row_ck( $has( array( 'contact', 'contact-us' ) ) ? 'ok' : 'no', 'Contact page' );
		self::row_ck( $has( array( 'about-us', 'about' ) ) ? 'ok' : 'no', 'About page' );
		self::row_ck( is_ssl() ? 'ok' : 'no', 'Site uses https' );
		self::row_ck( $lines > 0 ? 'ok' : 'mid', 'ads.txt has ' . (int) $lines . ' line(s)', 'Add your publisher line after the network approves you.' );
		self::row_ck( function_exists( 'wp_has_consent' ) ? 'ok' : 'mid', 'Cookie-consent support is active', 'Needed for personalised ads in some regions.' );
		echo '</div>';
		echo '<div class="at-c"><h3>Earnings estimator</h3><p class="d">A rough guide only. Real income depends on the network, country and season.</p><div class="at-f" id="at-earn"><label>Page views per month<input type="number" class="v" value="30000" min="0"></label><label>Page RPM (USD per 1000 views)<input type="number" class="r" value="1.2" min="0" step="0.1"></label><label>PKR per USD<input type="number" class="x" value="280" min="1"></label></div><div class="at-g" id="at-earn-out"></div></div>'; // phpcs:ignore
		echo '</div>';
	}

	/* ------------------------------------------------------------------ Auto ads */
	private static function p_auto() {
		echo '<div class="at">';
		self::hd( 'Caption tools' );
		echo '<div class="at-c"><h3>Caption checker</h3><p class="d">Paste a caption to see if it fits each channel. A channel that is too short for the text will cut it.</p><textarea class="at-cap" id="at-cap" placeholder="Type or paste a caption..."></textarea><div id="at-cap-out" style="margin-top:10px"></div></div>';
		$opts = '';
		foreach ( self::cities() as $c ) {
			$opts .= '<option>' . esc_html( $c ) . '</option>';
		}
		echo '<div class="at-c"><h3>Hashtag sets</h3><p class="d">Use three to six per post. Too many looks like spam.</p><div class="at-f"><label>City<select id="at-hcity">' . $opts . '</select></label><button type="button" class="button" data-cp="#at-hout">Copy hashtags</button></div><div class="at-pre" id="at-hout"></div></div>'; // phpcs:ignore
		echo '<div class="at-c"><h3>Best times to post (Pakistan time)</h3><p class="d">Starting points. Check which times your own followers react to and move your schedule there.</p>';
		self::row_ck( 'ok', 'Weekdays 8 pm to 10 pm', 'Families are home and on their phones.' );
		self::row_ck( 'ok', 'Friday after Jumu\'ah prayer', 'A quiet, family time.' );
		self::row_ck( 'ok', 'Sunday 6 pm to 9 pm', 'Planning time for the week.' );
		self::row_ck( 'mid', 'Avoid early mornings and prayer times', 'Low attention, and respectful.' );
		echo '</div></div>';
	}

	/* ------------------------------------------------------------------ script */
	private static function js() {
		static $done = false;
		if ( $done ) {
			return;
		}
		$done = true;
		$d = array( 'site' => home_url( '/' ), 'name' => get_bloginfo( 'name' ), 'review' => (string) ( $GLOBALS['mrsh_at_data']['review'] ?? '' ) );
		echo '<script>window.MRSH_AT=' . wp_json_encode( $d ) . ';</script>';
		echo '<script>';
		echo <<<'JS'
(function(){
var D=window.MRSH_AT||{};
function $(s,r){return (r||document).querySelector(s)}
function $$(s,r){return [].slice.call((r||document).querySelectorAll(s))}
function cp(t,b){var done=function(){if(b){var o=b.textContent;b.textContent='Copied';setTimeout(function(){b.textContent=o},1400)}};
 if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t).then(done,function(){fb(t,done)})}else fb(t,done)}
function fb(t,done){var a=document.createElement('textarea');a.value=t;document.body.appendChild(a);a.select();try{document.execCommand('copy')}catch(e){}a.remove();done()}
document.addEventListener('click',function(e){
 var b=e.target.closest('[data-cp]');if(b){var el=$(b.getAttribute('data-cp'));if(el)cp(el.value!==undefined&&el.tagName==='TEXTAREA'?el.value:el.textContent,b);return}
 var a=e.target.closest('[data-cp-all]');if(a){var l=$$(a.getAttribute('data-cp-all')+' .tx').map(function(x){return x.textContent});cp(l.join('\n'),a);return}
 var r=e.target.closest('[data-cp-row]');if(r){cp(r.closest('.at-r').querySelector('.tx').textContent,r)}
});
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
function lines(box,arr,max){box.innerHTML=arr.map(function(t){var n=t.length,bad=n>max;return '<div class="at-r"><span class="tx">'+esc(t)+'</span><span class="n'+(bad?' x':'')+'">'+n+'/'+max+'</span><button type="button" class="button" data-cp-row>Copy</button></div>'}).join('')}
function store(k,v){try{if(v===undefined)return JSON.parse(localStorage.getItem(k)||'null');localStorage.setItem(k,JSON.stringify(v))}catch(e){return null}}
function checks(box,key,items,onchange){var saved=store(key)||{};box.innerHTML=items.map(function(t,i){return '<label class="at-ck" style="cursor:pointer"><input type="checkbox" data-i="'+i+'"'+(saved[i]?' checked':'')+' style="margin-top:3px"><div>'+esc(t)+'</div></label>'}).join('');
 function upd(){var s={},n=0;$$('input',box).forEach(function(c){if(c.checked){s[c.dataset.i]=1;n++}});store(key,s);if(onchange)onchange(n,items.length)}
 box.addEventListener('change',upd);upd()}

/* ---- Google Ads ---- */
var utm=$('#at-utm');if(utm){var uo=$('#at-utm-out');function ub(){var u=$('.u',utm).value.trim()||D.site,q=[];[['s','utm_source'],['m','utm_medium'],['c','utm_campaign'],['k','utm_term']].forEach(function(p){var v=$('.'+p[0],utm).value.trim();if(v)q.push(p[1]+'='+encodeURIComponent(v))});uo.textContent=u+(u.indexOf('?')>-1?'&':'?')+q.join('&')}
 $$('input',utm).forEach(function(i){i.addEventListener('input',ub)});ub()}
var cs=$('#at-city');if(cs){function ad(){var c=cs.value;
 var H=['Free Rishta in '+c,'Verified Rishta Profiles',c+' Rishta Proposals','Create Free Profile Today','Private & Safe Rishta Site','Find a Rishta Online Free',"Pakistan's Free Rishta Site",'Join in 3 Minutes','Genuine Profiles Only','Start Your Rishta Search','Rishta Search in '+c,'No Fee. No Pressure.','Free Marriage Proposals','Family-Friendly Rishta Site','Rishta for Pakistanis Abroad'];
 var S=['Free rishta service run by a non-profit in Lahore. Create a profile in three minutes.','Browse profiles, message privately and involve both families. Free to join.','Safe, family-friendly rishta search for Pakistanis at home and abroad. Join free.','We act on reports of fake profiles. Create your free profile today in '+c+'.'];
 lines($('#at-hl'),H,30);lines($('#at-ds'),S,90)}cs.addEventListener('change',ad);ad()}
var kc=$('#at-kcity');if(kc){var km=$('#at-kmt');function kw(){var c=kc.value,w=['rishta in '+c,'online rishta '+c,'marriage proposals '+c,'rishta website '+c,'rishta service '+c,'free rishta site','rishta proposals pakistan','online rishta pakistan','rishta for overseas pakistanis','find rishta online','rishta match pakistan'];
 var m=km.value;$('#at-kw').value=w.map(function(x){return m==='p'?'"'+x+'"':m==='e'?'['+x+']':x}).join('\n');
 $('#at-neg').value=['jobs','vacancy','salary','wedding hall','dress','makeup','photography','catering','mehndi design','dj','invitation card','divorce lawyer','court marriage','nikah nama download','pdf','download','india','canada visa'].map(function(x){return '"'+x+'"'}).join('\n')}
 kc.addEventListener('change',kw);km.addEventListener('change',kw);kw()}
var bd=$('#at-bud');if(bd){function bb(){var b=+$('.b',bd).value||0,c=+$('.c',bd).value||1,s=(+$('.s',bd).value||0)/100,p=(+$('.p',bd).value||0)/100,cl=b/c,su=cl*s,pr=su*p,mo=b*30,f=function(n){return Math.round(n).toLocaleString()};
 $('#at-bud-out').innerHTML=[['Clicks per day',f(cl)],['Sign-ups per day',su.toFixed(1)],['New profiles per day',pr.toFixed(1)],['Cost per sign-up (PKR)',su?f(b/su):'-'],['Cost per profile (PKR)',pr?f(b/pr):'-'],['30-day spend (PKR)',f(mo)]].map(function(x){return '<div class="at-t"><b>'+x[1]+'</b><span>'+x[0]+'</span></div>'}).join('')}
 $$('input',bd).forEach(function(i){i.addEventListener('input',bb)});bb()}
var pol=$('#at-pol');if(pol)checks(pol,'mrsh_at_pol',['Ads do not promise a match or a marriage.','No fake stories, photos or testimonials.','Ads are aimed at adults (18+) only.','The landing page shows the privacy policy and terms.','The landing page matches what the ad says.','Contact details are visible on the site.','No member photo or personal data is used in any ad.','Conversion tracking is set up and tested.']);

/* ---- Business Profile ---- */
var rt=$('#at-rt');if(rt){var rn=$('#at-rn'),rl=$('#at-rl');function rm(){var n=rn.value.trim(),u=D.review||'(add your Google review link above)';
 rt.textContent=rl.value==='ur'?('Assalam o Alaikum'+(n?' '+n:'')+'! '+D.name+' ke saath aap ka tajurba kaisa raha? Agar aap ko pasand aaya ho to Google par ek chhota sa sacha review likh dein, is se dusre khandan ko madad milegi. Shukriya! '+u):('Assalam o Alaikum'+(n?' '+n:'')+'! Thank you for using '+D.name+'. If it helped your family, please share a short honest review on Google. It helps other families find us. Jazakallah! '+u)}
 rn.addEventListener('input',rm);rl.addEventListener('change',rm);rm();
 $('#at-rwa').onclick=function(){window.open('https://wa.me/?text='+encodeURIComponent(rt.textContent),'_blank','noopener')}}
var pl=$('#at-plan');if(pl){var P=[['Mon','Tip','Three questions to ask before accepting a rishta proposal. Read more: '+D.site],['Wed','Safety','Never send money or card details to someone you met online. Meet only with both families.'],['Fri','Dua','Jumu\'ah Mubarak. May Allah bless every family searching for a good match. Create a free profile: '+D.site],['Mon','Guide','How to say no to a rishta politely and keep respect on both sides.'],['Wed','Profile','A clear photo and honest details get more replies. Update your profile today.'],['Fri','Story','Families tell us the first message matters. Start with Assalam o Alaikum and a short introduction.'],['Mon','Overseas','Looking for a rishta from abroad? Create a free profile and involve family from the start.'],['Wed','City','Rishta proposals in Lahore, Karachi and Islamabad. Browse free profiles: '+D.site],['Fri','Dua','Jumu\'ah Mubarak. Take your time, make istikhara, and decide with family.'],['Mon','FAQ','Is it free? Yes. Is it private? You choose what to show. Learn how it works: '+D.site],['Wed','Verify','Look for the verification badge and report anything that looks wrong.'],['Fri','Thanks','Thank you to every family who trusts us. Share your honest feedback on Google.']];
 pl.innerHTML=[0,1,2,3].map(function(w){return '<div style="margin:0 0 10px"><b>Week '+(w+1)+'</b>'+P.slice(w*3,w*3+3).map(function(x){return '<div class="at-r" style="margin-top:6px"><span class="n" style="background:#eef2ff;color:#4338ca">'+x[0]+'</span><span class="tx"><b>'+x[1]+':</b> '+esc(x[2])+'</span><button type="button" class="button" data-cp-row>Copy</button></div>'}).join('')+'</div>'}).join('')}
var pc=$('#at-pc');if(pc)checks(pc,'mrsh_at_pc',['Logo added (square, at least 250 x 250)','Cover photo added','At least 5 real photos','Opening hours set','Service area set to Pakistan','Business category chosen','Short description written (750 characters)','Website and booking links added','Phone number verified','First review request sent','Post published this week','Questions and answers added'],function(n,t){$('#at-pcbar').style.width=Math.round(n/t*100)+'%';$('#at-pcn').textContent=n+' of '+t+' done'});

/* ---- MyRishta Ads ---- */
var er=$('#at-earn');if(er){function ee(){var v=+$('.v',er).value||0,r=+$('.r',er).value||0,x=+$('.x',er).value||1,usd=v/1000*r,f=function(n){return Math.round(n).toLocaleString()};
 $('#at-earn-out').innerHTML=[['Per month (USD)','$'+usd.toFixed(0)],['Per month (PKR)',f(usd*x)],['Per year (USD)','$'+f(usd*12)],['Per day (USD)','$'+(usd/30).toFixed(2)]].map(function(y){return '<div class="at-t"><b>'+y[1]+'</b><span>'+y[0]+'</span></div>'}).join('')}
 $$('input',er).forEach(function(i){i.addEventListener('input',ee)});ee()}

/* ---- Auto ads ---- */
var ca=$('#at-cap');if(ca){var L=[['X (Twitter)',280],['Instagram',2200],['Pinterest',500],['LinkedIn',3000],['Telegram',4096],['Facebook page',5000]];function cc(){var n=ca.value.length;$('#at-cap-out').innerHTML='<p class="d" style="margin:0 0 8px">'+n+' characters</p>'+L.map(function(x){var p=Math.min(100,n/x[1]*100),over=n>x[1];return '<div style="margin:0 0 8px"><div style="display:flex;justify-content:space-between;font-size:13px"><span>'+x[0]+'</span><span style="color:'+(over?'#b42318':'#0b5a3f')+'">'+(over?'too long by '+(n-x[1]):(x[1]-n)+' left')+'</span></div><div class="at-bar"><i class="'+(over?'over':'')+'" style="width:'+p+'%"></i></div></div>'}).join('')}
 ca.addEventListener('input',cc);cc()}
var hc=$('#at-hcity');if(hc){function hh(){var c=hc.value,t=c.replace(/\s+/g,'');$('#at-hout').textContent=['#RishtaPakistan','#'+t+'Rishta','#OnlineRishta','#FreeRishta','#MarriageProposals','#PakistaniFamilies'].join(' ')}hc.addEventListener('change',hh);hh()}
})();
JS;
		echo '</script>';
	}
}
