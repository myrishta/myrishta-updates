<?php
/**
 * Email delivery: sends all site mail through a real SMTP account (PHPMailer, already inside WordPress),
 * signs mail with DKIM, adds the headers that mail providers like, checks the DNS records (SPF, DKIM, DMARC),
 * sends a test mail and keeps a log of failures.
 * Options: mrsh_smtp (settings, password encrypted), mrsh_smtp_dkim (DKIM private key), mrsh_smtp_log.
 * The names contain "smtp" on purpose, so the settings export never includes them.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Delivery {

	const OPT = 'mrsh_smtp';

	public static function opt( $k = null ) {
		$d = array( 'on' => 0, 'host' => '', 'port' => 587, 'secure' => 'tls', 'user' => '', 'pass' => '', 'from' => '', 'name' => '', 'dkim' => 0, 'sel' => 'mrsh', 'unsub' => 1 );
		$o = array_merge( $d, (array) get_option( self::OPT, array() ) );
		return null === $k ? $o : $o[ $k ];
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 33 );
		add_action( 'admin_post_mrsh_mail_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_mrsh_mail_test', array( __CLASS__, 'test' ) );
		add_action( 'admin_post_mrsh_mail_keys', array( __CLASS__, 'keys' ) );
		add_filter( 'wp_mail_from', array( __CLASS__, 'from' ), 99 );
		add_filter( 'wp_mail_from_name', array( __CLASS__, 'from_name' ), 99 );
		add_action( 'phpmailer_init', array( __CLASS__, 'configure' ), 99 );
		add_action( 'wp_mail_failed', array( __CLASS__, 'failed' ) );
	}

	/* ---------- password is stored encrypted ---------- */
	private static function enc( $s ) {
		if ( '' === $s ) {
			return '';
		}
		if ( function_exists( 'openssl_encrypt' ) ) {
			$k  = hash( 'sha256', wp_salt( 'auth' ), true );
			$iv = random_bytes( 16 );
			return 'e:' . base64_encode( $iv . openssl_encrypt( $s, 'aes-256-cbc', $k, OPENSSL_RAW_DATA, $iv ) ); // phpcs:ignore
		}
		return 'b:' . base64_encode( $s ); // phpcs:ignore
	}

	private static function dec( $s ) {
		if ( 0 === strpos( $s, 'e:' ) && function_exists( 'openssl_decrypt' ) ) {
			$raw = base64_decode( substr( $s, 2 ) ); // phpcs:ignore
			$k   = hash( 'sha256', wp_salt( 'auth' ), true );
			return (string) openssl_decrypt( substr( $raw, 16 ), 'aes-256-cbc', $k, OPENSSL_RAW_DATA, substr( $raw, 0, 16 ) );
		}
		if ( 0 === strpos( $s, 'b:' ) ) {
			return (string) base64_decode( substr( $s, 2 ) ); // phpcs:ignore
		}
		return '';
	}

	private static function domain() {
		$f = self::opt( 'from' );
		if ( is_email( $f ) ) {
			return strtolower( substr( strrchr( $f, '@' ), 1 ) );
		}
		$h = wp_parse_url( home_url(), PHP_URL_HOST );
		return strtolower( preg_replace( '/^www\./', '', (string) $h ) );
	}

	/* ---------- sending ---------- */
	public static function from( $e ) {
		$f = self::opt( 'from' );
		return is_email( $f ) ? $f : $e;
	}

	public static function from_name( $n ) {
		$s = self::opt( 'name' );
		return '' !== $s ? $s : $n;
	}

	public static function configure( $m ) {
		try {
			$o = self::opt();
			// The newer MRSH_Smtp class owns the SMTP login (same option name, different password format), so this older block must not override it.
			if ( $o['on'] && $o['host'] && ! class_exists( 'MRSH_Smtp', false ) ) {
				$m->isSMTP();
				$m->Host       = $o['host'];
				$m->Port       = (int) $o['port'];
				$m->SMTPSecure = in_array( $o['secure'], array( 'tls', 'ssl' ), true ) ? $o['secure'] : '';
				$m->SMTPAutoTLS = 'none' !== $o['secure'];
				if ( $o['user'] ) {
					$m->SMTPAuth = true;
					$m->Username = $o['user'];
					$m->Password = self::dec( (string) $o['pass'] );
				}
				$m->Timeout = 15;
			}
			// The bounce address must match the sender domain or spam filters get suspicious.
			if ( is_email( $o['from'] ) ) {
				$m->Sender = $o['from'];
			}
			// A plain text copy next to the HTML mail: mails without one score worse.
			if ( 'text/html' === $m->ContentType && '' === (string) $m->AltBody ) {
				$m->AltBody = trim( html_entity_decode( wp_strip_all_tags( preg_replace( '#<(br|/p|/div|/h[1-6]|/li)[^>]*>#i', "\n", (string) $m->Body ) ), ENT_QUOTES, 'UTF-8' ) );
			}
			if ( $o['unsub'] && is_email( $o['from'] ) ) {
				$m->addCustomHeader( 'List-Unsubscribe', '<mailto:' . $o['from'] . '?subject=unsubscribe>' );
			}
			$m->addCustomHeader( 'X-Auto-Response-Suppress', 'OOF, AutoReply' );
			$dom = self::domain();
			$m->MessageID = '<' . bin2hex( random_bytes( 12 ) ) . '@' . $dom . '>';
			if ( $o['dkim'] ) {
				$key = (string) get_option( 'mrsh_smtp_dkim', '' );
				if ( $key && is_email( $o['from'] ) ) {
					$m->DKIM_domain         = $dom;
					$m->DKIM_selector       = $o['sel'] ? $o['sel'] : 'mrsh';
					$m->DKIM_private_string = $key;
					$m->DKIM_identity       = $o['from'];
				}
			}
		} catch ( \Throwable $e ) {
			self::log( 'Setup problem: ' . $e->getMessage() );
		}
	}

	private static function log( $msg ) {
		$l = (array) get_option( 'mrsh_smtp_log', array() );
		array_unshift( $l, array( 't' => time(), 'm' => mb_substr( (string) $msg, 0, 400 ) ) );
		update_option( 'mrsh_smtp_log', array_slice( $l, 0, 30 ), false );
	}

	public static function failed( $err ) {
		$to = '';
		$d  = is_wp_error( $err ) ? $err->get_error_data() : array();
		if ( is_array( $d ) && ! empty( $d['to'] ) ) {
			$to = ' (to ' . ( is_array( $d['to'] ) ? implode( ', ', $d['to'] ) : $d['to'] ) . ')';
		}
		self::log( ( is_wp_error( $err ) ? $err->get_error_message() : 'Mail failed' ) . $to );
	}

	/* ---------- admin ---------- */
	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Email delivery', 'Email delivery', 'manage_options', 'mrsh-delivery', array( __CLASS__, 'page' ) );
	}

	private static function guard( $n ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( $n );
	}

	private static function back( $m ) {
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-delivery&msg=' . rawurlencode( $m ) ) );
		exit;
	}

	public static function save() {
		self::guard( 'mrsh_mail_save' );
		$o = self::opt();
		$n = array(
			'on'     => empty( $_POST['on'] ) ? 0 : 1,
			'host'   => sanitize_text_field( wp_unslash( $_POST['host'] ?? '' ) ), // phpcs:ignore
			'port'   => absint( $_POST['port'] ?? 587 ), // phpcs:ignore
			'secure' => in_array( $_POST['secure'] ?? '', array( 'tls', 'ssl', 'none' ), true ) ? $_POST['secure'] : 'tls', // phpcs:ignore
			'user'   => sanitize_text_field( wp_unslash( $_POST['user'] ?? '' ) ), // phpcs:ignore
			'pass'   => $o['pass'],
			'from'   => sanitize_email( wp_unslash( $_POST['from'] ?? '' ) ), // phpcs:ignore
			'name'   => sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) ), // phpcs:ignore
			'dkim'   => empty( $_POST['dkim'] ) ? 0 : 1,
			'sel'    => sanitize_key( wp_unslash( $_POST['sel'] ?? 'mrsh' ) ), // phpcs:ignore
			'unsub'  => empty( $_POST['unsub'] ) ? 0 : 1,
		);
		if ( isset( $_POST['pass'] ) && '' !== $_POST['pass'] ) { // phpcs:ignore
			$n['pass'] = self::enc( wp_unslash( $_POST['pass'] ) ); // phpcs:ignore
		}
		update_option( self::OPT, $n, false );
		self::back( 'Saved. Now press "Send a test email".' );
	}

	public static function keys() {
		self::guard( 'mrsh_mail_keys' );
		if ( ! function_exists( 'openssl_pkey_new' ) ) {
			self::back( 'This server has no OpenSSL, so keys cannot be made here. Ask your host, or turn DKIM on at your mail provider instead.' );
		}
		$r = openssl_pkey_new( array( 'private_key_bits' => 2048, 'private_key_type' => OPENSSL_KEYTYPE_RSA ) );
		if ( ! $r ) {
			self::back( 'The key could not be made.' );
		}
		openssl_pkey_export( $r, $priv );
		$pub = openssl_pkey_get_details( $r );
		update_option( 'mrsh_smtp_dkim', $priv, false );
		update_option( 'mrsh_smtp_dkim_pub', trim( preg_replace( '/-----[A-Z ]+-----|\s+/', '', $pub['key'] ) ), false );
		self::back( 'New DKIM key made. Copy the DKIM record below into your domain DNS, then tick "Sign my mail".' );
	}

	public static function test() {
		self::guard( 'mrsh_mail_test' );
		$to = sanitize_email( wp_unslash( $_POST['to'] ?? '' ) ); // phpcs:ignore
		if ( ! is_email( $to ) ) {
			self::back( 'Write a valid email address for the test.' );
		}
		update_option( 'mrsh_smtp_log', array(), false );
		$ok = wp_mail( $to, 'Test email from ' . wp_specialchars_decode( get_bloginfo( 'name' ) ), '<p>This is a test email from your website.</p><p>If you can read this in your <b>inbox</b> (not junk), email delivery works.</p>', array( 'Content-Type: text/html; charset=UTF-8' ) );
		$l = (array) get_option( 'mrsh_smtp_log', array() );
		self::back( $ok ? 'Test email sent to ' . $to . '. Look in the inbox and also in Junk/Spam.' : 'The test failed: ' . ( $l ? $l[0]['m'] : 'unknown reason' ) );
	}

	private static function txt( $name ) {
		if ( ! function_exists( 'dns_get_record' ) ) {
			return null;
		}
		$r = @dns_get_record( $name, DNS_TXT ); // phpcs:ignore
		if ( false === $r ) {
			return array();
		}
		$o = array();
		foreach ( $r as $x ) {
			$o[] = isset( $x['txt'] ) ? $x['txt'] : '';
		}
		return $o;
	}

	private static function checks() {
		$d   = self::domain();
		$out = array();
		$spf = self::txt( $d );
		if ( null === $spf ) {
			return array( array( 'DNS check', null, 'This server cannot look up DNS. Check the records at mxtoolbox.com instead.' ) );
		}
		$s = '';
		foreach ( $spf as $t ) {
			if ( 0 === stripos( $t, 'v=spf1' ) ) {
				$s = $t;
			}
		}
		$out[] = array( 'SPF record (who may send for ' . $d . ')', '' !== $s && false === strpos( $s, '+all' ), '' === $s ? 'Missing. Add a TXT record on ' . $d . ': ' . ( self::opt( 'host' ) ? 'v=spf1 include:YOUR-MAIL-PROVIDER ~all (your provider shows the exact include).' : 'v=spf1 +a +mx ~all' ) : ( 'Found: ' . $s ) );
		$dm = self::txt( '_dmarc.' . $d );
		$m  = '';
		foreach ( (array) $dm as $t ) {
			if ( 0 === stripos( $t, 'v=DMARC1' ) ) {
				$m = $t;
			}
		}
		$out[] = array( 'DMARC record (what to do with fake mail)', '' !== $m, '' === $m ? 'Missing. Add a TXT record named _dmarc.' . $d . ' with: v=DMARC1; p=none; rua=mailto:' . ( is_email( self::opt( 'from' ) ) ? self::opt( 'from' ) : 'you@' . $d ) : ( 'Found: ' . $m ) );
		$pub = (string) get_option( 'mrsh_smtp_dkim_pub', '' );
		if ( $pub ) {
			$sel = self::opt( 'sel' ) ? self::opt( 'sel' ) : 'mrsh';
			$k   = implode( '', (array) self::txt( $sel . '._domainkey.' . $d ) );
			$out[] = array( 'DKIM record (digital signature)', '' !== $k && false !== strpos( str_replace( ' ', '', $k ), substr( $pub, 0, 60 ) ), '' === $k ? 'Missing. Add the TXT record shown below.' : 'A record exists but it is not the key made here.' );
		}
		return $out;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$o    = self::opt();
		$card = 'background:#fff;border:1px solid #dcdcde;border-radius:14px;padding:6px 18px 16px;margin:14px 0;max-width:900px';
		$f    = function ( $n, $l, $v, $t = 'text', $x = '' ) {
			return '<p><label style="display:block;font-weight:600">' . esc_html( $l ) . '</label><input type="' . $t . '" name="' . $n . '" value="' . esc_attr( $v ) . '" class="regular-text" ' . $x . '></p>';
		};
		echo '<div class="wrap"><h1>Email delivery</h1>';
		if ( isset( $_GET['msg'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-info is-dismissible"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['msg'] ) ) ) . '</p></div>'; // phpcs:ignore
		}
		echo '<p style="max-width:860px">Mail sent straight from a web server usually goes to junk. The fix is to send through a real mail account (SMTP) and to prove with DNS records that your domain allows it. The plugin does the sending part, signs the mail, and checks the records for you.</p>';
		echo '<div style="' . $card . '"><h2>1. Mail account (SMTP)</h2><p>';
		foreach ( array( 'Gmail' => array( 'smtp.gmail.com', 587, 'tls' ), 'Brevo' => array( 'smtp-relay.brevo.com', 587, 'tls' ), 'Zoho' => array( 'smtp.zoho.com', 587, 'tls' ), 'My host' => array( 'mail.' . self::domain(), 465, 'ssl' ) ) as $n => $p ) {
			echo '<button type="button" class="button mrsh-pre" data-h="' . esc_attr( $p[0] ) . '" data-p="' . (int) $p[1] . '" data-s="' . esc_attr( $p[2] ) . '">' . esc_html( $n ) . '</button> ';
		}
		echo '</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_mail_save">' . wp_nonce_field( 'mrsh_mail_save', '_wpnonce', true, false );
		echo '<p><label><input type="checkbox" name="on" value="1"' . checked( $o['on'], 1, false ) . '> Send all website mail through this account</label></p>';
		echo $f( 'host', 'Server (host)', $o['host'], 'text', 'id="mrsh-h"' ); // phpcs:ignore
		echo $f( 'port', 'Port', $o['port'], 'number', 'id="mrsh-p" style="width:100px"' ); // phpcs:ignore
		echo '<p><label style="display:block;font-weight:600">Security</label><select name="secure" id="mrsh-s"><option value="tls"' . selected( $o['secure'], 'tls', false ) . '>TLS (port 587)</option><option value="ssl"' . selected( $o['secure'], 'ssl', false ) . '>SSL (port 465)</option><option value="none"' . selected( $o['secure'], 'none', false ) . '>None</option></select></p>';
		echo $f( 'user', 'Username (usually the full email address)', $o['user'], 'text', 'autocomplete="off"' ); // phpcs:ignore
		echo '<p><label style="display:block;font-weight:600">Password ' . ( $o['pass'] ? '(saved, leave empty to keep it)' : '' ) . '</label><input type="password" name="pass" class="regular-text" autocomplete="new-password"><br><span class="description">Gmail needs an "App password", not your normal password. It is stored encrypted and never put in exports.</span></p>';
		echo $f( 'from', 'Send mail from (an address on YOUR domain, e.g. info@' . self::domain() . ')', $o['from'], 'email' ); // phpcs:ignore
		echo $f( 'name', 'Sender name', $o['name'] ?: get_bloginfo( 'name' ) ); // phpcs:ignore
		echo '<p><label><input type="checkbox" name="unsub" value="1"' . checked( $o['unsub'], 1, false ) . '> Add the "unsubscribe" header (mail providers trust mail more with it)</label></p>';
		echo '<p><label><input type="checkbox" name="dkim" value="1"' . checked( $o['dkim'], 1, false ) . '> Sign my mail with DKIM (step 2)</label> &nbsp; selector <input type="text" name="sel" value="' . esc_attr( $o['sel'] ) . '" style="width:90px"></p>';
		echo '<p><button class="button button-primary">Save</button></p></form></div>';

		echo '<div style="' . $card . '"><h2>2. DKIM key (digital signature)</h2>';
		$pub = (string) get_option( 'mrsh_smtp_dkim_pub', '' );
		if ( $pub ) {
			echo '<p>Add this TXT record in your domain DNS:</p><p>Name: <code>' . esc_html( ( $o['sel'] ?: 'mrsh' ) . '._domainkey.' . self::domain() ) . '</code></p><p>Value:</p><textarea readonly rows="4" style="width:100%;font-family:monospace" onclick="this.select()">v=DKIM1; k=rsa; p=' . esc_textarea( $pub ) . '</textarea>';
		} else {
			echo '<p>If your mail provider (Brevo, Zoho, host) already signs your mail, skip this. Otherwise make a key here.</p>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_mail_keys">' . wp_nonce_field( 'mrsh_mail_keys', '_wpnonce', true, false ) . '<button class="button">' . ( $pub ? 'Make a new key' : 'Make DKIM key' ) . '</button></form></div>';

		echo '<div style="' . $card . '"><h2>3. Check my domain records</h2><p class="description">DNS changes can take up to a few hours to show.</p>';
		foreach ( self::checks() as $c ) {
			$col = null === $c[1] ? '#b45309' : ( $c[1] ? '#16a34a' : '#dc2626' );
			echo '<p style="display:flex;gap:10px;align-items:flex-start"><span style="flex:none;width:22px;height:22px;border-radius:50%;color:#fff;text-align:center;line-height:22px;background:' . $col . '">' . ( $c[1] ? '&#10003;' : '!' ) . '</span><span><b>' . esc_html( $c[0] ) . '</b><br><small style="word-break:break-all">' . esc_html( $c[2] ) . '</small></span></p>';
		}
		echo '</div>';

		echo '<div style="' . $card . '"><h2>4. Send a test email</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_mail_test">' . wp_nonce_field( 'mrsh_mail_test', '_wpnonce', true, false ) . '<input type="email" name="to" value="' . esc_attr( wp_get_current_user()->user_email ) . '" class="regular-text"> <button class="button button-primary">Send a test email</button></form>';
		$l = (array) get_option( 'mrsh_smtp_log', array() );
		if ( $l ) {
			echo '<h3>Recent mail problems</h3><ul style="list-style:disc;padding-left:20px">';
			foreach ( $l as $r ) {
				echo '<li><b>' . esc_html( wp_date( 'j M H:i', $r['t'] ) ) . '</b> ' . esc_html( $r['m'] ) . '</li>';
			}
			echo '</ul>';
		}
		echo '</div>';

		echo '<div style="' . $card . '"><h2>Rules that keep mail out of junk</h2><ul style="list-style:disc;padding-left:20px;max-width:800px"><li>Send from an address on your own domain, never from gmail.com or yahoo.com through your site.</li><li>SPF, DKIM and DMARC must all be green above.</li><li>Do not send many mails at once. New domains build trust slowly.</li><li>Keep messages short, with no ALL CAPS, no "FREE!!!" and few links.</li><li>Ask members to press "Not junk" or add your address to contacts once.</li><li>Check your domain once at mail-tester.com: send a test to the address it gives you; 9 out of 10 or more is good.</li></ul></div></div>';
		echo '<script>document.querySelectorAll(".mrsh-pre").forEach(function(b){b.onclick=function(){document.getElementById("mrsh-h").value=b.dataset.h;document.getElementById("mrsh-p").value=b.dataset.p;document.getElementById("mrsh-s").value=b.dataset.s}})</script>';
	}
}
MRSH_Delivery::init();
