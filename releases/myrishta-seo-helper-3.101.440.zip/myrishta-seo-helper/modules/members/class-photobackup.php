<?php
/**
 * Photo safety copy (3.101.37).
 * Every profile photo is also saved in the database as a small compressed copy (longest side 800 px, JPEG).
 * If the file in the uploads folder is ever missing (site copy, restore, host move), the theme shows the
 * safety copy automatically, so a profile never loses its picture. The full-size original stays in uploads.
 * Table: {prefix}mrsh_photo_bak. Picture address: /?mrsh_pb=ATTACHMENT_ID
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_PhotoBak {

	const DBV = '1';
	const MAX = 800;
	const CAP = 220000; // bytes per copy

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'mrsh_photo_bak';
	}

	public static function init() {
		add_action( 'init', array( __CLASS__, 'install' ), 5 );
		add_action( 'template_redirect', array( __CLASS__, 'serve' ), 1 );
		add_filter( 'wp_generate_attachment_metadata', array( __CLASS__, 'on_meta' ), 20, 2 );
		add_action( 'save_post_listing_type', array( __CLASS__, 'on_profile' ), 99 );
		add_action( 'wp_ajax_mrsh_pbak_batch', array( __CLASS__, 'ajax_batch' ) );
		add_action( 'delete_attachment', array( __CLASS__, 'on_delete' ) );
		// A photo chosen as a profile's main picture gets its safety copy right away (3.101.107).
		add_action( 'added_post_meta', array( __CLASS__, 'on_thumb_meta' ), 20, 4 );
		add_action( 'updated_post_meta', array( __CLASS__, 'on_thumb_meta' ), 20, 4 );
		// Every hour, a few more photos are copied into the database until all of them are safe (3.101.107).
		add_action( 'mrsh_pbak_cron', array( __CLASS__, 'cron' ) );
		add_action( 'init', function () {
			if ( ! wp_next_scheduled( 'mrsh_pbak_cron' ) ) {
				wp_schedule_event( time() + 300, 'hourly', 'mrsh_pbak_cron' );
			}
		}, 20 );
	}

	/** Main picture set on a profile. */
	public static function on_thumb_meta( $mid, $pid, $key, $val ) {
		if ( '_thumbnail_id' !== $key || ! $val || 'listing_type' !== get_post_type( $pid ) ) {
			return;
		}
		$aid = (int) $val;
		// Link the photo to its profile so it is counted, backed up and found again (3.101.107).
		if ( 'attachment' === get_post_type( $aid ) && (int) wp_get_post_parent_id( $aid ) !== (int) $pid ) {
			global $wpdb;
			$wpdb->update( $wpdb->posts, array( 'post_parent' => (int) $pid ), array( 'ID' => $aid ), array( '%d' ), array( '%d' ) ); // phpcs:ignore
			clean_post_cache( $aid );
		}
		self::save( $aid );
	}

	/** Hourly: copy the next 12 profile photos that have no safety copy; wraps around when all are done. */
	public static function cron() {
		global $wpdb;
		self::heal( 60 );
		self::match_loose();
		$after = (int) get_option( 'mrsh_pbak_cursor', 0 );
		$pt    = $wpdb->posts;
		$ids   = $wpdb->get_col( $wpdb->prepare( "SELECT a.ID FROM {$pt} a INNER JOIN {$pt} p ON p.ID = a.post_parent WHERE a.post_type='attachment' AND a.post_mime_type LIKE 'image/%%' AND p.post_type='listing_type' AND a.ID > %d ORDER BY a.ID ASC LIMIT 40", $after ) ); // phpcs:ignore
		$last  = $after;
		foreach ( $ids as $id ) {
			$last = (int) $id;
			if ( ! self::has( $id ) ) {
				self::save( $id );
			}
		}
		update_option( 'mrsh_pbak_cursor', count( $ids ) < 40 ? 0 : $last, false );
	}

	/** Profiles that own a photo but have no main picture: use the first attached photo as the main picture (3.101.107). Returns how many were fixed. */
	public static function heal( $limit = 60 ) {
		global $wpdb;
		$pt  = $wpdb->posts;
		$pm  = $wpdb->postmeta;
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT p.ID AS pid, MIN(a.ID) AS aid FROM {$pt} p INNER JOIN {$pt} a ON a.post_parent = p.ID AND a.post_type='attachment' AND a.post_mime_type LIKE 'image/%%' LEFT JOIN {$pm} m ON m.post_id = p.ID AND m.meta_key = '_thumbnail_id' AND m.meta_value > 0 WHERE p.post_type='listing_type' AND p.post_status IN ('publish','draft','pending') AND m.meta_id IS NULL GROUP BY p.ID LIMIT %d", (int) $limit ) ); // phpcs:ignore
		$n = 0;
		foreach ( (array) $rows as $r ) {
			$file = (string) get_attached_file( (int) $r->aid );
			if ( $file && file_exists( $file ) ) {
				update_post_meta( (int) $r->pid, '_thumbnail_id', (int) $r->aid );
				++$n;
			}
		}
		return $n;
	}

	/**
	 * Loose photos (not attached to anything) are matched to profiles that have no picture (3.101.107).
	 * Only high-confidence matches are linked: the photo was uploaded within 10 minutes of the profile being created, it is the
	 * closest photo to that profile AND that profile is the closest to the photo. Weaker matches are only listed in the option
	 * mrsh_pbak_prop for a person to review. Photos named like logos, icons or screenshots are never used.
	 */
	public static function match_loose() {
		global $wpdb;
		$pt = $wpdb->posts;
		$pm = $wpdb->postmeta;
		$profiles = $wpdb->get_results( "SELECT p.ID, UNIX_TIMESTAMP(p.post_date_gmt) AS t FROM {$pt} p LEFT JOIN {$pm} m ON m.post_id = p.ID AND m.meta_key = '_thumbnail_id' AND m.meta_value > 0 WHERE p.post_type='listing_type' AND p.post_status IN ('publish','draft','pending') AND m.meta_id IS NULL AND NOT EXISTS (SELECT 1 FROM {$pt} c WHERE c.post_parent = p.ID AND c.post_type='attachment' AND c.post_mime_type LIKE 'image/%')" ); // phpcs:ignore
		if ( ! $profiles ) {
			return 0;
		}
		$imgs = $wpdb->get_results( "SELECT a.ID, a.post_title, UNIX_TIMESTAMP(a.post_date_gmt) AS t FROM {$pt} a WHERE a.post_type='attachment' AND a.post_parent=0 AND a.post_mime_type LIKE 'image/%' AND NOT EXISTS (SELECT 1 FROM {$pm} u WHERE u.meta_key='_thumbnail_id' AND u.meta_value = a.ID) AND a.ID NOT IN (SELECT meta_value FROM {$pm} WHERE meta_key IN ('site_icon','_wp_attachment_context'))" ); // phpcs:ignore
		$bad  = '/logo|icon|screenshot|locked|banner|flag|og-image|favicon|badge|avatar/i';
		$near = function ( $t, $list ) {
			$best = null;
			$bd   = PHP_INT_MAX;
			foreach ( $list as $o ) {
				$d = abs( (int) $o->t - (int) $t );
				if ( $d < $bd ) {
					$bd   = $d;
					$best = $o;
				}
			}
			return array( $best, $bd );
		};
		$imgs = array_values( array_filter( (array) $imgs, function ( $i ) use ( $bad ) {
			return ! preg_match( $bad, (string) $i->post_title );
		} ) );
		if ( ! $imgs ) {
			return 0;
		}
		$done = 0;
		$prop = array();
		foreach ( $profiles as $pr ) {
			list( $img, $d ) = $near( $pr->t, $imgs );
			if ( ! $img ) {
				continue;
			}
			list( $back, ) = $near( $img->t, $profiles );
			$ok = ( (int) $back->ID === (int) $pr->ID );
			if ( $ok && $d <= 600 ) {
				$wpdb->update( $wpdb->posts, array( 'post_parent' => (int) $pr->ID ), array( 'ID' => (int) $img->ID ), array( '%d' ), array( '%d' ) ); // phpcs:ignore
				clean_post_cache( (int) $img->ID );
				update_post_meta( (int) $pr->ID, '_thumbnail_id', (int) $img->ID );
				self::save( (int) $img->ID );
				++$done;
			} elseif ( $d <= 3600 ) {
				$prop[ (int) $pr->ID ] = array( (int) $img->ID, (int) $d, $ok ? 1 : 0 );
			}
		}
		update_option( 'mrsh_pbak_prop', $prop, false );
		update_option( 'mrsh_pbak_matched', (int) get_option( 'mrsh_pbak_matched', 0 ) + $done, false );
		return $done;
	}

	public static function install() {
		if ( get_option( 'mrsh_pbak_db' ) === self::DBV ) {
			return;
		}
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$t  = self::table();
		$cc = $wpdb->get_charset_collate();
		dbDelta( "CREATE TABLE {$t} (
			att_id bigint(20) unsigned NOT NULL,
			post_id bigint(20) unsigned NOT NULL DEFAULT 0,
			mime varchar(40) NOT NULL DEFAULT 'image/jpeg',
			w smallint(5) unsigned NOT NULL DEFAULT 0,
			h smallint(5) unsigned NOT NULL DEFAULT 0,
			len int(10) unsigned NOT NULL DEFAULT 0,
			created datetime NOT NULL,
			data mediumblob NOT NULL,
			PRIMARY KEY  (att_id),
			KEY post_id (post_id)
		) {$cc};" );
		update_option( 'mrsh_pbak_db', self::DBV, false );
	}

	/** Address of the safety copy, or '' when none is stored. */
	public static function url( $aid ) {
		return self::has( $aid ) ? add_query_arg( 'mrsh_pb', (int) $aid, home_url( '/' ) ) : '';
	}

	public static function has( $aid ) {
		global $wpdb;
		static $cache = array();
		$aid = (int) $aid;
		if ( ! $aid ) {
			return false;
		}
		if ( ! isset( $cache[ $aid ] ) ) {
			$cache[ $aid ] = (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT att_id FROM ' . self::table() . ' WHERE att_id = %d', $aid ) ); // phpcs:ignore
		}
		return $cache[ $aid ];
	}

	/** Saves one safety copy. Returns true when stored (or already stored). */
	public static function save( $aid, $force = false ) {
		global $wpdb;
		$aid = (int) $aid;
		if ( ! $aid || 'attachment' !== get_post_type( $aid ) || 0 !== strpos( (string) get_post_mime_type( $aid ), 'image/' ) ) {
			return false;
		}
		if ( ! $force && self::has( $aid ) ) {
			return true;
		}
		$file = (string) get_attached_file( $aid );
		if ( ! $file || ! file_exists( $file ) ) {
			return false;
		}
		// These helpers are only loaded inside wp-admin; cron and front-end requests need them too (3.101.107).
		if ( ! function_exists( 'wp_tempnam' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		if ( ! function_exists( 'wp_get_image_editor' ) ) {
			require_once ABSPATH . WPINC . '/media.php';
		}
		$ed = wp_get_image_editor( $file );
		if ( is_wp_error( $ed ) ) {
			return false;
		}
		$sz = $ed->get_size();
		if ( max( (int) $sz['width'], (int) $sz['height'] ) > self::MAX ) {
			$ed->resize( self::MAX, self::MAX, false );
		}
		$bin = '';
		foreach ( array( 78, 64, 50 ) as $q ) {
			$ed->set_quality( $q );
			$tmp = wp_tempnam( 'mrsh-pb' );
			$res = $ed->save( $tmp . '.jpg', 'image/jpeg' );
			@unlink( $tmp ); // phpcs:ignore
			if ( is_wp_error( $res ) || empty( $res['path'] ) ) {
				return false;
			}
			$bin = (string) file_get_contents( $res['path'] ); // phpcs:ignore
			$dim = array( (int) ( $res['width'] ?? 0 ), (int) ( $res['height'] ?? 0 ) );
			@unlink( $res['path'] ); // phpcs:ignore
			if ( '' !== $bin && strlen( $bin ) <= self::CAP ) {
				break;
			}
		}
		if ( '' === $bin || strlen( $bin ) > self::CAP * 2 ) {
			return false;
		}
		$ok = $wpdb->replace( self::table(), array( 'att_id' => $aid, 'post_id' => (int) wp_get_post_parent_id( $aid ), 'mime' => 'image/jpeg', 'w' => $dim[0], 'h' => $dim[1], 'len' => strlen( $bin ), 'created' => current_time( 'mysql', true ), 'data' => $bin ), array( '%d', '%d', '%s', '%d', '%d', '%d', '%s', '%s' ) ); // phpcs:ignore
		return false !== $ok;
	}

	/** New upload that belongs to a profile. */
	public static function on_meta( $meta, $aid ) {
		$par = (int) wp_get_post_parent_id( $aid );
		if ( $par && 'listing_type' === get_post_type( $par ) ) {
			self::save( $aid );
		}
		return $meta;
	}

	/** Profile saved: make sure its photos have safety copies. */
	public static function on_profile( $pid ) {
		if ( wp_is_post_revision( $pid ) ) {
			return;
		}
		$ids = array( (int) get_post_thumbnail_id( $pid ) );
		foreach ( get_children( array( 'post_parent' => $pid, 'post_type' => 'attachment', 'post_mime_type' => 'image', 'numberposts' => 12, 'fields' => 'ids' ) ) as $c ) {
			$ids[] = (int) ( is_object( $c ) ? $c->ID : $c );
		}
		foreach ( array_unique( array_filter( $ids ) ) as $a ) {
			self::save( $a );
		}
	}

	public static function on_delete( $aid ) {
		global $wpdb;
		$wpdb->delete( self::table(), array( 'att_id' => (int) $aid ), array( '%d' ) ); // phpcs:ignore
	}

	/** /?mrsh_pb=ID sends the stored picture. */
	public static function serve() {
		if ( empty( $_GET['mrsh_pb'] ) ) { // phpcs:ignore
			return;
		}
		global $wpdb;
		$aid = absint( $_GET['mrsh_pb'] ); // phpcs:ignore
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT mime, data, created FROM ' . self::table() . ' WHERE att_id = %d', $aid ), ARRAY_A ); // phpcs:ignore
		if ( ! $row ) {
			status_header( 404 );
			exit;
		}
		$etag = '"mrsh' . $aid . '-' . md5( $row['created'] . strlen( $row['data'] ) ) . '"';
		header( 'ETag: ' . $etag );
		if ( isset( $_SERVER['HTTP_IF_NONE_MATCH'] ) && trim( (string) $_SERVER['HTTP_IF_NONE_MATCH'] ) === $etag ) { // phpcs:ignore
			status_header( 304 );
			exit;
		}
		header( 'Content-Type: ' . $row['mime'] );
		header( 'Content-Length: ' . strlen( $row['data'] ) );
		header( 'Cache-Control: public, max-age=2592000' );
		header( 'X-Content-Type-Options: nosniff' );
		echo $row['data']; // phpcs:ignore
		exit;
	}

	/* ---------- admin: counts and batch backup ---------- */

	/** array( profile photo attachments, with a safety copy, bytes stored ) */
	public static function stats() {
		global $wpdb;
		$pt  = $wpdb->posts;
		$tot = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$pt} a INNER JOIN {$pt} p ON p.ID = a.post_parent WHERE a.post_type='attachment' AND a.post_mime_type LIKE 'image/%' AND p.post_type='listing_type'" ); // phpcs:ignore
		$bak = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::table() ); // phpcs:ignore
		$by  = (int) $wpdb->get_var( 'SELECT COALESCE(SUM(len),0) FROM ' . self::table() ); // phpcs:ignore
		return array( $tot, $bak, $by );
	}

	public static function ajax_batch() {
		if ( ! current_user_can( 'manage_options' ) || ! check_ajax_referer( 'mrsh_pbak', 'n', false ) ) {
			wp_send_json_error( 'Not allowed.' );
		}
		global $wpdb;
		@set_time_limit( 60 ); // phpcs:ignore
		$after = isset( $_POST['after'] ) ? absint( $_POST['after'] ) : 0; // phpcs:ignore
		$pt    = $wpdb->posts;
		$ids   = $wpdb->get_col( $wpdb->prepare( "SELECT a.ID FROM {$pt} a INNER JOIN {$pt} p ON p.ID = a.post_parent WHERE a.post_type='attachment' AND a.post_mime_type LIKE 'image/%%' AND p.post_type='listing_type' AND a.ID > %d ORDER BY a.ID ASC LIMIT 12", $after ) ); // phpcs:ignore
		$done = 0;
		$skip = 0;
		$last = $after;
		foreach ( $ids as $id ) {
			$last = (int) $id;
			if ( self::has( $id ) ) {
				continue;
			}
			if ( self::save( $id ) ) {
				$done++;
			} else {
				$skip++; // file missing here or not readable
			}
		}
		$st = self::stats();
		wp_send_json_success( array( 'done' => $done, 'skip' => $skip, 'next' => $last, 'end' => count( $ids ) < 12, 'total' => $st[0], 'have' => $st[1], 'bytes' => $st[2] ) );
	}
}
MRSH_PhotoBak::init();
