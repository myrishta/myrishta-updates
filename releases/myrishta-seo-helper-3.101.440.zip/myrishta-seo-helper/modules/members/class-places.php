<?php
/**
 * Place stories: every day 10 places of Pakistan (city, district, town or village) with a short old history and what the place
 * is known for, in Urdu first and English below. Members see them in My account and with the shortcode [mrsh_place_of_day].
 * Data comes from data/places*.json inside the plugin (one new file of 10 places is added every day) plus the admin's own edits.
 * Admin page: Growth > Place stories (review, approve, edit, add, import, export). Only approved places are shown to members.
 * Options: mrsh_places_cfg (settings), mrsh_places_ed (admin edits, one array per place id). No database tables.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Places {

	const CFG = 'mrsh_places_cfg';
	const ED  = 'mrsh_places_ed';

	public static function cfg( $k = null ) {
		$o = array_merge( array( 'on' => 1, 'per_day' => 10, 'show_new' => 0, 'account' => 1 ), (array) get_option( self::CFG, array() ) );
		return null === $k ? $o : $o[ $k ];
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 34 );
		add_action( 'admin_post_mrsh_pl_cfg', array( __CLASS__, 'save_cfg' ) );
		add_action( 'admin_post_mrsh_pl_save', array( __CLASS__, 'save_one' ) );
		add_action( 'admin_post_mrsh_pl_del', array( __CLASS__, 'del_one' ) );
		add_action( 'admin_post_mrsh_pl_ok', array( __CLASS__, 'approve' ) );
		add_action( 'admin_post_mrsh_pl_import', array( __CLASS__, 'import' ) );
		add_action( 'admin_post_mrsh_pl_export', array( __CLASS__, 'export' ) );
		add_action( 'admin_post_mrsh_pl_reset', array( __CLASS__, 'reset' ) );
		add_shortcode( 'mrsh_place_of_day', array( __CLASS__, 'shortcode' ) );
		add_action( 'mrt_account_extra', array( __CLASS__, 'account' ), 40 );
	}

	/* ================= pure logic (tested with a stub harness) ================= */

	/** Day number in the site's time zone. */
	public static function day_number( $ts, $offset_seconds = 0 ) {
		return (int) floor( ( (int) $ts + (int) $offset_seconds ) / 86400 );
	}

	/** Pick $n ids for a day from an ordered id list. Walks through the list so every place is shown before any repeats. */
	public static function pick( array $ids, $day, $n = 10 ) {
		$ids = array_values( $ids );
		$c   = count( $ids );
		$n   = max( 1, (int) $n );
		if ( 0 === $c ) {
			return array();
		}
		if ( $c <= $n ) {
			return $ids;
		}
		$out   = array();
		$start = ( ( (int) $day * $n ) % $c + $c ) % $c;
		for ( $i = 0; $i < $n; $i++ ) {
			$out[] = $ids[ ( $start + $i ) % $c ];
		}
		return $out;
	}

	/** Clean one place array. Returns null when it has no id or name. */
	public static function clean( $p ) {
		if ( ! is_array( $p ) ) {
			return null;
		}
		$id = sanitize_key( (string) ( $p['id'] ?? '' ) );
		$f  = function ( $k, $max ) use ( $p ) {
			$v = isset( $p[ $k ] ) ? (string) $p[ $k ] : '';
			$v = sanitize_textarea_field( $v );
			return function_exists( 'mb_substr' ) ? mb_substr( $v, 0, $max ) : substr( $v, 0, $max );
		};
		$o = array(
			'id'       => $id,
			'kind'     => in_array( $p['kind'] ?? '', array( 'city', 'district', 'town', 'village' ), true ) ? $p['kind'] : 'city',
			'province' => $f( 'province', 60 ),
			'en'       => $f( 'en', 80 ),
			'ur'       => $f( 'ur', 80 ),
			'hist_ur'  => $f( 'hist_ur', 900 ),
			'known_ur' => $f( 'known_ur', 700 ),
			'hist_en'  => $f( 'hist_en', 900 ),
			'known_en' => $f( 'known_en', 700 ),
		);
		if ( '' === $o['id'] || ( '' === $o['en'] && '' === $o['ur'] ) ) {
			return null;
		}
		return $o;
	}

	/** Parse JSON text into a list of clean places (invalid entries are skipped). */
	public static function parse_json( $text ) {
		$d = json_decode( (string) $text, true );
		if ( ! is_array( $d ) ) {
			return array();
		}
		if ( isset( $d['id'] ) ) {
			$d = array( $d );
		}
		$out = array();
		foreach ( $d as $row ) {
			$c = self::clean( $row );
			if ( $c ) {
				$out[ $c['id'] ] = $c;
			}
		}
		return $out;
	}

	/* ================= data ================= */

	/** All places: plugin files (sorted by file name, later files add more places), then the admin's edits on top. */
	public static function all() {
		static $cache = null;
		if ( null !== $cache ) {
			return $cache;
		}
		$list = array();
		try {
			$files = (array) glob( MRSH_DIR . 'data/places*.json' );
			sort( $files );
			foreach ( $files as $f ) {
				$t = is_readable( $f ) ? (string) file_get_contents( $f ) : ''; // phpcs:ignore
				foreach ( self::parse_json( $t ) as $id => $p ) {
					if ( ! isset( $list[ $id ] ) ) {
						$list[ $id ] = $p;
					}
				}
			}
			foreach ( (array) get_option( self::ED, array() ) as $id => $e ) {
				if ( ! is_array( $e ) ) {
					continue;
				}
				if ( ! empty( $e['deleted'] ) ) {
					unset( $list[ $id ] );
					continue;
				}
				$c = self::clean( array_merge( $list[ $id ] ?? array(), $e, array( 'id' => $id ) ) );
				if ( $c ) {
					$c['ok']     = ! empty( $e['ok'] ) ? 1 : 0;
					$list[ $id ] = $c;
				}
			}
		} catch ( \Throwable $e ) {
			MRSH_Safe::log_ex( $e, 'MRSH_Places::all' );
		}
		$cache = $list;
		return $list;
	}

	public static function approved( $p ) {
		return ! empty( $p['ok'] ) || (bool) self::cfg( 'show_new' );
	}

	/** The places for a day (approved ones only). */
	public static function today( $ts = null ) {
		$ts   = null === $ts ? time() : $ts;
		$off  = (int) round( (float) get_option( 'gmt_offset', 0 ) * 3600 );
		$ids  = array();
		foreach ( self::all() as $id => $p ) {
			if ( self::approved( $p ) ) {
				$ids[] = $id;
			}
		}
		$all = self::all();
		$out = array();
		foreach ( self::pick( $ids, self::day_number( $ts, $off ), max( 1, min( 30, (int) self::cfg( 'per_day' ) ) ) ) as $id ) {
			$out[] = $all[ $id ];
		}
		return $out;
	}

	/* ================= member side ================= */

	private static function card( $p, $open = false ) {
		$h  = '<details class="mrsh-pl-item"' . ( $open ? ' open' : '' ) . ' style="border:1px solid #f3d6e2;border-radius:12px;padding:10px 14px;margin:8px 0;background:#fff">';
		$h .= '<summary style="cursor:pointer;font-weight:700"><span lang="ur" dir="rtl">' . esc_html( $p['ur'] ?: $p['en'] ) . '</span>';
		if ( $p['en'] && $p['ur'] ) {
			$h .= ' <span style="color:#777;font-weight:400">· ' . esc_html( $p['en'] ) . '</span>';
		}
		if ( $p['province'] ) {
			$h .= ' <small style="color:#999;font-weight:400" lang="ur">(' . esc_html( $p['province'] ) . ')</small>';
		}
		$h .= '</summary>';
		if ( $p['hist_ur'] || $p['known_ur'] ) {
			$h .= '<div lang="ur" dir="rtl" style="line-height:2;margin-top:8px">';
			if ( $p['hist_ur'] ) {
				$h .= '<p style="margin:.3em 0"><strong>تاریخ:</strong> ' . esc_html( $p['hist_ur'] ) . '</p>';
			}
			if ( $p['known_ur'] ) {
				$h .= '<p style="margin:.3em 0"><strong>مشہور:</strong> ' . esc_html( $p['known_ur'] ) . '</p>';
			}
			$h .= '</div>';
		}
		if ( $p['hist_en'] || $p['known_en'] ) {
			$h .= '<div lang="en" dir="ltr" style="color:#444;margin-top:6px;font-size:.95em">';
			if ( $p['hist_en'] ) {
				$h .= '<p style="margin:.3em 0"><strong>History:</strong> ' . esc_html( $p['hist_en'] ) . '</p>';
			}
			if ( $p['known_en'] ) {
				$h .= '<p style="margin:.3em 0"><strong>Known for:</strong> ' . esc_html( $p['known_en'] ) . '</p>';
			}
			$h .= '</div>';
		}
		return $h . '</details>';
	}

	public static function html() {
		try {
			$set = self::today();
			if ( ! $set ) {
				return '';
			}
			$h = '<section class="mrsh-places" style="margin:18px 0"><h3 style="margin:0 0 4px"><span lang="ur" dir="rtl">آج کے دس مقامات</span> <small style="color:#777;font-weight:400">· Places of the day</small></h3>';
			$h .= '<p lang="ur" dir="rtl" style="margin:0 0 8px;color:#666">پاکستان کے شہروں، اضلاع اور قصبوں کی مختصر تاریخ اور خوبیاں۔</p>';
			foreach ( $set as $i => $p ) {
				$h .= self::card( $p, 0 === $i );
			}
			return $h . '</section>';
		} catch ( \Throwable $e ) {
			MRSH_Safe::log_ex( $e, 'MRSH_Places::html' );
			return '';
		}
	}

	public static function shortcode() {
		return self::cfg( 'on' ) ? self::html() : '';
	}

	public static function account() {
		if ( self::cfg( 'on' ) && self::cfg( 'account' ) ) {
			echo self::html(); // phpcs:ignore WordPress.Security.EscapeOutput -- built with esc_html above
		}
	}

	/* ================= admin side ================= */

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Place stories', 'Place stories', 'manage_options', 'mrsh-places', array( __CLASS__, 'page' ) );
	}

	private static function guard( $nonce ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'default' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( $nonce );
	}

	private static function back( $msg ) {
		wp_safe_redirect( add_query_arg( array( 'page' => 'mrsh-places', 'm' => rawurlencode( $msg ) ), admin_url( 'admin.php' ) ) );
		exit;
	}

	private static function edits() {
		return (array) get_option( self::ED, array() );
	}

	public static function save_cfg() {
		self::guard( 'mrsh_pl_cfg' );
		update_option( self::CFG, array(
			'on'       => empty( $_POST['on'] ) ? 0 : 1,
			'account'  => empty( $_POST['account'] ) ? 0 : 1,
			'show_new' => empty( $_POST['show_new'] ) ? 0 : 1,
			'per_day'  => max( 1, min( 30, absint( $_POST['per_day'] ?? 10 ) ) ), // phpcs:ignore
		), false );
		self::back( 'Saved.' );
	}

	public static function save_one() {
		self::guard( 'mrsh_pl_save' );
		try {
			$raw = array();
			foreach ( array( 'id', 'kind', 'province', 'en', 'ur', 'hist_ur', 'known_ur', 'hist_en', 'known_en' ) as $k ) {
				$raw[ $k ] = wp_unslash( $_POST[ $k ] ?? '' ); // phpcs:ignore
			}
			if ( '' === $raw['id'] ) {
				$raw['id'] = sanitize_title( (string) $raw['en'] );
			}
			$c = self::clean( $raw );
			if ( ! $c ) {
				self::back( 'Nothing saved: a name is needed.' );
			}
			$ed        = self::edits();
			$c['ok']   = empty( $_POST['ok'] ) ? 0 : 1;
			$ed[ $c['id'] ] = $c;
			update_option( self::ED, $ed, false );
			self::back( 'Saved: ' . $c['id'] );
		} catch ( \Throwable $e ) {
			MRSH_Safe::log_ex( $e, 'MRSH_Places::save_one' );
			self::back( 'Could not save. See the Problems page.' );
		}
	}

	public static function del_one() {
		self::guard( 'mrsh_pl_del' );
		$id = sanitize_key( wp_unslash( $_POST['id'] ?? '' ) ); // phpcs:ignore
		if ( $id ) {
			$ed        = self::edits();
			$ed[ $id ] = array( 'deleted' => 1 );
			update_option( self::ED, $ed, false );
		}
		self::back( 'Removed from the list.' );
	}

	public static function approve() {
		self::guard( 'mrsh_pl_ok' );
		$ed = self::edits();
		if ( ! empty( $_POST['all'] ) ) { // phpcs:ignore
			foreach ( self::all() as $id => $p ) {
				$ed[ $id ]       = array_merge( isset( $ed[ $id ] ) && is_array( $ed[ $id ] ) ? $ed[ $id ] : array(), array( 'ok' => 1 ) );
			}
			$msg = 'All places approved.';
		} else {
			$id = sanitize_key( wp_unslash( $_POST['id'] ?? '' ) ); // phpcs:ignore
			if ( $id && isset( self::all()[ $id ] ) ) {
				$on        = ! empty( $_POST['on'] ) ? 1 : 0; // phpcs:ignore
				$ed[ $id ] = array_merge( isset( $ed[ $id ] ) && is_array( $ed[ $id ] ) ? $ed[ $id ] : array(), array( 'ok' => $on ) );
			}
			$msg = 'Updated.';
		}
		update_option( self::ED, $ed, false );
		self::back( $msg );
	}

	public static function import() {
		self::guard( 'mrsh_pl_import' );
		$list = self::parse_json( wp_unslash( $_POST['json'] ?? '' ) ); // phpcs:ignore
		if ( ! $list ) {
			self::back( 'Nothing imported: the text is not a valid list of places.' );
		}
		$ed = self::edits();
		foreach ( $list as $id => $p ) {
			$p['ok']   = 0; // imported places always wait for approval
			$ed[ $id ] = $p;
		}
		update_option( self::ED, $ed, false );
		self::back( count( $list ) . ' places imported. They wait for your approval.' );
	}

	public static function export() {
		self::guard( 'mrsh_pl_export' );
		$out = array_values( self::all() );
		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="places-' . gmdate( 'Ymd' ) . '.json"' );
		echo wp_json_encode( $out, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ); // phpcs:ignore
		exit;
	}

	public static function reset() {
		self::guard( 'mrsh_pl_reset' );
		delete_option( self::ED );
		self::back( 'Your edits and approvals were cleared. The plugin list is shown again.' );
	}

	private static function field( $name, $label, $val, $rtl = false, $area = false ) {
		echo '<p><label><strong>' . esc_html( $label ) . '</strong><br>';
		if ( $area ) {
			echo '<textarea name="' . esc_attr( $name ) . '" rows="3" class="large-text"' . ( $rtl ? ' dir="rtl"' : '' ) . '>' . esc_textarea( $val ) . '</textarea>';
		} else {
			echo '<input type="text" name="' . esc_attr( $name ) . '" value="' . esc_attr( $val ) . '" class="regular-text"' . ( $rtl ? ' dir="rtl"' : '' ) . '>';
		}
		echo '</label></p>';
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		try {
			$all  = self::all();
			$cfg  = self::cfg();
			$ok   = 0;
			foreach ( $all as $p ) {
				$ok += ! empty( $p['ok'] ) ? 1 : 0;
			}
			$edit = isset( $_GET['edit'] ) ? sanitize_key( wp_unslash( $_GET['edit'] ) ) : ''; // phpcs:ignore
			$cur  = $edit && isset( $all[ $edit ] ) ? $all[ $edit ] : array_fill_keys( array( 'id', 'kind', 'province', 'en', 'ur', 'hist_ur', 'known_ur', 'hist_en', 'known_en' ), '' );
			$post = admin_url( 'admin-post.php' );
			echo '<div class="wrap"><h1>Place stories</h1>';
			if ( ! empty( $_GET['m'] ) ) { // phpcs:ignore
				echo '<div class="notice notice-info is-dismissible"><p>' . esc_html( rawurldecode( wp_unslash( $_GET['m'] ) ) ) . '</p></div>'; // phpcs:ignore
			}
			echo '<p>Every day 10 places of Pakistan are shown to members in My account (Urdu first, English below). A new daily batch of 10 places is added to the plugin; places wait here until you approve them. Total: <strong>' . (int) count( $all ) . '</strong>, approved: <strong>' . (int) $ok . '</strong>.</p>';

			// Settings.
			echo '<h2>Settings</h2><form method="post" action="' . esc_url( $post ) . '">';
			wp_nonce_field( 'mrsh_pl_cfg' );
			echo '<input type="hidden" name="action" value="mrsh_pl_cfg">';
			echo '<p><label><input type="checkbox" name="on" value="1"' . checked( $cfg['on'], 1, false ) . '> Show place stories (shortcode <code>[mrsh_place_of_day]</code>)</label></p>';
			echo '<p><label><input type="checkbox" name="account" value="1"' . checked( $cfg['account'], 1, false ) . '> Show the card inside My account</label></p>';
			echo '<p><label><input type="checkbox" name="show_new" value="1"' . checked( $cfg['show_new'], 1, false ) . '> Also show places I have not approved yet (not recommended)</label></p>';
			echo '<p><label>Places per day <input type="number" name="per_day" min="1" max="30" value="' . (int) $cfg['per_day'] . '" class="small-text"></label></p>';
			echo '<p><button class="button button-primary">Save settings</button></p></form>';

			// Today.
			echo '<h2>Today\'s set</h2><ol>';
			foreach ( self::today() as $p ) {
				echo '<li>' . esc_html( $p['en'] ?: $p['ur'] ) . ' <span dir="rtl" lang="ur">' . esc_html( $p['ur'] ) . '</span></li>';
			}
			echo '</ol>';
			if ( ! self::today() ) {
				echo '<p><em>Nothing to show yet: approve some places below.</em></p>';
			}
			echo '<form method="post" action="' . esc_url( $post ) . '" style="display:inline">';
			wp_nonce_field( 'mrsh_pl_ok' );
			echo '<input type="hidden" name="action" value="mrsh_pl_ok"><input type="hidden" name="all" value="1"><button class="button" onclick="return confirm(\'Approve every place in the list? Please read them first.\')">Approve all</button></form> ';
			echo '<form method="post" action="' . esc_url( $post ) . '" style="display:inline">';
			wp_nonce_field( 'mrsh_pl_export' );
			echo '<input type="hidden" name="action" value="mrsh_pl_export"><button class="button">Download list (JSON)</button></form> ';
			echo '<form method="post" action="' . esc_url( $post ) . '" style="display:inline">';
			wp_nonce_field( 'mrsh_pl_reset' );
			echo '<input type="hidden" name="action" value="mrsh_pl_reset"><button class="button" onclick="return confirm(\'Clear all your edits and approvals?\')">Clear my edits</button></form>';

			// List.
			echo '<h2>All places</h2><table class="widefat striped"><thead><tr><th>Place</th><th>Kind</th><th>Province</th><th>Status</th><th></th></tr></thead><tbody>';
			foreach ( $all as $id => $p ) {
				echo '<tr><td>' . esc_html( $p['en'] ) . ' <span dir="rtl" lang="ur">' . esc_html( $p['ur'] ) . '</span></td><td>' . esc_html( $p['kind'] ) . '</td><td lang="ur">' . esc_html( $p['province'] ) . '</td><td>' . ( ! empty( $p['ok'] ) ? 'Approved' : 'Waiting' ) . '</td><td>';
				echo '<a class="button button-small" href="' . esc_url( add_query_arg( array( 'page' => 'mrsh-places', 'edit' => $id ), admin_url( 'admin.php' ) ) ) . '#mrsh-pl-edit">Edit</a> ';
				echo '<form method="post" action="' . esc_url( $post ) . '" style="display:inline">';
				wp_nonce_field( 'mrsh_pl_ok' );
				echo '<input type="hidden" name="action" value="mrsh_pl_ok"><input type="hidden" name="id" value="' . esc_attr( $id ) . '"><input type="hidden" name="on" value="' . ( ! empty( $p['ok'] ) ? 0 : 1 ) . '"><button class="button button-small">' . ( ! empty( $p['ok'] ) ? 'Hide' : 'Approve' ) . '</button></form> ';
				echo '<form method="post" action="' . esc_url( $post ) . '" style="display:inline">';
				wp_nonce_field( 'mrsh_pl_del' );
				echo '<input type="hidden" name="action" value="mrsh_pl_del"><input type="hidden" name="id" value="' . esc_attr( $id ) . '"><button class="button button-small" onclick="return confirm(\'Remove this place from the list?\')">Remove</button></form>';
				echo '</td></tr>';
			}
			echo '</tbody></table>';

			// Edit or add.
			echo '<h2 id="mrsh-pl-edit">' . ( $edit ? 'Edit place' : 'Add a place' ) . '</h2><form method="post" action="' . esc_url( $post ) . '">';
			wp_nonce_field( 'mrsh_pl_save' );
			echo '<input type="hidden" name="action" value="mrsh_pl_save"><input type="hidden" name="id" value="' . esc_attr( $cur['id'] ) . '">';
			self::field( 'en', 'Name (English)', $cur['en'] );
			self::field( 'ur', 'نام (اردو)', $cur['ur'], true );
			self::field( 'province', 'Province (Urdu)', $cur['province'], true );
			echo '<p><label><strong>Kind</strong> <select name="kind">';
			foreach ( array( 'city', 'district', 'town', 'village' ) as $k ) {
				echo '<option value="' . esc_attr( $k ) . '"' . selected( $cur['kind'] ?: 'city', $k, false ) . '>' . esc_html( $k ) . '</option>';
			}
			echo '</select></label></p>';
			self::field( 'hist_ur', 'تاریخ (اردو)', $cur['hist_ur'], true, true );
			self::field( 'known_ur', 'مشہور (اردو)', $cur['known_ur'], true, true );
			self::field( 'hist_en', 'History (English)', $cur['hist_en'], false, true );
			self::field( 'known_en', 'Known for (English)', $cur['known_en'], false, true );
			echo '<p><label><input type="checkbox" name="ok" value="1"' . checked( ! empty( $cur['ok'] ), true, false ) . '> Approved (members can see it). Tick only after you have checked the facts.</label></p>';
			echo '<p><button class="button button-primary">Save place</button></p></form>';

			// Import.
			echo '<h2>Import</h2><p>Paste a JSON list of places (same format as the download). Imported places wait for approval.</p><form method="post" action="' . esc_url( $post ) . '">';
			wp_nonce_field( 'mrsh_pl_import' );
			echo '<input type="hidden" name="action" value="mrsh_pl_import"><textarea name="json" rows="6" class="large-text code"></textarea><p><button class="button">Import</button></p></form></div>';
		} catch ( \Throwable $e ) {
			MRSH_Safe::log_ex( $e, 'MRSH_Places::page' );
			echo '<div class="wrap"><p>This page had a problem. It was logged on the Problems page.</p></div>';
		}
	}
}
MRSH_Places::init();
