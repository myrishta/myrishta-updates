<?php
/**
 * Auto ads, more channels (3.101.107): Discord, Mastodon, Bluesky, X, Tumblr, Threads, LinkedIn, Pinterest, Reddit and a webhook
 * (Zapier / Make / IFTTT reach WhatsApp, YouTube, Google Business and hundreds more). Plus hand-share buttons for sites without a posting API.
 * Keys are saved in option mrsh_ads_ch, never printed back (leave a key box empty to keep the saved one).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_AutoAds_More {

	const OPT = 'mrsh_ads_ch';

	/** key => label, colour, limit, fields (name => array(label, secret?)), help */
	public static function channels() {
		return array(
			'discord'   => array( 'Discord', '#5865f2', 1900, array( 'url' => array( 'Webhook address', 1 ) ), 'Server settings > Integrations > Webhooks > New webhook > Copy URL. Free.' ),
			'mastodon'  => array( 'Mastodon', '#6364ff', 450, array( 'host' => array( 'Server (for example mastodon.social)', 0 ), 'token' => array( 'Access token', 1 ) ), 'Preferences > Development > New application (write:statuses), copy the access token. Free.' ),
			'bluesky'   => array( 'Bluesky', '#0085ff', 290, array( 'handle' => array( 'Handle (name.bsky.social)', 0 ), 'pass' => array( 'App password', 1 ) ), 'Settings > App passwords > Add. Do not use your main password. Free.' ),
			'x'         => array( 'X (Twitter)', '#111827', 270, array( 'ck' => array( 'API key', 0 ), 'cs' => array( 'API key secret', 1 ), 'at' => array( 'Access token', 0 ), 'ts' => array( 'Access token secret', 1 ) ), 'developer.x.com: create an app with Read and write permission, then generate the access token. The free plan allows a small number of posts per month.' ),
			'tumblr'    => array( 'Tumblr', '#36465d', 4000, array( 'ck' => array( 'Consumer key', 0 ), 'cs' => array( 'Consumer secret', 1 ), 'at' => array( 'Token', 0 ), 'ts' => array( 'Token secret', 1 ), 'blog' => array( 'Blog name (name.tumblr.com)', 0 ) ), 'tumblr.com/oauth/apps: register an app, then use its API console to get the token. Free.' ),
			'threads'   => array( 'Threads', '#111827', 480, array( 'uid' => array( 'Threads user ID', 0 ), 'token' => array( 'Access token', 1 ) ), 'Create a Threads app at developers.facebook.com and give it the threads_content_publish permission.' ),
			'linkedin'  => array( 'LinkedIn', '#0a66c2', 2900, array( 'author' => array( 'Author ID (urn:li:person:... or urn:li:organization:...)', 0 ), 'token' => array( 'Access token', 1 ) ), 'developer.linkedin.com: create an app with Share on LinkedIn (w_member_social). Tokens expire, so reconnect now and then.' ),
			'pinterest' => array( 'Pinterest', '#e60023', 480, array( 'board' => array( 'Board ID', 0 ), 'token' => array( 'Access token', 1 ) ), 'developers.pinterest.com: create an app and request access. Needs a picture.' ),
			'reddit'    => array( 'Reddit', '#ff4500', 290, array( 'id' => array( 'App ID', 0 ), 'secret' => array( 'App secret', 1 ), 'user' => array( 'Reddit username', 0 ), 'pass' => array( 'Reddit password', 1 ), 'sub' => array( 'Subreddit (yours, without r/)', 0 ) ), 'reddit.com/prefs/apps > script app. Post only in a community you run: other communities treat repeated ads as spam and may ban you.' ),
			'webhook'   => array( 'Zapier / Make / IFTTT', '#f59e0b', 3000, array( 'url' => array( 'Webhook address', 1 ) ), 'Sends the ad as JSON (text, link, image, ad). Connect it in Zapier, Make or IFTTT to reach WhatsApp, YouTube, Google Business, Buffer and more.' ),
		);
	}

	private static function cfg() {
		return (array) get_option( self::OPT, array() );
	}

	public static function init() {
		add_action( 'admin_post_mrsh_ads_more_save', array( __CLASS__, 'save' ) );
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'mrsh_ads_more_save' ) ) {
			wp_die( 'Not allowed.' );
		}
		$old = self::cfg();
		$new = array();
		foreach ( self::channels() as $k => $c ) {
			$new[ $k ] = array( 'on' => empty( $_POST[ 'on_' . $k ] ) ? 0 : 1 ); // phpcs:ignore
			foreach ( $c[3] as $f => $m ) {
				$v = isset( $_POST[ $k . '_' . $f ] ) ? trim( sanitize_text_field( wp_unslash( $_POST[ $k . '_' . $f ] ) ) ) : ''; // phpcs:ignore
				if ( 'url' === $f && '' !== $v ) { // webhook addresses must be secure web addresses
					$v = esc_url_raw( $v );
					if ( 0 !== strpos( $v, 'https://' ) ) {
						$v = '';
					}
				}
				$new[ $k ][ $f ] = ( '' === $v && $m[1] ) ? ( $old[ $k ][ $f ] ?? '' ) : $v;
			}
		}
		update_option( self::OPT, $new, false );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-autoads&ok=1' ) );
		exit;
	}

	private static function ready( $k ) {
		$c = self::cfg();
		if ( empty( $c[ $k ]['on'] ) ) {
			return false;
		}
		foreach ( self::channels()[ $k ][3] as $f => $m ) {
			if ( '' === (string) ( $c[ $k ][ $f ] ?? '' ) ) {
				return false;
			}
		}
		return true;
	}

	/** Cut the text to a limit but keep the link at the end. */
	private static function short( $text, $max ) {
		$text = trim( $text );
		if ( mb_strlen( $text ) <= $max ) {
			return $text;
		}
		$link = preg_match( '#https?://\S+$#', $text, $m ) ? $m[0] : '';
		$body = trim( str_replace( $link, '', $text ) );
		$room = max( 40, $max - mb_strlen( $link ) - 4 );
		return rtrim( mb_substr( $body, 0, $room ) ) . "…\n" . $link;
	}

	private static function link_of( $t ) {
		return preg_match( '#https?://\S+$#', $t, $m ) ? $m[0] : home_url( '/' );
	}

	private static function post_json( $url, $body, $headers = array() ) {
		return wp_remote_post( $url, array( 'timeout' => 20, 'headers' => array_merge( array( 'Content-Type' => 'application/json' ), $headers ), 'body' => wp_json_encode( $body ) ) );
	}

	private static function oauth1( $method, $url, $params, $ck, $cs, $at, $ts ) {
		$o = array( 'oauth_consumer_key' => $ck, 'oauth_nonce' => wp_generate_password( 20, false ), 'oauth_signature_method' => 'HMAC-SHA1', 'oauth_timestamp' => (string) time(), 'oauth_token' => $at, 'oauth_version' => '1.0' );
		$all = array_merge( $o, $params );
		ksort( $all );
		$pairs = array();
		foreach ( $all as $k => $v ) {
			$pairs[] = rawurlencode( $k ) . '=' . rawurlencode( $v );
		}
		$base = strtoupper( $method ) . '&' . rawurlencode( $url ) . '&' . rawurlencode( implode( '&', $pairs ) );
		$o['oauth_signature'] = base64_encode( hash_hmac( 'sha1', $base, rawurlencode( $cs ) . '&' . rawurlencode( $ts ), true ) );
		$h = array();
		foreach ( $o as $k => $v ) {
			$h[] = rawurlencode( $k ) . '="' . rawurlencode( $v ) . '"';
		}
		return 'OAuth ' . implode( ', ', $h );
	}

	/** Sends the ad to every ready channel. Returns label => result. */
	public static function send_all( $slug, $img ) {
		$out = array();
		$cf  = self::cfg();
		foreach ( self::channels() as $k => $ch ) {
			if ( ! self::ready( $k ) ) {
				continue;
			}
			$c    = $cf[ $k ];
			$full = MRSH_AutoAds::text( $slug, $k );
			$txt  = self::short( $full, $ch[2] );
			$link = self::link_of( $full );
			$r    = null;
			switch ( $k ) {
				case 'discord':
					$r = self::post_json( $c['url'], array( 'content' => $txt ) );
					break;
				case 'webhook':
					$r = self::post_json( $c['url'], array( 'text' => $txt, 'link' => $link, 'image' => $img, 'ad' => $slug ) );
					break;
				case 'mastodon':
					$r = wp_remote_post( 'https://' . preg_replace( '#^https?://|/.*$#', '', $c['host'] ) . '/api/v1/statuses', array( 'timeout' => 20, 'headers' => array( 'Authorization' => 'Bearer ' . $c['token'] ), 'body' => array( 'status' => $txt, 'visibility' => 'public' ) ) );
					break;
				case 'bluesky':
					$s = wp_remote_post( 'https://bsky.social/xrpc/com.atproto.server.createSession', array( 'timeout' => 20, 'headers' => array( 'Content-Type' => 'application/json' ), 'body' => wp_json_encode( array( 'identifier' => $c['handle'], 'password' => $c['pass'] ) ) ) );
					$d = is_wp_error( $s ) ? array() : (array) json_decode( wp_remote_retrieve_body( $s ), true );
					if ( empty( $d['accessJwt'] ) ) {
						$out[ $ch[0] ] = 'Login failed. Check the handle and app password.';
						continue 2;
					}
					$rec  = array( 'text' => $txt, 'createdAt' => gmdate( 'c' ), '$type' => 'app.bsky.feed.post' );
					$pos  = strpos( $txt, $link );
					if ( false !== $pos ) {
						$rec['facets'] = array( array( 'index' => array( 'byteStart' => $pos, 'byteEnd' => $pos + strlen( $link ) ), 'features' => array( array( '$type' => 'app.bsky.richtext.facet#link', 'uri' => $link ) ) ) );
					}
					$r = self::post_json( 'https://bsky.social/xrpc/com.atproto.repo.createRecord', array( 'repo' => $d['did'], 'collection' => 'app.bsky.feed.post', 'record' => $rec ), array( 'Authorization' => 'Bearer ' . $d['accessJwt'] ) );
					break;
				case 'x':
					$u = 'https://api.twitter.com/2/tweets';
					$r = self::post_json( $u, array( 'text' => $txt ), array( 'Authorization' => self::oauth1( 'POST', $u, array(), $c['ck'], $c['cs'], $c['at'], $c['ts'] ) ) );
					break;
				case 'tumblr':
					$u = 'https://api.tumblr.com/v2/blog/' . rawurlencode( preg_replace( '#^https?://|/.*$#', '', $c['blog'] ) ) . '/post';
					$p = array( 'type' => 'text', 'body' => nl2br( esc_html( preg_replace( '#\s*https?://\S+$#', '', $txt ) ) ) . '<br><a href="' . esc_url( $link ) . '">' . esc_html( $link ) . '</a>' );
					$r = wp_remote_post( $u, array( 'timeout' => 20, 'headers' => array( 'Authorization' => self::oauth1( 'POST', $u, $p, $c['ck'], $c['cs'], $c['at'], $c['ts'] ) ), 'body' => $p ) );
					break;
				case 'threads':
					$a = wp_remote_post( 'https://graph.threads.net/v1.0/' . rawurlencode( $c['uid'] ) . '/threads', array( 'timeout' => 20, 'body' => array( 'media_type' => 'TEXT', 'text' => $txt, 'access_token' => $c['token'] ) ) );
					$d = is_wp_error( $a ) ? array() : (array) json_decode( wp_remote_retrieve_body( $a ), true );
					$r = ! empty( $d['id'] ) ? wp_remote_post( 'https://graph.threads.net/v1.0/' . rawurlencode( $c['uid'] ) . '/threads_publish', array( 'timeout' => 20, 'body' => array( 'creation_id' => $d['id'], 'access_token' => $c['token'] ) ) ) : $a;
					break;
				case 'linkedin':
					$r = self::post_json( 'https://api.linkedin.com/v2/ugcPosts', array( 'author' => $c['author'], 'lifecycleState' => 'PUBLISHED', 'specificContent' => array( 'com.linkedin.ugc.ShareContent' => array( 'shareCommentary' => array( 'text' => $txt ), 'shareMediaCategory' => 'NONE' ) ), 'visibility' => array( 'com.linkedin.ugc.MemberNetworkVisibility' => 'PUBLIC' ) ), array( 'Authorization' => 'Bearer ' . $c['token'], 'X-Restli-Protocol-Version' => '2.0.0' ) );
					break;
				case 'pinterest':
					if ( ! $img ) {
						$out[ $ch[0] ] = 'Needs a picture.';
						continue 2;
					}
					$r = self::post_json( 'https://api.pinterest.com/v5/pins', array( 'board_id' => $c['board'], 'link' => $link, 'title' => mb_substr( strtok( $txt, "\n" ), 0, 95 ), 'description' => $txt, 'media_source' => array( 'source_type' => 'image_url', 'url' => $img ) ), array( 'Authorization' => 'Bearer ' . $c['token'] ) );
					break;
				case 'reddit':
					$t = wp_remote_post( 'https://www.reddit.com/api/v1/access_token', array( 'timeout' => 20, 'headers' => array( 'Authorization' => 'Basic ' . base64_encode( $c['id'] . ':' . $c['secret'] ), 'User-Agent' => 'myrishta-autoads/1.0' ), 'body' => array( 'grant_type' => 'password', 'username' => $c['user'], 'password' => $c['pass'] ) ) );
					$d = is_wp_error( $t ) ? array() : (array) json_decode( wp_remote_retrieve_body( $t ), true );
					if ( empty( $d['access_token'] ) ) {
						$out[ $ch[0] ] = 'Login failed. Check the app and account details.';
						continue 2;
					}
					$r = wp_remote_post( 'https://oauth.reddit.com/api/submit', array( 'timeout' => 20, 'headers' => array( 'Authorization' => 'Bearer ' . $d['access_token'], 'User-Agent' => 'myrishta-autoads/1.0' ), 'body' => array( 'sr' => $c['sub'], 'kind' => 'link', 'title' => mb_substr( strtok( $txt, "\n" ), 0, 290 ), 'url' => $link, 'api_type' => 'json' ) ) );
					break;
			}
			$out[ $ch[0] ] = $r ? MRSH_AutoAds::result( $r ) : 'Skipped';
		}
		return $out;
	}

	/* ---------- admin ---------- */

	public static function panel() {
		$cf = self::cfg();
		if ( class_exists( 'MRSH_Connect' ) ) {
			MRSH_Connect::card();
		}
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">+</span><h2>More channels</h2></div><p class="mx-sub">Switch on any channel you have signed up for and paste its keys. Keys you saved are never shown again; leave a box empty to keep it. Every switched-on channel gets each ad.</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_ads_more_save">';
		wp_nonce_field( 'mrsh_ads_more_save' );
		foreach ( self::channels() as $k => $ch ) {
			$ok = self::ready( $k );
			echo '<details class="mx-ch" style="--d:' . esc_attr( $ch[1] ) . '"' . ( ! empty( $cf[ $k ]['on'] ) ? ' open' : '' ) . '><summary><span class="dot"></span><b>' . esc_html( $ch[0] ) . '</b><span class="mx-pill ' . ( $ok ? 'ok' : ( ! empty( $cf[ $k ]['on'] ) ? 'warn' : '' ) ) . '">' . ( $ok ? 'ready' : ( ! empty( $cf[ $k ]['on'] ) ? 'keys missing' : 'off' ) ) . '</span></summary><div class="in">';
			echo '<label class="mx-sw"><input type="checkbox" name="on_' . esc_attr( $k ) . '" value="1"' . checked( ! empty( $cf[ $k ]['on'] ), true, false ) . '><span class="tr"></span><span class="lb">Post to ' . esc_html( $ch[0] ) . '</span></label><div class="mx-grid" style="margin-top:14px">';
			foreach ( $ch[3] as $f => $m ) {
				$have = ! empty( $cf[ $k ][ $f ] );
				echo '<div class="mx-f"><label class="t" for="' . esc_attr( $k . $f ) . '">' . esc_html( $m[0] ) . '</label><input type="' . ( $m[1] ? 'password' : 'text' ) . '" id="' . esc_attr( $k . $f ) . '" name="' . esc_attr( $k . '_' . $f ) . '" autocomplete="off" value="' . ( $m[1] ? '' : esc_attr( $cf[ $k ][ $f ] ?? '' ) ) . '" placeholder="' . ( $m[1] && $have ? 'Saved. Leave empty to keep.' : '' ) . '"></div>';
			}
			echo '</div><p class="mx-note">' . esc_html( $ch[4] ) . '</p></div></details>';
		}
		echo '<p style="margin:16px 0 0"><button class="mx-btn p">Save channels</button></p></form></div>';

		// hand-share buttons
		$ads = MRSH_AutoAds::templates();
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">+</span><h2>Share by hand</h2></div><p class="mx-sub">For sites that have no posting service (WhatsApp Channel, TikTok, Snapchat, YouTube community, Google Business). Copy the ad text, or open a ready share window. Links are tracked like the automatic ones.</p>';
		echo '<div class="mx-f" style="max-width:420px"><label class="t" for="mxsh">Ad</label><select id="mxsh">';
		foreach ( $ads as $s => $t ) {
			if ( 'count' !== $s ) {
				echo '<option value="' . esc_attr( $s ) . '">' . esc_html( $t[0] ) . '</option>';
			}
		}
		echo '</select></div>';
		$data = array();
		foreach ( $ads as $s => $t ) {
			if ( 'count' === $s ) {
				continue;
			}
			$row = array();
			foreach ( array( 'whatsapp', 'telegram', 'facebook', 'x', 'linkedin', 'reddit', 'pinterest', 'tumblr', 'tiktok', 'snapchat', 'youtube', 'email', 'messenger', 'sms', 'threads', 'bluesky', 'vk', 'instagram', 'fbgroup', 'imo', 'gbp' ) as $n ) {
				$tx = MRSH_AutoAds::text( $s, $n );
				$row[ $n ] = array( $tx, self::link_of( $tx ), trim( preg_replace( '#\s*https?://\S+$#', '', $tx ) ) );
			}
			$data[ $s ] = $row;
		}
		$btn = array( 'whatsapp' => 'WhatsApp', 'telegram' => 'Telegram', 'facebook' => 'Facebook', 'x' => 'X', 'linkedin' => 'LinkedIn', 'reddit' => 'Reddit', 'pinterest' => 'Pinterest', 'tumblr' => 'Tumblr', 'messenger' => 'Messenger (phone)', 'sms' => 'SMS (phone)', 'threads' => 'Threads', 'bluesky' => 'Bluesky', 'vk' => 'VK' );
		echo '<div class="mx-acts" style="margin-top:14px" id="mxsh-open">';
		foreach ( $btn as $n => $l ) {
			echo '<button type="button" class="mx-btn s" data-n="' . esc_attr( $n ) . '">' . esc_html( $l ) . '</button>';
		}
		echo '</div><div class="mx-acts" style="margin-top:10px" id="mxsh-copy">';
		foreach ( array( 'tiktok' => 'TikTok', 'snapchat' => 'Snapchat', 'youtube' => 'YouTube', 'whatsapp' => 'WhatsApp Channel or group', 'instagram' => 'Instagram', 'fbgroup' => 'Facebook group', 'imo' => 'imo, Likee or Kwai', 'gbp' => 'Google Business Profile', 'email' => 'Any other site' ) as $n => $l ) {
			echo '<button type="button" class="mx-btn s" data-n="' . esc_attr( $n ) . '">Copy for ' . esc_html( $l ) . '</button>';
		}
		echo '</div><span class="mx-msg" id="mxsh-msg"></span>';
		echo '<script>(function(){var D=' . wp_json_encode( $data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) . ',sel=document.getElementById("mxsh"),msg=document.getElementById("mxsh-msg");'
			. 'function e(s){return encodeURIComponent(s)}'
			. 'var U={whatsapp:function(a){return"https://wa.me/?text="+e(a[0])},telegram:function(a){return"https://t.me/share/url?url="+e(a[1])+"&text="+e(a[2])},facebook:function(a){return"https://www.facebook.com/sharer/sharer.php?u="+e(a[1])},x:function(a){return"https://twitter.com/intent/tweet?text="+e(a[2].slice(0,230))+"&url="+e(a[1])},linkedin:function(a){return"https://www.linkedin.com/sharing/share-offsite/?url="+e(a[1])},reddit:function(a){return"https://www.reddit.com/submit?url="+e(a[1])+"&title="+e(a[2].slice(0,290))},pinterest:function(a){return"https://www.pinterest.com/pin/create/button/?url="+e(a[1])+"&description="+e(a[2])},tumblr:function(a){return"https://www.tumblr.com/widgets/share/tool?canonicalUrl="+e(a[1])+"&caption="+e(a[2])},messenger:function(a){return"fb-messenger://share/?link="+e(a[1])},sms:function(a){return"sms:?&body="+e(a[0])},threads:function(a){return"https://www.threads.net/intent/post?text="+e(a[0])},bluesky:function(a){return"https://bsky.app/intent/compose?text="+e(a[0].slice(0,290))},vk:function(a){return"https://vk.com/share.php?url="+e(a[1])}};'
			. 'document.getElementById("mxsh-open").addEventListener("click",function(x){var b=x.target.closest("button");if(!b)return;var n=b.dataset.n,a=D[sel.value][n];window.open(U[n](a),"_blank","noopener")});'
			. 'document.getElementById("mxsh-copy").addEventListener("click",function(x){var b=x.target.closest("button");if(!b)return;var t=D[sel.value][b.dataset.n][0];function ok(){msg.textContent="Copied. Paste it into the app."}function fb(){var z=document.createElement("textarea");z.value=t;document.body.appendChild(z);z.select();try{document.execCommand("copy");ok()}catch(_){msg.textContent="Could not copy."}z.remove()}if(navigator.clipboard){navigator.clipboard.writeText(t).then(ok,fb)}else fb()});'
			. '})();</script>'; // phpcs:ignore
		echo '<style>.mx .mx-ch{border:1px solid #eceef6;border-radius:16px;margin:0 0 10px;background:#fff}.mx .mx-ch summary{list-style:none;display:flex;align-items:center;gap:12px;padding:14px 16px;cursor:pointer}.mx .mx-ch summary::-webkit-details-marker{display:none}.mx .mx-ch .dot{width:12px;height:12px;border-radius:50%;background:var(--d)}.mx .mx-ch summary b{flex:1;font-size:15px;color:#111827}.mx .mx-ch .in{padding:2px 16px 16px;border-top:1px solid #eef0f6;padding-top:16px}</style></div>';
	}
}
MRSH_AutoAds_More::init();
