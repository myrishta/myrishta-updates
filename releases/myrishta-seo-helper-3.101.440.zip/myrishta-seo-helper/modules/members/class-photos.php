<?php
/**
 * Photos tool: a copy of the site (for example a test site) often has the photo records but not the picture files.
 * This page downloads the missing files from the live site into this site's uploads folder, a few at a time.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Mem_Photos {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 21 );
		add_action( 'wp_ajax_mrsh_photos_batch', array( __CLASS__, 'batch' ) );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Photos', 'Photos', 'manage_options', 'mrsh-photos', array( __CLASS__, 'page' ) );
	}

	/** Live site to copy from: the "photo host" setting, else this address without test/staging/dev. */
	public static function host() {
		$set = function_exists( 'mrt_site' ) ? trim( (string) mrt_site( 'photo_host', '' ) ) : '';
		$set = preg_replace( '#^https?://#', '', rtrim( $set, '/' ) );
		$cur = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		if ( '' === $set || 'off' === strtolower( $set ) ) {
			$set = preg_replace( '/^(test|staging|stage|dev|new)\./i', '', $cur );
		}
		$set = strtolower( preg_replace( '#[^a-z0-9.\-]#i', '', $set ) );
		return ( $set && 0 !== strcasecmp( $set, $cur ) ) ? $set : '';
	}

	private static function missing_count() {
		global $wpdb;
		$ids = $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE post_type='attachment' AND post_mime_type LIKE 'image/%' ORDER BY ID DESC LIMIT 3000" ); // phpcs:ignore WordPress.DB
		$miss = 0;
		foreach ( $ids as $id ) {
			$f = get_attached_file( (int) $id );
			if ( $f && ! file_exists( $f ) ) {
				$miss++;
			}
		}
		return array( count( $ids ), $miss );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$host = self::host();
		list( $total, $miss ) = self::missing_count();
		echo '<div class="wrap"><h1>Photos</h1>';
		echo '<p>Pictures in the media library: <b>' . (int) $total . '</b>. Picture files missing on this site: <b>' . (int) $miss . '</b>.</p>';
		if ( ! $host ) {
			echo '<div class="notice notice-warning"><p>This looks like your live site, or no live address is set. To copy pictures from another site, enter its address under Site settings > Look and content > Photo host (for example myrishta.pk).</p></div></div>';
			return;
		}
		echo '<p>Copy from: <b>' . esc_html( $host ) . '</b>. Files that already exist here are never replaced. If a size is missing on the live site, the full picture is used instead.</p>';
		echo '<p><button class="button button-primary" id="mrsh-ph-go">Fetch missing photos from ' . esc_html( $host ) . '</button> <button class="button" id="mrsh-ph-stop" hidden>Stop</button></p>';
		echo '<div id="mrsh-ph-bar" style="max-width:520px;height:14px;background:#e5e7eb;border-radius:99px;overflow:hidden" hidden><div id="mrsh-ph-fill" style="height:100%;width:0;background:linear-gradient(90deg,#e11d74,#7c3aed);transition:width .3s"></div></div><p id="mrsh-ph-msg"></p></div>';
		$n = wp_create_nonce( 'mrsh_photos' );
		?>
<script>
(function(){
var go=document.getElementById('mrsh-ph-go'),st=document.getElementById('mrsh-ph-stop'),bar=document.getElementById('mrsh-ph-bar'),fill=document.getElementById('mrsh-ph-fill'),msg=document.getElementById('mrsh-ph-msg');
var stop=false,after=0,got=0,miss=0,fail=0,maxid=0,errs=0;
function run(){
 if(stop){msg.textContent='Stopped. Copied '+got+' files so far.';go.disabled=false;st.hidden=true;return}
 var f=new FormData();f.append('action','mrsh_photos_batch');f.append('n','<?php echo esc_js( $n ); ?>');f.append('after',after);
 fetch(ajaxurl,{method:'POST',body:f,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(r){
  if(!r||!r.success){errs++;if(errs>3){msg.textContent='Stopped: '+((r&&r.data)||'server problem')+'.';go.disabled=false;st.hidden=true;return}return setTimeout(run,1500)}
  var d=r.data;got+=d.got;fail+=d.fail;maxid=Math.max(maxid,d.next||0);
  if(d.max){fill.style.width=Math.min(100,Math.round(d.next/d.max*100))+'%'}
  msg.textContent='Copied '+got+' files'+(fail?', '+fail+' not found on the live site':'')+'...';
  if(d.done){fill.style.width='100%';msg.textContent='Done. Copied '+got+' files'+(fail?'; '+fail+' could not be found on the live site':'')+'. Reload this page to see the new count.';go.disabled=false;st.hidden=true;return}
  after=d.next;setTimeout(run,150)
 }).catch(function(){errs++;if(errs>3){msg.textContent='Network problem. Press the button again to continue.';go.disabled=false;st.hidden=true}else setTimeout(run,1500)})
}
go.onclick=function(){stop=false;after=0;got=0;fail=0;errs=0;go.disabled=true;st.hidden=false;bar.hidden=false;fill.style.width='0';msg.textContent='Starting...';run()};
st.onclick=function(){stop=true};
})();
</script>
		<?php
	}

	public static function batch() {
		if ( ! current_user_can( 'manage_options' ) || ! check_ajax_referer( 'mrsh_photos', 'n', false ) ) {
			wp_send_json_error( 'Not allowed.' );
		}
		global $wpdb;
		$host = self::host();
		if ( ! $host ) {
			wp_send_json_error( 'No live site address.' );
		}
		@set_time_limit( 60 ); // phpcs:ignore
		$after = isset( $_POST['after'] ) ? absint( $_POST['after'] ) : 0;
		$ids   = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type='attachment' AND post_mime_type LIKE %s AND ID > %d ORDER BY ID ASC LIMIT 3", 'image/%', $after ) ); // phpcs:ignore WordPress.DB
		$max   = (int) $wpdb->get_var( "SELECT MAX(ID) FROM {$wpdb->posts} WHERE post_type='attachment'" ); // phpcs:ignore WordPress.DB
		$got   = 0;
		$fail  = 0;
		foreach ( $ids as $id ) {
			list( $g, $f ) = self::fix( (int) $id, $host );
			$got  += $g;
			$fail += $f;
		}
		wp_send_json_success( array( 'got' => $got, 'fail' => $fail, 'done' => empty( $ids ), 'next' => $ids ? (int) end( $ids ) : $after, 'max' => $max ) );
	}

	/** Copies the missing files of one picture. Returns array( copied, not found ). */
	private static function fix( $id, $host ) {
		$rel = (string) get_post_meta( $id, '_wp_attached_file', true );
		if ( '' === $rel || false !== strpos( $rel, '..' ) || 0 === strpos( $rel, '/' ) || preg_match( '#^[a-z]+:#i', $rel ) ) {
			return array( 0, 0 );
		}
		$up    = wp_get_upload_dir();
		$base  = untrailingslashit( $up['basedir'] );
		$path  = (string) wp_parse_url( $up['baseurl'], PHP_URL_PATH );
		$dir   = dirname( $rel );
		$files = array( $rel );
		$meta  = wp_get_attachment_metadata( $id );
		if ( is_array( $meta ) && ! empty( $meta['sizes'] ) ) {
			foreach ( $meta['sizes'] as $s ) {
				if ( ! empty( $s['file'] ) && false === strpos( $s['file'], '/' ) && false === strpos( $s['file'], '..' ) ) {
					$files[] = ( '.' === $dir ? '' : $dir . '/' ) . $s['file'];
				}
			}
		}
		$got  = 0;
		$fail = 0;
		foreach ( array_unique( $files ) as $i => $r ) {
			$dest = $base . '/' . $r;
			if ( file_exists( $dest ) ) {
				continue;
			}
			$data = self::fetch( 'https://' . $host . $path . '/' . $r );
			if ( ! $data && 0 === $i ) {
				// The live site may have renamed the file; ask its media record for the real address.
				$j = wp_remote_get( 'https://' . $host . '/wp-json/wp/v2/media/' . $id . '?_fields=source_url', array( 'timeout' => 15 ) );
				if ( ! is_wp_error( $j ) && 200 === (int) wp_remote_retrieve_response_code( $j ) ) {
					$o = json_decode( wp_remote_retrieve_body( $j ), true );
					if ( ! empty( $o['source_url'] ) && 0 === strpos( $o['source_url'], 'https://' . $host . '/' ) ) {
						$data = self::fetch( $o['source_url'] );
					}
				}
			}
			if ( ! $data && $i > 0 && file_exists( $base . '/' . $rel ) ) {
				$data = (string) file_get_contents( $base . '/' . $rel ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			}
			if ( $data ) {
				wp_mkdir_p( dirname( $dest ) );
				if ( false !== file_put_contents( $dest, $data ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions
					$got++;
					continue;
				}
			}
			$fail++;
		}
		return array( $got, $fail );
	}

	/** One picture from the live site, or '' (only real images are accepted, up to 12 MB). */
	private static function fetch( $url ) {
		$r = wp_remote_get( $url, array( 'timeout' => 20, 'redirection' => 3, 'limit_response_size' => 12 * MB_IN_BYTES ) );
		if ( is_wp_error( $r ) || 200 !== (int) wp_remote_retrieve_response_code( $r ) ) {
			return '';
		}
		$b = (string) wp_remote_retrieve_body( $r );
		return ( strlen( $b ) > 200 && false !== @getimagesizefromstring( $b ) ) ? $b : ''; // phpcs:ignore WordPress.PHP.NoSilencedErrors
	}
}
MRSH_Mem_Photos::init();
