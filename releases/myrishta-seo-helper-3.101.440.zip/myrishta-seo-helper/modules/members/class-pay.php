<?php
/**
 * Online payment buttons: paste the payment links from Easypaisa, JazzCash, Google Pay or any card gateway and the
 * paid plans on the Membership page show "Pay with ..." buttons. Money goes straight to your own account at the gateway.
 * The member then sends the payment screenshot (Payment proofs) and you set the plan. Option: mrsh_pay.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Pay {

	const METHODS = array(
		'ep' => array( 'Easypaisa', '#17b26a' ),
		'jc' => array( 'JazzCash', '#e11d2f' ),
		'gp' => array( 'Google Pay', '#4285f4' ),
		'cd' => array( 'Card / other', '#334155' ),
	);

	public static function get() {
		$o = (array) get_option( 'mrsh_pay', array() );
		return array_merge( array( 'on' => 0, 'links' => array(), 'plan' => array(), 'note' => '', 'acct' => '' ), $o );
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 29 );
		add_action( 'admin_post_mrsh_pay_save', array( __CLASS__, 'save' ) );
		add_action( 'mrt_plan_pay', array( __CLASS__, 'buttons' ), 10, 2 );
		add_action( 'wp_head', array( __CLASS__, 'css' ), 100 );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Online payment', 'Online payment', 'manage_options', 'mrsh-pay', array( __CLASS__, 'page' ) );
	}

	private static function link_for( $method, $plan_name ) {
		$o = self::get();
		$u = $o['plan'][ strtolower( $plan_name ) ][ $method ] ?? '';
		if ( '' === $u ) {
			$u = $o['links'][ $method ] ?? '';
		}
		return (string) $u;
	}

	public static function css() {
		if ( ! self::get()['on'] ) {
			return;
		}
		echo '<style>.paybox{display:grid;gap:8px;margin-top:10px}.paybtn{display:flex;align-items:center;justify-content:center;gap:8px;padding:11px 14px;border-radius:12px;color:#fff!important;font-weight:700;text-decoration:none!important;background:var(--b,#334155);box-shadow:0 4px 12px rgba(0,0,0,.14);transition:transform .15s}.paybtn:hover{transform:translateY(-2px)}.paynote{font-size:.8rem;color:var(--mut,#64748b);text-align:center;margin:6px 0 0}</style>';
	}

	/** Called from the Membership page for every plan. */
	public static function buttons( $p, $i ) {
		$o = self::get();
		if ( empty( $o['on'] ) || 0 === (int) $i || get_option( 'mrsh_plans_free', 0 ) || ! is_array( $p ) ) {
			return;
		}
		$h = '';
		foreach ( self::METHODS as $k => $m ) {
			$u = self::link_for( $k, $p[0] );
			if ( '' !== $u && 0 === strpos( $u, 'https://' ) ) {
				$h .= '<a class="paybtn" style="--b:' . esc_attr( $m[1] ) . '" href="' . esc_url( $u ) . '" target="_blank" rel="noopener nofollow">Pay with ' . esc_html( $m[0] ) . '</a>';
			}
		}
		if ( '' === $h ) {
			return;
		}
		echo '<div class="paybox">' . $h . '</div>'; // phpcs:ignore
		echo '<p class="paynote">After paying, send the screenshot from <a href="' . esc_url( home_url( '/my-account/' ) ) . '">My account</a>. We set your ' . esc_html( $p[0] ) . ' plan after we receive it.' . ( '' !== trim( (string) $o['note'] ) ? ' ' . esc_html( $o['note'] ) : '' ) . '</p>';
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$o     = self::get();
		$plans = function_exists( 'mrt_plans' ) ? mrt_plans() : array();
		echo '<div class="wrap"><h1>Online payment</h1>';
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success is-dismissible"><p>Saved.</p></div>';
		}
		echo '<p>Create a payment link in your Easypaisa, JazzCash or Google Pay / card gateway business account, then paste it here. The member pays on the gateway page and the money goes to your own account. Links must start with https://. Paid plans only; nothing shows while "Make everything free" is on.</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_pay_save">';
		wp_nonce_field( 'mrsh_pay_save' );
		echo '<p><label style="font-size:15px"><input type="checkbox" name="on" value="1"' . checked( ! empty( $o['on'] ), true, false ) . '> <b>Show "Pay with" buttons on the Membership page</b></label></p>';
		echo '<h2>Links for all paid plans</h2><table class="form-table"><tbody>';
		foreach ( self::METHODS as $k => $m ) {
			echo '<tr><th>' . esc_html( $m[0] ) . '</th><td><input type="url" class="large-text" name="links[' . esc_attr( $k ) . ']" value="' . esc_attr( (string) ( $o['links'][ $k ] ?? '' ) ) . '" placeholder="https://"></td></tr>';
		}
		echo '</tbody></table>';
		if ( count( $plans ) > 1 ) {
			echo '<h2>Own link for one plan (optional)</h2><p class="description">Use this when each plan has its own amount. Leave empty to use the link above.</p>';
			foreach ( array_slice( $plans, 1 ) as $p ) {
				echo '<h3>' . esc_html( $p[0] ) . ' &middot; ' . esc_html( $p[1] ) . '</h3><table class="form-table"><tbody>';
				foreach ( self::METHODS as $k => $m ) {
					echo '<tr><th>' . esc_html( $m[0] ) . '</th><td><input type="url" class="large-text" name="plan[' . esc_attr( strtolower( $p[0] ) ) . '][' . esc_attr( $k ) . ']" value="' . esc_attr( (string) ( $o['plan'][ strtolower( $p[0] ) ][ $k ] ?? '' ) ) . '" placeholder="https://"></td></tr>';
				}
				echo '</tbody></table>';
			}
		}
		echo '<h2>Message under the buttons (optional)</h2><p><input type="text" class="large-text" name="note" value="' . esc_attr( (string) $o['note'] ) . '" placeholder="Example: Write your profile number in the payment note."></p>';
		echo '<p><button class="button button-primary button-large">Save</button></p></form>';
		echo '<p class="description">Where you see payments: your gateway account. Where members send their screenshot: Payment proofs. Set the plan on Members.</p></div>';
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_pay_save' );
		$u  = function ( $v ) {
			$v = esc_url_raw( trim( (string) $v ), array( 'https' ) );
			return $v;
		};
		$o  = array( 'on' => empty( $_POST['on'] ) ? 0 : 1, 'links' => array(), 'plan' => array(), 'note' => '' );
		$ln = isset( $_POST['links'] ) ? (array) wp_unslash( $_POST['links'] ) : array(); // phpcs:ignore
		foreach ( array_keys( self::METHODS ) as $k ) {
			$o['links'][ $k ] = $u( $ln[ $k ] ?? '' );
		}
		$pl = isset( $_POST['plan'] ) ? (array) wp_unslash( $_POST['plan'] ) : array(); // phpcs:ignore
		foreach ( $pl as $name => $arr ) {
			foreach ( array_keys( self::METHODS ) as $k ) {
				$v = $u( ( (array) $arr )[ $k ] ?? '' );
				if ( '' !== $v ) {
					$o['plan'][ sanitize_text_field( strtolower( $name ) ) ][ $k ] = $v;
				}
			}
		}
		$o['note'] = sanitize_text_field( wp_unslash( $_POST['note'] ?? '' ) ); // phpcs:ignore
		update_option( 'mrsh_pay', $o, false );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-pay&ok=1' ) );
		exit;
	}
}
MRSH_Pay::init();
