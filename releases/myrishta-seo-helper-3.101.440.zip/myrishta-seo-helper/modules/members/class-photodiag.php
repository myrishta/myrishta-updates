<?php
/**
 * Photo diagnosis: for every profile it shows which picture the theme would use, whether the file is on this site,
 * the exact address, a live check of that address, and a plain reason when no photo shows.
 * Also a button to forget the remembered photo choice of every profile (they are found again on the next visit).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Mem_PhotoDiag {

	const PER = 30;

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 22 );
		add_action( 'wp_ajax_mrsh_photodiag_check', array( __CLASS__, 'check' ) );
		add_action( 'admin_post_mrsh_photodiag_reset', array( __CLASS__, 'reset' ) );
		add_action( 'wp_ajax_mrsh_photodiag_clear', array( __CLASS__, 'clear' ) );
		add_action( 'admin_post_mrsh_photodiag_rm', array( __CLASS__, 'rm' ) );
	}

	/** A profile whose picture record has no file, no safety copy and no live copy. */
	private static function is_broken( $r ) {
		return ! $r['local'] && ! in_array( $r['source'], array( 'backup', 'live', 'address' ), true ) && '' !== trim( (string) $r['cands'] );
	}

	/** Remove the dead picture records of one profile. The file is already gone, so nothing real is lost. */
	private static function fix_one( $pid, $mail ) {
		$n = 0;
		foreach ( (array) ( function_exists( 'mrt_photo_candidates' ) ? mrt_photo_candidates( $pid ) : array() ) as $c ) {
			$c = (int) $c;
			if ( $c && 'attachment' === get_post_type( $c ) && ! file_exists( (string) get_attached_file( $c ) ) ) {
				wp_delete_attachment( $c, true );
				++$n;
			}
		}
		if ( has_post_thumbnail( $pid ) && ! file_exists( (string) get_attached_file( (int) get_post_thumbnail_id( $pid ) ) ) ) {
			delete_post_thumbnail( $pid );
		}
		delete_post_meta( $pid, '_mrt_ph' );
		$au = (int) get_post_field( 'post_author', $pid );
		if ( $mail && $au && class_exists( 'MRSH_Mailq' ) && ! get_user_meta( $au, 'mrsh_photo_lost_mail', true ) ) {
			$u = get_userdata( $au );
			if ( $u ) {
				update_user_meta( $au, 'mrsh_photo_lost_mail', time() );
				MRSH_Mailq::add( $u->user_email, 'Please add your photo again', "Assalam o Alaikum " . $u->display_name . ",\n\nYour profile photo could not be found on our site, so it is not shown. Please sign in and add your photo again. Profiles with a clear photo get many more replies.\n\n" . home_url( '/add-listing/' ), array( 'kind' => 'photo', 'uid' => $au ) );
			}
		}
		return $n;
	}

	public static function rm() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'mrsh_photodiag_rm' ) ) {
			wp_die( 'Not allowed.' );
		}
		$mail = ! empty( $_POST['mail'] ); // phpcs:ignore
		$one  = isset( $_POST['pid'] ) ? absint( $_POST['pid'] ) : 0; // phpcs:ignore
		$ids  = $one ? array( $one ) : get_posts( array( 'post_type' => 'listing_type', 'post_status' => 'publish', 'numberposts' => 1500, 'fields' => 'ids', 'no_found_rows' => true ) );
		$fixed = 0;
		foreach ( $ids as $pid ) {
			if ( self::is_broken( self::row( (int) $pid ) ) ) {
				self::fix_one( (int) $pid, $mail );
				++$fixed;
			}
		}
		delete_transient( 'mrsh_pd_cnt' );
		delete_transient( 'mrsh_people' );
		do_action( 'litespeed_purge_all' );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-photodiag&rmdone=' . $fixed ) );
		exit;
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Photo diagnosis', 'Photo diagnosis', 'manage_options', 'mrsh-photodiag', array( __CLASS__, 'page' ) );
	}

	/** Profiles whose photo cannot show (cached for 30 minutes). Used for the red number on the tab. */
	public static function problem_count() {
		$c = get_transient( 'mrsh_pd_cnt' );
		if ( false !== $c ) {
			return (int) $c;
		}
		$n   = 0;
		$ids = get_posts( array( 'post_type' => 'listing_type', 'post_status' => 'publish', 'numberposts' => 1500, 'fields' => 'ids', 'no_found_rows' => true ) );
		foreach ( $ids as $pid ) {
			$r = self::row( (int) $pid );
			if ( ! $r['ok'] && $r['cands'] ) { // a picture is linked but cannot show; members with no picture at all are not a fault
				$n++;
			}
		}
		set_transient( 'mrsh_pd_cnt', $n, 30 * MINUTE_IN_SECONDS );
		return $n;
	}

	/** One profile: array( id, title, cands, local, source, url, note, ok ). */
	private static function row( $pid ) {
		$cands  = function_exists( 'mrt_photo_candidates' ) ? mrt_photo_candidates( $pid ) : array();
		$aid    = function_exists( 'mrt_photo_id' ) ? (int) mrt_photo_id( $pid ) : 0;
		$local  = ( $aid && file_exists( (string) get_attached_file( $aid ) ) );
		$src    = function_exists( 'mrt_photo_source' ) ? mrt_photo_source( $pid, 'medium' ) : array( 'none', '' );
		$url    = (string) $src[1];
		$source = (string) $src[0];
		$note   = '';
		$ok     = false;
		$bak    = 0;
		if ( ! $local && class_exists( 'MRSH_PhotoBak' ) ) {
			foreach ( $cands as $c0 ) {
				if ( MRSH_PhotoBak::has( $c0 ) ) {
					$bak = (int) $c0;
					break;
				}
			}
		}
		if ( ! $cands && 'none' === $source ) {
			$note = 'No picture is linked to this profile. The member has not added one.';
		} elseif ( $local ) {
			$note = 'OK. The picture file is on this site.';
			$ok   = true;
		} elseif ( $bak ) {
			$note   = 'The file is not in the uploads folder, so the safety copy saved in the database is shown.';
			$ok     = true;
			$source = 'backup';
			$url    = (string) MRSH_PhotoBak::url( $bak );
		} elseif ( 'live' === $source ) {
			$note = 'The file is not on this site, so the live copy is used. It shows only if the live site lets this site load it (hotlink protection must be off). Run Photos > Fetch to copy the files here.';
			$ok   = true;
		} elseif ( 'address' === $source ) {
			$note = 'No file here. The old address saved on the profile is used.';
			$ok   = true;
		} else {
			$note = 'The picture record exists but its file is missing here, and no live site is set. Use Photos > Fetch missing photos, or set the Photo host in Site Settings.';
		}
		if ( $url && 0 === strpos( $url, 'http://' ) && is_ssl() ) {
			$note .= ' Warning: the address starts with http:// on an https page, browsers may block it.';
			$ok    = false;
		}
		$au   = (int) get_post_field( 'post_author', $pid );
		$priv = $au ? (string) ( get_user_meta( $au, 'mrt_photo_priv', true ) ?: 'all' ) : 'all';
		if ( 'all' !== $priv ) {
			$note .= ' The member hides the photo from others (privacy: ' . $priv . '), so visitors see "Photo is private".';
		}
		return array(
			'id'     => (int) $pid,
			'title'  => get_the_title( $pid ),
			'cands'  => implode( ', ', array_map( 'intval', $cands ) ),
			'local'  => $local,
			'source' => $source,
			'url'    => $url,
			'note'   => trim( $note ),
			'ok'     => $ok,
		);
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$ids = get_posts( array( 'post_type' => 'listing_type', 'post_status' => 'publish', 'numberposts' => 1500, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'DESC', 'no_found_rows' => true ) );
		$all = array();
		$sum = array( 'total' => 0, 'local' => 0, 'bak' => 0, 'live' => 0, 'addr' => 0, 'none' => 0, 'miss' => 0 );
		foreach ( $ids as $pid ) {
			$r     = self::row( (int) $pid );
			$all[] = $r;
			$sum['total']++;
			if ( $r['local'] ) {
				$sum['local']++;
			} elseif ( 'backup' === $r['source'] ) {
				$sum['bak']++;
			} elseif ( 'live' === $r['source'] ) {
				$sum['live']++;
			} elseif ( 'address' === $r['source'] ) {
				$sum['addr']++;
			} elseif ( ! $r['cands'] ) {
				$sum['none']++;
			} else {
				$sum['miss']++;
			}
		}
		$only = ! empty( $_GET['problems'] ); // phpcs:ignore
		$brk  = ! empty( $_GET['broken'] ); // phpcs:ignore
		$list = $brk ? array_values( array_filter( $all, function ( $r ) {
			return ! $r['ok'] && '' !== $r['cands'];
		} ) ) : ( $only ? array_values( array_filter( $all, function ( $r ) {
			return ! $r['ok'];
		} ) ) : $all );
		$pg   = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1; // phpcs:ignore
		$pages = max( 1, (int) ceil( count( $list ) / self::PER ) );
		$pg    = min( $pg, $pages );
		$rows  = array_slice( $list, ( $pg - 1 ) * self::PER, self::PER );
		$base  = admin_url( 'admin.php?page=mrsh-photodiag' );
		$nonce = wp_create_nonce( 'mrsh_photodiag' );

		if ( ! class_exists( 'MRSH_Boost' ) ) {
			echo '<div class="wrap"><h1>Photo diagnosis</h1><p>The page styles are missing. Reinstall the plugin zip.</p></div>';
			return;
		}
		MRSH_Boost::ui_open( 'Photo diagnosis', 'See which picture each profile uses and why a photo may not show. This page changes nothing except the buttons you press.', 'g-blue', 'M9 4 7.2 6H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-3.2L15 4zm3 5a4.5 4.5 0 1 1 0 9 4.5 4.5 0 0 1 0-9z' );
		if ( isset( $_GET['reset'] ) ) { // phpcs:ignore
			MRSH_Boost::ui_ok( 'Saved photo choices were cleared. The theme finds each photo again on the next visit. If you use LiteSpeed Cache, click Purge All.' );
		}
		if ( isset( $_GET['rmdone'] ) ) { // phpcs:ignore
			MRSH_Boost::ui_ok( 'Done. Broken pictures removed from ' . (int) $_GET['rmdone'] . ' profile(s). Those profiles now show no picture, so the member can add a new one.' ); // phpcs:ignore
		}
		echo '<div class="mx-stats">';
		echo MRSH_Boost::ui_stat( $sum['total'], 'Published profiles', '#4a69d6' ); // phpcs:ignore
		echo MRSH_Boost::ui_stat( $sum['local'], 'Picture file is on this site', '#10b981' ); // phpcs:ignore
		echo MRSH_Boost::ui_stat( $sum['bak'], 'File missing here, database safety copy used', '#7c3aed' ); // phpcs:ignore
		echo MRSH_Boost::ui_stat( $sum['live'], 'File missing here, live copy used', '#139a86' ); // phpcs:ignore
		echo MRSH_Boost::ui_stat( $sum['addr'], 'Old address on the profile used', '#f59e0b' ); // phpcs:ignore
		echo MRSH_Boost::ui_stat( $sum['miss'], 'Picture record but no file and no live site', '#e11d48' ); // phpcs:ignore
		echo MRSH_Boost::ui_stat( $sum['none'], 'No picture linked at all', '#6b7280' ); // phpcs:ignore
		echo '</div>';
		if ( class_exists( 'MRSH_PhotoBak' ) ) {
			$bs = MRSH_PhotoBak::stats();
			echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">1</span><h2>Photo safety copy in the database</h2></div><p class="mx-sub">Every profile photo is also saved in the database as a small copy (longest side 800 px). If a picture file ever goes missing, the site shows this copy, so a profile never loses its photo. New uploads are saved automatically. Press the button once to save the photos that were uploaded before.</p>';
			echo '<div class="mx-stats" style="margin-bottom:14px">' . MRSH_Boost::ui_stat( $bs[0], 'Profile photos', '#4a69d6' ) . MRSH_Boost::ui_stat( (int) $bs[1], 'With a safety copy', '#10b981', 'mrsh-pb-have' ) . MRSH_Boost::ui_stat( size_format( $bs[2] ), 'Space used in the database', '#f59e0b' ) . '</div>'; // phpcs:ignore
			echo '<div class="mx-acts"><button type="button" class="mx-btn p" id="mrsh-pb-go">Save safety copies now</button><span id="mrsh-pb-msg" class="mx-msg" style="margin:0"></span></div><div class="mx-prog" id="mrsh-pb-bar" hidden><i id="mrsh-pb-fill"></i></div>';
			echo '<p class="mx-note">Photos whose file is already missing here cannot be copied; copy them from the live site first (Fix all photos), or save the copies on the live site. Keep taking normal backups too: the safety copy is a smaller version, not the original.</p></div>';
		}
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">2</span><h2>Fix all photos</h2></div><p class="mx-sub">Copies the missing picture files from the live site (only on a test copy), then forgets the saved photo choices so every profile finds its photo again. It never replaces a file that already exists.</p>';
		echo '<div class="mx-acts"><button type="button" class="mx-btn p" id="mrsh-fixall">Fix all photos</button><span id="mrsh-fix-msg" class="mx-msg" style="margin:0"></span></div>';
		echo '<div class="mx-prog" id="mrsh-fix-bar" hidden><i id="mrsh-fix-fill"></i></div></div>';

		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">2b</span><h2>Remove broken pictures</h2></div><p class="mx-sub">For profiles with a picture record but no file, no safety copy and no live copy, there is nothing to repair. This removes the dead picture record (the file is already gone) so the profile shows the normal "no photo" picture, and can email the member to add the photo again, once.</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" onsubmit="return confirm(\'Remove the broken picture records now?\')">';
		wp_nonce_field( 'mrsh_photodiag_rm' );
		echo '<input type="hidden" name="action" value="mrsh_photodiag_rm"><label style="display:block;margin:0 0 12px"><input type="checkbox" name="mail" value="1" checked> Email these members to add their photo again</label><button class="mx-btn p" ' . ( $sum['miss'] ? '' : 'disabled' ) . '>Remove broken pictures (' . (int) $sum['miss'] . ')</button></form></div>';

		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">3</span><h2>Profiles</h2></div><p class="mx-sub">Use the filter to see only profiles with a problem. Press Check addresses to test the pictures on this page.</p>';
		echo '<div class="mx-tabs"><a class="mx-btn s' . ( $only ? '' : ' p' ) . '" href="' . esc_url( $base ) . '">All profiles</a><a class="mx-btn s' . ( $only ? ' p' : '' ) . '" href="' . esc_url( add_query_arg( 'problems', 1, $base ) ) . '">Only profiles with a problem</a><a class="mx-btn s' . ( $brk ? ' p' : '' ) . '" href="' . esc_url( add_query_arg( 'broken', 1, $base ) ) . '">Broken picture only</a><button type="button" class="mx-btn s" id="mrsh-pd-all">Check addresses on this page</button><span id="mrsh-pd-msg" class="mx-msg" style="margin:0"></span></div>';
		echo '<div class="mx-tbl"><table class="widefat striped"><thead><tr><th>ID</th><th>Profile</th><th>Picture IDs</th><th>File here</th><th>Source</th><th>Address used</th><th>Web check</th><th>What it means</th></tr></thead><tbody>';
		if ( ! $rows ) {
			echo '<tr><td colspan="8">Nothing to show.</td></tr>';
		}
		foreach ( $rows as $r ) {
			echo '<tr data-u="' . esc_attr( $r['url'] ) . '">';
			echo '<td>' . (int) $r['id'] . '</td>';
			echo '<td><a href="' . esc_url( get_permalink( $r['id'] ) ) . '" target="_blank" rel="noopener"><b>' . esc_html( $r['title'] ) . '</b></a></td>';
			echo '<td>' . esc_html( $r['cands'] ?: '-' ) . '</td>';
			echo '<td>' . ( $r['local'] ? '<span class="mx-pill ok">Yes</span>' : '<span class="mx-pill bad">No</span>' ) . '</td>';
			echo '<td><span class="mx-pill">' . esc_html( $r['source'] ?: '-' ) . '</span></td>';
			echo '<td style="word-break:break-all;max-width:260px">' . ( $r['url'] ? '<a href="' . esc_url( $r['url'] ) . '" target="_blank" rel="noopener">' . esc_html( strlen( $r['url'] ) > 70 ? '...' . substr( $r['url'], -67 ) : $r['url'] ) . '</a>' : '-' ) . '</td>';
			echo '<td class="wc">' . ( $r['url'] ? '<span class="description">not checked</span>' : '-' ) . '</td>';
			echo '<td style="max-width:320px">' . esc_html( $r['note'] ) . ( self::is_broken( $r ) ? '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin-top:8px"><input type="hidden" name="action" value="mrsh_photodiag_rm"><input type="hidden" name="pid" value="' . (int) $r['id'] . '"><input type="hidden" name="mail" value="1">' . wp_nonce_field( 'mrsh_photodiag_rm', '_wpnonce', true, false ) . '<button class="mx-btn s">Remove this broken picture</button></form>' : '' ) . '</td>';
			echo '</tr>';
		}
		echo '</tbody></table></div>';
		if ( $pages > 1 ) {
			echo '<div class="mx-tabs" style="margin:14px 0 0">';
			for ( $i = 1; $i <= $pages; $i++ ) {
				$u = add_query_arg( array( 'paged' => $i, 'problems' => $only ? 1 : null, 'broken' => $brk ? 1 : null ), $base );
				echo '<a class="mx-btn s' . ( $i === $pg ? ' p' : '' ) . '" href="' . esc_url( $u ) . '">' . (int) $i . '</a>';
			}
			echo '</div>';
		}
		echo '</div>';
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">4</span><h2>Forget saved photo choices</h2></div><p class="mx-sub">The theme remembers which picture it chose for each profile. If an old choice points to a missing file, this clears them all. Nothing is deleted from the media library or from any profile.</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'mrsh_photodiag_reset' );
		echo '<input type="hidden" name="action" value="mrsh_photodiag_reset"><button class="mx-btn">Forget saved photo choices</button></form></div>';
		?>
<script>
(function(){
var pg=document.getElementById('mrsh-pb-go');
if(pg){var pm=document.getElementById('mrsh-pb-msg'),pbb=document.getElementById('mrsh-pb-bar'),pf=document.getElementById('mrsh-pb-fill'),ph=document.getElementById('mrsh-pb-have'),pn2='<?php echo esc_js( wp_create_nonce( 'mrsh_pbak' ) ); ?>';
pg.onclick=function(){pg.disabled=true;pbb.hidden=false;var after=0,saved=0,skip=0,er=0;
(function step(){var f=new FormData();f.append('action','mrsh_pbak_batch');f.append('n',pn2);f.append('after',after);
fetch(ajaxurl,{method:'POST',body:f,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(r){
if(!r||!r.success){er++;if(er>3){pm.textContent='Stopped. Press the button again.';pg.disabled=false;return}return setTimeout(step,1500)}
var d=r.data;saved+=d.done;skip+=d.skip;after=d.next;if(ph)ph.textContent=d.have;pf.style.width=(d.total?Math.min(100,Math.round(d.have/d.total*100)):100)+'%';
pm.textContent='Saved '+saved+' new copies'+(skip?', '+skip+' skipped (file missing here)':'')+'...';
if(d.end){pf.style.width='100%';pm.textContent='Done. Saved '+saved+' new copies'+(skip?'; '+skip+' skipped because the file is missing here':'')+'.';pg.disabled=false;return}
setTimeout(step,100)}).catch(function(){er++;if(er>3){pm.textContent='Network problem. Press the button again.';pg.disabled=false}else setTimeout(step,1500)})})()}}
var fx=document.getElementById('mrsh-fixall'),fm=document.getElementById('mrsh-fix-msg'),fb=document.getElementById('mrsh-fix-bar'),ff=document.getElementById('mrsh-fix-fill'),pn='<?php echo esc_js( wp_create_nonce( 'mrsh_photos' ) ); ?>';
function clearChoices(){var f=new FormData();f.append('action','mrsh_photodiag_clear');f.append('n','<?php echo esc_js( $nonce ); ?>');return fetch(ajaxurl,{method:'POST',body:f,credentials:'same-origin'}).then(function(r){return r.json()})}
if(fx){fx.onclick=function(){fx.disabled=true;fb.hidden=false;ff.style.width='0';var after=0,got=0,fail=0,errs=0;
 (function step(){var f=new FormData();f.append('action','mrsh_photos_batch');f.append('n',pn);f.append('after',after);
  fetch(ajaxurl,{method:'POST',body:f,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(r){
   if(!r||!r.success){var why=(r&&r.data)||'';if(/live site/i.test(why)){fm.textContent='This looks like the live site, so nothing is copied. Saved photo choices are cleared instead.';return clearChoices().then(function(){fm.textContent+=' Reloading...';location.reload()})}
    errs++;if(errs>3){fm.textContent='Stopped: '+(why||'server problem')+'. Press the button again.';fx.disabled=false;return}return setTimeout(step,1500)}
   var d=r.data;got+=d.got;fail+=d.fail;if(d.max){ff.style.width=Math.min(100,Math.round(d.next/d.max*100))+'%'}fm.textContent='Copied '+got+' files'+(fail?', '+fail+' not found on the live site':'')+'...';
   if(d.done){ff.style.width='100%';return clearChoices().then(function(){fm.textContent='Done. Copied '+got+' files'+(fail?'; '+fail+' not found on the live site':'')+'. Reloading...';setTimeout(function(){location.reload()},900)})}
   after=d.next;setTimeout(step,150)}).catch(function(){errs++;if(errs>3){fm.textContent='Network problem. Press the button again to continue.';fx.disabled=false}else setTimeout(step,1500)})})()}}
var rows=[].slice.call(document.querySelectorAll('tr[data-u]')),btn=document.getElementById('mrsh-pd-all'),msg=document.getElementById('mrsh-pd-msg'),n='<?php echo esc_js( $nonce ); ?>';
function one(tr){return new Promise(function(done){
 var u=tr.getAttribute('data-u'),c=tr.querySelector('.wc');if(!u){done();return}
 c.textContent='checking...';var f=new FormData();f.append('action','mrsh_photodiag_check');f.append('n',n);f.append('u',u);
 fetch(ajaxurl,{method:'POST',body:f,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(r){
  if(r&&r.success){var d=r.data,ok=d.code>=200&&d.code<300&&/^image\//.test(d.type||'');
   c.innerHTML='<b style="color:'+(ok?'#0a7a3d':'#b42318')+'">'+d.code+'</b> '+(d.type||'')+(ok?'':(d.code==403?' (blocked: permissions or hotlink protection)':d.code==404?' (file not found)':''))}
  else{c.textContent=(r&&r.data)||'not allowed'}done()}).catch(function(){c.textContent='failed';done()})})}
btn.onclick=function(){btn.disabled=true;var i=0;msg.textContent='';
 (function next(){if(i>=rows.length){btn.disabled=false;msg.textContent='Done.';return}msg.textContent='Checking '+(i+1)+' of '+rows.length+'...';one(rows[i++]).then(next)})()};
})();
</script>
		</div>
		<?php
	}

	/** Checks one picture address from the server. Only this site and the live photo host are allowed. */
	public static function check() {
		if ( ! current_user_can( 'manage_options' ) || ! check_ajax_referer( 'mrsh_photodiag', 'n', false ) ) {
			wp_send_json_error( 'Not allowed.' );
		}
		$u = isset( $_POST['u'] ) ? esc_url_raw( wp_unslash( $_POST['u'] ) ) : ''; // phpcs:ignore
		$h = strtolower( (string) wp_parse_url( $u, PHP_URL_HOST ) );
		$s = strtolower( (string) wp_parse_url( $u, PHP_URL_SCHEME ) );
		$ok = array( strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) );
		if ( function_exists( 'mrt_remote_host' ) && mrt_remote_host() ) {
			$ok[] = strtolower( mrt_remote_host() );
		}
		if ( class_exists( 'MRSH_Mem_Photos' ) && MRSH_Mem_Photos::host() ) {
			$ok[] = strtolower( MRSH_Mem_Photos::host() );
		}
		if ( ! $u || ! in_array( $s, array( 'http', 'https' ), true ) || ! in_array( $h, $ok, true ) ) {
			wp_send_json_error( 'Address is not on this site or the live site, not checked.' );
		}
		$a = array( 'timeout' => 8, 'redirection' => 3, 'headers' => array( 'Referer' => home_url( '/' ) ), 'user-agent' => 'MyRishta photo check' );
		$r = wp_remote_head( $u, $a );
		if ( ! is_wp_error( $r ) && in_array( (int) wp_remote_retrieve_response_code( $r ), array( 405, 501 ), true ) ) {
			$a['headers']['Range'] = 'bytes=0-64';
			$r = wp_remote_get( $u, $a );
		}
		if ( is_wp_error( $r ) ) {
			wp_send_json_success( array( 'code' => 0, 'type' => 'error: ' . $r->get_error_message() ) );
		}
		wp_send_json_success( array( 'code' => (int) wp_remote_retrieve_response_code( $r ), 'type' => (string) wp_remote_retrieve_header( $r, 'content-type' ) ) );
	}

	public static function clear() {
		if ( ! current_user_can( 'manage_options' ) || ! check_ajax_referer( 'mrsh_photodiag', 'n', false ) ) {
			wp_send_json_error( 'Not allowed.' );
		}
		delete_post_meta_by_key( '_mrt_ph' );
		delete_transient( 'mrsh_pd_cnt' );
		wp_send_json_success();
	}

	public static function reset() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'mrsh_photodiag_reset' ) ) {
			wp_die( 'Not allowed.' );
		}
		delete_post_meta_by_key( '_mrt_ph' );
		delete_transient( 'mrsh_pd_cnt' );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-photodiag&reset=1' ) );
		exit;
	}
}
MRSH_Mem_PhotoDiag::init();
