<?php
/**
 * Keeps off-topic articles (government loan schemes) out of Google and the sitemap,
 * so the site stays focused on rishta. Uses the existing per-post _mrsh_noindex flag,
 * set once. Remove the flag on a post's edit screen (or delete the meta) to undo.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Offtopic {
	const SLUGS = array(
		'punjab-psic-interest-free-loan-women',
		'punjab-kisan-bank-kisan-card-farm-loans',
		'apni-chhat-mehfooz-chhat-punjab-loans',
	);

	public static function init() {
		add_action( 'init', array( __CLASS__, 'run' ), 30 );
	}

	public static function run() {
		if ( get_option( 'mrsh_offtopic_done' ) === '1' ) {
			return;
		}
		foreach ( self::SLUGS as $slug ) {
			$p = get_page_by_path( $slug, OBJECT, array( 'post', 'page' ) );
			if ( $p ) {
				update_post_meta( $p->ID, '_mrsh_noindex', '1' );
			}
		}
		update_option( 'mrsh_offtopic_done', '1', false );
	}
}

MRSH_Offtopic::init();
