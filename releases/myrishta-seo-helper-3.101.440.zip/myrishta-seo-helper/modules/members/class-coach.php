<?php
/**
 * Profile Coach: one robot, one calendar, one stop button.
 *
 * Replaces the two overlapping reminder systems (MRSH_Nudge and MRSH_Finish) with one robot that decides, for each member
 * and at the moment of sending, what is still missing, and sends ONE short message with ONE button that opens the Profile
 * Helper at that point. Email goes through the existing queue (MRSH_Mailq, unsubscribe headers), plus a slim in-site banner
 * and web push for members who opted in.
 *
 * Rules for every channel together: one message per member per 36 hours (setting), at most 6 in a lifetime (setting),
 * quiet hours 22:00 to 09:00 Pakistan time (setting), the stage is re-checked at the moment of sending, and it stops on
 * complete, unsubscribe, "don't remind me", blocked, or two hard bounces. Nothing is sent until the helper is on for everyone.
 * The old robots are never switched off silently: a member they messaged in the last 36 hours is skipped, and the owner
 * retires them with one button once the coach has run one clean day.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Coach {

	const HOOK  = 'mrsh_coach_run';
	const STATS = 'mrsh_coach_stats'; // code => array( sent, opened, saved )
	const TPL   = 'mrsh_coach_tpl';
	const CPT   = 'listing_type';

	/* ---------- wiring ---------- */

	public static function init() {
		add_action( self::HOOK, array( __CLASS__, 'run' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
		add_action( 'init', array( __CLASS__, 'landed' ), 2 );
		add_action( 'init', array( __CLASS__, 'off_link' ), 2 );
		add_action( 'wp_after_insert_post', array( __CLASS__, 'saved' ), 20, 4 );
		add_action( 'wp_footer', array( __CLASS__, 'banner' ), 50 );
		add_filter( 'mrsh_push_notif', array( __CLASS__, 'push_text' ), 10, 2 );
		add_action( 'mrsh_coach_summary', array( __CLASS__, 'summary' ) );
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + 900, 'hourly', self::HOOK );
		}
	}

	/* ---------- templates (Urdu first, English under it, one button) ---------- */

	public static function default_tpl() {
		return array(
			'A-1' => array( 's' => 'اپنا پروفائل بول کر بنائیں: صرف دو منٹ', 'b' => 'السلام علیکم! آپ نے My Rishta پر اکاؤنٹ بنایا مگر پروفائل ابھی مکمل نہیں ہوا۔ اب لکھنے کی ضرورت نہیں: اردو میں بولیں، ہم فارم بھر دیں گے، آپ صرف دیکھ کر محفوظ کریں۔', 'e' => 'You joined My Rishta but your profile is not made yet. No typing needed: speak in Urdu, we fill the form, you check and save.', 'btn' => 'بول کر پروفائل بنائیں' ),
			'A-2' => array( 's' => 'سوال و جواب سے پروفائل بنائیں: تقریباً دس ٹیپ', 'b' => 'بولنا پسند نہیں؟ کوئی بات نہیں۔ ایک وقت میں ایک سوال، بڑے بٹن، تقریباً دس ٹیپ میں پروفائل تیار۔', 'e' => 'Prefer not to speak? One question at a time, big buttons, about ten taps.', 'btn' => 'سوال و جواب شروع کریں' ),
			'A-3' => array( 's' => 'والدین بھی پروفائل بنا سکتے ہیں', 'b' => 'بیٹے یا بیٹی کا پروفائل والدین خود بنا سکتے ہیں: اردو میں بتائیں، باقی کام ہم کر دیں گے۔ یہ لنک گھر میں کسی کو بھی بھیج دیں۔', 'e' => 'Parents can make a profile for a son or daughter. Share this link with someone at home.', 'btn' => 'پروفائل بنائیں' ),
			'A-4' => array( 's' => 'آخری یاددہانی: آپ کا پروفائل ابھی نہیں بنا', 'b' => 'یہ ہماری آخری یاددہانی ہے۔ جب چاہیں، دو منٹ میں اردو بول کر پروفائل بنا لیں۔ مزید ای میل نہیں بھیجی جائے گی۔', 'e' => 'This is our last reminder. Make your profile in two minutes whenever you like.', 'btn' => 'بول کر پروفائل بنائیں' ),
			'AN'  => array( 's' => 'نیا: اردو بول کر پروفائل بھریں', 'b' => 'اب پروفائل اردو بول کر بھرا جا سکتا ہے۔ آپ بولیں، ہم فارم بھر دیں گے، آپ ہر جواب دیکھ کر محفوظ کریں۔ صرف دو منٹ۔', 'e' => 'New: fill your profile by speaking Urdu.', 'btn' => 'بول کر پروفائل بنائیں' ),
			'B-1' => array( 's' => 'آپ کا پروفائل تقریباً مکمل ہے', 'b' => 'بس {missing} باقی ہے۔ ایک منٹ میں مکمل کریں۔', 'e' => 'Your profile is almost done. Only {missing_en} is left.', 'btn' => 'مکمل کریں' ),
			'B-2' => array( 's' => 'آپ کا پروفائل تقریباً مکمل ہے', 'b' => 'بس {missing} باقی ہے۔ ایک منٹ میں مکمل کریں۔', 'e' => 'Your profile is almost done. Only {missing_en} is left.', 'btn' => 'مکمل کریں' ),
			'B-3' => array( 's' => 'آخری بار: پروفائل مکمل کریں', 'b' => 'بس {missing} باقی ہے۔ مکمل پروفائل پر خاندان زیادہ اعتماد کرتے ہیں۔', 'e' => 'Last note: only {missing_en} is left.', 'btn' => 'مکمل کریں' ),
			'C-1' => array( 's' => 'اپنا ای میل تصدیق کریں', 'b' => 'آپ کا پروفائل اچھا ہے۔ آخری قدم: اپنا ای میل ایڈریس تصدیق کریں تاکہ ہمیں معلوم ہو کہ یہ آپ ہی ہیں۔', 'e' => 'One last step: confirm your email address.', 'btn' => 'ای میل تصدیق کریں' ),
		);
	}

	public static function tpl() {
		$t = self::default_tpl();
		$o = get_option( self::TPL, array() );
		if ( is_array( $o ) ) {
			foreach ( $o as $k => $v ) {
				if ( isset( $t[ $k ] ) && is_array( $v ) ) {
					foreach ( array( 's', 'b', 'e', 'btn' ) as $f ) {
						if ( isset( $v[ $f ] ) && '' !== trim( (string) $v[ $f ] ) ) {
							$t[ $k ][ $f ] = (string) $v[ $f ];
						}
					}
				}
			}
		}
		return $t;
	}

	/* ---------- facts about one member ---------- */

	private static function staff( $u ) {
		return user_can( $u, 'manage_options' ) || user_can( $u, 'publish_posts' ) || user_can( $u, 'edit_others_posts' );
	}

	private static function stopped( $uid ) {
		return get_user_meta( $uid, 'mrsh_nudge_stop', true ) || get_user_meta( $uid, 'mrsh_nudge_off', true ) || get_user_meta( $uid, 'mrsh_coach_stop', true ) || get_user_meta( $uid, 'mrt_banned', true ) || get_user_meta( $uid, 'mrsh_mail_bad', true );
	}

	/** The member's best profile, or null. */
	public static function profile( $uid ) {
		$l = get_posts( array( 'post_type' => self::CPT, 'author' => $uid, 'post_status' => array( 'publish', 'draft', 'pending', 'pending_approval' ), 'numberposts' => 3, 'orderby' => 'date', 'order' => 'DESC' ) );
		return $l ? $l[0] : null;
	}

	/**
	 * Stage of one member right now.
	 * A signed up, no profile · B profile below the goal · C complete but email not confirmed · D live and complete · X left alone.
	 */
	public static function stage( $u ) {
		if ( ! $u || self::staff( $u ) || self::stopped( $u->ID ) || ! is_email( $u->user_email ) ) {
			return array( 'stage' => 'X', 'miss' => array(), 'score' => 0 );
		}
		$p = self::profile( $u->ID );
		if ( ! $p ) {
			return array( 'stage' => 'A', 'miss' => array(), 'score' => 0 );
		}
		$goal = class_exists( 'MRSH_Nudge' ) ? (int) MRSH_Nudge::get()['goal'] : 80;
		$sc   = class_exists( 'MRSH_Nudge' ) ? MRSH_Nudge::score( $p ) : array( 100, array() );
		if ( $sc[0] < $goal ) {
			return array( 'stage' => 'B', 'miss' => $sc[1], 'score' => $sc[0], 'pid' => $p->ID );
		}
		if ( ! get_user_meta( $u->ID, 'mrsh_email_ok', true ) ) {
			return array( 'stage' => 'C', 'miss' => array(), 'score' => $sc[0], 'pid' => $p->ID );
		}
		return array( 'stage' => 'D', 'miss' => array(), 'score' => $sc[0], 'pid' => $p->ID );
	}

	/** Pakistan time, quiet hours as a start and an end hour (22 to 9 runs over midnight). */
	public static function quiet( $now = 0 ) {
		$o = MRSH_Helper::get();
		$h = (int) ( new DateTime( '@' . ( $now ? $now : time() ) ) )->setTimezone( new DateTimeZone( 'Asia/Karachi' ) )->format( 'G' );
		$a = (int) $o['quiet_from'];
		$b = (int) $o['quiet_to'];
		return $a > $b ? ( $h >= $a || $h < $b ) : ( $h >= $a && $h < $b );
	}

	/** The last time ANY reminder reached this member: this coach or either old robot. */
	public static function last_any( $uid ) {
		$t = 0;
		foreach ( array( 'mrsh_coach_last', 'mrsh_nudge_last', 'mrsh_nudge1', 'mrsh_nudge2', 'mrsh_coach_push_t' ) as $k ) {
			$t = max( $t, (int) get_user_meta( $uid, $k, true ) );
		}
		return $t;
	}

	/** Which message is due now for this member, or ''. Stage is re-checked here, at the moment of sending. */
	public static function due( $u, $st, $now ) {
		$o = MRSH_Helper::get();
		$id = $u->ID;
		if ( 'X' === $st['stage'] || 'D' === $st['stage'] ) {
			return '';
		}
		if ( (int) get_user_meta( $id, 'mrsh_coach_n', true ) >= (int) $o['life'] ) {
			return '';
		}
		$gap = max( 1, (int) $o['gap_h'] ) * HOUR_IN_SECONDS;
		if ( $now - self::last_any( $id ) < $gap ) {
			return '';
		}
		$age = ( $now - strtotime( $u->user_registered . ' UTC' ) ) / DAY_IN_SECONDS;
		$old = (int) get_user_meta( $id, 'mrsh_nudge_count', true ) > 0 || (int) get_user_meta( $id, 'mrsh_nudge1', true ) > 0;
		if ( ! empty( $o['announce'] ) && $old && ! get_user_meta( $id, 'mrsh_coach_ann', true ) && in_array( $st['stage'], array( 'A', 'B' ), true ) ) {
			return 'AN';
		}
		if ( 'A' === $st['stage'] ) {
			$n    = (int) get_user_meta( $id, 'mrsh_coach_A', true );
			$days = array( 1, 3, 7, 14 );
			return ( $n < 4 && $age >= $days[ $n ] ) ? 'A-' . ( $n + 1 ) : '';
		}
		if ( 'B' === $st['stage'] ) {
			$n    = (int) get_user_meta( $id, 'mrsh_coach_B', true );
			$seen = max( (int) get_user_meta( $id, 'mrt_seen', true ), ! empty( $st['pid'] ) ? (int) strtotime( get_post_field( 'post_modified_gmt', $st['pid'] ) . ' UTC' ) : 0 );
			$last = (int) get_user_meta( $id, 'mrsh_coach_last', true );
			$base = max( $seen, $last );
			$wait = 0 === $n ? 2 * DAY_IN_SECONDS : 5 * DAY_IN_SECONDS;
			return ( $n < 3 && $base && $now - $base >= $wait ) ? 'B-' . ( $n + 1 ) : '';
		}
		if ( 'C' === $st['stage'] ) {
			$n = (int) get_user_meta( $id, 'mrsh_coach_C', true );
			return ( $n < 2 && $now - self::last_any( $id ) >= 5 * DAY_IN_SECONDS ) ? 'C-1' : '';
		}
		return '';
	}

	/* ---------- planning and sending ---------- */

	public static function live() {
		$o = MRSH_Helper::get();
		return 'all' === $o['who'] && ! empty( $o['coach'] ) && empty( $o['paused'] );
	}

	/** Who would get what, without sending anything. Returns array of array( uid, code, stage ). */
	public static function plan( $limit = 12 ) {
		$now = time();
		$out = array();
		$ids = get_users( array( 'fields' => 'ID', 'number' => 3000, 'orderby' => 'registered', 'order' => 'DESC' ) );
		foreach ( $ids as $id ) {
			if ( count( $out ) >= $limit ) {
				break;
			}
			$u  = get_userdata( $id );
			$st = self::stage( $u );
			$c  = self::due( $u, $st, $now );
			if ( '' !== $c ) {
				$out[] = array( 'uid' => (int) $id, 'code' => $c, 'stage' => $st['stage'] );
			}
		}
		return $out;
	}

	/** Hourly run. $force ignores the on switch and quiet hours (the Run coach now button) but never the per-member rules. */
	public static function run( $force = false ) {
		$o0 = MRSH_Helper::get();
		if ( 'all' !== $o0['who'] || ! empty( $o0['paused'] ) || empty( $o0['coach'] ) ) {
			return 0; // never sends while the helper is in preview, paused or off, not even by hand
		}
		if ( ! $force && self::quiet() ) {
			return 0;
		}
		if ( class_exists( 'MRSH_Mailq' ) && get_transient( 'mrsh_coach_bounce_pause' ) ) {
			return 0;
		}
		$o     = MRSH_Helper::get();
		$sent  = 0;
		$now   = time();
		$ann   = 0;
		$limit = 12;
		$ids   = get_users( array( 'fields' => 'ID', 'number' => 3000, 'orderby' => 'registered', 'order' => 'DESC' ) );
		foreach ( $ids as $id ) {
			if ( $sent >= $limit ) {
				break;
			}
			$u  = get_userdata( $id );
			$st = self::stage( $u ); // re-checked now
			$c  = self::due( $u, $st, $now );
			if ( '' === $c ) {
				// no email due: a push may go instead (opted in, at most one every 3 days)
				if ( in_array( $st['stage'], array( 'A', 'B' ), true ) && ! empty( $o['push'] ) && self::push_due( $u ) ) {
					if ( self::push( $u, $st ) ) {
						$sent++;
					}
				}
				continue;
			}
			if ( 'AN' === $c && $ann >= 12 ) {
				continue;
			}
			if ( self::send( $u, $c, $st ) ) {
				$sent++;
				if ( 'AN' === $c ) {
					$ann++;
				}
			}
		}
		if ( $sent && ! get_option( 'mrsh_coach_first' ) ) {
			update_option( 'mrsh_coach_first', time(), false );
			wp_schedule_single_event( time() + DAY_IN_SECONDS, 'mrsh_coach_summary' ); // the owner gets a summary after the first day
		}
		self::bounce_watch();
		$sent += self::news_tick();
		return $sent;
	}

	private static function push_due( $u ) {
		if ( ! array_filter( (array) get_user_meta( $u->ID, 'mrt_push', true ) ) ) {
			return false;
		}
		$o   = MRSH_Helper::get();
		$now = time();
		if ( $now - (int) get_user_meta( $u->ID, 'mrsh_coach_push_t', true ) < 3 * DAY_IN_SECONDS ) {
			return false;
		}
		if ( $now - self::last_any( $u->ID ) < (int) $o['gap_h'] * HOUR_IN_SECONDS || (int) get_user_meta( $u->ID, 'mrsh_coach_n', true ) >= (int) $o['life'] ) {
			return false;
		}
		return true;
	}

	private static function push( $u, $st ) {
		if ( ! class_exists( 'MRSH_Mem_Push' ) ) {
			return false;
		}
		update_user_meta( $u->ID, 'mrsh_coach_push_pending', time() );
		$n = MRSH_Mem_Push::ping( $u->ID, 'finish' );
		if ( $n > 0 ) {
			update_user_meta( $u->ID, 'mrsh_coach_push_t', time() );
			update_user_meta( $u->ID, 'mrsh_coach_n', (int) get_user_meta( $u->ID, 'mrsh_coach_n', true ) + 1 );
			self::stat( 'push', 0 );
			return true;
		}
		delete_user_meta( $u->ID, 'mrsh_coach_push_pending' );
		return false;
	}

	/** Text of the push alert (the service worker asks the site what to show). */
	public static function push_text( $arr, $uid ) {
		$t = (int) get_user_meta( $uid, 'mrsh_coach_push_pending', true );
		if ( $t && time() - $t < 600 && is_array( $arr ) && ! preg_match( '/unread/', (string) ( $arr['body'] ?? '' ) ) ) {
			$arr['body'] = 'اپنا پروفائل مکمل کریں: بول کر، صرف دو منٹ';
			$arr['url']  = self::link( 'push-1' );
			delete_user_meta( $uid, 'mrsh_coach_push_pending' );
		}
		return $arr;
	}

	public static function link( $code ) {
		return add_query_arg( array( 'helper' => 1, 'from' => $code ), home_url( '/add-listing/' ) );
	}

	private static function sign( $uid, $what ) {
		return hash_hmac( 'sha256', $what . $uid, wp_salt( 'auth' ) );
	}

	/** Email body parts for one member and one message code. Returns array( subject, text, html ). */
	public static function build( $u, $code, $st ) {
		$t   = self::tpl();
		$k   = isset( $t[ $code ] ) ? $code : 'A-1';
		$m   = $t[ $k ];
		$miss_ur = array();
		$miss_en = array();
		foreach ( (array) ( $st['miss'] ?? array() ) as $x ) {
			$miss_en[] = $x[0];
			$miss_ur[] = $x[1];
		}
		$mu  = $miss_ur ? implode( '، ', array_slice( $miss_ur, 0, 3 ) ) : 'آخری چند باتیں';
		$me  = $miss_en ? implode( ', ', array_slice( $miss_en, 0, 3 ) ) : 'a few last details';
		$rep = array( '{missing}' => $mu, '{missing_en}' => $me );
		$s   = strtr( $m['s'], $rep );
		$bu  = strtr( $m['b'], $rep );
		$be  = strtr( $m['e'], $rep );
		$url = 'C-1' === $k ? MRSH_Nudge::ev_url( $u->ID ) : self::link( $k . '-' . (int) get_user_meta( $u->ID, 'mrsh_coach_n', true ) );
		$url = 'C-1' === $k ? $url : self::link( $k );
		$un  = add_query_arg( array( 'mrsh_unsub' => $u->ID, 't' => self::sign( $u->ID, 'nudge' ) ), home_url( '/' ) );
		$off = add_query_arg( array( 'mrsh_coach_off' => $u->ID, 't' => self::sign( $u->ID, 'coachoff' ) ), home_url( '/' ) );
		$text = $bu . "\n\n" . $m['btn'] . ': ' . $url . "\n\n" . $be . "\n\n— My Rishta Pakistan\nروکنے کے لیے / Stop: " . $un . "\nمجھے یاد نہ دلائیں / Don't remind me: " . $off . "\n";
		$icons = array( 'A' => '🎤', 'AN' => '🎤', 'B' => '📸', 'C' => '✉️' );
		$html  = MRSH_Mem_Mail::shell( array(
			'icon'    => $icons[ 0 === strpos( $k, 'AN' ) ? 'AN' : $k[0] ] ?? '🎤',
			'head'    => $s,
			'head_en' => '',
			'ur'      => $bu,
			'en'      => $be,
			'btn_ur'  => $m['btn'],
			'link'    => $url,
			'steps'   => in_array( $k[0], array( 'A' ), true ) || 'AN' === $k,
			'mode'    => 'both',
			'tone'    => 'C' === $k[0] ? 'green' : 'purple',
			'pre'     => $s,
			'foot'    => '<a href="' . esc_url( $un ) . '" style="color:#6b7280">روکیں / Stop reminders</a> &middot; <a href="' . esc_url( $off ) . '" style="color:#6b7280">یاد نہ دلائیں / Don\'t remind me</a><br>',
		) );
		return array( $s, $text, $html, $un );
	}

	private static function send( $u, $code, $st ) {
		list( $subject, $text, $html, $un ) = self::build( $u, $code, $st );
		$hdr = array(
			'Reply-To: My Rishta Support <support@myrishta.pk>',
			'List-Unsubscribe: <' . $un . '>, <mailto:support@myrishta.pk?subject=Unsubscribe>',
			'List-Unsubscribe-Post: List-Unsubscribe=One-Click',
		);
		$ok = class_exists( 'MRSH_Mailq' )
			? (bool) MRSH_Mailq::add( $u->user_email, $subject, $text, array( 'html' => $html, 'headers' => $hdr, 'kind' => 'coach', 'uid' => $u->ID ) )
			: wp_mail( $u->user_email, $subject, $text, $hdr );
		if ( ! $ok ) {
			return false;
		}
		$now = time();
		update_user_meta( $u->ID, 'mrsh_coach_last', $now );
		update_user_meta( $u->ID, 'mrsh_coach_n', (int) get_user_meta( $u->ID, 'mrsh_coach_n', true ) + 1 );
		update_user_meta( $u->ID, 'mrsh_coach_code', $code );
		if ( 'AN' === $code ) {
			update_user_meta( $u->ID, 'mrsh_coach_ann', $now );
			// after the announcement the normal calendar goes on from day 14, with at most one more message
			if ( 'A' === $st['stage'] ) {
				update_user_meta( $u->ID, 'mrsh_coach_A', 3 );
			} elseif ( 'B' === $st['stage'] ) {
				update_user_meta( $u->ID, 'mrsh_coach_B', 2 );
			}
		} elseif ( 0 === strpos( $code, 'A-' ) ) {
			update_user_meta( $u->ID, 'mrsh_coach_A', (int) substr( $code, 2 ) );
		} elseif ( 0 === strpos( $code, 'B-' ) ) {
			update_user_meta( $u->ID, 'mrsh_coach_B', (int) substr( $code, 2 ) );
		} elseif ( 0 === strpos( $code, 'C-' ) ) {
			update_user_meta( $u->ID, 'mrsh_coach_C', (int) get_user_meta( $u->ID, 'mrsh_coach_C', true ) + 1 );
		}
		self::stat( $code, 0 );
		MRSH_Helper::log( 'send', $code . ' to #' . $u->ID );
		return true;
	}

	/** Sends one message of this kind to an administrator as a test. */
	public static function send_test( $u, $code ) {
		$st = array( 'stage' => 'B', 'miss' => array( array( 'a clear photo', 'صاف تصویر' ), array( 'a few lines about yourself', 'اپنے بارے میں چند سطریں' ) ) );
		list( $s, $t, $h ) = self::build( $u, $code, $st );
		return wp_mail( $u->user_email, '[Test] ' . $s, $h, array( 'Content-Type: text/html; charset=UTF-8' ) ) ? true : false;
	}

	/** Manual invite: sends the message the member is due for (or the first one of their stage) right now, ignoring the calendar. */
	public static function invite( $uid ) {
		if ( 'all' !== MRSH_Helper::get()['who'] ) {
			return false;
		}
		$u  = get_userdata( (int) $uid );
		$st = self::stage( $u );
		if ( ! $u || ! in_array( $st['stage'], array( 'A', 'B' ), true ) ) {
			return false;
		}
		$code = 'A' === $st['stage'] ? 'AN' : 'B-1';
		return self::send( $u, $code, $st );
	}

	/* ---------- measuring ---------- */

	public static function stat( $code, $i ) {
		$s = get_option( self::STATS, array() );
		$s = is_array( $s ) ? $s : array();
		if ( ! isset( $s[ $code ] ) ) {
			$s[ $code ] = array( 0, 0, 0 );
		}
		$s[ $code ][ $i ]++;
		update_option( self::STATS, $s, false );
	}

	public static function stats() {
		$s = get_option( self::STATS, array() );
		return is_array( $s ) ? $s : array();
	}

	private static function from_ok( $f ) {
		return (bool) preg_match( '/^(?:[ABC]-\d|AN|NW|banner|push-\d)$/', (string) $f );
	}

	/** A coach link was opened: count it once per member (or per browser when not logged in), and remember it for the "saved" count. */
	public static function landed() {
		if ( empty( $_GET['from'] ) || is_admin() ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$f = sanitize_text_field( wp_unslash( $_GET['from'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( ! self::from_ok( $f ) ) {
			return;
		}
		$uid = get_current_user_id();
		if ( $uid ) {
			self::opened( $uid, $f );
		} elseif ( empty( $_COOKIE['mrsh_cf'] ) && ! headers_sent() ) {
			setcookie( 'mrsh_cf', $f, time() + 30 * DAY_IN_SECONDS, COOKIEPATH ? COOKIEPATH : '/', '', is_ssl(), true );
			self::stat( $f, 1 );
		}
	}

	public static function opened( $uid, $f ) {
		if ( ! self::from_ok( $f ) ) {
			return;
		}
		$seen = get_user_meta( $uid, 'mrsh_coach_opened', true );
		$seen = is_array( $seen ) ? $seen : array();
		update_user_meta( $uid, 'mrsh_coach_from', array( $f, time() ) );
		if ( ! in_array( $f, $seen, true ) ) {
			$seen[] = $f;
			update_user_meta( $uid, 'mrsh_coach_opened', $seen );
			if ( empty( $_COOKIE['mrsh_cf'] ) || $_COOKIE['mrsh_cf'] !== $f ) { // phpcs:ignore
				self::stat( $f, 1 );
			}
		}
	}

	/** A new profile was saved: count it against the coach link that brought the member, when that was within 7 days. */
	public static function saved( $post_id, $post, $update, $before ) {
		if ( $update || ! $post || self::CPT !== $post->post_type || 'auto-draft' === $post->post_status ) {
			return;
		}
		$uid = (int) $post->post_author;
		$f   = get_user_meta( $uid, 'mrsh_coach_from', true );
		if ( is_array( $f ) && ! empty( $f[0] ) && time() - (int) $f[1] < 7 * DAY_IN_SECONDS && ! get_user_meta( $uid, 'mrsh_coach_saved', true ) ) {
			update_user_meta( $uid, 'mrsh_coach_saved', time() );
			self::stat( (string) $f[0], 2 );
		}
	}

	public static function off_link() {
		if ( empty( $_GET['mrsh_coach_off'] ) || empty( $_GET['t'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$uid = (int) $_GET['mrsh_coach_off']; // phpcs:ignore WordPress.Security.NonceVerification
		$t   = sanitize_text_field( wp_unslash( $_GET['t'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( $uid > 0 && hash_equals( self::sign( $uid, 'coachoff' ), $t ) ) {
			update_user_meta( $uid, 'mrsh_nudge_off', time() );
			wp_die( '<p dir="rtl" style="font-size:18px">ٹھیک ہے، اب ہم آپ کو پروفائل کی یاددہانی نہیں بھیجیں گے۔</p><p>You will not get profile reminders any more.</p><p><a href="' . esc_url( home_url( '/' ) ) . '">My Rishta Pakistan</a></p>', 'Reminders stopped', array( 'response' => 200 ) );
		}
	}

	/** More than 10% hard bounces in a day: the coach pauses itself and a ticket opens. */
	private static function bounce_watch() {
		global $wpdb;
		$sent = (int) MRSH_Helper::day_sum( 'coach_sent', 1 );
		$sent = max( $sent, 0 );
		$n    = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key='mrsh_mail_bad' AND meta_value > %d", time() - DAY_IN_SECONDS ) ); // phpcs:ignore WordPress.DB
		$tot  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key='mrsh_coach_last' AND meta_value > %d", time() - DAY_IN_SECONDS ) ); // phpcs:ignore WordPress.DB
		if ( $tot >= 10 && $n > 0.1 * $tot ) {
			set_transient( 'mrsh_coach_bounce_pause', 1, DAY_IN_SECONDS );
			if ( class_exists( 'MRSH_Fixer' ) ) {
				MRSH_Fixer::ticket( 'ph_bounce', 'Profile Coach paused: many bounced emails', 'More than 10% of the coach emails sent in the last day bounced. The coach paused itself for a day. Check the mail settings, then press Run coach now on the Profile Helper page.', 'high', 'needs_approval' );
			}
		}
	}

	/** One day after the first send: a summary for the owner with a Pause coach button. */
	public static function summary() {
		$s = self::stats();
		$n = 0;
		foreach ( $s as $c => $v ) {
			$n += (int) $v[0];
		}
		$pause = wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_ph_pause' ), 'mrsh_ph_pause' );
		wp_mail( get_option( 'admin_email' ), 'Profile Coach: first day summary', 'The Profile Coach has sent ' . $n . " message(s) so far.\n\nSee the numbers: " . admin_url( 'admin.php?page=' . MRSH_Helper::SLUG ) . "\nPause the coach (one click, you must be logged in): " . $pause . "\n" );
	}

	/* ---------- one-time news to newsletter subscribers ---------- */

	const NEWS = 'mrsh_ph_news'; // array( on => 0/1, started => time, sent => n )

	public static function news_state() {
		$n = get_option( self::NEWS, array() );
		return wp_parse_args( is_array( $n ) ? $n : array(), array( 'on' => 0, 'started' => 0, 'sent' => 0 ) );
	}

	/** Members who may get the news: not opted out of the newsletter, not stopped or blocked, valid email, not staff, not yet sent. */
	public static function news_audience( $limit = 5000 ) {
		$ids = get_users( array( 'fields' => 'ID', 'number' => $limit, 'orderby' => 'registered', 'order' => 'DESC', 'meta_query' => array( 'relation' => 'AND',
			array( 'relation' => 'OR', array( 'key' => 'mrt_news_ok', 'compare' => 'NOT EXISTS' ), array( 'key' => 'mrt_news_ok', 'value' => '0', 'compare' => '!=' ) ),
			array( 'key' => 'mrsh_ph_news_sent', 'compare' => 'NOT EXISTS' ) ) ) );
		$out = array();
		foreach ( $ids as $id ) {
			$u = get_userdata( $id );
			if ( $u && is_email( $u->user_email ) && ! self::staff( $u ) && ! get_user_meta( $id, 'mrsh_nudge_stop', true ) && ! get_user_meta( $id, 'mrsh_coach_stop', true ) && ! get_user_meta( $id, 'mrsh_mail_bad', true ) && ! get_user_meta( $id, 'mrt_banned', true ) ) {
				$out[] = (int) $id;
			}
		}
		return $out;
	}

	public static function news_mail( $u ) {
		$link = self::link( 'NW' );
		$un   = add_query_arg( array( 'mrsh_unsub' => $u->ID, 'k' => hash_hmac( 'sha256', 'unsub' . $u->ID, wp_salt() ) ), home_url( '/' ) );
		$ur   = "السلام علیکم!\n\nاب پروفائل لکھنے کی ضرورت نہیں۔ اردو میں بولیں، ہم فارم بھر دیں گے، آپ صرف دیکھ کر محفوظ کریں۔ صرف دو منٹ۔\n\nبیٹے، بیٹی یا بھائی بہن کا رشتہ بھی اسی طرح درج کریں۔ یہ پیغام اپنے گھر والوں اور جاننے والوں کو بھی بھیج دیں۔";
		$en   = "New: fill your profile by speaking Urdu. No typing needed: you speak, we fill the form, you check and save. Two minutes. Works for a son, daughter or sibling too, and it is still free.";
		$html = MRSH_Mem_Mail::shell( array(
			'icon' => '🎤', 'head' => 'نیا: اردو بول کر پروفائل بنائیں', 'head_en' => 'New: make your profile by speaking', 'ur' => $ur, 'en' => $en,
			'btn_ur' => 'بول کر پروفائل بنائیں', 'link' => $link, 'steps' => true, 'mode' => 'both', 'tone' => 'purple',
			'foot' => '<a href="' . esc_url( $un ) . '" style="color:#6b7280">نیوز لیٹر بند کریں / Unsubscribe</a><br>',
		) );
		return array( 'نیا: اردو بول کر پروفائل بنائیں | New: make your profile by speaking', $ur . "\n\n" . $link . "\n\n" . $en . "\n\nUnsubscribe: " . $un . "\n", $html, $un );
	}

	/** Called every hour from run(): up to 40 emails, only after the owner pressed Start, never in quiet hours. */
	public static function news_tick() {
		$st = self::news_state();
		if ( empty( $st['on'] ) || self::quiet() || get_transient( 'mrsh_coach_bounce_pause' ) ) {
			return 0;
		}
		$sent = 0;
		foreach ( self::news_audience( 600 ) as $id ) {
			if ( $sent >= 40 ) {
				break;
			}
			$u = get_userdata( $id );
			if ( time() - self::last_any( $id ) < 6 * HOUR_IN_SECONDS ) { // someone mailed in the last hours: wait for the next run
				continue;
			}
			list( $subject, $text, $html, $un ) = self::news_mail( $u );
			$ok = class_exists( 'MRSH_Mailq' ) ? (bool) MRSH_Mailq::add( $u->user_email, $subject, $text, array( 'html' => $html, 'headers' => array( 'List-Unsubscribe: <' . $un . '>', 'List-Unsubscribe-Post: List-Unsubscribe=One-Click' ), 'kind' => 'news', 'uid' => $u->ID ) ) : false;
			update_user_meta( $id, 'mrsh_ph_news_sent', time() ); // marked even when the address was refused, so it is not retried every hour
			if ( $ok ) {
				$sent++;
				self::stat( 'NW', 0 );
			}
		}
		if ( $sent ) {
			$st['sent'] = (int) $st['sent'] + $sent;
			update_option( self::NEWS, $st, false );
			MRSH_Helper::log( 'news', $sent . ' news email(s) queued' );
		}
		if ( ! self::news_audience( 1 ) ) {
			$st['on'] = 0;
			update_option( self::NEWS, $st, false );
			MRSH_Helper::log( 'news', 'News finished: everyone has been mailed' );
		}
		return $sent;
	}

	/* ---------- in-site banner ---------- */

	public static function banner() {
		$o = MRSH_Helper::get();
		if ( is_admin() || empty( $o['banner'] ) || ! is_user_logged_in() ) {
			return;
		}
		$uid = get_current_user_id();
		if ( ! MRSH_Helper::active_for( $uid ) || is_page( 'add-listing' ) ) {
			return;
		}
		$k  = 'mrsh_cb_' . $uid;
		$st = get_transient( $k );
		if ( ! is_array( $st ) ) {
			$st = self::stage( wp_get_current_user() );
			$st = array( 'stage' => $st['stage'], 'score' => (int) $st['score'] );
			set_transient( $k, $st, 10 * MINUTE_IN_SECONDS );
		}
		if ( ! in_array( $st['stage'], array( 'A', 'B' ), true ) ) {
			return;
		}
		$S = MRSH_Helper::strings();
		echo '<div id="mrsh-cb" dir="rtl" lang="ur" hidden style="position:fixed;left:0;right:0;bottom:0;z-index:9990;background:#4c1d95;color:#fff;padding:8px 12px calc(8px + env(safe-area-inset-bottom,0px));display:flex;align-items:center;gap:10px;font:16px/1.7 \'Noto Nastaliq Urdu\',Tahoma,sans-serif">'
			. '<span style="flex:none;width:38px;height:38px;border-radius:50%;background:conic-gradient(#f9a8d4 ' . (int) $st['score'] . '%,rgba(255,255,255,.25) 0);display:grid;place-items:center;font-size:11px;direction:ltr"><b style="background:#4c1d95;border-radius:50%;width:28px;height:28px;display:grid;place-items:center">' . (int) $st['score'] . '%</b></span>'
			. '<span style="flex:1;min-width:0">' . esc_html( $S['banner'] ) . '</span>'
			. '<a href="' . esc_url( self::link( 'banner' ) ) . '" style="flex:none;min-height:44px;display:inline-flex;align-items:center;background:#fff;color:#4c1d95;font-weight:700;border-radius:12px;padding:0 16px;text-decoration:none">' . esc_html( $S['banner_go'] ) . '</a>'
			. '<button type="button" aria-label="close" style="flex:none;min-width:44px;min-height:44px;background:none;border:0;color:#fff;font-size:22px;cursor:pointer">&times;</button></div>'
			. '<script>(function(){var b=document.getElementById("mrsh-cb");if(!b)return;try{var t=+localStorage.getItem("mrsh_cb_x")||0;if(Date.now()-t<259200000)return}catch(e){}b.hidden=false;b.querySelector("button").onclick=function(){b.hidden=true;try{localStorage.setItem("mrsh_cb_x",Date.now())}catch(e){}}})();</script>';
	}
}

MRSH_Coach::init();
