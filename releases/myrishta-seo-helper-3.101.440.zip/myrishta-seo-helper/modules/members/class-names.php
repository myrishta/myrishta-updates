<?php
/**
 * Brand and names: change the site name, short name, domain, e-mail address and any other word from one admin page, so the
 * same plugin and theme can run another website (for example a Bangladesh or UK matrimony site).
 * It rewrites the text that visitors see: page text, titles, meta tags, structured data, the phone-app manifest and e-mails.
 * It never touches web addresses, scripts, styles or the database. Option: mrsh_brand.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Names {

	const DEF_NAME   = 'My Rishta Pakistan';
	const DEF_SHORT  = 'My Rishta';
	const DEF_DOMAIN = 'myrishta.pk';

	private static $pairs = null;
	private static $ci    = array();

	public static function get( $k = null ) {
		$o = array_merge( array( 'name' => self::DEF_NAME, 'short' => self::DEF_SHORT, 'domain' => self::DEF_DOMAIN, 'email' => '', 'pairs' => '', 'admin' => 1, 'ci' => 1 ), (array) get_option( 'mrsh_brand', array() ) );
		return null === $k ? $o : ( $o[ $k ] ?? '' );
	}

	/** The list of exact replacements, longest first. */
	public static function pairs() {
		if ( null !== self::$pairs ) {
			return self::$pairs;
		}
		$o = self::get();
		$p = array();
		$n = trim( (string) $o['name'] );
		$s = trim( (string) $o['short'] );
		if ( $n && $n !== self::DEF_NAME ) {
			$p[ self::DEF_NAME ]          = $n;
			$p[ strtoupper( self::DEF_NAME ) ] = strtoupper( $n );
		}
		if ( $s && $s !== self::DEF_SHORT ) {
			$p[ self::DEF_SHORT ]          = $s;
			$p[ strtoupper( self::DEF_SHORT ) ] = strtoupper( $s );
			$p['MyRishta']                 = preg_replace( '/\s+/', '', $s );
		}
		$ci = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $o['pairs'] ) as $line ) {
			if ( false !== strpos( $line, '=>' ) ) {
				list( $a, $b ) = array_map( 'trim', explode( '=>', $line, 2 ) );
				if ( '' !== $a && $a !== $b ) {
					if ( ! empty( $o['ci'] ) ) {
						$ci[ $a ] = $b; // matches any capital or small letters
					} else {
						$p[ $a ] = $b;
					}
				}
			}
		}
		uksort( $p, function ( $x, $y ) { return strlen( $y ) - strlen( $x ); } );
		uksort( $ci, function ( $x, $y ) { return strlen( $y ) - strlen( $x ); } );
		self::$ci    = $ci;
		self::$pairs = $p;
		return $p;
	}

	public static function active() {
		$o = self::get();
		return (bool) ( self::pairs() || self::$ci || ( trim( (string) $o['domain'] ) && trim( (string) $o['domain'] ) !== self::DEF_DOMAIN ) || trim( (string) $o['email'] ) );
	}

	/** Replace brand words inside plain text. */
	public static function t( $s ) {
		if ( ! is_string( $s ) || '' === $s ) {
			return $s;
		}
		$p = self::pairs();
		if ( $p ) {
			$s = strtr( $s, $p );
		}
		foreach ( self::$ci as $a => $b ) {
			$s = preg_replace_callback( '/(?<![\p{L}\p{N}])' . preg_quote( $a, '/' ) . '(?![\p{L}\p{N}])/iu', function ( $m ) use ( $b ) {
				$w = $m[0];
				if ( $w === mb_strtoupper( $w ) && mb_strlen( $w ) > 1 ) {
					return mb_strtoupper( $b );
				}
				if ( $w === mb_strtolower( $w ) ) {
					return mb_strtolower( $b );
				}
				return $b;
			}, $s );
		}
		$o = self::get();
		$d = trim( (string) $o['domain'] );
		if ( $d && self::DEF_DOMAIN !== $d ) {
			// words only, never inside an address such as https://test.myrishta.pk/
			$s = preg_replace( '#(?<![/.\w-])(www\.)?' . preg_quote( self::DEF_DOMAIN, '#' ) . '(?![\w-])#i', '$1' . $d, $s );
			$s = preg_replace( '#@' . preg_quote( self::DEF_DOMAIN, '#' ) . '#i', '@' . $d, $s );
		}
		$e = trim( (string) $o['email'] );
		if ( $e && is_email( $e ) ) {
			$s = preg_replace( '#[A-Za-z0-9._%+-]+@' . preg_quote( self::DEF_DOMAIN, '#' ) . '#i', $e, $s );
		}
		return $s;
	}

	/** Same replacements for the phone-app files (JavaScript strings), with quotes made safe. */
	public static function t_js( $s ) {
		self::pairs();
		$keep = self::$pairs;
		$ci   = self::$ci;
		$esc = function ( $v ) { return substr( wp_json_encode( (string) $v, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ), 1, -1 ); };
		self::$pairs = array_map( $esc, self::$pairs );
		self::$ci    = array_map( $esc, self::$ci );
		$out         = self::t( $s );
		self::$pairs = $keep;
		self::$ci    = $ci;
		return $out;
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 26 );
		add_action( 'admin_post_mrsh_brand_save', array( __CLASS__, 'save' ) );
		add_action( 'init', array( __CLASS__, 'start' ), 0 );
		add_filter( 'wp_mail', array( __CLASS__, 'mail' ), 5 );
		add_filter( 'pre_get_document_title', array( __CLASS__, 'title' ), 999 );
		add_filter( 'admin_menu', array( __CLASS__, 'menu_labels' ), 999 );
		add_action( 'admin_init', array( __CLASS__, 'admin_buffer' ), 1 );
	}

	/* ---------- output rewriting ---------- */

	public static function start() {
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ! self::active() || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
			return;
		}
		ob_start( array( __CLASS__, 'filter' ) );
	}

	public static function admin_buffer() {
		if ( ! self::active() || ! self::get( 'admin' ) || wp_doing_ajax() ) {
			return;
		}
		$pg = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore
		if ( 0 === strpos( $pg, 'mrsh' ) || 0 === strpos( $pg, 'myrishta' ) ) {
			ob_start( array( __CLASS__, 'filter' ) );
		}
	}

	public static function filter( $html ) {
		if ( '' === $html || strlen( $html ) > 6000000 ) {
			return $html;
		}
		$type = '';
		foreach ( headers_list() as $h ) {
			if ( 0 === stripos( $h, 'content-type:' ) ) {
				$type = strtolower( $h );
			}
		}
		if ( false !== strpos( $type, 'javascript' ) || false !== strpos( $type, 'css' ) || false !== strpos( $type, 'image' ) || false !== strpos( $type, 'xml' ) || false !== strpos( $type, 'zip' ) || false !== strpos( $type, 'pdf' ) ) {
			return $html;
		}
		if ( false !== strpos( $type, 'json' ) ) {
			return self::t( $html ); // manifest and similar: names only
		}
		if ( false === strpos( $html, '<' ) ) {
			return $html;
		}
		// Text between tags, and a few attributes people read. Scripts and styles are left alone, except JSON-LD.
		$parts = preg_split( '#(<script\b[^>]*>.*?</script>|<style\b[^>]*>.*?</style>)#is', $html, -1, PREG_SPLIT_DELIM_CAPTURE );
		foreach ( $parts as $i => $part ) {
			if ( 1 === $i % 2 ) {
				if ( preg_match( '#^<script\b[^>]*type=["\']application/ld\+json#i', $part ) ) {
					$parts[ $i ] = self::t( $part );
				}
				continue;
			}
			$part = preg_replace_callback( '#>([^<>]+)<#', function ( $m ) { return '>' . self::t( $m[1] ) . '<'; }, $part );
			$part = preg_replace_callback( '#\b(title|alt|placeholder|aria-label|data-title|data-n)=("|\')(.*?)\2#is', function ( $m ) { return $m[1] . '=' . $m[2] . self::t( $m[3] ) . $m[2]; }, $part );
			$part = preg_replace_callback( '#<meta\b[^>]*>#i', function ( $m ) {
				if ( preg_match( '#(name|property)=["\'](description|og:[a-z_:]+|twitter:[a-z_:]+|application-name|apple-mobile-web-app-title)["\']#i', $m[0] ) ) {
					return preg_replace_callback( '#\bcontent=("|\')(.*?)\1#is', function ( $c ) { return 'content=' . $c[1] . self::t( $c[2] ) . $c[1]; }, $m[0] );
				}
				return $m[0];
			}, $part );
			$parts[ $i ] = $part;
		}
		return implode( '', $parts );
	}

	public static function title( $t ) {
		return $t;
	}

	public static function mail( $a ) {
		if ( self::active() && is_array( $a ) ) {
			foreach ( array( 'subject', 'message' ) as $k ) {
				if ( isset( $a[ $k ] ) && is_string( $a[ $k ] ) ) {
					$a[ $k ] = self::t( $a[ $k ] );
				}
			}
			if ( ! empty( $a['headers'] ) ) {
				$a['headers'] = is_array( $a['headers'] ) ? array_map( array( __CLASS__, 't' ), $a['headers'] ) : self::t( $a['headers'] );
			}
		}
		return $a;
	}

	public static function menu_labels() {
		global $menu, $submenu;
		if ( ! self::active() || ! is_array( $menu ) ) {
			return;
		}
		foreach ( $menu as $k => $m ) {
			if ( isset( $m[2] ) && ( 0 === strpos( (string) $m[2], 'myrishta' ) || 0 === strpos( (string) $m[2], 'mrsh' ) ) ) {
				$menu[ $k ][0] = self::t( $m[0] );
			}
		}
	}

	/* ---------- admin page ---------- */

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Brand and names', 'Brand and names', 'manage_options', 'mrsh-brand', array( __CLASS__, 'page' ) );
	}

	public static function page() {
		$o = self::get();
		echo '<div class="wrap"><h1>Brand and names</h1><p class="description" style="max-width:760px">Use this page to run the same website for another name, country or city. Visitors, e-mails, the phone app and search results then show your words. Nothing is changed in the database, so you can switch back at any time.</p>';
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success is-dismissible"><p>Saved. Clear your cache plugin (LiteSpeed) and refresh the site.</p></div>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_brand_save">';
		wp_nonce_field( 'mrsh_brand_save' );
		echo '<table class="form-table"><tbody>';
		$row = function ( $k, $l, $help, $ph = '' ) use ( $o ) {
			echo '<tr><th><label for="b_' . esc_attr( $k ) . '">' . esc_html( $l ) . '</label></th><td><input type="text" class="regular-text" id="b_' . esc_attr( $k ) . '" name="' . esc_attr( $k ) . '" value="' . esc_attr( (string) $o[ $k ] ) . '" placeholder="' . esc_attr( $ph ) . '"><p class="description">' . esc_html( $help ) . '</p></td></tr>';
		};
		$row( 'name', 'Full site name', 'Replaces "' . self::DEF_NAME . '" everywhere visitors read it.', self::DEF_NAME );
		$row( 'short', 'Short name', 'Replaces "' . self::DEF_SHORT . '" (and "MyRishta" without the space).', self::DEF_SHORT );
		$row( 'domain', 'Domain name (words only)', 'Replaces "' . self::DEF_DOMAIN . '" when it is written as text, such as in e-mail footers. Web addresses are never changed.', self::DEF_DOMAIN );
		$row( 'email', 'Support e-mail', 'Replaces every @' . self::DEF_DOMAIN . ' e-mail address in the text.', 'info@yourdomain.com' );
		echo '<tr><th><label for="b_pairs">Other words to replace</label></th><td><textarea id="b_pairs" name="pairs" rows="9" class="large-text code" placeholder="Pakistan => Bangladesh&#10;Pakistani => Bangladeshi&#10;Lahore => Dhaka&#10;Rishta => Matrimony">' . esc_textarea( (string) $o['pairs'] ) . '</textarea><p class="description">One change per line, written as <code>old => new</code>. Capital letters must match. Longer words are applied first, so write "Pakistani" as its own line if you also change "Pakistan".</p></td></tr>';
		echo '<tr><th>Match capital and small letters</th><td><label><input type="checkbox" name="ci" value="1"' . checked( ! empty( $o['ci'] ), true, false ) . '> Treat "rishta", "Rishta" and "RISHTA" as the same word (the new word follows the same style)</label></td></tr>';
		echo '<tr><th>Also in these admin pages</th><td><label><input type="checkbox" name="admin" value="1"' . checked( ! empty( $o['admin'] ), true, false ) . '> Show the new names inside the My Rishta admin pages and menu</label></td></tr>';
		$st = (array) get_option( 'mrsh_site', array() );
		echo '</tbody></table><h2>Logo, colours and contact</h2><table class="form-table"><tbody>';
		echo '<tr><th><label for="s_logo">Logo</label></th><td><input type="url" class="regular-text" id="s_logo" name="s_logo" value="' . esc_attr( (string) ( $st['logo'] ?? '' ) ) . '" placeholder="https://"> <button type="button" class="button" id="s_logo_pick">Choose from Media Library</button><p class="description">A small square image works best. Shown in the header, the e-mails and the phone app.</p></td></tr>';
		echo '<tr><th><label for="s_brand">Name beside the logo</label></th><td><input type="text" class="regular-text" id="s_brand" name="s_brand" value="' . esc_attr( (string) ( $st['brand'] ?? '' ) ) . '"><p class="description">Leave empty to use the full site name.</p></td></tr>';
		echo '<tr><th>Main colour</th><td><input type="color" name="s_c1" value="' . esc_attr( ! empty( $st['c1'] ) ? $st['c1'] : '#9b1b4b' ) . '"> <label><input type="checkbox" name="s_c_on" value="1"' . checked( ! empty( $st['c1'] ), true, false ) . '> Use my colours</label></td></tr>';
		echo '<tr><th>Second colour</th><td><input type="color" name="s_c2" value="' . esc_attr( ! empty( $st['c2'] ) ? $st['c2'] : '#6e1230' ) . '"></td></tr>';
		foreach ( array( 'phone' => 'Phone', 'whatsapp' => 'WhatsApp number', 'email' => 'Contact e-mail', 'address' => 'Address' ) as $k => $l ) {
			echo '<tr><th><label for="s_' . esc_attr( $k ) . '">' . esc_html( $l ) . '</label></th><td><input type="text" class="regular-text" id="s_' . esc_attr( $k ) . '" name="s_' . esc_attr( $k ) . '" value="' . esc_attr( (string) ( $st[ $k ] ?? '' ) ) . '"></td></tr>';
		}
		echo '</tbody></table><p class="description">More colours, fonts and layout are on the Theme options page.</p><p><button class="button button-primary">Save</button></p></form>';
		wp_enqueue_media();
		echo '<script>jQuery(function($){$("#s_logo_pick").on("click",function(e){e.preventDefault();var f=wp.media({title:"Logo",multiple:false,library:{type:"image"}});f.on("select",function(){$("#s_logo").val(f.state().get("selection").first().toJSON().url)});f.open()})});</script>';
		echo '<h2>Try it</h2><p class="description">This is how a sentence looks after your changes:</p><p style="background:#fff;border:1px solid #ddd;border-radius:12px;padding:12px;max-width:760px">' . esc_html( self::t( 'Welcome to My Rishta Pakistan. Free rishta service in Lahore. Write to info@myrishta.pk or visit myrishta.pk. Join My Rishta today.' ) ) . '</p>';
		echo '<h2>Good to know</h2><ul style="list-style:disc;margin-left:22px"><li>The Urdu translations are separate. They are written for a rishta website, so translate your own words there if you change the country or language.</li><li>The phone-app files in the /app/ folder follow the names on this page.</li><li>For a new website, also set the city list on the Add profile fields.</li></ul></div>';
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_brand_save' );
		$g = function ( $k ) { return isset( $_POST[ $k ] ) ? sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) : ''; }; // phpcs:ignore
		$d = strtolower( preg_replace( '#^https?://#', '', $g( 'domain' ) ) );
		$st = (array) get_option( 'mrsh_site', array() );
		$st['logo']     = esc_url_raw( $g( 's_logo' ) );
		$st['brand']    = $g( 's_brand' );
		$on             = ! empty( $_POST['s_c_on'] ); // phpcs:ignore
		$c1             = $g( 's_c1' );
		$c2             = $g( 's_c2' );
		$st['c1']       = ( $on && preg_match( '/^#[0-9a-f]{6}$/i', $c1 ) ) ? $c1 : '';
		$st['c2']       = ( $on && preg_match( '/^#[0-9a-f]{6}$/i', $c2 ) ) ? $c2 : '';
		foreach ( array( 'phone', 'whatsapp', 'address' ) as $k ) {
			$st[ $k ] = $g( 's_' . $k );
		}
		$st['email'] = is_email( $g( 's_email' ) ) ? $g( 's_email' ) : '';
		update_option( 'mrsh_site', $st, false );
		update_option( 'mrsh_brand', array(
			'name' => $g( 'name' ) ?: self::DEF_NAME, 'short' => $g( 'short' ) ?: self::DEF_SHORT, 'domain' => trim( $d, '/ ' ) ?: self::DEF_DOMAIN,
			'email' => is_email( $g( 'email' ) ) ? $g( 'email' ) : '', 'pairs' => sanitize_textarea_field( wp_unslash( $_POST['pairs'] ?? '' ) ), // phpcs:ignore
			'admin' => empty( $_POST['admin'] ) ? 0 : 1, 'ci' => empty( $_POST['ci'] ) ? 0 : 1,
		), false );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-brand&ok=1' ) );
		exit;
	}
}
MRSH_Names::init();
