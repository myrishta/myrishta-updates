<?php
/**
 * Tidy WordPress sidebar: custom post type menus go into "Site content", other plugin menus into "Plugins and tools",
 * MyRishta Ads becomes a tab under Site settings. Nothing is removed; pages keep their addresses. Switch off in Site Settings > Look.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Menu {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'tidy' ), 10000 );
		add_action( 'admin_head', function () {
			echo '<style>#adminmenu .wp-menu-separator{display:none}#adminmenu li.menu-top{margin-bottom:0}</style>';
		} );
	}

	private static function core() {
		return array( 'index.php', 'upload.php', 'edit.php', 'edit.php?post_type=page', 'edit-comments.php', 'themes.php', 'plugins.php', 'users.php', 'tools.php', 'options-general.php', 'myrishta-seo', 'mrsh-content', 'mrsh-plugins', 'profile.php' );
	}

	private static function link( $slug ) {
		return ( false !== strpos( $slug, '.php' ) ) ? $slug : 'admin.php?page=' . $slug;
	}

	public static function tidy() {
		if ( class_exists( 'MRSH_Site' ) && ! MRSH_Site::get( 'tidy_menu' ) ) {
			return;
		}
		global $menu, $submenu;
		if ( ! is_array( $menu ) ) {
			return;
		}
		$content = array();
		$plugins = array();
		foreach ( $menu as $k => $m ) {
			$slug = isset( $m[2] ) ? $m[2] : '';
			$name = trim( wp_strip_all_tags( preg_replace( '#<span.*?</span>#s', '', (string) $m[0] ) ) );
			if ( '' === $slug || '' === $name || 0 === strpos( $slug, 'separator' ) || in_array( $slug, self::core(), true ) || ! current_user_can( $m[1] ) ) {
				continue;
			}
			if ( 'myrishta-ads' === $slug ) {
				unset( $menu[ $k ] ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
				continue;
			}
			if ( 0 === strpos( $slug, 'edit.php?post_type=' ) ) {
				$content[] = array( $name, $m[1], $slug );
			} else {
				$first = $slug;
				if ( ! empty( $submenu[ $slug ][0][2] ) ) {
					$first = $submenu[ $slug ][0][2];
				}
				$plugins[] = array( $name, $m[1], self::link( $first ) );
			}
			unset( $menu[ $k ] ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		}
		self::group( 'mrsh-content', 'Site content', ( class_exists( 'MRSH_Tabs' ) ? MRSH_Tabs::menu_icon( 'layout' ) : 'dashicons-portfolio' ), 26, $content );
		self::group( 'mrsh-plugins', 'Plugins and tools', ( class_exists( 'MRSH_Tabs' ) ? MRSH_Tabs::menu_icon( 'plug' ) : 'dashicons-admin-generic' ), 99, $plugins );
	}

	private static function group( $slug, $title, $icon, $pos, $items ) {
		global $submenu;
		if ( ! $items ) {
			return;
		}
		add_menu_page( $title, $title, 'read', $slug, function () use ( $title, $items ) {
			echo '<div class="wrap"><h1>' . esc_html( $title ) . '</h1><ul style="list-style:disc;margin-left:20px">';
			foreach ( $items as $it ) {
				echo '<li><a href="' . esc_url( admin_url( $it[2] ) ) . '">' . esc_html( $it[0] ) . '</a></li>';
			}
			echo '</ul></div>';
		}, $icon, $pos );
		$submenu[ $slug ] = array(); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		foreach ( $items as $it ) {
			$submenu[ $slug ][] = array( $it[0], $it[1], $it[2] ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		}
	}
}
MRSH_Menu::init();
