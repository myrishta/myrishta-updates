<?php
/**
 * Ticket Concierge: the robot that looks after every new support ticket so the owner does not have to.
 *
 *  1. Package requests ("I want Gold / Silver / Bronze", also in Urdu): when the plans are free (launch offer),
 *     it finds the member, gives the package for the launch period and writes back. When the plans are not free,
 *     or the message is about money paid, it never assigns anything: the ticket goes to a human.
 *  2. Normal questions: the AI answer job (MRSH_AIJobs) replies to simple, safe topics.
 *  3. Everything it cannot or should not handle: status becomes "In progress", the member gets a clear message
 *     "waiting for a human reply", and the ticket stays in the owner's list with a note why.
 * Every step is written in the ticket thread. Nothing is deleted. Works without AI (package requests and the
 * "waiting for a human" notice need no AI).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Concierge {

	const DONE = 'mrsh_conc_done';
	const STAT = 'mrsh_conc_stat';
	const MIN  = 60;  // default: profile completeness (percent) the robot needs before it gives a package (Gold and others).
	const MIN_SILVER = 50; // Silver needs only this much.

	/** Completeness needed for a plan: Silver 50%, Gold and every other plan 60%. */
	public static function min_for( $plan ) {
		return 0 === strcasecmp( trim( (string) $plan ), 'Silver' ) ? self::MIN_SILVER : self::MIN;
	}

	const DAYS = 180; // length of a free launch package

	public static function init() {
		if ( class_exists( 'MRSH_Switch' ) && ! MRSH_Switch::on( 'concierge' ) ) {
			return;
		}
		if ( class_exists( 'MRSH_Tickets' ) ) {
			add_action( MRSH_Tickets::CRON, array( __CLASS__, 'tick' ), 30 );
		}
	}

	private static function mail( $to, $subject, $body ) {
		$hdr = array( 'Auto-Submitted: auto-generated' );
		if ( class_exists( 'MRSH_Mailq' ) ) {
			return (bool) MRSH_Mailq::add( $to, $subject, $body, array( 'kind' => 'ticket_ai', 'headers' => $hdr ) );
		}
		return wp_mail( $to, $subject, $body, $hdr );
	}

	private static function stat( $k ) {
		$s = get_option( self::STAT, array() );
		$s = is_array( $s ) ? $s : array();
		$s[ $k ] = (int) ( $s[ $k ] ?? 0 ) + 1;
		update_option( self::STAT, $s, false );
	}

	public static function stats() {
		$s = get_option( self::STAT, array() );
		return array_merge( array( 'plan' => 0, 'human' => 0 ), is_array( $s ) ? $s : array() );
	}

	/** Which package does the text ask for? Returns the plan index, or -1 when none is named, or -2 when it asks about packages without naming one. */
	private static function wanted_plan( $text, $plans ) {
		$t   = mb_strtolower( $text );
		$map = array( 'گولڈ' => 'gold', 'گولڈن' => 'gold', 'سلور' => 'silver', 'برونز' => 'bronze', 'مفت' => 'free' );
		foreach ( $map as $ur => $en ) {
			$t = str_replace( $ur, $en, $t );
		}
		$ask = preg_match( '/\b(want|need|give|upgrade|activate|apply|request|interested|chahiye|chahiyey|chahye|chahta|chahti|dein|dain|karen|kar do|laga|lagao|assign)\b|چاہیے|چاہئے|دیں|اپگریڈ|لگا|کر دیں|کریں/iu', $t );
		$hit = -1;
		foreach ( $plans as $i => $p ) {
			if ( 0 === $i ) {
				continue; // Free is what everybody already has
			}
			if ( preg_match( '/\b' . preg_quote( mb_strtolower( $p[0] ), '/' ) . '\b/u', $t ) ) {
				$hit = max( $hit, $i );
			}
		}
		if ( $hit > 0 && $ask ) {
			return $hit;
		}
		if ( preg_match( '/\b(package|packages|membership|plan|plans|premium|vip)\b|پیکج|ممبرشپ|پلان/iu', $t ) && $ask ) {
			return -2;
		}
		return -1;
	}

	private static function is_free( $plans, $i ) {
		if ( get_option( 'mrsh_plans_free', 0 ) ) {
			return true;
		}
		return 0 === $i || (bool) preg_match( '/^(free|0|rs\.?\s*0)$/i', trim( (string) $plans[ $i ][1] ) );
	}

	/** Members who pressed "ask for a package" in My account (no ticket). Free plans: give it when the profile is complete enough, otherwise say what is missing once. Paid plans stay for a person. */
	public static function plan_requests() {
		if ( ! function_exists( 'mrt_plans' ) || ( class_exists( 'MRSH_Autopilot' ) && ! MRSH_Autopilot::can( 'packages' ) ) ) {
			return;
		}
		$plans = mrt_plans();
		$users = get_users( array( 'meta_key' => 'mrt_plan_req', 'meta_compare' => '!=', 'meta_value' => '', 'number' => 20, 'fields' => 'all' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		foreach ( (array) $users as $u ) {
			$req = trim( (string) get_user_meta( $u->ID, 'mrt_plan_req', true ) );
			$i   = -1;
			foreach ( $plans as $k => $p ) {
				if ( 0 === strcasecmp( $p[0], $req ) ) {
					$i = (int) $k;
				}
			}
			if ( $i < 0 ) {
				continue;
			}
			$pn   = $plans[ $i ][0];
			$name = $u->display_name ? $u->display_name : $u->user_login;
			$sig  = "\n\n--\nMy Rishta Pakistan Support (automatic assistant)\nمائی رشتہ پاکستان سپورٹ (خودکار معاون)";
			if ( 0 === strcasecmp( (string) get_user_meta( $u->ID, 'mrt_plan', true ), $pn ) ) {
				delete_user_meta( $u->ID, 'mrt_plan_req' );
				if ( class_exists( 'MRSH_Attn' ) ) {
					MRSH_Attn::close( 'planreq', $u->ID );
				}
				continue;
			}
			if ( ! self::is_free( $plans, $i ) ) {
				continue; // paid: a person checks the payment
			}
			$pc = self::profile_pct( $u->ID );
			$need = self::min_for( $pn );
			if ( $pc[0] < $need ) {
				if ( get_user_meta( $u->ID, 'mrsh_pr_held', true ) !== md5( $pn ) ) {
					$mi = array();
					foreach ( array_slice( (array) $pc[1], 0, 6 ) as $m1 ) {
						$mi[] = is_array( $m1 ) ? (string) reset( $m1 ) : (string) $m1;
					}
					$miss = $mi ? implode( ', ', $mi ) : 'the empty fields';
					$msg  = "Thank you for asking for the " . $pn . " package. We give packages to profiles that are at least " . $need . "% complete, so that other members see real, useful profiles. Yours is " . (int) $pc[0] . "% complete. Please add: " . $miss . ". Open My account, update your profile, and the package is given automatically within minutes.\n\nآپ کی " . $pn . " پیکج کی درخواست کا شکریہ۔ ہم پیکج ان پروفائلز کو دیتے ہیں جو کم از کم " . $need . " فیصد مکمل ہوں۔ آپ کا پروفائل " . (int) $pc[0] . " فیصد مکمل ہے۔ براہ کرم پروفائل مکمل کریں، پیکج خود بخود دے دیا جائے گا۔";
					self::mail( $u->user_email, 'Your ' . $pn . ' package request - My Rishta Pakistan', "Hello " . $name . ",\n\n" . $msg . $sig );
					update_user_meta( $u->ID, 'mrsh_pr_held', md5( $pn ) );
					if ( class_exists( 'MRSH_Autopilot' ) ) {
						MRSH_Autopilot::log( 'Packages', 'Held a ' . $pn . ' request: profile ' . (int) $pc[0] . '% complete. Told the member.' );
					}
				}
				if ( class_exists( 'MRSH_Attn' ) ) {
					MRSH_Attn::close( 'planreq', $u->ID ); // the robot is handling it; it will give the package when the profile is ready
				}
				continue;
			}
			$exp = time() + self::DAYS * DAY_IN_SECONDS;
			update_user_meta( $u->ID, 'mrt_plan', $pn );
			update_user_meta( $u->ID, 'mrt_plan_exp', $exp );
			delete_user_meta( $u->ID, 'mrt_plan_req' );
			delete_user_meta( $u->ID, 'mrsh_pr_held' );
			$until = wp_date( 'j M Y', $exp );
			$msg   = "Done. Your account now has the " . $pn . " package, free as part of our launch offer, until " . $until . ". You can see it in My account.\n\nہو گیا۔ آپ کے اکاؤنٹ میں اب " . $pn . " پیکج ہے، جو ہماری لانچ آفر کے تحت مفت ہے، " . $until . " تک۔ آپ اسے My account میں دیکھ سکتے ہیں۔";
			self::mail( $u->user_email, 'Your ' . $pn . ' package is ready - My Rishta Pakistan', "Hello " . $name . ",\n\n" . $msg . $sig );
			self::stat( 'plan' );
			if ( class_exists( 'MRSH_Attn' ) ) {
				MRSH_Attn::close( 'planreq', $u->ID );
			}
			if ( class_exists( 'MRSH_Autopilot' ) ) {
				MRSH_Autopilot::log( 'Packages', 'Gave the ' . $pn . ' package to ' . $name . ' (free launch offer).' );
			}
		}
	}

	public static function tick() {
		if ( ! class_exists( 'MRSH_Tickets' ) ) {
			return;
		}
		self::plan_requests();
		global $wpdb;
		$done = get_option( self::DONE, array() );
		$done = is_array( $done ) ? $done : array();
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . MRSH_Tickets::t1() . " WHERE status='open' AND ( answered=0 OR updated > answered ) AND created < %d AND created > %d ORDER BY id ASC LIMIT 15", time() - 30, time() - 14 * DAY_IN_SECONDS ) ); // phpcs:ignore WordPress.DB
		$plans = function_exists( 'mrt_plans' ) ? mrt_plans() : array();
		foreach ( (array) $rows as $t ) {
			if ( isset( $done[ $t->id ] ) ) {
				continue;
			}
			$first = (string) $wpdb->get_var( $wpdb->prepare( 'SELECT body FROM ' . MRSH_Tickets::t2() . " WHERE ticket_id=%d AND who='user' ORDER BY id ASC LIMIT 1", $t->id ) ); // phpcs:ignore WordPress.DB
			$text  = mb_substr( wp_strip_all_tags( $first ), 0, 1500 );
			if ( '' === trim( $text ) ) {
				continue;
			}
			$full = $t->subject . "\n" . $text;
			$i    = $plans ? self::wanted_plan( $full, $plans ) : -1;
			if ( -1 !== $i && ( ! class_exists( 'MRSH_Autopilot' ) || MRSH_Autopilot::can( 'packages' ) ) && ! preg_match( '/price|cost|how much|fees?|charges?|kitn[ae]|قیمت|فیس|refund|paid|payment sent|screenshot|receipt|deposit|transfer(red)?|bank|jazzcash|easypaisa|fraud|scam|police|ادا|رسید|پیسے/iu', $full ) ) {
				$r = self::plan_flow( $t, $i, $plans );
				if ( $r && 'hold' !== $r ) { // 'hold' = told the member to complete the profile; look again when they reply.
					$done[ $t->id ] = time();
				}
			}
		}
		update_option( self::DONE, array_slice( $done, -500, null, true ), false );
		// Normal questions: the AI answer job does the simple, safe ones.
		if ( class_exists( 'MRSH_AIJobs' ) && class_exists( 'MRSH_AIHub' ) && MRSH_AIHub::ready() && MRSH_AIHub::o()['reply'] ) {
			MRSH_AIJobs::run_job( 'reply', false );
		}
		self::human_notice( $done );
	}

	/** array( percent, missing fields ) for the member's profile; 0 when there is no profile yet. */
	public static function profile_pct( $uid ) {
		$ps = get_posts( array( 'post_type' => 'listing_type', 'post_status' => array( 'publish', 'draft', 'pending' ), 'author' => (int) $uid, 'numberposts' => 1, 'suppress_filters' => true ) );
		if ( ! $ps || ! class_exists( 'MRSH_Members' ) ) {
			return array( 0, array() );
		}
		$c = MRSH_Members::completeness( $ps[0] );
		return array( (int) ( $c[0] ?? 0 ), (array) ( $c[1] ?? array() ) );
	}

	/** A package request. Returns true when the ticket was dealt with here. */
	private static function plan_flow( $t, $i, $plans ) {
		global $wpdb;
		$uid = (int) $t->user_id;
		if ( ! $uid && is_email( $t->email ) ) {
			$u   = get_user_by( 'email', $t->email );
			$uid = $u ? (int) $u->ID : 0;
		}
		$code = MRSH_Tickets::code( (int) $t->id );
		$name = $t->name ?: '';
		$sub  = '[' . $code . '] Re: ' . $t->subject;
		$sig  = "\n\n--\nMy Rishta Pakistan Support (automatic assistant)\nمائی رشتہ پاکستان سپورٹ (خودکار معاون)";
		if ( -2 === $i ) { // asks about packages but names none
			$list = array();
			foreach ( $plans as $k => $p ) {
				$list[] = $p[0];
			}
			$msg = "Thank you for your message. We have these packages: " . implode( ', ', $list ) . ". Please reply with the name of the one you want (for example Gold) and we will set it up.\n\nآپ کے پیغام کا شکریہ۔ ہمارے پیکجز: " . implode( '، ', $list ) . "۔ براہ کرم جواب میں اس پیکج کا نام لکھیں جو آپ چاہتے ہیں (مثلاً Gold)، ہم لگا دیں گے۔";
			MRSH_Tickets::add_msg( (int) $t->id, 'staff', $msg );
			MRSH_Tickets::add_msg( (int) $t->id, 'system', 'Concierge: the member asked about packages without naming one; asked which. Waiting for the member.' );
			$wpdb->update( MRSH_Tickets::t1(), array( 'status' => 'waiting', 'answered' => time() ), array( 'id' => (int) $t->id ) ); // phpcs:ignore WordPress.DB
			self::mail( $t->email, $sub, "Hello " . $name . ",\n\n" . $msg . $sig );
			return true;
		}
		$pn = $plans[ $i ][0];
		if ( class_exists( 'MRSH_Orders' ) && $uid ) {
			MRSH_Orders::open( $uid, $pn, 'ticket' );
		}
		if ( ! self::is_free( $plans, $i ) ) {
			return false; // paid plans are never given by the robot: human notice follows
		}
		if ( ! $uid ) {
			$msg = "Thank you for asking for the " . $pn . " package. We could not find an account with this email address. Please sign up or log in at " . home_url( '/register/' ) . " with " . $t->email . " and reply here, and we will set it up.\n\n" . $pn . " پیکج مانگنے کا شکریہ۔ اس ای میل سے ہمیں کوئی اکاؤنٹ نہیں ملا۔ براہ کرم " . home_url( '/register/' ) . " پر اسی ای میل سے سائن اپ یا لاگ ان کریں اور یہاں جواب دیں، ہم پیکج لگا دیں گے۔";
			MRSH_Tickets::add_msg( (int) $t->id, 'staff', $msg );
			MRSH_Tickets::add_msg( (int) $t->id, 'system', 'Concierge: package request, but no account with this email. Asked the member to sign up. Waiting for the member.' );
			$wpdb->update( MRSH_Tickets::t1(), array( 'status' => 'waiting', 'answered' => time() ), array( 'id' => (int) $t->id ) ); // phpcs:ignore WordPress.DB
			self::mail( $t->email, $sub, "Hello " . $name . ",\n\n" . $msg . $sig );
			return true;
		}
		if ( 0 === strcasecmp( (string) get_user_meta( $uid, 'mrt_plan', true ), $pn ) ) {
			$msg = "Good news: your account already has the " . $pn . " package. You can see it in My account.\n\nخوشخبری: آپ کے اکاؤنٹ میں " . $pn . " پیکج پہلے سے موجود ہے۔ آپ اسے My account میں دیکھ سکتے ہیں۔";
			$note = 'Concierge: the member already had ' . $pn . '. Told them.';
		} elseif ( ( $pc = self::profile_pct( $uid ) ) && $pc[0] < ( $need = self::min_for( $pn ) ) ) {
			$mi = array();
			foreach ( array_slice( (array) $pc[1], 0, 6 ) as $m1 ) {
				$mi[] = is_array( $m1 ) ? (string) reset( $m1 ) : (string) $m1;
			}
			$miss = $mi ? implode( ', ', $mi ) : 'the empty fields';
			$msg  = "Thank you for asking for the " . $pn . " package. We give packages to profiles that are at least " . $need . "% complete, so that other members see real, useful profiles. Yours is " . (int) $pc[0] . "% complete. Please open " . home_url( '/add-listing/' ) . " and fill in more details (for example: " . $miss . "). When it reaches " . $need . "%, reply to this message and we will set up your package.\n\nپیکج ان پروفائلز کو دیا جاتا ہے جو کم از کم " . $need . " فیصد مکمل ہوں۔ آپ کی پروفائل " . (int) $pc[0] . " فیصد مکمل ہے۔ براہ کرم مزید تفصیل بھر دیں، پھر اسی پیغام کا جواب دیں، ہم آپ کا پیکج لگا دیں گے۔";
			$held = true;
			$note = 'Concierge: package ' . $pn . ' NOT given yet: profile is ' . (int) $pc[0] . '% complete (needs ' . $need . '%). Told the member what to fill in.';
			if ( class_exists( 'MRSH_Autopilot' ) ) {
				MRSH_Autopilot::log( 'Packages', 'Held a package on ticket ' . MRSH_Tickets::code( (int) $t->id ) . ': profile only ' . (int) $pc[0] . '% complete.' );
			}
		} else {
			$exp = time() + self::DAYS * DAY_IN_SECONDS;
			update_user_meta( $uid, 'mrt_plan', $pn );
			update_user_meta( $uid, 'mrt_plan_exp', $exp );
			delete_user_meta( $uid, 'mrt_plan_req' );
			$until = wp_date( 'j M Y', $exp );
			$msg   = "Done. Your account now has the " . $pn . " package, free as part of our launch offer, until " . $until . ". You can see it in My account. If something is not showing, reply to this message.\n\nہو گیا۔ آپ کے اکاؤنٹ میں اب " . $pn . " پیکج لگ گیا ہے، ہمارے لانچ آفر کے تحت مفت، " . $until . " تک۔ آپ اسے My account میں دیکھ سکتے ہیں۔ کچھ نظر نہ آئے تو اسی پیغام کا جواب دیں۔";
			$note  = 'Concierge: gave the ' . $pn . ' package to user #' . $uid . ' until ' . $until . ' (launch offer, plans are free).';
			self::stat( 'plan' );
			if ( class_exists( 'MRSH_Autopilot' ) ) {
				MRSH_Autopilot::log( 'Packages', 'Gave a free package on ticket ' . MRSH_Tickets::code( (int) $t->id ) . '.' );
			}
		}
		MRSH_Tickets::add_msg( (int) $t->id, 'staff', $msg );
		MRSH_Tickets::add_msg( (int) $t->id, 'system', $note );
		$wpdb->update( MRSH_Tickets::t1(), array( 'status' => 'waiting', 'answered' => time() ), array( 'id' => (int) $t->id ) ); // phpcs:ignore WordPress.DB
		self::mail( $t->email, $sub, "Hello " . $name . ",\n\n" . $msg . $sig );
		return isset( $held ) ? 'hold' : true;
	}

	/** Tickets the robot could not or should not answer: In progress + a clear message. Sent once per ticket. */
	private static function human_notice( $done ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . MRSH_Tickets::t1() . " WHERE status='open' AND answered=0 AND created < %d AND created > %d ORDER BY id ASC LIMIT 15", time() - 1500, time() - 14 * DAY_IN_SECONDS ) ); // phpcs:ignore WordPress.DB
		$hrs  = max( 1, (int) MRSH_Tickets::get()['hours'] );
		foreach ( (array) $rows as $t ) {
			if ( isset( $done[ $t->id ] ) ) {
				continue;
			}
			$code = MRSH_Tickets::code( (int) $t->id );
			$msg  = "Your request is now in process. This one needs a person to look at it, so it is waiting for a human reply from our team. We will answer within " . $hrs . " hours. You do not need to send it again.\n\nآپ کی درخواست پر کام شروع ہو گیا ہے۔ اس کے لیے ہماری ٹیم کے کسی فرد کا جواب درکار ہے، اس لیے یہ انسانی جواب کے انتظار میں ہے۔ ہم " . $hrs . " گھنٹوں کے اندر جواب دیں گے۔ دوبارہ بھیجنے کی ضرورت نہیں۔";
			MRSH_Tickets::add_msg( (int) $t->id, 'staff', $msg );
			MRSH_Tickets::add_msg( (int) $t->id, 'system', 'Concierge: the robot could not answer this one by itself (or it is about money, safety or a paid package). Set to In progress and told the member it is waiting for a human reply. Please answer it.' );
			$wpdb->update( MRSH_Tickets::t1(), array( 'status' => 'progress' ), array( 'id' => (int) $t->id ) ); // phpcs:ignore WordPress.DB
			self::mail( $t->email, '[' . $code . '] Re: ' . $t->subject, "Hello " . ( $t->name ?: '' ) . ",\n\n" . $msg . "\n\n--\nMy Rishta Pakistan Support (automatic assistant)\nمائی رشتہ پاکستان سپورٹ (خودکار معاون)" );
			$done[ $t->id ] = time();
			self::stat( 'human' );
			if ( class_exists( 'MRSH_Autopilot' ) ) {
				MRSH_Autopilot::log( 'Tickets', 'Ticket ' . MRSH_Tickets::code( (int) $t->id ) . ' is waiting for a human reply.' );
			}
		}
		update_option( self::DONE, array_slice( $done, -500, null, true ), false );
	}
}
MRSH_Concierge::init();
