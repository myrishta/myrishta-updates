<?php
/**
 * Admin e-mail alerts for member activity that did not have one yet: new member, new profile waiting or published,
 * voice introduction waiting, agreement letter printed. (Plan requests, payment proofs, selfie and video checks,
 * verification requests and profile reports already send their own e-mail.) Alerts go to the site admin e-mail
 * (Settings > General). The same alert is never sent twice within a minute.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Notify {

	public static function init() {
		add_action( 'user_register', array( __CLASS__, 'new_user' ), 20 );
		add_action( 'transition_post_status', array( __CLASS__, 'profile' ), 20, 3 );
		add_action( 'mrsh_voice_waiting', array( __CLASS__, 'voice' ) );
		add_action( 'mrsh_agreement_printed', array( __CLASS__, 'agreement' ), 10, 2 );
	}

	public static function send( $subject, $body ) {
		$key = 'mrsh_nt_' . md5( $subject . $body );
		if ( get_transient( $key ) ) {
			return;
		}
		set_transient( $key, 1, MINUTE_IN_SECONDS );
		wp_mail( get_option( 'admin_email' ), '[' . get_bloginfo( 'name' ) . '] ' . $subject, $body );
	}

	public static function new_user( $uid ) {
		$u = get_userdata( $uid );
		if ( ! $u ) {
			return;
		}
		self::send( 'New member: ' . $u->display_name, "A new member joined.\n\nName: " . $u->display_name . "\nEmail: " . $u->user_email . "\n\nOpen: " . admin_url( 'admin.php?page=mrsh-users' ) );
	}

	public static function profile( $new, $old, $post ) {
		if ( ! $post || 'listing_type' !== $post->post_type || $new === $old || ! in_array( $new, array( 'pending', 'pending_approval', 'publish' ), true ) ) {
			return;
		}
		if ( 'publish' === $new && in_array( $old, array( 'pending', 'pending_approval' ), true ) ) {
			return; // approved by the admin: no alert
		}
		$what = 'publish' === $new ? 'A new profile was published' : 'A profile is waiting for your approval';
		self::send( ( 'publish' === $new ? 'New profile: ' : 'Profile to approve: ' ) . $post->post_title, $what . ".\n\nProfile: " . $post->post_title . "\nEdit: " . admin_url( 'post.php?post=' . (int) $post->ID . '&action=edit' ) );
	}

	public static function voice( $uid ) {
		$u = get_userdata( $uid );
		self::send( 'Voice introduction waiting', ( $u ? $u->display_name . ' (' . $u->user_email . ')' : 'A member' ) . " sent a voice introduction.\n\nCheck it: " . admin_url( 'admin.php?page=mrsh-more2' ) );
	}

	public static function agreement( $ref, $uid ) {
		$u = get_userdata( $uid );
		self::send( 'Agreement letter printed: ' . $ref, ( $u ? $u->display_name . ' (' . $u->user_email . ')' : 'A member' ) . " printed an agreement letter.\n\nReference: " . $ref . "\nOpen: " . admin_url( 'admin.php?page=mrsh-agreement&q=' . rawurlencode( $ref ) ) . "\n\nAfter payment is received and the letter is stamped and signed, press Mark stamped." );
	}
}
MRSH_Notify::init();
