<?php
/**
 * Photo Guard: every photo a member adds to a profile is looked at once by a free AI that can see pictures.
 * Nudity, kissing or hugging couples (even drawn), cartoons and AI art instead of a real photo, screenshots, quote posters and
 * violence are taken off the profile at once (kept safe, not deleted), the member is told kindly in Urdu and English, and a ticket
 * opens so the owner can approve or delete with one button. Other doubts (no person, contact details, a child) are only flagged.
 * Free pictures-capable AI only (Gemini, Groq, Mistral, GitHub Models, OpenRouter free models): no new cost. Admin page in the Members hub.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_PhotoGuard {

	const OPT  = 'mrsh_pg';
	const LOG  = 'mrsh_pg_log';
	const CNT  = 'mrsh_pg_cnt';
	const SLUG = 'mrsh-photoguard';
	const META = '_mrsh_pg';

	/** Problems that take a photo off the profile at once, and what the member is told. */
	public static function hide_cats() {
		return array(
			'nudity'   => array( 'Nudity or sexual picture', 'ایسی تصویر جس میں بے پردگی یا غیر اخلاقی منظر ہے' ),
			'intimate' => array( 'Romantic or intimate couple picture', 'رومانوی یا قریبی جوڑے کی تصویر' ),
			'cartoon'  => array( 'Cartoon, drawing or AI art (not a real photo)', 'کارٹون، ڈرائنگ یا اے آئی آرٹ، اصل تصویر نہیں' ),
			'screenshot' => array( 'Screenshot of a phone, app or social media', 'موبائل، ایپ یا سوشل میڈیا کا اسکرین شاٹ' ),
			'meme'     => array( 'Quote, poster or text picture', 'اقتباس، پوسٹر یا لکھائی والی تصویر' ),
			'violence' => array( 'Weapons or violence', 'ہتھیار یا تشدد' ),
		);
	}

	public static function flag_cats() {
		return array(
			'no_person' => 'No person in the picture',
			'contact'   => 'Phone number or social handle visible',
			'child'     => 'Looks like a child',
			'other'     => 'Other doubt',
		);
	}

	public static function defaults() {
		return array( 'on' => 1, 'hide' => 1, 'notify' => 1, 'paid' => 1, 'conf' => 70, 'budget' => 150, 'sweep' => 12 );
	}

	public static function get() {
		$o = get_option( self::OPT, array() );
		return array_merge( self::defaults(), is_array( $o ) ? $o : array() );
	}

	public static function init() {
		add_action( 'add_attachment', array( __CLASS__, 'on_add' ) );
		add_action( 'mrsh_pg_one', array( __CLASS__, 'cron_one' ), 10, 1 );
		add_action( 'mrsh_pg_sweep', array( __CLASS__, 'sweep' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 45 );
		add_action( 'admin_post_mrsh_pg_save', array( __CLASS__, 'act_save' ) );
		add_action( 'admin_post_mrsh_pg_do', array( __CLASS__, 'act_do' ) );
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( 'mrsh_pg_sweep' ) ) {
			wp_schedule_event( time() + 600, 'hourly', 'mrsh_pg_sweep' );
		}
	}

	/* ---------- when a photo arrives ---------- */

	public static function on_add( $aid ) {
		$o = self::get();
		if ( empty( $o['on'] ) || ! wp_attachment_is_image( $aid ) ) {
			return;
		}
		$par = (int) wp_get_post_parent_id( $aid );
		if ( ! $par || 'listing_type' !== get_post_type( $par ) ) {
			return;
		}
		wp_schedule_single_event( time() + 20, 'mrsh_pg_one', array( (int) $aid ) );
	}

	public static function cron_one( $aid ) {
		self::check( (int) $aid, false );
	}

	/** Hourly: looks at photos that were never checked (new ones that missed, then the older ones, a few at a time). */
	public static function sweep() {
		$o = self::get();
		if ( empty( $o['on'] ) ) {
			return;
		}
		foreach ( self::unchecked( max( 1, (int) $o['sweep'] ) ) as $aid ) {
			if ( is_wp_error( self::check( $aid, false ) ) ) {
				break; // no AI answering right now: try again next hour
			}
		}
	}

	/** Photo ids on live profiles that have no verdict yet, newest first. */
	public static function unchecked( $n ) {
		global $wpdb;
		return array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare(
			"SELECT a.ID FROM {$wpdb->posts} a INNER JOIN {$wpdb->posts} p ON p.ID = a.post_parent
			 WHERE a.post_type = 'attachment' AND a.post_mime_type IN ('image/jpeg','image/png','image/webp')
			 AND p.post_type = 'listing_type' AND p.post_status IN ('publish','pending','draft')
			 AND NOT EXISTS (SELECT 1 FROM {$wpdb->postmeta} m WHERE m.post_id = a.ID AND m.meta_key = %s)
			 ORDER BY a.ID DESC LIMIT %d", self::META, (int) $n
		) ) ); // phpcs:ignore WordPress.DB.PreparedSQL
	}

	/* ---------- the check ---------- */

	private static function used_today() {
		$c = get_option( self::CNT, array() );
		return is_array( $c ) && ( $c['d'] ?? '' ) === gmdate( 'Y-m-d' ) ? (int) $c['n'] : 0;
	}

	private static function bump() {
		update_option( self::CNT, array( 'd' => gmdate( 'Y-m-d' ), 'n' => self::used_today() + 1 ), false );
	}

	public static function log( $k, $m ) {
		$l = get_option( self::LOG, array() );
		$l = is_array( $l ) ? $l : array();
		$l[] = array( 't' => time(), 'k' => $k, 'm' => mb_substr( (string) $m, 0, 220 ) );
		update_option( self::LOG, array_slice( $l, -60 ), false );
	}

	/** Checks one photo. Returns the verdict array or a WP_Error (nothing is stored when no AI could answer). */
	public static function check( $aid, $force = false ) {
		$o = self::get();
		if ( ! $aid || ! wp_attachment_is_image( $aid ) ) {
			return new WP_Error( 'img', 'Not an image.' );
		}
		$have = get_post_meta( $aid, self::META, true );
		if ( $have && ! $force ) {
			return $have;
		}
		if ( self::used_today() >= (int) $o['budget'] ) {
			return new WP_Error( 'budget', 'Daily limit of checks reached.' );
		}
		$b64 = self::prepare( $aid );
		if ( '' === $b64 ) {
			return new WP_Error( 'file', 'The picture file could not be read.' );
		}
		$v = self::vision( $b64 );
		if ( is_wp_error( $v ) ) {
			self::log( 'ai', $v->get_error_message() );
			return $v;
		}
		self::bump();
		$cat  = $v['cat'];
		$conf = (int) $v['conf'];
		$hide = self::hide_cats();
		$st   = 'ok';
		if ( 'fine' !== $cat ) {
			if ( isset( $hide[ $cat ] ) && $conf >= (int) $o['conf'] ) {
				$st = 'held';
			} elseif ( 'fine' !== $cat && $conf >= 50 ) {
				$st = 'flag';
			}
		}
		$rec = array( 'state' => $st, 'cat' => $cat, 'conf' => $conf, 'why' => $v['why'], 't' => time() );
		update_post_meta( $aid, self::META, $rec );
		if ( 'held' === $st && ! empty( $o['hide'] ) ) {
			self::hold( $aid, $rec );
		} elseif ( 'held' === $st ) {
			$rec['state'] = 'flag'; // hiding is switched off: only flag it
			update_post_meta( $aid, self::META, $rec );
		}
		return $rec;
	}

	/** A small JPEG (longest side 768 px) as base64, so the AI answers fast and the upload stays small. */
	private static function prepare( $aid ) {
		if ( ! function_exists( 'wp_tempnam' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		if ( ! function_exists( 'wp_crop_image' ) ) {
			require_once ABSPATH . 'wp-admin/includes/image.php';
		}
		$f = get_attached_file( $aid );
		if ( ! $f || ! is_readable( $f ) ) {
			$u = wp_get_attachment_url( $aid );
			if ( ! $u ) {
				return '';
			}
			$r = wp_safe_remote_get( $u, array( 'timeout' => 20 ) );
			if ( is_wp_error( $r ) || 200 !== (int) wp_remote_retrieve_response_code( $r ) ) {
				return '';
			}
			$f = wp_tempnam( 'pg' );
			file_put_contents( $f, wp_remote_retrieve_body( $r ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
			$tmpsrc = $f;
		}
		$out = '';
		$ed  = wp_get_image_editor( $f );
		if ( ! is_wp_error( $ed ) ) {
			$ed->resize( 768, 768, false );
			$tmp = wp_tempnam( 'pgj' );
			$sv  = $ed->save( $tmp . '.jpg', 'image/jpeg' );
			if ( ! is_wp_error( $sv ) && ! empty( $sv['path'] ) && is_readable( $sv['path'] ) ) {
				$out = base64_encode( (string) file_get_contents( $sv['path'] ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				@unlink( $sv['path'] ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
			}
			@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
		}
		if ( isset( $tmpsrc ) ) {
			@unlink( $tmpsrc ); // phpcs:ignore WordPress.PHP.NoSilencedErrors, WordPress.WP.AlternativeFunctions
		}
		return $out;
	}

	private static function prompt() {
		return 'You check profile photos for a Pakistani Muslim matrimonial (rishta) website. Look at the picture and answer with ONE line of JSON only, nothing else: '
			. '{"cat":"fine|nudity|intimate|cartoon|screenshot|meme|violence|no_person|contact|child|other","conf":0-100,"why":"at most 12 words"}. '
			. 'cat meanings: nudity = naked or sexual; intimate = a couple kissing, hugging or touching romantically, even in a drawing; '
			. 'cartoon = a drawing, anime, illustration or AI art instead of a real photograph; screenshot = a capture of a phone, app, chat or social media page; '
			. 'meme = a quote, poster or text laid over a picture; violence = weapons or blood; no_person = no person in it (object, scenery, flower, car); '
			. 'contact = a phone number, email or social media name is readable; child = the main person is a child; '
			. 'fine = a normal real photograph of a person, modest or not. conf = how sure you are, 0 to 100. Be strict and honest.';
	}

	/** Free services that can see pictures, in the order they are tried. */
	private static function vision_chain() {
		$vm = array(
			'gemini'     => '',
			'groq'       => 'meta-llama/llama-4-scout-17b-16e-instruct',
			'mistral'    => 'pixtral-12b-2409',
			'openrouter' => 'google/gemma-3-27b-it:free',
		);
		$out = array();
		foreach ( (array) MRSH_AIHub::chain() as $id => $c ) {
			if ( isset( $vm[ $id ] ) ) {
				$out[ $id ] = $c;
				if ( '' !== $vm[ $id ] ) {
					$out[ $id ]['model'] = $vm[ $id ];
				}
			}
		}
		$o = self::get();
		$a = (array) MRSH_AIHub::chain();
		if ( ! empty( $o['paid'] ) && isset( $a['main'] ) ) {
			$out['main'] = $a['main']; // the paid account answers only when no free service can
		}
		return $out;
	}

	public static function vision_ready() {
		return (bool) self::vision_chain();
	}

	private static function vision( $b64 ) {
		$chain = self::vision_chain();
		if ( ! $chain ) {
			return new WP_Error( 'nokey', 'No free AI with picture reading is set up (Gemini, Groq, Mistral, GitHub Models or OpenRouter key in AI Assistant).' );
		}
		$last = '';
		foreach ( $chain as $id => $c ) {
			if ( 'anthropic' === $c['kind'] ) {
				$url  = 'https://api.anthropic.com/v1/messages';
				$hdr  = array( 'x-api-key' => $c['key'], 'anthropic-version' => '2023-06-01', 'content-type' => 'application/json' );
				$body = array( 'model' => $c['model'], 'max_tokens' => 1500, 'thinking' => array( 'type' => 'disabled' ), 'messages' => array( array( 'role' => 'user', 'content' => array( array( 'type' => 'image', 'source' => array( 'type' => 'base64', 'media_type' => 'image/jpeg', 'data' => $b64 ) ), array( 'type' => 'text', 'text' => self::prompt() ) ) ) ) );
			} elseif ( 'gemini' === $c['kind'] ) {
				$url  = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode( $c['model'] ) . ':generateContent';
				$hdr  = array( 'x-goog-api-key' => $c['key'], 'content-type' => 'application/json' );
				$body = array( 'contents' => array( array( 'role' => 'user', 'parts' => array( array( 'text' => self::prompt() ), array( 'inline_data' => array( 'mime_type' => 'image/jpeg', 'data' => $b64 ) ) ) ) ), 'generationConfig' => array( 'maxOutputTokens' => 120, 'temperature' => 0 ) );
			} else {
				$url  = $c['base'] . '/chat/completions';
				$hdr  = array( 'Authorization' => 'Bearer ' . $c['key'], 'content-type' => 'application/json' );
				$body = array( 'model' => $c['model'], 'max_tokens' => 120, 'temperature' => 0, 'messages' => array( array( 'role' => 'user', 'content' => array( array( 'type' => 'text', 'text' => self::prompt() ), array( 'type' => 'image_url', 'image_url' => array( 'url' => 'data:image/jpeg;base64,' . $b64 ) ) ) ) ) );
			}
			$r = wp_remote_post( $url, array( 'timeout' => 35, 'headers' => $hdr, 'body' => wp_json_encode( $body ) ) );
			if ( is_wp_error( $r ) ) {
				$last = $c['label'] . ': ' . $r->get_error_message();
				continue;
			}
			$code = (int) wp_remote_retrieve_response_code( $r );
			$j    = json_decode( wp_remote_retrieve_body( $r ), true );
			if ( 400 === $code && preg_match( '/content_filter|filtered|safety|policy/i', wp_remote_retrieve_body( $r ) ) ) {
				return array( 'cat' => 'other', 'conf' => 60, 'why' => 'The AI safety filter blocked this picture', 'by' => $id );
			}
			if ( $code < 200 || $code >= 300 ) {
				$last = $c['label'] . ' answered HTTP ' . $code;
				continue;
			}
			if ( 'anthropic' === $c['kind'] ) {
				$t = '';
				foreach ( (array) ( $j['content'] ?? array() ) as $blk ) {
					if ( 'text' === ( $blk['type'] ?? '' ) ) {
						$t .= (string) ( $blk['text'] ?? '' );
					}
				}
			} elseif ( 'gemini' === $c['kind'] ) {
				$t = (string) ( $j['candidates'][0]['content']['parts'][0]['text'] ?? '' );
			} else {
				$t = (string) ( $j['choices'][0]['message']['content'] ?? '' );
			}
			$fin = (string) ( $j['choices'][0]['finish_reason'] ?? ( $j['candidates'][0]['finishReason'] ?? '' ) );
			if ( '' === trim( $t ) && preg_match( '/content_filter|SAFETY|PROHIBITED|BLOCKLIST/i', $fin . ' ' . wp_json_encode( $j['promptFeedback'] ?? '' ) ) ) {
				return array( 'cat' => 'other', 'conf' => 60, 'why' => 'The AI safety filter blocked this picture', 'by' => $id );
			}
			$d = self::parse( $t );
			if ( $d ) {
				$d['by'] = $id;
				return $d;
			}
			if ( preg_match( '/can.?t|cannot|unable|sorry|not able|inappropriate|explicit|sexual/i', $t ) ) {
				// the service would not describe the picture: that is itself a warning sign, so flag it for a look
				return array( 'cat' => 'other', 'conf' => 60, 'why' => 'The AI would not describe this picture', 'by' => $id );
			}
			$last = $c['label'] . ' gave an unreadable answer (' . $fin . '): ' . mb_substr( preg_replace( '/\s+/', ' ', '' !== trim( $t ) ? $t : wp_remote_retrieve_body( $r ) ), 0, 200 );
		}
		return new WP_Error( 'ai', $last ? $last : 'No AI answered.' );
	}

	/* ---------- holding, restoring, telling the member ---------- */

	/** Reads the AI answer: JSON (even in a code block or with extra words), or the words cat / conf / why in plain text. */
	private static function parse( $t ) {
		$ok  = array_merge( array( 'fine' ), array_keys( self::hide_cats() ), array_keys( self::flag_cats() ) );
		$cat = '';
		$conf = 70;
		$why = '';
		if ( preg_match( '/\{.*\}/s', $t, $m ) ) {
			$d = json_decode( $m[0], true );
			if ( is_array( $d ) && isset( $d['cat'] ) ) {
				$cat  = strtolower( trim( (string) $d['cat'] ) );
				$conf = (int) ( $d['conf'] ?? 70 );
				$why  = (string) ( $d['why'] ?? '' );
			}
		}
		if ( '' === $cat && preg_match( '/cat\W{1,6}([a-z_]+)/i', $t, $m ) ) {
			$cat = strtolower( $m[1] );
			if ( preg_match( '/conf\W{1,6}(\d{1,3})/i', $t, $n ) ) {
				$conf = (int) $n[1];
			}
			if ( preg_match( '/why\W{1,6}([^\n"}]{3,120})/i', $t, $n ) ) {
				$why = $n[1];
			}
		}
		if ( '' === $cat ) {
			foreach ( $ok as $k ) {
				if ( preg_match( '/\b' . $k . '\b/i', $t ) ) {
					$cat  = $k;
					$conf = 50; // only a guess from plain words: flag, never take off
					break;
				}
			}
		}
		if ( '' === $cat ) {
			return null;
		}
		if ( ! in_array( $cat, $ok, true ) ) {
			$cat = 'other';
		}
		return array( 'cat' => $cat, 'conf' => max( 0, min( 100, $conf ) ), 'why' => mb_substr( sanitize_text_field( $why ), 0, 120 ) );
	}

	/** Takes the photo off the profile. The file stays safe in the library; nothing is deleted. */
	public static function hold( $aid, $rec ) {
		$par = (int) wp_get_post_parent_id( $aid );
		update_post_meta( $aid, '_mrsh_pg_parent', $par );
		if ( $par ) {
			if ( (int) get_post_thumbnail_id( $par ) === (int) $aid ) {
				delete_post_thumbnail( $par );
			}
			foreach ( array( '_mrt_ph', 'image_aid' ) as $k ) {
				if ( (int) get_post_meta( $par, $k, true ) === (int) $aid ) {
					delete_post_meta( $par, $k );
				}
			}
			$u = (string) get_post_meta( $par, 'image', true );
			if ( $u && (int) attachment_url_to_postid( $u ) === (int) $aid ) {
				delete_post_meta( $par, 'image' );
			}
			wp_update_post( array( 'ID' => $aid, 'post_parent' => 0 ) );
			delete_post_meta( $par, '_mrt_ph' );
			// the next picture on the profile (if any good one is left) becomes the main one again
			$next = 0;
			foreach ( get_children( array( 'post_parent' => $par, 'post_type' => 'attachment', 'post_mime_type' => 'image', 'numberposts' => 8, 'orderby' => 'menu_order ID', 'order' => 'ASC' ) ) as $c ) {
				$s = get_post_meta( $c->ID, self::META, true );
				if ( ! is_array( $s ) || 'held' !== ( $s['state'] ?? '' ) ) {
					$next = $c->ID;
					break;
				}
			}
			if ( $next && ! get_post_thumbnail_id( $par ) ) {
				set_post_thumbnail( $par, $next );
			}
		}
		self::log( 'held', '#' . $aid . ' ' . $rec['cat'] . ' (' . $rec['conf'] . '%) ' . $rec['why'] );
		self::tell_member( $aid, $par, $rec );
		self::open_ticket( $aid, $par, $rec );
	}

	public static function restore( $aid ) {
		$par = (int) get_post_meta( $aid, '_mrsh_pg_parent', true );
		$rec = get_post_meta( $aid, self::META, true );
		$rec = is_array( $rec ) ? $rec : array();
		$rec['state'] = 'approved';
		update_post_meta( $aid, self::META, $rec );
		if ( $par && get_post( $par ) ) {
			wp_update_post( array( 'ID' => $aid, 'post_parent' => $par ) );
			if ( ! get_post_thumbnail_id( $par ) ) {
				set_post_thumbnail( $par, $aid );
			}
			delete_post_meta( $par, '_mrt_ph' );
		}
		self::log( 'approved', '#' . $aid . ' put back on the profile.' );
	}

	private static function tell_member( $aid, $par, $rec ) {
		$o = self::get();
		if ( empty( $o['notify'] ) || ! $par ) {
			return;
		}
		$p = get_post( $par );
		$u = $p ? get_userdata( (int) $p->post_author ) : null;
		if ( ! $u || ! is_email( $u->user_email ) || get_transient( 'mrsh_pg_mail_' . $u->ID ) ) {
			return;
		}
		set_transient( 'mrsh_pg_mail_' . $u->ID, 1, DAY_IN_SECONDS );
		$h   = self::hide_cats();
		$why = $h[ $rec['cat'] ] ?? array( '', '' );
		$url = home_url( '/add-listing/' );
		$ur  = "السلام علیکم!\n\nآپ کی ایک تصویر پروفائل پر نہیں دکھائی جا رہی کیونکہ وہ ہمارے اصولوں کے مطابق نہیں:\n" . $why[1] . "\n\nبراہِ کرم اپنی صاف، حقیقی اور شائستہ تصویر لگائیں (چہرہ نظر آئے، اسکرین شاٹ یا کارٹون نہ ہو)۔ ہم تصویر دیکھ کر ہی رشتے آگے بڑھاتے ہیں۔";
		$en  = "One of your photos is not shown on your profile because it does not follow our rules:\n" . $why[0] . "\n\nPlease add a clear, real and modest photo of yourself (face visible, not a screenshot or cartoon). If you think this is a mistake, reply to this email and we will look again.";
		$html = class_exists( 'MRSH_Mem_Mail' ) ? MRSH_Mem_Mail::shell( array(
			'icon' => '📸', 'head' => 'آپ کی تصویر قبول نہیں ہوئی', 'head_en' => 'Your photo was not accepted', 'ur' => $ur, 'en' => $en,
			'btn_ur' => 'نئی تصویر لگائیں', 'link' => $url, 'steps' => false, 'mode' => 'both', 'tone' => 'purple', 'foot' => '',
		) ) : '';
		$subject = 'آپ کی تصویر قبول نہیں ہوئی | Your photo was not accepted';
		$text    = $ur . "\n\n" . $url . "\n\n" . $en . "\n";
		if ( class_exists( 'MRSH_Mailq' ) ) {
			MRSH_Mailq::add( $u->user_email, $subject, $text, array( 'html' => $html, 'kind' => 'photoguard', 'uid' => $u->ID ) );
		} else {
			wp_mail( $u->user_email, $subject, $html ? $html : $text, $html ? array( 'Content-Type: text/html; charset=UTF-8' ) : array() );
		}
	}

	private static function open_ticket( $aid, $par, $rec ) {
		if ( ! class_exists( 'MRSH_Tickets' ) ) {
			return;
		}
		$h = self::hide_cats();
		try {
			MRSH_Tickets::create( 'Photo Guard', get_option( 'admin_email' ), 'Photo held: ' . ( $h[ $rec['cat'] ][0] ?? $rec['cat'] ), "A profile photo was taken off automatically.\nReason: " . ( $h[ $rec['cat'] ][0] ?? $rec['cat'] ) . ' (' . $rec['conf'] . "% sure). " . $rec['why'] . "\nProfile: " . ( $par ? get_edit_post_link( $par, 'raw' ) : '' ) . "\nApprove or delete it here with one button: " . admin_url( 'admin.php?page=' . self::SLUG ), 'photoguard', 'photo' );
		} catch ( \Throwable $e ) { // phpcs:ignore
			self::log( 'ticket', $e->getMessage() );
		}
	}

	/* ---------- admin ---------- */

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Photo Guard', 'Photo Guard', 'manage_options', self::SLUG, array( __CLASS__, 'page' ) );
	}

	private static function back( $msg ) {
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&msg=' . rawurlencode( $msg ) ) );
		exit;
	}

	private static function guard( $a ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'No access.' );
		}
		check_admin_referer( $a );
	}

	public static function act_save() {
		self::guard( 'mrsh_pg_save' );
		$o = array();
		foreach ( array( 'on', 'hide', 'notify', 'paid' ) as $k ) {
			$o[ $k ] = empty( $_POST[ $k ] ) ? 0 : 1; // phpcs:ignore WordPress.Security.NonceVerification
		}
		$o['conf']   = max( 50, min( 95, isset( $_POST['conf'] ) ? absint( $_POST['conf'] ) : 70 ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$o['budget'] = max( 10, min( 1000, isset( $_POST['budget'] ) ? absint( $_POST['budget'] ) : 150 ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$o['sweep']  = max( 1, min( 40, isset( $_POST['sweep'] ) ? absint( $_POST['sweep'] ) : 12 ) ); // phpcs:ignore WordPress.Security.NonceVerification
		update_option( self::OPT, $o, false );
		self::back( 'Saved.' );
	}

	public static function act_do() {
		self::guard( 'mrsh_pg_do' );
		$op  = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( $_POST['op'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$aid = isset( $_POST['aid'] ) ? absint( $_POST['aid'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		if ( 'scan' === $op ) {
			$n = 0;
			$h = 0;
			$err = '';
			foreach ( self::unchecked( 6 ) as $id ) {
				$r = self::check( $id, false );
				if ( is_wp_error( $r ) ) {
					$err = $r->get_error_message();
					break;
				}
				$n++;
				if ( 'held' === $r['state'] ) {
					$h++;
				}
			}
			self::back( $err ? 'Checked ' . $n . '. Stopped: ' . $err : 'Checked ' . $n . ' photo(s), ' . $h . ' taken off. Press again for the next ones.' );
		}
		if ( 'test' === $op ) {
			if ( ! self::vision_ready() ) {
				self::back( 'No free AI with picture reading is set up. Add a Gemini or Groq key in AI Assistant.' );
			}
			$png = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
			$v   = self::vision( $png );
			self::back( is_wp_error( $v ) ? 'The AI did not answer: ' . $v->get_error_message() : 'The AI can read pictures (answered by ' . $v['by'] . ').' );
		}
		if ( 'reset_cnt' === $op ) {
			delete_option( self::CNT );
			self::back( 'Today\'s counter is reset.' );
		}
		if ( ! $aid || ! get_post( $aid ) ) {
			self::back( 'Photo not found.' );
		}
		if ( 'approve' === $op ) {
			self::restore( $aid );
			self::back( 'Approved. The photo is back on the profile.' );
		}
		if ( 'delete' === $op ) {
			wp_delete_attachment( $aid, true );
			self::log( 'deleted', '#' . $aid . ' deleted by the owner.' );
			self::back( 'Deleted for good.' );
		}
		if ( 'recheck' === $op ) {
			$r = self::check( $aid, true );
			self::back( is_wp_error( $r ) ? 'Could not check: ' . $r->get_error_message() : 'Checked again: ' . $r['cat'] . ' (' . $r['conf'] . '%).' );
		}
		if ( 'hold' === $op ) {
			$rec = get_post_meta( $aid, self::META, true );
			$rec = is_array( $rec ) ? $rec : array( 'cat' => 'other', 'conf' => 100, 'why' => 'Taken off by the owner.' );
			$rec['state'] = 'held';
			update_post_meta( $aid, self::META, $rec );
			self::hold( $aid, $rec );
			self::back( 'Taken off the profile.' );
		}
		self::back( 'Nothing to do.' );
	}

	private static function btn( $op, $aid, $label, $cls = 's', $confirm = '' ) {
		return '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline"' . ( $confirm ? ' onsubmit="return confirm(' . esc_attr( wp_json_encode( $confirm ) ) . ')"' : '' ) . '>'
			. '<input type="hidden" name="action" value="mrsh_pg_do"><input type="hidden" name="op" value="' . esc_attr( $op ) . '">' . ( $aid ? '<input type="hidden" name="aid" value="' . (int) $aid . '">' : '' )
			. wp_nonce_field( 'mrsh_pg_do', '_wpnonce', true, false ) . '<button class="mx-btn ' . esc_attr( $cls ) . '" type="submit">' . esc_html( $label ) . '</button></form> ';
	}

	private static function counts() {
		global $wpdb;
		$r = array( 'ok' => 0, 'held' => 0, 'flag' => 0, 'approved' => 0 );
		foreach ( (array) $wpdb->get_col( $wpdb->prepare( "SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s", self::META ) ) as $v ) { // phpcs:ignore WordPress.DB.PreparedSQL
			$m = maybe_unserialize( $v );
			if ( is_array( $m ) && isset( $r[ $m['state'] ?? '' ] ) ) {
				$r[ $m['state'] ]++;
			}
		}
		return $r;
	}

	private static function rows( $states, $n = 40 ) {
		global $wpdb;
		$ids = (array) $wpdb->get_col( $wpdb->prepare( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s ORDER BY post_id DESC LIMIT 400", self::META ) ); // phpcs:ignore WordPress.DB.PreparedSQL
		$out = array();
		foreach ( $ids as $id ) {
			$m = get_post_meta( (int) $id, self::META, true );
			if ( is_array( $m ) && in_array( $m['state'] ?? '', $states, true ) ) {
				$out[ (int) $id ] = $m;
				if ( count( $out ) >= $n ) {
					break;
				}
			}
		}
		return $out;
	}

	private static function table( $rows, $held ) {
		$h = self::hide_cats();
		$f = self::flag_cats();
		echo '<div>';
		foreach ( $rows as $aid => $m ) {
			$par = $held ? (int) get_post_meta( $aid, '_mrsh_pg_parent', true ) : (int) wp_get_post_parent_id( $aid );
			$p   = $par ? get_post( $par ) : null;
			$img = wp_get_attachment_image_url( $aid, 'thumbnail' );
			$cn  = $h[ $m['cat'] ][0] ?? ( $f[ $m['cat'] ] ?? $m['cat'] );
			echo '<div style="display:flex;flex-wrap:wrap;gap:10px 14px;align-items:flex-start;padding:12px 0;border-top:1px solid #eef0f6">';
			echo $img ? '<a href="' . esc_url( wp_get_attachment_url( $aid ) ) . '" target="_blank" rel="noopener" style="flex:0 0 72px"><img src="' . esc_url( $img ) . '" width="72" height="72" style="object-fit:cover;border-radius:12px;display:block" alt=""></a>' : '';
			echo '<div style="flex:1 1 180px;min-width:0"><b>' . esc_html( $cn ) . '</b> <span class="mx-pill ' . ( $held ? 'bad' : 'warn' ) . '">' . (int) $m['conf'] . '% sure</span><div style="color:#667085;font-size:13px;margin:3px 0">' . esc_html( $m['why'] ) . '</div>'
				. ( $p ? '<a href="' . esc_url( get_edit_post_link( $par ) ) . '">' . esc_html( get_the_title( $par ) ) . '</a>' : '<span style="color:#98a2b3">no profile</span>' ) . '</div>';
			echo '<div class="mx-acts" style="flex:1 1 100%">';
			if ( $held ) {
				echo self::btn( 'approve', $aid, 'Approve', 'p' ) . self::btn( 'delete', $aid, 'Delete', 'd', 'Delete this photo for good?' ) . self::btn( 'recheck', $aid, 'Check again', 's' );
			} else {
				echo self::btn( 'hold', $aid, 'Take off', 'd', 'Take this photo off the profile?' ) . self::btn( 'approve', $aid, 'It is fine', 'p' ) . self::btn( 'recheck', $aid, 'Check again', 's' );
			}
			echo '</div></div>';
		}
		if ( ! $rows ) {
			echo '<p style="color:#667085">Nothing here.</p>';
		}
		echo '</div>';
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$o  = self::get();
		$c  = self::counts();
		$un = count( self::unchecked( 500 ) );
		MRSH_Boost::ui_open( 'Photo Guard', 'Every profile photo is looked at once by a free AI. Bad pictures (nudity, kissing couples, cartoons, screenshots, quote posters) are taken off by themselves, the member is told, and you can approve or delete with one button.', 'g-red', 'M12 2 4 5v6c0 5 3.4 9.7 8 11 4.6-1.3 8-6 8-11V5l-8-3zm-1 14-3-3 1.4-1.4L11 13.2l4.6-4.6L17 10l-6 6z' );
		if ( isset( $_GET['msg'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			MRSH_Boost::ui_ok( sanitize_text_field( wp_unslash( $_GET['msg'] ) ) );
		}
		echo '<div class="mx-card"><div class="mx-acts">';
		echo '<span class="mx-pill ' . ( $o['on'] ? 'ok' : 'bad' ) . '">Guard: ' . ( $o['on'] ? 'on' : 'off' ) . '</span> ';
		echo '<span class="mx-pill ' . ( self::vision_ready() ? 'ok' : 'bad' ) . '">Picture AI: ' . ( self::vision_ready() ? 'ready' : 'no key' ) . '</span> ';
		echo '<span class="mx-pill ' . ( $o['hide'] ? 'ok' : 'warn' ) . '">' . ( $o['hide'] ? 'Takes bad photos off by itself' : 'Only flags, does not take off' ) . '</span> ';
		echo '</div><div class="mx-acts" style="margin-top:12px">' . self::btn( 'scan', 0, 'Check the next 6 old photos now', 'p' ) . self::btn( 'test', 0, 'Test the AI', 's' ) . self::btn( 'reset_cnt', 0, 'Reset today\'s counter', 's' ) . '</div></div>';
		echo '<div class="mx-stats">'
			. MRSH_Boost::ui_stat( $c['held'], 'Taken off', '#dc2626' ) . MRSH_Boost::ui_stat( $c['flag'], 'To look at', '#f59e0b' ) . MRSH_Boost::ui_stat( $c['ok'] + $c['approved'], 'Fine', '#16a34a' ) . MRSH_Boost::ui_stat( $un, 'Not checked yet', '#6366f1' ) . MRSH_Boost::ui_stat( self::used_today() . '/' . (int) $o['budget'], 'AI checks today', '#7c3aed' )
			. '</div>';
		echo '<div class="mx-card"><div class="mx-h"><h2>Taken off by the guard</h2></div><p class="mx-sub">These photos are not on the profile. Press Approve if the guard was wrong.</p>';
		self::table( self::rows( array( 'held' ) ), true );
		echo '</div>';
		echo '<div class="mx-card"><div class="mx-h"><h2>Flagged, still showing</h2></div><p class="mx-sub">Doubts only: no person, a phone number or handle in the picture, or a child. Take off or mark fine.</p>';
		self::table( self::rows( array( 'flag' ) ), false );
		echo '</div>';
		echo '<div class="mx-card"><div class="mx-h"><h2>Switches</h2></div><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_pg_save">' . wp_nonce_field( 'mrsh_pg_save', '_wpnonce', true, false );
		echo '<p><label><input type="checkbox" name="on" value="1"' . checked( $o['on'], 1, false ) . '> Check every new profile photo</label></p>';
		echo '<p><label><input type="checkbox" name="hide" value="1"' . checked( $o['hide'], 1, false ) . '> Take bad photos off the profile by itself (kept safe, you can bring them back)</label></p>';
		echo '<p><label><input type="checkbox" name="paid" value="1"' . checked( $o['paid'], 1, false ) . '> Use the paid AI account when no free one can read pictures (a few cents per hundred photos)</label></p>';
		echo '<p><label><input type="checkbox" name="notify" value="1"' . checked( $o['notify'], 1, false ) . '> Email the member (Urdu and English), once a day at most</label></p>';
		echo '<p><label>How sure the AI must be before it takes a photo off: <input type="number" name="conf" min="50" max="95" value="' . (int) $o['conf'] . '" style="width:70px"> %</label> <span class="mx-note">Higher = fewer mistakes, but more bad photos stay.</span></p>';
		echo '<p><label>Most AI checks a day: <input type="number" name="budget" min="10" max="1000" value="' . (int) $o['budget'] . '" style="width:80px"></label> &nbsp; <label>Old photos checked each hour: <input type="number" name="sweep" min="1" max="40" value="' . (int) $o['sweep'] . '" style="width:70px"></label></p>';
		echo '<p><button class="mx-btn p" type="submit">Save</button></p></form></div>';
		$l = get_option( self::LOG, array() );
		$l = is_array( $l ) ? array_reverse( $l ) : array();
		echo '<div class="mx-card"><div class="mx-h"><h2>Log</h2></div><div style="overflow-x:auto"><table style="width:100%;border-collapse:collapse">';
		foreach ( array_slice( $l, 0, 30 ) as $e ) {
			echo '<tr style="border-top:1px solid #eef0f6"><td style="padding:6px 8px;width:140px">' . esc_html( wp_date( 'j M H:i', $e['t'] ) ) . '</td><td style="padding:6px 8px;width:80px"><span class="mx-pill">' . esc_html( $e['k'] ) . '</span></td><td style="padding:6px 8px">' . esc_html( $e['m'] ) . '</td></tr>';
		}
		if ( ! $l ) {
			echo '<tr><td style="padding:8px">No events yet.</td></tr>';
		}
		echo '</table></div></div></div>';
	}
}

MRSH_PhotoGuard::init();
