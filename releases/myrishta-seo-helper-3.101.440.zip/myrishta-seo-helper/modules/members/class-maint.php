<?php
/**
 * Maintenance mode: visitors see a friendly "back soon" page (HTTP 503, so Google keeps the pages), admins and robots carry on.
 * Use it while the site is moved to another server, so no registration or profile is lost during the move.
 * Option: mrsh_maint = array( on, until (timestamp, 0 = no end), msg_en, msg_ur ). It switches itself off after the end time.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Maint {

	const OPT = 'mrsh_maint';

	public static function get() {
		return array_merge( array( 'on' => 0, 'until' => 0, 'en' => 'We are moving to a faster server. My Rishta Pakistan will be back very soon, InshaAllah. Thank you for your patience.', 'ur' => 'ہم تیز سرور پر منتقل ہو رہے ہیں۔ مائی رشتہ پاکستان بہت جلد واپس آئے گا، ان شاء اللہ۔ آپ کے صبر کا شکریہ۔' ), (array) get_option( self::OPT, array() ) );
	}

	public static function active() {
		$o = self::get();
		return ! empty( $o['on'] ) && ( ! (int) $o['until'] || time() < (int) $o['until'] );
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 31 );
		add_action( 'admin_post_mrsh_maint_save', array( __CLASS__, 'save' ) );
		add_action( 'init', array( __CLASS__, 'gate' ), 1 );
		add_action( 'admin_bar_menu', array( __CLASS__, 'bar' ), 100 );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Maintenance mode', 'Maintenance mode', 'manage_options', 'mrsh-maint', array( __CLASS__, 'page' ) );
	}

	public static function bar( $b ) {
		if ( self::active() && current_user_can( 'manage_options' ) ) {
			$b->add_node( array( 'id' => 'mrsh-maint', 'title' => 'Maintenance mode is ON', 'href' => admin_url( 'admin.php?page=mrsh-maint' ) ) );
		}
	}

	/** Visitors get the "back soon" page. Admins, the login page and cron are never blocked. Form posts, ajax and the REST API are blocked for visitors, so nothing is saved during the move. */
	public static function gate() {
		if ( ! self::active() || ( defined( 'DOING_CRON' ) && DOING_CRON ) || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
			return;
		}
		$script = isset( $_SERVER['SCRIPT_NAME'] ) ? basename( (string) $_SERVER['SCRIPT_NAME'] ) : ''; // phpcs:ignore
		if ( 'wp-login.php' === $script || current_user_can( 'manage_options' ) ) { // admins and the login page always work
			return;
		}
		$o = self::get();
		nocache_headers();
		status_header( 503 );
		header( 'Retry-After: 3600' );
		header( 'X-Robots-Tag: noindex' );
		$e = wp_kses_post( $o['en'] );
		$u = wp_kses_post( $o['ur'] );
		echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>Back soon | ' . esc_html( get_bloginfo( 'name' ) ) . '</title><style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#fdf2f8,#eef2ff);font-family:system-ui,-apple-system,Segoe UI,sans-serif;color:#1d2430;padding:20px;box-sizing:border-box}.c{max-width:520px;background:#fff;border-radius:24px;padding:34px 28px;text-align:center;box-shadow:0 10px 40px rgba(60,40,120,.12)}h1{margin:0 0 10px;font-size:24px}p{margin:0 0 14px;line-height:1.65;color:#4b5563}.u{direction:rtl;font-size:19px}.i{font-size:46px;margin-bottom:6px}</style></head><body><div class="c"><div class="i">&#128736;</div><h1>' . esc_html( get_bloginfo( 'name' ) ) . '</h1><p>' . $e . '</p><p class="u">' . $u . '</p></div></body></html>'; // phpcs:ignore
		exit;
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_maint_save' );
		$o        = self::get();
		$hrs      = max( 0, min( 24, absint( $_POST['hours'] ?? 0 ) ) ); // phpcs:ignore
		$o['on']  = empty( $_POST['on'] ) ? 0 : 1; // phpcs:ignore
		$o['en']  = wp_kses_post( wp_unslash( $_POST['en'] ?? $o['en'] ) ); // phpcs:ignore
		$o['ur']  = wp_kses_post( wp_unslash( $_POST['ur'] ?? $o['ur'] ) ); // phpcs:ignore
		$o['until'] = $o['on'] && $hrs ? time() + $hrs * HOUR_IN_SECONDS : 0;
		update_option( self::OPT, $o, false );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-maint&ok=1' ) );
		exit;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) || ! class_exists( 'MRSH_Boost' ) ) {
			return;
		}
		$o  = self::get();
		$on = self::active();
		MRSH_Boost::ui_open( 'Maintenance mode', 'Shows visitors a friendly "back soon" page while you move the site or change something big. You, as admin, still see the normal site.', 'g-gold', 'M12 2l9 4v6c0 5-3.500 8.500-9 10-5.500-1.500-9-5-9-10V6z' );
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			MRSH_Boost::ui_ok( 'Saved.' );
		}
		echo '<div class="mx-stats">' . MRSH_Boost::ui_stat( $on ? 'ON' : 'Off', 'Maintenance mode', $on ? '#e11d74' : '#10b981' ) . MRSH_Boost::ui_stat( $on && (int) $o['until'] ? wp_date( 'j M, g:i a', (int) $o['until'] ) : '-', 'Switches off by itself at', '#4a69d6' ) . '</div>'; // phpcs:ignore
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_maint_save">';
		wp_nonce_field( 'mrsh_maint_save' );
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">1</span><h2>Switch it on</h2></div><p class="mx-sub">Use it before the server move: it stops new registrations and profile edits, so nothing is lost while Hostinger copies the site. Visitors get an HTTP 503 page, which tells Google it is only temporary.</p>';
		echo '<div class="mx-f"><label class="mx-sw"><input type="checkbox" name="on" value="1"' . checked( $on, true, false ) . '><span class="tr"></span><span class="lb">Maintenance mode is on</span></label></div>';
		echo '<div class="mx-f" style="margin-top:16px;max-width:320px"><label class="t" for="mh">Switch off by itself after (hours, 0 = I will switch it off)</label><input type="number" id="mh" name="hours" min="0" max="24" value="6"></div></div>';
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">2</span><h2>Message visitors see</h2></div><div class="mx-f"><label class="t" for="me">English</label><textarea id="me" name="en" rows="3" style="width:100%">' . esc_textarea( $o['en'] ) . '</textarea></div><div class="mx-f" style="margin-top:12px"><label class="t" for="mu">Urdu</label><textarea id="mu" name="ur" rows="3" style="width:100%;direction:rtl">' . esc_textarea( $o['ur'] ) . '</textarea></div>';
		echo '<p style="margin:16px 0 0"><button class="mx-btn p">Save</button></p></div></form></div>';
	}
}
MRSH_Maint::init();
