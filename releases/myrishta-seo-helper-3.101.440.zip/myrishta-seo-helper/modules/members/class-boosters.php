<?php
/**
 * Member boosters (3.101.168): quick reply buttons, pause my profile, share with family, reply reminders,
 * Rishta tools page (shortcode [mrmb_tools]), profile next steps and biodata box. Each one has an On/Off switch
 * (MyRishta SEO > Member boosters). Options: mrmb_set, mrmb_tokens, mrmb_resp. Built into the plugin: no extra plugin is needed.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( class_exists( 'MRMB' ) ) {
	return; // the old separate add-on is still active: let it run until it is deleted.
}

class MRMB {

	const OPT  = 'mrmb_set';
	const TOK  = 'mrmb_tokens';
	const RESP = 'mrmb_resp';
	const CRON = 'mrmb_hourly';
	const SLUG = 'mrmb';

	public static function feats() {
		return array(
			'quick'   => array( 'Quick reply buttons', 'One-tap answers above the message box (English and Urdu).' ),
			'pause'   => array( 'Pause my profile', 'Members can hide their profile for 7, 30 or 90 days. It comes back by itself.' ),
			'family'  => array( 'Share with family', 'A private link a parent or sibling can open without signing up, with "I like it" and "Not for us" buttons.' ),
			'remind'  => array( 'Reply reminders', 'A friendly email or alert when a member has had an unread message for 3 days.' ),
			'tools'   => array( 'Rishta tools page', 'Checklist, budget calculator and questions to ask, in English and Urdu (shortcode [mrmb_tools]).' ),
			'steps'   => array( 'Profile next steps', 'Shows the 3 most useful things a member can still do to improve the profile.' ),
			'biodata' => array( 'Biodata link box', 'A box in My account that opens the printable biodata page (choose Save as PDF).' ),
		);
	}

	public static function on( $k ) {
		$o = get_option( self::OPT, array() );
		return ! ( is_array( $o ) && isset( $o[ $k ] ) && ! $o[ $k ] );
	}

	public static function init() {
		add_action( 'wp_footer', array( __CLASS__, 'quick_js' ), 50 );
		add_action( 'mrt_account_extra', array( __CLASS__, 'boxes' ), 60 );
		add_action( 'admin_post_mrmb_pause', array( __CLASS__, 'pause' ) );
		add_action( 'admin_post_mrmb_fam_new', array( __CLASS__, 'fam_new' ) );
		add_action( 'admin_post_mrmb_fam_del', array( __CLASS__, 'fam_del' ) );
		add_action( 'admin_post_mrmb_opt', array( __CLASS__, 'opt' ) );
		add_action( 'admin_post_nopriv_mrmb_fam_ans', array( __CLASS__, 'fam_ans' ) );
		add_action( 'admin_post_mrmb_fam_ans', array( __CLASS__, 'fam_ans' ) );
		add_action( 'template_redirect', array( __CLASS__, 'fam_page' ), 1 );
		add_shortcode( 'mrmb_tools', array( __CLASS__, 'tools' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
		add_action( self::CRON, array( __CLASS__, 'hourly' ) );
		if ( is_admin() ) {
			add_action( 'admin_menu', array( __CLASS__, 'menu' ), 40 );
			add_action( 'admin_post_mrmb_save', array( __CLASS__, 'save' ) );
			add_action( 'admin_init', array( __CLASS__, 'make_page' ) );
		}
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::CRON ) ) {
			wp_schedule_event( time() + 600, 'hourly', self::CRON );
		}
	}

	private static function profile( $uid ) {
		if ( class_exists( 'MRSH_Members' ) ) {
			return MRSH_Members::my_profile( $uid );
		}
		$q = get_posts( array( 'post_type' => 'listing_type', 'author' => $uid, 'post_status' => array( 'publish', 'draft', 'pending' ), 'numberposts' => 1 ) );
		return $q ? $q[0] : null;
	}

	/* ---------- 1. quick replies ---------- */

	public static function quick_js() {
		if ( ! self::on( 'quick' ) || ! is_user_logged_in() ) {
			return;
		}
		$r = array(
			array( 'Thank you', 'Thank you for your interest. Our family will talk and contact you soon. / آپ کی دلچسپی کا شکریہ۔ ہمارا خاندان بات کر کے جلد جواب دے گا۔' ),
			array( 'Not interested', 'Thank you, but we are not looking in this direction. Jazakallah khair. / شکریہ، ہم اس سلسلے میں آگے نہیں بڑھ سکتے۔ جزاک اللہ خیر۔' ),
			array( 'More details', 'Please share a few more details about your family, education and work. / براہ کرم اپنے خاندان، تعلیم اور کام کے بارے میں مزید بتائیں۔' ),
			array( 'Family to talk', 'We would like our families to speak with each other. Please ask your parents to contact us through this site. / ہم چاہتے ہیں کہ ہمارے گھر والے آپس میں بات کریں۔ اپنے والدین سے کہیں کہ اسی سائٹ کے ذریعے رابطہ کریں۔' ),
			array( 'Please wait', 'We are thinking about it and will reply in a few days. / ہم غور کر رہے ہیں، چند دن میں جواب دیں گے۔' ),
		);
		echo '<script>(function(){var R=' . wp_json_encode( $r ) . ';function add(c){if(c.dataset.mrmb)return;c.dataset.mrmb=1;var ta=c.querySelector("textarea");if(!ta)return;var d=document.createElement("div");d.className="mrmb-q";d.style.cssText="display:flex;flex-wrap:wrap;gap:6px;margin:0 0 8px";R.forEach(function(x){var b=document.createElement("button");b.type="button";b.textContent=x[0];b.style.cssText="border:1px solid #e4c9d3;background:#fff7fa;color:#6e1230;border-radius:999px;padding:6px 12px;font-size:13px;cursor:pointer";b.onclick=function(){ta.value=x[1].slice(0,1000);ta.focus();ta.dispatchEvent(new Event("input",{bubbles:true}))};d.appendChild(b)});c.parentNode.insertBefore(d,c)}function scan(){document.querySelectorAll(".cmp").forEach(add);var m=document.getElementById("mrt-msgbox");if(m&&!m.dataset.mrmb){m.dataset.mrmb=1;var ta=document.getElementById("mrt-msgtxt");if(ta){var d=document.createElement("div");d.style.cssText="display:flex;flex-wrap:wrap;gap:6px;margin:6px 0";R.slice(0,4).forEach(function(x){var b=document.createElement("button");b.type="button";b.textContent=x[0];b.style.cssText="border:1px solid #e4c9d3;background:#fff7fa;color:#6e1230;border-radius:999px;padding:6px 12px;font-size:13px;cursor:pointer";b.onclick=function(){ta.value=x[1].slice(0,1000);ta.focus()};d.appendChild(b)});ta.parentNode.insertBefore(d,ta)}}}scan();new MutationObserver(scan).observe(document.body,{childList:true,subtree:true})})();</script>';
	}

	/* ---------- account boxes (2, 4, 6 opt-out, 5, 8) ---------- */

	public static function boxes( $uid ) {
		$uid = (int) $uid;
		if ( ! $uid ) {
			return;
		}
		if ( self::on( 'steps' ) ) {
			self::box_steps( $uid );
		}
		if ( self::on( 'pause' ) ) {
			self::box_pause( $uid );
		}
		if ( self::on( 'family' ) ) {
			self::box_family( $uid );
		}
		if ( self::on( 'biodata' ) ) {
			echo '<div class="box"><h3>Biodata (PDF)</h3><p style="color:#666;font-size:.92rem">Open your one-page biodata, press Print and choose <b>Save as PDF</b>. You can send it to your family.</p><a class="btn" href="' . esc_url( home_url( '/my-biodata/' ) ) . '">Open my biodata</a></div>';
		}
		if ( self::on( 'remind' ) ) {
			$no = (int) get_user_meta( $uid, 'mrmb_noremind', true );
			echo '<div class="box"><h3>Reply reminders</h3><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrmb_opt">' . wp_nonce_field( 'mrmb_opt', '_wpnonce', true, false ) . '<label><input type="checkbox" name="remind" value="1" style="width:auto"' . checked( ! $no, true, false ) . '> Remind me by email when a message has waited 3 days</label><p><button class="btn">Save</button></p></form></div>';
		}
	}

	public static function opt() {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( home_url( '/' ) );
			exit;
		}
		check_admin_referer( 'mrmb_opt' );
		update_user_meta( get_current_user_id(), 'mrmb_noremind', empty( $_POST['remind'] ) ? 1 : 0 );
		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : home_url( '/' ) );
		exit;
	}

	private static function box_steps( $uid ) {
		$p = self::profile( $uid );
		if ( ! $p ) {
			return;
		}
		$words = str_word_count( wp_strip_all_tags( $p->post_content ) );
		$meta  = 0;
		foreach ( (array) get_post_meta( $p->ID ) as $k => $v ) {
			if ( '_' !== substr( $k, 0, 1 ) && '' !== trim( (string) ( $v[0] ?? '' ) ) ) {
				$meta++;
			}
		}
		$todo = array();
		if ( ! has_post_thumbnail( $p ) ) {
			$todo[] = 'Add a clear photo of yourself. Profiles with a photo get many more replies.';
		}
		if ( $words < 30 ) {
			$todo[] = 'Write 2 or 3 lines about yourself and your family in the About box.';
		} elseif ( $words < 80 ) {
			$todo[] = 'Add a little more to your About text: your values, work and what you look for.';
		}
		if ( $meta < 8 ) {
			$todo[] = 'Fill in more details: education, work, family and city.';
		} elseif ( $meta < 15 ) {
			$todo[] = 'Complete the remaining details so families can match you better.';
		}
		if ( 'publish' !== $p->post_status && ! get_user_meta( $uid, 'mrmb_pause', true ) ) {
			$todo[] = 'Your profile is not live yet. Finish the missing parts so it can be approved.';
		}
		$edit = home_url( '/add-listing/' );
		echo '<div class="box"><h3>Next steps for your profile</h3>';
		if ( ! $todo ) {
			echo '<p>&#10003; Your profile looks complete. Keep it up to date and answer messages quickly.</p></div>';
			return;
		}
		echo '<ol style="margin:6px 0 10px 18px;padding:0">';
		foreach ( array_slice( $todo, 0, 3 ) as $t ) {
			echo '<li style="margin:4px 0">' . esc_html( $t ) . '</li>';
		}
		echo '</ol><a class="btn" href="' . esc_url( $edit ) . '">Edit my profile</a></div>';
	}

	/* ---------- 2. pause my profile ---------- */

	private static function box_pause( $uid ) {
		$p = self::profile( $uid );
		if ( ! $p ) {
			return;
		}
		$ps = get_user_meta( $uid, 'mrmb_pause', true );
		echo '<div class="box"><h3>Pause my profile</h3>';
		if ( is_array( $ps ) && ! empty( $ps['until'] ) ) {
			echo '<p>Your profile is hidden until <b>' . esc_html( wp_date( 'j M Y', (int) $ps['until'] ) ) . '</b>. Nobody can see it. You can still log in and read messages.</p>' . self::pause_form( array( 'resume' => 'Show my profile again' ) ) . '</div>';
			return;
		}
		if ( 'publish' !== $p->post_status ) {
			echo '<p style="color:#666">You can pause the profile once it is live.</p></div>';
			return;
		}
		echo '<p style="color:#666;font-size:.92rem">Taking a break, or a rishta is in talks? Hide your profile for a while. It comes back by itself.</p>' . self::pause_form( array( '7' => '7 days', '30' => '30 days', '90' => '90 days' ) ) . '</div>';
	}

	private static function pause_form( $btns ) {
		$o = '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:flex;gap:8px;flex-wrap:wrap"><input type="hidden" name="action" value="mrmb_pause">' . wp_nonce_field( 'mrmb_pause', '_wpnonce', true, false );
		foreach ( $btns as $k => $l ) {
			$o .= '<button class="btn" name="d" value="' . esc_attr( $k ) . '">' . esc_html( $l ) . '</button>';
		}
		return $o . '</form>';
	}

	public static function pause() {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( home_url( '/' ) );
			exit;
		}
		check_admin_referer( 'mrmb_pause' );
		$uid = get_current_user_id();
		$p   = self::profile( $uid );
		$d   = isset( $_POST['d'] ) ? sanitize_key( wp_unslash( $_POST['d'] ) ) : '';
		if ( $p ) {
			if ( 'resume' === $d ) {
				self::resume( $uid );
			} elseif ( in_array( $d, array( '7', '30', '90' ), true ) && 'publish' === $p->post_status && ! get_user_meta( $uid, 'mrt_banned', true ) ) {
				update_user_meta( $uid, 'mrmb_pause', array( 'until' => time() + (int) $d * DAY_IN_SECONDS, 'pid' => $p->ID ) );
				wp_update_post( array( 'ID' => $p->ID, 'post_status' => 'draft' ) );
			}
		}
		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : home_url( '/' ) );
		exit;
	}

	private static function resume( $uid ) {
		$ps = get_user_meta( $uid, 'mrmb_pause', true );
		delete_user_meta( $uid, 'mrmb_pause' );
		if ( ! is_array( $ps ) || empty( $ps['pid'] ) ) {
			return;
		}
		$p = get_post( (int) $ps['pid'] );
		if ( $p && 'draft' === $p->post_status && (int) $p->post_author === (int) $uid && ! get_user_meta( $uid, 'mrt_banned', true ) ) {
			wp_update_post( array( 'ID' => $p->ID, 'post_status' => 'publish' ) );
		}
	}

	/* ---------- 4. share with family ---------- */

	private static function toks() {
		$t = get_option( self::TOK, array() );
		return is_array( $t ) ? $t : array();
	}

	private static function box_family( $uid ) {
		$p = self::profile( $uid );
		if ( ! $p || 'publish' !== $p->post_status ) {
			return;
		}
		$mine = array();
		foreach ( self::toks() as $tk => $r ) {
			if ( (int) $r['uid'] === $uid && (int) $r['t'] > time() - 30 * DAY_IN_SECONDS ) {
				$mine[ $tk ] = $r;
			}
		}
		$resp = get_option( self::RESP, array() );
		$resp = is_array( $resp ) ? $resp : array();
		echo '<div class="box"><h3>Share with family</h3><p style="color:#666;font-size:.92rem">Send a private link to a parent or sibling. They can look at your profile without signing up and tap <b>I like it</b> or <b>Not for us</b>. The link works for 30 days.</p>';
		foreach ( $mine as $tk => $r ) {
			$url = add_query_arg( 'mrmb_fam', $tk, home_url( '/' ) );
			$a   = isset( $resp[ $tk ] ) ? (array) $resp[ $tk ] : array();
			echo '<div style="border:1px solid #eee;border-radius:10px;padding:8px 10px;margin:8px 0"><input type="text" readonly value="' . esc_attr( $url ) . '" onclick="this.select()" style="width:100%"><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px"><a class="btn" target="_blank" rel="noopener" href="' . esc_url( 'https://wa.me/?text=' . rawurlencode( 'Please look at this rishta profile and tell me what you think: ' . $url ) ) . '">Send on WhatsApp</a><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline"><input type="hidden" name="action" value="mrmb_fam_del"><input type="hidden" name="tk" value="' . esc_attr( $tk ) . '">' . wp_nonce_field( 'mrmb_fam_del', '_wpnonce', true, false ) . '<button class="btn" style="background:#888">Stop sharing</button></form></div>';
			foreach ( array_slice( $a, -5 ) as $x ) {
				echo '<p style="margin:6px 0 0"><b>' . ( 'yes' === $x['a'] ? '&#128154; I like it' : '&#128078; Not for us' ) . '</b>' . ( $x['n'] ? ' - ' . esc_html( $x['n'] ) : '' ) . ' <span style="color:#999;font-size:.85em">' . esc_html( wp_date( 'j M H:i', (int) $x['t'] ) ) . '</span></p>';
			}
			echo '</div>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrmb_fam_new">' . wp_nonce_field( 'mrmb_fam_new', '_wpnonce', true, false ) . '<button class="btn">Make a family link</button></form></div>';
	}

	public static function fam_new() {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( home_url( '/' ) );
			exit;
		}
		check_admin_referer( 'mrmb_fam_new' );
		$uid = get_current_user_id();
		$t   = self::toks();
		foreach ( $t as $k => $r ) {
			if ( (int) $r['t'] < time() - 30 * DAY_IN_SECONDS ) {
				unset( $t[ $k ] );
			}
		}
		$n = 0;
		foreach ( $t as $r ) {
			$n += (int) $r['uid'] === $uid ? 1 : 0;
		}
		if ( $n < 5 ) {
			$t[ wp_generate_password( 22, false, false ) ] = array( 'uid' => $uid, 't' => time() );
		}
		update_option( self::TOK, array_slice( $t, -800, null, true ), false );
		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : home_url( '/' ) );
		exit;
	}

	public static function fam_del() {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( home_url( '/' ) );
			exit;
		}
		check_admin_referer( 'mrmb_fam_del' );
		$tk = isset( $_POST['tk'] ) ? sanitize_text_field( wp_unslash( $_POST['tk'] ) ) : '';
		$t  = self::toks();
		if ( isset( $t[ $tk ] ) && (int) $t[ $tk ]['uid'] === get_current_user_id() ) {
			unset( $t[ $tk ] );
			update_option( self::TOK, $t, false );
		}
		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : home_url( '/' ) );
		exit;
	}

	/** The page a family member opens. */
	public static function fam_page() {
		if ( empty( $_GET['mrmb_fam'] ) || ! self::on( 'family' ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$tk = sanitize_text_field( wp_unslash( $_GET['mrmb_fam'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$t  = self::toks();
		nocache_headers();
		header( 'X-Robots-Tag: noindex, nofollow' );
		$r = $t[ $tk ] ?? null;
		$p = $r && (int) $r['t'] > time() - 30 * DAY_IN_SECONDS ? self::profile( (int) $r['uid'] ) : null;
		echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>A rishta profile for you</title><style>body{margin:0;background:linear-gradient(180deg,#3b0a19 0,#6e1230 220px,#f7f1e8 220px);font:16px/1.6 system-ui,-apple-system,Segoe UI,sans-serif;color:#222}.c{max-width:520px;margin:0 auto;padding:22px 16px 40px}.top{color:#fff;text-align:center;margin:0 0 16px}.top b{display:block;font-size:1.05rem;letter-spacing:.04em;color:#f0d080}.top span{opacity:.85;font-size:.9rem}.card{background:#fff;border-radius:24px;padding:18px;box-shadow:0 18px 50px rgba(59,10,25,.25)}img{width:100%;border-radius:18px;max-height:400px;object-fit:cover;display:block}h1{font-size:1.5rem;margin:.7em 0 .2em;color:#6e1230;line-height:1.25}.ab{color:#444}.b{display:block;width:100%;border:0;border-radius:14px;padding:15px;font-size:1.05rem;font-weight:700;color:#fff;margin-top:10px;cursor:pointer;box-shadow:0 8px 18px rgba(0,0,0,.12)}.y{background:linear-gradient(135deg,#12a375,#0f7a55)}.n{background:linear-gradient(135deg,#9b1b4b,#6e1230)}input[type=text]{width:100%;box-sizing:border-box;padding:12px;border:1px solid #e6d7dc;border-radius:12px;margin-top:12px;font-size:1rem}a{color:#6e1230;font-weight:600}.ok{background:#e9f9f2;border:1px solid #bfe9d6;color:#0b6b4a;border-radius:14px;padding:12px 14px;margin-top:12px;font-weight:700}.sm{font-size:.82rem;color:#8a7c80;margin-top:16px;text-align:center}</style></head><body><div class="c"><div class="top"><b>' . esc_html( get_bloginfo( 'name' ) ) . '</b><span>A private profile shared by a family</span></div><div class="card">';
		if ( ! $p || 'publish' !== $p->post_status ) {
			echo '<h1>This link is not available</h1><p>The link has expired or the profile is not visible right now. Please ask for a new link.</p>';
		} else {
			if ( has_post_thumbnail( $p ) ) {
				echo get_the_post_thumbnail( $p, 'large' ); // phpcs:ignore WordPress.Security.EscapeOutput
			}
			echo '<h1>' . esc_html( get_the_title( $p ) ) . '</h1><p class="ab">' . esc_html( wp_trim_words( wp_strip_all_tags( $p->post_content ), 60 ) ) . '</p><p><a href="' . esc_url( get_permalink( $p ) ) . '" target="_blank" rel="noopener">See the full profile</a></p>';
			if ( isset( $_GET['done'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
				echo '<div class="ok">Thank you. Your answer was sent.</div>';
			} else {
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrmb_fam_ans"><input type="hidden" name="tk" value="' . esc_attr( $tk ) . '"><input type="text" name="n" maxlength="40" placeholder="Your name or relation (optional)"><input type="text" name="website" value="" autocomplete="off" tabindex="-1" style="position:absolute;left:-9999px"><button class="b y" name="a" value="yes">&#128154; I like it</button><button class="b n" name="a" value="no">Not for us</button></form>';
			}
			echo '<p class="sm">Private link shared by the family. Phone numbers are not shown here.</p>';
		}
		echo '</div></div></body></html>';
		exit;
	}

	public static function fam_ans() {
		$tk = isset( $_POST['tk'] ) ? sanitize_text_field( wp_unslash( $_POST['tk'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$a  = isset( $_POST['a'] ) && 'yes' === $_POST['a'] ? 'yes' : 'no'; // phpcs:ignore WordPress.Security.NonceVerification
		$t  = self::toks();
		$back = add_query_arg( array( 'mrmb_fam' => $tk, 'done' => 1 ), home_url( '/' ) );
		if ( ! isset( $t[ $tk ] ) || ! empty( $_POST['website'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			wp_safe_redirect( $back );
			exit;
		}
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		$rk = 'mrmb_rl_' . md5( $ip . $tk );
		if ( get_transient( $rk ) ) {
			wp_safe_redirect( $back );
			exit;
		}
		set_transient( $rk, 1, 60 );
		$n    = isset( $_POST['n'] ) ? mb_substr( sanitize_text_field( wp_unslash( $_POST['n'] ) ), 0, 40 ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$resp = get_option( self::RESP, array() );
		$resp = is_array( $resp ) ? $resp : array();
		$resp[ $tk ][] = array( 'a' => $a, 'n' => $n, 't' => time() );
		$resp[ $tk ]   = array_slice( $resp[ $tk ], -10 );
		update_option( self::RESP, array_slice( $resp, -400, null, true ), false );
		$u = get_userdata( (int) $t[ $tk ]['uid'] );
		if ( $u && $u->user_email ) {
			wp_mail( $u->user_email, 'Your family looked at your profile', 'Assalam o Alaikum ' . $u->display_name . ",\n\nSomeone you shared your profile with answered: " . ( 'yes' === $a ? 'I like it' : 'Not for us' ) . ( $n ? ' (' . $n . ')' : '' ) . ".\n\nSee it in My account: " . home_url( '/my-account/' ) );
		}
		wp_safe_redirect( $back );
		exit;
	}

	/* ---------- 6. reply reminders ---------- */

	public static function hourly() {
		self::unpause_due();
		if ( self::on( 'remind' ) ) {
			self::remind();
		}
	}

	private static function unpause_due() {
		foreach ( get_users( array( 'meta_key' => 'mrmb_pause', 'fields' => 'ID', 'number' => 200 ) ) as $uid ) { // phpcs:ignore WordPress.DB.SlowDBQuery
			$ps = get_user_meta( (int) $uid, 'mrmb_pause', true );
			if ( ! is_array( $ps ) || empty( $ps['until'] ) || (int) $ps['until'] <= time() ) {
				self::resume( (int) $uid );
			}
		}
	}

	private static function remind() {
		$ids = get_posts( array(
			'post_type' => 'ppt_message', 'post_status' => 'publish', 'numberposts' => 80, 'fields' => 'ids',
			'date_query' => array( array( 'before' => '3 days ago', 'after' => '30 days ago', 'inclusive' => true ) ),
			'meta_query' => array( array( 'key' => 'msg_status', 'value' => 'unread_', 'compare' => 'LIKE' ) ),
		) );
		$sent = 0;
		$seen = array();
		foreach ( $ids as $id ) {
			$to = (int) get_post_meta( $id, 'reciever_id', true );
			if ( ! $to || isset( $seen[ $to ] ) || $sent >= 25 ) {
				continue;
			}
			$seen[ $to ] = 1;
			if ( get_user_meta( $to, 'mrmb_noremind', true ) || get_transient( 'mrmb_rm_' . $to ) ) {
				continue;
			}
			if ( class_exists( 'MRSH_Mem_More5' ) && MRSH_Mem_More5::quiet( $to ) ) {
				continue;
			}
			$u = get_userdata( $to );
			if ( ! $u || ! $u->user_email || 'unread_' . $to !== (string) get_post_meta( $id, 'msg_status', true ) ) {
				continue;
			}
			set_transient( 'mrmb_rm_' . $to, 1, 7 * DAY_IN_SECONDS );
			$body = 'Assalam o Alaikum ' . $u->display_name . ",\n\nSomeone wrote to you on " . get_bloginfo( 'name' ) . " a few days ago and is waiting for an answer. A short reply, even a polite no, is kind and helps families move on.\n\nOpen your messages: " . home_url( '/my-account/' ) . "\n\nYou can stop these reminders in My account.";
			if ( class_exists( 'MRSH_Mailq' ) ) {
				MRSH_Mailq::add( $u->user_email, 'A message is waiting for your reply', $body, array( 'kind' => 'reminder', 'uid' => $to ) );
			} else {
				wp_mail( $u->user_email, 'A message is waiting for your reply', $body );
			}
			if ( class_exists( 'MRSH_Mem_Push' ) ) {
				MRSH_Mem_Push::ping( $to, 'msg' );
			}
			$sent++;
		}
	}

	/* ---------- 7. Rishta tools page ---------- */

	public static function make_page() {
		if ( ! self::on( 'tools' ) || get_option( 'mrmb_page_made' ) ) {
			return;
		}
		update_option( 'mrmb_page_made', 1, false );
		if ( ! get_page_by_path( 'rishta-tools' ) ) {
			wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => 'Rishta tools', 'post_name' => 'rishta-tools', 'post_content' => '[mrmb_tools]' ) );
		}
	}

	public static function tools() {
		if ( ! self::on( 'tools' ) ) {
			return '';
		}
		$chk = array( 'Both families agree and pray istikhara', 'First meeting with elders present', 'Check education and job in person or by phone', 'Ask about family background and neighbours', 'Talk openly about expectations and living arrangement', 'Agree on nikah date and simple arrangements', 'Decide mehr and write it clearly', 'Fix the guest list and venue', 'Budget for food, clothes and venue', 'Prepare nikah documents (CNICs, nikah nama)', 'Arrange witnesses and the nikah khwan', 'Plan walima' );
		$qs  = array( 'What are your plans for work and income in the next 5 years?', 'Where will we live after marriage?', 'How do you see the role of both families in daily life?', 'What are your religious practice and values?', 'Do you want to continue your studies or job after marriage?', 'What are your health or family responsibilities I should know about?', 'How do you handle disagreements?', 'What is important to you in a life partner?' );
		ob_start();
		?>
<div class="mrmb-tools">
<style>
.mrmb-tools{--m:#6e1230;--m2:#9b1b4b;--g:#c9962f;--bg:#faf5ef;--ln:#eadfe3;max-width:820px;margin:0 auto;padding:4px 0 24px;font-family:inherit}
.mrmb-tools .hero{background:linear-gradient(135deg,#3b0a19,#6e1230 55%,#9b1b4b);color:#fff;border-radius:22px;padding:26px 22px;margin:0 0 16px;position:relative;overflow:hidden}
.mrmb-tools .hero:after{content:"";position:absolute;right:-50px;top:-50px;width:190px;height:190px;border-radius:50%;background:rgba(240,208,128,.18)}
.mrmb-tools .hero h2{margin:0 0 6px;color:#fff;font-size:1.6rem;line-height:1.2}
.mrmb-tools .hero p{margin:0;opacity:.9;max-width:520px}
.mrmb-tools .tabs{display:flex;gap:8px;overflow-x:auto;margin:0 0 14px;padding:2px;-webkit-overflow-scrolling:touch;position:sticky;top:0;z-index:5;background:linear-gradient(var(--bg),rgba(250,245,239,.9))}
.mrmb-tools .tabs button{flex:none;border:1px solid var(--ln);background:#fff;color:#444;border-radius:999px;padding:10px 18px;font-weight:700;font-size:.95rem;cursor:pointer;transition:.15s}
.mrmb-tools .tabs button.on{background:linear-gradient(135deg,var(--m2),var(--m));color:#fff;border-color:transparent;box-shadow:0 6px 16px rgba(110,18,48,.25)}
.mrmb-tools .pane{display:none}.mrmb-tools .pane.on{display:block}
.mrmb-tools .card{background:#fff;border:1px solid var(--ln);border-radius:20px;padding:18px;box-shadow:0 8px 28px rgba(110,18,48,.06)}
.mrmb-tools .bar{height:10px;border-radius:10px;background:#f1e6ea;overflow:hidden;margin:6px 0 4px}.mrmb-tools .bar i{display:block;height:100%;width:0;background:linear-gradient(90deg,var(--g),#12a375);border-radius:10px;transition:width .3s}
.mrmb-tools .pc{font-weight:700;color:var(--m)}
.mrmb-tools label.k{display:flex;align-items:flex-start;gap:12px;padding:12px;border:1px solid var(--ln);border-radius:14px;margin:8px 0;cursor:pointer;transition:.15s;background:#fffdfb}
.mrmb-tools label.k:hover{border-color:var(--m2)}
.mrmb-tools label.k input{appearance:none;-webkit-appearance:none;flex:none;width:24px;height:24px;border-radius:8px;border:2px solid #d9c6cd;display:grid;place-items:center;margin:1px 0 0;background:#fff}
.mrmb-tools label.k input:checked{background:#12a375;border-color:#12a375}
.mrmb-tools label.k input:checked:after{content:"";width:6px;height:11px;border:solid #fff;border-width:0 3px 3px 0;transform:rotate(45deg) translate(-1px,-1px)}
.mrmb-tools label.k input:checked+span{color:#8a7c80;text-decoration:line-through}
.mrmb-tools .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px}
.mrmb-tools .f label{display:block;font-weight:700;font-size:.85rem;color:#555;margin:0 0 4px}
.mrmb-tools .f input{width:100%;box-sizing:border-box;padding:12px 14px;border:1px solid var(--ln);border-radius:12px;font-size:1rem;background:#fffdfb}
.mrmb-tools .f input:focus{outline:2px solid #e4c9d3;border-color:var(--m2)}
.mrmb-tools .tot{margin-top:16px;background:linear-gradient(135deg,#fff7fa,#f7f1e8);border:1px solid #efd9e1;border-radius:16px;padding:16px}
.mrmb-tools .tot b{display:block;font-size:1.7rem;color:var(--m);line-height:1.2}
.mrmb-tools .tot small{color:#6b5a5f}
.mrmb-tools .seg{display:flex;height:14px;border-radius:10px;overflow:hidden;margin:12px 0 6px;background:#eee}
.mrmb-tools .seg i{display:block;height:100%;transition:width .3s}
.mrmb-tools .lg{display:flex;flex-wrap:wrap;gap:6px 14px;font-size:.85rem;color:#555}.mrmb-tools .lg span:before{content:"";display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:6px;background:var(--c)}
.mrmb-tools ol.q{list-style:none;counter-reset:q;margin:0;padding:0}
.mrmb-tools ol.q li{counter-increment:q;display:flex;gap:12px;align-items:flex-start;padding:12px 0;border-bottom:1px solid #f1e6ea}.mrmb-tools ol.q li:last-child{border:0}
.mrmb-tools ol.q li:before{content:counter(q);flex:none;width:30px;height:30px;border-radius:10px;background:linear-gradient(135deg,var(--m2),var(--m));color:#fff;display:grid;place-items:center;font-weight:700;font-size:.9rem}
.mrmb-tools .note{margin-top:12px;padding:12px 14px;border-radius:14px;background:#fff7e6;border:1px solid #f0dcae;color:#6b5320;font-size:.9rem}
.mrmb-tools .ur{direction:rtl;font-weight:400;opacity:.9}
</style>
<div class="hero"><h2>Rishta tools <span class="ur">· رشتہ ٹولز</span></h2><p>Simple helpers for families: a nikah checklist, a wedding budget and questions to ask before you meet.</p></div>
<div class="tabs" role="tablist"><button class="on" data-p="ck">Checklist <span class="ur">· فہرست</span></button><button data-p="bd">Budget <span class="ur">· بجٹ</span></button><button data-p="qs">Questions <span class="ur">· سوالات</span></button></div>
<div class="pane on" id="mrmb-ck"><div class="card"><div class="pc"><span id="ck-n">0</span> of <?php echo (int) count( $chk ); ?> done</div><div class="bar"><i id="ck-b"></i></div>
		<?php foreach ( $chk as $i => $t ) : ?>
<label class="k"><input type="checkbox" data-i="<?php echo (int) $i; ?>"><span><?php echo esc_html( $t ); ?></span></label>
		<?php endforeach; ?>
<p style="color:#8a7c80;font-size:.85rem;margin:10px 0 0">Your ticks are saved on this phone only.</p></div></div>
<div class="pane" id="mrmb-bd"><div class="card"><div class="grid f">
<div><label for="mb-g">Guests</label><input type="number" id="mb-g" value="200" min="0"></div>
<div><label for="mb-f">Food per guest (Rs)</label><input type="number" id="mb-f" value="1500" min="0"></div>
<div><label for="mb-v">Venue / hall (Rs)</label><input type="number" id="mb-v" value="150000" min="0"></div>
<div><label for="mb-c">Clothes and jewellery (Rs)</label><input type="number" id="mb-c" value="300000" min="0"></div>
<div><label for="mb-o">Photo, decor, other (Rs)</label><input type="number" id="mb-o" value="100000" min="0"></div></div>
<div class="tot"><small>Estimated total</small><b id="mb-t">Rs 0</b><small id="mb-p"></small><div class="seg" id="mb-s"></div><div class="lg" id="mb-l"></div></div></div></div>
<div class="pane" id="mrmb-qs"><div class="card"><ol class="q">
		<?php foreach ( $qs as $q ) : ?>
<li><span><?php echo esc_html( $q ); ?></span></li>
		<?php endforeach; ?>
</ol><div class="note">Meet in a public place with elders present. Never send money to anyone you meet through the internet.</div></div></div>
<script>(function(){var R=document.querySelector(".mrmb-tools");R.querySelectorAll(".tabs button").forEach(function(b){b.onclick=function(){R.querySelectorAll(".tabs button").forEach(function(x){x.classList.toggle("on",x===b)});R.querySelectorAll(".pane").forEach(function(p){p.classList.toggle("on",p.id==="mrmb-"+b.dataset.p)})}});var K="mrmb_ck",s={};try{s=JSON.parse(localStorage.getItem(K)||"{}")}catch(e){}var cs=R.querySelectorAll("#mrmb-ck input");function pr(){var n=0;cs.forEach(function(c){if(c.checked)n++});R.querySelector("#ck-n").textContent=n;R.querySelector("#ck-b").style.width=(cs.length?n/cs.length*100:0)+"%"}cs.forEach(function(c){c.checked=!!s[c.dataset.i];c.onchange=function(){s[c.dataset.i]=c.checked?1:0;try{localStorage.setItem(K,JSON.stringify(s))}catch(e){}pr()}});pr();function n(i){return parseFloat(document.getElementById(i).value)||0}var fmt=function(x){return "Rs "+Math.round(x).toLocaleString("en-PK")};function u(){var g=n("mb-g"),parts=[["Food",g*n("mb-f"),"#c9962f"],["Venue",n("mb-v"),"#6e1230"],["Clothes",n("mb-c"),"#9b1b4b"],["Other",n("mb-o"),"#12a375"]],t=parts.reduce(function(a,p){return a+p[1]},0);document.getElementById("mb-t").textContent=fmt(t);document.getElementById("mb-p").textContent=g?"About "+fmt(t/g)+" per guest":"";document.getElementById("mb-s").innerHTML=parts.map(function(p){return "<i style=\"width:"+(t?p[1]/t*100:0)+"%;background:"+p[2]+"\"></i>"}).join("");document.getElementById("mb-l").innerHTML=parts.map(function(p){return "<span style=\"--c:"+p[2]+"\">"+p[0]+" "+fmt(p[1])+"</span>"}).join("")}R.querySelectorAll("#mrmb-bd input").forEach(function(i){i.oninput=u});u()})();</script>
</div>
		<?php
		return ob_get_clean();
	}

	/* ---------- admin switches ---------- */

	public static function menu() {
		$parent = 'myrishta-seo';
		add_submenu_page( $parent, 'Member boosters', 'Member boosters', 'manage_options', self::SLUG, array( __CLASS__, 'page' ) );
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrmb_save' );
		$o = array();
		foreach ( self::feats() as $k => $f ) {
			$o[ $k ] = empty( $_POST[ 'sw_' . $k ] ) ? 0 : 1;
		}
		update_option( self::OPT, $o, false );
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&ok=1' ) );
		exit;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		echo '<div class="wrap"><h1>Member boosters</h1>';
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="notice notice-success"><p>Saved. Clear the LiteSpeed cache so members see it.</p></div>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrmb_save">' . wp_nonce_field( 'mrmb_save', '_wpnonce', true, false ) . '<table class="form-table" role="presentation">';
		foreach ( self::feats() as $k => $f ) {
			echo '<tr><th>' . esc_html( $f[0] ) . '</th><td><label><input type="checkbox" name="sw_' . esc_attr( $k ) . '" value="1"' . checked( self::on( $k ), true, false ) . '> On</label> <span class="description">' . esc_html( $f[1] ) . '</span></td></tr>';
		}
		echo '</table><p><button class="button button-primary">Save</button> <a class="button" href="' . esc_url( home_url( '/rishta-tools/' ) ) . '" target="_blank">Open the Rishta tools page</a></p></form></div>';
	}
}
MRMB::init();
