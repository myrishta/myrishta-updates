<?php
/**
 * AI Autopilot: one master switch that lets the AI and the robots act on their own while the site is free.
 *
 * ON (default): the AI answers every ticket it can answer safely, the robot sends login / password-reset help,
 * packages are given by the Ticket Concierge, keyword phrases and search-engine pings run more often, and every
 * action is written to a log here. OFF ("ask before action"): the AI only writes draft notes for the owner.
 * Hard limits that stay on even in full mode: money, refunds, legal, threats, safety, deleting or banning members,
 * and anything about other people's private data always go to a human. The AI never asks for passwords,
 * CNIC numbers or bank details.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Autopilot {

	const OPT  = 'mrsh_ap';
	const LOG  = 'mrsh_ap_log';
	const DONE = 'mrsh_ap_done';

	public static function o() {
		$o = get_option( self::OPT, array() );
		return array_merge( array( 'on' => 1, 'areas' => array() ), is_array( $o ) ? $o : array() );
	}

	/** The jobs the autopilot really does. Each has its own switch (default ON). */
	public static function areas() {
		return array(
			'tickets'  => array( 'Support tickets', 'Answers safe questions, or says "waiting for a human".', 'mrsh-tickets' ),
			'packages' => array( 'Packages', 'Gives the free Bronze / Silver / Gold packages people ask for.', 'mrsh-plans' ),
			'login'    => array( 'Login and email help', 'Sends password-reset links to members who cannot log in.', 'mrsh-users' ),
			'meta'     => array( 'Search descriptions', 'Writes search-result descriptions for pages without one.', 'mrsh-search' ),
			'keywords' => array( 'Keyword phrases', 'Applies focus phrases to new pages.', 'mrsh-autokw' ),
			'profiles' => array( 'Profile screening', 'Pauses (never deletes) a new profile whose text is clearly abusive, a scam or asks for money. Other doubts go to your Inbox.', 'mrsh-profiles' ),
			'report'   => array( 'Daily report to you', 'One email each morning: what the robots did and the few things that need you.', 'mrsh-autopilot' ),
			'landing'  => array( 'Gulf growth pages', 'Publishes the Qatar, Bahrain, Oman, Kuwait and Gulf city guide pages, two a day.', 'mrsh-landing' ),
			'adsense'  => array( 'AdSense approval guard', 'Checks every day what AdSense reviewers look at and tells you in the Inbox and the daily report.', 'mrsh-autopilot' ),
			'indexing' => array( 'Indexing', 'Tells search engines about changed pages every hour.', 'mrsh-search' ),
		);
	}

	/** May the autopilot act in this area? Master switch and the area switch must both be ON. */
	public static function can( $area ) {
		if ( ! self::on() ) {
			return false;
		}
		$a = self::o()['areas'];
		return ! is_array( $a ) || ! isset( $a[ $area ] ) || ! empty( $a[ $area ] );
	}

	public static function on() {
		return ! empty( self::o()['on'] ) && ( ! class_exists( 'MRSH_Switch' ) || MRSH_Switch::on( 'autopilot' ) );
	}

	public static function log( $area, $msg ) {
		$l   = get_option( self::LOG, array() );
		$l   = is_array( $l ) ? $l : array();
		$l[] = array( 't' => time(), 'a' => (string) $area, 'm' => mb_substr( (string) $msg, 0, 240 ) );
		update_option( self::LOG, array_slice( $l, -150 ), false );
	}

	/**
	 * Safe removal: nothing is ever lost. Writes a restore record (kept in the "Removed members" list below),
	 * sets the member's profiles to draft and hands them to an administrator instead of erasing them, then removes the login.
	 */
	public static function safe_delete( $u, $why = '' ) {
		if ( ! $u || ! $u->ID ) {
			return false;
		}
		$ids = get_posts( array( 'post_type' => 'listing_type', 'post_status' => 'any', 'author' => $u->ID, 'numberposts' => 50, 'fields' => 'ids', 'suppress_filters' => true ) );
		$rec = array(
			't'      => time(),
			'login'  => $u->user_login,
			'email'  => $u->user_email,
			'name'   => $u->display_name,
			'reg'    => $u->user_registered,
			'why'    => (string) $why,
			'posts'  => array_map( 'intval', $ids ),
			'plan'   => (string) get_user_meta( $u->ID, 'mrt_plan', true ),
			'mobile' => (string) get_user_meta( $u->ID, 'mrt_mobile', true ),
		);
		$a   = get_option( 'mrsh_ap_removed', array() );
		$a   = is_array( $a ) ? $a : array();
		$a[] = $rec;
		update_option( 'mrsh_ap_removed', array_slice( $a, -1000 ), false );
		foreach ( $ids as $i ) {
			wp_update_post( array( 'ID' => $i, 'post_status' => 'draft' ) );
		}
		$adm = get_users( array( 'role' => 'administrator', 'number' => 1, 'fields' => 'ID' ) );
		require_once ABSPATH . 'wp-admin/includes/user.php';
		$ok = wp_delete_user( (int) $u->ID, $adm ? (int) $adm[0] : null );
		self::log( 'Safety', 'Removed login ' . $u->user_login . ' (' . $why . '). Profiles kept as drafts; restore record saved.' );
		return (bool) $ok;
	}

	/** One-time SEO tidy: private-looking utility pages must not be indexed. Runs once per version of this list. */
	public static function seo_tidy() {
		if ( get_option( 'mrsh_ap_seo' ) === '1' || ! class_exists( 'MRSH_Options' ) ) {
			return;
		}
		$o    = MRSH_Options::get();
		$have = MRSH_Options::to_list( $o['noindex_slugs'] );
		$add  = array_diff( array( 'profile-details' ), $have );
		if ( $add ) {
			$o['noindex_slugs'] = implode( ',', array_merge( $have, $add ) );
			update_option( MRSH_Options::KEY, $o );
			self::log( 'SEO', 'Kept private-looking pages out of Google: ' . implode( ', ', $add ) . '.' );
		}
		update_option( 'mrsh_ap_seo', '1', false );
	}

	public static function init() {
		add_action( 'init', array( __CLASS__, 'seo_tidy' ), 30 );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 44 );
		add_action( 'admin_post_mrsh_ap_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_mrsh_ap_rep', array( __CLASS__, 'rep_now' ) );
		if ( class_exists( 'MRSH_Tickets' ) ) {
			add_action( MRSH_Tickets::CRON, array( __CLASS__, 'tick' ), 20 );
		}
	}

	/* ---------- the robot work ---------- */

	public static function tick() {
		if ( ! self::on() ) {
			return;
		}
		if ( class_exists( 'MRSH_Help' ) ) {
			MRSH_Help::tick();
		}
		self::daily_report();
		if ( self::can( 'login' ) ) {
			self::login_help();
		}
		if ( class_exists( 'MRSH_AdsGuard' ) && self::can( 'adsense' ) ) {
			MRSH_AdsGuard::daily();
		}
		if ( class_exists( 'MRSH_Landing' ) && self::can( 'landing' ) ) {
			MRSH_Landing::drip();
		}
		// Search engines: ping about changed pages at most once an hour.
		if ( class_exists( 'MRSH_Agent' ) && self::can( 'indexing' ) && ! get_transient( 'mrsh_ap_idx' ) ) {
			set_transient( 'mrsh_ap_idx', 1, HOUR_IN_SECONDS );
			try {
				$r = MRSH_Agent::run( false, false );
				if ( is_array( $r ) && ! empty( $r['ok'] ) && (int) $r['count'] > 1 ) {
					self::log( 'Indexing', 'Told search engines about ' . (int) $r['count'] . ' changed page(s).' );
				}
			} catch ( \Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement
			}
		}
		// Broken addresses: redirect the ones that clearly match an existing page (hourly).
		if ( class_exists( 'MRSH_Seofix' ) && self::can( 'indexing' ) && ! get_transient( 'mrsh_ap_fix' ) ) {
			set_transient( 'mrsh_ap_fix', 1, HOUR_IN_SECONDS );
			try {
				MRSH_Seofix::auto();
			} catch ( \Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement
			}
		}
		// Keyword phrases: apply to new pages every 6 hours (never overwrites a phrase you typed).
		if ( class_exists( 'MRSH_AutoKW' ) && self::can( 'keywords' ) && ! get_transient( 'mrsh_ap_kw' ) ) {
			set_transient( 'mrsh_ap_kw', 1, 6 * HOUR_IN_SECONDS );
			try {
				MRSH_AutoKW::run();
				self::log( 'Keywords', 'Checked pages for missing focus keyword phrases.' );
			} catch ( \Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement
			}
		}
	}

	/** One short email a day to the site owner: what was done, and what needs a person. */
	public static function daily_report( $force = false ) {
		if ( ! self::can( 'report' ) || ( ! $force && ( (int) wp_date( 'G' ) < 8 || get_option( 'mrsh_ap_rep' ) === wp_date( 'Y-m-d' ) ) ) ) {
			return false;
		}
		update_option( 'mrsh_ap_rep', wp_date( 'Y-m-d' ), false );
		$since = time() - DAY_IN_SECONDS;
		$by    = array();
		foreach ( (array) get_option( self::LOG, array() ) as $r ) {
			if ( (int) $r['t'] >= $since ) {
				$by[ $r['a'] ] = ( $by[ $r['a'] ] ?? 0 ) + 1;
			}
		}
		global $wpdb;
		$wait = class_exists( 'MRSH_Tickets' ) ? (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . MRSH_Tickets::t1() . " WHERE status IN ('open','progress')" ) : 0; // phpcs:ignore WordPress.DB
		$inb  = class_exists( 'MRSH_Attn' ) ? (int) MRSH_Attn::open_count() : 0;
		$new  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->users} WHERE user_registered > %s", gmdate( 'Y-m-d H:i:s', $since ) ) ); // phpcs:ignore WordPress.DB
		$ai   = class_exists( 'MRSH_AIHub' ) ? MRSH_AIHub::used_today() : 0;
		$l    = "Daily report from your AI Autopilot\n\n";
		$l   .= $by ? "Done by itself in the last 24 hours:\n" : "The robots had nothing to do in the last 24 hours.\n";
		foreach ( $by as $a => $n ) {
			$l .= ' - ' . $a . ': ' . $n . "\n";
		}
		$l .= "\nNew members: " . $new . "\nAI calls today so far: " . $ai . "\n";
		$l .= "\nNeeds a person:\n - Tickets waiting for a human: " . $wait . "\n - Items in your Inbox: " . $inb . "\n";
		if ( class_exists( 'MRSH_AdsGuard' ) && MRSH_AdsGuard::summary() ) {
			$l .= ' - ' . MRSH_AdsGuard::summary() . "\n";
		}
		$l .= ( $wait || $inb ) ? "\nOpen: " . admin_url( 'admin.php?page=mrsh-tickets' ) . "\n" : "\nNothing needs you today.\n";
		$to = get_option( 'admin_email' );
		$sb = 'My Rishta daily report: ' . ( $wait + $inb ? ( $wait + $inb ) . ' item(s) need you' : 'all calm' );
		if ( class_exists( 'MRSH_Mailq' ) ) {
			MRSH_Mailq::add( $to, $sb, $l, array( 'kind' => 'ticket_ai' ) );
		} else {
			wp_mail( $to, $sb, $l );
		}
		self::log( 'Report', 'Sent the daily report to the owner.' );
		return true;
	}

	/** "I forgot my password / cannot log in": send the member a fresh reset link by email and answer the ticket. */
	private static function login_help() {
		global $wpdb;
		$done = get_option( self::DONE, array() );
		$done = is_array( $done ) ? $done : array();
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . MRSH_Tickets::t1() . " WHERE status='open' AND answered=0 AND created < %d AND created > %d ORDER BY id ASC LIMIT 10", time() - 60, time() - 7 * DAY_IN_SECONDS ) ); // phpcs:ignore WordPress.DB
		foreach ( (array) $rows as $t ) {
			if ( isset( $done[ $t->id ] ) ) {
				continue;
			}
			$first = (string) $wpdb->get_var( $wpdb->prepare( 'SELECT body FROM ' . MRSH_Tickets::t2() . " WHERE ticket_id=%d AND who='user' ORDER BY id ASC LIMIT 1", $t->id ) ); // phpcs:ignore WordPress.DB
			$text  = $t->subject . "\n" . mb_substr( wp_strip_all_tags( $first ), 0, 1200 );
			if ( ! preg_match( '/forgot.{0,12}password|reset.{0,12}password|password.{0,15}(reset|forgot|lost|bhool)|cannot log ?in|can.?t log ?in|unable to log ?in|login problem|bhool gaya|bhul gaya|پاس ورڈ|لاگ ان/iu', $text ) ) {
				continue;
			}
			if ( preg_match( '/refund|police|fraud|scam|hack(ed)?|stolen|someone else|threat|blackmail|paid|payment|bank/i', $text ) ) {
				continue; // possible account takeover or money: a person must look.
			}
			$u = (int) $t->user_id ? get_userdata( (int) $t->user_id ) : ( is_email( $t->email ) ? get_user_by( 'email', $t->email ) : false );
			if ( ! $u || user_can( $u, 'edit_others_posts' ) || get_user_meta( $u->ID, 'mrsh_ap_reset', true ) > time() - DAY_IN_SECONDS ) {
				continue;
			}
			$key = get_password_reset_key( $u );
			if ( is_wp_error( $key ) ) {
				continue;
			}
			update_user_meta( $u->ID, 'mrsh_ap_reset', time() );
			$url = network_site_url( 'wp-login.php?action=rp&key=' . $key . '&login=' . rawurlencode( $u->user_login ), 'login' );
			$msg = "Assalam o Alaikum " . $u->display_name . ",\n\nWe sent a password reset link to your account email (" . self::mask( $u->user_email ) . "). Open it and choose a new password. The link works for a limited time. You can also use 'Forgot password' on the login page any time.\n\nآپ کے اکاؤنٹ کی ای میل پر پاس ورڈ ری سیٹ لنک بھیج دیا گیا ہے۔ اسے کھول کر نیا پاس ورڈ بنا لیں۔ اگر ای میل نظر نہ آئے تو سپیم فولڈر دیکھ لیں۔";
			MRSH_Tickets::add_msg( (int) $t->id, 'staff', $msg );
			MRSH_Tickets::add_msg( (int) $t->id, 'system', 'Password reset email sent automatically by the AI autopilot.' );
			$wpdb->update( MRSH_Tickets::t1(), array( 'status' => 'waiting', 'answered' => time() ), array( 'id' => (int) $t->id ) ); // phpcs:ignore WordPress.DB
			$body = "Assalam o Alaikum " . $u->display_name . ",\n\nYou asked for help logging in to My Rishta Pakistan. Open this link to choose a new password:\n\n" . $url . "\n\nIf you did not ask for this, ignore this email; your password stays the same.\n\nآپ نے لاگ ان میں مدد مانگی تھی۔ نیا پاس ورڈ بنانے کے لیے اوپر والا لنک کھولیں۔ اگر آپ نے نہیں مانگا تو اس ای میل کو نظر انداز کر دیں۔";
			if ( class_exists( 'MRSH_Mailq' ) ) {
				MRSH_Mailq::add( $u->user_email, 'Reset your password - My Rishta Pakistan', $body, array( 'kind' => 'ticket_ai', 'headers' => array( 'Auto-Submitted: auto-generated' ) ) );
			} else {
				wp_mail( $u->user_email, 'Reset your password - My Rishta Pakistan', $body );
			}
			$done[ $t->id ] = time();
			self::log( 'Login help', 'Sent a password reset link for ticket ' . MRSH_Tickets::code( (int) $t->id ) . '.' );
		}
		update_option( self::DONE, array_slice( $done, -300, null, true ), false );
	}

	private static function mask( $e ) {
		$p = explode( '@', (string) $e );
		return count( $p ) < 2 ? '' : substr( $p[0], 0, 2 ) . '***@' . $p[1];
	}

	/* ---------- admin page ---------- */

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'AI Autopilot', 'AI Autopilot', 'manage_options', 'mrsh-autopilot', array( __CLASS__, 'page' ) );
	}

	public static function rep_now() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'No.' );
		}
		check_admin_referer( 'mrsh_ap_rep' );
		self::daily_report( true );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-autopilot&ok=1' ) );
		exit;
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'No.' );
		}
		check_admin_referer( 'mrsh_ap' );
		$ar = array();
		foreach ( array_keys( self::areas() ) as $k ) {
			$ar[ $k ] = empty( $_POST['area'][ $k ] ) ? 0 : 1; // phpcs:ignore
		}
		update_option( self::OPT, array( 'on' => empty( $_POST['on'] ) ? 0 : 1, 'areas' => $ar ), false );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-autopilot&ok=1' ) );
		exit;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$on = ! empty( self::o()['on'] );
		MRSH_Boost::ui_open( 'AI Autopilot', 'While the site is free, the AI and robots act on their own to support members. Every action is listed below.', 'g-blue', 'M12 2a3 3 0 0 1 3 3v1h2a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H7a3 3 0 0 1-3-3V9a3 3 0 0 1 3-3h2V5a3 3 0 0 1 3-3zM9 12a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3zm6 0a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3z' );
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			MRSH_Boost::ui_ok( 'Saved.' );
		}
		$ready = class_exists( 'MRSH_AIHub' ) && MRSH_AIHub::ready();
		$st    = class_exists( 'MRSH_Concierge' ) ? MRSH_Concierge::stats() : array( 'plan' => 0, 'human' => 0 );
		$log   = array_reverse( (array) get_option( self::LOG, array() ) );
		echo '<div class="mx-stats">' . MRSH_Boost::ui_stat( $on ? 'ON' : 'ASK FIRST', 'Mode', $on ? '#139a86' : '#f59e0b' ) . MRSH_Boost::ui_stat( $ready ? 'Ready' : 'No AI key', 'AI', $ready ? '#139a86' : '#e11d48' ) . MRSH_Boost::ui_stat( (int) $st['plan'], 'Packages given', '#7c3aed' ) . MRSH_Boost::ui_stat( (int) $st['human'], 'Sent to a human', '#6b7280' ) . '</div>'; // phpcs:ignore
		global $wpdb;
		$wt = class_exists( 'MRSH_Tickets' ) ? (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . MRSH_Tickets::t1() . " WHERE status IN ('open','progress')" ) : 0; // phpcs:ignore WordPress.DB
		$ib = class_exists( 'MRSH_Attn' ) ? (int) MRSH_Attn::open_count() : 0;
		echo '<div class="mx-card"><h2 class="mx-h">Needs you right now</h2><div class="mx-stats">' . MRSH_Boost::ui_stat( $wt, 'Tickets waiting for a human', $wt ? '#f59e0b' : '#139a86' ) . MRSH_Boost::ui_stat( $ib, 'Items in your Inbox', $ib ? '#f59e0b' : '#139a86' ) . '</div><div class="mx-acts"><a class="mx-btn s" href="' . esc_url( admin_url( 'admin.php?page=mrsh-tickets' ) ) . '">Open tickets</a> <a class="mx-btn s" href="' . esc_url( admin_url( 'admin.php?page=mrsh-inbox' ) ) . '">Open Inbox</a> <a class="mx-btn s" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_ap_rep' ), 'mrsh_ap_rep' ) ) . '">Send me the report now</a></div></div>';
		if ( class_exists( 'MRSH_Help' ) ) {
			MRSH_Help::card();
		}
		if ( class_exists( 'MRSH_Finish' ) ) {
			MRSH_Finish::card();
		}
		if ( class_exists( 'MRSH_NameFix' ) ) {
			MRSH_NameFix::card();
		}
		echo '<div class="mx-card"><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'mrsh_ap' );
		echo '<input type="hidden" name="action" value="mrsh_ap_save">';
		echo '<p><label><input type="checkbox" name="on" value="1"' . checked( $on, true, false ) . '> <b>Full support mode</b>: the AI and robots act without waiting for my approval</label></p>';
		echo '<p class="mx-sub">What it does when ON: answers every ticket it can answer safely (and says "waiting for a human" when it cannot), gives the free packages people ask for, sends password-reset emails for login problems, writes search-result descriptions, applies keyword phrases to new pages, and tells search engines about changed pages every hour. Turn it OFF when you start charging: the AI then only writes draft notes for you.</p>';
		echo '<h2 class="mx-h">Where the AI may act</h2><div class="mx-stats" style="grid-template-columns:repeat(auto-fit,minmax(240px,1fr))">';
		$ao = self::o()['areas'];
		foreach ( self::areas() as $k => $a ) {
			$chk = ! is_array( $ao ) || ! isset( $ao[ $k ] ) || ! empty( $ao[ $k ] );
			echo '<label class="mx-stat" style="--c:#7c3aed;text-align:left;cursor:pointer"><span><input type="checkbox" name="area[' . esc_attr( $k ) . ']" value="1"' . checked( $chk, true, false ) . '> <b style="font-size:15px">' . esc_html( $a[0] ) . '</b></span><span>' . esc_html( $a[1] ) . '</span></label>';
		}
		echo '</div><p><button class="mx-btn">Save</button></p></form></div>';
		global $submenu;
		$real = array_keys( self::areas() );
		$pages = isset( $submenu['myrishta-seo'] ) ? $submenu['myrishta-seo'] : array();
		echo '<div class="mx-card"><h2 class="mx-h">Every admin page, one tap away</h2><p class="mx-sub">The six jobs above are done by the robot itself. All other pages are listed here so you can jump to them; the AI reads their results through the ticket and report robots but does not change their settings.</p><div class="mx-acts" style="flex-wrap:wrap;gap:8px">';
		foreach ( $pages as $pg ) {
			if ( empty( $pg[2] ) || 'mrsh-autopilot' === $pg[2] ) {
				continue;
			}
			echo '<a class="mx-btn s" href="' . esc_url( admin_url( 'admin.php?page=' . $pg[2] ) ) . '">' . esc_html( trim( preg_replace( '/<span.*?<\/span>|\(\d+\)/s', '', wp_strip_all_tags( $pg[0] ) ) ) ) . '</a>';
		}
		echo '</div></div>';
		echo '<div class="mx-card"><h2 class="mx-h">Always for a human (even in full mode)</h2><p class="mx-sub">Money, payments and refunds; legal matters, police, threats, blackmail; safety and abuse; deleting, removing or banning members; hacked accounts; anything about another person\'s private details. The AI never asks anyone for a password, CNIC or bank details.</p></div>';
		echo '<div class="mx-card"><h2 class="mx-h">Keep it running cheaply</h2><p class="mx-sub">Open <a href="' . esc_url( admin_url( 'admin.php?page=mrsh-ai-hub' ) ) . '">AI Assistant</a> and add another provider key to the pool. The robots rotate through all keys and use the free ones first, so a cheaper API can be added later without changing anything here.</p></div>';
		if ( class_exists( 'MRSH_AdsGuard' ) ) {
			MRSH_AdsGuard::card();
		}
		$rm = array_reverse( (array) get_option( 'mrsh_ap_removed', array() ) );
		echo '<div class="mx-card"><h2 class="mx-h">Removed members (kept on record)</h2><p class="mx-sub">When a login is removed automatically, the profile stays here as a draft and this record is kept, so nothing is lost. Backups run daily (Full backup page).</p>';
		if ( ! $rm ) {
			echo '<p class="mx-sub">None.</p>';
		} else {
			echo '<div class="mx-tbl"><table class="widefat striped"><thead><tr><th>When</th><th>Name</th><th>Email</th><th>Why</th></tr></thead><tbody>';
			foreach ( array_slice( $rm, 0, 30 ) as $r ) {
				echo '<tr><td>' . esc_html( wp_date( 'd M Y', (int) $r['t'] ) ) . '</td><td>' . esc_html( $r['name'] ) . '</td><td>' . esc_html( $r['email'] ) . '</td><td>' . esc_html( $r['why'] ) . '</td></tr>';
			}
			echo '</tbody></table></div>';
		}
		echo '</div>';
		echo '<div class="mx-card"><h2 class="mx-h">What the AI did</h2>';
		if ( ! $log ) {
			echo '<p class="mx-sub">Nothing yet. Actions appear here as they happen.</p>';
		} else {
			echo '<div class="mx-tbl"><table class="widefat striped"><thead><tr><th>When</th><th>Area</th><th>Action</th></tr></thead><tbody>';
			foreach ( array_slice( $log, 0, 60 ) as $r ) {
				echo '<tr><td>' . esc_html( wp_date( 'd M, H:i', (int) $r['t'] ) ) . '</td><td><span class="mx-pill">' . esc_html( $r['a'] ) . '</span></td><td>' . esc_html( $r['m'] ) . '</td></tr>';
			}
			echo '</tbody></table></div>';
		}
		echo '</div></div>';
	}
}

MRSH_Autopilot::init();
