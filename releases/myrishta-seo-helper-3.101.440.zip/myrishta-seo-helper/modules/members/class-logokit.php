<?php
/**
 * Logo kit: ready-made logos (horizontal, vertical, square mark, one-colour, reversed) and banner sizes for Google Ads,
 * Google Business Profile, Facebook, YouTube, X and LinkedIn, all made from the CSS logo and kept in assets/logos.
 * Search engines and consoles find them on their own through the fixed addresses below:
 *   /favicon.ico  /apple-touch-icon.png  /logo.png  /logo.svg
 * (only used when no real file with that name exists, and a Site icon set in Customize still wins for the favicon).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_LogoKit {

	const SLUG = 'mrsh-logokit';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'serve' ), 1 );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 30 );
		add_action( 'admin_post_mrsh_logokit_zip', array( __CLASS__, 'zip' ) );
		add_action( 'admin_post_mrsh_logokit_media', array( __CLASS__, 'to_media' ) );
	}

	/** Copy every kit PNG into the Media Library once (full quality, nothing re-compressed), so the pictures are kept with the site, its backups and its moves. */
	public static function to_media() {
		if ( ! current_user_can( 'upload_files' ) || ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'mrsh_logokit_media' ) ) {
			wp_die( 'Not allowed.' );
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		add_filter( 'big_image_size_threshold', '__return_false' ); // never shrink or re-compress the originals
		add_filter( 'jpeg_quality', function () { return 100; } );
		$new = 0;
		$ids = array();
		foreach ( (array) glob( self::dir() . '*.png' ) as $f ) {
			$n  = basename( $f );
			$ex = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'meta_key' => '_mrsh_kit', 'meta_value' => $n, 'fields' => 'ids', 'posts_per_page' => 1, 'no_found_rows' => true ) );
			if ( $ex ) {
				$ids[ $n ] = (int) $ex[0];
				continue;
			}
			$tmp = wp_tempnam( $n );
			if ( ! @copy( $f, $tmp ) ) { // phpcs:ignore
				continue;
			}
			$id = media_handle_sideload( array( 'name' => 'myrishta-' . $n, 'tmp_name' => $tmp ), 0, 'My Rishta logo kit: ' . str_replace( array( '-', '.png' ), array( ' ', '' ), $n ) );
			if ( is_wp_error( $id ) ) {
				wp_delete_file( $tmp );
				continue;
			}
			update_post_meta( $id, '_mrsh_kit', $n );
			update_post_meta( $id, '_wp_attachment_image_alt', 'My Rishta Pakistan logo' );
			$ids[ $n ] = (int) $id;
			$new++;
		}
		// Use the Media Library copies for the Organization logo and share image when those are still empty.
		if ( class_exists( 'MRSH_Options' ) ) {
			$o = get_option( MRSH_Options::KEY, array() );
			$o = is_array( $o ) ? $o : array();
			if ( empty( $o['org_logo'] ) && ! empty( $ids['logo-mark-padded.png'] ) ) {
				$o['org_logo'] = (string) wp_get_attachment_url( $ids['logo-mark-padded.png'] );
			}
			if ( empty( $o['social_image'] ) && ! empty( $ids['og-image-1200x630.png'] ) ) {
				$o['social_image'] = (string) wp_get_attachment_url( $ids['og-image-1200x630.png'] );
			}
			update_option( MRSH_Options::KEY, $o );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&added=' . $new . '&total=' . count( $ids ) ) );
		exit;
	}

	private static function dir() {
		return MRSH_DIR . 'assets/logos/';
	}

	private static function url( $f ) {
		return MRSH_URL . 'assets/logos/' . $f . '?v=' . MRSH_VERSION;
	}

	/** Fixed addresses that crawlers and consoles ask for. */
	public static function serve() {
		if ( is_admin() || empty( $_SERVER['REQUEST_URI'] ) ) {
			return;
		}
		$p = strtolower( (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH ) ); // phpcs:ignore
		$home = strtolower( rtrim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' ) );
		if ( $home && 0 === strpos( $p, $home ) ) {
			$p = substr( $p, strlen( $home ) );
		}
		$map = array(
			'/favicon.ico'                       => array( MRSH_DIR . 'assets/favicon.ico', 'image/x-icon' ),
			'/apple-touch-icon.png'              => array( MRSH_DIR . 'assets/pwa/icon-180.png', 'image/png' ),
			'/apple-touch-icon-precomposed.png'  => array( MRSH_DIR . 'assets/pwa/icon-180.png', 'image/png' ),
			'/logo.png'                          => array( self::dir() . 'logo-horizontal.png', 'image/png' ),
			'/logo.svg'                          => array( self::dir() . 'logo-horizontal.svg', 'image/svg+xml' ),
		);
		if ( ! isset( $map[ $p ] ) || ! is_readable( $map[ $p ][0] ) ) {
			return;
		}
		if ( '/favicon.ico' === $p && function_exists( 'has_site_icon' ) && has_site_icon() ) {
			return; // WordPress serves the Site icon
		}
		status_header( 200 );
		header( 'Content-Type: ' . $map[ $p ][1] );
		header( 'Cache-Control: public, max-age=604800' );
		header( 'Content-Length: ' . filesize( $map[ $p ][0] ) );
		readfile( $map[ $p ][0] ); // phpcs:ignore
		exit;
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Logo kit', 'Logo kit', 'manage_options', self::SLUG, array( __CLASS__, 'page' ) );
	}

	public static function zip() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'mrsh_logokit_zip' ) || ! class_exists( 'ZipArchive' ) ) {
			wp_die( 'Not allowed.' );
		}
		$tmp = wp_tempnam( 'myrishta-logo-kit.zip' );
		$z   = new ZipArchive();
		if ( true !== $z->open( $tmp, ZipArchive::OVERWRITE ) ) {
			wp_die( 'Could not build the zip.' );
		}
		foreach ( (array) glob( self::dir() . '*.{png,svg}', GLOB_BRACE ) as $f ) {
			$z->addFile( $f, 'myrishta-logo-kit/' . basename( $f ) );
		}
		$z->close();
		header( 'Content-Type: application/zip' );
		header( 'Content-Disposition: attachment; filename="myrishta-logo-kit.zip"' );
		header( 'Content-Length: ' . filesize( $tmp ) );
		readfile( $tmp ); // phpcs:ignore
		wp_delete_file( $tmp );
		exit;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$set = array(
			'Main logos' => array(
				array( 'logo-horizontal', 'Horizontal logo', 'Website header, e-mail, letterhead. Google Ads landscape logo (4:1, 1200 x 300).' ),
				array( 'logo-vertical', 'Vertical (stacked) logo', 'Square placements, posters, WhatsApp status, Google Ads square logo (1200 x 1200).' ),
				array( 'logo-mark', 'Square mark only', 'App icon, profile picture, small spaces.' ),
				array( 'logo-mark-padded', 'Square mark with white margin', 'Google Business Profile and Google Ads when a white border is needed.' ),
				array( 'logo-horizontal-reverse', 'Horizontal, for dark backgrounds', 'White text on dark or photo backgrounds.' ),
				array( 'logo-vertical-reverse', 'Vertical, for dark backgrounds', 'White text on dark backgrounds.' ),
				array( 'logo-horizontal-black', 'One colour, black', 'Print, stamps, newspapers.' ),
				array( 'logo-horizontal-white', 'One colour, white', 'Single-colour white print or video.' ),
			),
			'More styles' => array(
				array( 'logo-gold-horizontal', 'Gold on navy, horizontal', 'Premium look for agreements, invitations and cards.' ),
				array( 'logo-gold-vertical', 'Gold on navy, stacked', 'Premium square use.' ),
				array( 'logo-mark-outline', 'Outline mark', 'Light, modern look on white or photos.' ),
				array( 'logo-seal', 'Round seal / stamp', 'Round badge for agreements and certificates.' ),
			),
			'Letterheads and documents (A4)' => array(
				array( 'letterhead-a4-classic', 'A4 letterhead, classic', 'Logo, line, footer. The Agreement tool prints on this.' ),
				array( 'letterhead-a4-modern', 'A4 letterhead, colour band', 'Gradient header and footer band.' ),
				array( 'letterhead-a4-minimal', 'A4 letterhead, minimal', 'Centred logo, light footer.' ),
				array( 'watermark-mark', 'Watermark, mark', 'Faint mark for the middle of a page (put it behind the text).' ),
				array( 'watermark-logo', 'Watermark, full logo', 'Faint full logo for the middle of a page.' ),
			),
			'Google' => array(
				array( 'google-profile-logo-720x720', 'Google profile logo (maroon and gold)', '720 x 720 px. Matches the website colours.', 'png' ),
				array( 'google-profile-cover-1080x608', 'Google profile cover (maroon and gold)', '1080 x 608 px.', 'png' ),
				array( 'google-post-families-1200x1200', 'Google post photo: find a match', '1200 x 1200 px, for Google profile posts.', 'png' ),
				array( 'google-post-safe-1200x1200', 'Google post photo: safe and free', '1200 x 1200 px, for Google profile posts.', 'png' ),
				array( 'google-post-parents-1200x1200', 'Google post photo: parents', '1200 x 1200 px, for Google profile posts.', 'png' ),
				array( 'google-business-logo-720x720', 'Google Business Profile logo', '720 x 720 px.', 'png' ),
				array( 'google-business-cover-1024x576', 'Google Business Profile cover', '1024 x 576 px.' ),
				array( 'ads-landscape-1200x628', 'Google Ads landscape image', '1.91:1, 1200 x 628 px.' ),
				array( 'ads-square-1200x1200', 'Google Ads square image', '1:1, 1200 x 1200 px.' ),
				array( 'ads-portrait-960x1200', 'Google Ads portrait image', '4:5, 960 x 1200 px.' ),
				array( 'youtube-banner-2560x1440', 'YouTube channel banner', '2560 x 1440 px.' ),
			),
			'Social' => array(
				array( 'social-profile-400x400', 'Profile picture', '400 x 400 px, for Facebook, Instagram, X, WhatsApp Business, LinkedIn.', 'png' ),
				array( 'facebook-cover-1640x624', 'Facebook cover', '1640 x 624 px.' ),
				array( 'x-header-1500x500', 'X (Twitter) header', '1500 x 500 px.' ),
				array( 'linkedin-banner-1584x396', 'LinkedIn banner', '1584 x 396 px.' ),
				array( 'og-image-1200x630', 'Link share image', '1200 x 630 px, for WhatsApp, Facebook and X link previews.' ),
			),
		);
		echo '<div class="wrap"><h1>Logo kit</h1><p>All logos are drawn from the same design as the website header. PNG for uploading, SVG for printing and editing. Right-click or use the buttons to save.</p>';
		if ( isset( $_GET['added'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success"><p>Done: ' . (int) $_GET['added'] . ' new pictures added to the Media Library (' . (int) ( $_GET['total'] ?? 0 ) . ' in total). The Organization logo and share image now use those copies.</p></div>'; // phpcs:ignore
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin:0 0 10px"><input type="hidden" name="action" value="mrsh_logokit_media">' . wp_nonce_field( 'mrsh_logokit_media', '_wpnonce', true, false ) . '<button class="button button-primary">Save all pictures to the Media Library</button> <span class="description">Keeps full quality copies with the site, so they are never lost. Safe to press again: nothing is added twice.</span></form>'; // phpcs:ignore
		if ( class_exists( 'ZipArchive' ) ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin:0 0 14px"><input type="hidden" name="action" value="mrsh_logokit_zip">' . wp_nonce_field( 'mrsh_logokit_zip', '_wpnonce', true, false ) . '<button class="button button-primary">Download everything (zip)</button></form>'; // phpcs:ignore
		}
		foreach ( $set as $title => $items ) {
			echo '<h2>' . esc_html( $title ) . '</h2><div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px">';
			foreach ( $items as $it ) {
				$png = self::url( $it[0] . '.png' );
				$svg = ( isset( $it[3] ) && 'png' === $it[3] ) ? '' : self::url( $it[0] . '.svg' );
				$dk  = false !== strpos( $it[0], 'reverse' );
				echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:12px;display:flex;flex-direction:column;gap:8px"><div style="background:' . ( $dk ? '#222' : '#f3f4f7' ) . ';border-radius:8px;display:grid;place-items:center;height:150px;overflow:hidden"><img src="' . esc_url( $png ) . '" alt="" style="max-width:100%;max-height:150px;object-fit:contain"></div><b>' . esc_html( $it[1] ) . '</b><span class="description">' . esc_html( $it[2] ) . '</span><span><a class="button" download href="' . esc_url( $png ) . '">PNG</a> ' . ( $svg ? '<a class="button" download href="' . esc_url( $svg ) . '">SVG</a>' : '' ) . '</span></div>'; // phpcs:ignore
			}
			echo '</div>';
		}
		echo '<p><a class="button" href="' . esc_url( admin_url( 'admin.php?page=mrsh-agreement' ) ) . '">Open the Agreement letter tool</a></p><h2>Found automatically by search engines</h2><ul style="list-style:disc;margin-left:20px"><li>Organization schema on the home page points to the logo and share images.</li><li>These fixed addresses answer without any setting: <code>/favicon.ico</code>, <code>/apple-touch-icon.png</code>, <code>/logo.png</code>, <code>/logo.svg</code>.</li><li>The tab icon (SVG + ICO), phone home-screen icons and the app manifest use the same mark.</li></ul>';
		echo '<p class="description">For Google Business Profile, Google Ads and social pages the images still have to be uploaded in those accounts once; no website can upload them for you.</p></div>';
	}
}
MRSH_LogoKit::init();
