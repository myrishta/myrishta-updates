<?php
/**
 * Ban for good (3.101.253). The member can never come back, but every record is kept: account, profile text, tickets, messages.
 * - the profile is hidden and kept out of Google, the member is signed out, cached pages are cleared;
 * - log in and password reset stop working, so nothing can be recovered by email;
 * - the email address (also Gmail dot / plus variants) cannot register again; a new sign-up is closed at once;
 * - automatic emails stop (only mail you write yourself from the Desk or a ticket reply still goes out);
 * - nothing is deleted. "Undo ban for good" brings the account back to a normal temporary block.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_PermBan {

	const EMAILS = 'mrsh_permban_emails';

	public static function init() {
		add_filter( 'authenticate', array( __CLASS__, 'login' ), 98, 2 );
		add_filter( 'allow_password_reset', array( __CLASS__, 'reset' ), 10, 2 );
		add_filter( 'registration_errors', array( __CLASS__, 'register' ), 10, 3 );
		add_action( 'user_register', array( __CLASS__, 'late' ), 30 );
		if ( is_admin() ) {
			add_action( 'admin_post_mrsh_permban', array( __CLASS__, 'handler' ) );
		}
	}

	/** Same mailbox, whatever the spelling: lower case, Gmail dots and +tags removed. */
	public static function norm( $e ) {
		$e = strtolower( trim( (string) $e ) );
		if ( false === strpos( $e, '@' ) ) {
			return $e;
		}
		list( $l, $d ) = explode( '@', $e, 2 );
		$l = preg_replace( '/\+.*$/', '', $l );
		if ( in_array( $d, array( 'gmail.com', 'googlemail.com' ), true ) ) {
			$l = str_replace( '.', '', $l );
			$d = 'gmail.com';
		}
		return $l . '@' . $d;
	}

	public static function is_perm( $uid ) {
		return (bool) get_user_meta( (int) $uid, 'mrsh_perm_ban', true );
	}

	public static function email_banned( $email ) {
		$list = (array) get_option( self::EMAILS, array() );
		return $email && isset( $list[ md5( self::norm( $email ) ) ] );
	}

	/** Ban for good. Returns true when done. Never deletes anything. */
	public static function ban( $uid, $why = '' ) {
		$uid = (int) $uid;
		$u   = get_userdata( $uid );
		if ( ! $u || user_can( $uid, 'manage_options' ) ) {
			return false;
		}
		update_user_meta( $uid, 'mrt_banned', 1 );
		update_user_meta( $uid, 'mrsh_perm_ban', time() );
		update_user_meta( $uid, 'mrsh_perm_ban_why', sanitize_text_field( $why ) );
		update_user_meta( $uid, 'mrsh_mm_off', 1 );
		update_user_meta( $uid, 'mrt_news_ok', '0' );
		$list = (array) get_option( self::EMAILS, array() );
		$list[ md5( self::norm( $u->user_email ) ) ] = array( $uid, time() );
		update_option( self::EMAILS, $list, false );
		if ( class_exists( 'MRSH_Manage' ) ) {
			MRSH_Manage::enforce_ban( $uid );
		}
		return true;
	}

	public static function undo( $uid ) {
		$uid = (int) $uid;
		$u   = get_userdata( $uid );
		if ( ! $u ) {
			return false;
		}
		delete_user_meta( $uid, 'mrsh_perm_ban' );
		delete_user_meta( $uid, 'mrsh_perm_ban_why' );
		$list = (array) get_option( self::EMAILS, array() );
		unset( $list[ md5( self::norm( $u->user_email ) ) ] );
		update_option( self::EMAILS, $list, false );
		return true; // stays blocked (the normal temporary block) until you press Unblock
	}

	public static function login( $user, $login ) {
		$u = $user instanceof WP_User ? $user : get_user_by( 'login', (string) $login );
		if ( ! $u && is_email( $login ) ) {
			$u = get_user_by( 'email', $login );
		}
		if ( $u && self::is_perm( $u->ID ) ) {
			return new WP_Error( 'mrt_permban', 'This account has been closed.' );
		}
		return $user;
	}

	public static function reset( $allow, $uid ) {
		return self::is_perm( $uid ) || get_user_meta( (int) $uid, 'mrt_banned', true ) ? false : $allow;
	}

	public static function register( $errors, $login, $email ) {
		if ( self::email_banned( $email ) ) {
			$errors->add( 'mrt_permban', 'This email address cannot be used on this site.' );
		}
		return $errors;
	}

	/** A sign-up that got past the form is closed at once. */
	public static function late( $uid ) {
		$u = get_userdata( $uid );
		if ( $u && self::email_banned( $u->user_email ) && ! self::is_perm( $uid ) ) {
			self::ban( $uid, 'Registered again with a banned email address' );
		}
	}

	/** Used by the mail queue: automatic mail to a banned address is dropped. Mail you write yourself still goes. */
	public static function mail_blocked( $to, $uid, $kind ) {
		if ( in_array( (string) $kind, array( 'desk', 'ticket', 'tickets' ), true ) ) {
			return false;
		}
		return ( $uid && self::is_perm( $uid ) ) || self::email_banned( $to );
	}

	public static function handler() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		$uid = isset( $_GET['uid'] ) ? absint( $_GET['uid'] ) : 0;
		check_admin_referer( 'mrsh_permban' . $uid );
		if ( 'undo' === ( $_GET['do'] ?? '' ) ) { // phpcs:ignore
			self::undo( $uid );
		} else {
			self::ban( $uid, 'Banned for good by an administrator' );
		}
		wp_safe_redirect( wp_get_referer() ?: admin_url( 'admin.php?page=mrsh-desk' ) );
		exit;
	}

	public static function link( $uid, $do = 'ban' ) {
		return wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_permban&do=' . $do . '&uid=' . (int) $uid ), 'mrsh_permban' . (int) $uid );
	}
}
MRSH_PermBan::init();
