<?php
/**
 * Agent-ready site (3.101.279).
 * Makes myrishta.pk easy for AI agents and assistants to use, using public information only. No member data is ever returned.
 *  1. robots.txt: Content-Signal line (search=yes, ai-input=yes, ai-train=no).
 *  2. Sitemap: <lastmod> on every URL and every sitemap of the index.
 *  3. Markdown: a public page answers "Accept: text/markdown" (or ?mrsh_md=1) with a clean Markdown copy.
 *  4. WebMCP: in-browser agents get small read-only tools (navigator.modelContext.registerTool).
 *  5. MCP server: a public read-only MCP endpoint at /mr-mcp (site_info, search_guides, how_to_register) and its
 *     MCP Server Card at /.well-known/mcp/server-card.json.
 * Switch: "Agent-ready site" in Feature switches (on by default).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Agentready {

	const SIGNAL = 'search=yes, ai-input=yes, ai-train=no';
	const PROTO  = '2025-06-18';

	public static function on() {
		return ! class_exists( 'MRSH_Switch' ) || MRSH_Switch::on( 'agentready' );
	}

	public static function init() {
		add_filter( 'robots_txt', array( __CLASS__, 'robots' ), 99, 2 );
		add_filter( 'wp_sitemaps_posts_entry', array( __CLASS__, 'sm_post' ), 10, 2 );
		add_filter( 'wp_sitemaps_taxonomies_entry', array( __CLASS__, 'sm_term' ), 10, 2 );
		add_filter( 'wp_sitemaps_index_entry', array( __CLASS__, 'sm_index' ), 10, 3 );
		add_action( 'init', array( __CLASS__, 'routes' ), 1 );
		add_action( 'template_redirect', array( __CLASS__, 'markdown' ), 1 );
		add_action( 'wp_head', array( __CLASS__, 'head_links' ), 7 );
		add_action( 'wp_footer', array( __CLASS__, 'webmcp' ), 97 );
		add_action( 'admin_init', array( __CLASS__, 'htaccess' ) );
	}

	/* ---------- 1. robots.txt ---------- */

	public static function robots( $out, $public ) {
		if ( ! $public || ! self::on() || false !== stripos( $out, 'Content-Signal' ) ) {
			return $out;
		}
		$sig = apply_filters( 'mrsh_content_signal', self::SIGNAL );
		$n   = preg_replace( '/^User-agent:[^\r\n]*$/mi', "$0\nContent-Signal: " . $sig, $out );
		return is_string( $n ) && $n !== $out ? $n : "User-agent: *\nContent-Signal: " . $sig . "\n\n" . $out;
	}

	/* ---------- 2. sitemap lastmod ---------- */

	private static function iso( $mysql_gmt ) {
		$t = $mysql_gmt ? strtotime( $mysql_gmt . ' UTC' ) : 0;
		return $t ? gmdate( 'c', $t ) : '';
	}

	public static function sm_post( $e, $post ) {
		if ( self::on() && $post instanceof WP_Post ) {
			$d = self::iso( $post->post_modified_gmt );
			if ( $d ) {
				$e['lastmod'] = $d;
			}
		}
		return $e;
	}

	public static function sm_term( $e, $term ) {
		$tid = is_object( $term ) ? (int) ( isset( $term->term_id ) ? $term->term_id : 0 ) : (int) $term;
		if ( ! self::on() || $tid < 1 ) {
			return $e;
		}
		global $wpdb;
		$k = 'mrsh_smt_' . $tid;
		$v = get_transient( $k );
		if ( false === $v ) {
			$v = (string) $wpdb->get_var( $wpdb->prepare( "SELECT MAX(p.post_modified_gmt) FROM {$wpdb->posts} p JOIN {$wpdb->term_relationships} r ON r.object_id=p.ID JOIN {$wpdb->term_taxonomy} t ON t.term_taxonomy_id=r.term_taxonomy_id WHERE t.term_id=%d AND p.post_status='publish'", $tid ) ); // phpcs:ignore
			set_transient( $k, $v, HOUR_IN_SECONDS );
		}
		$d = self::iso( $v );
		if ( $d ) {
			$e['lastmod'] = $d;
		}
		return $e;
	}

	public static function sm_index( $e, $type = '', $sub = '' ) {
		if ( ! self::on() ) {
			return $e;
		}
		global $wpdb;
		$k = 'mrsh_smi_' . md5( $type . '|' . $sub );
		$v = get_transient( $k );
		if ( false === $v ) {
			if ( 'post' === $type && $sub ) {
				$v = (string) $wpdb->get_var( $wpdb->prepare( "SELECT MAX(post_modified_gmt) FROM {$wpdb->posts} WHERE post_type=%s AND post_status='publish'", $sub ) ); // phpcs:ignore
			} else {
				$v = (string) $wpdb->get_var( "SELECT MAX(post_modified_gmt) FROM {$wpdb->posts} WHERE post_status='publish' AND post_type IN ('post','page')" ); // phpcs:ignore
			}
			set_transient( $k, $v, HOUR_IN_SECONDS );
		}
		$d = self::iso( $v );
		if ( $d ) {
			$e['lastmod'] = $d;
		}
		return $e;
	}

	/* ---------- helpers ---------- */

	private static function path() {
		$u = isset( $_SERVER['REQUEST_URI'] ) ? wp_parse_url( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH ) : ''; // phpcs:ignore
		$b = untrailingslashit( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ) );
		$u = untrailingslashit( (string) $u );
		return $b && 0 === strpos( $u, $b ) ? substr( $u, strlen( $b ) ) : $u;
	}

	private static function org() {
		return class_exists( 'MRSH_Options' ) ? MRSH_Options::org() : array( 'street' => 'Shahdara', 'city' => 'Lahore', 'region' => 'Punjab', 'postal' => '54000', 'phone' => '+92-42-29292921', 'email' => 'support@myrishta.pk', 'line' => 'Shahdara, Lahore 54000' );
	}

	private static function cors() {
		header( 'Access-Control-Allow-Origin: *' );
		header( 'Access-Control-Allow-Methods: GET, POST, OPTIONS' );
		header( 'Access-Control-Allow-Headers: Content-Type, Accept, Mcp-Session-Id, MCP-Protocol-Version' );
	}

	private static function nocache() {
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		header( 'X-LiteSpeed-Cache-Control: no-cache' );
	}

	/* ---------- 5. MCP server + server card ---------- */

	public static function routes() {
		if ( ! self::on() ) {
			return;
		}
		$p = self::path();
		if ( '/.well-known/mcp/server-card.json' === $p || '/.well-known/mcp.json' === $p ) {
			self::cors();
			header( 'Content-Type: application/json; charset=utf-8' );
			header( 'Cache-Control: public, max-age=3600' );
			echo wp_json_encode( self::card(), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
			exit;
		}
		if ( '/mr-mcp' === $p ) {
			self::mcp();
			exit;
		}
	}

	private static function ver() {
		return defined( 'MRSH_VERSION' ) ? MRSH_VERSION : '1.0.0';
	}

	public static function card() {
		$ep = home_url( '/mr-mcp' );
		return array(
			'$schema'         => 'https://static.modelcontextprotocol.io/schemas/mcp-server-card/v1.json',
			'name'            => 'pk.myrishta/public',
			'title'           => 'MyRishta.pk public information',
			'description'     => 'Public, read-only information about MyRishta.pk, a free non-profit rishta and matrimonial service for Pakistani families: how it works, how to register, and a search of its public guides. No member data is available.',
			'version'         => self::ver(),
			'protocolVersion' => self::PROTO,
			'serverInfo'      => array( 'name' => 'pk.myrishta/public', 'title' => 'MyRishta.pk public information', 'version' => self::ver() ),
			'websiteUrl'      => home_url( '/' ),
			'endpoint'        => $ep,
			'transport'       => array( 'type' => 'streamable-http', 'endpoint' => $ep ),
			'authentication'  => array( 'required' => false ),
			'capabilities'    => array( 'tools' => array( 'listChanged' => false ) ),
			'tools'           => array_map(
				function ( $t ) {
					return array( 'name' => $t['name'], 'description' => $t['description'] );
				},
				self::tools()
			),
			'instructions'    => 'Use these tools for public facts about MyRishta.pk. Member profiles, messages and contact details are private and are never returned.',
		);
	}

	public static function tools() {
		return array(
			array(
				'name'        => 'site_info',
				'description' => 'Who runs MyRishta.pk, what it offers, its office address, phone, email and opening hours.',
				'inputSchema' => array( 'type' => 'object', 'properties' => new stdClass(), 'additionalProperties' => false ),
				'annotations' => array( 'readOnlyHint' => true, 'openWorldHint' => false ),
			),
			array(
				'name'        => 'search_guides',
				'description' => 'Search the public rishta guides and articles of MyRishta.pk. Returns title, link and a short summary.',
				'inputSchema' => array(
					'type'       => 'object',
					'properties' => array(
						'query' => array( 'type' => 'string', 'description' => 'Words to search for, for example "rishta process" or "documents for nikah".' ),
						'limit' => array( 'type' => 'integer', 'minimum' => 1, 'maximum' => 10, 'description' => 'How many results (default 5).' ),
					),
					'required'   => array( 'query' ),
				),
				'annotations' => array( 'readOnlyHint' => true, 'openWorldHint' => false ),
			),
			array(
				'name'        => 'how_to_register',
				'description' => 'Plain steps and links to create a free profile on MyRishta.pk and to contact the team.',
				'inputSchema' => array( 'type' => 'object', 'properties' => new stdClass(), 'additionalProperties' => false ),
				'annotations' => array( 'readOnlyHint' => true, 'openWorldHint' => false ),
			),
		);
	}

	public static function run_tool( $name, $a ) {
		$o = self::org();
		if ( 'site_info' === $name ) {
			$g     = class_exists( 'MRSH_Gbp' ) ? MRSH_Gbp::get() : array();
			$hours = ! empty( $g['hours'] ) ? $g['hours'] : 'Mo-Su 08:00-17:30';
			return "MyRishta.pk (My Rishta Pakistan)\n"
				. "A free, non-profit rishta and matrimonial service for Pakistani families in Pakistan and overseas.\n"
				. 'Website: ' . home_url( '/' ) . "\n"
				. 'Address: ' . $o['line'] . ( ! empty( $o['region'] ) ? ', ' . $o['region'] : '' ) . ", Pakistan\n"
				. 'Phone: ' . $o['phone'] . "\n"
				. 'Email: ' . $o['email'] . "\n"
				. 'Opening hours: ' . $hours . "\n"
				. "Languages: English, Urdu\n"
				. "Member profiles and messages are private and not available through this tool.\n";
		}
		if ( 'how_to_register' === $name ) {
			return "Create a free profile on MyRishta.pk:\n"
				. '1. Open ' . home_url( '/add-listing/' ) . " and sign in (Google sign-in or email).\n"
				. "2. Fill in the profile one short step at a time: about you, family, education and work, and what you look for.\n"
				. "3. Add a photo if you wish, then save.\n"
				. "4. Search other profiles and send an interest or a message from your account.\n"
				. "The service is free. Never send money, card or bank details to anyone you meet here.\n"
				. 'Help: ' . $o['email'] . ' / ' . $o['phone'] . "\n";
		}
		if ( 'search_guides' === $name ) {
			$q = isset( $a['query'] ) ? sanitize_text_field( (string) $a['query'] ) : '';
			$n = isset( $a['limit'] ) ? max( 1, min( 10, (int) $a['limit'] ) ) : 5;
			if ( '' === $q ) {
				return '';
			}
			$w   = new WP_Query( array( 'post_type' => 'post', 'post_status' => 'publish', 's' => $q, 'posts_per_page' => $n, 'no_found_rows' => true, 'ignore_sticky_posts' => true ) );
			$out = '';
			foreach ( $w->posts as $p ) {
				$out .= '- [' . wp_strip_all_tags( get_the_title( $p ) ) . '](' . get_permalink( $p ) . '): ' . wp_trim_words( wp_strip_all_tags( $p->post_excerpt ? $p->post_excerpt : $p->post_content ), 30 ) . ' (updated ' . get_post_modified_time( 'Y-m-d', true, $p ) . ")\n";
			}
			return '' === $out ? 'No public guide matched "' . $q . '".' : $out;
		}
		return null;
	}

	private static function rpc_one( $r ) {
		if ( ! is_array( $r ) || empty( $r['method'] ) ) {
			return array( 'jsonrpc' => '2.0', 'id' => null, 'error' => array( 'code' => -32600, 'message' => 'Invalid request' ) );
		}
		$has_id = array_key_exists( 'id', $r );
		$id     = $has_id ? $r['id'] : null;
		$m      = (string) $r['method'];
		$p      = isset( $r['params'] ) && is_array( $r['params'] ) ? $r['params'] : array();
		$ok     = function ( $res ) use ( $id ) {
			return array( 'jsonrpc' => '2.0', 'id' => $id, 'result' => $res );
		};
		$er     = function ( $c, $t ) use ( $id ) {
			return array( 'jsonrpc' => '2.0', 'id' => $id, 'error' => array( 'code' => $c, 'message' => $t ) );
		};
		if ( ! $has_id ) {
			return null; // notification: no reply.
		}
		switch ( $m ) {
			case 'initialize':
				$want = isset( $p['protocolVersion'] ) ? (string) $p['protocolVersion'] : '';
				$ver  = in_array( $want, array( '2025-06-18', '2025-03-26', '2024-11-05' ), true ) ? $want : self::PROTO;
				return $ok( array(
					'protocolVersion' => $ver,
					'capabilities'    => array( 'tools' => array( 'listChanged' => false ) ),
					'serverInfo'      => array( 'name' => 'pk.myrishta/public', 'title' => 'MyRishta.pk public information', 'version' => self::ver() ),
					'instructions'    => 'Public, read-only facts about MyRishta.pk. Member data is never returned.',
				) );
			case 'ping':
				return $ok( new stdClass() );
			case 'tools/list':
				return $ok( array( 'tools' => self::tools() ) );
			case 'tools/call':
				$name = isset( $p['name'] ) ? (string) $p['name'] : '';
				$args = isset( $p['arguments'] ) && is_array( $p['arguments'] ) ? $p['arguments'] : array();
				$t    = self::run_tool( $name, $args );
				if ( null === $t ) {
					return $er( -32602, 'Unknown tool: ' . $name );
				}
				return $ok( array( 'content' => array( array( 'type' => 'text', 'text' => $t ) ), 'isError' => false ) );
		}
		return $er( -32601, 'Method not found' );
	}

	private static function mcp() {
		self::cors();
		self::nocache();
		$meth = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( (string) $_SERVER['REQUEST_METHOD'] ) : 'GET'; // phpcs:ignore
		if ( 'OPTIONS' === $meth ) {
			status_header( 204 );
			return;
		}
		if ( 'POST' !== $meth ) {
			status_header( 405 );
			header( 'Allow: POST, OPTIONS' );
			header( 'Content-Type: application/json; charset=utf-8' );
			echo wp_json_encode( array( 'jsonrpc' => '2.0', 'id' => null, 'error' => array( 'code' => -32000, 'message' => 'Send JSON-RPC requests with POST.' ) ) );
			return;
		}
		// Light rate limit: 90 calls a minute for each visitor address.
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : ''; // phpcs:ignore
		$rk = 'mrsh_mcp_' . md5( $ip );
		$c  = (int) get_transient( $rk );
		if ( $c >= 90 ) {
			status_header( 429 );
			header( 'Retry-After: 60' );
			return;
		}
		set_transient( $rk, $c + 1, MINUTE_IN_SECONDS );
		$raw = file_get_contents( 'php://input' );
		$req = json_decode( (string) $raw, true );
		header( 'Content-Type: application/json; charset=utf-8' );
		if ( ! is_array( $req ) ) {
			status_header( 400 );
			echo wp_json_encode( array( 'jsonrpc' => '2.0', 'id' => null, 'error' => array( 'code' => -32700, 'message' => 'Parse error' ) ) );
			return;
		}
		if ( isset( $req[0] ) ) {
			$res = array();
			foreach ( array_slice( $req, 0, 20 ) as $r ) {
				$x = self::rpc_one( $r );
				if ( null !== $x ) {
					$res[] = $x;
				}
			}
			if ( ! $res ) {
				status_header( 202 );
				return;
			}
			echo wp_json_encode( $res, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
			return;
		}
		$x = self::rpc_one( $req );
		if ( null === $x ) {
			status_header( 202 );
			return;
		}
		echo wp_json_encode( $x, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
	}

	/* ---------- 4. WebMCP (in-browser agents) ---------- */

	public static function webmcp() {
		if ( ! self::on() || is_admin() || is_feed() ) {
			return;
		}
		$t = array();
		foreach ( self::tools() as $x ) {
			$t[] = array( 'name' => $x['name'], 'description' => $x['description'], 'inputSchema' => $x['inputSchema'], 'annotations' => $x['annotations'] );
		}
		echo '<script id="mrsh-webmcp">(function(){try{var T=' . wp_json_encode( $t, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . ',EP=' . wp_json_encode( home_url( '/mr-mcp' ) ) . ';'
			. 'function call(n,a){return fetch(EP,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({jsonrpc:"2.0",id:1,method:"tools/call",params:{name:n,arguments:a||{}}})}).then(function(r){return r.json()}).then(function(r){return r.result||{content:[{type:"text",text:(r.error&&r.error.message)||"Error"}],isError:true}})}'
			. 'function reg(){var mc=navigator.modelContext;if(!mc||typeof mc.registerTool!=="function")return;T.forEach(function(t){try{mc.registerTool({name:t.name,description:t.description,inputSchema:t.inputSchema,annotations:t.annotations,execute:function(a){return call(t.name,a)}})}catch(e){}})}'
			. 'reg()}catch(e){}})();</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	/* ---------- 3. Markdown for agents ---------- */

	private static function wants_md() {
		if ( isset( $_GET['mrsh_md'] ) ) { // phpcs:ignore
			return true;
		}
		$a = isset( $_SERVER['HTTP_ACCEPT'] ) ? strtolower( (string) $_SERVER['HTTP_ACCEPT'] ) : ''; // phpcs:ignore
		if ( false === strpos( $a, 'text/markdown' ) ) {
			return false;
		}
		$qm = 1.0;
		if ( preg_match( '#text/markdown\s*(?:;\s*q=([0-9.]+))?#', $a, $m ) && isset( $m[1] ) ) {
			$qm = (float) $m[1];
		}
		$qh = 0.0;
		if ( preg_match( '#text/html\s*(?:;\s*q=([0-9.]+))?#', $a, $h ) ) {
			$qh = isset( $h[1] ) ? (float) $h[1] : 1.0;
		}
		return $qm > 0 && $qm >= $qh;
	}

	private static function md_ok() {
		if ( is_admin() || is_feed() || is_search() || is_404() || is_user_logged_in() ) {
			return false;
		}
		if ( is_front_page() || is_home() || is_category() || is_tag() ) {
			return true;
		}
		if ( is_singular( array( 'post', 'page' ) ) ) {
			$p = get_queried_object();
			return $p && ! in_array( $p->post_name, array( 'my-account', 'add-listing', 'login', 'register', 'checkout', 'cart' ), true );
		}
		return false; // member profiles and their lists stay HTML-only and private.
	}

	public static function head_links() {
		if ( ! self::on() || ! self::md_ok() ) {
			return;
		}
		$u = is_singular() ? get_permalink() : ( is_front_page() ? home_url( '/' ) : '' );
		if ( $u ) {
			echo '<link rel="alternate" type="text/markdown" href="' . esc_url( add_query_arg( 'mrsh_md', '1', $u ) ) . '">' . "\n";
		}
	}

	public static function markdown() {
		if ( ! self::on() || ! self::wants_md() || ! self::md_ok() ) {
			return;
		}
		$url   = is_singular() ? get_permalink() : ( is_front_page() ? home_url( '/' ) : home_url( strtok( isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '/', '?' ) ) ); // phpcs:ignore
		$title = html_entity_decode( is_singular() ? get_the_title() : ( is_front_page() ? get_bloginfo( 'name' ) : wp_strip_all_tags( wp_get_document_title() ) ), ENT_QUOTES, 'UTF-8' );
		$desc  = '';
		$body  = '';
		if ( is_singular() ) {
			$p     = get_queried_object();
			$desc  = wp_trim_words( wp_strip_all_tags( $p->post_excerpt ? $p->post_excerpt : $p->post_content ), 35 );
			$body  = self::to_md( apply_filters( 'the_content', $p->post_content ) ); // phpcs:ignore
			$mod   = get_post_modified_time( 'c', true, $p );
		} else {
			$mod  = gmdate( 'c' );
			$desc = html_entity_decode( (string) get_bloginfo( 'description' ), ENT_QUOTES, 'UTF-8' );
			$o    = self::org();
			if ( is_front_page() ) {
				$body .= "MyRishta.pk is a free, non-profit rishta and matrimonial service for Pakistani families in Pakistan and overseas, run by My Rishta Pakistan in " . $o['line'] . ", Pakistan.\n\n";
				$body .= "## Start here\n\n- [Create a free profile](" . home_url( '/add-listing/' ) . ")\n- [Search profiles](" . home_url( '/?post_type=listing_type&s=' ) . ")\n\n";
			}
			$w = new WP_Query( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 20, 'no_found_rows' => true, 'ignore_sticky_posts' => true ) );
			if ( is_category() || is_tag() ) {
				$w = new WP_Query( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 20, 'no_found_rows' => true, 'cat' => is_category() ? get_queried_object_id() : 0, 'tag_id' => is_tag() ? get_queried_object_id() : 0 ) );
			}
			if ( $w->posts ) {
				$body .= "## Guides and articles\n\n";
				foreach ( $w->posts as $x ) {
					$body .= '- [' . wp_strip_all_tags( get_the_title( $x ) ) . '](' . get_permalink( $x ) . ')' . "\n";
				}
				$body .= "\n";
			}
			$body .= "## Contact\n\n" . $o['email'] . ' / ' . $o['phone'] . "\n";
		}
		$md  = "---\ntitle: " . str_replace( array( "\r", "\n", ':' ), array( ' ', ' ', ' -' ), wp_strip_all_tags( (string) $title ) ) . "\nurl: " . $url . "\n";
		if ( $desc ) {
			$md .= 'description: ' . str_replace( array( "\r", "\n" ), ' ', $desc ) . "\n";
		}
		$md .= 'lastmod: ' . $mod . "\n---\n\n# " . wp_strip_all_tags( (string) $title ) . "\n\n" . trim( $body ) . "\n";
		self::nocache();
		self::cors();
		status_header( 200 );
		header( 'Content-Type: text/markdown; charset=utf-8' );
		header( 'Vary: Accept' );
		header( 'Content-Signal: ' . apply_filters( 'mrsh_content_signal', self::SIGNAL ) );
		header( 'X-Markdown-Tokens: ' . (int) ceil( strlen( $md ) / 4 ) );
		header( 'X-Robots-Tag: noindex' );
		echo $md; // phpcs:ignore WordPress.Security.EscapeOutput
		exit;
	}

	/** Small, safe HTML to Markdown converter (headings, paragraphs, lists, links, bold, italic, quotes, code). */
	public static function to_md( $html ) {
		$h = (string) $html;
		$h = preg_replace( '#<(script|style|noscript|svg|form|iframe|nav|button|select|textarea)\b.*?</\1>#is', '', $h );
		$h = preg_replace_callback( '#<h([1-6])[^>]*>(.*?)</h\1>#is', function ( $m ) {
			return "\n\n" . str_repeat( '#', (int) $m[1] ) . ' ' . trim( wp_strip_all_tags( $m[2] ) ) . "\n\n";
		}, $h );
		$h = preg_replace_callback( '#<a\b[^>]*href=["\']([^"\']+)["\'][^>]*>(.*?)</a>#is', function ( $m ) {
			$t = trim( wp_strip_all_tags( $m[2] ) );
			$u = $m[1];
			if ( '' === $t || 0 === strpos( $u, '#' ) || 0 === stripos( $u, 'javascript:' ) ) {
				return $t;
			}
			if ( 0 === strpos( $u, '/' ) && 0 !== strpos( $u, '//' ) ) {
				$u = home_url( $u );
			}
			return '[' . $t . '](' . $u . ')';
		}, $h );
		$h = preg_replace( '#<(strong|b)\b[^>]*>(.*?)</\1>#is', '**$2**', $h );
		$h = preg_replace( '#<(em|i)\b[^>]*>(.*?)</\1>#is', '*$2*', $h );
		$h = preg_replace( '#<code\b[^>]*>(.*?)</code>#is', '`$1`', $h );
		$h = preg_replace( '#<blockquote\b[^>]*>(.*?)</blockquote>#is', "\n\n> $1\n\n", $h );
		$h = preg_replace( '#<li\b[^>]*>#i', "\n- ", $h );
		$h = preg_replace( '#<br\s*/?>#i', "\n", $h );
		$h = preg_replace( '#</(p|div|ul|ol|tr|table|section|article|figure|h[1-6])>#i', "\n\n", $h );
		$h = preg_replace( '#</t[dh]>#i', ' | ', $h );
		$h = html_entity_decode( wp_strip_all_tags( $h ), ENT_QUOTES, 'UTF-8' );
		$h = preg_replace( "/[ \t]+\n/", "\n", $h );
		$h = preg_replace( "/\n{3,}/", "\n\n", $h );
		return trim( (string) $h );
	}

	/* ---------- LiteSpeed: keep the Markdown copy apart from the cached HTML ---------- */

	public static function htaccess() {
		if ( ! self::on() || ! current_user_can( 'manage_options' ) || get_option( 'mrsh_ar_ht' ) === self::ver() ) {
			return;
		}
		update_option( 'mrsh_ar_ht', self::ver(), false );
		$f = ABSPATH . '.htaccess';
		if ( ! is_file( $f ) || ! is_writable( $f ) ) { // phpcs:ignore
			return;
		}
		$c = (string) file_get_contents( $f ); // phpcs:ignore
		if ( false !== strpos( $c, '# BEGIN MyRishta Agent' ) || false === strpos( $c, 'LiteSpeed' ) ) {
			return;
		}
		$blk = "# BEGIN MyRishta Agent\n<IfModule LiteSpeed>\nRewriteEngine on\nRewriteCond %{HTTP:Accept} text/markdown [NC]\nRewriteRule .* - [E=Cache-Control:vary=mdagent]\n</IfModule>\n# END MyRishta Agent\n\n";
		@copy( $f, $f . '.mrsh-bak' ); // phpcs:ignore
		file_put_contents( $f, $blk . $c ); // phpcs:ignore
	}
}
MRSH_Agentready::init();
