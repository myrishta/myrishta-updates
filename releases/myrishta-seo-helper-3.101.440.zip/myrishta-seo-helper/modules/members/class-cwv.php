<?php
/**
 * Speed agent (Core Web Vitals): keeps the page cache warm, reads what real visitors experience from Google,
 * tells you in plain words what is slow and why, and emails you when the Core Web Vitals result changes.
 *  - Cache warmer: after a cache purge, an update or every few hours, the main public pages are opened once so the first real visitor
 *    gets a cached page (a cache miss is what makes the server response slow). It records hit or miss for each page.
 *  - Real visitor data: Google PageSpeed API (loadingExperience = Chrome real-user data, last 28 days). Checked weekly.
 * It cannot move the server closer to the visitors; when the delay is distance it says so.
 * Option mrsh_cwv: array( warm => array( t, n, hit, avg, rows, off ), field => array( t, cat, m ), hist => array(), mail => cat ).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Cwv {

	const OPT  = 'mrsh_cwv';
	const HOOK = 'mrsh_cwv_tick';

	public static function get() {
		return array_merge( array( 'warm' => array(), 'field' => array(), 'hist' => array(), 'mail' => '' ), (array) get_option( self::OPT, array() ) );
	}

	private static function put( $o ) {
		update_option( self::OPT, $o, false );
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 32 );
		add_action( 'admin_post_mrsh_cwv_warm', array( __CLASS__, 'act_warm' ) );
		add_action( 'admin_post_mrsh_cwv_field', array( __CLASS__, 'act_field' ) );
		add_action( self::HOOK, array( __CLASS__, 'tick' ) );
		add_action( 'mrsh_cwv_after_purge', array( __CLASS__, 'warm_cron' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
		foreach ( array( 'litespeed_purged_all', 'litespeed_purged_post', 'upgrader_process_complete', 'activated_plugin', 'switch_theme' ) as $h ) {
			add_action( $h, array( __CLASS__, 'after_purge' ) );
		}
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Speed agent', 'Speed agent', 'manage_options', 'mrsh-cwv', array( __CLASS__, 'page' ) );
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + 600, 'hourly', self::HOOK );
		}
	}

	/** A purge or update empties the cache: start filling it again from the first page, in about a minute. */
	public static function after_purge() {
		$o = self::get();
		$o['warm']['off'] = 0;
		self::put( $o );
		if ( ! wp_next_scheduled( 'mrsh_cwv_after_purge' ) ) {
			wp_schedule_single_event( time() + 90, 'mrsh_cwv_after_purge' );
		}
	}

	/* ---------- cache warmer ---------- */

	/** The public pages worth keeping warm: home, main pages and the newest articles. */
	public static function urls() {
		$u    = array( home_url( '/' ) );
		$skip = array( 'my-account', 'add-listing', 'login', 'register', 'registration', 'forgot-password', 'chat', 'chatroom', 'callback', 'logout', 'checkout', 'cart' );
		foreach ( get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 'posts_per_page' => 20, 'orderby' => 'menu_order date', 'order' => 'ASC', 'no_found_rows' => true, 'has_password' => false ) ) as $p ) {
			if ( in_array( $p->post_name, $skip, true ) || get_post_meta( $p->ID, '_mrsh_noindex', true ) ) {
				continue;
			}
			$u[] = get_permalink( $p );
		}
		foreach ( get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 8, 'no_found_rows' => true, 'has_password' => false ) ) as $p ) {
			$u[] = get_permalink( $p );
		}
		return array_values( array_unique( array_filter( $u ) ) );
	}

	/** Opens pages one after another until the time budget is used. Returns how many were done. */
	public static function warm( $budget = 30 ) {
		if ( class_exists( 'MRSH_Maint' ) && MRSH_Maint::active() ) { // visitors get the "back soon" page now, nothing useful to warm
			return 0;
		}
		$o    = self::get();
		$list = self::urls();
		if ( ! $list ) {
			return 0;
		}
		$w     = (array) $o['warm'];
		$rows  = (array) ( $w['rows'] ?? array() );
		$off   = (int) ( $w['off'] ?? 0 ) % count( $list );
		$start = microtime( true );
		$done  = 0;
		for ( $i = 0; $i < count( $list ); $i++ ) {
			if ( microtime( true ) - $start > $budget ) {
				break;
			}
			$u  = $list[ ( $off + $i ) % count( $list ) ];
			$t0 = microtime( true );
			$r  = wp_remote_get( $u, array( 'timeout' => 20, 'redirection' => 3, 'user-agent' => 'MyRishta-SpeedAgent (cache warmer)', 'headers' => array( 'Accept-Encoding' => 'gzip' ) ) );
			$ms = (int) round( ( microtime( true ) - $t0 ) * 1000 );
			if ( is_wp_error( $r ) ) {
				$rows[ $u ] = array( 'ms' => $ms, 'hit' => '', 'code' => 0 );
			} else {
				$h          = strtolower( (string) wp_remote_retrieve_header( $r, 'x-litespeed-cache' ) );
				$rows[ $u ] = array( 'ms' => $ms, 'hit' => false !== strpos( $h, 'hit' ) ? 'hit' : ( false !== strpos( $h, 'miss' ) ? 'miss' : '' ), 'code' => (int) wp_remote_retrieve_response_code( $r ) );
			}
			++$done;
		}
		$rows = array_intersect_key( $rows, array_flip( $list ) );
		$seen = array_filter( $rows, function ( $r ) { return '' !== $r['hit']; } );
		$hits = count( array_filter( $seen, function ( $r ) { return 'hit' === $r['hit']; } ) );
		$ms   = array_column( $rows, 'ms' );
		$o['warm'] = array( 't' => time(), 'n' => $done, 'hit' => $seen ? (int) round( 100 * $hits / count( $seen ) ) : -1, 'avg' => $ms ? (int) round( array_sum( $ms ) / count( $ms ) ) : 0, 'rows' => $rows, 'off' => ( $off + $done ) % count( $list ) );
		self::put( $o );
		return $done;
	}

	public static function warm_cron() {
		if ( ! get_transient( 'mrsh_cwv_lock' ) ) {
			set_transient( 'mrsh_cwv_lock', 1, 10 * MINUTE_IN_SECONDS );
			self::warm( 40 );
			delete_transient( 'mrsh_cwv_lock' );
		}
	}

	/* ---------- real visitor data from Google ---------- */

	private static function key() {
		$k = trim( (string) get_option( 'mrsh_psi_key', '' ) );
		if ( '' === $k ) {
			$wk = (array) get_option( 'mrsh_keys', array() );
			$k  = trim( (string) ( $wk['psi_key'] ?? '' ) );
		}
		return $k;
	}

	/** Returns array( cat, m ) or an error string. cat: FAST, AVERAGE, SLOW or NONE. */
	public static function fetch_field() {
		$q = add_query_arg( array( 'url' => home_url( '/' ), 'strategy' => 'mobile', 'category' => 'performance' ), 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed' );
		if ( self::key() ) {
			$q .= '&key=' . rawurlencode( self::key() );
		}
		$r = wp_remote_get( $q, array( 'timeout' => 60 ) );
		if ( is_wp_error( $r ) ) {
			return 'Could not reach Google: ' . $r->get_error_message();
		}
		$d = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( self::key() && is_array( $d ) && ! empty( $d['error'] ) && false !== stripos( (string) ( $d['error']['message'] ?? '' ), 'api key' ) ) {
			// the saved key is expired or wrong: Google still answers without a key (a lower free limit is enough for one check a week)
			$r = wp_remote_get( remove_query_arg( 'key', $q ), array( 'timeout' => 60 ) );
			if ( is_wp_error( $r ) ) {
				return 'Could not reach Google: ' . $r->get_error_message();
			}
			$d = json_decode( wp_remote_retrieve_body( $r ), true );
			update_option( 'mrsh_cwv_keybad', time(), false );
		}
		if ( ! is_array( $d ) || ! empty( $d['error'] ) ) {
			return 'Google did not answer: ' . sanitize_text_field( (string) ( $d['error']['message'] ?? 'try again in a few minutes' ) );
		}
		$le = ! empty( $d['loadingExperience']['metrics'] ) ? $d['loadingExperience'] : ( $d['originLoadingExperience'] ?? array() );
		if ( empty( $le['metrics'] ) ) {
			return array( 'cat' => 'NONE', 'm' => array() );
		}
		$map = array( 'lcp' => 'LARGEST_CONTENTFUL_PAINT_MS', 'inp' => 'INTERACTION_TO_NEXT_PAINT', 'cls' => 'CUMULATIVE_LAYOUT_SHIFT_SCORE', 'fcp' => 'FIRST_CONTENTFUL_PAINT_MS', 'ttfb' => 'EXPERIMENTAL_TIME_TO_FIRST_BYTE' );
		$m   = array();
		foreach ( $map as $k => $g ) {
			if ( isset( $le['metrics'][ $g ]['percentile'] ) ) {
				$v        = (float) $le['metrics'][ $g ]['percentile'];
				$m[ $k ] = array( 'v' => 'cls' === $k ? $v / 100 : $v, 'c' => (string) ( $le['metrics'][ $g ]['category'] ?? '' ) );
			}
		}
		return array( 'cat' => (string) ( $le['overall_category'] ?? 'NONE' ), 'm' => $m );
	}

	public static function check_field() {
		$f = self::fetch_field();
		if ( ! is_array( $f ) ) {
			return $f;
		}
		$o              = self::get();
		$o['field']     = array( 't' => time(), 'cat' => $f['cat'], 'm' => $f['m'] );
		$o['hist'][]    = array( 't' => time(), 'cat' => $f['cat'], 'lcp' => $f['m']['lcp']['v'] ?? 0, 'ttfb' => $f['m']['ttfb']['v'] ?? 0 );
		$o['hist']      = array_slice( $o['hist'], -12 );
		if ( $o['mail'] && $o['mail'] !== $f['cat'] && 'NONE' !== $f['cat'] ) {
			wp_mail( get_option( 'admin_email' ), 'Core Web Vitals changed: ' . self::cat_label( $f['cat'] ), "Real visitors now give the home page this Core Web Vitals result: " . self::cat_label( $f['cat'] ) . ".\n\nOpen the Speed agent for the details and what to do:\n" . admin_url( 'admin.php?page=mrsh-cwv' ) );
		}
		$o['mail'] = 'NONE' === $f['cat'] ? $o['mail'] : $f['cat'];
		self::put( $o );
		return true;
	}

	/** Hourly: keep the cache warm; once a week read the real visitor data. */
	public static function tick() {
		self::warm_cron();
		$o = self::get();
		if ( time() - (int) ( $o['field']['t'] ?? 0 ) > 7 * DAY_IN_SECONDS ) {
			self::check_field();
		}
	}

	/* ---------- admin actions ---------- */

	private static function guard( $n ) {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( $n ) ) {
			wp_die( 'Not allowed.' );
		}
	}

	public static function act_warm() {
		self::guard( 'mrsh_cwv_warm' );
		$o = self::get();
		$o['warm']['off'] = 0;
		self::put( $o );
		$n = self::warm( 20 );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-cwv&warmed=' . (int) $n ) );
		exit;
	}

	public static function act_field() {
		self::guard( 'mrsh_cwv_field' );
		$r = self::check_field();
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-cwv&' . ( true === $r ? 'checked=1' : 'err=' . rawurlencode( (string) $r ) ) ) );
		exit;
	}

	/* ---------- page ---------- */

	private static function cat_label( $c ) {
		return array( 'FAST' => 'Passed', 'AVERAGE' => 'Needs improvement', 'SLOW' => 'Failed' )[ $c ] ?? 'Not enough data';
	}

	private static function fmt( $k, $v ) {
		if ( 'cls' === $k ) {
			return number_format( (float) $v, 2 );
		}
		return $v >= 1000 && 'inp' !== $k ? number_format( $v / 1000, 1 ) . ' s' : (int) $v . ' ms';
	}

	/** Plain-words findings from the numbers. */
	public static function advice( $o ) {
		$m   = (array) ( $o['field']['m'] ?? array() );
		$hit = (int) ( $o['warm']['hit'] ?? -1 );
		$out = array();
		$ttfb = (float) ( $m['ttfb']['v'] ?? 0 );
		if ( $ttfb > 800 ) {
			if ( $hit >= 0 && $hit < 80 ) {
				$out[] = array( 'bad', 'Many pages are not coming from the cache (' . $hit . '% served from cache). The agent keeps filling the cache; avoid purging the cache or uploading updates often, because each one empties it.' );
			} else {
				$hist = array_values( array_filter( (array) ( $o['hist'] ?? array() ), function ( $r ) { return ! empty( $r['ttfb'] ); } ) );
				$trend = '';
				if ( count( $hist ) >= 3 ) {
					$first = (float) $hist[ max( 0, count( $hist ) - 6 ) ]['ttfb'];
					$last  = (float) $hist[ count( $hist ) - 1 ]['ttfb'];
					if ( $first > 0 && $last < $first * 0.9 ) {
						$trend = ' Good sign: it has already come down from ' . number_format( $first / 1000, 1 ) . ' s to ' . number_format( $last / 1000, 1 ) . ' s.';
					}
				}
				$out[] = array( 'warn', 'The first response is slow in Google\'s real-visitor data (' . self::fmt( 'ttfb', $ttfb ) . '), even though the cache works (' . ( $hit >= 0 ? $hit . '% from cache' : 'cache status unknown' ) . '). Google averages the last 28 days, so if the hosting was moved to a nearer data centre (Malaysia) recently, this number still contains the old, slower weeks and will improve a little each week.' . $trend . ' Nothing to do now. If it is still slow about 4 weeks after the move, put the free Cloudflare plan in front.' );
			}
		}
		if ( isset( $m['lcp'] ) && $m['lcp']['v'] > 2500 ) {
			$out[] = array( $ttfb > 800 ? 'warn' : 'bad', $ttfb > 800 ? 'The largest picture or heading appears late (' . self::fmt( 'lcp', $m['lcp']['v'] ) . '), mostly because of the slow first response in the same 28-day data. It should improve together with it.' : 'The largest picture or heading appears late (' . self::fmt( 'lcp', $m['lcp']['v'] ) . ') while the server is fast. Check the top picture size and the styles that block drawing.' );
		}
		if ( isset( $m['inp'] ) && $m['inp']['v'] > 200 ) {
			$out[] = array( 'bad', 'Taps feel slow (' . self::fmt( 'inp', $m['inp']['v'] ) . '). Too much script runs on the page; the Google Ads tag is already delayed.' );
		}
		if ( isset( $m['cls'] ) && $m['cls']['v'] > 0.1 ) {
			$out[] = array( 'bad', 'The page jumps while loading. Give pictures and banners a fixed size.' );
		}
		if ( ! $out && $m ) {
			$out[] = array( 'ok', 'Nothing to fix: real visitors are getting a good experience.' );
		}
		if ( ! $m ) {
			$out[] = array( 'warn', 'Google has no real-visitor data yet. Press "Check real visitors now" later, or wait a week.' );
		}
		return $out;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) || ! class_exists( 'MRSH_Boost' ) ) {
			return;
		}
		$o = self::get();
		$f = (array) $o['field'];
		$w = (array) $o['warm'];
		$m = (array) ( $f['m'] ?? array() );
		MRSH_Boost::ui_open( 'Speed agent', 'Keeps the cache warm, reads what real visitors experience from Google, and tells you in plain words what is slow and why.', 'g-gold', 'M13 2L3 14h8l-1 8 10-12h-8z' );
		if ( isset( $_GET['checked'] ) ) { // phpcs:ignore
			MRSH_Boost::ui_ok( 'Real visitor data updated.' );
		}
		if ( isset( $_GET['warmed'] ) ) { // phpcs:ignore
			MRSH_Boost::ui_ok( absint( $_GET['warmed'] ) . ' pages warmed.' ); // phpcs:ignore
		}
		if ( ! empty( $_GET['err'] ) ) { // phpcs:ignore
			echo '<div class="mx-ok" style="background:#fef3f2;color:#912018;box-shadow:0 0 0 1px #fecdca">' . esc_html( sanitize_text_field( wp_unslash( $_GET['err'] ) ) ) . '</div>'; // phpcs:ignore
		}
		if ( get_option( 'mrsh_cwv_keybad' ) && self::key() ) {
			echo '<div class="mx-ok" style="background:#fffaeb;color:#93370d;box-shadow:0 0 0 1px #fedf89;display:block"><b>Your Google PageSpeed key has expired.</b> The agent checked without it, so it still works, but with a lower free limit. Make a new key (Website keys page, Google PageSpeed: Enable API, then create key) or tick "remove this key" there and on the PageSpeed page.</div>';
		}
		$cat = (string) ( $f['cat'] ?? '' );
		$col = array( 'FAST' => '#10b981', 'AVERAGE' => '#f59e0b', 'SLOW' => '#e11d48' )[ $cat ] ?? '#9ca3af';
		echo '<div class="mx-stats">' . MRSH_Boost::ui_stat( self::cat_label( $cat ), 'Core Web Vitals (real visitors)', $col ) . MRSH_Boost::ui_stat( isset( $m['lcp'] ) ? self::fmt( 'lcp', $m['lcp']['v'] ) : '-', 'Largest content (LCP)', '#4a69d6' ) . MRSH_Boost::ui_stat( isset( $m['ttfb'] ) ? self::fmt( 'ttfb', $m['ttfb']['v'] ) : '-', 'First response (TTFB)', '#e11d74' ) . MRSH_Boost::ui_stat( isset( $w['hit'] ) && $w['hit'] >= 0 ? $w['hit'] . '%' : '-', 'Pages served from cache', '#10b981' ) . '</div>'; // phpcs:ignore

		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">1</span><h2>What the agent found</h2></div>';
		foreach ( self::advice( $o ) as $a ) {
			echo '<div class="mx-rep"><div class="who"><span class="mx-pill ' . ( 'ok' === $a[0] ? 'ok' : ( 'bad' === $a[0] ? 'bad' : 'warn' ) ) . '">' . ( 'ok' === $a[0] ? 'Good' : ( 'bad' === $a[0] ? 'Fix' : 'Note' ) ) . '</span> ' . esc_html( $a[1] ) . '</div></div>';
		}
		echo '<p class="mx-note">Real visitor data is the last 28 days, so changes show up slowly. The agent cannot move the server closer to your visitors; it tells you when that is the cause.</p></div>';

		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">2</span><h2>Real visitors, last 28 days</h2></div>';
		if ( $m ) {
			echo '<table class="widefat striped" style="max-width:760px"><thead><tr><th>Measure</th><th>Result</th><th>Good is</th><th>Rating</th></tr></thead><tbody>';
			$rows = array( 'lcp' => array( 'Largest content (LCP)', 'under 2.5 s' ), 'inp' => array( 'Tap response (INP)', 'under 200 ms' ), 'cls' => array( 'Page jumping (CLS)', 'under 0.1' ), 'fcp' => array( 'First paint (FCP)', 'under 1.8 s' ), 'ttfb' => array( 'First response (TTFB)', 'under 0.8 s' ) );
			foreach ( $rows as $k => $r ) {
				if ( isset( $m[ $k ] ) ) {
					$c = $m[ $k ]['c'];
					echo '<tr data-attn="0"><td>' . esc_html( $r[0] ) . '</td><td><b>' . esc_html( self::fmt( $k, $m[ $k ]['v'] ) ) . '</b></td><td>' . esc_html( $r[1] ) . '</td><td><span class="mx-pill ' . ( 'FAST' === $c ? 'ok' : ( 'SLOW' === $c ? 'bad' : 'warn' ) ) . '">' . esc_html( self::cat_label( $c ) ) . '</span></td></tr>';
				}
			}
			echo '</tbody></table><p class="mx-note">Checked ' . esc_html( human_time_diff( (int) $f['t'] ) ) . ' ago. It is checked again every week by itself, and you get an email when the result changes.</p>';
		} else {
			echo '<div class="mx-empty"><b>No data yet</b><p>Press the button below. Google needs enough real visits before it shows numbers.</p></div>';
		}
		echo '<div class="mx-acts"><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'mrsh_cwv_field' );
		echo '<input type="hidden" name="action" value="mrsh_cwv_field"><button class="mx-btn p">Check real visitors now</button></form></div></div>';

		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">3</span><h2>Cache warmer</h2></div><p class="mx-sub">After every cache purge or update, and every hour, the agent opens the main public pages so the first real visitor gets a ready page. ' . ( ! empty( $w['t'] ) ? 'Last run ' . esc_html( human_time_diff( (int) $w['t'] ) ) . ' ago, average ' . (int) $w['avg'] . ' ms per page.' : 'It has not run yet.' ) . '</p>';
		if ( ! empty( $w['rows'] ) ) {
			$rs = (array) $w['rows'];
			uasort( $rs, function ( $a, $b ) { return $b['ms'] <=> $a['ms']; } );
			echo '<table class="widefat striped" style="max-width:860px"><thead><tr><th>Page</th><th>Time</th><th>Cache</th></tr></thead><tbody>';
			foreach ( array_slice( $rs, 0, 10, true ) as $u => $r ) {
				echo '<tr data-attn="0"><td>' . esc_html( preg_replace( '#^https?://[^/]+#', '', $u ) ?: '/' ) . '</td><td>' . (int) $r['ms'] . ' ms</td><td><span class="mx-pill ' . ( 'hit' === $r['hit'] ? 'ok' : ( 'miss' === $r['hit'] ? 'warn' : '' ) ) . '">' . esc_html( $r['hit'] ? $r['hit'] : 'unknown' ) . '</span></td></tr>';
			}
			echo '</tbody></table><p class="mx-note">The ten slowest pages. "Cache: miss" means that page was not ready yet; it is ready after this visit.</p>';
		}
		echo '<div class="mx-acts"><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'mrsh_cwv_warm' );
		echo '<input type="hidden" name="action" value="mrsh_cwv_warm"><button class="mx-btn p">Warm the cache now</button></form></div></div></div>';
	}
}
MRSH_Cwv::init();
