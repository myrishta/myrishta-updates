<?php
/**
 * Rishta Agencies: approved volunteers who help families that do not know how to use the site.
 * A helper makes a separate account for each family (with the family's agreement), fills in the profile,
 * and can open it again later to answer messages. Free only: helpers may not charge families.
 * Each managed account has user meta mrt_helper = helper's user id. A helper is approved by the admin
 * (user meta mrsh_helper: pending, ok, off).
 *
 * @package MyRishta_SEO_Helper
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Community {

	const MAX    = 50; // profiles one helper can look after
	const DAILY  = 10; // new family profiles a helper can start per day
	const COOKIE = 'mrsh_hp_back';

	public static function init() {
		add_action( 'mrt_account_extra', array( __CLASS__, 'account' ), 12 );
		add_action( 'admin_post_mrsh_hp_apply', array( __CLASS__, 'apply' ) );
		add_action( 'admin_post_mrsh_hp_new', array( __CLASS__, 'create' ) );
		add_action( 'admin_post_mrsh_hp_switch', array( __CLASS__, 'go' ) );
		add_action( 'admin_post_mrsh_hp_fam', array( __CLASS__, 'fam_act' ) );
		add_filter( 'wp_mail', array( __CLASS__, 'route_mail' ) );
		add_filter( 'mrt_prefill_phone', array( __CLASS__, 'prefill_phone' ), 10, 2 );
		add_action( 'admin_post_mrsh_hp_back', array( __CLASS__, 'back_action' ) );
		add_action( 'wp_footer', array( __CLASS__, 'bar' ), 90 );
		add_action( 'mrt_profile_after', array( __CLASS__, 'label' ), 7 );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 32 );
		add_action( 'admin_post_mrsh_hp_admin', array( __CLASS__, 'admin_act' ) );
	}

	/* ---------- admin page: Rishta Agencies ---------- */

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Rishta Agencies', 'Rishta Agencies', 'manage_options', 'mrsh-helpers', array( __CLASS__, 'page' ) );
	}

	private static function status_label( $p ) {
		if ( ! $p ) {
			return array( 'No profile yet', '#6b7280' );
		}
		switch ( $p->post_status ) {
			case 'publish':
				return array( 'Live', '#10b981' );
			case 'draft':
				return array( 'Draft', '#f59e0b' );
			case 'pending':
			case 'pending_approval':
			case 'payment':
				return array( 'Waiting approval', '#4a69d6' );
			case 'expired':
				return array( 'Expired', '#e11d48' );
		}
		return array( 'Closed', '#6b7280' );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		if ( ! class_exists( 'MRSH_Boost' ) ) {
			echo '<div class="wrap"><h1>Rishta Agencies</h1><p>The page styles are missing. Reinstall the plugin zip.</p></div>';
			return;
		}
		$all  = get_users( array( 'meta_key' => 'mrsh_helper', 'meta_compare' => 'EXISTS', 'number' => 300, 'orderby' => 'registered', 'order' => 'DESC' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		$pend = array();
		$ok   = array();
		$off  = array();
		foreach ( $all as $u ) {
			$st = self::status( $u->ID );
			if ( 'pending' === $st ) {
				$pend[] = $u;
			} elseif ( 'ok' === $st ) {
				$ok[] = $u;
			} elseif ( 'off' === $st ) {
				$off[] = $u;
			}
		}
		$tot = array( 'Live' => 0, 'Draft' => 0, 'Waiting approval' => 0, 'Expired' => 0, 'Closed' => 0, 'No profile yet' => 0 );
		$blk = '';
		foreach ( $ok as $u ) {
			$rows = '';
			$fam  = self::managed( $u->ID );
			foreach ( $fam as $f ) {
				$p  = class_exists( 'MRSH_Members' ) ? MRSH_Members::my_profile( $f->ID ) : null;
				$sl = self::status_label( $p );
				$tot[ $sl[0] ] = isset( $tot[ $sl[0] ] ) ? $tot[ $sl[0] ] + 1 : 1;
				$rows .= '<tr><td>' . esc_html( $f->display_name ) . '</td><td><span class="mx-pill" style="background:' . esc_attr( $sl[1] ) . ';color:#fff">' . esc_html( $sl[0] ) . '</span></td><td>' . ( $p ? '<a href="' . esc_url( get_permalink( $p->ID ) ) . '" target="_blank" rel="noopener">View</a> &middot; ' : '' ) . '<a href="' . esc_url( admin_url( 'admin.php?page=mrsh-desk&q=' . rawurlencode( (string) $f->user_login ) ) ) . '">Member manager</a></td></tr>';
			}
			$blk .= '<div class="mx-card"><h2 class="mx-h">' . esc_html( $u->display_name ) . ' <small style="font-weight:400;color:#6b7280">' . esc_html( $u->user_email ) . ' &middot; ' . (int) count( $fam ) . ' of ' . (int) self::MAX . ' profiles</small></h2>' . ( $rows ? '<table class="widefat striped"><thead><tr><th>Family profile</th><th>Status</th><th>Open</th></tr></thead><tbody>' . $rows . '</tbody></table>' : '<p style="color:#6b7280">No family profiles yet.</p>' ) . '<p>' . self::admin_btn( $u->ID, 'off', 'Remove helper access' ) . '</p></div>';
		}
		MRSH_Boost::ui_open( 'Rishta Agencies', 'Volunteers who create profiles for families that cannot use the site. Approve a request and they can only open the family profiles they created. Profiles appear to other members like any other profile.', 'g-blue', 'M16 11a4 4 0 1 0-8 0 4 4 0 0 0 8 0zM4 21a8 8 0 0 1 16 0z' );
		if ( isset( $_GET['msg'] ) ) { // phpcs:ignore
			MRSH_Boost::ui_ok( sanitize_text_field( wp_unslash( $_GET['msg'] ) ) ); // phpcs:ignore
		}
		echo '<div class="mx-stats">' . MRSH_Boost::ui_stat( count( $pend ), 'Requests waiting', count( $pend ) ? '#e11d48' : '#10b981' ) . MRSH_Boost::ui_stat( count( $ok ), 'Approved helpers', '#4a69d6' ) . MRSH_Boost::ui_stat( $tot['Live'], 'Profiles live', '#10b981' ) . MRSH_Boost::ui_stat( $tot['Draft'] + $tot['No profile yet'], 'Draft or not started', '#f59e0b' ) . MRSH_Boost::ui_stat( $tot['Waiting approval'], 'Waiting approval', '#7c3aed' ) . MRSH_Boost::ui_stat( $tot['Expired'] + $tot['Closed'], 'Expired or closed', '#6b7280' ) . '</div>';
		echo '<div class="mx-card"><h2 class="mx-h">Requests to become a helper</h2>';
		if ( ! $pend ) {
			echo '<p style="color:#6b7280">No requests right now.</p>';
		} else {
			echo '<table class="widefat striped"><thead><tr><th>Member</th><th>Agency, mobile, area</th><th>About</th><th>Decision</th></tr></thead><tbody>';
			foreach ( $pend as $u ) {
				$i = (array) get_user_meta( $u->ID, 'mrsh_helper_info', true );
				echo '<tr><td><b>' . esc_html( $u->display_name ) . '</b><br><small>' . esc_html( $u->user_email ) . '</small></td><td><b>' . esc_html( $i['agency'] ?? '' ) . '</b><br>' . esc_html( $i['mobile'] ?? '' ) . '<br>' . esc_html( $i['area'] ?? '' ) . '</td><td>' . esc_html( $i['why'] ?? '' ) . '</td><td>' . self::admin_btn( $u->ID, 'ok', 'Approve', true ) . ' ' . self::admin_btn( $u->ID, 'no', 'Decline' ) . '</td></tr>';
			}
			echo '</tbody></table>';
		}
		echo '</div>';
		echo $blk ? $blk : '<div class="mx-card"><h2 class="mx-h">Approved helpers</h2><p style="color:#6b7280">None yet. Approved helpers and their family profiles appear here, with the status of each profile.</p></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( $off ) {
			echo '<div class="mx-card"><h2 class="mx-h">Declined or removed</h2><p>';
			foreach ( $off as $u ) {
				echo esc_html( $u->display_name ) . ' ' . self::admin_btn( $u->ID, 'ok', 'Approve again' ) . ' ';
			}
			echo '</p></div>';
		}
		echo '</div>';
	}

	private static function admin_btn( $uid, $do, $label, $primary = false ) {
		$u = wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_hp_admin&do=' . $do . '&uid=' . (int) $uid ), 'mrsh_hp_admin' );
		return '<a class="mx-btn s' . ( $primary ? ' p' : '' ) . '" href="' . esc_url( $u ) . '">' . esc_html( $label ) . '</a>';
	}

	public static function admin_act() {
		if ( ! current_user_can( 'manage_options' ) || ! wp_verify_nonce( isset( $_GET['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ) : '', 'mrsh_hp_admin' ) ) {
			wp_die( 'Not allowed.' );
		}
		$uid = isset( $_GET['uid'] ) ? absint( $_GET['uid'] ) : 0;
		$do  = isset( $_GET['do'] ) ? sanitize_key( wp_unslash( $_GET['do'] ) ) : '';
		$u   = $uid ? get_userdata( $uid ) : null;
		$msg = 'Nothing changed.';
		if ( $u && ! user_can( $u, 'manage_options' ) && in_array( $do, array( 'ok', 'no', 'off' ), true ) ) {
			update_user_meta( $uid, 'mrsh_helper', 'ok' === $do ? 'ok' : 'off' );
			delete_transient( 'mrsh_cnt' );
			if ( class_exists( 'MRSH_Attn' ) ) {
				MRSH_Attn::close( 'helper', $uid );
			}
			$txt = 'ok' === $do ? 'Assalam o Alaikum ' . $u->display_name . ",\n\nOur team approved you as a Rishta Agency. Open My account and find the Rishta Agency box to add family profiles. Always keep the family's agreement, and never ask for money." : 'Assalam o Alaikum ' . $u->display_name . ",\n\nThank you for offering to help. We cannot give Rishta Agency access right now. You can write to us if you have questions.";
			wp_mail( $u->user_email, 'ok' === $do ? 'You are now a Rishta Agency' : 'About your Rishta Agency request', $txt . "\n\n" . get_bloginfo( 'name' ) . "\n" . home_url( '/' ) );
			$msg = 'ok' === $do ? $u->display_name . ' is now a Rishta Agency.' : $u->display_name . ' was set to no helper access.';
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-helpers&msg=' . rawurlencode( $msg ) ) );
		exit;
	}

	/* ---------- helpers ---------- */

	public static function status( $uid ) {
		return (string) get_user_meta( (int) $uid, 'mrsh_helper', true );
	}

	/** Name shown to the public: the agency name the helper gave, else the account name. */
	public static function agency_name( $helper ) {
		$i = (array) get_user_meta( (int) $helper, 'mrsh_helper_info', true );
		$n = isset( $i['agency'] ) ? trim( (string) $i['agency'] ) : '';
		if ( '' === $n ) {
			$u = get_userdata( (int) $helper );
			$n = $u ? $u->display_name : 'Agency';
		}
		return $n;
	}

	/** Private notes the agency keeps about a family (never shown to members or the public). */
	public static function notes( $uid ) {
		$n = get_user_meta( (int) $uid, 'mrt_family_notes', true );
		$n = is_array( $n ) ? $n : array();
		$f = (string) get_user_meta( (int) $uid, 'mrt_family_phone', true );
		return array_merge( array( 'full' => '', 'phone' => $f, 'address' => '', 'remarks' => '' ), $n );
	}

	/** The agency's own mobile number, used as the contact number on its family profiles. */
	public static function agency_phone( $helper ) {
		$i = (array) get_user_meta( (int) $helper, 'mrsh_helper_info', true );
		return isset( $i['mobile'] ) ? (string) $i['mobile'] : '';
	}

	private static function acct_url( $args = array() ) {
		$u = function_exists( 'mrt_link' ) ? mrt_link( 'myaccount', '/my-account/' ) : home_url( '/my-account/' );
		return $args ? add_query_arg( $args, $u ) : $u;
	}

	private static function managed( $helper ) {
		return get_users( array( 'meta_key' => 'mrt_helper', 'meta_value' => (int) $helper, 'number' => self::MAX + 5, 'orderby' => 'registered', 'order' => 'DESC' ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
	}

	private static function sig( $helper ) {
		return (int) $helper . '|' . substr( hash_hmac( 'sha256', 'hpback|' . (int) $helper, wp_salt( 'auth' ) ), 0, 24 );
	}

	/** Helper id from a valid "go back" cookie, else 0. */
	private static function back_id() {
		$c = isset( $_COOKIE[ self::COOKIE ] ) ? sanitize_text_field( wp_unslash( $_COOKIE[ self::COOKIE ] ) ) : '';
		$p = explode( '|', $c );
		if ( 2 === count( $p ) && (int) $p[0] > 0 && hash_equals( self::sig( (int) $p[0] ), $c ) && 'ok' === self::status( (int) $p[0] ) ) {
			return (int) $p[0];
		}
		return 0;
	}

	private static function back() {
		$h = self::back_id();
		$me = get_current_user_id();
		if ( $h && $me && (int) get_user_meta( $me, 'mrt_helper', true ) === $h ) {
			wp_set_current_user( $h );
			wp_set_auth_cookie( $h, false );
			setcookie( self::COOKIE, '', time() - 3600, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN, is_ssl(), true );
		}
		wp_safe_redirect( self::acct_url() );
		exit;
	}

	/* ---------- My account box ---------- */

	public static function account( $uid ) {
		$uid = $uid ? (int) $uid : get_current_user_id();
		if ( ! $uid || (int) get_user_meta( $uid, 'mrt_helper', true ) || user_can( $uid, 'manage_options' ) ) {
			return;
		}
		$st = self::status( $uid );
		$m  = isset( $_GET['hp'] ) ? sanitize_key( wp_unslash( $_GET['hp'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$e  = isset( $_GET['hpe'] ) ? sanitize_text_field( wp_unslash( $_GET['hpe'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		echo '<div class="wrap narrow"><div class="box" id="hp"><h3>Rishta Agency</h3>';
		if ( 'sent' === $m ) {
			echo '<div class="note">Thank you. Your request was received. Our team will look at it and write to you.</div>';
		}
		if ( $e ) {
			echo '<div class="' . ( 'done' === $m ? 'note' : 'err' ) . '">' . esc_html( $e ) . '</div>';
		}
		if ( 'ok' === $st ) {
			self::dashboard( $uid, $m );
		} elseif ( 'pending' === $st ) {
			echo '<p style="color:#555">Your request to become a Rishta Agency is waiting for our team. We will write to you soon.</p>';
		} else {
			echo '<p style="color:#555;font-size:.95rem">Do you help families who do not know how to use the internet? Rishta Agencies create profiles for them, free of charge, with the family\'s agreement. Ask to become a helper. / جو خاندان انٹرنیٹ استعمال نہیں کر سکتے ان کے لیے مفت پروفائل بنانے میں مدد کریں۔</p>';
			echo '<details><summary style="cursor:pointer;font-weight:700">Ask to become a Rishta Agency</summary><form class="frm" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin-top:10px"><input type="hidden" name="action" value="mrsh_hp_apply">' . wp_nonce_field( 'mrsh_hp_apply', '_wpnonce', true, false );
			echo '<label>Agency name <small class="ml">(shown on profiles as: Listed By, Rishta Agency "Name")</small></label><input name="agency" maxlength="60" required>';
			echo '<label>Agency mobile number <small class="ml">(shown on the profiles you list)</small></label><input name="amobile" type="tel" inputmode="tel" maxlength="20" required>';
			echo '<label>Your area (city or town)</label><input name="area" maxlength="60" required>';
			echo '<label>Tell us a little about how you help families</label><textarea name="why" rows="3" maxlength="400" required></textarea>';
			echo '<p><label><input type="checkbox" name="rules" value="1" style="width:auto" required> I will help families for free, only with their agreement, and I will never ask for money, gifts or ID photos.</label></p>';
			echo '<button class="btn">Send my request</button></form></details>';
		}
		echo '</div></div>';
	}

	private static function dashboard( $uid, $m ) {
		$list = self::managed( $uid );
		$n    = count( $list );
		if ( 'new' === $m ) {
			echo '<div class="note">The profile was created. Continue below.</div>';
		}
		echo '<p style="color:#555;font-size:.95rem">You look after <b>' . (int) $n . '</b> of ' . (int) self::MAX . ' family profiles. Always keep the family\'s agreement. It is free, never take money.</p>';
		if ( $list ) {
			$plans = function_exists( 'mrt_plans' ) ? mrt_plans() : array();
			$un    = 0;
			foreach ( $list as $u ) {
				$un += class_exists( 'MRSH_Members' ) ? (int) MRSH_Members::unread_count( $u->ID ) : 0;
			}
			echo '<p style="margin:0 0 8px"><b>' . (int) $un . '</b> unread message(s) across your families.</p><input type="search" id="hp-q" placeholder="Search your families by name, phone or address" style="margin:0 0 8px"><div id="hp-list" style="display:grid;gap:8px;margin:10px 0">';
			foreach ( $list as $u ) {
				$p  = class_exists( 'MRSH_Members' ) ? MRSH_Members::my_profile( $u->ID ) : null;
				$sl = self::status_label( $p );
				$ur = class_exists( 'MRSH_Members' ) ? (int) MRSH_Members::unread_count( $u->ID ) : 0;
				$go = wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_hp_switch&to=' . (int) $u->ID ), 'mrsh_hp_sw' );
				$ch = wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_hp_switch&dest=messages&to=' . (int) $u->ID ), 'mrsh_hp_sw' );
				$av = (int) get_user_meta( $u->ID, 'mrt_agency_verified', true );
				$cur = (string) get_user_meta( $u->ID, 'mrt_plan', true );
				$nt = self::notes( $u->ID );
				echo '<div class="hp-row" data-s="' . esc_attr( strtolower( $u->display_name . ' ' . $nt['full'] . ' ' . $nt['phone'] . ' ' . $nt['address'] . ' ' . $nt['remarks'] ) ) . '" style="border:1px solid #e5e7eb;border-radius:10px;padding:10px 12px"><div style="display:flex;gap:10px;align-items:center;justify-content:space-between;flex-wrap:wrap"><span><b>' . esc_html( $u->display_name ) . '</b> <small style="color:#fff;background:' . esc_attr( $sl[1] ) . ';padding:2px 8px;border-radius:99px">' . esc_html( $sl[0] ) . '</small>' . ( $av ? ' <small style="color:#065f46">Agency verified</small>' : '' ) . ( $cur ? ' <small style="color:#7c3aed">' . esc_html( $cur ) . '</small>' : '' ) . '</span><span><a class="btn line" href="' . esc_url( $go ) . '">Edit profile</a> <a class="btn line" href="' . esc_url( $ch ) . '">Chats' . ( $ur ? ' (' . (int) $ur . ' new)' : '' ) . '</a></span></div>';
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:8px"><input type="hidden" name="action" value="mrsh_hp_fam"><input type="hidden" name="uid" value="' . (int) $u->ID . '">' . wp_nonce_field( 'mrsh_hp_fam', '_wpnonce', true, false );
				echo '<button class="btn line" name="do" value="' . ( $av ? 'unverify' : 'verify' ) . '" style="width:auto">' . ( $av ? 'Remove agency verified' : 'Mark agency verified' ) . '</button> <select name="plan" style="width:auto"><option value="">Free package</option><option>Silver</option><option>Gold</option></select> <button class="btn line" name="do" value="plan" style="width:auto">Give package</button></form>';
				echo '<details style="margin-top:8px"><summary style="cursor:pointer;font-weight:700;font-size:.92rem">Private notes (only you can see these)</summary><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="frm" style="margin-top:8px"><input type="hidden" name="action" value="mrsh_hp_fam"><input type="hidden" name="uid" value="' . (int) $u->ID . '"><input type="hidden" name="do" value="notes">' . wp_nonce_field( 'mrsh_hp_fam', '_wpnonce', true, false );
				echo '<label>Family full name</label><input name="full" maxlength="80" value="' . esc_attr( $nt['full'] ) . '"><label>Family phone</label><input name="phone" maxlength="30" value="' . esc_attr( $nt['phone'] ) . '"><label>Address</label><input name="address" maxlength="200" value="' . esc_attr( $nt['address'] ) . '"><label>Remarks (anything you want to remember)</label><textarea name="remarks" rows="3" maxlength="800">' . esc_textarea( $nt['remarks'] ) . '</textarea><button class="btn line" style="width:auto">Save notes</button></form></details></div>';
			}
			echo '</div><script>(function(){var q=document.getElementById("hp-q");if(!q)return;q.addEventListener("input",function(){var v=q.value.toLowerCase();document.querySelectorAll("#hp-list .hp-row").forEach(function(r){r.style.display=r.getAttribute("data-s").indexOf(v)>-1?"":"none"})})})();</script>';
		}
		if ( $n >= self::MAX ) {
			echo '<p class="ml">You reached the limit of ' . (int) self::MAX . ' profiles. Please contact us if you need more.</p>';
			return;
		}
		echo '<details' . ( $list ? '' : ' open' ) . '><summary style="cursor:pointer;font-weight:700">Add a new family profile</summary><form class="frm" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin-top:10px"><input type="hidden" name="action" value="mrsh_hp_new">' . wp_nonce_field( 'mrsh_hp_new', '_wpnonce', true, false );
		echo '<label>First name of the person who needs the rishta</label><input name="fname" maxlength="60" required>';
		echo '<label>Family mobile number <small class="ml">(optional, kept private for your records)</small></label><input name="fphone" type="tel" inputmode="tel" maxlength="20" placeholder="03XX XXXXXXX">';
		echo '<label>Address <small class="ml">(private note for you, never shown)</small></label><input name="faddress" maxlength="200"><label>Remarks <small class="ml">(private, anything to remember)</small></label><textarea name="fremarks" rows="2" maxlength="800"></textarea>';
		echo '<p class="ml">Messages and notifications for this profile come to your agency email: ' . esc_html( wp_get_current_user()->user_email ) . '. The contact number shown is your agency mobile.</p>';
		echo '<p><label><input type="checkbox" name="agree" value="1" style="width:auto" required> The family agreed that I create this profile, and I will not ask them for money.</label></p>';
		echo '<button class="btn">Create and fill the profile</button></form></details>';
	}

	/* ---------- actions ---------- */

	public static function apply() {
		$uid = get_current_user_id();
		if ( ! $uid || ! wp_verify_nonce( isset( $_POST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ) : '', 'mrsh_hp_apply' ) || empty( $_POST['rules'] ) ) { // phpcs:ignore
			wp_safe_redirect( self::acct_url( array( 'hpe' => 'Please tick the box and try again.' ) ) );
			exit;
		}
		if ( ! in_array( self::status( $uid ), array( 'pending', 'ok' ), true ) ) {
			$info = array( 'agency' => sanitize_text_field( wp_unslash( $_POST['agency'] ?? '' ) ), 'mobile' => preg_replace( '/[^0-9+\\-\\s]/', '', (string) wp_unslash( $_POST['amobile'] ?? '' ) ), 'area' => sanitize_text_field( wp_unslash( $_POST['area'] ?? '' ) ), 'why' => sanitize_textarea_field( wp_unslash( $_POST['why'] ?? '' ) ), 'at' => time() ); // phpcs:ignore
			update_user_meta( $uid, 'mrsh_helper', 'pending' );
			update_user_meta( $uid, 'mrsh_helper_info', $info );
			if ( class_exists( 'MRSH_Attn' ) ) {
				$u = get_userdata( $uid );
				MRSH_Attn::add( 'helper', $uid, ( $u ? $u->display_name : 'A member' ) . ' asked to become a Rishta Agency (' . $info['area'] . '). Check them, then approve in Member manager.', admin_url( 'admin.php?page=mrsh-helpers' ) );
			}
		}
		wp_safe_redirect( self::acct_url( array( 'hp' => 'sent' ) ) . '#hp' );
		exit;
	}

	private static function plus_email( $helper_email ) {
		$p = explode( '@', (string) $helper_email );
		if ( 2 !== count( $p ) ) {
			return '';
		}
		$base = preg_replace( '/\+.*$/', '', $p[0] );
		for ( $i = 0; $i < 6; $i++ ) {
			$e = $base . '+fam' . wp_rand( 1000, 99999 ) . '@' . $p[1];
			if ( ! email_exists( $e ) ) {
				return $e;
			}
		}
		return '';
	}

	public static function create() {
		$h = get_current_user_id();
		if ( ! $h || 'ok' !== self::status( $h ) || ! wp_verify_nonce( isset( $_POST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ) : '', 'mrsh_hp_new' ) ) { // phpcs:ignore
			wp_safe_redirect( self::acct_url() );
			exit;
		}
		$bad = function ( $m ) {
			wp_safe_redirect( self::acct_url( array( 'hpe' => $m ) ) . '#hp' );
			exit;
		};
		$fname = sanitize_text_field( wp_unslash( $_POST['fname'] ?? '' ) ); // phpcs:ignore
		if ( '' === $fname || empty( $_POST['agree'] ) ) { // phpcs:ignore
			$bad( 'Please write the first name and tick the agreement.' );
		}
		if ( count( self::managed( $h ) ) >= self::MAX ) {
			$bad( 'You reached the limit of profiles.' );
		}
		$day = 'mrsh_hp_day_' . $h;
		$cnt = (int) get_transient( $day );
		if ( $cnt >= self::DAILY ) {
			$bad( 'You made many profiles today. Please continue tomorrow.' );
		}
		$hu    = get_userdata( $h );
		$email = self::plus_email( $hu ? $hu->user_email : '' );
		if ( ! $email ) {
			$bad( 'Could not prepare an email for this profile. Please try again.' );
		}
		$login = 'fam' . strtolower( wp_generate_password( 8, false, false ) );
		$id    = wp_insert_user( array( 'user_login' => $login, 'user_pass' => wp_generate_password( 20 ), 'user_email' => $email, 'display_name' => $fname, 'first_name' => $fname, 'role' => 'subscriber' ) );
		if ( is_wp_error( $id ) ) {
			$bad( 'Could not create the profile. Please try again.' );
		}
		update_user_meta( $id, 'mrt_helper', $h );
		update_user_meta( $id, 'mrt_helper_ok', time() );
		$ph = isset( $_POST['fphone'] ) ? preg_replace( '/[^0-9+\\-\\s]/', '', (string) wp_unslash( $_POST['fphone'] ) ) : ''; // phpcs:ignore
		if ( $ph ) {
			update_user_meta( $id, 'mrt_family_phone', $ph );
		}
		update_user_meta( $id, 'mrt_family_notes', array( 'full' => '', 'phone' => $ph, 'address' => sanitize_text_field( wp_unslash( $_POST['faddress'] ?? '' ) ), 'remarks' => sanitize_textarea_field( wp_unslash( $_POST['fremarks'] ?? '' ) ) ) ); // phpcs:ignore
		set_transient( $day, $cnt + 1, DAY_IN_SECONDS );
		if ( class_exists( 'MRSH_Autopilot' ) ) {
			MRSH_Autopilot::log( 'Rishta Agencies', ( $hu ? $hu->display_name : 'A helper' ) . ' started a family profile for ' . $fname . '.' );
		}
		self::switch_to( $h, (int) $id );
		$add = function_exists( 'mrt_link' ) ? mrt_link( 'add', '/add-listing/' ) : home_url( '/add-listing/' );
		wp_safe_redirect( $add );
		exit;
	}

	private static function switch_to( $helper, $target ) {
		setcookie( self::COOKIE, self::sig( $helper ), time() + 12 * HOUR_IN_SECONDS, COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN, is_ssl(), true );
		wp_set_current_user( $target );
		wp_set_auth_cookie( $target, false );
	}

	public static function go() {
		$h = get_current_user_id();
		$t = isset( $_GET['to'] ) ? absint( $_GET['to'] ) : 0; // phpcs:ignore
		if ( ! $h || ! $t || 'ok' !== self::status( $h ) || ! wp_verify_nonce( isset( $_GET['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ) : '', 'mrsh_hp_sw' ) || (int) get_user_meta( $t, 'mrt_helper', true ) !== $h || user_can( $t, 'manage_options' ) ) { // phpcs:ignore
			wp_safe_redirect( self::acct_url() );
			exit;
		}
		self::switch_to( $h, $t );
		$d = isset( $_GET['dest'] ) ? sanitize_key( wp_unslash( $_GET['dest'] ) ) : ''; // phpcs:ignore
		wp_safe_redirect( 'messages' === $d ? self::acct_url( array( 'tab' => 'messages' ) ) : ( function_exists( 'mrt_link' ) ? mrt_link( 'add', '/add-listing/' ) : home_url( '/add-listing/' ) ) );
		exit;
	}

	public static function back_action() {
		self::back();
	}

	/* ---------- helper mode bar and public label ---------- */

	public static function bar() {
		$me = get_current_user_id();
		$h  = $me ? self::back_id() : 0;
		if ( ! $h || (int) get_user_meta( $me, 'mrt_helper', true ) !== $h ) {
			return;
		}
		$u = get_userdata( $me );
		echo '<div style="position:fixed;left:0;right:0;bottom:0;z-index:99999;background:#1f2430;color:#fff;padding:10px 16px calc(10px + env(safe-area-inset-bottom,0px));display:flex;gap:12px;align-items:center;justify-content:space-between;flex-wrap:wrap;font:14px/1.4 Arial,sans-serif"><span>Helper mode: you are working on <b>' . esc_html( $u ? $u->display_name : '' ) . '</b>\'s profile.</span><a href="' . esc_url( admin_url( 'admin-post.php?action=mrsh_hp_back' ) ) . '" style="background:#e11d74;color:#fff;text-decoration:none;padding:8px 16px;border-radius:8px;font-weight:700">Back to my helper account</a></div>';
	}

	public static function label( $pid ) {
		$p = get_post( $pid ? $pid : get_the_ID() );
		if ( ! $p ) {
			return;
		}
		$h = (int) get_user_meta( (int) $p->post_author, 'mrt_helper', true );
		if ( $h && get_userdata( $h ) ) {
			$o = '<span class="chip on" style="display:inline-block;margin:4px 6px 4px 0">Listed By (Rishta Agency &ldquo;' . esc_html( self::agency_name( $h ) ) . '&rdquo;)</span>';
			if ( (int) get_user_meta( (int) $p->post_author, 'mrt_agency_verified', true ) ) {
				$o .= '<span class="chip" style="display:inline-block;margin:4px 0">Agency verified</span>';
			}
			echo '<div class="wrap">' . $o . '</div>'; // phpcs:ignore
		}
	}

	/* ---------- agency actions on its own families ---------- */

	public static function fam_act() {
		$h = get_current_user_id();
		$t = isset( $_POST['uid'] ) ? absint( $_POST['uid'] ) : 0; // phpcs:ignore
		if ( ! $h || ! $t || 'ok' !== self::status( $h ) || ! wp_verify_nonce( isset( $_POST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ) : '', 'mrsh_hp_fam' ) || (int) get_user_meta( $t, 'mrt_helper', true ) !== $h ) { // phpcs:ignore
			wp_safe_redirect( self::acct_url() );
			exit;
		}
		$do = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : ''; // phpcs:ignore
		$m  = '';
		if ( 'notes' === $do ) {
			update_user_meta( $t, 'mrt_family_notes', array(
				'full'    => sanitize_text_field( wp_unslash( $_POST['full'] ?? '' ) ), // phpcs:ignore
				'phone'   => preg_replace( '/[^0-9+\\-\\s]/', '', (string) wp_unslash( $_POST['phone'] ?? '' ) ), // phpcs:ignore
				'address' => sanitize_text_field( wp_unslash( $_POST['address'] ?? '' ) ), // phpcs:ignore
				'remarks' => sanitize_textarea_field( wp_unslash( $_POST['remarks'] ?? '' ) ), // phpcs:ignore
			) );
			$m = 'Notes saved.';
		} elseif ( 'verify' === $do ) {
			update_user_meta( $t, 'mrt_agency_verified', time() );
			$m = 'Marked as verified by your agency.';
		} elseif ( 'unverify' === $do ) {
			delete_user_meta( $t, 'mrt_agency_verified' );
			$m = 'Agency verified mark removed.';
		} elseif ( 'plan' === $do ) {
			$pn = isset( $_POST['plan'] ) ? sanitize_text_field( wp_unslash( $_POST['plan'] ) ) : ''; // phpcs:ignore
			if ( ! in_array( $pn, array( 'Silver', 'Gold' ), true ) ) {
				$m = 'Choose Silver or Gold first.';
			} elseif ( ! get_option( 'mrsh_plans_free' ) ) {
				$m = 'Packages are not free right now. Please ask our team.';
			} else {
				$need = class_exists( 'MRSH_Concierge' ) ? MRSH_Concierge::min_for( $pn ) : 60;
				$pc   = class_exists( 'MRSH_Concierge' ) ? MRSH_Concierge::profile_pct( $t ) : array( 0 );
				if ( (int) $pc[0] < $need ) {
					$m = $pn . ' needs the profile to be at least ' . (int) $need . '% complete. This one is ' . (int) $pc[0] . '%.';
				} else {
					$days = class_exists( 'MRSH_Concierge' ) ? MRSH_Concierge::DAYS : 180;
					update_user_meta( $t, 'mrt_plan', $pn );
					update_user_meta( $t, 'mrt_plan_exp', time() + $days * DAY_IN_SECONDS );
					delete_user_meta( $t, 'mrt_plan_req' );
					$u = get_userdata( $t );
					if ( class_exists( 'MRSH_Autopilot' ) ) {
						MRSH_Autopilot::log( 'Rishta agencies', self::agency_name( $h ) . ' gave the free ' . $pn . ' package to ' . ( $u ? $u->display_name : '#' . $t ) . '.' );
					}
					$m = 'The ' . $pn . ' package is now active.';
				}
			}
		}
		wp_safe_redirect( self::acct_url( array( 'hp' => 'done', 'hpe' => $m ) ) . '#hp' );
		exit;
	}

	/** Mail for agency family accounts goes to the agency's exact email (the +fam part is removed). */
	public static function route_mail( $a ) {
		if ( ! empty( $a['to'] ) ) {
			$a['to'] = is_array( $a['to'] ) ? array_map( array( __CLASS__, 'plain' ), $a['to'] ) : self::plain( $a['to'] );
		}
		return $a;
	}

	private static function plain( $e ) {
		return is_string( $e ) ? preg_replace( '/\+fam\d+@/', '@', $e ) : $e;
	}

	/** The contact number prefilled on a family profile is the agency mobile. */
	public static function prefill_phone( $v, $uid ) {
		$h = (int) get_user_meta( (int) $uid, 'mrt_helper', true );
		if ( $h ) {
			$ph = self::agency_phone( $h );
			if ( '' !== $ph ) {
				return $ph;
			}
		}
		return $v;
	}
}

MRSH_Community::init();
