<?php
/**
 * Ads checkup: is the site ready for ad approval, which pages show ads and why, one-click hide/show per page,
 * and 14 days of taps on the app card and install bar. Reads the MyRishta Ads settings; changes only the per-page switch.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_AdsCheck {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 40 );
		add_action( 'admin_post_mrsh_adscheck_toggle', array( __CLASS__, 'toggle' ) );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-ads', 'Ads checkup', 'Ads checkup', 'manage_options', 'mrads-check', array( __CLASS__, 'page' ) );
	}

	public static function toggle() {
		$id = absint( $_GET['post'] ?? 0 ); // phpcs:ignore
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_adscheck_' . $id );
		if ( $id && current_user_can( 'edit_post', $id ) ) {
			if ( get_post_meta( $id, '_mrads_off', true ) ) {
				delete_post_meta( $id, '_mrads_off' );
			} else {
				update_post_meta( $id, '_mrads_off', 1 );
			}
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrads-check#pages' ) );
		exit;
	}

	private static function words( $p ) {
		$n = str_word_count( wp_strip_all_tags( strip_shortcodes( (string) $p->post_content ) ) );
		if ( $n >= 250 ) {
			return $n;
		}
		// Text added by shortcodes or the page template: count what visitors really see (kept for 12 hours).
		$k = 'mrsh_pw_' . $p->ID . '_' . strtotime( $p->post_modified_gmt );
		$v = get_transient( $k );
		if ( false === $v ) {
			$v = 0;
			$r = wp_remote_get( add_query_arg( 'mrsh_w', 1, get_permalink( $p ) ), array( 'timeout' => 8, 'redirection' => 3 ) );
			if ( ! is_wp_error( $r ) && 200 === (int) wp_remote_retrieve_response_code( $r ) ) {
				$h = (string) wp_remote_retrieve_body( $r );
				if ( preg_match( '#<main\b.*?</main>#is', $h, $m ) ) {
					$h = $m[0];
				}
				$h = preg_replace( '#<(script|style|nav|form)\b.*?</\1>#is', ' ', $h );
				$v = str_word_count( wp_strip_all_tags( (string) $h ) );
			}
			set_transient( $k, $v, 12 * HOUR_IN_SECONDS );
		}
		return max( $n, (int) $v );
	}

	/** Of the possible addresses, the published page with the most text. */
	private static function page_by( $slugs ) {
		$best = null;
		$max  = -1;
		foreach ( $slugs as $s ) {
			$p = get_page_by_path( $s );
			if ( $p && 'publish' === $p->post_status ) {
				$w = self::words( $p );
				if ( $w > $max ) {
					$best = $p;
					$max  = $w;
				}
			}
		}
		return $best;
	}

	/** Checks that ad networks look at when they review a site. */
	private static function readiness( $s ) {
		$c   = array();
		$npo = (int) wp_count_posts( 'post' )->publish;
		$pub = '';
		if ( class_exists( 'MRSH_Options' ) ) {
			$o   = MRSH_Options::get();
			$pub = (string) ( $o['adsense_pub'] ?? '' );
		}
		$lines = class_exists( 'MRSH_Tools' ) ? count( array_filter( explode( "\n", (string) MRSH_Tools::ads_txt_body() ) ) ) : 0;
		$need  = array(
			'About page'          => array( array( 'about-us', 'about' ), 150 ),
			'Contact page'        => array( array( 'contact', 'contact-us' ), 60 ),
			'Privacy policy page' => array( array( 'privacy-policy', 'privacy' ), 250 ),
			'Terms page'          => array( array( 'terms', 'terms-and-conditions', 'terms-of-use' ), 250 ),
		);
		foreach ( $need as $label => $r ) {
			$p = self::page_by( $r[0] );
			$c[] = array( $label . ' exists with real text', $p && self::words( $p ) >= $r[1], $p ? 'Found, ' . self::words( $p ) . ' words (needs ' . $r[1] . '+).' : 'Not found. Networks ask for it.' );
		}
		$c[] = array( '20 or more helpful guides', $npo >= 20, $npo . ' published guides.' );
		$c[] = array( 'Site uses https', 0 === strpos( home_url(), 'https' ), 'Install the free SSL certificate at your host.' );
		$c[] = array( 'Search engines allowed', '1' === (string) get_option( 'blog_public' ), 'Settings > Reading: untick "Discourage search engines".' );
		$c[] = array( 'AdSense publisher ID saved', '' !== $pub, 'Add it in SEO > Search engines so ads.txt is correct.' );
		$c[] = array( 'ads.txt has lines', $lines > 0, $lines . ' lines.' );
		$c[] = array( 'Cookie-consent tool active', function_exists( 'wp_has_consent' ), 'Optional but safer for visitors.' );
		$c[] = array( 'Ads stay off thin pages', (int) $s['minwords'] >= 300, 'Minimum words is ' . (int) $s['minwords'] . '. Use 400 or more.' );
		return $c;
	}

	/** Why a page does or does not get ads. Returns '' when it does. */
	private static function reason( $p, $s ) {
		$types = 'post' === $s['types'] ? array( 'post' ) : ( 'page' === $s['types'] ? array( 'page' ) : array( 'post', 'page' ) );
		if ( ! in_array( $p->post_type, $types, true ) ) {
			return 'Type not selected';
		}
		if ( get_post_meta( $p->ID, '_mrads_off', true ) ) {
			return 'Hidden by you';
		}
		if ( get_post_meta( $p->ID, '_mrsh_noindex', true ) ) {
			return 'Page is noindex';
		}
		$ex = array_filter( array_map( 'trim', preg_split( '/\R/', (string) $s['exclude'] ) ) );
		if ( in_array( $p->post_name, $ex, true ) ) {
			return 'On the no-ads list';
		}
		if ( (int) get_option( 'page_on_front' ) === (int) $p->ID ) {
			return 'Front page';
		}
		if ( self::words( $p ) < (int) $s['minwords'] ) {
			return 'Too few words (' . self::words( $p ) . ')';
		}
		return '';
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) || ! class_exists( 'MRADS' ) ) {
			return;
		}
		$s    = MRADS::get();
		$card = 'background:#fff;border:1px solid #dcdcde;border-radius:14px;padding:6px 18px 16px;margin:14px 0;max-width:980px';
		echo '<div class="wrap"><h1>Ads checkup</h1><p>Is the site ready for ad approval, where do ads show, and are people tapping your app promotion? <a class="button" href="' . esc_url( admin_url( 'admin.php?page=myrishta-ads' ) ) . '">Open ad settings</a></p>';

		// 1. Readiness.
		$rd   = self::readiness( $s );
		$good = count( array_filter( wp_list_pluck( $rd, 1 ) ) );
		$pct  = (int) round( 100 * $good / max( 1, count( $rd ) ) );
		echo '<div style="' . $card . '"><h2>Ready for ad approval: <span style="color:' . ( $pct >= 80 ? '#16a34a' : ( $pct >= 50 ? '#d97706' : '#dc2626' ) ) . '">' . $pct . '%</span></h2>';
		foreach ( $rd as $r ) {
			echo '<p style="margin:7px 0"><span style="display:inline-block;width:20px;height:20px;border-radius:50%;color:#fff;text-align:center;line-height:20px;background:' . ( $r[1] ? '#16a34a' : '#dc2626' ) . '">' . ( $r[1] ? '&#10003;' : '!' ) . '</span> <b>' . esc_html( $r[0] ) . '</b> <small style="color:#646970">' . esc_html( $r[2] ) . '</small></p>';
		}
		echo '<p class="description">Networks decide by their own rules, so a high score does not promise approval. It only removes the common reasons for refusal.</p></div>';

		// 2. Taps, 14 days.
		$st  = (array) get_option( 'mrads_stats', array() );
		$day = array();
		$max = 1;
		for ( $i = 13; $i >= 0; $i-- ) {
			$d   = wp_date( 'Y-m-d', time() - $i * DAY_IN_SECONDS );
			$c   = (int) ( $st[ $d ]['card'] ?? 0 );
			$b   = (int) ( $st[ $d ]['bar'] ?? 0 );
			$max = max( $max, $c + $b );
			$day[ $d ] = array( $c, $b );
		}
		echo '<div style="' . $card . '"><h2>App taps, last 14 days</h2><div style="display:flex;align-items:flex-end;gap:6px;height:120px;border-bottom:1px solid #dcdcde;padding-top:8px">';
		foreach ( $day as $d => $v ) {
			$h1 = (int) round( 100 * $v[0] / $max );
			$h2 = (int) round( 100 * $v[1] / $max );
			echo '<div title="' . esc_attr( $d . ': card ' . $v[0] . ', bar ' . $v[1] ) . '" style="flex:1;display:flex;flex-direction:column;justify-content:flex-end;height:100%"><div style="background:#7c3aed;height:' . $h2 . '%;min-height:' . ( $v[1] ? 2 : 0 ) . 'px"></div><div style="background:#e11d74;height:' . $h1 . '%;min-height:' . ( $v[0] ? 2 : 0 ) . 'px"></div></div>';
		}
		echo '</div><p><span style="color:#e11d74">&#9632;</span> app card in guides &nbsp; <span style="color:#7c3aed">&#9632;</span> install bar on phones &nbsp; (hover a bar for the numbers). Total: ' . array_sum( array_column( $day, 0 ) ) . ' card, ' . array_sum( array_column( $day, 1 ) ) . ' bar.</p></div>';

		// 3. Pages.
		$posts = get_posts( array( 'post_type' => array( 'post', 'page' ), 'post_status' => 'publish', 'numberposts' => 200, 'orderby' => 'modified', 'order' => 'DESC', 'suppress_filters' => true ) );
		$rows  = array();
		$show  = 0;
		foreach ( $posts as $p ) {
			$why = self::reason( $p, $s );
			if ( '' === $why ) {
				++$show;
			}
			$rows[] = array( $p, $why );
		}
		usort( $rows, function ( $a, $b ) { return strcmp( $b[1], $a[1] ); } );
		echo '<div style="' . $card . '" id="pages"><h2>Which pages get ads</h2><p>' . ( $s['enabled'] ? 'Ads are <b>on</b>.' : 'Ad-network ads are <b>off</b> (only your app promotion shows). The table shows what would happen when you switch them on.' ) . ' Ads would show on <b>' . $show . '</b> of ' . count( $rows ) . ' pages.</p><div style="overflow-x:auto"><table class="widefat striped"><thead><tr><th>Page</th><th>Ads</th><th></th></tr></thead><tbody>';
		foreach ( array_slice( $rows, 0, 80 ) as $r ) {
			$p   = $r[0];
			$off = (bool) get_post_meta( $p->ID, '_mrads_off', true );
			$url = wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_adscheck_toggle&post=' . (int) $p->ID ), 'mrsh_adscheck_' . (int) $p->ID );
			echo '<tr><td><a href="' . esc_url( (string) get_permalink( $p ) ) . '" target="_blank" rel="noopener">' . esc_html( get_the_title( $p ) ) . '</a> <small>(' . esc_html( $p->post_type ) . ', ' . (int) self::words( $p ) . ' words)</small></td><td>' . ( '' === $r[1] ? '<b style="color:#16a34a">Shown</b>' : '<span style="color:#646970">' . esc_html( $r[1] ) . '</span>' ) . '</td><td><a class="button" href="' . esc_url( $url ) . '">' . ( $off ? 'Allow ads here' : 'Hide ads here' ) . '</a></td></tr>';
		}
		echo '</tbody></table></div>' . ( count( $rows ) > 80 ? '<p class="description">Showing 80 of ' . count( $rows ) . '.</p>' : '' ) . '</div></div>';
	}
}
MRSH_AdsCheck::init();
