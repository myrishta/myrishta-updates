<?php
/**
 * More member tools: compare profiles, who viewed me (paid plans), 24 hour profile boost, weekly activity summary,
 * payment proof upload with admin list, moderator role, haptic patterns, chat report link, family meeting checklist page.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Mem_More {

	public static function init() {
		add_action( 'template_redirect', array( __CLASS__, 'track_view' ), 20 );
		add_action( 'template_redirect', array( __CLASS__, 'compare_page' ), 5 );
		add_filter( 'posts_clauses', array( __CLASS__, 'boost_sort' ), 20, 2 );
		add_action( 'mrt_account_extra', array( __CLASS__, 'account' ), 20 );
		add_action( 'admin_post_mrsh_boost', array( __CLASS__, 'boost_now' ) );
		add_action( 'admin_post_mrsh_proof', array( __CLASS__, 'proof_post' ) );
		add_action( 'admin_post_mrsh_proof_done', array( __CLASS__, 'proof_done' ) );
		add_action( 'admin_post_mrsh_proof_days', array( __CLASS__, 'proof_days_save' ) );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 26 );
		add_action( 'mrsh_growth_daily', array( __CLASS__, 'weekly_summary' ) );
		add_action( 'init', array( __CLASS__, 'role' ) );
		add_action( 'admin_init', array( __CLASS__, 'page' ) );
		add_action( 'wp_footer', array( __CLASS__, 'js' ), 75 );
		add_action( 'show_user_profile', array( __CLASS__, 'user_boost' ) );
		add_action( 'edit_user_profile', array( __CLASS__, 'user_boost' ) );
		add_action( 'edit_user_profile_update', array( __CLASS__, 'user_boost_save' ) );
	}

	private static function paid( $uid ) {
		$p = trim( (string) get_user_meta( $uid, 'mrt_plan', true ) );
		return '' !== $p && 0 !== strcasecmp( $p, 'free' );
	}

	/* ---------- who viewed me ---------- */

	public static function track_view() {
		if ( ! is_singular( 'listing_type' ) || ! is_user_logged_in() ) {
			return;
		}
		$me = get_current_user_id();
		$p  = get_queried_object();
		if ( ! $p || (int) $p->post_author === $me ) {
			return;
		}
		$k = 'mrt_viewers';
		$v = get_user_meta( (int) $p->post_author, $k, true );
		$v = is_array( $v ) ? $v : array();
		unset( $v[ $me ] );
		$v[ $me ] = time();
		arsort( $v );
		update_user_meta( (int) $p->post_author, $k, array_slice( $v, 0, 40, true ) );
	}

	/* ---------- boost ---------- */

	public static function boost_sort( $c, $q ) {
		global $wpdb;
		if ( is_admin() || ! $q->is_main_query() || 'listing_type' !== $q->get( 'post_type' ) ) {
			return $c;
		}
		$ob = $q->get( 'orderby' );
		if ( $ob && ! in_array( $ob, array( 'date', 'post_date' ), true ) ) {
			return $c;
		}
		$c['join']   .= " LEFT JOIN {$wpdb->usermeta} mrb ON (mrb.user_id = {$wpdb->posts}.post_author AND mrb.meta_key = 'mrt_boost_until' AND CAST(mrb.meta_value AS UNSIGNED) > " . (int) time() . ' )';
		$c['orderby'] = '(mrb.umeta_id IS NOT NULL) DESC' . ( $c['orderby'] ? ', ' . $c['orderby'] : '' );
		return $c;
	}

	public static function boost_now() {
		$uid = get_current_user_id();
		if ( ! $uid || ! check_admin_referer( 'mrsh_boost' ) || ! self::paid( $uid ) ) {
			wp_safe_redirect( home_url( '/my-account/' ) );
			exit;
		}
		$last = (int) get_user_meta( $uid, 'mrt_boost_last', true );
		if ( $last > time() - 7 * DAY_IN_SECONDS ) {
			wp_safe_redirect( add_query_arg( 'boost', 'wait', home_url( '/my-account/' ) ) );
			exit;
		}
		update_user_meta( $uid, 'mrt_boost_until', time() + DAY_IN_SECONDS );
		update_user_meta( $uid, 'mrt_boost_last', time() );
		wp_safe_redirect( add_query_arg( 'boost', 'ok', home_url( '/my-account/' ) ) );
		exit;
	}

	public static function user_boost( $u ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$b = (int) get_user_meta( $u->ID, 'mrt_boost_until', true );
		echo '<table class="form-table"><tr><th>Boost until</th><td><input type="datetime-local" name="mrt_boost_until" value="' . esc_attr( $b > time() ? wp_date( 'Y-m-d\TH:i', $b ) : '' ) . '"> <span class="description">While active, this member\'s profile is listed first in search. Empty = no boost.</span></td></tr></table>';
	}

	public static function user_boost_save( $uid ) {
		if ( ! current_user_can( 'manage_options' ) || ! isset( $_POST['mrt_boost_until'] ) ) { // phpcs:ignore
			return;
		}
		$t = strtotime( sanitize_text_field( wp_unslash( $_POST['mrt_boost_until'] ) ) ); // phpcs:ignore
		$t ? update_user_meta( $uid, 'mrt_boost_until', $t ) : delete_user_meta( $uid, 'mrt_boost_until' );
	}

	/* ---------- member account blocks ---------- */

	public static function account( $uid ) {
		if ( ! $uid ) {
			return;
		}
		$paid = self::paid( $uid );
		echo '<div class="wrap narrow">';
		if ( isset( $_GET['boost'] ) ) { // phpcs:ignore
			echo '<div class="note2">' . ( 'ok' === $_GET['boost'] ? 'Your profile is boosted for 24 hours.' : 'You can boost once every 7 days.' ) . '</div>'; // phpcs:ignore
		}
		if ( isset( $_GET['proof'] ) ) { // phpcs:ignore
			echo '<div class="note2">' . ( 'ok' === $_GET['proof'] ? 'Thank you. We received your payment proof and will update your plan soon.' : 'Please attach a JPG, PNG or WebP picture under 3 MB.' ) . '</div>'; // phpcs:ignore
		}
		// Who viewed me
		echo '<div class="box"><h3>Who viewed my profile</h3>';
		$v = get_user_meta( $uid, 'mrt_viewers', true );
		$v = is_array( $v ) ? $v : array();
		if ( ! $paid ) {
			echo '<p class="mut">' . (int) count( $v ) . ' member(s) viewed your profile recently. Names are shown on paid plans. <a href="' . esc_url( home_url( '/memberships/' ) ) . '">See plans</a></p>';
		} elseif ( ! $v ) {
			echo '<p class="mut">No views from members yet.</p>';
		} else {
			echo '<ul>';
			foreach ( array_slice( $v, 0, 15, true ) as $vid => $t ) {
				$p = MRSH_Members::my_profile( (int) $vid );
				if ( $p && 'publish' === $p->post_status ) {
					echo '<li><a href="' . esc_url( get_permalink( $p ) ) . '">' . esc_html( get_the_title( $p ) ) . '</a> <span class="mut">' . esc_html( human_time_diff( (int) $t ) ) . ' ago</span></li>';
				}
			}
			echo '</ul>';
		}
		echo '</div>';
		// Boost
		if ( $paid ) {
			$b = (int) get_user_meta( $uid, 'mrt_boost_until', true );
			echo '<div class="box"><h3>Boost my profile</h3>';
			if ( $b > time() ) {
				echo '<p>Boost is active until <b>' . esc_html( wp_date( 'j M, H:i', $b ) ) . '</b>.</p>';
			} else {
				echo '<p>Show your profile first in search for 24 hours. Once every 7 days.</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_boost">' . wp_nonce_field( 'mrsh_boost', '_wpnonce', true, false ) . '<button class="btn">Boost now</button></form>';
			}
			echo '</div>';
		}
		// Payment proof: hidden while one is waiting; shown again if the admin rejects it or the waiting time ends.
		$wait = self::proof_waiting( $uid );
		if ( $wait ) {
			$days = self::proof_days();
			echo '<div class="box"><h3>Payment proof received</h3><p>Thank you. Your screenshot' . ( ! empty( $wait['plan'] ) ? ' for <b>' . esc_html( $wait['plan'] ) . '</b>' : '' ) . ' is waiting for our check. We will update your plan soon.</p><p class="mut">If it is not checked by <b>' . esc_html( wp_date( 'j M Y', (int) $wait['t'] + $days * DAY_IN_SECONDS ) ) . '</b>, this card will appear again so you can send it once more.</p></div>';
		} elseif ( ! class_exists( 'MRSH_Switch' ) || MRSH_Switch::on( 'payproof' ) ) {
			$rej = get_user_meta( $uid, 'mrt_proof_rej', true );
			if ( is_array( $rej ) && ! empty( $rej['t'] ) ) {
				echo '<div class="note2">Your last payment proof was not accepted' . ( ! empty( $rej['note'] ) ? ': ' . esc_html( $rej['note'] ) : '.' ) . ' Please send it again.</div>';
			}
			echo '<div class="box"><h3>Send payment proof</h3><p class="mut">Paid by Easypaisa, JazzCash or bank? Attach the screenshot and tell us the plan. We will update your plan after checking.</p><form method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_proof">' . wp_nonce_field( 'mrsh_proof', '_wpnonce', true, false ) . '<p><input type="text" name="plan" placeholder="Plan name, for example Silver" maxlength="40" required style="width:100%"></p><p><input type="file" name="shot" accept="image/jpeg,image/png,image/webp" required></p><p><button class="btn">Send</button></p></form></div>';
		}
		echo '</div>';
	}

	/* ---------- payment proofs ---------- */

	/** Days the member's proof card stays hidden while waiting for the admin. */
	public static function proof_days() {
		return max( 1, min( 60, (int) get_option( 'mrsh_proof_days', 7 ) ) );
	}

	/** The member's newest proof that is still waiting (not rejected, not older than the limit), or null. */
	public static function proof_waiting( $uid ) {
		$lim = time() - self::proof_days() * DAY_IN_SECONDS;
		$hit = null;
		foreach ( (array) get_option( 'mrsh_proofs', array() ) as $p ) {
			if ( (int) ( $p['u'] ?? 0 ) === (int) $uid && (int) ( $p['t'] ?? 0 ) > $lim && ( $p['t'] ?? 0 ) >= ( $hit['t'] ?? 0 ) ) {
				$hit = $p;
			}
		}
		return $hit;
	}

	public static function proof_post() {
		$uid = get_current_user_id();
		$bk  = home_url( '/my-account/' );
		if ( ! $uid || ! check_admin_referer( 'mrsh_proof' ) ) {
			wp_safe_redirect( $bk );
			exit;
		}
		if ( self::proof_waiting( $uid ) ) { // one at a time: the earlier proof is still waiting
			wp_safe_redirect( add_query_arg( 'proof', 'ok', $bk ) );
			exit;
		}
		delete_user_meta( $uid, 'mrt_proof_rej' );
		$lim = 'mrsh_pf_' . $uid;
		if ( (int) get_transient( $lim ) >= 5 || empty( $_FILES['shot']['name'] ) || (int) $_FILES['shot']['size'] > 3 * MB_IN_BYTES ) { // phpcs:ignore
			wp_safe_redirect( add_query_arg( 'proof', 'bad', $bk ) );
			exit;
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		$r = wp_handle_upload( $_FILES['shot'], array( // phpcs:ignore
			'test_form' => false,
			'mimes'     => array( 'jpg|jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' ),
			'unique_filename_callback' => function ( $dir, $name, $ext ) {
				return 'proof-' . wp_generate_password( 20, false ) . $ext;
			},
		) );
		if ( ! empty( $r['error'] ) || empty( $r['url'] ) ) {
			wp_safe_redirect( add_query_arg( 'proof', 'bad', $bk ) );
			exit;
		}
		set_transient( $lim, (int) get_transient( $lim ) + 1, DAY_IN_SECONDS );
		$l   = (array) get_option( 'mrsh_proofs', array() );
		$l[] = array( 'u' => $uid, 'url' => esc_url_raw( $r['url'] ), 'plan' => sanitize_text_field( wp_unslash( $_POST['plan'] ?? '' ) ), 't' => time() ); // phpcs:ignore
		update_option( 'mrsh_proofs', array_slice( $l, -200 ), false );
		wp_mail( get_option( 'admin_email' ), 'Payment proof received', 'A member sent a payment proof. Open: ' . admin_url( 'admin.php?page=mrsh-proofs' ) );
		wp_safe_redirect( add_query_arg( 'proof', 'ok', $bk ) );
		exit;
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Payment proofs', 'Payment proofs', 'manage_options', 'mrsh-proofs', array( __CLASS__, 'proofs_page' ) );
	}

	public static function proofs_page() {
		echo '<div class="wrap"><h1>Payment proofs</h1><p>Check the screenshot, then open the member and set the plan (and end date) on the Users > Edit screen. <b>Done</b> removes the entry after you set the plan. <b>Reject</b> removes the screenshot, tells the member and shows their card again. While a proof is waiting the member sees no upload card; it appears again after the days set below. Screenshots are stored in the uploads folder with a long random name.</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin:8px 0"><input type="hidden" name="action" value="mrsh_proof_days">' . wp_nonce_field( 'mrsh_proof_days', '_wpnonce', true, false ) . '<label>Hide the member card for <input type="number" name="days" min="1" max="60" value="' . (int) self::proof_days() . '" style="width:70px"> days after a proof is sent</label> <button class="button">Save</button></form><table class="widefat striped"><thead><tr><th>Date</th><th>Member</th><th>Plan asked</th><th>Screenshot</th><th></th></tr></thead><tbody>';
		$l = array_reverse( (array) get_option( 'mrsh_proofs', array() ), true );
		if ( ! $l ) {
			echo '<tr><td colspan="5">None yet.</td></tr>';
		}
		foreach ( $l as $i => $p ) {
			$u = get_userdata( (int) $p['u'] );
			echo '<tr><td>' . esc_html( wp_date( 'j M Y H:i', (int) $p['t'] ) ) . '</td><td>' . ( $u ? '<a href="' . esc_url( get_edit_user_link( $u->ID ) ) . '">' . esc_html( $u->display_name ) . '</a>' : '#' . (int) $p['u'] ) . '</td><td>' . esc_html( $p['plan'] ) . '</td><td><a href="' . esc_url( $p['url'] ) . '" target="_blank" rel="noopener">Open</a></td><td><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_proof_done"><input type="hidden" name="i" value="' . (int) $i . '">' . wp_nonce_field( 'mrsh_proof_done', '_wpnonce', true, false ) . '<button class="button" name="do" value="done">Done</button> <input type="text" name="note" placeholder="Reason (optional)" maxlength="120" style="width:150px"> <button class="button" name="do" value="reject">Reject</button></form></td></tr>';
		}
		echo '</tbody></table></div>';
	}

	public static function proof_days_save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_proof_days' );
		update_option( 'mrsh_proof_days', max( 1, min( 60, absint( $_POST['days'] ?? 7 ) ) ), false ); // phpcs:ignore
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-proofs' ) );
		exit;
	}

	public static function proof_done() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_proof_done' );
		$l = (array) get_option( 'mrsh_proofs', array() );
		$i = absint( $_POST['i'] ?? 0 ); // phpcs:ignore
		if ( isset( $l[ $i ] ) && 'reject' === ( $_POST['do'] ?? '' ) ) { // phpcs:ignore
			$p    = $l[ $i ];
			$note = sanitize_text_field( wp_unslash( $_POST['note'] ?? '' ) ); // phpcs:ignore
			$up   = wp_get_upload_dir();
			if ( ! empty( $p['url'] ) && 0 === strpos( $p['url'], $up['baseurl'] ) ) {
				$f = wp_normalize_path( $up['basedir'] . substr( $p['url'], strlen( $up['baseurl'] ) ) );
				if ( 0 === strpos( $f, wp_normalize_path( $up['basedir'] ) ) && false === strpos( $f, '..' ) ) {
					wp_delete_file( $f );
				}
			}
			update_user_meta( (int) $p['u'], 'mrt_proof_rej', array( 't' => time(), 'note' => $note ) );
			$u = get_userdata( (int) $p['u'] );
			if ( $u ) {
				wp_mail( $u->user_email, 'Your payment proof was not accepted', "Assalam o Alaikum,\n\nWe could not accept the payment proof you sent" . ( $note ? ': ' . $note : '.' ) . "\n\nPlease send it again from your account page: " . home_url( '/my-account/' ) );
			}
		}
		unset( $l[ $i ] );
		update_option( 'mrsh_proofs', array_values( $l ), false );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-proofs' ) );
		exit;
	}

	/* ---------- weekly summary (Sundays) ---------- */

	public static function weekly_summary() {
		if ( 7 !== (int) gmdate( 'N' ) ) {
			return;
		}
		$q = get_users( array( 'meta_key' => 'mrt_viewers', 'meta_compare' => 'EXISTS', 'number' => 300 ) );
		foreach ( $q as $u ) {
			$pref = MRSH_Match::pref( $u->ID );
			if ( isset( $pref['digest'] ) && ! $pref['digest'] ) {
				continue;
			}
			$v   = (array) get_user_meta( $u->ID, 'mrt_viewers', true );
			$cnt = 0;
			foreach ( $v as $t ) {
				if ( (int) $t > time() - 7 * DAY_IN_SECONDS ) {
					$cnt++;
				}
			}
			$un = MRSH_Members::unread_count( $u->ID );
			if ( ! $cnt && ! $un ) {
				continue;
			}
			$body = 'Assalam o Alaikum ' . $u->display_name . ",\n\nYour week on " . get_bloginfo( 'name' ) . ":\n- " . $cnt . " member(s) viewed your profile\n- " . $un . " unread message(s)\n\nOpen: " . home_url( '/my-account/' ) . "\n\nآپ کا ہفتہ: " . $cnt . ' ممبرز نے پروفائل دیکھی، ' . $un . " پیغامات نہیں پڑھے گئے۔\n\nNever send money to anyone you meet online.";
			wp_mail( $u->user_email, 'Your weekly summary | آپ کا ہفتہ وار خلاصہ', $body );
		}
	}

	/* ---------- moderator role ---------- */

	public static function role() {
		if ( get_option( 'mrsh_role_v' ) !== '1' ) {
			add_role( 'mrsh_moderator', 'Rishta Moderator', array( 'read' => true, 'edit_posts' => true, 'edit_others_posts' => true, 'edit_published_posts' => true, 'publish_posts' => true, 'delete_posts' => true, 'upload_files' => true ) );
			update_option( 'mrsh_role_v', '1', false );
		}
	}

	/* ---------- compare profiles ---------- */

	public static function compare_page() {
		if ( empty( $_GET['mrt_compare'] ) || 'myrishta' !== get_template() ) { // phpcs:ignore
			return;
		}
		$ids = array_slice( array_filter( array_map( 'absint', explode( ',', (string) wp_unslash( $_GET['mrt_compare'] ) ) ) ), 0, 3 ); // phpcs:ignore
		$ps  = array();
		foreach ( $ids as $id ) {
			$p = get_post( $id );
			if ( $p && 'listing_type' === $p->post_type && 'publish' === $p->post_status ) {
				$ps[] = $p;
			}
		}
		status_header( 200 );
		nocache_headers();
		add_filter( 'wp_robots', function ( $r ) { $r['noindex'] = true; return $r; } );
		get_header();
		if ( function_exists( 'mrt_page_hero' ) ) {
			mrt_page_hero( 'Compare profiles', 'Side by side, so families can decide calmly.', 'user', 'Compare' );
		}
		echo '<main class="pg"><div class="wrap">';
		if ( count( $ps ) < 2 ) {
			echo '<p>Choose two or three profiles to compare. Open a profile and press "Add to compare".</p>';
		} else {
			echo '<div style="overflow-x:auto"><table class="cmp" style="width:100%;border-collapse:collapse;background:var(--card,#fff);border-radius:14px"><thead><tr><th></th>';
			foreach ( $ps as $p ) {
				echo '<th style="padding:12px;text-align:left"><a href="' . esc_url( get_permalink( $p ) ) . '">' . esc_html( get_the_title( $p ) ) . '</a></th>';
			}
			echo '</tr></thead><tbody>';
			$rows = array( 'Age' => function ( $p ) { return (string) get_post_meta( $p->ID, 'daage', true ); }, 'Gender' => function ( $p ) { return MRSH_Match::gender( $p->ID ); } );
			foreach ( MRSH_Match::dims() as $d ) {
				$rows[ $d[2] ] = function ( $p ) use ( $d ) { return MRSH_Match::val( $p->ID, $d[0], $d[1] ); };
			}
			foreach ( $rows as $label => $fn ) {
				echo '<tr><th style="padding:10px 12px;text-align:left;border-top:1px solid var(--line,#eee)">' . esc_html( $label ) . '</th>';
				foreach ( $ps as $p ) {
					echo '<td style="padding:10px 12px;border-top:1px solid var(--line,#eee)">' . esc_html( $fn( $p ) ?: '-' ) . '</td>';
				}
				echo '</tr>';
			}
			echo '</tbody></table></div>';
		}
		echo '<p style="margin-top:14px"><a class="btn alt" href="#" onclick="try{localStorage.removeItem(\'mrt_cmp\')}catch(e){}location.href=\'' . esc_js( home_url( '/' ) ) . '\';return false">Clear comparison</a></p></div></main>';
		get_footer();
		exit;
	}

	/* ---------- family meeting checklist page ---------- */

	public static function page() {
		if ( get_option( 'mrsh_more_pages' ) || ! current_user_can( 'manage_options' ) || 'myrishta' !== get_template() ) {
			return;
		}
		if ( ! get_page_by_path( 'family-meeting-checklist' ) ) {
			wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => 'family-meeting-checklist', 'post_title' => 'Family Meeting Checklist | خاندانی ملاقات کی فہرست',
				'post_content' => '<p>Use this list before and after the first family meeting.</p><h2>Before</h2><ul><li>Both families agree on place, time and who will attend.</li><li>Confirm education, job and family background through relatives.</li><li>Write your top three must-haves and top three deal-breakers.</li><li>Make istikhara if you wish.</li></ul><h2>During</h2><ul><li>Be polite and listen to every elder.</li><li>Ask about expectations on living arrangement, work and children.</li><li>Do not discuss money transfers or gifts.</li></ul><h2>After</h2><ul><li>Reply within a few days, yes or no, with respect.</li><li>Take time for a second meeting before deciding.</li></ul><p dir="rtl" lang="ur"><b>ملاقات سے پہلے:</b> جگہ اور وقت طے کریں، رشتہ داروں سے تصدیق کریں، اپنی ترجیحات لکھ لیں۔ <b>ملاقات کے دوران:</b> بڑوں کی بات سنیں، توقعات پر بات کریں، رقم یا تحائف کی بات نہ کریں۔ <b>بعد میں:</b> چند دن میں عزت کے ساتھ جواب دیں۔</p>' ) );
		}
		update_option( 'mrsh_more_pages', 1, false );
	}

	/* ---------- front end: compare button, haptics, chat report link ---------- */

	public static function js() {
		if ( 'myrishta' !== get_template() ) {
			return;
		}
		$pid = is_singular( 'listing_type' ) ? (int) get_queried_object_id() : 0;
		?>
<script>
(function(){
function ls(k,v){try{if(v===undefined)return JSON.parse(localStorage.getItem(k)||'[]');localStorage.setItem(k,JSON.stringify(v))}catch(e){return []}}
var PID=<?php echo (int) $pid; ?>,BASE=<?php echo wp_json_encode( home_url( '/' ) ); ?>;
var list=ls('mrt_cmp');
function bar(){var o=document.getElementById('mrt-cmpbar');if(list.length<1){if(o)o.remove();return}
if(!o){o=document.createElement('a');o.id='mrt-cmpbar';o.className='btn';o.style.cssText='position:fixed;left:16px;bottom:78px;z-index:55;box-shadow:0 6px 18px rgba(0,0,0,.25)';document.body.appendChild(o)}
o.textContent='Compare ('+list.length+')';o.href=BASE+'?mrt_compare='+list.join(',')}
if(PID){var s=document.querySelector('.stick');var b=document.createElement('button');b.type='button';b.className='btn alt';
function lab(){b.textContent=list.indexOf(PID)>-1?'Remove from compare':'Add to compare'}lab();
b.onclick=function(){var i=list.indexOf(PID);if(i>-1)list.splice(i,1);else{if(list.length>=3){alert('You can compare up to 3 profiles.');return}list.push(PID)}ls('mrt_cmp',list);lab();bar()};
if(s)s.appendChild(b);else{b.style.cssText='margin:10px 0';var h=document.querySelector('main h1');if(h)h.parentNode.insertBefore(b,h.nextSibling)}}
bar();
/* haptic patterns */
document.addEventListener('click',function(e){if(!navigator.vibrate||!e.target.closest)return;var t=e.target.closest('[data-act]');if(!t)return;var a=t.getAttribute('data-act');navigator.vibrate(a==='interest'?[20,40,20]:a==='fav'||a==='hit'?15:a==='gift'?[15,30,15,30,25]:10)},true);
/* chat: report link */
var c=document.getElementById('mrt-chat');if(c){var r=document.createElement('a');r.href=BASE+'contact/';r.textContent='Report a problem with this chat';r.style.cssText='display:inline-block;margin:6px 0;font-size:.85rem;color:#b42318';c.appendChild(r)}
})();
</script>
		<?php
	}
}
MRSH_Mem_More::init();
