<?php
/**
 * Auto ads (3.101.107): posts ready-made, tracked ads to your own Facebook Page, Instagram and Telegram channel on a schedule.
 *  - These are ordinary posts on pages you own, not paid Meta ads (paid ads need a Meta ad account and payment).
 *  - Never uses member names, photos or details. Only general messages about the service.
 *  - "Connect Facebook" asks Facebook for Page access (admin only) and lists your Pages; keys are saved privately.
 *  - Each link carries utm_source / utm_campaign so Ad links shows visits and sign-ups per ad.
 * Options: mrsh_autoads (settings), mrsh_ads_conn (connected Page), mrsh_ads_pages (pages found while connecting), mrsh_ads_log.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_AutoAds {

	const OPT  = 'mrsh_autoads';
	const CONN = 'mrsh_ads_conn';

	public static function defaults() {
		return array( 'on' => 0, 'freq' => 'daily', 'hour' => 19, 'lang' => 'both', 'tg' => 1, 'fb' => 1, 'ig' => 1, 'image' => '', 'skip' => array(), 'idx' => 0, 'next' => 0, 'feed' => 1, 'feed_recycle' => 1, 'feed_gap' => 6 );
	}

	public static function get( $k = null ) {
		$o = array_merge( self::defaults(), (array) get_option( self::OPT, array() ) );
		return null === $k ? $o : ( $o[ $k ] ?? '' );
	}

	/** slug => array( label, English, Urdu, target ). {link} and {count} are filled in when posting. */
	public static function templates() {
		return array(
			'free'      => array( 'Free for families', 'Looking for a rishta? My Rishta Pakistan is completely free for families. Make a profile in three easy steps.', 'رشتہ تلاش کر رہے ہیں؟ مائی رشتہ پاکستان خاندانوں کے لیے مکمل مفت ہے۔ تین آسان مراحل میں پروفائل بنائیں۔', 'add' ),
			'private'   => array( 'Phone stays private', 'Your phone number stays private. It is shared only when the family agrees. A safe, free rishta service.', 'آپ کا فون نمبر پرائیویٹ رہتا ہے۔ خاندان کی رضامندی کے بعد ہی شیئر ہوتا ہے۔', 'home' ),
			'bride'     => array( 'For a daughter', 'Find a good rishta for your daughter. Respectable Pakistani families, free and private.', 'اپنی بیٹی کے لیے اچھا رشتہ تلاش کریں۔ معزز پاکستانی خاندان، مفت اور محفوظ۔', 'brides' ),
			'groom'     => array( 'For a son', 'Find a good rishta for your son. Respectable Pakistani families, free and private.', 'اپنے بیٹے کے لیے اچھا رشتہ تلاش کریں۔ معزز پاکستانی خاندان، مفت اور محفوظ۔', 'grooms' ),
			'verified'  => array( 'Checked profiles', 'Profiles are checked by our team. If something looks wrong, report it with one tap.', 'ہماری ٹیم پروفائلز کی جانچ کرتی ہے۔ کچھ غلط لگے تو ایک ٹیپ سے رپورٹ کریں۔', 'home' ),
			'tip'       => array( 'Safety tip', 'Rishta safety tip: never send money to someone you have not met, and involve your family from the first call.', 'حفاظتی مشورہ: جس سے ملے نہ ہوں اسے کبھی پیسے نہ بھیجیں، اور پہلی کال سے خاندان کو شامل رکھیں۔', 'home' ),
			'nonprofit' => array( 'Non-profit', 'We are a non-profit service run from Lahore. No fee to join, search or message.', 'ہم غیر منافع بخش ادارہ ہیں۔ شمولیت، تلاش اور پیغام رسانی کی کوئی فیس نہیں۔', 'home' ),
			'founding'  => array( 'Founding members', 'Join as a Founding Member: a free thank-you badge for the first families who joined.', 'بانی رکن بنیں: پہلے خاندانوں کے لیے مفت شکریہ بیج۔', 'add' ),
			'count'     => array( 'Families joined (needs 100+ members)', 'More than {count} Pakistani members have joined My Rishta. Free, private and family friendly.', '', 'home' ),
		);
	}

	private static function target( $t, $src, $slug ) {
		$base = array(
			'home'   => home_url( '/' ),
			'add'    => function_exists( 'mrt_link' ) ? mrt_link( 'add-listing', '/add-listing/' ) : home_url( '/add-listing/' ),
			'brides' => home_url( '/for-brides-families/' ),
			'grooms' => home_url( '/for-grooms-families/' ),
		);
		$u = $base[ $t ] ?? $base['home'];
		return add_query_arg( array( 'utm_source' => $src, 'utm_medium' => 'social', 'utm_campaign' => 'auto-' . $slug ), $u );
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 24 );
		add_action( 'admin_post_mrsh_ads_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_mrsh_ads_now', array( __CLASS__, 'now' ) );
		add_action( 'admin_post_mrsh_ads_connect', array( __CLASS__, 'connect' ) );
		add_action( 'admin_post_mrsh_ads_fbcb', array( __CLASS__, 'callback' ) );
		add_action( 'admin_post_mrsh_ads_pick', array( __CLASS__, 'pick' ) );
		add_action( 'admin_post_mrsh_ads_forget', array( __CLASS__, 'forget' ) );
		add_action( 'mrsh_autoads_tick', array( __CLASS__, 'tick' ) );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
		add_action( 'transition_post_status', array( __CLASS__, 'feed_queue' ), 9, 3 );
		add_action( 'admin_post_mrsh_feed_now', array( __CLASS__, 'feed_now' ) );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Auto ads', 'Auto ads', 'manage_options', 'mrsh-autoads', array( __CLASS__, 'page' ) );
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( 'mrsh_autoads_tick' ) ) {
			wp_schedule_event( time() + 300, 'hourly', 'mrsh_autoads_tick' );
		}
	}

	/* ---------- credentials ---------- */

	private static function cred() {
		$i = class_exists( 'MRSH_Mem_Integr' ) ? MRSH_Mem_Integr::get() : array();
		$c = (array) get_option( self::CONN, array() );
		return array(
			'tg_token' => (string) ( $i['tg_token'] ?? '' ),
			'tg_chat'  => (string) ( $i['tg_chat'] ?? '' ),
			'fb_page'  => (string) ( $c['page'] ?? ( $i['fb_page'] ?? '' ) ),
			'fb_token' => (string) ( $c['token'] ?? ( $i['fb_token'] ?? '' ) ),
			'ig_id'    => (string) ( $c['ig'] ?? ( $i['ig_id'] ?? '' ) ),
			'name'     => (string) ( $c['name'] ?? '' ),
		);
	}

	/* ---------- composing and sending ---------- */

	private static function member_count() {
		$u = count_users();
		return (int) ( $u['total_users'] ?? 0 );
	}

	public static function text( $slug, $src ) {
		if ( 0 === strpos( $slug, 'post:' ) ) {
			return self::feed_text( (int) substr( $slug, 5 ), $src );
		}
		$t = self::templates();
		if ( ! isset( $t[ $slug ] ) ) {
			return '';
		}
		$n   = self::member_count();
		$en  = str_replace( '{count}', (string) ( floor( $n / 50 ) * 50 ), $t[ $slug ][1] );
		$ur  = $t[ $slug ][2];
		$lg  = self::get( 'lang' );
		$out = 'en' === $lg || '' === $ur ? $en : ( 'ur' === $lg ? $ur : $en . "\n\n" . $ur );
		return $out . "\n\n" . self::target( $t[ $slug ][3], $src, $slug );
	}

	/** Ads that can run now (members count rule for the "count" ad), in order. */
	private static function pool() {
		$skip = (array) self::get( 'skip' );
		$out  = array();
		foreach ( array_keys( self::templates() ) as $s ) {
			if ( in_array( $s, $skip, true ) || ( 'count' === $s && self::member_count() < 100 ) ) {
				continue;
			}
			$out[] = $s;
		}
		return $out;
	}

	/** Sends one ad to every ready channel. Returns array of channel => message. */
	public static function post_one( $slug = '' ) {
		$pool = self::pool();
		$feed = 0 === strpos( $slug, 'post:' ) && self::feed_ok( (int) substr( $slug, 5 ) );
		if ( ! $pool && ! $feed ) {
			return array( 'ads' => 'No ad is switched on.' );
		}
		$o = self::get();
		if ( ! $feed && ( '' === $slug || ! in_array( $slug, $pool, true ) ) ) {
			$slug = $pool[ (int) $o['idx'] % count( $pool ) ];
		}
		$c   = self::cred();
		$res = array();
		$img = $o['image'] ? $o['image'] : ( defined( 'MRSH_URL' ) ? MRSH_URL . 'assets/logos/ads-square-1200x1200.png' : '' );
		if ( $feed ) {
			$th  = get_the_post_thumbnail_url( (int) substr( $slug, 5 ), 'large' );
			$img = $th ? $th : $img;
		}
		if ( ! empty( $o['tg'] ) && $c['tg_token'] && $c['tg_chat'] ) {
			$r = wp_remote_post( 'https://api.telegram.org/bot' . rawurlencode( $c['tg_token'] ) . '/sendMessage', array( 'timeout' => 15, 'body' => array( 'chat_id' => $c['tg_chat'], 'text' => self::text( $slug, 'telegram' ) ) ) );
			$res['Telegram'] = self::result( $r );
		}
		$bad = (int) get_option( 'mrsh_ads_tokbad', 0 );
		if ( $bad && time() - $bad > 12 * HOUR_IN_SECONDS ) { // try again after 12 hours in case the key was fixed by hand
			delete_option( 'mrsh_ads_tokbad' );
			$bad = 0;
		}
		if ( $bad ) {
			$c['fb_token']   = ''; // paused until reconnected: no point sending requests Facebook will refuse
			$res['Facebook'] = 'Paused: Facebook login expired. Press Reconnect on the Auto ads page.';
		}
		if ( ! empty( $o['fb'] ) && $c['fb_page'] && $c['fb_token'] ) {
			$t   = self::text( $slug, 'facebook' );
			$lnk = preg_match( '#https?://\S+$#', $t, $m ) ? $m[0] : '';
			$r   = wp_remote_post( 'https://graph.facebook.com/v19.0/' . rawurlencode( $c['fb_page'] ) . '/feed', array( 'timeout' => 20, 'body' => array( 'message' => trim( str_replace( $lnk, '', $t ) ), 'link' => $lnk, 'access_token' => $c['fb_token'] ) ) );
			$res['Facebook'] = self::result( $r );
		}
		if ( ! empty( $o['ig'] ) && $c['ig_id'] && $c['fb_token'] && $img ) {
			$cap = preg_replace( '#\s*https?://\S+$#', '', self::text( $slug, 'instagram' ) ) . "\n\n" . home_url( '/' );
			$r   = wp_remote_post( 'https://graph.facebook.com/v19.0/' . rawurlencode( $c['ig_id'] ) . '/media', array( 'timeout' => 25, 'body' => array( 'image_url' => $img, 'caption' => $cap, 'access_token' => $c['fb_token'] ) ) );
			$d   = is_wp_error( $r ) ? null : json_decode( wp_remote_retrieve_body( $r ), true );
			if ( ! empty( $d['id'] ) ) {
				$r2              = wp_remote_post( 'https://graph.facebook.com/v19.0/' . rawurlencode( $c['ig_id'] ) . '/media_publish', array( 'timeout' => 25, 'body' => array( 'creation_id' => $d['id'], 'access_token' => $c['fb_token'] ) ) );
				$res['Instagram'] = self::result( $r2 );
			} else {
				$res['Instagram'] = self::result( $r );
			}
		}
		if ( class_exists( 'MRSH_AutoAds_More' ) ) {
			$res = array_merge( $res, MRSH_AutoAds_More::send_all( $slug, $img ) );
		}
		if ( ! $res ) {
			return array( 'channels' => 'No channel is connected yet.' );
		}
		if ( ! $feed ) {
			$o['idx'] = (int) $o['idx'] + 1;
			update_option( self::OPT, array_merge( (array) get_option( self::OPT, array() ), array( 'idx' => $o['idx'] ) ), false );
		}
		$log   = (array) get_option( 'mrsh_ads_log', array() );
		$log[] = array( 't' => time(), 'a' => $slug, 'r' => $res );
		update_option( 'mrsh_ads_log', array_slice( $log, -40 ), false );
		return $res;
	}

	public static function result( $r ) {
		if ( is_wp_error( $r ) ) {
			return 'Failed: ' . $r->get_error_message();
		}
		$c = (int) wp_remote_retrieve_response_code( $r );
		if ( $c >= 200 && $c < 300 ) {
			return 'Posted';
		}
		$d = json_decode( wp_remote_retrieve_body( $r ), true );
		$m = (string) ( $d['error']['message'] ?? ( $d['description'] ?? '' ) );
		if ( 190 === (int) ( $d['error']['code'] ?? 0 ) || false !== stripos( $m, 'access token' ) ) {
			if ( ! get_option( 'mrsh_ads_tokbad' ) ) {
				wp_mail( get_option( 'admin_email' ), 'Facebook posting stopped: please reconnect', "Facebook says the saved access token is invalid or expired, so posts to Facebook and Instagram are paused.\n\nOpen Auto ads and press Reconnect Facebook and Instagram:\n" . admin_url( 'admin.php?page=mrsh-autoads' ) );
			}
			update_option( 'mrsh_ads_tokbad', time(), false );
			return 'Facebook login expired. Press Reconnect on the Auto ads page.';
		}
		return 'Not accepted (' . $c . ')' . ( $m ? ': ' . substr( sanitize_text_field( $m ), 0, 160 ) : '' );
	}

	/** Next time for the chosen hour (site time) after $from. */
	private static function next_after( $from ) {
		$o   = self::get();
		$tz  = wp_timezone();
		$d   = ( new DateTimeImmutable( '@' . (int) $from ) )->setTimezone( $tz )->setTime( (int) $o['hour'], 0, 0 );
		$add = array( 'daily' => 1, 'every2' => 2, 'weekly' => 7 );
		$d   = $d->modify( '+' . ( $add[ $o['freq'] ] ?? 1 ) . ' day' );
		return $d->getTimestamp();
	}

	public static function tick() {
		$o = self::get();
		self::feed_tick();
		if ( empty( $o['on'] ) || get_transient( 'mrsh_ads_lock' ) ) {
			return;
		}
		if ( (int) $o['next'] <= 0 ) { // first run: set the first time, do not post at once
			self::set_next( self::first_time() );
			return;
		}
		if ( time() < (int) $o['next'] ) {
			return;
		}
		set_transient( 'mrsh_ads_lock', 1, 10 * MINUTE_IN_SECONDS );
		$old = ! empty( $o['feed'] ) && ! empty( $o['feed_recycle'] ) && 0 === (int) $o['idx'] % 2 ? self::feed_old() : 0; // every second slot shows a good older article
		self::post_one( $old ? 'post:' . $old : '' );
		if ( $old ) { // an article slot still counts as one turn, so the next slot is a normal ad
			update_option( self::OPT, array_merge( (array) get_option( self::OPT, array() ), array( 'idx' => (int) $o['idx'] + 1 ) ), false );
		}
		self::set_next( self::next_after( time() ) );
	}

	private static function first_time() {
		$o = self::get();
		$d = ( new DateTimeImmutable( 'now', wp_timezone() ) )->setTime( (int) $o['hour'], 0, 0 );
		return $d->getTimestamp() > time() + 600 ? $d->getTimestamp() : $d->modify( '+1 day' )->getTimestamp();
	}

	private static function set_next( $t ) {
		update_option( self::OPT, array_merge( (array) get_option( self::OPT, array() ), array( 'next' => (int) $t ) ), false );
	}

	/* ---------- feeder: real articles go to the same channels ---------- */

	const FEED = 'mrsh_feed_state';

	private static function fstate() {
		return array_merge( array( 'q' => array(), 'last' => 0 ), (array) get_option( self::FEED, array() ) );
	}

	private static function fsave( $st ) {
		update_option( self::FEED, $st, false );
	}

	/** An article can be shared: published blog post without a password. */
	private static function feed_ok( $id ) {
		$p = $id ? get_post( $id ) : null;
		return $p && 'post' === $p->post_type && 'publish' === $p->post_status && '' === $p->post_password;
	}

	public static function feed_text( $id, $src ) {
		$p = get_post( $id );
		if ( ! $p ) {
			return '';
		}
		$ttl = html_entity_decode( get_the_title( $p ), ENT_QUOTES, 'UTF-8' );
		$sum = wp_trim_words( wp_strip_all_tags( strip_shortcodes( $p->post_excerpt ? $p->post_excerpt : $p->post_content ) ), 30, '...' );
		$lnk = add_query_arg( array( 'utm_source' => $src, 'utm_medium' => 'social', 'utm_campaign' => 'feed-post' ), get_permalink( $p ) );
		$lg  = self::get( 'lang' );
		$ur  = 'en' === $lg ? '' : "\n\n" . 'مکمل تحریر پڑھیں:';
		return $ttl . "\n\n" . $sum . $ur . "\n\n" . $lnk;
	}

	/** A new article is queued the moment it is published. */
	public static function feed_queue( $new, $old, $post ) {
		if ( $new === $old || 'publish' !== $new || ! $post || 'post' !== $post->post_type || ! self::get( 'feed' ) || get_post_meta( $post->ID, '_mrsh_social_done', true ) ) {
			return;
		}
		update_post_meta( $post->ID, '_mrsh_social_done', 1 ); // stops the older single-post sharing from posting it a second time
		$st      = self::fstate();
		$st['q'] = array_values( array_unique( array_merge( (array) $st['q'], array( (int) $post->ID ) ) ) );
		self::fsave( $st );
	}

	/** Hourly: send the next queued article if enough hours have passed since the last one. */
	public static function feed_tick() {
		$o = self::get();
		if ( empty( $o['feed'] ) || get_transient( 'mrsh_feed_lock' ) ) {
			return;
		}
		$st = self::fstate();
		if ( empty( $st['q'] ) || time() < (int) $st['last'] + max( 1, (int) $o['feed_gap'] ) * HOUR_IN_SECONDS ) {
			return;
		}
		set_transient( 'mrsh_feed_lock', 1, 10 * MINUTE_IN_SECONDS );
		self::feed_send( (int) array_shift( $st['q'] ), $st );
	}

	private static function feed_send( $id, $st ) {
		$r = array();
		if ( self::feed_ok( $id ) ) {
			$r = self::post_one( 'post:' . $id );
			update_post_meta( $id, '_mrsh_feed_t', time() );
			$st['last'] = time();
		}
		self::fsave( $st );
		return $r;
	}

	/** An older article that has not been shared for 60 days, picked at random. */
	private static function feed_old() {
		$q = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 1, 'orderby' => 'rand', 'fields' => 'ids', 'has_password' => false, 'no_found_rows' => true,
			'meta_query' => array( 'relation' => 'OR', array( 'key' => '_mrsh_feed_t', 'compare' => 'NOT EXISTS' ), array( 'key' => '_mrsh_feed_t', 'value' => time() - 60 * DAY_IN_SECONDS, 'compare' => '<', 'type' => 'NUMERIC' ) ),
			'date_query' => array( array( 'before' => '3 days ago' ) ) ) );
		return $q ? (int) $q[0] : 0;
	}

	public static function feed_now() {
		self::guard( 'mrsh_feed_now' );
		$id = absint( $_POST['pid'] ?? 0 ); // phpcs:ignore
		$id = $id ? $id : self::feed_old();
		if ( ! self::feed_ok( $id ) ) {
			set_transient( 'mrsh_ads_last', array( 'Feeder' => 'No published article found to share.' ), 5 * MINUTE_IN_SECONDS );
			self::back( 'sent=1' );
		}
		$st      = self::fstate();
		$st['q'] = array_values( array_diff( (array) $st['q'], array( $id ) ) );
		set_transient( 'mrsh_ads_last', self::feed_send( $id, $st ), 5 * MINUTE_IN_SECONDS );
		self::back( 'sent=1' );
	}

	/* ---------- admin actions ---------- */

	private static function guard( $nonce ) {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( $nonce ) ) {
			wp_die( 'Not allowed.' );
		}
	}

	private static function back( $arg = 'ok=1' ) {
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-autoads&' . $arg ) );
		exit;
	}

	public static function save() {
		self::guard( 'mrsh_ads_save' );
		$o  = (array) get_option( self::OPT, array() );
		$old = self::get();
		$o['on']   = empty( $_POST['on'] ) ? 0 : 1; // phpcs:ignore
		$o['freq'] = in_array( $_POST['freq'] ?? '', array( 'daily', 'every2', 'weekly' ), true ) ? $_POST['freq'] : 'daily'; // phpcs:ignore
		$o['hour'] = max( 0, min( 23, absint( $_POST['hour'] ?? 19 ) ) ); // phpcs:ignore
		$o['lang'] = in_array( $_POST['lang'] ?? '', array( 'en', 'ur', 'both' ), true ) ? $_POST['lang'] : 'both'; // phpcs:ignore
		foreach ( array( 'tg', 'fb', 'ig' ) as $k ) {
			$o[ $k ] = empty( $_POST[ $k ] ) ? 0 : 1; // phpcs:ignore
		}
		$o['feed']         = empty( $_POST['feed'] ) ? 0 : 1; // phpcs:ignore
		$o['feed_recycle'] = empty( $_POST['feed_recycle'] ) ? 0 : 1; // phpcs:ignore
		$o['feed_gap']     = max( 1, min( 72, absint( $_POST['feed_gap'] ?? 6 ) ) ); // phpcs:ignore
		$o['image'] = isset( $_POST['image'] ) ? esc_url_raw( wp_unslash( $_POST['image'] ) ) : ''; // phpcs:ignore
		$ons        = isset( $_POST['ad'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['ad'] ) ) : array(); // phpcs:ignore
		$o['skip']  = array_values( array_diff( array_keys( self::templates() ), $ons ) );
		if ( $o['on'] && ( empty( $old['on'] ) || $old['freq'] !== $o['freq'] || (int) $old['hour'] !== (int) $o['hour'] ) ) {
			$o['next'] = 0; // the next time is worked out again
		}
		update_option( self::OPT, $o, false );
		if ( $o['on'] ) {
			self::schedule();
			self::set_next( self::first_time() );
		}
		self::back();
	}

	public static function now() {
		self::guard( 'mrsh_ads_now' );
		$r = self::post_one( sanitize_key( wp_unslash( $_POST['ad'] ?? '' ) ) ); // phpcs:ignore
		set_transient( 'mrsh_ads_last', $r, 5 * MINUTE_IN_SECONDS );
		self::back( 'sent=1' );
	}

	/* ---------- connect Facebook (admin only) ---------- */

	private static function fbapp() {
		return class_exists( 'MRSH_Mem_Social' ) ? array( (string) MRSH_Mem_Social::get( 'fb_id' ), (string) MRSH_Mem_Social::get( 'fb_secret' ) ) : array( '', '' );
	}

	public static function redirect_uri() {
		return admin_url( 'admin-post.php?action=mrsh_ads_fbcb' );
	}

	public static function connect() {
		self::guard( 'mrsh_ads_connect' );
		$a = self::fbapp();
		if ( ! $a[0] || ! $a[1] ) {
			self::back( 'err=' . rawurlencode( 'Add the Facebook App ID and secret on the Social login page first.' ) );
		}
		$st = wp_generate_password( 24, false );
		set_transient( 'mrsh_adsst_' . $st, get_current_user_id(), 10 * MINUTE_IN_SECONDS );
		$u = add_query_arg( array( 'client_id' => $a[0], 'redirect_uri' => self::redirect_uri(), 'state' => $st, 'scope' => 'pages_show_list,pages_manage_posts,pages_read_engagement,instagram_basic,instagram_content_publish' ), 'https://www.facebook.com/v19.0/dialog/oauth' );
		wp_redirect( $u ); // phpcs:ignore WordPress.Security.SafeRedirect -- fixed Facebook address
		exit;
	}

	public static function callback() {
		$st  = sanitize_text_field( wp_unslash( $_GET['state'] ?? '' ) ); // phpcs:ignore
		$code = sanitize_text_field( wp_unslash( $_GET['code'] ?? '' ) ); // phpcs:ignore
		$who = $st ? (int) get_transient( 'mrsh_adsst_' . $st ) : 0;
		if ( ! current_user_can( 'manage_options' ) || ! $who || $who !== get_current_user_id() || ! $code ) {
			self::back( 'err=' . rawurlencode( 'Facebook connection was cancelled or expired. Please try again.' ) );
		}
		delete_transient( 'mrsh_adsst_' . $st );
		$a = self::fbapp();
		$g = function ( $url ) {
			$r = wp_remote_get( $url, array( 'timeout' => 20 ) );
			return is_wp_error( $r ) ? array() : (array) json_decode( wp_remote_retrieve_body( $r ), true );
		};
		$t = $g( add_query_arg( array( 'client_id' => $a[0], 'client_secret' => $a[1], 'redirect_uri' => self::redirect_uri(), 'code' => $code ), 'https://graph.facebook.com/v19.0/oauth/access_token' ) );
		if ( empty( $t['access_token'] ) ) {
			self::back( 'err=' . rawurlencode( 'Facebook did not give access. Check the redirect address in the Facebook app.' ) );
		}
		$l   = $g( add_query_arg( array( 'grant_type' => 'fb_exchange_token', 'client_id' => $a[0], 'client_secret' => $a[1], 'fb_exchange_token' => $t['access_token'] ), 'https://graph.facebook.com/v19.0/oauth/access_token' ) );
		$tok = ! empty( $l['access_token'] ) ? $l['access_token'] : $t['access_token'];
		$p   = $g( add_query_arg( array( 'fields' => 'id,name,access_token,instagram_business_account{id,username}', 'access_token' => $tok ), 'https://graph.facebook.com/v19.0/me/accounts' ) );
		$out = array();
		foreach ( (array) ( $p['data'] ?? array() ) as $pg ) {
			if ( ! empty( $pg['id'] ) && ! empty( $pg['access_token'] ) ) {
				$out[] = array( 'id' => (string) $pg['id'], 'name' => sanitize_text_field( $pg['name'] ?? '' ), 'token' => (string) $pg['access_token'], 'ig' => (string) ( $pg['instagram_business_account']['id'] ?? '' ), 'ign' => sanitize_text_field( $pg['instagram_business_account']['username'] ?? '' ) );
			}
		}
		if ( ! $out ) {
			self::back( 'err=' . rawurlencode( 'No Facebook Page was found for this login. Make sure you are an admin of the Page.' ) );
		}
		update_option( 'mrsh_ads_pages', $out, false );
		self::back( 'pick=1' );
	}

	public static function pick() {
		self::guard( 'mrsh_ads_pick' );
		$id = sanitize_text_field( wp_unslash( $_POST['page'] ?? '' ) ); // phpcs:ignore
		foreach ( (array) get_option( 'mrsh_ads_pages', array() ) as $pg ) {
			if ( (string) $pg['id'] === $id ) {
				update_option( self::CONN, array( 'page' => $pg['id'], 'name' => $pg['name'], 'token' => $pg['token'], 'ig' => $pg['ig'], 'ign' => $pg['ign'] ), false );
				delete_option( 'mrsh_ads_tokbad' ); // a fresh login: posting starts again
				break;
			}
		}
		delete_option( 'mrsh_ads_pages' ); // the other pages' keys are not kept
		self::back();
	}

	public static function forget() {
		self::guard( 'mrsh_ads_forget' );
		delete_option( self::CONN );
		delete_option( 'mrsh_ads_pages' );
		self::back();
	}

	/* ---------- page ---------- */

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) || ! class_exists( 'MRSH_Boost' ) ) {
			return;
		}
		$o  = self::get();
		$c  = self::cred();
		$tg = $c['tg_token'] && $c['tg_chat'];
		$fb = $c['fb_page'] && $c['fb_token'];
		$ig = $c['ig_id'] && $c['fb_token'];
		MRSH_Boost::ui_open( 'Auto ads', 'Posts ready-made, tracked ads to your own social pages (Facebook, Instagram, Telegram, X, Bluesky, Mastodon, LinkedIn and more) on a schedule. These are normal posts on pages you own, not paid ads.', 'g-gold', 'M3 11v2l13 5V6zM18 8.500v7l3 1.500v-10z' );
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			MRSH_Boost::ui_ok( 'Saved.' );
		}
		if ( ! empty( $_GET['err'] ) ) { // phpcs:ignore
			echo '<div class="mx-ok" style="background:#fef3f2;color:#912018;box-shadow:0 0 0 1px #fecdca">' . esc_html( sanitize_text_field( wp_unslash( $_GET['err'] ) ) ) . '</div>'; // phpcs:ignore
		}
		if ( isset( $_GET['sent'] ) ) { // phpcs:ignore
			$r = (array) get_transient( 'mrsh_ads_last' );
			$h = '';
			foreach ( $r as $k => $v ) {
				$h .= esc_html( $k . ': ' . $v ) . '<br>';
			}
			echo '<div class="mx-ok" style="display:block">' . ( $h ? $h : 'Done.' ) . '</div>'; // phpcs:ignore
		}
		$nx = (int) $o['next'];
		echo '<div class="mx-stats">' . MRSH_Boost::ui_stat( $o['on'] ? 'On' : 'Off', 'Automatic ads', $o['on'] ? '#10b981' : '#9ca3af' ) . MRSH_Boost::ui_stat( $o['on'] && $nx ? wp_date( 'j M, g:i a', $nx ) : '-', 'Next ad', '#4a69d6' ) . MRSH_Boost::ui_stat( count( (array) get_option( 'mrsh_ads_log', array() ) ), 'Ads sent (last 40)', '#e11d74' ) . MRSH_Boost::ui_stat( count( self::pool() ), 'Ads in rotation', '#f59e0b' ) . MRSH_Boost::ui_stat( ! empty( $o['feed'] ) ? count( (array) self::fstate()['q'] ) . ' queued' : 'Off', 'Article feeder', '#1877f2' ) . '</div>'; // phpcs:ignore

		// 1. connections
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">1</span><h2>Connect your social pages</h2></div><p class="mx-sub">Logging in with Google or Facebook does not give permission to post. Connecting a Page is a separate step, done by you as admin.</p>';
		if ( get_option( 'mrsh_ads_tokbad' ) ) {
			echo '<div class="mx-ok" style="background:#fef3f2;color:#912018;box-shadow:0 0 0 1px #fecdca;display:block"><b>Facebook login is invalid or expired.</b> Posts to Facebook and Instagram are paused. Press <b>Reconnect Facebook and Instagram</b> below, choose your Page, and it starts again by itself.</div>';
		}
		echo '<div class="mx-acts" style="margin-bottom:12px"><span class="mx-pill ' . ( $fb ? 'ok' : 'warn' ) . '">Facebook Page: ' . esc_html( $fb ? ( $c['name'] ? $c['name'] : 'connected' ) : 'not connected' ) . '</span><span class="mx-pill ' . ( $ig ? 'ok' : 'warn' ) . '">Instagram: ' . ( $ig ? 'connected' : 'not connected' ) . '</span><span class="mx-pill ' . ( $tg ? 'ok' : 'warn' ) . '">Telegram: ' . ( $tg ? 'connected' : 'not connected' ) . '</span></div>';
		echo '<div class="mx-acts"><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'mrsh_ads_connect' );
		echo '<input type="hidden" name="action" value="mrsh_ads_connect"><button class="mx-btn p">' . ( $fb ? 'Reconnect Facebook and Instagram' : 'Connect Facebook and Instagram' ) . '</button></form>';
		if ( $fb ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( 'mrsh_ads_forget' );
			echo '<input type="hidden" name="action" value="mrsh_ads_forget"><button class="mx-btn d">Disconnect</button></form>';
		}
		echo '<a class="mx-btn" href="' . esc_url( admin_url( 'admin.php?page=mrsh-int' ) ) . '">Telegram keys (Integrations)</a></div>';
		$pg = (array) get_option( 'mrsh_ads_pages', array() );
		if ( $pg ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin-top:16px"><b>Choose the Page to post to</b><div class="mx-chips" style="margin:10px 0">';
			wp_nonce_field( 'mrsh_ads_pick' );
			foreach ( $pg as $i => $p ) {
				echo '<label class="mx-chip" style="--d:#1877f2"><input type="radio" name="page" value="' . esc_attr( $p['id'] ) . '"' . ( 0 === $i ? ' checked' : '' ) . '><span>' . esc_html( $p['name'] . ( $p['ign'] ? ' + Instagram @' . $p['ign'] : '' ) ) . '</span></label>';
			}
			echo '</div><input type="hidden" name="action" value="mrsh_ads_pick"><button class="mx-btn p">Use this Page</button></form>';
		}
		echo '<p class="mx-note">Needs the Facebook App from Social login. In the Facebook app add this address under Facebook Login > Valid OAuth Redirect URIs: <code>' . esc_html( self::redirect_uri() ) . '</code>. While the Facebook app is in development mode, only people with a role in the app (you) can connect; posting to your own Page then works without Meta review. Instagram must be a business account linked to the Page and needs a picture (below).</p></div>';

		if ( class_exists( 'MRSH_AutoAds_More' ) ) {
			MRSH_AutoAds_More::panel();
		}

		// 2. schedule + ads
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_ads_save">';
		wp_nonce_field( 'mrsh_ads_save' );
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">2</span><h2>Schedule</h2></div><p class="mx-sub">One ad at a time, rotating through the ads you keep switched on. The first ad goes out at the next chosen hour.</p>';
		echo '<div class="mx-f"><label class="mx-sw"><input type="checkbox" name="on" value="1"' . checked( ! empty( $o['on'] ), true, false ) . '><span class="tr"></span><span class="lb">Send ads automatically</span></label></div>';
		echo '<div class="mx-grid" style="margin-top:16px"><div class="mx-f"><label class="t" for="fq">How often</label><select id="fq" name="freq">';
		foreach ( array( 'daily' => 'Every day', 'every2' => 'Every 2 days', 'weekly' => 'Once a week' ) as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $o['freq'], $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select></div><div class="mx-f"><label class="t" for="hr">At what hour (site time)</label><select id="hr" name="hour">';
		for ( $h = 0; $h < 24; $h++ ) {
			echo '<option value="' . (int) $h . '"' . selected( (int) $o['hour'], $h, false ) . '>' . esc_html( gmdate( 'g a', $h * 3600 ) ) . '</option>';
		}
		echo '</select></div><div class="mx-f"><label class="t" for="lg">Language</label><select id="lg" name="lang">';
		foreach ( array( 'both' => 'English and Urdu', 'en' => 'English only', 'ur' => 'Urdu only' ) as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $o['lang'], $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select></div></div><div class="mx-grid" style="margin-top:16px">';
		foreach ( array( 'fb' => 'Post to Facebook', 'ig' => 'Post to Instagram', 'tg' => 'Post to Telegram' ) as $k => $l ) {
			echo '<div class="mx-f"><label class="mx-sw"><input type="checkbox" name="' . esc_attr( $k ) . '" value="1"' . checked( ! empty( $o[ $k ] ), true, false ) . '><span class="tr"></span><span class="lb">' . esc_html( $l ) . '</span></label></div>';
		}
		echo '</div><div class="mx-f" style="margin-top:16px"><label class="t" for="im">Picture for Instagram (address, optional)</label><input type="text" id="im" name="image" value="' . esc_attr( $o['image'] ) . '" placeholder="Leave empty to use the square site picture"><span class="hint">Instagram needs a picture. It must be a public .jpg or .png address.</span></div></div>';

		$fs = self::fstate();
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">&#9733;</span><h2>Feeder: your articles on Facebook</h2></div><p class="mx-sub">Every new blog or SEO article you publish (including the weekly robot articles) is shared by itself to the connected pages, with its picture, a short Urdu line and a tracked link. No extra work.</p>';
		echo '<div class="mx-f"><label class="mx-sw"><input type="checkbox" name="feed" value="1"' . checked( ! empty( $o['feed'] ), true, false ) . '><span class="tr"></span><span class="lb">Share new articles automatically</span></label></div>';
		echo '<div class="mx-f" style="margin-top:12px"><label class="mx-sw"><input type="checkbox" name="feed_recycle" value="1"' . checked( ! empty( $o['feed_recycle'] ), true, false ) . '><span class="tr"></span><span class="lb">Also bring back a good older article in every second ad slot</span></label></div>';
		echo '<div class="mx-f" style="margin-top:16px;max-width:320px"><label class="t" for="fg">Hours to wait between two articles</label><input type="number" id="fg" name="feed_gap" min="1" max="72" value="' . (int) $o['feed_gap'] . '"><span class="hint">Stops several articles from flooding the page at once.</span></div>';
		echo '<p class="mx-note" style="margin-top:14px">Waiting in the queue now: <b>' . count( (array) $fs['q'] ) . '</b>. Last article shared: <b>' . esc_html( $fs['last'] ? wp_date( 'j M, g:i a', (int) $fs['last'] ) : 'none yet' ) . '</b>. Only your own articles are shared, never member profiles.</p></div>';

		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">3</span><h2>Ads</h2></div><p class="mx-sub">Switch off any ad you do not want. Each ad link is tracked: see visits and sign-ups on Ad links (campaign names start with auto-). Ads never use member names, photos or details.</p>';
		$skip = (array) $o['skip'];
		foreach ( self::templates() as $slug => $t ) {
			$dis = 'count' === $slug && self::member_count() < 100;
			echo '<div class="mx-rep"><div class="who"><label class="mx-sw"><input type="checkbox" name="ad[]" value="' . esc_attr( $slug ) . '"' . checked( ! in_array( $slug, $skip, true ) && ! $dis, true, false ) . ( $dis ? ' disabled' : '' ) . '><span class="tr"></span><span class="lb">' . esc_html( $t[0] ) . '</span></label><p style="margin:8px 0 0 66px;color:#6b7280;font-size:13.5px;line-height:1.55">' . esc_html( str_replace( '{count}', '100+', $t[1] ) ) . '</p></div></div>';
		}
		echo '<p style="margin:16px 0 0"><button class="mx-btn p">Save</button></p></div></form>';

		// 4. post now
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">4</span><h2>Send one now</h2></div><p class="mx-sub">Sends one ad straight away to the connected pages, so you can check how it looks.</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="mx-acts">';
		wp_nonce_field( 'mrsh_ads_now' );
		echo '<input type="hidden" name="action" value="mrsh_ads_now"><select name="ad" style="height:44px;border-radius:13px;min-width:240px;padding:0 12px"><option value="">Next ad in the rotation</option>';
		foreach ( self::pool() as $s ) {
			echo '<option value="' . esc_attr( $s ) . '">' . esc_html( self::templates()[ $s ][0] ) . '</option>';
		}
		echo '</select><button class="mx-btn">Send one ad now</button></form></div>';

		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">&#9733;</span><h2>Share an article now</h2></div><p class="mx-sub">Pick one article, or leave it empty to share a good older one.</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="mx-acts">';
		wp_nonce_field( 'mrsh_feed_now' );
		echo '<input type="hidden" name="action" value="mrsh_feed_now"><select name="pid" style="height:44px;border-radius:13px;min-width:240px;max-width:100%;padding:0 12px"><option value="">A good older article</option>';
		foreach ( get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 25, 'no_found_rows' => true ) ) as $bp ) {
			echo '<option value="' . (int) $bp->ID . '">' . esc_html( wp_html_excerpt( html_entity_decode( get_the_title( $bp ), ENT_QUOTES, 'UTF-8' ), 70, '...' ) ) . '</option>';
		}
		echo '</select><button class="mx-btn">Share article now</button></form></div>';

		// 5. log
		$log = array_reverse( (array) get_option( 'mrsh_ads_log', array() ) );
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">5</span><h2>Recent ads</h2></div>';
		if ( ! $log ) {
			echo '<div class="mx-empty"><b>Nothing sent yet</b><p>Ads you send appear here with the result for each page.</p></div>';
		}
		foreach ( array_slice( $log, 0, 12 ) as $l ) {
			$rs = '';
			foreach ( (array) $l['r'] as $k => $v ) {
				$rs .= '<span class="mx-pill ' . ( 'Posted' === $v ? 'ok' : 'bad' ) . '" title="' . esc_attr( $v ) . '">' . esc_html( $k . ': ' . ( 'Posted' === $v ? 'posted' : substr( $v, 0, 60 ) ) ) . '</span> ';
			}
			$tl = self::templates();
			echo '<div class="mx-rep"><div class="who"><b>' . esc_html( 0 === strpos( (string) $l['a'], 'post:' ) ? 'Article: ' . wp_html_excerpt( html_entity_decode( get_the_title( (int) substr( $l['a'], 5 ) ), ENT_QUOTES, 'UTF-8' ), 60, '...' ) : ( $tl[ $l['a'] ][0] ?? $l['a'] ) ) . '</b> <span class="mx-pill">' . esc_html( wp_date( 'j M, g:i a', (int) $l['t'] ) ) . '</span><div class="why">' . $rs . '</div></div></div>'; // phpcs:ignore
		}
		if ( class_exists( 'MRSH_AdsTools' ) ) {
			MRSH_AdsTools::panel( 'auto' );
		}
		echo '<p class="mx-note">The Urdu lines are written for quick use; please have a native Urdu reader check them. Posting only runs when someone opens the site or WordPress cron runs, so very quiet sites may post a little late.</p></div></div>';
	}
}
MRSH_AutoAds::init();
