<?php
/**
 * Small, safe hardening for a members site: security headers, no user listing for visitors, no XML-RPC, plain login errors.
 * Switch off with define( 'MRSH_NO_HARDEN', true ) in wp-config.php if a rule ever clashes with another plugin.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Mem_Harden {

	public static function init() {
		if ( defined( 'MRSH_NO_HARDEN' ) && MRSH_NO_HARDEN ) {
			return;
		}
		add_action( 'send_headers', array( __CLASS__, 'headers' ) );
		add_filter( 'rest_endpoints', array( __CLASS__, 'rest' ) );
		add_filter( 'xmlrpc_enabled', '__return_false' );
		add_filter( 'login_errors', array( __CLASS__, 'login_error' ) );
		add_action( 'template_redirect', array( __CLASS__, 'author_scan' ), 1 );
		remove_action( 'wp_head', 'wp_generator' );
	}

	public static function headers() {
		if ( is_admin() || headers_sent() ) {
			return;
		}
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Referrer-Policy: strict-origin-when-cross-origin' );
		header( 'X-Frame-Options: SAMEORIGIN' );
		header( 'Permissions-Policy: camera=(self), microphone=(self), geolocation=(self)' );
	}

	/** Visitors who are not logged in cannot list members through the REST API (names and login names). */
	public static function rest( $eps ) {
		if ( ! is_user_logged_in() ) {
			foreach ( array_keys( $eps ) as $r ) {
				if ( 0 === strpos( $r, '/wp/v2/users' ) ) {
					unset( $eps[ $r ] );
				}
			}
		}
		return $eps;
	}

	/** Same message whether the username or the password was wrong, so nobody can test which usernames exist. Other messages (two-step login, reset) are left alone. */
	public static function login_error( $e ) {
		global $errors;
		if ( $errors instanceof WP_Error && array_intersect( array( 'invalid_username', 'invalid_email', 'incorrect_password' ), $errors->get_error_codes() ) ) {
			return 'Wrong email, username or password.';
		}
		return $e;
	}

	/** /?author=1 would reveal login names; send visitors home instead. */
	public static function author_scan() {
		if ( ! is_user_logged_in() && isset( $_GET['author'] ) && is_numeric( $_GET['author'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			wp_safe_redirect( home_url( '/' ), 301 );
			exit;
		}
	}
}
MRSH_Mem_Harden::init();
