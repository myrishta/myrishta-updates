<?php
/**
 * Search performance (3.101.282).
 * A live page in the admin that shows how myrishta.pk does in Google Search: clicks, impressions, click-through rate and average
 * position, daily charts, the top searches and pages, and searches that are close to page one. The data comes from Google Search
 * Console through Site Kit (already connected), so no key is needed. A short summary also shows on the main WordPress dashboard.
 * Data is kept for 3 hours; the Refresh button fetches it again.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Searchdash {

	const ROUTE = '/google-site-kit/v1/modules/search-console/data/searchanalytics';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 32 );
		add_action( 'wp_dashboard_setup', array( __CLASS__, 'widget_add' ) );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Search performance', 'Search performance', 'manage_options', 'mrsh-search', array( __CLASS__, 'page' ) );
	}

	/* ---------- data ---------- */

	private static function range( $days ) {
		$end   = gmdate( 'Y-m-d', time() - 2 * DAY_IN_SECONDS ); // Google's numbers are about two days behind.
		$start = gmdate( 'Y-m-d', time() - ( 2 + $days - 1 ) * DAY_IN_SECONDS );
		return array( $start, $end );
	}

	/** @return array|WP_Error rows: { keys:[..], clicks, impressions, ctr, position } */
	private static function fetch( $dims, $days, $limit ) {
		list( $s, $e ) = self::range( $days );
		$k = 'mrsh_sd_' . md5( $dims . '|' . $s . '|' . $e . '|' . $limit );
		$c = get_transient( $k );
		if ( is_array( $c ) ) {
			return $c;
		}
		if ( ! class_exists( 'WP_REST_Request' ) || ! function_exists( 'rest_do_request' ) ) {
			return new WP_Error( 'x', 'REST is not available.' );
		}
		$r = new WP_REST_Request( 'GET', self::ROUTE );
		$r->set_query_params( array( 'startDate' => $s, 'endDate' => $e, 'dimensions' => $dims, 'limit' => $limit ) );
		$res = rest_do_request( $r );
		if ( $res->is_error() ) {
			$er = $res->as_error();
			return new WP_Error( 'x', $er ? $er->get_error_message() : 'Site Kit did not answer.' );
		}
		$d = $res->get_data();
		$d = is_array( $d ) ? array_values( $d ) : array();
		set_transient( $k, $d, 3 * HOUR_IN_SECONDS );
		return $d;
	}

	private static function totals( $rows ) {
		$c = 0;
		$i = 0;
		$p = 0.0;
		foreach ( $rows as $r ) {
			$c += (int) $r['clicks'];
			$i += (int) $r['impressions'];
			$p += (float) $r['position'] * (int) $r['impressions'];
		}
		return array( 'clicks' => $c, 'impr' => $i, 'ctr' => $i ? $c / $i * 100 : 0, 'pos' => $i ? $p / $i : 0 );
	}

	/* ---------- charts (plain SVG, no library) ---------- */

	private static function chart( $rows, $key, $color, $bars ) {
		$n = count( $rows );
		if ( $n < 2 ) {
			return '<p class="mx-sub">Not enough days yet.</p>';
		}
		$w   = 640;
		$h   = 190;
		$l   = 34;
		$b   = 24;
		$max = 1;
		foreach ( $rows as $r ) {
			$max = max( $max, (int) $r[ $key ] );
		}
		$max   = $max < 5 ? 5 : (int) ceil( $max / 5 ) * 5;
		$pw    = $w - $l - 8;
		$ph    = $h - $b - 10;
		$out   = '<svg viewBox="0 0 ' . $w . ' ' . $h . '" width="100%" role="img" aria-label="' . esc_attr( $key ) . ' per day" style="display:block;max-width:100%">';
		for ( $g = 0; $g <= 2; $g++ ) {
			$y    = 10 + $ph - ( $ph * $g / 2 );
			$out .= '<line x1="' . $l . '" x2="' . ( $w - 8 ) . '" y1="' . $y . '" y2="' . $y . '" stroke="#e5e7eb"/><text x="' . ( $l - 6 ) . '" y="' . ( $y + 4 ) . '" font-size="11" text-anchor="end" fill="#6b7280">' . (int) round( $max * $g / 2 ) . '</text>';
		}
		$pts = array();
		foreach ( $rows as $ix => $r ) {
			$x = $l + ( $n > 1 ? $pw * $ix / ( $n - 1 ) : 0 );
			$y = 10 + $ph - ( $ph * (int) $r[ $key ] / $max );
			if ( $bars ) {
				$bw   = max( 2, $pw / $n - 2 );
				$out .= '<rect x="' . round( $x - $bw / 2, 1 ) . '" y="' . round( $y, 1 ) . '" width="' . round( $bw, 1 ) . '" height="' . round( 10 + $ph - $y, 1 ) . '" fill="' . $color . '" rx="1"><title>' . esc_attr( $r['keys'][0] . ': ' . $r[ $key ] ) . '</title></rect>';
			} else {
				$pts[] = round( $x, 1 ) . ',' . round( $y, 1 );
			}
		}
		if ( ! $bars ) {
			$out .= '<polyline fill="none" stroke="' . $color . '" stroke-width="2.2" stroke-linejoin="round" points="' . implode( ' ', $pts ) . '"/>';
		}
		$first = esc_html( gmdate( 'j M', strtotime( $rows[0]['keys'][0] ) ) );
		$last  = esc_html( gmdate( 'j M', strtotime( $rows[ $n - 1 ]['keys'][0] ) ) );
		$out  .= '<text x="' . $l . '" y="' . ( $h - 6 ) . '" font-size="11" fill="#6b7280">' . $first . '</text><text x="' . ( $w - 8 ) . '" y="' . ( $h - 6 ) . '" font-size="11" text-anchor="end" fill="#6b7280">' . $last . '</text></svg>';
		return $out;
	}

	/* ---------- page ---------- */

	private static function table( $rows, $first, $limit ) {
		$o = '<div style="overflow-x:auto"><table class="widefat striped" style="border:0;box-shadow:none"><thead><tr><th>' . esc_html( $first ) . '</th><th style="text-align:right">Clicks</th><th style="text-align:right">Impressions</th><th style="text-align:right">CTR</th><th style="text-align:right">Position</th></tr></thead><tbody>';
		foreach ( array_slice( $rows, 0, $limit ) as $r ) {
			$k = (string) $r['keys'][0];
			$o .= '<tr data-attn="0"><td style="word-break:break-word">' . esc_html( 0 === strpos( $k, 'http' ) ? preg_replace( '#^https?://[^/]+#', '', $k ) : $k ) . '</td><td style="text-align:right">' . (int) $r['clicks'] . '</td><td style="text-align:right">' . (int) $r['impressions'] . '</td><td style="text-align:right">' . esc_html( number_format( (float) $r['ctr'] * 100, 1 ) ) . '%</td><td style="text-align:right">' . esc_html( number_format( (float) $r['position'], 1 ) ) . '</td></tr>';
		}
		return $o . '</tbody></table></div>';
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$days = isset( $_GET['days'] ) && 90 === (int) $_GET['days'] ? 90 : ( isset( $_GET['days'] ) && 7 === (int) $_GET['days'] ? 7 : 28 ); // phpcs:ignore
		if ( isset( $_GET['mrsh_refresh'] ) && check_admin_referer( 'mrsh_sd' ) ) { // phpcs:ignore
			global $wpdb;
			$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_mrsh\_sd\_%' OR option_name LIKE '\_transient\_timeout\_mrsh\_sd\_%'" ); // phpcs:ignore
		}
		MRSH_Boost::ui_open( 'Search performance', 'How myrishta.pk does in Google Search. Live numbers from Google Search Console through Site Kit; Google reports about two days late.', 'g-blue', 'M3 3h2v18H3zm4 10h2v8H7zm4-6h2v14h-2zm4 3h2v11h-2zm4-6h2v17h-2z' );
		$daily = self::fetch( 'date', $days, 120 );
		if ( is_wp_error( $daily ) ) {
			echo '<div class="mx-card"><div class="mx-h"><h2>Google data is not available</h2></div><p class="mx-sub">' . esc_html( $daily->get_error_message() ) . ' Open Site Kit, check that Search Console is connected, then press Refresh.</p></div></div>';
			return;
		}
		usort( $daily, function ( $a, $b ) {
			return strcmp( $a['keys'][0], $b['keys'][0] );
		} );
		$t     = self::totals( $daily );
		$q     = self::fetch( 'query', $days, 100 );
		$p     = self::fetch( 'page', $days, 50 );
		$q     = is_wp_error( $q ) ? array() : $q;
		$p     = is_wp_error( $p ) ? array() : $p;
		$base  = admin_url( 'admin.php?page=mrsh-search' );
		echo '<div class="mx-card"><div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center">';
		foreach ( array( 7, 28, 90 ) as $d ) {
			echo '<a class="mx-btn s' . ( $d === $days ? ' p' : '' ) . '" href="' . esc_url( add_query_arg( 'days', $d, $base ) ) . '">Last ' . (int) $d . ' days</a>';
		}
		echo '<a class="mx-btn s" href="' . esc_url( wp_nonce_url( add_query_arg( array( 'days' => $days, 'mrsh_refresh' => 1 ), $base ), 'mrsh_sd' ) ) . '">Refresh</a></div></div>';
		echo '<div class="mx-grid" style="margin:0 0 18px">'
			. MRSH_Boost::ui_stat( number_format_i18n( $t['clicks'] ), 'Clicks from Google', '#0f7a55' ) // phpcs:ignore
			. MRSH_Boost::ui_stat( number_format_i18n( $t['impr'] ), 'Impressions (times shown)', '#2563eb' ) // phpcs:ignore
			. MRSH_Boost::ui_stat( number_format( $t['ctr'], 1 ) . '%', 'Click-through rate', '#7c3aed' ) // phpcs:ignore
			. MRSH_Boost::ui_stat( number_format( $t['pos'], 1 ), 'Average position (lower is better)', '#e11d74' ) // phpcs:ignore
			. '</div>';
		echo '<div class="mx-grid" style="grid-template-columns:repeat(auto-fit,minmax(320px,1fr));margin:0 0 18px"><div class="mx-card" style="margin:0"><div class="mx-h"><h2>Impressions per day</h2></div><p class="mx-sub">How often Google showed the site in results.</p>' . self::chart( $daily, 'impressions', '#2563eb', false ) . '</div>'; // phpcs:ignore
		echo '<div class="mx-card" style="margin:0"><div class="mx-h"><h2>Clicks per day</h2></div><p class="mx-sub">Visits that came from Google Search.</p>' . self::chart( $daily, 'clicks', '#f97316', true ) . '</div></div>'; // phpcs:ignore
		// New members per day (from the site's own user list, so it is live, not two days late).
		global $wpdb;
		$from = gmdate( 'Y-m-d', strtotime( '-' . ( $days - 1 ) . ' days', current_time( 'timestamp' ) ) ); // phpcs:ignore
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT DATE(user_registered) d, COUNT(*) n FROM {$wpdb->users} WHERE user_registered >= %s GROUP BY d", $from . ' 00:00:00' ), OBJECT_K ); // phpcs:ignore
		$mem  = array();
		$sum  = 0;
		for ( $i = 0; $i < $days; $i++ ) {
			$d     = gmdate( 'Y-m-d', strtotime( $from . ' +' . $i . ' days' ) );
			$c     = isset( $rows[ $d ] ) ? (int) $rows[ $d ]->n : 0;
			$sum  += $c;
			$mem[] = array( 'keys' => array( $d ), 'members' => $c );
		}
		echo '<div class="mx-card"><div class="mx-h"><h2>New members per day</h2></div><p class="mx-sub"><b>' . (int) $sum . '</b> new accounts in the last ' . (int) $days . ' days (about ' . esc_html( number_format( $sum / max( 1, $days ), 1 ) ) . ' a day). Counts every new account, including any test accounts. Live from the site, not delayed like Google data.</p><div style="max-width:760px">' . self::chart( $mem, 'members', '#0f7a55', true ) . '</div></div>'; // phpcs:ignore
		// Searches close to page one: shown 3+ times, position 8 to 20.
		$near = array_filter( $q, function ( $r ) {
			return (int) $r['impressions'] >= 3 && (float) $r['position'] >= 8 && (float) $r['position'] <= 20;
		} );
		usort( $near, function ( $a, $b ) {
			return (int) $b['impressions'] - (int) $a['impressions'];
		} );
		if ( $near ) {
			echo '<div class="mx-card"><div class="mx-h"><h2>Close to page one</h2></div><p class="mx-sub">People searched these words and the site appeared on page two (positions 8 to 20). A better guide or title for each can move it to page one.</p>' . self::table( $near, 'Search words', 10 ) . '</div>'; // phpcs:ignore
		}
		echo '<div class="mx-grid" style="grid-template-columns:repeat(auto-fit,minmax(340px,1fr))"><div class="mx-card" style="margin:0"><div class="mx-h"><h2>Top searches</h2></div><p class="mx-sub">What people typed into Google.</p>' . ( $q ? self::table( $q, 'Search words', 15 ) : '<p>No searches yet.</p>' ) . '</div>'; // phpcs:ignore
		echo '<div class="mx-card" style="margin:0"><div class="mx-h"><h2>Top pages</h2></div><p class="mx-sub">Pages Google showed most.</p>' . ( $p ? self::table( $p, 'Page', 15 ) : '<p>No pages yet.</p>' ) . '</div></div>'; // phpcs:ignore
		echo '<p class="mx-sub" style="margin-top:14px">Range: ' . esc_html( self::range( $days )[0] ) . ' to ' . esc_html( self::range( $days )[1] ) . '. Source: Google Search Console via Site Kit.</p></div>';
	}

	/* ---------- WordPress dashboard widget ---------- */

	public static function widget_add() {
		if ( current_user_can( 'manage_options' ) ) {
			wp_add_dashboard_widget( 'mrsh_search_widget', 'Google Search (last 28 days)', array( __CLASS__, 'widget' ) );
		}
	}

	public static function widget() {
		$d = self::fetch( 'date', 28, 120 );
		if ( is_wp_error( $d ) ) {
			echo '<p>Google data is not available right now.</p>';
		} else {
			$t = self::totals( $d );
			echo '<div style="display:flex;gap:18px;flex-wrap:wrap"><div><b style="font-size:24px">' . esc_html( number_format_i18n( $t['clicks'] ) ) . '</b><br><span>clicks</span></div><div><b style="font-size:24px">' . esc_html( number_format_i18n( $t['impr'] ) ) . '</b><br><span>impressions</span></div><div><b style="font-size:24px">' . esc_html( number_format( $t['pos'], 1 ) ) . '</b><br><span>avg. position</span></div></div>';
		}
		echo '<p style="margin-top:12px"><a class="button button-primary" href="' . esc_url( admin_url( 'admin.php?page=mrsh-search' ) ) . '">Open Search performance</a></p>';
	}
}
MRSH_Searchdash::init();
