<?php
/**
 * Pro skin (3.101.107): one modern look for every plugin admin screen, including the older ones.
 *  - Dark sidebar with a gradient active item, soft cards, pill tabs, modern tables, buttons and fields.
 *  - A small script groups older pages (plain headings and lines) into cards. Pages already built in the new
 *    style (.mx) are left alone. If anything looks wrong, add ?mrsh_noskin=1 to the address to see the page without it.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_ProStyle {

	public static function init() {
		add_action( 'admin_head', array( __CLASS__, 'css' ), 99 );
		add_action( 'admin_footer', array( __CLASS__, 'js' ), 99 );
	}

	private static function on() {
		return is_admin() && empty( $_GET['mrsh_noskin'] ) && class_exists( 'MRSH_Tabs' ) && ( ! empty( $_GET['page'] ) ? 0 === strpos( sanitize_key( wp_unslash( $_GET['page'] ) ), 'mrsh-' ) || 'myrishta-seo' === $_GET['page'] || 'myrishta-ads' === $_GET['page'] : false ); // phpcs:ignore
	}

	public static function css() {
		if ( ! self::on() ) {
			return;
		}
		echo '<style id="mrsh-pro">' . self::skin() . '</style>'; // phpcs:ignore
	}

	public static function skin() {
		return '
body.mrt-ui{--ink:#101828;--mut:#667085;--line:#eaecf5;--bg:#f4f5fb;--card:#fff;--r:20px;background:var(--bg);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Inter,Roboto,sans-serif;-webkit-font-smoothing:antialiased}
body.mrt-ui #adminmenuback,body.mrt-ui #adminmenuwrap,body.mrt-ui #adminmenu{background:#0f1222}
body.mrt-ui #adminmenu a{color:#b6bbd3}
body.mrt-ui #adminmenu li.menu-top:hover>a,body.mrt-ui #adminmenu li.opensub>a.menu-top{background:rgba(255,255,255,.07);color:#fff}
body.mrt-ui #adminmenu li.menu-top>a{border-radius:12px;margin:2px 8px;padding:0}
body.mrt-ui #adminmenu li.current>a.menu-top,body.mrt-ui #adminmenu li.wp-has-current-submenu>a.wp-has-current-submenu{background:linear-gradient(135deg,var(--g,#e11d74),var(--g2,#7c3aed))!important;color:#fff;box-shadow:0 8px 20px rgba(0,0,0,.35)}
body.mrt-ui #adminmenu .wp-submenu{background:#171a30;border-radius:12px;padding:6px 0}
body.mrt-ui #adminmenu .wp-submenu a{color:#b6bbd3}body.mrt-ui #adminmenu .wp-submenu a:hover,body.mrt-ui #adminmenu .wp-submenu li.current a{color:#fff}
body.mrt-ui #adminmenu div.wp-menu-image:before,body.mrt-ui #adminmenu .wp-menu-image img{color:#b6bbd3}
body.mrt-ui #adminmenu li.current div.wp-menu-image:before,body.mrt-ui #adminmenu li:hover div.wp-menu-image:before{color:#fff}
body.mrt-ui #adminmenu .wp-has-current-submenu .wp-submenu{background:#171a30}
body.mrt-ui #wpadminbar{background:#0f1222}
body.mrt-ui #wpfooter{display:none}
body.mrt-ui .wrap{max-width:1240px}
body.mrt-ui .wrap>h1:first-child{border-radius:24px;box-shadow:0 18px 40px -12px rgba(17,24,39,.35)}
/* sections */
body.mrt-ui .mx-sec{background:var(--card);border-radius:var(--r);padding:22px 24px;margin:0 0 18px;box-shadow:0 1px 2px rgba(16,24,40,.05),0 8px 24px -10px rgba(16,24,40,.10),0 0 0 1px rgba(16,24,40,.04);position:relative;overflow:hidden}
body.mrt-ui .mx-sec>h2:first-child,body.mrt-ui .mx-sec>h3:first-child{margin:0 0 14px;padding:0;border:0;display:flex;align-items:center;gap:12px;font-size:17px;color:var(--ink);letter-spacing:-.01em}
body.mrt-ui .mx-sec>h2:first-child:before{content:"";flex:none;width:10px;height:26px;border-radius:99px;background:linear-gradient(180deg,var(--g,#e11d74),var(--g2,#7c3aed))}
body.mrt-ui .mx-sec>p{margin:8px 0;color:#475467;line-height:1.6}
body.mrt-ui .mx-sec>p.mx-rowp{display:flex;flex-wrap:wrap;gap:8px 10px;align-items:center;margin:0;padding:13px 0;border-top:1px solid var(--line)}
body.mrt-ui .mx-sec>h2:first-child+p.mx-rowp{border-top:0}
body.mrt-ui .mx-sec>p.mx-rowp b{color:var(--ink);margin-right:4px}
body.mrt-ui .mx-sec>p.mx-rowp .button{margin:0}
body.mrt-ui .mx-sec>.widefat,body.mrt-ui .mx-sec>.wp-list-table,body.mrt-ui .mx-sec>.form-table{margin-top:0}
body.mrt-ui .mx-sec .form-table{box-shadow:none;border-top:0;border-radius:0;background:transparent}
body.mrt-ui .mx-sec .form-table th{width:230px;color:var(--ink);font-weight:600}
body.mrt-ui .mx-sec .form-table th,body.mrt-ui .mx-sec .form-table td{border-bottom:1px solid var(--line);padding:16px 8px}
body.mrt-ui .mx-sec>.submit,body.mrt-ui .mx-sec>p.submit{margin:16px 0 0;padding:0}
/* stat tiles used by older pages */
body.mrt-ui .mrx{gap:14px}
body.mrt-ui .mrx>div{background:#fff;border:0;border-radius:18px;padding:18px 20px;box-shadow:0 1px 2px rgba(16,24,40,.05),0 8px 24px -12px rgba(16,24,40,.18),0 0 0 1px rgba(16,24,40,.04);position:relative;overflow:hidden}
body.mrt-ui .mrx>div:before{content:"";position:absolute;left:0;top:0;bottom:0;width:4px;background:linear-gradient(180deg,var(--g,#e11d74),var(--g2,#7c3aed))}
body.mrt-ui .mrx>div b{display:block;font-size:30px;line-height:1.1;letter-spacing:-.03em;color:var(--ink)}
body.mrt-ui .mrx>div span{color:var(--mut);font-size:13px}
body.mrt-ui p.mrx-q{display:flex;flex-wrap:wrap;gap:10px;margin:0 0 18px}
body.mrt-ui p.mrx-q .button{margin:0}
/* controls */
body.mrt-ui .button,body.mrt-ui .button-secondary{box-sizing:border-box;border-radius:12px;border:1px solid #d6d9e8;background:#fff;color:#344054;box-shadow:0 1px 2px rgba(16,24,40,.05);font-weight:600}
body.mrt-ui .button:hover,body.mrt-ui .button:focus{background:#faf5ff;border-color:#c4a8f7;color:#6d28d9}
body.mrt-ui .button-primary{border:0;background:linear-gradient(135deg,var(--g,#e11d74),var(--g2,#7c3aed));color:#fff;box-shadow:0 10px 22px -8px rgba(124,58,237,.55)}
body.mrt-ui .button-primary:hover,body.mrt-ui .button-primary:focus{background:linear-gradient(135deg,var(--g,#e11d74),var(--g2,#7c3aed));color:#fff;filter:brightness(.94)}
body.mrt-ui .button-link-delete,body.mrt-ui a.submitdelete{color:#b42318}
body.mrt-ui input[type=text],body.mrt-ui input[type=number],body.mrt-ui input[type=email],body.mrt-ui input[type=url],body.mrt-ui input[type=password],body.mrt-ui input[type=search],body.mrt-ui input[type=date],body.mrt-ui select,body.mrt-ui textarea{border-radius:12px;border:1px solid #d6d9e8;background:#fcfcfe;color:var(--ink)}
body.mrt-ui input[type=checkbox],body.mrt-ui input[type=radio]{width:18px;height:18px;border-radius:6px;border:1.5px solid #c3c8dc}
body.mrt-ui input[type=radio]{border-radius:50%}
body.mrt-ui input[type=checkbox]:checked{background:var(--g,#7c3aed);border-color:var(--g,#7c3aed)}
body.mrt-ui input[type=checkbox]:checked:before{filter:brightness(0) invert(1);margin:-2px 0 0 -1px}
body.mrt-ui input[type=radio]:checked{background:#fff;border-color:var(--g,#7c3aed)}
body.mrt-ui input[type=radio]:checked:before{background:var(--g,#7c3aed);width:10px;height:10px;margin:3px}
body.mrt-ui .tablenav{margin:10px 0}
body.mrt-ui .tablenav .tablenav-pages .button,body.mrt-ui .tablenav-pages .current-page{border-radius:10px}
body.mrt-ui .subsubsub{margin:8px 0 14px;display:flex;flex-wrap:wrap;gap:6px;float:none}
body.mrt-ui .subsubsub li{margin:0;color:transparent;font-size:0}
body.mrt-ui .subsubsub li a{display:inline-block;font-size:13px;padding:6px 14px;border-radius:99px;background:#fff;color:#475467;box-shadow:0 0 0 1px var(--line);text-decoration:none;font-weight:500}
body.mrt-ui .subsubsub li a.current{background:#101828;color:#fff;font-weight:600}
body.mrt-ui .subsubsub li a .count{opacity:.7}
body.mrt-ui .notice,body.mrt-ui div.updated,body.mrt-ui div.error{border-radius:14px;background:#fff;box-shadow:0 1px 2px rgba(16,24,40,.05),0 0 0 1px rgba(16,24,40,.05)}
body.mrt-ui .notice p{margin:8px 0}
body.mrt-ui ::-webkit-scrollbar{width:10px;height:10px}body.mrt-ui ::-webkit-scrollbar-thumb{background:#cfd3e6;border-radius:99px}
body.mrt-ui a{color:#6d28d9}body.mrt-ui .button,body.mrt-ui .button-primary,body.mrt-ui .mrt-tabs a,body.mrt-ui .mx-btn{color:inherit}
body.mrt-ui .button-primary{color:#fff!important}
body.mrt-ui .mrt-tabs .r1 a.on{color:#fff}
@media(max-width:782px){body.mrt-ui .mx-sec{padding:18px 16px;border-radius:18px}body.mrt-ui .mx-sec .form-table th{width:auto}}
';
	}

	public static function js() {
		if ( ! self::on() ) {
			return;
		}
		echo '<script id="mrsh-pro-js">' . self::script() . '</script>'; // phpcs:ignore
	}

	public static function script() {
		return '(function(){try{
var w=document.querySelector("#wpbody-content .wrap");if(!w||w.classList.contains("mx")||w.querySelector(".mx-hero"))return;
var skip=/^(SCRIPT|STYLE|HR|H1)$/;
function keep(n){return n.nodeType===1&&(skip.test(n.tagName)||n.classList.contains("notice")||n.classList.contains("mrt-tabs")||n.classList.contains("mrx-q")||n.classList.contains("mrx")||n.id==="message"||n.classList.contains("updated")||n.classList.contains("error")||n.classList.contains("subsubsub")||n.classList.contains("tablenav")||n.classList.contains("search-box"))}
function group(c){
 var kids=Array.prototype.slice.call(c.childNodes),cur=null,made=0;
 kids.forEach(function(n){
  if(n.nodeType===1&&/^H[23]$/.test(n.tagName)&&n.tagName==="H2"){cur=document.createElement("section");cur.className="mx-sec";c.insertBefore(cur,n);cur.appendChild(n);made++;return}
  if(!cur)return;
  if(n.nodeType===3&&!n.textContent.trim()){cur.appendChild(n);return}
  if(n.nodeType===1&&keep(n)){cur=null;return}
  cur.appendChild(n)});
 return made}
var m=group(w);
Array.prototype.slice.call(w.children).forEach(function(f){if(f.tagName==="FORM"&&f.querySelector(":scope>h2"))group(f)});
if(!m){var tb=w.querySelectorAll(":scope>.form-table,:scope>.widefat,:scope>form>.form-table,:scope>form>.widefat");}
Array.prototype.forEach.call(w.querySelectorAll(".mx-sec>p"),function(p){if(p.querySelector("b,strong")&&p.querySelector(".button,a.button")){p.classList.add("mx-rowp")}});
}catch(e){}})();';
	}
}
MRSH_ProStyle::init();
