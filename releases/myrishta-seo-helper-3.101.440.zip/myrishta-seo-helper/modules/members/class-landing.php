<?php
/**
 * Gulf growth pages: helpful, honest guide pages for Pakistani families in Qatar, Bahrain, Oman, Kuwait and for the
 * main Gulf cities. The pages are written from a careful template (no invented numbers or promises, official
 * offices named only as "check with"), published as normal pages, listed on the home page and in the sitemap,
 * and announced to search engines. The AI Autopilot adds two per day so Google sees steady, natural growth.
 * Manual buttons: create one page, or all missing pages, on the "Gulf growth pages" screen.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Landing {

	const LAST = 'mrsh_land_last';

	/** slug => array( type, English name, Urdu name, country, parent slug, embassy text ) */
	public static function pages() {
		$m = array(
			'qa' => 'the Embassy of Pakistan in Doha',
			'bh' => 'the Embassy of Pakistan in Manama',
			'om' => 'the Embassy of Pakistan in Muscat',
			'kw' => 'the Embassy of Pakistan in Kuwait City',
			'ae' => 'the Embassy of Pakistan in Abu Dhabi or the Consulate General of Pakistan in Dubai',
			'sa' => 'the Embassy of Pakistan in Riyadh or the Consulate General of Pakistan in Jeddah',
		);
		$c = array(
			'rishta-qatar-pakistani-families'   => array( 'country', 'Qatar', 'قطر', 'Qatar', '', $m['qa'], array( 'Doha', 'Al Wakrah', 'Al Khor' ) ),
			'rishta-bahrain-pakistani-families' => array( 'country', 'Bahrain', 'بحرین', 'Bahrain', '', $m['bh'], array( 'Manama', 'Riffa', 'Muharraq' ) ),
			'rishta-oman-pakistani-families'    => array( 'country', 'Oman', 'عمان', 'Oman', '', $m['om'], array( 'Muscat', 'Salalah', 'Sohar' ) ),
			'rishta-kuwait-pakistani-families'  => array( 'country', 'Kuwait', 'کویت', 'Kuwait', '', $m['kw'], array( 'Kuwait City', 'Hawalli', 'Salmiya' ) ),
		);
		$city = array(
			'rishta-dubai'       => array( 'Dubai', 'دبئی', 'the UAE', 'rishta-uae-pakistani-families', $m['ae'] ),
			'rishta-abu-dhabi'   => array( 'Abu Dhabi', 'ابوظہبی', 'the UAE', 'rishta-uae-pakistani-families', $m['ae'] ),
			'rishta-sharjah'     => array( 'Sharjah', 'شارجہ', 'the UAE', 'rishta-uae-pakistani-families', $m['ae'] ),
			'rishta-riyadh'      => array( 'Riyadh', 'ریاض', 'Saudi Arabia', 'rishta-saudi-arabia-pakistani-families', $m['sa'] ),
			'rishta-jeddah'      => array( 'Jeddah', 'جدہ', 'Saudi Arabia', 'rishta-saudi-arabia-pakistani-families', $m['sa'] ),
			'rishta-dammam'      => array( 'Dammam', 'دمام', 'Saudi Arabia', 'rishta-saudi-arabia-pakistani-families', $m['sa'] ),
			'rishta-doha'        => array( 'Doha', 'دوحہ', 'Qatar', 'rishta-qatar-pakistani-families', $m['qa'] ),
			'rishta-manama'      => array( 'Manama', 'منامہ', 'Bahrain', 'rishta-bahrain-pakistani-families', $m['bh'] ),
			'rishta-muscat'      => array( 'Muscat', 'مسقط', 'Oman', 'rishta-oman-pakistani-families', $m['om'] ),
			'rishta-kuwait-city' => array( 'Kuwait City', 'کویت سٹی', 'Kuwait', 'rishta-kuwait-pakistani-families', $m['kw'] ),
		);
		$out = array();
		foreach ( $c as $slug => $r ) {
			$out[ $slug ] = array( 'country', $r[1], $r[2], $r[3], '', $r[5], $r[6] );
		}
		foreach ( $city as $slug => $r ) {
			$out[ $slug ] = array( 'city', $r[0], $r[1], $r[2], $r[3], $r[4], array() );
		}
		return $out;
	}

	public static function exists( $slug ) {
		$p = get_page_by_path( $slug, OBJECT, 'page' );
		return $p ? (int) $p->ID : 0;
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 45 );
		add_action( 'admin_post_mrsh_land_make', array( __CLASS__, 'act_make' ) );
		add_action( 'init', array( __CLASS__, 'heal_tools' ), 20 );
	}

	/** The Rishta tools page needs [mrmb_tools]. If the boosters file did not register it, load it here so the page never shows the raw tag. */
	public static function heal_tools() {
		if ( shortcode_exists( 'mrmb_tools' ) ) {
			return;
		}
		try {
			if ( ! class_exists( 'MRMB', false ) ) {
				$f = MRSH_DIR . 'modules/members/class-boosters.php';
				if ( is_readable( $f ) ) {
					require_once $f; // phpcs:ignore
				}
			}
			if ( class_exists( 'MRMB', false ) && is_callable( array( 'MRMB', 'tools' ) ) ) {
				add_shortcode( 'mrmb_tools', array( 'MRMB', 'tools' ) );
				if ( class_exists( 'MRSH_Autopilot' ) && ! get_option( 'mrsh_tools_healed' ) ) {
					update_option( 'mrsh_tools_healed', time(), false );
					MRSH_Autopilot::log( 'landing', 'Rishta tools shortcode was not registered; it was loaded again automatically.' );
				}
			}
		} catch ( \Throwable $e ) {
			if ( class_exists( 'MRSH_Safe' ) ) {
				MRSH_Safe::log_ex( $e, 'heal_tools' );
			}
		}
	}

	/* ---------- content ---------- */

	private static function link( $slug, $text ) {
		return '<a href="' . esc_url( home_url( '/' . $slug . '/' ) ) . '">' . esc_html( $text ) . '</a>';
	}

	private static function hub_links( $skip ) {
		$h = array();
		foreach ( self::pages() as $slug => $r ) {
			if ( $slug === $skip || ! self::exists( $slug ) ) {
				continue;
			}
			$h[] = '<li>' . self::link( $slug, 'Rishta in ' . $r[1] ) . '</li>';
		}
		return $h ? '<h2>More rishta guides for Pakistanis in the Gulf</h2><ul>' . implode( '', $h ) . '</ul>' : '';
	}

	private static function safety() {
		return '<h2>Staying safe</h2><ul>'
			. '<li>Never send money to anyone to &#8220;arrange&#8221; or &#8220;confirm&#8221; a rishta. Our service is free.</li>'
			. '<li>Be careful if someone asks for a visa fee, a ticket, a deposit or a gift before you have met their family.</li>'
			. '<li>Do not share bank, card or OTP details, and keep your home address and ID numbers private.</li>'
			. '<li>Meet in a public place or a family home, with family. Do not meet alone with a stranger in a private place.</li>'
			. '<li>Report suspicious profiles with the report button or on our ' . self::link( 'contact', 'contact page' ) . '. Read the ' . self::link( 'rishta-safety-tips', 'rishta safety tips' ) . ' and look for the green tick explained on the ' . self::link( 'verification-badges', 'verification badges' ) . ' page.</li></ul>';
	}

	private static function urdu( $n, $ur, $cu ) {
		return '<h2>اردو خلاصہ</h2><p dir="rtl" lang="ur">اگر آپ ' . $ur . ' میں رہتے ہیں اور اپنے لیے یا اپنے خاندان کے کسی فرد کے لیے رشتہ تلاش کر رہے ہیں تو مائی رشتہ پاکستان بالکل مفت ہے۔ پروفائل بنائیں، رشتے دیکھیں، پہلے خاندان کو شامل کریں، پھر ویڈیو کال پر بات کریں اور ملاقات ہمیشہ خاندان کے ساتھ کسی محفوظ جگہ پر کریں۔ رشتہ کروانے کے نام پر کسی کو پیسے نہ بھیجیں۔ ' . $cu . '</p>';
	}

	private static function faq( $n, $country ) {
		return '<h2>Frequently asked questions</h2>'
			. '<h3>Can I use My Rishta Pakistan from ' . esc_html( $n ) . '?</h3><p>Yes. You can create a profile and browse proposals from anywhere in the world. Registration is free and we never charge for introductions.</p>'
			. '<h3>Should I look for a partner in ' . esc_html( $n ) . ' or in Pakistan?</h3><p>Both are common. Some families prefer someone who already lives in ' . esc_html( $country ) . ' and understands the life there; others look in Pakistan. Decide what matters to you and say it clearly in your profile.</p>'
			. '<h3>Is my phone number visible to everyone?</h3><p>No. Your phone number stays private. Members contact each other through the site first.</p>'
			. '<h3>Do I need to pay to get a good rishta?</h3><p>No. My Rishta Pakistan is a free, non-profit service. Anyone who asks you for money in our name is not connected to us. Please report them.</p>';
	}

	public static function content( $slug ) {
		$all = self::pages();
		if ( ! isset( $all[ $slug ] ) ) {
			return '';
		}
		list( $type, $n, $ur, $country, $parent, $mission, $cities ) = $all[ $slug ];
		$reg = self::link( 'register', 'create a free profile' );
		$ov  = self::link( 'rishta-overseas-pakistanis', 'rishta for overseas Pakistanis' );
		$h   = '';
		if ( 'country' === $type ) {
			$cl = implode( ', ', $cities );
			$h .= '<p>Pakistanis working and living in ' . esc_html( $cl ) . ' and the other cities of ' . esc_html( $n ) . ' can use My Rishta Pakistan free of charge. Many families in ' . esc_html( $n ) . ' look for a partner in Pakistan, and many look within the Pakistani community already living in the Gulf. This page explains how a rishta usually works when one or both people are in ' . esc_html( $n ) . ', and what to think about before you say yes.</p>';
			$h .= '<h2>Who this page is for</h2><p>It is for Pakistani professionals, workers and business owners in ' . esc_html( $n ) . ', for parents in Pakistan who are looking for a son-in-law or daughter-in-law who works there, and for relatives who want to help a family member abroad. You can make a profile for yourself or for a relative, as long as the person knows about it and agrees. Part of our wider guide to ' . $ov . '.</p>';
		} else {
			$h .= '<p>Looking for a rishta from ' . esc_html( $n ) . '? Pakistani families in ' . esc_html( $n ) . ', ' . esc_html( $country ) . ', can use My Rishta Pakistan free of charge. Many look for a partner in Pakistan, and many look within the Pakistani community already living in ' . esc_html( $n ) . ' and nearby. This guide explains a practical way to do it, with family involved and without paying anyone.</p>';
			$h .= '<p>For the full country guide, read ' . self::link( $parent, 'rishta for Pakistanis in ' . $country ) . ' and our page for ' . $ov . '.</p>';
		}
		$h .= '<h2>Why a rishta from ' . esc_html( $n ) . ' needs a little extra planning</h2><p>When both people live in the same city, a family can visit, meet several times and ask neighbours about each other. A rishta from ' . esc_html( $n ) . ' is often different. One family may be in Pakistan and the other in the Gulf, and the person abroad may only have a few weeks of leave each year. It helps to agree early on a few practical points:</p>'
			. '<ul><li><strong>Where will the couple live?</strong> Some couples stay in ' . esc_html( $country ) . ', some settle in Pakistan, some plan to move later. Say this honestly from the first conversation.</li>'
			. '<li><strong>Who will meet whom, and when?</strong> Many families plan the main meetings, the engagement and the nikah around a trip home, so agree likely dates before you start.</li>'
			. '<li><strong>What does the work situation look like?</strong> Residence in the Gulf is usually linked to a job or a sponsor. Ask politely about the contract, how often salary is paid and how long the person expects to stay.</li>'
			. '<li><strong>What happens after marriage?</strong> If one partner will join the other in ' . esc_html( $country ) . ', check the family or spouse residence rules on the official government websites. Rules change, so do not rely on a friend&#8217;s memory of the process.</li></ul>';
		$h .= '<aside class="mrads-card" aria-label="My Rishta app"><strong>Get the free My Rishta app</strong><span>Read guides and browse rishta on your phone. Free, private, no sign-up needed to install.</span><a class="mrads-btn" data-mrads-t="card" href="' . esc_url( home_url( '/app/' ) ) . '">Open the app</a></aside>';
		$h .= '<h2>A simple step-by-step approach</h2><ol>'
			. '<li><strong>Create a clear profile.</strong> ' . ucfirst( $reg ) . ' with your city in ' . esc_html( $country ) . ', your city or district in Pakistan, your education, your work and the kind of partner you want. Do not post your home address or document numbers.</li>'
			. '<li><strong>Browse and shortlist a few.</strong> Read each profile completely and check whether the person&#8217;s plans about living abroad or at home match yours.</li>'
			. '<li><strong>Bring the family in early.</strong> Share shortlisted profiles with parents or elders, even if you are abroad. A rishta with the family&#8217;s approval from the start is easier to complete.</li>'
			. '<li><strong>Talk first, then meet.</strong> Use calls and video calls so both families can speak. Talk about work, plans, expectations and family responsibilities.</li>'
			. '<li><strong>Check the details through trusted people.</strong> Ask relatives or friends in Pakistan and in ' . esc_html( $country ) . ' to quietly confirm the person&#8217;s job, family and character.</li>'
			. '<li><strong>Meet in person with family.</strong> Choose a public place or a family home.</li>'
			. '<li><strong>Decide together, without pressure.</strong> It is fine to say no politely. Do not agree to a nikah or a wedding date because of time pressure.</li></ol>';
		$h .= '<h2>Documents and paperwork: what to keep in mind</h2><p>Marriage documents made in Pakistan sometimes need to be verified or attested before they can be used abroad, and the steps depend on the country, the document and the purpose. Ask ' . esc_html( $mission ) . ', the authorities in ' . esc_html( $country ) . ' or a qualified lawyer. Keep copies of every document safely and never hand originals or identity papers to someone you have not met through family.</p>';
		$h .= self::safety();
		$h .= self::faq( $n, $country );
		$h .= '<h2>Start free today</h2><p>' . ucfirst( $reg ) . ' for yourself or a relative, or ' . self::link( 'latest-profiles', 'browse the latest profiles' ) . '. Looking for guidance first? Read our ' . self::link( 'how-it-works', 'how it works' ) . ' page.</p>';
		$h .= self::hub_links( $slug );
		$cu = 'سفارت خانے یا قونصلیٹ سے دستاویزات کی تصدیق کے بارے میں پوچھ لیں۔';
		$h .= self::urdu( $n, $ur, $cu );
		return $h;
	}

	public static function meta( $slug ) {
		$all = self::pages();
		list( $type, $n, , $country ) = $all[ $slug ];
		if ( 'country' === $type ) {
			return array(
				'title' => 'Rishta in ' . $n . ': Free Rishta for Pakistanis in ' . $n,
				'desc'  => 'Free rishta guide for Pakistani families in ' . $n . ': how to find a match, meet safely, plan the nikah and avoid scams. Create a free profile.',
				'focus' => 'rishta in ' . strtolower( $n ),
				'h1'    => 'Rishta in ' . $n . ': A Free Guide for Pakistani Families',
			);
		}
		return array(
			'title' => 'Rishta in ' . $n . ': Free Rishta for Pakistanis in ' . $n,
			'desc'  => 'Pakistani rishta in ' . $n . ' made simple and free: create a profile, involve family, meet safely and avoid fake offers. Free for every family.',
			'focus' => 'rishta in ' . strtolower( $n ),
			'h1'    => 'Rishta in ' . $n . ': Free Pakistani Rishta Guide',
		);
	}

	/* ---------- making pages ---------- */

	public static function make( $slug ) {
		$all = self::pages();
		if ( ! isset( $all[ $slug ] ) || self::exists( $slug ) ) {
			return 0;
		}
		$m  = self::meta( $slug );
		$id = wp_insert_post( array(
			'post_type'    => 'page',
			'post_status'  => 'publish',
			'post_name'    => $slug,
			'post_title'   => $m['h1'],
			'post_content' => self::content( $slug ),
		), true );
		if ( is_wp_error( $id ) || ! $id ) {
			return 0;
		}
		update_post_meta( $id, '_mrsh_title', $m['title'] );
		update_post_meta( $id, '_mrsh_desc', $m['desc'] );
		update_post_meta( $id, '_mrsh_focus', $m['focus'] );
		update_post_meta( $id, '_mrsh_landing', time() );
		if ( class_exists( 'MRSH_Autopilot' ) ) {
			MRSH_Autopilot::log( 'Growth pages', 'Published the page "' . $m['h1'] . '".' );
		}
		if ( class_exists( 'MRSH_Agent' ) ) {
			try {
				MRSH_Agent::run( false, true );
			} catch ( \Throwable $e ) { // phpcs:ignore Generic.CodeAnalysis.EmptyStatement
			}
		}
		return (int) $id;
	}

	/** The autopilot calls this: two new pages a day, until all exist. */
	public static function drip() {
		if ( class_exists( 'MRSH_Switch' ) && ! MRSH_Switch::on( 'landing' ) ) {
			return 0;
		}
		if ( get_option( self::LAST ) === wp_date( 'Y-m-d' ) ) {
			return 0;
		}
		update_option( self::LAST, wp_date( 'Y-m-d' ), false );
		$n = 0;
		foreach ( array_keys( self::pages() ) as $slug ) {
			if ( $n >= 2 ) {
				break;
			}
			if ( ! self::exists( $slug ) && self::make( $slug ) ) {
				++$n;
			}
		}
		return $n;
	}

	/* ---------- admin ---------- */

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Gulf growth pages', 'Gulf growth pages', 'manage_options', 'mrsh-landing', array( __CLASS__, 'page' ) );
	}

	public static function act_make() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'No.' );
		}
		check_admin_referer( 'mrsh_land' );
		$slug = sanitize_title( wp_unslash( $_POST['slug'] ?? '' ) ); // phpcs:ignore
		$n    = 0;
		if ( 'all' === $slug ) {
			foreach ( array_keys( self::pages() ) as $s ) {
				if ( self::make( $s ) ) {
					++$n;
				}
			}
		} elseif ( self::make( $slug ) ) {
			$n = 1;
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-landing&made=' . $n ) );
		exit;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$all  = self::pages();
		$have = 0;
		foreach ( $all as $s => $r ) {
			if ( self::exists( $s ) ) {
				++$have;
			}
		}
		MRSH_Boost::ui_open( 'Gulf growth pages', 'Free guide pages for Pakistani families in Qatar, Bahrain, Oman, Kuwait and the main Gulf cities. The Autopilot adds two a day.', 'g-gold', 'M12 2 3 7v2h18V7zM5 11h2v8H5zm6 0h2v8h-2zm6 0h2v8h-2zM3 21h18v-2H3z' );
		if ( isset( $_GET['made'] ) ) { // phpcs:ignore
			MRSH_Boost::ui_ok( (int) $_GET['made'] . ' page(s) published and sent to search engines.' ); // phpcs:ignore
		}
		echo '<div class="mx-stats">' . MRSH_Boost::ui_stat( $have, 'Pages live', '#139a86' ) . MRSH_Boost::ui_stat( count( $all ) - $have, 'Still to publish', '#f59e0b' ) . MRSH_Boost::ui_stat( count( $all ), 'Planned', '#7c3aed' ) . '</div>';
		echo '<div class="mx-card"><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'mrsh_land' );
		echo '<input type="hidden" name="action" value="mrsh_land_make"><input type="hidden" name="slug" value="all"><p class="mx-sub">One tap publishes every missing page now. Or leave it: the AI Autopilot publishes two a day.</p><button class="mx-btn">Publish all missing pages now</button></form></div>';
		echo '<div class="mx-card"><div class="mx-tbl"><table class="widefat striped"><thead><tr><th>Page</th><th>Type</th><th>Status</th><th></th></tr></thead><tbody>';
		foreach ( $all as $s => $r ) {
			$id = self::exists( $s );
			echo '<tr><td><b>Rishta in ' . esc_html( $r[1] ) . '</b><br><small>/' . esc_html( $s ) . '/</small></td><td>' . esc_html( 'country' === $r[0] ? 'Country guide' : 'City guide' ) . '</td><td>' . ( $id ? '<span class="mx-pill ok">Live</span>' : '<span class="mx-pill">Not yet</span>' ) . '</td><td>';
			if ( $id ) {
				echo '<a class="mx-btn s" href="' . esc_url( get_permalink( $id ) ) . '" target="_blank" rel="noopener">View</a> <a class="mx-btn s" href="' . esc_url( get_edit_post_link( $id, 'raw' ) ) . '">Edit</a>';
			} else {
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline">';
				wp_nonce_field( 'mrsh_land' );
				echo '<input type="hidden" name="action" value="mrsh_land_make"><input type="hidden" name="slug" value="' . esc_attr( $s ) . '"><button class="mx-btn s">Publish now</button></form>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table></div></div></div>';
	}
}
MRSH_Landing::init();
