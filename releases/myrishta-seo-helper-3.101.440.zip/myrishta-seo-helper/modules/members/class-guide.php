<?php
/**
 * Admin guide (English and Urdu) inside WordPress: Dashboard > Admin guide.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Guide {
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 30 );
	}
	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Admin guide', 'Admin guide', 'edit_posts', 'mrsh-guide', array( __CLASS__, 'page' ) );
	}
	public static function page() {
		echo '<div class="wrap">';
		include __DIR__ . '/guide-view.php';
		echo '</div>';
	}
}
MRSH_Guide::init();
