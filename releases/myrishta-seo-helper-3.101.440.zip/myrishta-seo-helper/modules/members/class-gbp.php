<?php
/**
 * Google Business Profile helper (Growth > Google Business Profile, 3.101.168).
 * - Organization schema on the home page (name, phone, area served, sameAs with the profile link) so Google can match the site to the profile.
 * - Tagged links (utm) for the profile buttons and a cache-safe counter of visits that came from the profile.
 * - Review link, review button for members, ready review-request and review-reply texts (English and Urdu).
 * - Seven ready post ideas that rotate by day, Q and A texts, and a readiness checklist with a score.
 * Nothing is invented: the profile can only be changed by the owner in Google, so every text has a Copy button.
 * Options: mrsh_gbp (settings), mrsh_gbp_hits (visits per day, last 60 days). No tables, no personal data.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Gbp {

	const OPT  = 'mrsh_gbp';
	const HITS = 'mrsh_gbp_hits';

	public static function get() {
		return array_merge( array( 'on' => 1, 'schema' => 1, 'btn' => 1, 'name' => '', 'place_id' => '', 'url' => '', 'review' => '', 'phone' => '', 'email' => '', 'area' => 'Pakistan', 'hours' => '', 'same' => '' ), (array) get_option( self::OPT, array() ) );
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 31 );
		add_action( 'admin_post_mrsh_gbp_save', array( __CLASS__, 'save' ) );
		add_action( 'wp_head', array( __CLASS__, 'schema' ), 6 );
		add_action( 'wp_footer', array( __CLASS__, 'beacon' ), 60 );
		add_action( 'wp_ajax_nopriv_mrsh_gbp_hit', array( __CLASS__, 'hit' ) );
		add_action( 'wp_ajax_mrsh_gbp_hit', array( __CLASS__, 'hit' ) );
		add_action( 'mrt_account_extra', array( __CLASS__, 'account' ), 75 );
		add_action( 'mrt_account_extra', array( __CLASS__, 'banner' ), 2 );
		add_action( 'admin_post_mrsh_rv_go', array( __CLASS__, 'rv_go' ) );
		add_shortcode( 'mrsh_review_button', array( __CLASS__, 'shortcode' ) );
	}

	/* ---------- helpers ---------- */

	public static function review_url() {
		$g = self::get();
		$p = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $g['place_id'] );
		if ( ! $p && preg_match( '#^https://#i', (string) $g['review'] ) ) {
			return esc_url_raw( $g['review'] );
		}
		return $p ? 'https://search.google.com/local/writereview?placeid=' . rawurlencode( $p ) : '';
	}

	public static function tagged( $path, $content = 'button' ) {
		return add_query_arg( array( 'utm_source' => 'google', 'utm_medium' => 'organic', 'utm_campaign' => 'gbp', 'utm_content' => $content ), home_url( $path ) );
	}

	private static function lines( $t ) {
		$o = array();
		foreach ( preg_split( '/\R/', (string) $t ) as $l ) {
			$l = trim( $l );
			if ( '' !== $l && preg_match( '#^https?://#i', $l ) ) {
				$o[] = esc_url_raw( $l );
			}
		}
		return array_values( array_unique( $o ) );
	}

	/* ---------- automatic parts ---------- */

	public static function schema() {
		$g = self::get();
		if ( ! $g['on'] || ! $g['schema'] || is_admin() || ! is_front_page() ) {
			return;
		}
		$d = array(
			'@context'   => 'https://schema.org',
			'@type'      => 'Organization',
			'@id'        => home_url( '/#gbp-org' ),
			'name'       => $g['name'] ? $g['name'] : get_bloginfo( 'name' ),
			'url'        => home_url( '/' ),
			'areaServed' => $g['area'] ? $g['area'] : 'Pakistan',
		);
		$org = class_exists( 'MRSH_Options' ) ? MRSH_Options::org() : array();
		if ( $org ) {
			$d['telephone'] = $g['phone'] ? $g['phone'] : $org['phone'];
			$d['email']     = $g['email'] ? $g['email'] : $org['email'];
			$d['address']   = array( '@type' => 'PostalAddress', 'streetAddress' => $org['street'], 'addressLocality' => $org['city'], 'addressRegion' => $org['region'], 'postalCode' => $org['postal'], 'addressCountry' => 'PK' );
		}
		if ( $g['phone'] || $g['email'] ) {
			$cp = array( '@type' => 'ContactPoint', 'contactType' => 'customer support', 'availableLanguage' => array( 'Urdu', 'English' ) );
			if ( $g['phone'] ) {
				$cp['telephone'] = $g['phone'];
			}
			if ( $g['email'] ) {
				$cp['email'] = $g['email'];
			}
			$d['contactPoint'] = $cp;
		}
		if ( $g['hours'] ) {
			$d['openingHours'] = $g['hours'];
		}
		$same = self::lines( $g['same'] );
		if ( $g['url'] && preg_match( '#^https?://#i', $g['url'] ) ) {
			array_unshift( $same, esc_url_raw( $g['url'] ) );
		}
		if ( $same ) {
			$d['sameAs'] = array_values( array_unique( $same ) );
		}
		echo '<script type="application/ld+json">' . wp_json_encode( $d, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	/** Cache-safe counter: a page cached by LiteSpeed still counts, because the browser calls admin-ajax. */
	public static function beacon() {
		if ( ! self::get()['on'] || is_admin() || is_user_logged_in() ) {
			return;
		}
		echo '<script>(function(){try{if(location.search.indexOf("utm_campaign=gbp")<0||sessionStorage.getItem("mrsh_gbp"))return;sessionStorage.setItem("mrsh_gbp","1");var f=new FormData();f.append("action","mrsh_gbp_hit");navigator.sendBeacon?navigator.sendBeacon(' . wp_json_encode( admin_url( 'admin-ajax.php' ) ) . ',f):fetch(' . wp_json_encode( admin_url( 'admin-ajax.php' ) ) . ',{method:"POST",body:f})}catch(e){}})();</script>';
	}

	public static function hit() {
		$h   = (array) get_option( self::HITS, array() );
		$day = gmdate( 'Y-m-d' );
		$h[ $day ] = ( isset( $h[ $day ] ) ? (int) $h[ $day ] : 0 ) + 1;
		krsort( $h );
		update_option( self::HITS, array_slice( $h, 0, 60, true ), false );
		wp_send_json_success();
	}

	/** Review button for members (My account) and the shortcode. */
	private static function button_html() {
		$u = self::review_url();
		if ( ! $u ) {
			return '';
		}
		return '<a class="btn" href="' . esc_url( $u ) . '" target="_blank" rel="noopener">Review us on Google</a>';
	}

	/** Review link for members when the feature is on, else empty. */
	public static function review_ask_url() {
		$g = self::get();
		return ( $g['on'] && $g['btn'] ) ? self::review_url() : '';
	}

	/** One-time banner in My account once the member's profile is live. Asks everyone, never only happy members. */
	public static function banner( $uid = 0 ) {
		$uid = $uid ? (int) $uid : get_current_user_id();
		if ( ! $uid || '' === self::review_ask_url() || get_user_meta( $uid, 'mrsh_rv_done', true ) ) {
			return;
		}
		$live = get_posts( array( 'post_type' => 'listing_type', 'author' => $uid, 'post_status' => 'publish', 'numberposts' => 1, 'fields' => 'ids', 'no_found_rows' => true ) );
		if ( ! $live ) {
			return;
		}
		$go  = function ( $a ) {
			return esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_rv_go&a=' . $a ), 'mrsh_rv_go' ) );
		};
		echo '<div class="box" style="border:1px solid #e9d5ff;background:#faf5ff;position:relative"><a href="' . $go( 'close' ) . '" aria-label="Close" style="position:absolute;top:8px;right:12px;text-decoration:none;color:#6b7280;font-size:18px">&times;</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<h3 style="margin-top:0">Happy with ' . esc_html( get_bloginfo( 'name' ) ) . '?</h3><p style="color:#555;font-size:.92rem;margin:.3em 0 .8em">Leave a short honest review on Google. It takes five seconds and helps other families find a free, safe rishta service. / گوگل پر مختصر سچا تبصرہ لکھیں، صرف پانچ سیکنڈ لگتے ہیں۔</p>';
		echo '<a class="btn" href="' . $go( 'review' ) . '" target="_blank" rel="noopener">Review us on Google</a></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	public static function rv_go() {
		$uid = get_current_user_id();
		if ( ! $uid || ! wp_verify_nonce( isset( $_GET['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ) : '', 'mrsh_rv_go' ) ) {
			wp_safe_redirect( home_url( '/' ) );
			exit;
		}
		update_user_meta( $uid, 'mrsh_rv_done', time() );
		$a = isset( $_GET['a'] ) ? sanitize_key( wp_unslash( $_GET['a'] ) ) : '';
		$u = self::review_url();
		if ( 'review' === $a && $u ) {
			wp_redirect( $u ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect
			exit;
		}
		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : home_url( '/' ) );
		exit;
	}

	public static function account() {
		$g = self::get();
		if ( ! $g['on'] || ! $g['btn'] || ! self::review_url() ) {
			return;
		}
		echo '<div class="box"><h3>Happy with ' . esc_html( get_bloginfo( 'name' ) ) . '?</h3><p style="color:#666;font-size:.92rem">A short honest review on Google helps other families find a free, safe rishta service.</p>' . self::button_html() . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	public static function shortcode() {
		$g = self::get();
		return ( $g['on'] && $g['btn'] ) ? self::button_html() : '';
	}

	/* ---------- ready texts ---------- */

	public static function posts() {
		$site = get_bloginfo( 'name' );
		$link = self::tagged( '/', 'post' );
		$place = '';
		if ( class_exists( 'MRSH_Places' ) ) {
			$t = MRSH_Places::today();
			if ( $t ) {
				$place = $t[0]['en'] ? $t[0]['en'] : $t[0]['ur'];
			}
		}
		$p = array(
			array( 'Free service', $site . ' is a free rishta service for Pakistani families. Create a profile in minutes, no fees, no agents. Families stay in control. ' . $link . ' / ' . $site . ' پاکستانی خاندانوں کے لیے مفت رشتہ سروس ہے۔ چند منٹ میں پروفائل بنائیں، کوئی فیس نہیں۔' ),
			array( 'Safety tip', 'Safety tip: meet in a public place with elders present, and never send money to someone you meet online. Report anything suspicious from the profile page. ' . $link . ' / حفاظتی مشورہ: ملاقات عوامی جگہ پر بزرگوں کی موجودگی میں کریں اور آن لائن ملنے والے کو رقم نہ بھیجیں۔' ),
			array( 'Profile tip', 'A clear photo, honest details and a short family introduction make a profile trusted. Finish yours today. ' . $link . ' / صاف تصویر، سچی معلومات اور خاندان کا مختصر تعارف پروفائل کو قابل اعتماد بناتا ہے۔' ),
			array( 'Place of the day', ( $place ? 'Place of the day: ' . $place . '. ' : '' ) . 'Every day we share the history of places of Pakistan with our members. ' . $link . ' / ہر روز ہم پاکستان کے مقامات کی تاریخ اپنے ممبران کے ساتھ شیئر کرتے ہیں۔' ),
			array( 'For families', 'Looking for a rishta for your son or daughter? Browse verified profiles and contact families respectfully. ' . self::tagged( '/for-brides-families/', 'post' ) . ' / بیٹے یا بیٹی کے لیے رشتہ تلاش کر رہے ہیں؟ تصدیق شدہ پروفائل دیکھیں اور احترام سے رابطہ کریں۔' ),
			array( 'Overseas Pakistanis', 'Living abroad? Families overseas can find a rishta in Pakistan here, with privacy controls for every member. ' . $link . ' / بیرونِ ملک رہنے والے خاندان بھی یہاں پاکستان میں رشتہ تلاش کر سکتے ہیں۔' ),
			array( 'Biodata', 'Make a one-page biodata from your profile, save it as PDF and share it with your family. ' . self::tagged( '/my-biodata/', 'post' ) . ' / اپنے پروفائل سے ایک صفحے کا بائیو ڈیٹا بنائیں، پی ڈی ایف محفوظ کریں اور گھر والوں کو بھیجیں۔' ),
		);
		return $p;
	}

	public static function replies() {
		return array(
			array( '5 stars', 'Thank you for your kind words and for trusting us with your family\'s search. We pray you find a good match soon. / آپ کے محبت بھرے الفاظ اور اعتماد کا شکریہ۔ دعا ہے آپ کو جلد اچھا رشتہ ملے۔' ),
			array( '3 to 4 stars', 'Thank you for the feedback. We would like to make this better for you. Please tell us what could be improved through the Contact page. / آپ کی رائے کا شکریہ۔ ہم بہتری چاہتے ہیں، رابطہ صفحے کے ذریعے بتائیں کہ کیا بہتر ہو سکتا ہے۔' ),
			array( 'Complaint', 'We are sorry about your experience. Please contact us with your registered email so we can look into it personally and help. / آپ کے تجربے پر ہمیں افسوس ہے۔ رجسٹرڈ ای میل کے ساتھ رابطہ کریں تاکہ ہم ذاتی طور پر دیکھ کر مدد کر سکیں۔' ),
			array( 'Ask for a review', 'Salaam! If our service helped you, would you leave a short honest review on Google? It helps other families a lot. {link} / السلام علیکم! اگر ہماری سروس سے مدد ملی تو براہ کرم گوگل پر مختصر سچا تبصرہ لکھیں۔ {link}' ),
		);
	}

	public static function qa() {
		return array(
			array( 'Is it free?', 'Yes. Creating a profile and contacting families is free. We never ask for money to arrange a rishta.' ),
			array( 'Who can join?', 'Pakistani families and individuals looking for marriage, in Pakistan and abroad. Profiles are reviewed before they appear.' ),
			array( 'How do you keep members safe?', 'Photos and profiles are checked, members can block and report, and we advise meeting in public with elders present.' ),
			array( 'Can parents manage a profile?', 'Yes. A parent or guardian can create and manage a profile for a son or daughter.' ),
			array( 'Do you take commission or charge for matches?', 'No. We are a free, non-profit service and do not sell matches.' ),
			array( 'How do I delete my profile?', 'Sign in, open My account and use the delete option. Your data is removed.' ),
		);
	}

	/* ---------- admin ---------- */

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Google Business Profile', 'Google Business Profile', 'manage_options', 'mrsh-gbp', array( __CLASS__, 'page' ) );
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.', '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'mrsh_gbp_save' );
		$p = function ( $k ) {
			return isset( $_POST[ $k ] ) ? sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		};
		update_option( self::OPT, array(
			'on'       => empty( $_POST['on'] ) ? 0 : 1, // phpcs:ignore
			'schema'   => empty( $_POST['schema'] ) ? 0 : 1, // phpcs:ignore
			'btn'      => empty( $_POST['btn'] ) ? 0 : 1, // phpcs:ignore
			'name'     => $p( 'name' ),
			'review'   => esc_url_raw( $p( 'review' ) ),
			'place_id' => preg_replace( '/[^A-Za-z0-9_\-]/', '', $p( 'place_id' ) ),
			'url'      => esc_url_raw( $p( 'url' ) ),
			'phone'    => preg_replace( '/[^0-9+\-\s()]/', '', $p( 'phone' ) ),
			'email'    => sanitize_email( $p( 'email' ) ),
			'area'     => $p( 'area' ),
			'hours'    => $p( 'hours' ),
			'same'     => isset( $_POST['same'] ) ? sanitize_textarea_field( wp_unslash( $_POST['same'] ) ) : '', // phpcs:ignore
		), false );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-gbp&ok=1' ) );
		exit;
	}

	private static function copy_row( $label, $text ) {
		return '<div class="mx-row" style="display:flex;gap:10px;align-items:flex-start;padding:10px 0;border-bottom:1px solid #eee"><div style="flex:1;min-width:0"><b>' . esc_html( $label ) . '</b><div class="mrsh-gb-t" style="color:#444;margin-top:2px;word-break:break-word">' . esc_html( $text ) . '</div></div><button type="button" class="button mrsh-gb-copy">Copy</button></div>';
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		try {
			$g    = self::get();
			$hits = (array) get_option( self::HITS, array() );
			$week = 0;
			$all  = 0;
			$now  = time();
			foreach ( $hits as $d => $n ) {
				$all += (int) $n;
				if ( strtotime( $d . ' 00:00:00 UTC' ) >= $now - 7 * DAY_IN_SECONDS ) {
					$week += (int) $n;
				}
			}
			$chk = array(
				array( 'Business name entered', '' !== $g['name'], 'Type the name exactly as it is on Google.' ),
				array( 'Profile link or Place ID entered', '' !== $g['url'] || '' !== $g['place_id'] || '' !== $g['review'], 'Needed for the review button and for Google to match the site.' ),
				array( 'Phone or email entered', '' !== $g['phone'] || '' !== $g['email'], 'Use the same one as on the profile.' ),
				array( 'Opening hours entered', '' !== $g['hours'], 'For example Mo-Su 00:00-23:59 for an online service.' ),
				array( 'Home page schema is on', ! empty( $g['schema'] ) && ! empty( $g['on'] ), 'Lets Google read the business details from the site.' ),
				array( 'Contact page exists', (bool) get_page_by_path( 'contact' ) || (bool) get_page_by_path( 'contact-us' ), 'Same phone and email as the profile.' ),
				array( 'Privacy page exists', (bool) get_page_by_path( 'privacy-policy' ) || (bool) get_page_by_path( 'privacy' ), 'Google trusts sites with clear policies.' ),
				array( 'Profile link added to the site (sameAs)', '' !== $g['url'] || '' !== trim( $g['same'] ), 'Links the site and the profile.' ),
				array( 'Google Ads tag is set', class_exists( 'MRSH_Gads' ) && '' !== (string) ( MRSH_Gads::get()['id'] ?? '' ), 'So visits from the profile can count as leads.' ),
				array( 'First visit from the profile seen', $all > 0, 'Use the tagged links below on the profile buttons.' ),
			);
			$ok = 0;
			foreach ( $chk as $c ) {
				$ok += $c[1] ? 1 : 0;
			}
			$pct = (int) round( $ok / count( $chk ) * 100 );

			MRSH_Boost::ui_open( 'Google Business Profile', 'Help Google match the site to your profile, bring visits from it, and collect reviews. Works well together with Google Ads.', 'g-blue', 'M12 2a7 7 0 0 0-7 7c0 5 7 13 7 13s7-8 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6a2.5 2.5 0 0 1 0 5.5z' );
			if ( isset( $_GET['ok'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
				MRSH_Boost::ui_ok( 'Saved. Clear the LiteSpeed cache so the home page schema updates.' );
			}
			echo '<div style="display:flex;gap:12px;flex-wrap:wrap;margin:14px 0">' . MRSH_Boost::ui_stat( $pct . '%', 'Ready', '#12a375' ) . MRSH_Boost::ui_stat( $week, 'Visits from profile (7 days)', '#2563eb' ) . MRSH_Boost::ui_stat( $all, 'Visits from profile (60 days)', '#7c3aed' ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput

			echo '<div class="card" style="max-width:none;padding:16px;margin:12px 0"><h2 style="margin-top:0">1. Readiness</h2><div style="height:10px;background:#eee;border-radius:10px;overflow:hidden;margin:8px 0 12px"><i style="display:block;height:100%;width:' . (int) $pct . '%;background:linear-gradient(90deg,#c9962f,#12a375)"></i></div>';
			foreach ( $chk as $c ) {
				echo '<div style="padding:6px 0;border-bottom:1px solid #f1f1f1"><b style="color:' . ( $c[1] ? '#0f7a55' : '#b45309' ) . '">' . ( $c[1] ? '✔' : '○' ) . '</b> ' . esc_html( $c[0] ) . ( $c[1] ? '' : ' <span class="description">' . esc_html( $c[2] ) . '</span>' ) . '</div>';
			}
			echo '</div>';

			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="card" style="max-width:none;padding:16px;margin:12px 0"><h2 style="margin-top:0">2. Business details</h2><input type="hidden" name="action" value="mrsh_gbp_save">' . wp_nonce_field( 'mrsh_gbp_save', '_wpnonce', true, false ); // phpcs:ignore WordPress.Security.EscapeOutput
			echo '<p><label><input type="checkbox" name="on" value="1"' . checked( $g['on'], 1, false ) . '> Switch everything on this page on</label> &nbsp; <label><input type="checkbox" name="schema" value="1"' . checked( $g['schema'], 1, false ) . '> Add business details to the home page (schema)</label> &nbsp; <label><input type="checkbox" name="btn" value="1"' . checked( $g['btn'], 1, false ) . '> Show "Review us on Google" in My account</label></p>';
			$f = function ( $n, $l, $v, $ph = '' ) {
				echo '<p><label><strong>' . esc_html( $l ) . '</strong><br><input type="text" name="' . esc_attr( $n ) . '" value="' . esc_attr( $v ) . '" class="regular-text" placeholder="' . esc_attr( $ph ) . '" style="width:100%;max-width:520px"></label></p>';
			};
			$f( 'name', 'Business name (as on Google)', $g['name'], get_bloginfo( 'name' ) );
			$f( 'url', 'Google profile link (Share > copy link, starts with https://)', $g['url'] );
			$f( 'review', 'Review link (easiest: in Google Business Profile press Get more reviews, copy the link)', $g['review'], 'https://g.page/r/.../review' );
			$f( 'place_id', 'Place ID (optional, only if you have no review link)', $g['place_id'], 'ChIJ...' );
			echo '<p class="description" style="margin-top:-8px">Use the review link OR the Place ID. One of them is enough for the review button.</p>';
			$f( 'phone', 'Phone (same as the profile)', $g['phone'], '+92...' );
			$f( 'email', 'Email (same as the profile)', $g['email'] );
			$f( 'area', 'Area served', $g['area'] );
			$f( 'hours', 'Opening hours (schema format)', $g['hours'], 'Mo-Su 00:00-23:59' );
			echo '<p><label><strong>Other official pages (one link per line: Facebook, Instagram, YouTube...)</strong><br><textarea name="same" rows="4" class="large-text" style="max-width:520px">' . esc_textarea( $g['same'] ) . '</textarea></label></p>';
			echo '<p><button class="button button-primary">Save</button></p></form>';

			echo '<div class="card" style="max-width:none;padding:16px;margin:12px 0"><h2 style="margin-top:0">3. Links for your profile buttons</h2><p class="description">Paste these in Google Business Profile (website, appointment and posts). Visits through them are counted above and can be tracked in Google Ads and Analytics.</p>';
			echo self::copy_row( 'Website button', self::tagged( '/', 'website' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
			echo self::copy_row( 'Appointment / sign-up button', self::tagged( '/add-listing/', 'signup' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
			echo self::copy_row( 'Message / contact button', self::tagged( '/contact/', 'contact' ) ); // phpcs:ignore WordPress.Security.EscapeOutput
			$r = self::review_url();
			echo self::copy_row( 'Review link (send to happy members)', $r ? $r : 'Add the review link or Place ID above first.' ); // phpcs:ignore WordPress.Security.EscapeOutput
			echo '<p><a class="button" href="https://business.google.com/" target="_blank" rel="noopener">Open Google Business Profile</a> <a class="button" href="' . esc_url( admin_url( 'admin.php?page=mrsh-gads' ) ) . '">Google Ads page</a></p></div>';

			echo '<div class="card" style="max-width:none;padding:16px;margin:12px 0"><h2 style="margin-top:0">4. Post ideas (copy and post weekly)</h2><p class="description">Posts keep the profile active. Seven ready posts, English and Urdu.</p>';
			foreach ( self::posts() as $x ) {
				echo self::copy_row( $x[0], $x[1] ); // phpcs:ignore WordPress.Security.EscapeOutput
			}
			echo '</div><div class="card" style="max-width:none;padding:16px;margin:12px 0"><h2 style="margin-top:0">5. Reviews: ask and reply</h2>';
			foreach ( self::replies() as $x ) {
				echo self::copy_row( $x[0], str_replace( '{link}', $r ? $r : '[review link]', $x[1] ) ); // phpcs:ignore WordPress.Security.EscapeOutput
			}
			echo '</div><div class="card" style="max-width:none;padding:16px;margin:12px 0"><h2 style="margin-top:0">6. Questions and answers for the profile</h2><p class="description">Add these in the Q and A section so the answers are ready before visitors ask.</p>';
			foreach ( self::qa() as $x ) {
				echo self::copy_row( $x[0], $x[1] ); // phpcs:ignore WordPress.Security.EscapeOutput
			}
			echo '</div><div class="card" style="max-width:none;padding:16px;margin:12px 0"><h2 style="margin-top:0">7. Get more leads with Google Ads</h2><ol><li>Open Google Ads, go to Assets, add a <b>Location</b> asset and link your Business Profile.</li><li>Use the tagged website link above as the final URL for local campaigns, so visits are counted here.</li><li>Keep the Google Ads tag and conversions on the Google Ads page switched on; sign-ups and messages already count as leads.</li><li>Ask three happy members for a review each week with the ready text above.</li></ol></div></div>';
			if ( class_exists( 'MRSH_AdsTools' ) ) {
				MRSH_AdsTools::panel( 'gbp' );
			}
			echo '<script>document.querySelectorAll(".mrsh-gb-copy").forEach(function(b){b.onclick=function(){var t=b.parentNode.querySelector(".mrsh-gb-t");var v=t.textContent;var done=function(){b.textContent="Copied";setTimeout(function(){b.textContent="Copy"},1500)};if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(v).then(done,function(){var r=document.createRange();r.selectNodeContents(t);var s=getSelection();s.removeAllRanges();s.addRange(r)})}else{var r=document.createRange();r.selectNodeContents(t);var s=getSelection();s.removeAllRanges();s.addRange(r)}}});</script>';
		} catch ( \Throwable $e ) {
			MRSH_Safe::log_ex( $e, 'MRSH_Gbp::page' );
			echo '<div class="wrap"><p>This page had a problem. It was logged on the Problems page.</p></div>';
		}
	}
}
MRSH_Gbp::init();
