<?php
/** Admin screens: Settings, Profiles manager, Messages monitor, Users (ban), Orders (read only); and "who viewed me" tracking. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Manage {

	public static function defaults() {
		return array( 'wink' => 50, 'interest' => 20, 'msg' => 30, 'status' => 'publish', 'minpct' => 40, 'digest' => 1, 'words' => '', 'minage' => 18, 'needphoto' => 0, 'wordsprof' => 1, 'dupphone' => 1, 'autopause' => 3, 'maxgift' => 10, 'photos' => 1, 'blurguest' => 0, 'style' => 'emerald' );
	}

	public static function get() {
		$o = get_option( 'mrsh_mem', array() );
		return array_merge( self::defaults(), is_array( $o ) ? $o : array() );
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 28 );
		add_action( 'admin_post_mrt_mem_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_mrt_prof', array( __CLASS__, 'prof_action' ) );
		add_action( 'admin_post_mrt_msgdel', array( __CLASS__, 'msg_delete' ) );
		add_action( 'admin_post_mrt_setplan', array( __CLASS__, 'setplan' ) );
		add_action( 'admin_post_mrt_ban', array( __CLASS__, 'ban' ) );
		add_filter( 'authenticate', array( __CLASS__, 'block_login' ), 99, 2 );
		add_action( 'template_redirect', array( __CLASS__, 'track_view' ) );
		add_action( 'wp_footer', array( __CLASS__, 'hidden_banner' ) );
	}

	/** Only an administrator can open a hidden profile. Say so clearly, so it is not mistaken for a live one. */
	public static function hidden_banner() {
		if ( ! is_singular( 'listing_type' ) || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$post = get_queried_object();
		if ( ! $post ) {
			return;
		}
		$ban = get_user_meta( (int) $post->post_author, 'mrt_banned', true );
		if ( 'publish' === $post->post_status && ! $ban ) {
			return;
		}
		$why = $ban ? 'This member is blocked.' : 'This profile is not published.';
		echo '<div style="position:fixed;left:0;right:0;bottom:0;z-index:99999;background:#991b1b;color:#fff;padding:12px 16px;text-align:center;font:600 14px system-ui">' . esc_html( $why ) . ' Visitors and members cannot see this page. Only you (administrator) can.</div>'; // phpcs:ignore
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Member settings', 'Member settings', 'manage_options', 'mrsh-mem', array( __CLASS__, 'page_settings' ) );
		add_submenu_page( 'myrishta-seo', 'Profiles', 'Profiles', 'manage_options', 'mrsh-profiles', array( __CLASS__, 'page_profiles' ) );
		add_submenu_page( 'myrishta-seo', 'Messages', 'Messages', 'manage_options', 'mrsh-msgs', array( __CLASS__, 'page_msgs' ) );
		add_submenu_page( 'myrishta-seo', 'Members', 'Members', 'manage_options', 'mrsh-users', array( __CLASS__, 'page_users' ) );
		add_submenu_page( 'myrishta-seo', 'Orders', 'Orders', 'manage_options', 'mrsh-orders', array( __CLASS__, 'page_orders' ) );
	}

	private static function guard( $nonce = '' ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		if ( $nonce ) {
			check_admin_referer( $nonce );
		}
	}

	private static function nurl( $action, $args, $nonce ) {
		return wp_nonce_url( add_query_arg( array_merge( array( 'action' => $action ), $args ), admin_url( 'admin-post.php' ) ), $nonce );
	}

	/* ---- settings ---- */
	public static function page_settings() {
		$s = self::get();
		echo '<div class="wrap"><h1>Member settings</h1>';
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success"><p>Saved.</p></div>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrt_mem_save">';
		wp_nonce_field( 'mrt_mem_save' );
		echo '<table class="form-table">';
		foreach ( array( 'wink' => 'Winks per member per day', 'interest' => 'Interests per member per day', 'msg' => 'Messages per member per day', 'minpct' => 'Lowest match % shown' ) as $k => $l ) {
			echo '<tr><th>' . esc_html( $l ) . '</th><td><input type="number" min="1" max="500" name="' . esc_attr( $k ) . '" value="' . (int) $s[ $k ] . '"></td></tr>';
		}
		echo '<tr><th>New profiles</th><td><select name="status"><option value="publish"' . selected( $s['status'], 'publish', false ) . '>Go live at once</option><option value="pending"' . selected( $s['status'], 'pending', false ) . '>Wait for my approval</option></select></td></tr>';
		echo '<tr><th>Weekly match email</th><td><label><input type="checkbox" name="digest" value="1"' . checked( $s['digest'], 1, false ) . '> On</label></td></tr>';
		if ( function_exists( 'mrt_styles' ) ) {
			echo '<tr><th>Interface style</th><td><select name="style">';
			foreach ( mrt_styles() as $k => $d ) {
				echo '<option value="' . esc_attr( $k ) . '"' . selected( $s['style'], $k, false ) . '>' . esc_html( $d[0] ) . '</option>';
			}
			echo '</select> <span class="description">Changes colours, fonts and shapes of the whole site.</span></td></tr>';
		}
		echo '<tr><th>Photos</th><td><label><input type="checkbox" name="photos" value="1"' . checked( $s['photos'], 1, false ) . '> Show small photos in lists and profiles</label><br><label><input type="checkbox" name="blurguest" value="1"' . checked( $s['blurguest'], 1, false ) . '> Blur photos for visitors who are not logged in</label></td></tr>';
		echo '<tr><th>Profile rules</th><td><label>Lowest age allowed <input type="number" min="18" max="60" name="minage" value="' . (int) $s['minage'] . '" style="width:80px"></label><br><label><input type="checkbox" name="needphoto" value="1"' . checked( $s['needphoto'], 1, false ) . '> New profiles without a photo wait for my approval</label><br><label><input type="checkbox" name="wordsprof" value="1"' . checked( $s['wordsprof'], 1, false ) . '> Apply blocked words to names and about text too</label><br><label><input type="checkbox" name="dupphone" value="1"' . checked( $s['dupphone'], 1, false ) . '> Refuse a phone number already used by another profile</label><br><label>Pause a profile after this many reports (0 = never) <input type="number" min="0" max="50" name="autopause" value="' . (int) $s['autopause'] . '" style="width:80px"></label><br><label>Virtual gifts per member per day <input type="number" min="0" max="100" name="maxgift" value="' . (int) $s['maxgift'] . '" style="width:80px"></label></td></tr>';
		echo '<tr><th>Blocked words</th><td><textarea name="words" rows="4" cols="50" placeholder="one word per line">' . esc_textarea( $s['words'] ) . '</textarea></td></tr></table><p><button class="button button-primary">Save</button></p></form></div>';
	}

	public static function save() {
		self::guard( 'mrt_mem_save' );
		$o = array();
		foreach ( array( 'wink', 'interest', 'msg', 'minpct' ) as $k ) {
			$o[ $k ] = isset( $_POST[ $k ] ) ? max( 1, min( 500, absint( $_POST[ $k ] ) ) ) : self::defaults()[ $k ];
		}
		$o['status'] = isset( $_POST['status'] ) && 'pending' === $_POST['status'] ? 'pending' : 'publish';
		$o['digest'] = empty( $_POST['digest'] ) ? 0 : 1;
		$o['style'] = ( isset( $_POST['style'] ) && function_exists( 'mrt_styles' ) && isset( mrt_styles()[ $_POST['style'] ] ) ) ? sanitize_key( $_POST['style'] ) : 'emerald';
		$o['photos'] = empty( $_POST['photos'] ) ? 0 : 1;
		$o['blurguest'] = empty( $_POST['blurguest'] ) ? 0 : 1;
		$o['minage']    = isset( $_POST['minage'] ) ? max( 18, min( 60, absint( $_POST['minage'] ) ) ) : 18;
		foreach ( array( 'needphoto', 'wordsprof', 'dupphone' ) as $k ) {
			$o[ $k ] = empty( $_POST[ $k ] ) ? 0 : 1;
		}
		$o['autopause'] = isset( $_POST['autopause'] ) ? max( 0, min( 50, absint( $_POST['autopause'] ) ) ) : 3;
		$o['maxgift']   = isset( $_POST['maxgift'] ) ? max( 0, min( 100, absint( $_POST['maxgift'] ) ) ) : 10;
		$o['words']  = isset( $_POST['words'] ) ? sanitize_textarea_field( wp_unslash( $_POST['words'] ) ) : '';
		update_option( 'mrsh_mem', $o, false );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-mem&ok=1' ) );
		exit;
	}

	/* ---- profiles ---- */
	public static function page_profiles() {
		$st = isset( $_GET['st'] ) ? sanitize_key( $_GET['st'] ) : 'any'; // phpcs:ignore
		$q  = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : ''; // phpcs:ignore
		$pg = isset( $_GET['pg'] ) ? max( 1, absint( $_GET['pg'] ) ) : 1; // phpcs:ignore
		$ps = get_posts( array( 'post_type' => 'listing_type', 'post_status' => 'any' === $st ? array( 'publish', 'draft', 'pending', 'pending_approval', 'payment', 'expired' ) : $st, 's' => $q, 'posts_per_page' => 30, 'paged' => $pg ) );
		echo '<div class="wrap"><h1>Profiles</h1><form method="get"><input type="hidden" name="page" value="mrsh-profiles"><input name="q" value="' . esc_attr( $q ) . '" placeholder="Name"> <select name="st">';
		foreach ( array( 'any' => 'All', 'publish' => 'Live', 'pending' => 'Waiting', 'draft' => 'Paused', 'expired' => 'Expired' ) as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $st, $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select> <button class="button">Filter</button></form><table class="widefat striped"><thead><tr><th>ID</th><th>Name</th><th>Age</th><th>Status</th><th>Reports</th><th>Actions</th></tr></thead><tbody>';
		foreach ( $ps as $p ) {
			$b  = function ( $do, $l ) use ( $p ) {
				return '<a class="button button-small" href="' . esc_url( self::nurl( 'mrt_prof', array( 'pid' => $p->ID, 'do' => $do ), 'mrt_prof' . $p->ID ) ) . '"' . ( 'delete' === $do ? ' onclick="return confirm(\'Move to trash?\')"' : '' ) . '>' . esc_html( $l ) . '</a> ';
			};
			echo '<tr><td>' . (int) $p->ID . '</td><td><a href="' . esc_url( get_edit_post_link( $p->ID ) ) . '">' . esc_html( $p->post_title ) . '</a></td><td>' . (int) get_post_meta( $p->ID, 'daage', true ) . '</td><td>' . esc_html( $p->post_status ) . ( 'yes' === get_post_meta( $p->ID, 'featured', true ) ? ' ★' : '' ) . ( get_user_meta( (int) $p->post_author, '_mrsh_id_verified', true ) ? ' ✔' : '' ) . '</td><td>' . count( array_filter( (array) get_post_meta( $p->ID, 'mrt_reports', true ) ) ) . '</td><td>';
			echo ( 'publish' === $p->post_status ? $b( 'pause', 'Pause' ) : $b( 'approve', 'Approve' ) ) . $b( 'feature', 'Feature on/off' ) . $b( 'verify', 'Verify on/off' ) . $b( 'delete', 'Trash' ); // phpcs:ignore
			echo '</td></tr>';
		}
		echo '</tbody></table><p>' . ( $pg > 1 ? '<a class="button" href="' . esc_url( add_query_arg( 'pg', $pg - 1 ) ) . '">Previous</a> ' : '' ) . ( count( $ps ) === 30 ? '<a class="button" href="' . esc_url( add_query_arg( 'pg', $pg + 1 ) ) . '">Next</a>' : '' ) . '</p></div>';
	}

	public static function prof_action() {
		$id = isset( $_GET['pid'] ) ? absint( $_GET['pid'] ) : 0;
		self::guard( 'mrt_prof' . $id );
		$do = isset( $_GET['do'] ) ? sanitize_key( $_GET['do'] ) : '';
		if ( 'approve' === $do ) {
			wp_update_post( array( 'ID' => $id, 'post_status' => 'publish' ) );
		} elseif ( 'pause' === $do ) {
			wp_update_post( array( 'ID' => $id, 'post_status' => 'draft' ) );
		} elseif ( 'feature' === $do ) {
			update_post_meta( $id, 'featured', 'yes' === get_post_meta( $id, 'featured', true ) ? 'no' : 'yes' );
		} elseif ( 'verify' === $do ) {
			$au = (int) get_post_field( 'post_author', $id );
			get_user_meta( $au, '_mrsh_id_verified', true ) ? delete_user_meta( $au, '_mrsh_id_verified' ) : update_user_meta( $au, '_mrsh_id_verified', time() );
			delete_transient( 'mrsh_verified_map' );
		} elseif ( 'delete' === $do ) {
			wp_trash_post( $id );
		}
		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : admin_url( 'admin.php?page=mrsh-profiles' ) );
		exit;
	}

	/* ---- messages ---- */
	public static function page_msgs() {
		$ms = get_posts( array( 'post_type' => 'ppt_message', 'post_status' => 'publish', 'numberposts' => 50 ) );
		echo '<div class="wrap"><h1>Messages</h1><p>Latest 50. Remove anything abusive or that asks for money.</p><table class="widefat striped"><thead><tr><th>Date</th><th>From</th><th>To</th><th>Text</th><th></th></tr></thead><tbody>';
		foreach ( $ms as $m ) {
			$f = get_userdata( (int) get_post_meta( $m->ID, 'sender_id', true ) );
			$t = get_userdata( (int) get_post_meta( $m->ID, 'reciever_id', true ) );
			echo '<tr><td>' . esc_html( mysql2date( 'j M H:i', $m->post_date ) ) . '</td><td>' . esc_html( $f ? $f->display_name : '-' ) . '</td><td>' . esc_html( $t ? $t->display_name : '-' ) . '</td><td>' . esc_html( wp_trim_words( $m->post_content, 30 ) ) . '</td><td><a class="button button-small" href="' . esc_url( self::nurl( 'mrt_msgdel', array( 'mid' => $m->ID ), 'mrt_msgdel' . $m->ID ) ) . '">Remove</a></td></tr>';
		}
		echo '</tbody></table></div>';
	}

	public static function msg_delete() {
		$id = isset( $_GET['mid'] ) ? absint( $_GET['mid'] ) : 0;
		self::guard( 'mrt_msgdel' . $id );
		$p = get_post( $id );
		if ( $p && 'ppt_message' === $p->post_type ) {
			wp_trash_post( $id );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-msgs' ) );
		exit;
	}

	/* ---- users ---- */
	public static function page_users() {
		$q  = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : ''; // phpcs:ignore
		$us = get_users( array( 'number' => 40, 'orderby' => 'registered', 'order' => 'DESC', 'search' => $q ? '*' . $q . '*' : '', 'search_columns' => array( 'user_login', 'user_email', 'display_name' ) ) );
		echo '<div class="wrap"><h1>Members</h1><form method="get"><input type="hidden" name="page" value="mrsh-users"><input name="q" value="' . esc_attr( $q ) . '" placeholder="Name or email"> <button class="button">Search</button></form><table class="widefat striped"><thead><tr><th>Name</th><th>Email</th><th>Joined</th><th>Last seen</th><th>Profile</th><th>Plan</th><th></th></tr></thead><tbody>';
		foreach ( $us as $u ) {
			$p  = MRSH_Members::my_profile( $u->ID );
			$bn = (bool) get_user_meta( $u->ID, 'mrt_banned', true );
			$ls = (int) get_user_meta( $u->ID, 'mrt_seen', true );
			echo '<tr><td>' . esc_html( $u->display_name ) . '</td><td>' . esc_html( $u->user_email ) . '</td><td>' . esc_html( mysql2date( 'j M Y', $u->user_registered ) ) . '</td><td>' . ( $ls ? esc_html( human_time_diff( $ls ) . ' ago' ) : '-' ) . '</td><td>' . ( $p ? '<a href="' . esc_url( get_edit_post_link( $p->ID ) ) . '">#' . (int) $p->ID . ' ' . esc_html( $p->post_status ) . '</a>' : '-' ) . '</td><td>' . self::plan_cell( $u->ID ) . '</td><td>';
			if ( ! user_can( $u, 'manage_options' ) ) {
				echo '<a class="button button-small" href="' . esc_url( self::nurl( 'mrt_ban', array( 'uid' => $u->ID ), 'mrt_ban' . $u->ID ) ) . '">' . ( $bn ? 'Unban' : 'Ban' ) . '</a> ';
				if ( class_exists( 'MRSH_PermBan' ) ) {
					echo MRSH_PermBan::is_perm( $u->ID ) ? '<a class="button button-small" href="' . esc_url( MRSH_PermBan::link( $u->ID, 'undo' ) ) . '">Undo ban for good</a>' : '<a class="button button-small" style="color:#b91c1c" href="' . esc_url( MRSH_PermBan::link( $u->ID ) ) . '" onclick="return confirm(\'Ban for good? They can never come back. Their record is kept.\')">Ban for good</a>';
				}
			}
			echo '</td></tr>';
		}
		echo '</tbody></table></div>';
	}

	private static function plan_cell( $uid ) {
		$cur = (string) get_user_meta( $uid, 'mrt_plan', true );
		$req = (string) get_user_meta( $uid, 'mrt_plan_req', true );
		$h   = '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:flex;gap:4px"><input type="hidden" name="action" value="mrt_setplan"><input type="hidden" name="uid" value="' . (int) $uid . '">' . wp_nonce_field( 'mrt_setplan' . $uid, '_wpnonce', true, false ) . '<select name="plan"><option value="">-</option>';
		if ( function_exists( 'mrt_plans' ) ) {
			foreach ( mrt_plans() as $p ) {
				$h .= '<option' . selected( $cur, $p[0], false ) . '>' . esc_html( $p[0] ) . '</option>';
			}
		}
		return $h . '</select><button class="button button-small">Set</button></form>' . ( $req ? '<small>asked: ' . esc_html( $req ) . '</small>' : '' );
	}

	public static function setplan() {
		$id = isset( $_POST['uid'] ) ? absint( $_POST['uid'] ) : 0;
		self::guard( 'mrt_setplan' . $id );
		$pl = isset( $_POST['plan'] ) ? sanitize_text_field( wp_unslash( $_POST['plan'] ) ) : '';
		if ( $id ) {
			$pl ? update_user_meta( $id, 'mrt_plan', $pl ) : delete_user_meta( $id, 'mrt_plan' );
			delete_user_meta( $id, 'mrt_plan_req' );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-users' ) );
		exit;
	}

	/** Make a suspension complete: hide the profile everywhere, sign the member out, clear cached pages. Safe to run again. */
	public static function enforce_ban( $uid ) {
		$uid  = (int) $uid;
		$done = false;
		if ( ! $uid || user_can( $uid, 'manage_options' ) ) {
			return false;
		}
		$p = class_exists( 'MRSH_Members' ) ? MRSH_Members::my_profile( $uid ) : null;
		if ( $p ) {
			if ( 'publish' === $p->post_status ) {
				wp_update_post( array( 'ID' => $p->ID, 'post_status' => 'draft' ) );
				$done = true;
			}
			if ( get_post_meta( $p->ID, 'featured', true ) ) {
				delete_post_meta( $p->ID, 'featured' );
				$done = true;
			}
			update_post_meta( $p->ID, '_mrsh_noindex', 1 );
		}
		if ( class_exists( 'WP_Session_Tokens' ) ) {
			$st = WP_Session_Tokens::get_instance( $uid );
			if ( $st->get_all() ) {
				$st->destroy_all();
				$done = true;
			}
		}
		self::purge_member( $uid, $p ? $p->ID : 0 );
		return $done;
	}

	/** Forget every cached copy of a member: lists, titles, page cache. */
	public static function purge_member( $uid, $pid = 0 ) {
		delete_transient( 'mrsh_people' );
		delete_transient( 'mrsh_titles' );
		delete_transient( 'mrsh_verified_map' );
		delete_transient( 'mrsh_cnt' );
		if ( $pid ) {
			clean_post_cache( $pid );
			do_action( 'litespeed_purge_post', $pid );
		}
		do_action( 'litespeed_purge_url', home_url( '/' ) );
		do_action( 'litespeed_purge_all' );
	}

	public static function ban() {
		$id = isset( $_GET['uid'] ) ? absint( $_GET['uid'] ) : 0;
		self::guard( 'mrt_ban' . $id );
		if ( $id && ! user_can( $id, 'manage_options' ) ) {
			if ( get_user_meta( $id, 'mrt_banned', true ) ) {
				delete_user_meta( $id, 'mrt_banned' );
			} else {
				update_user_meta( $id, 'mrt_banned', 1 );
				self::enforce_ban( $id );
			}
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-users' ) );
		exit;
	}

	public static function block_login( $user, $login ) {
		if ( $user instanceof WP_User && get_user_meta( $user->ID, 'mrt_banned', true ) ) {
			return new WP_Error( 'mrt_banned', 'This account has been suspended. Please contact us.' );
		}
		return $user;
	}

	/* ---- orders (read only; whatever the old theme saved) ---- */
	public static function page_orders() {
		if ( class_exists( 'MRSH_Orders' ) ) {
			MRSH_Orders::page();
			return;
		}
		echo '<div class="wrap"><h1>Orders</h1>';
		$t = post_type_exists( 'ppt_orders' ) ? 'ppt_orders' : ( post_type_exists( 'ppt_order' ) ? 'ppt_order' : '' );
		if ( ! $t ) {
			echo '<p>No order records found. Your data is kept safely in the database; this site is free, so there is nothing to collect.</p></div>';
			return;
		}
		$os = get_posts( array( 'post_type' => $t, 'post_status' => 'any', 'numberposts' => 50 ) );
		echo '<table class="widefat striped"><thead><tr><th>Date</th><th>Order</th><th>Status</th></tr></thead><tbody>';
		foreach ( $os as $o ) {
			echo '<tr><td>' . esc_html( mysql2date( 'j M Y', $o->post_date ) ) . '</td><td>' . esc_html( $o->post_title ) . '</td><td>' . esc_html( $o->post_status ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
	}

	/* ---- who viewed me ---- */
	public static function track_view() {
		if ( ! is_singular( 'listing_type' ) || ! is_user_logged_in() ) {
			return;
		}
		$id  = get_queried_object_id();
		$uid = get_current_user_id();
		if ( (int) get_post_field( 'post_author', $id ) === $uid ) {
			return;
		}
		$v = (array) get_post_meta( $id, 'mrt_viewers', true );
		$v = array_values( array_diff( array_map( 'intval', array_filter( $v ) ), array( $uid ) ) );
		$v[] = $uid;
		update_post_meta( $id, 'mrt_viewers', array_slice( $v, -60 ) );
	}
}
MRSH_Manage::init();
