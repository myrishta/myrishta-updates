<?php
/**
 * Editable member email templates (3.101.152): the "Quick email" list in the Member manager.
 * Option: mrsh_em_tpl (array of array( title, subject, message )). {name} = member name, {site} = site name.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Emtpl {

	const SLUG = 'mrsh-emtpl';

	public static function init() {
		if ( is_admin() ) {
			add_action( 'admin_menu', array( __CLASS__, 'menu' ), 25 );
			add_action( 'admin_post_mrsh_emtpl_save', array( __CLASS__, 'save' ) );
		}
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Email templates', 'Email templates', 'manage_options', self::SLUG, array( __CLASS__, 'page' ) );
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_emtpl' );
		if ( ! empty( $_POST['reset'] ) ) {
			delete_option( 'mrsh_em_tpl' );
			wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&ok=2' ) );
			exit;
		}
		$out = array();
		foreach ( (array) ( $_POST['t'] ?? array() ) as $r ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			$r  = wp_unslash( (array) $r );
			$ti = sanitize_text_field( $r['title'] ?? '' );
			$su = sanitize_text_field( $r['subject'] ?? '' );
			$me = sanitize_textarea_field( $r['message'] ?? '' );
			if ( '' !== $ti && '' !== $su && '' !== trim( $me ) && empty( $r['del'] ) ) {
				$out[] = array( mb_substr( $ti, 0, 40 ), mb_substr( $su, 0, 160 ), $me );
			}
		}
		update_option( 'mrsh_em_tpl', array_slice( $out, 0, 40 ), false );
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&ok=1' ) );
		exit;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		MRSH_Boost::ui_open( 'Email templates', 'Ready emails for the "Quick email" list in the Member manager. Edit the words, tick Delete, or add new ones at the bottom. Use {name} for the member name and {site} for the site name.', 'g-blue', 'M3 5h18v14H3zM3 6l9 7 9-7' );
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			MRSH_Boost::ui_ok( '2' === $_GET['ok'] ? 'Back to the original templates.' : 'Saved.' ); // phpcs:ignore WordPress.Security.NonceVerification
		}
		$rows   = MRSH_Desk::email_templates();
		$rows[] = array( '', '', '' );
		$rows[] = array( '', '', '' );
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_emtpl_save">' . wp_nonce_field( 'mrsh_emtpl', '_wpnonce', true, false );
		foreach ( $rows as $i => $r ) {
			$new = '' === $r[0];
			echo '<div class="mx-card"' . ( $new ? ' style="border-style:dashed"' : '' ) . '><p><b>' . ( $new ? 'New template' : 'Template ' . ( $i + 1 ) ) . '</b></p>';
			echo '<p><input type="text" name="t[' . (int) $i . '][title]" value="' . esc_attr( $r[0] ) . '" placeholder="Name shown in the list" style="width:100%;max-width:420px"></p>';
			echo '<p><input type="text" name="t[' . (int) $i . '][subject]" value="' . esc_attr( $r[1] ) . '" placeholder="Email subject" style="width:100%;max-width:760px"></p>';
			echo '<p><textarea name="t[' . (int) $i . '][message]" rows="5" placeholder="Email message" style="width:100%;max-width:760px">' . esc_textarea( $r[2] ) . '</textarea></p>';
			if ( ! $new ) {
				echo '<label><input type="checkbox" name="t[' . (int) $i . '][del]" value="1"> Delete this template</label>';
			}
			echo '</div>';
		}
		echo '<p><button class="button button-primary mx-btn">Save templates</button> <button name="reset" value="1" class="button mx-btn" onclick="return confirm(\'Replace all templates with the original ones?\')">Back to the original templates</button></p></form></div>';
	}
}
MRSH_Emtpl::init();
