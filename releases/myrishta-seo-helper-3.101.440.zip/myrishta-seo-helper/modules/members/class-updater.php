<?php
/**
 * Auto updater for this plugin and the MyRishta theme. No extra plugin is needed.
 *
 * The site reads a small manifest (update.json) from a web address, shows a normal WordPress update for the plugin and the
 * theme, and installs it by itself when "Install updates automatically" is on. Every zip is checked before it is installed:
 * the address must be on the allowed list, the SHA-256 must match, and the Ed25519 signature must match the public key
 * built into this plugin. A stolen link or a changed file therefore cannot install code on the site.
 * Before each install a zip copy of the old version is kept in wp-content/mrsh-updates so it can be restored with one button.
 *
 * Options: mrsh_upd (url, auto), mrsh_upd_state (last check), mrsh_upd_log (last events). Transient: mrsh_upd_man (manifest).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Updater {

	const OPT   = 'mrsh_upd';
	const STATE = 'mrsh_upd_state';
	const LOG   = 'mrsh_upd_log';
	const MAN   = 'mrsh_upd_man';
	const SEEN  = 'mrsh_upd_seen';
	const BAD   = 'mrsh_upd_bad';
	const LOCK  = 'mrsh_upd_lock';
	const PK    = 'EYiPeVjuIVfA9iB5nAJR/0lwPHDRNASDM2t0v4yDqWQ=';
	const THEME = 'myrishta';
	const SLUG  = 'myrishta-seo-helper';

	public static function o( $k = null ) {
		$o = array_merge( array( 'url' => 'https://raw.githubusercontent.com/myrishta/myrishta-updates/main/update.json', 'auto' => 1, 'keep' => 2, 'every' => 12, 'soak' => 6, 'window' => 'night', 'plugin_on' => 1, 'theme_on' => 1, 'rollback' => 1, 'mail' => 1, 'pause' => 0 ), (array) get_option( self::OPT, array() ) );
		return null === $k ? $o : ( $o[ $k ] ?? null );
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 32 );
		foreach ( array( 'save', 'check', 'install', 'restore', 'pause' ) as $a ) {
			add_action( 'admin_post_mrsh_upd_' . $a, array( __CLASS__, $a ) );
		}
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'inject_plugin' ) );
		add_filter( 'pre_set_site_transient_update_themes', array( __CLASS__, 'inject_theme' ) );
		add_filter( 'upgrader_pre_download', array( __CLASS__, 'verify' ), 10, 3 );
		add_filter( 'auto_update_plugin', array( __CLASS__, 'auto_plugin' ), 20, 2 );
		add_filter( 'auto_update_theme', array( __CLASS__, 'auto_theme' ), 20, 2 );
		add_filter( 'cron_schedules', array( __CLASS__, 'schedules' ) );
		add_action( 'mrsh_upd_tick', array( __CLASS__, 'tick' ) );
		add_action( 'mrsh_upd_pilot', array( __CLASS__, 'pilot' ) );
		add_action( 'upgrader_process_complete', array( __CLASS__, 'after' ), 99, 2 );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Auto updates', 'Auto updates', 'manage_options', 'mrsh-upd', array( __CLASS__, 'page' ) );
	}

	public static function schedules( $s ) {
		$s['mrsh_upd_every'] = array( 'interval' => max( 1, (int) self::o( 'every' ) ) * HOUR_IN_SECONDS, 'display' => 'My Rishta update check' );
		return $s;
	}

	public static function schedule() {
		$ev   = wp_get_scheduled_event( 'mrsh_upd_tick' );
		$want = max( 1, (int) self::o( 'every' ) ) * HOUR_IN_SECONDS;
		if ( $ev && ( 'mrsh_upd_every' !== $ev->schedule || (int) $ev->interval !== $want ) ) {
			wp_unschedule_hook( 'mrsh_upd_tick' );
			$ev = false;
		}
		if ( ! $ev ) {
			wp_schedule_event( time() + 300, 'mrsh_upd_every', 'mrsh_upd_tick' );
		}
		if ( ! wp_next_scheduled( 'mrsh_upd_pilot' ) ) {
			wp_schedule_event( time() + 900, 'hourly', 'mrsh_upd_pilot' );
		}
	}

	/* ---------------------------------------------------------------- helpers */
	private static function plugin_file() {
		return plugin_basename( MRSH_FILE );
	}

	private static function theme_version() {
		$t = wp_get_theme( self::THEME );
		return $t->exists() ? (string) $t->get( 'Version' ) : '';
	}

	private static function host_ok( $url ) {
		$p = wp_parse_url( (string) $url );
		if ( empty( $p['scheme'] ) || 'https' !== $p['scheme'] || empty( $p['host'] ) ) {
			return false;
		}
		$h = strtolower( $p['host'] );
		return in_array( $h, array( 'github.com', 'raw.githubusercontent.com', 'myrishta.pk', 'www.myrishta.pk' ), true ) || ( strlen( $h ) > 22 && '.githubusercontent.com' === substr( $h, -22 ) );
	}

	private static function log( $msg, $ok = true ) {
		$l   = (array) get_option( self::LOG, array() );
		$l[] = array( time(), $ok ? 1 : 0, $msg );
		update_option( self::LOG, array_slice( $l, -25 ), false );
	}

	private static function message( $kind, $ver, $sha ) {
		return 'myrishta-update|' . $kind . '|' . $ver . '|' . $sha;
	}

	/** Read the manifest. Returns array( plugin => array, theme => array ) or WP_Error. Cached for one hour. */
	public static function manifest( $force = false ) {
		if ( ! $force ) {
			$c = get_transient( self::MAN );
			if ( is_array( $c ) ) {
				return $c;
			}
		}
		$url = (string) self::o( 'url' );
		if ( ! self::host_ok( $url ) ) {
			return new WP_Error( 'mrsh_upd', 'The update address must start with https:// and be on GitHub or myrishta.pk.' );
		}
		$r = wp_remote_get( add_query_arg( 't', floor( time() / 300 ), $url ), array( 'timeout' => 15 ) );
		if ( is_wp_error( $r ) ) {
			return new WP_Error( 'mrsh_upd', 'Could not reach the update address: ' . $r->get_error_message() );
		}
		if ( 200 !== (int) wp_remote_retrieve_response_code( $r ) ) {
			return new WP_Error( 'mrsh_upd', 'The update address answered ' . (int) wp_remote_retrieve_response_code( $r ) . '. Check that the file update.json exists there.' );
		}
		$j = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( ! is_array( $j ) ) {
			return new WP_Error( 'mrsh_upd', 'The update file is not valid.' );
		}
		$out = array();
		foreach ( array( 'plugin', 'theme' ) as $k ) {
			$m = $j[ $k ] ?? null;
			if ( ! is_array( $m ) || empty( $m['version'] ) || empty( $m['zip'] ) || empty( $m['sha256'] ) || empty( $m['sig'] ) ) {
				continue;
			}
			if ( ! preg_match( '/^\d+(\.\d+){1,3}$/', (string) $m['version'] ) || ! preg_match( '/^[a-f0-9]{64}$/', (string) $m['sha256'] ) || ! self::host_ok( $m['zip'] ) ) {
				continue;
			}
			$out[ $k ] = array( 'version' => (string) $m['version'], 'zip' => (string) $m['zip'], 'sha256' => (string) $m['sha256'], 'sig' => (string) $m['sig'], 'notes' => isset( $m['notes'] ) ? sanitize_text_field( (string) $m['notes'] ) : '' );
		}
		set_transient( self::MAN, $out, HOUR_IN_SECONDS );
		return $out;
	}

	/** Which updates are waiting. Returns array( plugin => array|null, theme => array|null ). */
	public static function pending( $force = false ) {
		$m = self::manifest( $force );
		if ( is_wp_error( $m ) ) {
			return $m;
		}
		$r = array( 'plugin' => null, 'theme' => null );
		if ( isset( $m['plugin'] ) && version_compare( $m['plugin']['version'], MRSH_VERSION, '>' ) ) {
			$r['plugin'] = $m['plugin'];
		}
		if ( isset( $m['theme'] ) && self::theme_version() && version_compare( $m['theme']['version'], self::theme_version(), '>' ) ) {
			$r['theme'] = $m['theme'];
		}
		return $r;
	}

	/* ---------------------------------------------------------------- WordPress update hooks */
	public static function inject_plugin( $t ) {
		if ( ! is_object( $t ) ) {
			return $t;
		}
		$p = self::pending();
		if ( is_wp_error( $p ) || empty( $p['plugin'] ) ) {
			return $t;
		}
		$f = self::plugin_file();
		$t->response[ $f ] = (object) array(
			'id'          => 'mrsh-updater/' . self::SLUG,
			'slug'        => self::SLUG,
			'plugin'      => $f,
			'new_version' => $p['plugin']['version'],
			'url'         => home_url( '/' ),
			'package'     => $p['plugin']['zip'],
		);
		unset( $t->no_update[ $f ] );
		return $t;
	}

	public static function inject_theme( $t ) {
		if ( ! is_object( $t ) ) {
			return $t;
		}
		$p = self::pending();
		if ( is_wp_error( $p ) || empty( $p['theme'] ) ) {
			return $t;
		}
		$t->response[ self::THEME ] = array( 'theme' => self::THEME, 'new_version' => $p['theme']['version'], 'url' => home_url( '/' ), 'package' => $p['theme']['zip'] );
		unset( $t->no_update[ self::THEME ] );
		return $t;
	}

	public static function auto_plugin( $update, $item ) {
		if ( is_object( $item ) && isset( $item->plugin ) && self::plugin_file() === $item->plugin ) {
			return false; // Autopilot installs these itself, with safety checks.
		}
		return $update;
	}

	public static function auto_theme( $update, $item ) {
		if ( is_object( $item ) && isset( $item->theme ) && self::THEME === $item->theme ) {
			return false; // Autopilot installs these itself, with safety checks.
		}
		return $update;
	}

	/** Every zip that comes from our manifest is downloaded here and checked. Anything that does not pass is refused. */
	public static function verify( $reply, $package, $upgrader = null ) {
		if ( false !== $reply ) {
			return $reply;
		}
		$m = get_transient( self::MAN );
		if ( ! is_array( $m ) ) {
			return $reply;
		}
		$kind = '';
		foreach ( array( 'plugin', 'theme' ) as $k ) {
			if ( isset( $m[ $k ] ) && $m[ $k ]['zip'] === $package ) {
				$kind = $k;
			}
		}
		if ( ! $kind ) {
			return $reply;
		}
		$e = $m[ $kind ];
		if ( ! function_exists( 'download_url' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$tmp = download_url( $package, 300 );
		if ( is_wp_error( $tmp ) ) {
			self::log( 'Download failed: ' . $tmp->get_error_message(), false );
			return $tmp;
		}
		$fail = function ( $why ) use ( $tmp, $kind ) {
			wp_delete_file( $tmp );
			self::log( 'Refused the ' . $kind . ' update: ' . $why, false );
			return new WP_Error( 'mrsh_upd_bad', 'The ' . $kind . ' update was refused: ' . $why );
		};
		if ( ! hash_equals( $e['sha256'], (string) hash_file( 'sha256', $tmp ) ) ) {
			return $fail( 'the file does not match its checksum.' );
		}
		$sig = base64_decode( $e['sig'], true ); // phpcs:ignore
		$pk  = base64_decode( self::PK, true ); // phpcs:ignore
		if ( ! $sig || ! $pk || ! function_exists( 'sodium_crypto_sign_verify_detached' ) || ! sodium_crypto_sign_verify_detached( $sig, self::message( $kind, $e['version'], $e['sha256'] ), $pk ) ) {
			return $fail( 'the signature is not valid.' );
		}
		$top = 'plugin' === $kind ? self::SLUG . '/' : self::THEME . '/';
		if ( ! class_exists( 'ZipArchive' ) ) {
			return $fail( 'the server cannot read zip files.' );
		}
		$z = new ZipArchive();
		if ( true !== $z->open( $tmp ) || $z->numFiles < 3 ) {
			return $fail( 'the zip cannot be opened.' );
		}
		for ( $i = 0; $i < $z->numFiles; $i++ ) {
			$n = (string) $z->getNameIndex( $i );
			if ( 0 !== strpos( $n, $top ) || false !== strpos( $n, '..' ) ) {
				$z->close();
				return $fail( 'the zip has the wrong folder layout.' );
			}
		}
		$z->close();
		self::log( 'Checked the ' . $kind . ' zip ' . $e['version'] . ': checksum and signature are correct.' );
		return $tmp;
	}

	/* ---------------------------------------------------------------- checking and installing */
	public static function tick() {
		$p = self::pending( true );
		self::remember( $p );
		if ( is_wp_error( $p ) ) {
			return;
		}
		if ( ( ! empty( $p['plugin'] ) || ! empty( $p['theme'] ) ) && function_exists( 'wp_update_plugins' ) ) {
			wp_update_plugins();
			wp_update_themes();
		}
		self::autopilot( $p );
	}

	/** Hourly: no new download, it only decides whether a waiting update is now allowed to install (safety delay, quiet hours). */
	public static function pilot() {
		if ( empty( self::o( 'auto' ) ) ) {
			return;
		}
		$p = self::pending( false );
		if ( ! is_wp_error( $p ) ) {
			self::autopilot( $p );
		}
	}

	private static function autopilot( $p ) {
		$go = array( 'plugin' => null, 'theme' => null );
		foreach ( array( 'theme', 'plugin' ) as $k ) {
			if ( ! empty( $p[ $k ] ) ) {
				self::seen( $k, $p[ $k ]['version'] );
				$why = '';
				if ( self::due( $k, $p[ $k ], $why ) ) {
					$go[ $k ] = $p[ $k ];
				}
			}
		}
		if ( $go['plugin'] || $go['theme'] ) {
			self::run( $go, true );
		}
	}

	/** When an update was first noticed (used for the safety delay). */
	private static function seen( $k, $v ) {
		$s   = (array) get_option( self::SEEN, array() );
		$key = $k . '-' . $v;
		if ( empty( $s[ $key ] ) ) {
			$s[ $key ] = time();
			update_option( self::SEEN, array_slice( $s, -10, null, true ), false );
		}
		return (int) $s[ $key ];
	}

	/** May autopilot install this update right now? $why says what it is waiting for. */
	public static function due( $k, $item, &$why = '' ) {
		$o = self::o();
		if ( empty( $o['auto'] ) ) {
			$why = 'Autopilot is off, so it waits for you to press Install now.';
			return false;
		}
		if ( empty( $o[ $k . '_on' ] ) ) {
			$why = ucfirst( $k ) . ' autopilot is switched off.';
			return false;
		}
		if ( (int) $o['pause'] > time() ) {
			$why = 'Autopilot is paused until ' . wp_date( 'j M, g:i a', (int) $o['pause'] ) . '.';
			return false;
		}
		if ( in_array( $k . '-' . $item['version'], (array) get_option( self::BAD, array() ), true ) ) {
			$why = 'This version failed on this site before, so autopilot skips it. Install now tries it again.';
			return false;
		}
		$at = self::seen( $k, $item['version'] ) + (int) $o['soak'] * HOUR_IN_SECONDS;
		if ( time() < $at ) {
			$why = 'Safety delay: it installs after ' . wp_date( 'j M, g:i a', $at ) . '.';
			return false;
		}
		if ( 'night' === $o['window'] ) {
			$h = (int) wp_date( 'G' );
			if ( $h < 1 || $h >= 5 ) {
				$why = 'Waiting for the quiet hours (1 am to 5 am).';
				return false;
			}
		}
		if ( class_exists( 'MRSH_Maint' ) && MRSH_Maint::active() ) {
			$why = 'Maintenance mode is on.';
			return false;
		}
		$free = function_exists( 'disk_free_space' ) ? @disk_free_space( WP_CONTENT_DIR ) : false; // phpcs:ignore
		if ( false !== $free && $free < 300 * MB_IN_BYTES ) {
			$why = 'Not enough free disk space (needs 300 MB).';
			return false;
		}
		if ( get_transient( self::LOCK ) ) {
			$why = 'Another update is running.';
			return false;
		}
		return true;
	}

	private static function remember( $p ) {
		$s = array( 'time' => time(), 'ok' => ! is_wp_error( $p ), 'msg' => is_wp_error( $p ) ? $p->get_error_message() : '', 'plugin' => is_wp_error( $p ) || empty( $p['plugin'] ) ? '' : $p['plugin']['version'], 'theme' => is_wp_error( $p ) || empty( $p['theme'] ) ? '' : $p['theme']['version'] );
		update_option( self::STATE, $s, false );
		if ( is_wp_error( $p ) ) {
			self::log( 'Check failed: ' . $p->get_error_message(), false );
		}
	}

	private static function guard( $n ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( $n );
	}

	private static function back( $m ) {
		wp_safe_redirect( add_query_arg( 'msg', rawurlencode( $m ), admin_url( 'admin.php?page=mrsh-upd' ) ) );
		exit;
	}

	public static function save() {
		self::guard( 'mrsh_upd_save' );
		$o        = self::o();
		$u        = isset( $_POST['url'] ) ? esc_url_raw( trim( wp_unslash( $_POST['url'] ) ) ) : ''; // phpcs:ignore
		$o['url'] = self::host_ok( $u ) ? $u : $o['url'];
		$o['auto'] = empty( $_POST['auto'] ) ? 0 : 1; // phpcs:ignore
		$o['keep'] = isset( $_POST['keep'] ) ? max( 0, min( 5, (int) $_POST['keep'] ) ) : 2; // phpcs:ignore
		$ev = isset( $_POST['every'] ) ? (int) $_POST['every'] : 12; // phpcs:ignore
		$o['every'] = in_array( $ev, array( 1, 2, 6, 12, 24 ), true ) ? $ev : 12;
		$sk = isset( $_POST['soak'] ) ? (int) $_POST['soak'] : 6; // phpcs:ignore
		$o['soak'] = in_array( $sk, array( 0, 6, 24, 72 ), true ) ? $sk : 6;
		$o['window'] = ( isset( $_POST['window'] ) && 'any' === $_POST['window'] ) ? 'any' : 'night'; // phpcs:ignore
		foreach ( array( 'plugin_on', 'theme_on', 'rollback', 'mail' ) as $f ) {
			$o[ $f ] = empty( $_POST[ $f ] ) ? 0 : 1; // phpcs:ignore
		}
		self::prune( 'plugin', $o['keep'] );
		self::prune( 'theme', $o['keep'] );
		update_option( self::OPT, $o, false );
		self::schedule();
		delete_transient( self::MAN );
		self::back( self::host_ok( $u ) ? 'Saved.' : 'Saved. The address was not allowed, so the old address was kept (it must start with https:// and be on GitHub or myrishta.pk).' );
	}

	public static function check() {
		self::guard( 'mrsh_upd_check' );
		$p = self::pending( true );
		self::remember( $p );
		if ( is_wp_error( $p ) ) {
			self::back( $p->get_error_message() );
		}
		if ( function_exists( 'wp_update_plugins' ) ) {
			wp_update_plugins();
			wp_update_themes();
		}
		self::back( ( $p['plugin'] || $p['theme'] ) ? 'An update is ready. Press Install now.' : 'You are on the newest version.' );
	}

	/** Zip copy of the folder that is about to be replaced. Keeps the newest two per kind. */
	/** Keep only the newest $keep backup zips of one kind and delete the rest (0 = delete them all). */
	private static function prune( $kind, $keep ) {
		$all = glob( WP_CONTENT_DIR . '/mrsh-updates/' . $kind . '-*.zip' );
		if ( ! $all || count( $all ) <= $keep ) {
			return;
		}
		usort( $all, function ( $a, $b ) { return filemtime( $a ) - filemtime( $b ); } );
		foreach ( array_slice( $all, 0, count( $all ) - $keep ) as $old ) {
			wp_delete_file( $old );
		}
	}

	/** After a finished update of this plugin or theme: apply the "old versions to keep" setting. */
	public static function after( $upgrader, $info ) {
		if ( empty( $info['type'] ) || empty( $info['action'] ) || 'update' !== $info['action'] ) {
			return;
		}
		$keep = (int) self::o( 'keep' );
		if ( 'plugin' === $info['type'] && ! empty( $info['plugins'] ) && in_array( self::SLUG . '/' . self::SLUG . '.php', (array) $info['plugins'], true ) ) {
			self::prune( 'plugin', $keep );
		} elseif ( 'theme' === $info['type'] && ! empty( $info['themes'] ) && in_array( self::THEME, (array) $info['themes'], true ) ) {
			self::prune( 'theme', $keep );
		}
	}

	private static function backup( $kind ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return false;
		}
		$src = 'plugin' === $kind ? WP_PLUGIN_DIR . '/' . self::SLUG : get_theme_root() . '/' . self::THEME;
		if ( ! is_dir( $src ) ) {
			return false;
		}
		$dir = WP_CONTENT_DIR . '/mrsh-updates';
		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
			file_put_contents( $dir . '/.htaccess', "Require all denied\nDeny from all\n" ); // phpcs:ignore
			file_put_contents( $dir . '/index.php', "<?php\n// Silence.\n" ); // phpcs:ignore
		}
		$ver  = 'plugin' === $kind ? MRSH_VERSION : self::theme_version();
		$file = $dir . '/' . $kind . '-' . $ver . '-' . time() . '.zip';
		$z    = new ZipArchive();
		if ( true !== $z->open( $file, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
			return false;
		}
		$top = basename( $src );
		$it  = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $src, FilesystemIterator::SKIP_DOTS ) );
		foreach ( $it as $f ) {
			if ( $f->isFile() ) {
				$z->addFile( $f->getPathname(), $top . '/' . substr( $f->getPathname(), strlen( $src ) + 1 ) );
			}
		}
		$z->close();
		self::prune( $kind, max( 1, (int) self::o( 'keep' ) ) ); // the copy just made always stays until the install has finished
		return $file;
	}

	public static function install() {
		self::guard( 'mrsh_upd_install' );
		require_once ABSPATH . 'wp-admin/includes/file.php';
		$p = self::pending( true );
		self::remember( $p );
		if ( is_wp_error( $p ) ) {
			self::back( $p->get_error_message() );
		}
		if ( empty( $p['plugin'] ) && empty( $p['theme'] ) ) {
			self::back( 'You are already on the newest version.' );
		}
		self::back( implode( ' ', self::run( $p, false ) ) );
	}

	public static function pause() {
		self::guard( 'mrsh_upd_pause' );
		$o          = self::o();
		$o['pause'] = isset( $_POST['resume'] ) ? 0 : time() + 7 * DAY_IN_SECONDS; // phpcs:ignore
		update_option( self::OPT, $o, false );
		self::log( $o['pause'] ? 'Autopilot paused for 7 days.' : 'Autopilot resumed.' );
		self::back( $o['pause'] ? 'Autopilot is paused for 7 days.' : 'Autopilot is running again.' );
	}

	/** Install the waiting updates one by one: back up, install, health-check, and put the old version back if the site breaks. */
	public static function run( $go, $auto = false ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		require_once ABSPATH . 'wp-admin/includes/misc.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		require_once ABSPATH . 'wp-admin/includes/update.php';
		if ( get_transient( self::LOCK ) ) {
			return array( 'Another update is running. Try again in a few minutes.' );
		}
		set_transient( self::LOCK, 1, 15 * MINUTE_IN_SECONDS );
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 300 ); // phpcs:ignore
		}
		// WordPress only rebuilds its update list every 12 hours. Clear it so our entries are added right now.
		delete_site_transient( 'update_plugins' );
		delete_site_transient( 'update_themes' );
		wp_update_plugins();
		wp_update_themes();
		$o   = self::o();
		$out = array();
		foreach ( array( 'theme', 'plugin' ) as $k ) {
			if ( empty( $go[ $k ] ) ) {
				continue;
			}
			$ver  = $go[ $k ]['version'];
			$name = ucfirst( $k ) . ' ' . $ver;
			$file = self::backup( $k );
			if ( 'plugin' === $k ) {
				$f   = self::plugin_file();
				$was = is_plugin_active( $f );
				$up  = new Plugin_Upgrader( new Automatic_Upgrader_Skin() );
				$r   = $up->upgrade( $f );
				if ( $was && ! is_plugin_active( $f ) ) {
					activate_plugin( $f, '', false, true );
				}
			} else {
				$up = new Theme_Upgrader( new Automatic_Upgrader_Skin() );
				$r  = $up->upgrade( self::THEME );
			}
			if ( ! ( true === $r || ( is_array( $r ) && ! is_wp_error( $r ) ) ) ) {
				$why = '';
				if ( is_wp_error( $r ) ) {
					$why = $r->get_error_message();
				} elseif ( isset( $up->skin ) ) {
					$er = $up->skin->get_errors();
					$why = is_wp_error( $er ) && $er->has_errors() ? $er->get_error_message() : trim( implode( ' ', array_map( 'wp_strip_all_tags', (array) $up->skin->get_upgrade_messages() ) ) );
				}
				$m = $name . ' did not install' . ( '' !== $why ? ': ' . $why : ' (WordPress gave no reason).' ) . ' The old version is still in place.';
				$out[] = $m;
				self::log( $m, false );
				self::mark_bad( $k, $ver );
				self::tell( 'Update failed', $m );
				continue;
			}
			$h = self::healthy();
			if ( false === $h && ! empty( $o['rollback'] ) && $file ) {
				$res = self::do_restore( basename( $file ) );
				self::mark_bad( $k, $ver );
				$m = $name . ' broke the site, so the old version was put back' . ( true === $res ? '.' : ' - but the put-back failed: ' . $res );
				$out[] = $m;
				self::log( $m, false );
				self::tell( 'Update rolled back', $m );
				continue;
			}
			$m = $name . ' installed' . ( null === $h ? ' (the site check could not run).' : ( false === $h ? ' - the site check failed and rollback is off.' : ' and the site checked fine.' ) );
			$out[] = $m;
			self::log( $m, false !== $h );
			if ( $auto ) {
				self::tell( 'Updated by autopilot', $m );
			}
		}
		delete_transient( self::LOCK );
		delete_transient( self::MAN );
		return $out;
	}

	/** true = site answers normally, false = fatal error or HTTP 500, null = could not test. */
	private static function healthy() {
		$any = false;
		foreach ( array( home_url( '/?mrsh_hc=' . time() ), wp_login_url() ) as $u ) {
			$r = wp_remote_get( $u, array( 'timeout' => 25, 'redirection' => 3, 'headers' => array( 'Cache-Control' => 'no-cache' ) ) );
			if ( is_wp_error( $r ) ) {
				continue;
			}
			$any = true;
			if ( 500 === (int) wp_remote_retrieve_response_code( $r ) || preg_match( '/There has been a critical error|Fatal error:|Parse error:/i', (string) wp_remote_retrieve_body( $r ) ) ) {
				return false;
			}
		}
		return $any ? true : null;
	}

	private static function mark_bad( $k, $ver ) {
		$b   = (array) get_option( self::BAD, array() );
		$b[] = $k . '-' . $ver;
		update_option( self::BAD, array_slice( array_unique( $b ), -10 ), false );
	}

	private static function tell( $subject, $body ) {
		if ( ! empty( self::o( 'mail' ) ) ) {
			wp_mail( get_option( 'admin_email' ), '[My Rishta] ' . $subject, $body . "\n\n" . admin_url( 'admin.php?page=mrsh-upd' ) );
		}
	}

	public static function restore() {
		self::guard( 'mrsh_upd_restore' );
		$name = isset( $_POST['file'] ) ? basename( sanitize_text_field( wp_unslash( $_POST['file'] ) ) ) : ''; // phpcs:ignore
		$r    = self::do_restore( $name );
		self::back( true === $r ? 'Restored ' . $name . '. Reload the page to see the older version.' : $r );
	}

	/** Put a saved zip back. Returns true or a plain-language error. */
	private static function do_restore( $name ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		$zip = WP_CONTENT_DIR . '/mrsh-updates/' . $name;
		if ( ! preg_match( '/^(plugin|theme)-[\d.]+-\d+\.zip$/', $name ) || ! is_file( $zip ) ) {
			return 'That saved copy was not found.';
		}
		$kind = 0 === strpos( $name, 'plugin' ) ? 'plugin' : 'theme';
		$dir  = 'plugin' === $kind ? WP_PLUGIN_DIR . '/' . self::SLUG : get_theme_root() . '/' . self::THEME;
		$hold = WP_CONTENT_DIR . '/mrsh-updates/replaced-' . $kind . '-' . time();
		if ( ! @rename( $dir, $hold ) ) { // phpcs:ignore
			return 'Could not move the current ' . $kind . ' folder, so nothing was changed.';
		}
		WP_Filesystem();
		global $wp_filesystem;
		$r = unzip_file( $zip, dirname( $dir ) );
		if ( is_wp_error( $r ) || ! is_dir( $dir ) ) {
			if ( is_dir( $dir ) ) {
				$wp_filesystem->delete( $dir, true );
			}
			@rename( $hold, $dir ); // phpcs:ignore
			self::log( 'Restore of ' . $name . ' failed; the current version was put back.', false );
			return 'The restore failed, and the current version was put back.';
		}
		$wp_filesystem->delete( $hold, true );
		self::log( 'Restored ' . $name . '.' );
		return true;
	}

	/* ---------------------------------------------------------------- page */
	public static function page() {
		if ( ! current_user_can( 'manage_options' ) || ! class_exists( 'MRSH_Boost' ) ) {
			return;
		}
		$o  = self::o();
		$s  = (array) get_option( self::STATE, array() );
		$tv = self::theme_version();
		MRSH_Boost::ui_open( 'Auto updates', 'Updates for this plugin and the theme install by themselves from a safe link. Every file is checked before it is installed, and the old version is kept so you can go back.', 'g-blue', 'M12 3v12m0 0l-4-4m4 4l4-4M5 21h14' );
		if ( ! empty( $_GET['msg'] ) ) { // phpcs:ignore
			MRSH_Boost::ui_ok( sanitize_text_field( rawurldecode( wp_unslash( $_GET['msg'] ) ) ) ); // phpcs:ignore
		}
		$pn = ! empty( $s['plugin'] ) ? $s['plugin'] : '';
		$tn = ! empty( $s['theme'] ) ? $s['theme'] : '';
		echo '<div class="mx-stats">';
		echo MRSH_Boost::ui_stat( MRSH_VERSION, 'Plugin installed', $pn ? '#e11d74' : '#10b981' ); // phpcs:ignore
		echo MRSH_Boost::ui_stat( $tv ? $tv : '-', 'Theme installed', $tn ? '#e11d74' : '#10b981' ); // phpcs:ignore
		echo MRSH_Boost::ui_stat( ( $pn || $tn ) ? 'Update ready' : 'Up to date', $pn ? 'Plugin ' . $pn : ( $tn ? 'Theme ' . $tn : 'Nothing waiting' ), ( $pn || $tn ) ? '#f59e0b' : '#10b981' ); // phpcs:ignore
		$paused = (int) $o['pause'] > time();
		echo MRSH_Boost::ui_stat( $paused ? 'Paused' : ( ! empty( $o['auto'] ) ? 'ON' : 'Off' ), 'Autopilot', $paused ? '#f59e0b' : ( ! empty( $o['auto'] ) ? '#10b981' : '#6b7280' ) ); // phpcs:ignore
		echo MRSH_Boost::ui_stat( ! empty( $s['time'] ) ? human_time_diff( (int) $s['time'] ) . ' ago' : 'never', 'Last check', '#4a69d6' ); // phpcs:ignore
		echo '</div>';
		if ( ! empty( $s['time'] ) && empty( $s['ok'] ) && ! empty( $s['msg'] ) ) {
			echo '<div class="mx-card" style="border-left:4px solid #e11d74"><p style="margin:0"><strong>The last check did not work.</strong> ' . esc_html( $s['msg'] ) . '</p></div>';
		}
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">1</span><h2>Check and install</h2></div><p class="mx-sub">The site checks every ' . (int) $o['every'] . ' hours. You can also check now and install with one press. The page tells you if an update is waiting.</p><div style="display:flex;gap:10px;flex-wrap:wrap">';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_upd_check">' . wp_nonce_field( 'mrsh_upd_check', '_wpnonce', true, false ) . '<button class="mx-btn">Check now</button></form>'; // phpcs:ignore
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_upd_install">' . wp_nonce_field( 'mrsh_upd_install', '_wpnonce', true, false ) . '<button class="mx-btn p"' . ( ( $pn || $tn ) ? '' : ' disabled' ) . '>Install now</button></form>'; // phpcs:ignore
		echo '</div>';
		foreach ( array( 'theme' => $tn, 'plugin' => $pn ) as $k => $vv ) {
			$pi = self::pending( false );
			if ( $vv && ! is_wp_error( $pi ) && ! empty( $pi[ $k ] ) ) {
				$why = '';
				echo '<p class="mx-sub" style="margin:10px 0 0"><b>' . esc_html( ucfirst( $k ) . ' ' . $vv ) . ':</b> ' . esc_html( self::due( $k, $pi[ $k ], $why ) ? 'autopilot installs it at its next hourly run.' : $why ) . '</p>'; // phpcs:ignore
			}
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin-top:12px"><input type="hidden" name="action" value="mrsh_upd_pause">' . wp_nonce_field( 'mrsh_upd_pause', '_wpnonce', true, false ) . ( $paused ? '<input type="hidden" name="resume" value="1"><button class="mx-btn">Resume autopilot</button>' : '<button class="mx-btn">Pause autopilot for 7 days</button>' ) . '</form>'; // phpcs:ignore
		echo '</div>';
		$sel = function ( $name, $cur, $opts ) {
			$h = '<select name="' . esc_attr( $name ) . '" style="min-width:260px">';
			foreach ( $opts as $v => $lb ) {
				$h .= '<option value="' . esc_attr( $v ) . '"' . selected( (string) $cur, (string) $v, false ) . '>' . esc_html( $lb ) . '</option>';
			}
			return $h . '</select>';
		};
		$sw = function ( $name, $on, $label, $hint = '' ) {
			return '<div class="mx-f" style="margin-top:12px"><label class="mx-sw"><input type="checkbox" name="' . esc_attr( $name ) . '" value="1"' . checked( ! empty( $on ), true, false ) . '><span class="tr"></span><span class="lb">' . esc_html( $label ) . '</span></label>' . ( $hint ? '<p class="mx-sub" style="margin:4px 0 0 52px">' . esc_html( $hint ) . '</p>' : '' ) . '</div>';
		};
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_upd_save">' . wp_nonce_field( 'mrsh_upd_save', '_wpnonce', true, false ); // phpcs:ignore
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">2</span><h2>Autopilot (careful install)</h2></div><p class="mx-sub">Autopilot installs a new version only when it is safe: after a delay, in quiet hours, never in maintenance mode, with a copy saved first, and a check of the site afterwards. If the site breaks it puts the old version back by itself and emails you.</p>';
		echo $sw( 'auto', $o['auto'], 'Autopilot ON - install updates by itself' ); // phpcs:ignore
		echo $sw( 'plugin_on', $o['plugin_on'], 'Include the plugin (MyRishta Admin)' ); // phpcs:ignore
		echo $sw( 'theme_on', $o['theme_on'], 'Include the theme' ); // phpcs:ignore
		echo '<div class="mx-f" style="margin-top:14px"><label class="t">Safety delay</label><br>' . $sel( 'soak', $o['soak'], array( 0 => 'Install as soon as it is allowed', 6 => 'Wait 6 hours after it appears', 24 => 'Wait 1 day after it appears', 72 => 'Wait 3 days after it appears' ) ) . '<p class="mx-sub" style="margin:6px 0 0">A short wait lets a bad release be pulled before your site gets it.</p></div>'; // phpcs:ignore
		echo '<div class="mx-f" style="margin-top:14px"><label class="t">When may it install?</label><br>' . $sel( 'window', $o['window'], array( 'night' => 'Quiet hours only (1 am to 5 am, site time)', 'any' => 'Any time' ) ) . '</div>'; // phpcs:ignore
		echo $sw( 'rollback', $o['rollback'], 'Put the old version back if the site breaks', 'After each install the site front page and login page are loaded. A fatal error or HTTP 500 triggers the automatic put-back.' ); // phpcs:ignore
		echo $sw( 'mail', $o['mail'], 'Email me when it installs, fails or rolls back', 'Sent to the site admin address: ' . get_option( 'admin_email' ) ); // phpcs:ignore
		echo '</div>';
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">3</span><h2>Checking and old versions</h2></div>';
		echo '<div class="mx-f"><label class="t">Look for new versions</label><br>' . $sel( 'every', $o['every'], array( 1 => 'Every hour', 2 => 'Every 2 hours', 6 => 'Every 6 hours', 12 => 'Every 12 hours (default)', 24 => 'Once a day' ) ) . '</div>'; // phpcs:ignore
		echo '<div class="mx-f" style="margin-top:14px"><label class="t">Old versions to keep after an update</label><br>' . $sel( 'keep', $o['keep'], array( 0 => 'None - delete the old version once the update is done', 1 => 'Keep 1 (the version just replaced)', 2 => 'Keep 2', 3 => 'Keep 3' ) ) . '<p class="mx-sub" style="margin:6px 0 0">Older zips are deleted automatically when a new update arrives. With None there is no Restore button.</p></div>'; // phpcs:ignore
		echo '<div class="mx-f" style="margin-top:14px"><label class="t" for="uu">Update address (update.json)</label><input type="url" id="uu" name="url" value="' . esc_attr( $o['url'] ) . '" style="width:100%"><p class="mx-sub" style="margin:6px 0 0">Only https addresses on GitHub or myrishta.pk are accepted. Files must carry the MyRishta signature, otherwise they are refused.</p></div>';
		echo '<p style="margin:16px 0 0"><button class="mx-btn p">Save</button></p></div></form>';
		$files = glob( WP_CONTENT_DIR . '/mrsh-updates/*.zip' );
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">4</span><h2>Go back to an older version</h2></div>';
		if ( $files ) {
			usort( $files, function ( $a, $b ) { return filemtime( $b ) - filemtime( $a ); } );
			echo '<p class="mx-sub">A copy of the old version is saved before every update (the newest two are kept).</p>';
			foreach ( $files as $f ) {
				$n = basename( $f );
				echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:flex;align-items:center;gap:12px;margin:6px 0;flex-wrap:wrap"><input type="hidden" name="action" value="mrsh_upd_restore"><input type="hidden" name="file" value="' . esc_attr( $n ) . '">' . wp_nonce_field( 'mrsh_upd_restore', '_wpnonce', true, false ) . '<span>' . esc_html( $n ) . ' <small style="color:#6b7280">(' . esc_html( size_format( filesize( $f ) ) ) . ', ' . esc_html( wp_date( 'j M, g:i a', filemtime( $f ) ) ) . ')</small></span><button class="mx-btn">Restore this</button></form>'; // phpcs:ignore
			}
		} else {
			echo '<p class="mx-sub">No saved copy yet. One is made automatically before the first update.</p>';
		}
		echo '</div>';
		$log = array_reverse( (array) get_option( self::LOG, array() ) );
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">5</span><h2>What happened</h2></div>';
		if ( $log ) {
			foreach ( array_slice( $log, 0, 12 ) as $l ) {
				echo '<p style="margin:5px 0"><span style="color:#6b7280">' . esc_html( wp_date( 'j M, g:i a', (int) $l[0] ) ) . '</span> &nbsp;' . ( $l[1] ? '&#9989;' : '&#10060;' ) . ' ' . esc_html( $l[2] ) . '</p>';
			}
		} else {
			echo '<p class="mx-sub">Nothing yet.</p>';
		}
		echo '</div></div>';
	}
}
MRSH_Updater::init();
