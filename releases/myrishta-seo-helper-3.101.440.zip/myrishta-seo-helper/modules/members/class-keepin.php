<?php
/**
 * Stay signed in. A member who signed in on a phone or computer stays signed in for 30 days from the last visit,
 * even when the browser or the page is closed. A new device still needs the password (and the new-device email still goes out).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_KeepIn {

	const DAYS = 30;

	public static function init() {
		add_filter( 'auth_cookie_expiration', array( __CLASS__, 'expiry' ), 99, 3 );
		add_action( 'login_init', array( __CLASS__, 'force_remember' ), 1 );
		add_action( 'init', array( __CLASS__, 'renew' ), 20 );
	}

	public static function days() {
		return max( 1, (int) apply_filters( 'mrsh_keepin_days', self::DAYS ) );
	}

	/** Every sign-in cookie lasts 30 days (WordPress default is 14 days with "remember me" and only until the browser closes without it). */
	public static function expiry( $seconds, $user_id, $remember ) {
		return self::days() * DAY_IN_SECONDS;
	}

	/** The login form acts as if "Remember me" was ticked, so the cookie survives closing the browser. */
	public static function force_remember() {
		if ( 'POST' === ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' ) ) { // phpcs:ignore
			$_POST['rememberme'] = 'forever'; // phpcs:ignore WordPress.Security.NonceVerification
		}
	}

	/** Once a day, on a normal page visit, push the end date forward: 30 days from the last visit. */
	public static function renew() {
		if ( ! is_user_logged_in() || headers_sent() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || defined( 'XMLRPC_REQUEST' ) ) {
			return;
		}
		if ( isset( $_COOKIE['mrsh_hp_back'] ) ) {
			return; // an agency "open as family" session stays short
		}
		$uid  = get_current_user_id();
		$last = (int) get_user_meta( $uid, 'mrsh_keepin', true );
		if ( $last && ( time() - $last ) < DAY_IN_SECONDS ) {
			return;
		}
		update_user_meta( $uid, 'mrsh_keepin', time() );
		wp_set_auth_cookie( $uid, true, is_ssl(), wp_get_session_token() );
	}
}
MRSH_KeepIn::init();
