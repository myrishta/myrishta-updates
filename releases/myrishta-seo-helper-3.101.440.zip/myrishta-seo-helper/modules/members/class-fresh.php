<?php
/**
 * New installation: a checklist and one button that prepares a brand new WordPress site (no old theme data needed),
 * plus an import for the settings file that Quality and safety exports. Never overwrites profile fields that already exist.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Fresh {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 28 );
		add_action( 'admin_init', array( __CLASS__, 'auto' ), 99 );
		add_action( 'admin_post_mrsh_fresh_run', array( __CLASS__, 'run' ) );
		add_action( 'admin_post_mrsh_fresh_import', array( __CLASS__, 'import' ) );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'New installation', 'New installation', 'manage_options', 'mrsh-fresh', array( __CLASS__, 'page' ) );
	}

	/** The default profile form, in the same shape as the old theme's "cfields" option. */
	public static function default_fields() {
		$rows = array(
			array( 'Profile Created by', 'custom-13', 'select', 'dagender', "Self\r\nParents\r\nSibling\r\nRelative\r\nFriend\r\nGuardian", 'yes', 'no' ),
			array( 'Gender', 'key4', 'taxonomy', 'dagender', '', 'no', 'no' ),
			array( 'Age', 'daage', 'taxonomy', 'dagender', '', 'yes', 'no' ),
			array( 'Phone No', 'custom-14', 'input', 'dagender', '', 'yes', 'yes' ),
			array( 'Marital Status', 'custom-15', 'select', 'dagender', "Prefer to not Say\r\nDivorced\r\nMarried\r\nSeparated\r\nUnmarried\r\nWidowed", 'yes', 'no' ),
			array( 'Children', 'custom-16', 'select', 'dagender', "Prefer to not say\r\nNone\r\n1\r\n2\r\n3 or Above", 'no', 'no' ),
			array( 'Children Satus', 'custom-17', 'select', 'dagender', "Prefer to not say\r\nStaying with me\r\nStaying With Mother\r\nStaying With Father\r\nStaying Separate\r\nStaying With Grandparents", 'no', 'no' ),
			array( 'Religion', 'custom-18', 'select', 'dagender', "Muslims-Islam\r\nChristianity\r\nHinduism\r\nSikhism\r\nOthers", 'yes', 'no' ),
			array( 'Sect', 'custom-19', 'select', 'dagender', "Prefer to not Say\r\nSuni\r\nShia\r\nOther", 'yes', 'no' ),
			array( 'Caste', 'custom-20', 'select', 'dagender', "Others\r\nPrefer not to say", 'yes', 'no' ),
			array( 'Nationalty ', 'custom-21', 'select', 'country', "Pakistani\r\nBritish\r\nAmerican\r\nCanadian\r\nSaudi Arabian\r\nEmirati\r\nIndian\r\nBangladeshi\r\nOther", 'yes', 'no' ),
			array( 'Education and Occupation', 'custom-23', 'title', 'dagender', '', 'no', 'no' ),
			array( 'Education', 'custom-2322', 'select', 'dagender', "Matric (10)\r\nBachelor Degree\r\nMaster Degree\r\nOther", 'yes', 'no' ),
			array( 'Occupation', 'custom-24', 'select', 'dagender', "Prefer to not say\r\nGovernment Employee\r\nPrivate Sector Employee\r\nOther", 'yes', 'no' ),
			array( 'What do I look like?', 'key5', 'title', 'dagender', '', 'no', 'no' ),
			array( 'Ethnicity', 'key2', 'select', 'dathnicity', "Pakistani\r\nOther", 'no', 'no' ),
			array( 'My Eyes', 'key6', 'select', 'daeyes', "Black\r\nBrown\r\nGreen\r\nHazel\r\nOther", 'no', 'no' ),
			array( 'My Hair', 'key7', 'select', 'dahair', "Black\r\nBrown\r\nBlond\r\nGray\r\nOther", 'no', 'no' ),
			array( 'My Body', 'key8', 'select', 'dabody', "Slim\r\nAverage\r\nAthletic\r\nOther", 'no', 'no' ),
		);
		$cf = array( 'name' => array(), 'help' => array(), 'dbkey' => array(), 'cat' => array(), 'fieldtype' => array(), 'taxonomy' => array(), 'values' => array(), 'required' => array(), 'editonly' => array() );
		foreach ( $rows as $r ) {
			$cf['name'][]      = $r[0];
			$cf['help'][]      = '';
			$cf['dbkey'][]     = $r[1];
			$cf['cat'][]       = array( '0' );
			$cf['fieldtype'][] = $r[2];
			$cf['taxonomy'][]  = $r[3];
			$cf['values'][]    = $r[4];
			$cf['required'][]  = $r[5];
			$cf['editonly'][]  = $r[6];
		}
		return $cf;
	}

	private static function checks() {
		$c   = array();
		$cf  = get_option( 'cfields' );
		$cnt = wp_count_posts( 'listing_type' );
		$c[] = array( 'My Rishta theme is active', 'myrishta' === get_template(), 'Appearance > Themes > activate My Rishta.' );
		$c[] = array( 'Profile type is ready', post_type_exists( 'listing_type' ), 'Activate this plugin.' );
		$c[] = array( 'Profile form fields exist', is_array( $cf ) && ! empty( $cf['dbkey'] ), 'Press the button below.' );
		$c[] = array( 'Gender choices exist (Male, Female)', taxonomy_exists( 'dagender' ) && term_exists( 'Male', 'dagender' ) && term_exists( 'Female', 'dagender' ), 'Press the button below.' );
		$c[] = array( 'Countries and cities are loaded', taxonomy_exists( 'country' ) && (int) wp_count_terms( array( 'taxonomy' => 'country', 'hide_empty' => false ) ) > 20, 'Press the button below.' );
		foreach ( array( 'my-account' => 'My account', 'add-listing' => 'Add your profile', 'memberships' => 'Memberships', 'contact' => 'Contact', 'blog' => 'Blog' ) as $slug => $l ) {
			$c[] = array( 'Page: ' . $l, (bool) get_page_by_path( $slug ), 'Press the button below.' );
		}
		$c[] = array( 'Main menu is set', (bool) get_nav_menu_locations() && ! empty( get_nav_menu_locations()['primary'] ), 'Press the button below.' );
		$c[] = array( 'Nice web addresses (not ?p=123)', '' !== (string) get_option( 'permalink_structure' ), 'Press the button below.' );
		$c[] = array( 'Site uses https', is_ssl() || 0 === strpos( home_url(), 'https' ), 'Turn on the free SSL certificate at your host.' );
		$c[] = array( 'Admin e-mail is set', is_email( get_option( 'admin_email' ) ), 'Settings > General.' );
		$c[] = array( 'Profiles on the site: ' . ( (int) ( $cnt->publish ?? 0 ) ), (int) ( $cnt->publish ?? 0 ) > 0, 'Empty on a new site. Restore your backup or add a profile.' );
		return $c;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		echo '<div class="wrap"><h1>New installation</h1>';
		if ( isset( $_GET['done'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['done'] ) ) ) . '</p></div>'; // phpcs:ignore
		}
		echo '<p>Use this on a new WordPress site (new host or a clean install). It checks that everything the site needs is there and creates what is missing. It never changes profile fields that already exist and never deletes anything.</p>';
		echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:14px;padding:6px 18px;max-width:760px">';
		$bad = 0;
		foreach ( self::checks() as $r ) {
			if ( ! $r[1] ) {
				++$bad;
			}
			echo '<p style="display:flex;gap:10px;align-items:center;margin:10px 0;padding-bottom:8px;border-bottom:1px solid #f0f0f1"><span style="width:22px;height:22px;border-radius:50%;color:#fff;text-align:center;line-height:22px;background:' . ( $r[1] ? '#16a34a' : '#dc2626' ) . '">' . ( $r[1] ? '&#10003;' : '!' ) . '</span><b style="flex:1">' . esc_html( $r[0] ) . '</b>' . ( $r[1] ? '' : '<small style="color:#b45309">' . esc_html( $r[2] ) . '</small>' ) . '</p>';
		}
		echo '</div>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin:16px 0"><input type="hidden" name="action" value="mrsh_fresh_run">';
		wp_nonce_field( 'mrsh_fresh_run' );
		echo '<button class="button button-primary button-hero">' . ( $bad ? 'Set up my new site now' : 'Run the setup again (safe)' ) . '</button></form>';
		echo '<h2>Bring your settings from the old site</h2><p>On the old site open Quality and safety and press "Export settings". Choose that file here. Keys, passwords and tokens are never in that file, so enter those again under Website keys. Profiles, members and messages come from your normal WordPress backup restore.</p>';
		echo '<form method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_fresh_import">';
		wp_nonce_field( 'mrsh_fresh_import' );
		echo '<input type="file" name="f" accept=".json" required> <button class="button">Import settings</button></form></div>';
	}

	public static function run() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_fresh_run' );
		$did = self::setup();
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-fresh&done=' . rawurlencode( 'Done: ' . implode( ', ', $did ) . '. Check that every line below is green.' ) ) );
		exit;
	}

	/** Runs by itself the first time an admin opens the dashboard on a new site (and again once if the theme changes). */
	public static function auto() {
		if ( ! current_user_can( 'manage_options' ) || wp_doing_ajax() ) {
			return;
		}
		$key = get_template() . '|' . ( function_exists( 'mrt_inner_pages' ) ? 1 : 0 );
		if ( get_option( 'mrsh_fresh_auto' ) === $key ) {
			return;
		}
		update_option( 'mrsh_fresh_auto', $key, false ); // set first so a problem can never loop
		try {
			$did = self::setup();
			update_option( 'mrsh_fresh_auto_done', gmdate( 'c' ) . ' ' . implode( ', ', $did ), false );
		} catch ( \Throwable $e ) {
			if ( class_exists( 'MRSH_Safe', false ) ) {
				MRSH_Safe::log_ex( $e, 'automatic setup' );
			}
		}
	}

	/** Creates everything a new site needs. Safe to repeat: it never changes or deletes what exists. */
	public static function setup() {
		$did = array();
		// 1. Profile form fields (only when there are none).
		$cf = get_option( 'cfields' );
		if ( ! is_array( $cf ) || empty( $cf['dbkey'] ) ) {
			update_option( 'cfields', self::default_fields() );
			delete_option( 'mrsh_refine_done' );
			$did[] = 'profile form';
		}
		// 2. Gender choices.
		if ( taxonomy_exists( 'dagender' ) ) {
			foreach ( array( 'Male', 'Female' ) as $g ) {
				if ( ! term_exists( $g, 'dagender' ) ) {
					wp_insert_term( $g, 'dagender' );
				}
			}
		}
		// 3. Long dropdown lists, countries and cities.
		if ( class_exists( 'MRSH_Data' ) ) {
			MRSH_Data::maybe_run( true );
			$did[] = 'lists';
		}
		// 4. Pages.
		if ( class_exists( 'MRSH_Mem_Extras' ) && method_exists( 'MRSH_Mem_Extras', 'make_pages' ) ) {
			MRSH_Mem_Extras::make_pages();
		}
		delete_option( 'mrt_pages_made' );
		delete_option( 'mrsh_more_pages' );
		if ( 'myrishta' === get_template() && function_exists( 'mrt_inner_pages' ) ) {
			foreach ( mrt_inner_pages() as $slug => $d ) {
				if ( in_array( $slug, array( 'memberships', 'contact', 'blog' ), true ) && ! get_page_by_path( $slug ) ) {
					$id = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => $d[0], 'post_name' => $slug, 'post_content' => '' ) );
					if ( $id && ! is_wp_error( $id ) ) {
						update_post_meta( $id, '_wp_page_template', $d[1] );
					}
				}
			}
		}
		$did[] = 'pages';
		// 5. Main menu.
		$loc = get_nav_menu_locations();
		if ( empty( $loc['primary'] ) ) {
			$mid = wp_create_nav_menu( 'Main menu ' . gmdate( 'ymd-His' ) );
			if ( $mid && ! is_wp_error( $mid ) ) {
				foreach ( array( 'search' => 'Search', 'memberships' => 'Memberships', 'blog' => 'Blog', 'contact' => 'Contact', 'add-listing' => 'Add profile', 'my-account' => 'My account' ) as $slug => $label ) {
					$p = get_page_by_path( $slug );
					if ( $p ) {
						wp_update_nav_menu_item( $mid, 0, array( 'menu-item-title' => $label, 'menu-item-object' => 'page', 'menu-item-object-id' => $p->ID, 'menu-item-type' => 'post_type', 'menu-item-status' => 'publish' ) );
					}
				}
				$loc['primary'] = $mid;
				set_theme_mod( 'nav_menu_locations', $loc );
				$did[] = 'menu';
			}
		}
		// 6. Web addresses.
		if ( '' === (string) get_option( 'permalink_structure' ) ) {
			update_option( 'permalink_structure', '/%postname%/' );
		}
		flush_rewrite_rules( false );
		return $did;
	}

	public static function import() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_fresh_import' );
		$msg = 'No file received.';
		if ( ! empty( $_FILES['f']['tmp_name'] ) && is_uploaded_file( $_FILES['f']['tmp_name'] ) && $_FILES['f']['size'] < 5000000 ) { // phpcs:ignore
			$j = json_decode( (string) file_get_contents( $_FILES['f']['tmp_name'] ), true ); // phpcs:ignore
			if ( is_array( $j ) ) {
				$n = 0;
				foreach ( $j as $k => $v ) {
					$k = (string) $k;
					$ok = ( 0 === strpos( $k, 'mrsh_' ) || 0 === strpos( $k, 'mrt_' ) || 0 === strpos( $k, 'myrishta' ) || 'cfields' === $k || 'core_admin_values' === $k );
					if ( ! $ok || preg_match( '/key|secret|token|password|smtp|auth|vapid|license|sid|salt/i', $k ) ) {
						continue;
					}
					update_option( $k, $v );
					++$n;
				}
				flush_rewrite_rules( false );
				$msg = $n . ' settings imported.';
			} else {
				$msg = 'That file is not a settings file.';
			}
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-fresh&done=' . rawurlencode( $msg ) ) );
		exit;
	}
}
MRSH_Fresh::init();
