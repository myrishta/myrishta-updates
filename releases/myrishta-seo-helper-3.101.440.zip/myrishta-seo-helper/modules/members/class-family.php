<?php
/**
 * Family features: "profile managed by" label and an opt-in guardian copy of chats.
 *
 * @package MyRishta_SEO_Helper
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Family {

	const WHO = array( 'self' => 'Myself', 'parent' => 'Parent', 'sibling' => 'Brother or sister', 'relative' => 'Relative', 'guardian' => 'Guardian (wali)' );

	public static function init() {
		add_action( 'mrt_account_extra', array( __CLASS__, 'account' ), 45 );
		add_action( 'mrt_profile_after', array( __CLASS__, 'profile' ), 6 );
		add_action( 'admin_post_mrsh_family', array( __CLASS__, 'save' ) );
		add_action( 'mrsh_msg_sent', array( __CLASS__, 'on_msg' ), 10, 5 );
		add_action( 'mrsh_gcopy_flush', array( __CLASS__, 'flush' ) );
		add_action( 'init', array( __CLASS__, 'links' ) );
	}

	private static function sig( $uid, $act ) {
		return substr( hash_hmac( 'sha256', $act . '|' . $uid . '|' . get_user_meta( $uid, 'mrt_guardian_mail', true ), wp_salt( 'auth' ) ), 0, 20 );
	}

	/* ---------- member settings ---------- */

	public static function account( $uid ) {
		if ( ! $uid ) {
			return;
		}
		$by = (string) get_user_meta( $uid, 'mrt_managed_by', true );
		$gm = (string) get_user_meta( $uid, 'mrt_guardian_mail', true );
		$ok = $gm && get_user_meta( $uid, 'mrt_guardian_ok', true ) === md5( $gm );
		$on = (bool) get_user_meta( $uid, 'mrt_guardian_copy', true );
		$m  = isset( $_GET['fam'] ) ? sanitize_key( $_GET['fam'] ) : ''; // phpcs:ignore
		echo '<div class="wrap narrow"><div class="box"><h3>Family and guardian</h3>';
		if ( $m ) {
			echo '<div class="note2">' . esc_html( 'sent' === $m ? 'Saved. We sent a confirmation email to your guardian.' : 'Saved.' ) . '</div>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_family">' . wp_nonce_field( 'mrsh_family', '_wpnonce', true, false );
		echo '<p><label>Who manages this profile?<br><select name="by" style="width:100%">';
		foreach ( self::WHO as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $by ?: 'self', $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select></label></p><p class="mut">Shown on your profile so other families know who they are talking to.</p>';
		echo '<p><label>Guardian email (optional)<br><input type="email" name="gm" maxlength="100" value="' . esc_attr( $gm ) . '" style="width:100%"></label></p>';
		echo '<p><label><input type="checkbox" name="gc" value="1" style="width:auto"' . checked( $on, true, false ) . '> Send my guardian a copy of my chat messages</label></p>';
		echo '<p class="mut">Your guardian must confirm by email first' . ( $gm ? ( $ok ? ' (confirmed &#10003;)' : ' (waiting for confirmation)' ) : '' ) . '. Other members see a note on your profile that chats are shared with a family guardian. You can switch this off at any time.</p>';
		echo '<p><button class="btn">Save</button></p></form></div></div>';
	}

	public static function save() {
		$uid = get_current_user_id();
		if ( ! $uid || ! check_admin_referer( 'mrsh_family' ) ) {
			wp_die( 'Not allowed.' );
		}
		$by = sanitize_key( $_POST['by'] ?? 'self' ); // phpcs:ignore
		isset( self::WHO[ $by ] ) && 'self' !== $by ? update_user_meta( $uid, 'mrt_managed_by', $by ) : delete_user_meta( $uid, 'mrt_managed_by' );
		$gm  = sanitize_email( wp_unslash( $_POST['gm'] ?? '' ) ); // phpcs:ignore
		$old = (string) get_user_meta( $uid, 'mrt_guardian_mail', true );
		$msg = 'ok';
		if ( ! $gm || ! is_email( $gm ) ) {
			delete_user_meta( $uid, 'mrt_guardian_mail' );
			delete_user_meta( $uid, 'mrt_guardian_ok' );
			delete_user_meta( $uid, 'mrt_guardian_copy' );
		} else {
			if ( $gm !== $old ) {
				update_user_meta( $uid, 'mrt_guardian_mail', $gm );
				delete_user_meta( $uid, 'mrt_guardian_ok' );
			}
			! empty( $_POST['gc'] ) ? update_user_meta( $uid, 'mrt_guardian_copy', 1 ) : delete_user_meta( $uid, 'mrt_guardian_copy' ); // phpcs:ignore
			if ( get_user_meta( $uid, 'mrt_guardian_ok', true ) !== md5( $gm ) && ! get_transient( 'mrsh_gc_sent_' . $uid ) ) {
				$u = get_userdata( $uid );
				wp_mail( $gm, 'Please confirm: guardian copy on My Rishta Pakistan', ( $u ? $u->display_name : 'A member' ) . " has asked to share their chat messages with you as a family guardian.\n\nIf you agree, confirm here:\n" . add_query_arg( array( 'mrsh_gc' => $uid, 't' => self::sig( $uid, 'ok' ) ), home_url( '/' ) ) . "\n\nIf you do not know this person, ignore this email and nothing will be sent.\n\nMy Rishta Pakistan" );
				set_transient( 'mrsh_gc_sent_' . $uid, 1, DAY_IN_SECONDS );
				$msg = 'sent';
			}
		}
		wp_safe_redirect( add_query_arg( 'fam', $msg, wp_get_referer() ?: home_url( '/' ) ) );
		exit;
	}

	/* ---------- confirm / stop links ---------- */

	public static function links() {
		foreach ( array( 'mrsh_gc' => 'ok', 'mrsh_gcstop' => 'stop' ) as $q => $act ) {
			if ( empty( $_GET[ $q ] ) || empty( $_GET['t'] ) ) { // phpcs:ignore
				continue;
			}
			$uid = absint( $_GET[ $q ] ); // phpcs:ignore
			$gm  = (string) get_user_meta( $uid, 'mrt_guardian_mail', true );
			if ( ! $gm || ! hash_equals( self::sig( $uid, $act ), sanitize_text_field( wp_unslash( $_GET['t'] ) ) ) ) { // phpcs:ignore
				wp_die( 'This link is not valid any more.', 'Link', array( 'response' => 403 ) );
			}
			if ( 'ok' === $act ) {
				update_user_meta( $uid, 'mrt_guardian_ok', md5( $gm ) );
				wp_die( 'Thank you. You will now receive a copy of this member\'s chat messages. Every email has a link to stop at any time.', 'Confirmed', array( 'response' => 200 ) );
			}
			delete_user_meta( $uid, 'mrt_guardian_copy' );
			wp_die( 'Done. You will not receive any more copies.', 'Stopped', array( 'response' => 200 ) );
		}
	}

	/* ---------- chat copy (buffered, one email per 10 minutes) ---------- */

	public static function active( $uid ) {
		$gm = (string) get_user_meta( $uid, 'mrt_guardian_mail', true );
		return $gm && get_user_meta( $uid, 'mrt_guardian_copy', true ) && get_user_meta( $uid, 'mrt_guardian_ok', true ) === md5( $gm );
	}

	public static function on_msg( $id, $from, $to, $text, $pid ) {
		$buf = (array) get_option( 'mrsh_gcopy_buf', array() );
		foreach ( array( (int) $from, (int) $to ) as $u ) {
			if ( $u && self::active( $u ) ) {
				$f             = get_userdata( (int) $from );
				$t             = get_userdata( (int) $to );
				$buf[ $u ][]   = gmdate( 'H:i', time() + 5 * HOUR_IN_SECONDS ) . '  ' . ( $f ? $f->display_name : '?' ) . ' to ' . ( $t ? $t->display_name : '?' ) . ': ' . wp_strip_all_tags( $text );
			}
		}
		update_option( 'mrsh_gcopy_buf', $buf, false );
		if ( $buf && ! wp_next_scheduled( 'mrsh_gcopy_flush' ) ) {
			wp_schedule_single_event( time() + 600, 'mrsh_gcopy_flush' );
		}
	}

	public static function flush() {
		$buf = (array) get_option( 'mrsh_gcopy_buf', array() );
		update_option( 'mrsh_gcopy_buf', array(), false );
		foreach ( $buf as $uid => $lines ) {
			if ( ! self::active( (int) $uid ) ) {
				continue;
			}
			$u = get_userdata( (int) $uid );
			wp_mail( get_user_meta( $uid, 'mrt_guardian_mail', true ), 'Chat copy for ' . ( $u ? $u->display_name : 'your family member' ), "New messages (copy shared with your consent):\n\n" . implode( "\n", array_slice( $lines, -60 ) ) . "\n\nStop receiving copies: " . add_query_arg( array( 'mrsh_gcstop' => $uid, 't' => self::sig( (int) $uid, 'stop' ) ), home_url( '/' ) ) . "\n\nMy Rishta Pakistan" );
		}
	}

	/* ---------- profile labels ---------- */

	public static function profile( $pid ) {
		$p = get_post( $pid ? $pid : get_the_ID() );
		if ( ! $p ) {
			return;
		}
		$a  = (int) $p->post_author;
		$by = (string) get_user_meta( $a, 'mrt_managed_by', true );
		$o  = '';
		if ( isset( self::WHO[ $by ] ) ) {
			$o .= '<span class="chip on" style="display:inline-block;margin:4px 6px 4px 0">Profile managed by: ' . esc_html( self::WHO[ $by ] ) . '</span>';
		}
		if ( self::active( $a ) ) {
			$o .= '<span class="chip" style="display:inline-block;margin:4px 0">Chats are shared with a family guardian</span>';
		}
		if ( $o ) {
			echo '<div class="wrap">' . $o . '</div>'; // phpcs:ignore
		}
	}
}

MRSH_Family::init();
