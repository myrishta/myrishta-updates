<?php
/**
 * More member tools, part 2: selfie check, profile video (with approval), voice messages, typing / seen / away notes in chat,
 * swipe Hit / Miss on a profile, guardian contact line, monthly newsletter with one-click unsubscribe.
 * Switches live in My Rishta SEO > Growth tools2 (option mrsh_more2). Everything that stores files uses random file names.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Mem_More2 {

	public static function defaults() {
		return array( 'selfie_on' => 1, 'video_on' => 0, 'voice_on' => 0, 'news_on' => 0, 'swipe_on' => 1 );
	}

	public static function get( $k = null ) {
		$o = array_merge( self::defaults(), (array) get_option( 'mrsh_more2', array() ) );
		return null === $k ? $o : ( $o[ $k ] ?? '' );
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 28 );
		add_action( 'admin_post_mrsh_m2_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_mrsh_selfie', array( __CLASS__, 'selfie_post' ) );
		add_action( 'admin_post_mrsh_video', array( __CLASS__, 'video_post' ) );
		add_action( 'admin_post_mrsh_wali', array( __CLASS__, 'wali_post' ) );
		add_action( 'admin_post_mrsh_check_act', array( __CLASS__, 'check_act' ) );
		add_action( 'wp_ajax_mrsh_voice', array( __CLASS__, 'voice' ) );
		add_action( 'wp_ajax_mrsh_typing', array( __CLASS__, 'typing' ) );
		add_action( 'wp_ajax_mrsh_status', array( __CLASS__, 'status' ) );
		add_action( 'mrt_account_extra', array( __CLASS__, 'account' ), 40 );
		add_action( 'mrt_profile_after', array( __CLASS__, 'profile' ) );
		add_action( 'wp_footer', array( __CLASS__, 'js' ), 85 );
		add_action( 'mrsh_growth_daily', array( __CLASS__, 'newsletter' ) );
		add_action( 'init', array( __CLASS__, 'unsub' ) );
	}

	private static function code( $uid ) {
		return 'MR' . strtoupper( substr( md5( $uid . wp_salt() ), 0, 4 ) );
	}

	private static function save_file( $field, $mimes, $max, $prefix ) {
		if ( empty( $_FILES[ $field ]['name'] ) || (int) $_FILES[ $field ]['size'] > $max ) { // phpcs:ignore
			return null;
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		$r = wp_handle_upload( $_FILES[ $field ], array( 'test_form' => false, 'mimes' => $mimes, // phpcs:ignore
			'unique_filename_callback' => function ( $d, $n, $ext ) use ( $prefix ) { return $prefix . wp_generate_password( 20, false ) . $ext; } ) );
		return ( ! empty( $r['error'] ) || empty( $r['url'] ) ) ? null : $r;
	}

	private static function back( $k, $v ) {
		wp_safe_redirect( add_query_arg( $k, $v, home_url( '/my-account/' ) ) );
		exit;
	}

	/* ---------- selfie + video + wali (member side) ---------- */

	public static function selfie_post() {
		$uid = get_current_user_id();
		if ( ! $uid || ! check_admin_referer( 'mrsh_selfie' ) || ! self::get( 'selfie_on' ) ) {
			self::back( 'm2', 'bad' );
		}
		$r = self::save_file( 'shot', array( 'jpg|jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' ), 4 * MB_IN_BYTES, 'selfie-' );
		if ( ! $r ) {
			self::back( 'm2', 'bad' );
		}
		$l   = (array) get_option( 'mrsh_checks', array() );
		$l[] = array( 'k' => 'selfie', 'u' => $uid, 'url' => esc_url_raw( $r['url'] ), 'f' => $r['file'], 't' => time(), 'code' => self::code( $uid ) );
		update_option( 'mrsh_checks', array_slice( $l, -300 ), false );
		wp_mail( get_option( 'admin_email' ), 'Selfie check received', 'Open: ' . admin_url( 'admin.php?page=mrsh-checks' ) );
		self::back( 'm2', 'selfie' );
	}

	public static function video_post() {
		$uid = get_current_user_id();
		if ( ! $uid || ! check_admin_referer( 'mrsh_video' ) || ! self::get( 'video_on' ) || (int) get_transient( 'mrsh_vd_' . $uid ) >= 3 ) {
			self::back( 'm2', 'bad' );
		}
		$r = self::save_file( 'vid', array( 'mp4' => 'video/mp4', 'webm' => 'video/webm', 'mov' => 'video/quicktime' ), 15 * MB_IN_BYTES, 'intro-' );
		if ( ! $r ) {
			self::back( 'm2', 'bad' );
		}
		set_transient( 'mrsh_vd_' . $uid, (int) get_transient( 'mrsh_vd_' . $uid ) + 1, DAY_IN_SECONDS );
		$l   = (array) get_option( 'mrsh_checks', array() );
		$l[] = array( 'k' => 'video', 'u' => $uid, 'url' => esc_url_raw( $r['url'] ), 'f' => $r['file'], 't' => time() );
		update_option( 'mrsh_checks', array_slice( $l, -300 ), false );
		wp_mail( get_option( 'admin_email' ), 'Profile video waiting', 'Open: ' . admin_url( 'admin.php?page=mrsh-checks' ) );
		self::back( 'm2', 'video' );
	}

	public static function wali_post() {
		$uid = get_current_user_id();
		if ( ! $uid || ! check_admin_referer( 'mrsh_wali' ) ) {
			self::back( 'm2', 'bad' );
		}
		$t = sanitize_text_field( wp_unslash( $_POST['wali'] ?? '' ) ); // phpcs:ignore
		$t = preg_replace( '/[\d\+@]{4,}|https?:\/\/\S+|www\.\S+/i', '', $t );
		$t = mb_substr( trim( $t ), 0, 80 );
		$t ? update_user_meta( $uid, 'mrt_wali', $t ) : delete_user_meta( $uid, 'mrt_wali' );
		$a = sanitize_text_field( wp_unslash( $_POST['away'] ?? '' ) ); // phpcs:ignore
		$a = mb_substr( trim( preg_replace( '/[\d\+@]{6,}|https?:\/\/\S+|www\.\S+/i', '', $a ) ), 0, 140 );
		$a ? update_user_meta( $uid, 'mrt_away', $a ) : delete_user_meta( $uid, 'mrt_away' );
		self::back( 'm2', 'saved' );
	}

	public static function account( $uid ) {
		if ( ! $uid ) {
			return;
		}
		$o = self::get();
		echo '<div class="wrap narrow">';
		if ( isset( $_GET['m2'] ) ) { // phpcs:ignore
			$m = array( 'selfie' => 'Thank you. We will check your selfie.', 'video' => 'Thank you. Your video will appear after we check it.', 'saved' => 'Saved.', 'bad' => 'That did not work. Check the file type and size.' );
			echo '<div class="note2">' . esc_html( $m[ $_GET['m2'] ] ?? 'Done.' ) . '</div>'; // phpcs:ignore
		}
		// Guardian + away
		echo '<div class="box"><h3>Guardian line and away note</h3><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_wali">' . wp_nonce_field( 'mrsh_wali', '_wpnonce', true, false )
			. '<p><label>Contact through (name and relation, no phone number)<br><input type="text" name="wali" maxlength="80" value="' . esc_attr( (string) get_user_meta( $uid, 'mrt_wali', true ) ) . '" placeholder="For example: Father, Mr Ahmed" style="width:100%"></label></p>'
			. '<p><label>Away note shown in your chat (optional)<br><input type="text" name="away" maxlength="140" value="' . esc_attr( (string) get_user_meta( $uid, 'mrt_away', true ) ) . '" placeholder="For example: Travelling until Sunday, will reply then" style="width:100%"></label></p><p><button class="btn">Save</button></p></form></div>';
		if ( $o['selfie_on'] ) {
			echo '<div class="box"><h3>Selfie check</h3>';
			if ( get_user_meta( $uid, 'mrt_selfie_ok', true ) ) {
				echo '<p>&#10003; Your selfie check is approved.</p>';
			} else {
				echo '<p class="mut">Take a selfie holding a paper with this code written on it: <b>' . esc_html( self::code( $uid ) ) . '</b>. Your face must be clear. We only use it to check that your pictures are really yours.</p><form method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_selfie">' . wp_nonce_field( 'mrsh_selfie', '_wpnonce', true, false ) . '<p><input type="file" name="shot" accept="image/*" capture="user" required></p><p><button class="btn">Send selfie</button></p></form>';
			}
			echo '</div>';
		}
		if ( $o['video_on'] ) {
			echo '<div class="box"><h3>Video introduction</h3><p class="mut">A 30 second video (MP4 or WebM, up to 15 MB). It appears on your profile after we check it. No phone numbers or addresses in the video.</p>';
			if ( get_user_meta( $uid, 'mrt_video_url', true ) ) {
				echo '<p>&#10003; You have an approved video.</p>';
			}
			echo '<form method="post" enctype="multipart/form-data" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_video">' . wp_nonce_field( 'mrsh_video', '_wpnonce', true, false ) . '<p><input type="file" name="vid" accept="video/mp4,video/webm,video/quicktime" required></p><p><button class="btn">Send video</button></p></form></div>';
		}
		echo '</div>';
	}

	public static function profile( $pid ) {
		$p = get_post( $pid ? $pid : get_the_ID() );
		if ( ! $p ) {
			return;
		}
		$a = (int) $p->post_author;
		echo '<div class="wrap">';
		if ( get_user_meta( $a, 'mrt_selfie_ok', true ) ) {
			echo '<span class="chip on" style="display:inline-block;margin:4px 6px 4px 0">&#10003; Selfie checked</span>';
		}
		$w = (string) get_user_meta( $a, 'mrt_wali', true );
		if ( $w ) {
			echo '<span class="chip" style="display:inline-block;margin:4px 0">Contact through: ' . esc_html( $w ) . '</span>';
		}
		$v = (string) get_user_meta( $a, 'mrt_video_url', true );
		if ( $v && self::get( 'video_on' ) ) {
			echo '<div class="box" style="margin-top:10px"><h3>Video introduction</h3><video src="' . esc_url( $v ) . '" controls preload="none" playsinline style="width:100%;max-width:480px;border-radius:14px"></video></div>';
		}
		echo '</div>';
	}

	/* ---------- admin: checks queue + settings ---------- */

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Selfie and video checks', 'Selfie and video checks', 'manage_options', 'mrsh-checks', array( __CLASS__, 'checks_page' ) );
		add_submenu_page( 'myrishta-seo', 'Extra features', 'Extra features', 'manage_options', 'mrsh-more2', array( __CLASS__, 'page' ) );
	}

	public static function checks_page() {
		echo '<div class="wrap"><h1>Selfie and video checks</h1><p>Selfie: the person must hold a paper with the code shown. Approve only if the face matches the profile pictures. Reject deletes the file.</p><table class="widefat striped"><thead><tr><th>Date</th><th>Member</th><th>Type</th><th>File</th><th>Code</th><th></th></tr></thead><tbody>';
		$l = array_reverse( (array) get_option( 'mrsh_checks', array() ), true );
		if ( ! $l ) {
			echo '<tr><td colspan="6">Nothing waiting.</td></tr>';
		}
		foreach ( $l as $i => $c ) {
			$u = get_userdata( (int) $c['u'] );
			echo '<tr><td>' . esc_html( wp_date( 'j M Y H:i', (int) $c['t'] ) ) . '</td><td>' . ( $u ? '<a href="' . esc_url( get_edit_user_link( $u->ID ) ) . '">' . esc_html( $u->display_name ) . '</a>' : '#' . (int) $c['u'] ) . '</td><td>' . esc_html( $c['k'] ) . '</td><td><a href="' . esc_url( $c['url'] ) . '" target="_blank" rel="noopener">Open</a></td><td>' . esc_html( $c['code'] ?? '' ) . '</td><td><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_check_act"><input type="hidden" name="i" value="' . (int) $i . '">' . wp_nonce_field( 'mrsh_check_act', '_wpnonce', true, false ) . '<button class="button button-primary" name="do" value="approve">Approve</button> <button class="button" name="do" value="reject">Reject</button></form></td></tr>';
		}
		echo '</tbody></table></div>';
	}

	public static function check_act() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_check_act' );
		$l = (array) get_option( 'mrsh_checks', array() );
		$i = absint( $_POST['i'] ?? 0 ); // phpcs:ignore
		if ( isset( $l[ $i ] ) ) {
			$c  = $l[ $i ];
			$ok = 'approve' === ( $_POST['do'] ?? '' ); // phpcs:ignore
			if ( $ok ) {
				'selfie' === $c['k'] ? update_user_meta( (int) $c['u'], 'mrt_selfie_ok', time() ) : update_user_meta( (int) $c['u'], 'mrt_video_url', esc_url_raw( $c['url'] ) );
			}
			if ( 'selfie' === $c['k'] || ! $ok ) { // selfies are never kept after the decision
				$up = wp_get_upload_dir();
				if ( ! empty( $c['f'] ) && 0 === strpos( wp_normalize_path( $c['f'] ), wp_normalize_path( $up['basedir'] ) ) ) {
					wp_delete_file( $c['f'] );
				}
			}
			if ( class_exists( 'MRSH_Mem_Growth' ) ) {
				MRSH_Mem_Growth::log( ( $ok ? 'Approved ' : 'Rejected ' ) . $c['k'] . ' check of user #' . (int) $c['u'] );
			}
			unset( $l[ $i ] );
			update_option( 'mrsh_checks', array_values( $l ), false );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-checks' ) );
		exit;
	}

	public static function page() {
		$o   = self::get();
		$row = function ( $k, $l, $h ) use ( $o ) {
			echo '<tr><th>' . esc_html( $l ) . '</th><td><label><input type="checkbox" name="' . esc_attr( $k ) . '" value="1"' . checked( (int) $o[ $k ], 1, false ) . '> On</label> <span class="description">' . esc_html( $h ) . '</span></td></tr>';
		};
		echo '<div class="wrap"><h1>Extra features</h1>';
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success is-dismissible"><p>Saved.</p></div>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_m2_save">';
		wp_nonce_field( 'mrsh_m2_save' );
		echo '<table class="form-table">';
		$row( 'selfie_on', 'Selfie check', 'Members send a selfie with a code. You approve on the Selfie and video checks page. The selfie is deleted after your decision.' );
		$row( 'video_on', 'Video introduction', 'Members send a short video. It shows on the profile only after you approve it. Needs your checking time, so keep it off if you cannot review videos.' );
		$row( 'voice_on', 'Voice messages in chat', 'A microphone button in chat (up to 60 seconds). Voice cannot be checked by the word filter, so keep it off if you cannot handle reports.' );
		$row( 'swipe_on', 'Swipe on a profile', 'On phones, swipe right = Hit, swipe left = Miss.' );
		$row( 'news_on', 'Monthly newsletter to members', 'On the 1st of each month: new profiles count and latest articles. Every email has a one-click unsubscribe link.' );
		echo '</table><p><button class="button button-primary">Save</button></p></form></div>';
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_m2_save' );
		$n = array();
		foreach ( array_keys( self::defaults() ) as $k ) {
			$n[ $k ] = empty( $_POST[ $k ] ) ? 0 : 1; // phpcs:ignore
		}
		update_option( 'mrsh_more2', $n, false );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-more2&ok=1' ) );
		exit;
	}

	/* ---------- chat: voice, typing, status ---------- */

	public static function voice() {
		check_ajax_referer( 'mrt', 'n' );
		$uid  = get_current_user_id();
		$with = absint( $_POST['with'] ?? 0 ); // phpcs:ignore
		$no   = function ( $m ) { wp_send_json( array( 'ok' => false, 'msg' => $m ) ); };
		if ( ! $uid || ! self::get( 'voice_on' ) || ! $with || $with === $uid || ! get_userdata( $with ) ) {
			$no( 'Voice messages are not available.' );
		}
		if ( in_array( $uid, (array) get_user_meta( $with, 'blocked', true ), true ) ) {
			$no( 'You cannot contact this member.' );
		}
		$op = MRSH_Members::my_profile( $with );
		if ( ! $op || 'publish' !== $op->post_status ) {
			$no( 'This member has no live profile right now.' );
		}
		$set = MRSH_Manage::get();
		$k   = 'mrt_lim_msg_' . $uid . '_' . gmdate( 'Ymd' );
		$n   = (int) get_transient( $k );
		if ( $n >= (int) $set['msg'] ) {
			$no( 'Daily limit reached. Try again tomorrow.' );
		}
		$r = self::save_file( 'audio', array( 'webm' => 'audio/webm', 'ogg' => 'audio/ogg', 'm4a' => 'audio/mp4', 'mp3' => 'audio/mpeg', 'weba' => 'audio/webm' ), 1500 * KB_IN_BYTES, 'voice-' );
		if ( ! $r ) {
			$no( 'Could not save the recording.' );
		}
		set_transient( $k, $n + 1, DAY_IN_SECONDS );
		$id = MRSH_Members::send( $uid, $with, '[voice:' . ltrim( str_replace( wp_normalize_path( wp_get_upload_dir()['basedir'] ), '', wp_normalize_path( $r['file'] ) ), '/' ) . ']', $op->ID );
		MRSH_Members::notify( $with, 'msg' );
		wp_send_json( array( 'ok' => (bool) $id, 'id' => (int) $id ) );
	}

	public static function typing() {
		check_ajax_referer( 'mrt', 'n' );
		$uid  = get_current_user_id();
		$with = absint( $_POST['with'] ?? 0 ); // phpcs:ignore
		if ( $uid && $with ) {
			set_transient( 'mrt_ty_' . $uid . '_' . $with, 1, 6 );
		}
		wp_send_json( array( 'ok' => true ) );
	}

	/** Typing, seen and away note for an open chat. Read only. */
	public static function status() {
		check_ajax_referer( 'mrt', 'n' );
		$uid  = get_current_user_id();
		$with = absint( $_POST['with'] ?? 0 ); // phpcs:ignore
		if ( ! $uid || ! $with ) {
			wp_send_json( array( 'ok' => false ) );
		}
		$q    = get_posts( array( 'post_type' => MRSH_Members::MSG, 'post_status' => 'publish', 'numberposts' => 1, 'author' => $uid, 'orderby' => 'ID', 'order' => 'DESC',
			'meta_query' => array( array( 'key' => 'msg_stick', 'value' => '[' . $with . '][' . $uid . ']' ) ) ) );
		$seen = $q && 'read' === get_post_meta( $q[0]->ID, 'msg_status', true );
		wp_send_json( array( 'ok' => true, 'typing' => (bool) get_transient( 'mrt_ty_' . $with . '_' . $uid ), 'seen' => (bool) $seen, 'last' => $q ? (int) $q[0]->ID : 0, 'away' => (string) get_user_meta( $with, 'mrt_away', true ) ) );
	}

	/* ---------- front end ---------- */

	public static function js() {
		if ( 'myrishta' !== get_template() ) {
			return;
		}
		$o  = self::get();
		$up = wp_get_upload_dir();
		?>
<script>
(function(){
var AJ=<?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>,N=<?php echo wp_json_encode( wp_create_nonce( 'mrt' ) ); ?>,UP=<?php echo wp_json_encode( trailingslashit( $up['baseurl'] ) ); ?>,VOICE=<?php echo (int) $o['voice_on']; ?>;
function post(d,cb){var f=new FormData();for(var k in d)f.append(k,d[k]);f.append('n',N);return fetch(AJ,{method:'POST',body:f,credentials:'same-origin'}).then(function(r){return r.json()}).then(cb||function(){}).catch(function(){})}
var box=document.getElementById('mrt-chat');
if(box){var w=box.getAttribute('data-with'),ta=box.querySelector('textarea'),cl=box.querySelector('.cl');
var st=document.createElement('div');st.style.cssText='font-size:.8rem;color:#667085;min-height:18px;margin:4px 2px';if(cl)cl.parentNode.insertBefore(st,cl.nextSibling);
var away=document.createElement('div');away.style.cssText='display:none;background:#eef4ff;border:1px solid #c9dbff;border-radius:12px;padding:8px 12px;margin:8px 0;font-size:.9rem';if(cl)cl.parentNode.insertBefore(away,cl);
var lt=0;if(ta)ta.addEventListener('input',function(){var n=Date.now();if(n-lt>3000){lt=n;post({action:'mrsh_typing',with:w})}});
function tick(){if(document.hidden)return;post({action:'mrsh_status',with:w},function(r){if(!r||!r.ok)return;var lastMine=cl.querySelectorAll('.bub.me');var t=r.typing?'Typing...':'';if(!r.typing&&lastMine.length&&r.last){t=r.seen?'Seen':'Sent'}st.textContent=t;if(r.away){away.style.display='block';away.textContent='Away note: '+r.away}else away.style.display='none'})}
tick();setInterval(tick,5000);
/* voice messages: show a player instead of the code text */
function vdec(b){var m=/^\[voice:([A-Za-z0-9._\/-]+)\]$/.exec(b.textContent.trim());if(!m||b.getAttribute('data-v')||m[1].indexOf('..')>-1)return;b.setAttribute('data-v','1');
var a=document.createElement('audio');a.controls=true;a.preload='none';a.style.maxWidth='100%';a.src=UP+m[1];b.textContent='';b.appendChild(a)}
function vall(){cl.querySelectorAll('.bub').forEach(vdec)}vall();if(cl)new MutationObserver(vall).observe(cl,{childList:true});
if(VOICE&&ta&&window.MediaRecorder&&navigator.mediaDevices){var mic=document.createElement('button');mic.type='button';mic.className='chip';mic.textContent='Voice message';var rec=null,chunks=[],tm=null;
mic.onclick=function(){if(rec){rec.stop();return}navigator.mediaDevices.getUserMedia({audio:true}).then(function(s){chunks=[];rec=new MediaRecorder(s);rec.ondataavailable=function(e){chunks.push(e.data)};
rec.onstop=function(){clearTimeout(tm);s.getTracks().forEach(function(t){t.stop()});var type=rec.mimeType||'audio/webm';var ext=/mp4/.test(type)?'m4a':/ogg/.test(type)?'ogg':'webm';var blob=new Blob(chunks,{type:type});rec=null;mic.textContent='Voice message';
var f=new FormData();f.append('action','mrsh_voice');f.append('n',N);f.append('with',w);f.append('audio',blob,'v.'+ext);fetch(AJ,{method:'POST',body:f,credentials:'same-origin'}).then(function(r){return r.json()}).then(function(r){if(r.ok)location.reload();else alert(r.msg||'Could not send')})};
rec.start();mic.textContent='Stop and send';tm=setTimeout(function(){if(rec)rec.stop()},60000)}).catch(function(){alert('Microphone is not allowed.')})};ta.parentNode.insertBefore(mic,ta)}}
/* swipe on a profile: right = Hit, left = Miss */
<?php if ( $o['swipe_on'] ) : ?>
var hit=document.querySelector('[data-act="hit"]'),miss=document.querySelector('[data-act="miss"]');
if(hit&&miss&&'ontouchstart' in window){var x0=0,y0=0,ok=false;
document.addEventListener('touchstart',function(e){ok=!e.target.closest('.hscroll,.gallery,input,textarea,select,video,audio,#mrt-chat');x0=e.touches[0].clientX;y0=e.touches[0].clientY},{passive:true});
document.addEventListener('touchend',function(e){if(!ok)return;var dx=e.changedTouches[0].clientX-x0,dy=e.changedTouches[0].clientY-y0;if(Math.abs(dx)>150&&Math.abs(dy)<35&&Math.abs(dx)>Math.abs(dy)*4){(dx>0?hit:miss).click()}},{passive:true})}
<?php endif; ?>
})();
</script>
		<?php
	}

	/* ---------- monthly newsletter ---------- */

	private static function key( $uid ) {
		return hash_hmac( 'sha256', 'unsub' . $uid, wp_salt() );
	}

	public static function unsub() {
		if ( empty( $_GET['mrsh_unsub'] ) ) { // phpcs:ignore
			return;
		}
		$uid = absint( $_GET['mrsh_unsub'] ); // phpcs:ignore
		$k   = sanitize_text_field( wp_unslash( $_GET['k'] ?? '' ) ); // phpcs:ignore
		if ( $uid && hash_equals( self::key( $uid ), $k ) ) {
			update_user_meta( $uid, 'mrt_news_ok', '0' );
			wp_die( 'You are unsubscribed from the newsletter. / آپ نیوز لیٹر سے نکل گئے ہیں۔', 'Unsubscribed', array( 'response' => 200 ) );
		}
	}

	public static function newsletter() {
		if ( ! self::get( 'news_on' ) || 1 !== (int) gmdate( 'j' ) ) {
			return;
		}
		$mk = gmdate( 'Ym' );
		$q  = get_users( array( 'number' => 300, 'meta_query' => array( 'relation' => 'AND',
			array( 'relation' => 'OR', array( 'key' => 'mrt_news_ok', 'compare' => 'NOT EXISTS' ), array( 'key' => 'mrt_news_ok', 'value' => '0', 'compare' => '!=' ) ),
			array( 'relation' => 'OR', array( 'key' => 'mrt_news_sent', 'compare' => 'NOT EXISTS' ), array( 'key' => 'mrt_news_sent', 'value' => $mk, 'compare' => '!=' ) ) ) ) );
		if ( ! $q ) {
			return;
		}
		$cnt = (int) ( new WP_Query( array( 'post_type' => 'listing_type', 'post_status' => 'publish', 'date_query' => array( array( 'after' => '30 days ago' ) ), 'fields' => 'ids', 'posts_per_page' => 1 ) ) )->found_posts;
		$art = '';
		foreach ( get_posts( array( 'numberposts' => 3, 'post_status' => 'publish' ) ) as $p ) {
			$art .= '- ' . html_entity_decode( get_the_title( $p ), ENT_QUOTES, 'UTF-8' ) . ' ' . get_permalink( $p ) . "\n";
		}
		foreach ( $q as $u ) {
			update_user_meta( $u->ID, 'mrt_news_sent', $mk );
			$un   = add_query_arg( array( 'mrsh_unsub' => $u->ID, 'k' => self::key( $u->ID ) ), home_url( '/' ) );
			$body = 'Assalam o Alaikum ' . $u->display_name . ",\n\n" . $cnt . " new profiles joined " . get_bloginfo( 'name' ) . " in the last 30 days.\n\nLatest guides:\n" . $art . "\nOpen the site: " . home_url( '/' ) . "\n\nپچھلے 30 دنوں میں " . $cnt . " نئی پروفائلز شامل ہوئیں۔\n\nNever send money to anyone you meet online.\n\nUnsubscribe / نیوز لیٹر بند کریں: " . $un;
			wp_mail( $u->user_email, 'Monthly update | ماہانہ اپڈیٹ', $body, array( 'List-Unsubscribe: <' . $un . '>' ) );
		}
	}
}
MRSH_Mem_More2::init();
