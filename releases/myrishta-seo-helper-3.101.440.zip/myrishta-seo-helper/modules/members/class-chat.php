<?php
/**
 * Live chat: an open conversation checks for new messages every few seconds and shows them without a page reload.
 * Messages are saved the same way as before (post type ppt_message), so nothing in the old data changes.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Mem_Chat {

	public static function init() {
		add_action( 'wp_ajax_mrsh_chat_poll', array( __CLASS__, 'poll' ) );
		add_action( 'wp_ajax_mrsh_chat_send', array( __CLASS__, 'send' ) );
		add_action( 'wp_ajax_mrsh_unread', array( __CLASS__, 'unread' ) );
	}

	private static function uid() {
		check_ajax_referer( 'mrt', 'n' );
		$uid = get_current_user_id();
		if ( ! $uid ) {
			wp_send_json( array( 'ok' => false, 'msg' => 'Please log in first.' ) );
		}
		return $uid;
	}

	private static function thread_ids( $uid, $other, $after ) {
		$q   = get_posts( array(
			'post_type' => MRSH_Members::MSG, 'post_status' => 'publish', 'numberposts' => 60, 'orderby' => 'ID', 'order' => 'DESC',
			'meta_query' => array( 'relation' => 'OR',
				array( 'key' => 'msg_stick', 'value' => '[' . $uid . '][' . $other . ']' ),
				array( 'key' => 'msg_stick', 'value' => '[' . $other . '][' . $uid . ']' ),
			),
		) );
		$out = array();
		foreach ( array_reverse( $q ) as $m ) {
			if ( (int) $m->ID > $after ) {
				$out[] = $m;
			}
		}
		return $out;
	}

	private static function shape( $m, $uid ) {
		$me = (int) $m->post_author === $uid;
		return array(
			'id' => (int) $m->ID, 'me' => $me, 'text' => (string) $m->post_content, 'time' => mysql2date( 'H:i', $m->post_date ),
			'day' => substr( (string) $m->post_date, 0, 10 ), 'dl' => self::day_label( $m->post_date ),
			'read' => $me && 'read' === get_post_meta( $m->ID, 'msg_status', true ),
		);
	}

	/** "Today", "Yesterday" or a date, in the site's time. */
	public static function day_label( $post_date ) {
		$d = substr( (string) $post_date, 0, 10 );
		if ( wp_date( 'Y-m-d' ) === $d ) {
			return 'Today';
		}
		if ( wp_date( 'Y-m-d', time() - DAY_IN_SECONDS ) === $d ) {
			return 'Yesterday';
		}
		return mysql2date( 'j M Y', $post_date );
	}

	/** How recently a member was on the site, in words (the site only records this a few times a day). */
	public static function presence( $uid ) {
		$t = (int) get_user_meta( $uid, 'mrsh_last_active', true );
		if ( ! $t ) {
			return '';
		}
		$age = time() - $t;
		if ( $age < DAY_IN_SECONDS ) {
			return 'Active today';
		}
		if ( $age < 7 * DAY_IN_SECONDS ) {
			return 'Active this week';
		}
		return '';
	}

	/** Ids of my own messages in this conversation that the other person has not read yet. */
	private static function pending( $uid, $other ) {
		$ids = array();
		foreach ( self::thread_ids( $uid, $other, 0 ) as $m ) {
			if ( (int) $m->post_author === $uid && 'read' !== get_post_meta( $m->ID, 'msg_status', true ) ) {
				$ids[] = (int) $m->ID;
			}
		}
		return $ids;
	}

	public static function poll() {
		$uid   = self::uid();
		$with  = isset( $_POST['with'] ) ? absint( $_POST['with'] ) : 0;
		$after = isset( $_POST['after'] ) ? absint( $_POST['after'] ) : 0;
		if ( ! $with || ! get_userdata( $with ) ) {
			wp_send_json( array( 'ok' => false ) );
		}
		$out = array();
		foreach ( self::thread_ids( $uid, $with, $after ) as $m ) {
			if ( 'unread_' . $uid === get_post_meta( $m->ID, 'msg_status', true ) ) {
				update_post_meta( $m->ID, 'msg_status', 'read' );
			}
			$out[] = self::shape( $m, $uid );
		}
		wp_send_json( array( 'ok' => true, 'msgs' => $out, 'pending' => self::pending( $uid, $with ), 'unread' => (int) MRSH_Members::unread_count( $uid ) ) );
	}

	public static function send() {
		$uid  = self::uid();
		$with = isset( $_POST['with'] ) ? absint( $_POST['with'] ) : 0;
		$text = isset( $_POST['text'] ) ? trim( wp_strip_all_tags( (string) wp_unslash( $_POST['text'] ) ) ) : '';
		$no   = function ( $m ) {
			wp_send_json( array( 'ok' => false, 'msg' => $m ) );
		};
		if ( ! $with || $with === $uid || ! get_userdata( $with ) ) {
			$no( 'Member not found.' );
		}
		if ( in_array( $uid, (array) get_user_meta( $with, 'blocked', true ), true ) ) {
			$no( 'You cannot contact this member.' );
		}
		$op = MRSH_Members::my_profile( $with );
		if ( ! $op || 'publish' !== $op->post_status ) {
			$no( 'This member has no live profile right now.' );
		}
		if ( strlen( $text ) < 1 || strlen( $text ) > 1000 ) {
			$no( 'Write between 1 and 1000 characters.' );
		}
		if ( preg_match( '#https?://|www\.|\b\d[\d\s\-]{8,}\d\b#i', $text ) ) {
			$no( 'For your safety, links and phone numbers cannot be sent here.' );
		}
		if ( class_exists( 'MRSH_Queue' ) && ( $m = MRSH_Queue::money_block( $text, $uid, $with ) ) ) {
			$no( $m );
		}
		// the same words sent twice within a few seconds (double tap, two scripts) are stored once
		$dk  = 'mrsh_dup_' . md5( $uid . '|' . $with . '|' . $text );
		$dup = (int) get_transient( $dk );
		if ( $dup && ( $old = get_post( $dup ) ) && 'trash' !== $old->post_status ) {
			wp_send_json( array( 'ok' => true, 'msg' => self::shape( $old, $uid ) ) );
		}
		$set = MRSH_Manage::get();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $set['words'] ) as $w ) {
			if ( '' !== trim( $w ) && false !== stripos( $text, trim( $w ) ) ) {
				$no( 'This message contains a word that is not allowed.' );
			}
		}
		$k = 'mrt_lim_msg_' . $uid . '_' . gmdate( 'Ymd' ); // the same daily count as messages sent from a profile
		$n = (int) get_transient( $k );
		if ( $n >= (int) $set['msg'] ) {
			$no( 'Daily limit reached. Try again tomorrow.' );
		}
		set_transient( $k, $n + 1, DAY_IN_SECONDS );
		$id = MRSH_Members::send( $uid, $with, $text, $op->ID );
		if ( ! $id ) {
			$no( 'Could not send. Please try again.' );
		}
		set_transient( $dk, (int) $id, 8 );
		MRSH_Members::notify( $with, 'msg' );
		$m = get_post( $id );
		wp_send_json( array( 'ok' => true, 'msg' => self::shape( $m, $uid ) ) );
	}

	/** Unread total, used to keep the badge on the bottom bar up to date. */
	public static function unread() {
		$uid = self::uid();
		wp_send_json( array( 'ok' => true, 'unread' => (int) MRSH_Members::unread_count( $uid ) ) );
	}
}
MRSH_Mem_Chat::init();
