<?php
/**
 * Delete my account (3.101.148): a member can remove their own account from My account. Needs the password and a tick.
 * Removes the profile(s), the messages they wrote and the login. Admins cannot use it (so the owner is never deleted by mistake).
 * Can be switched off in Feature switches.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Delacct {

	public static function init() {
		add_action( 'admin_post_mrsh_delacct', array( __CLASS__, 'go' ) );
	}

	public static function box() {
		if ( ! is_user_logged_in() || current_user_can( 'manage_options' ) ) {
			return;
		}
		$err = isset( $_GET['delerr'] ) ? 1 : 0; // phpcs:ignore WordPress.Security.NonceVerification
		echo '<div class="box" id="mrsh-del"><h3>Delete my account</h3><p style="color:#666;font-size:.92rem">This removes your profile, your messages and your login for good. It cannot be undone. If you only want a break, you can leave the profile as it is.</p>';
		if ( $err ) {
			echo '<p style="color:#b91c1c;font-weight:700">The password was wrong or the box was not ticked. Nothing was deleted.</p>';
		}
		echo '<details><summary style="cursor:pointer;font-weight:700;color:#b91c1c">I want to delete my account</summary><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="margin-top:10px"><input type="hidden" name="action" value="mrsh_delacct">';
		wp_nonce_field( 'mrsh_delacct' );
		echo '<label>Your password</label><input type="password" name="pw" autocomplete="current-password" required><p><label><input type="checkbox" name="sure" value="1" style="width:auto"> Yes, delete my account and everything on it</label></p><button class="btn" style="background:#b91c1c">Delete my account</button></form></details></div>';
	}

	public static function go() {
		if ( ! is_user_logged_in() || current_user_can( 'manage_options' ) ) {
			wp_safe_redirect( home_url( '/' ) );
			exit;
		}
		check_admin_referer( 'mrsh_delacct' );
		$u    = wp_get_current_user();
		$back = add_query_arg( array( 'delerr' => 1, 'tab' => 'settings' ), ( function_exists( 'mrt_link' ) ? mrt_link( 'myaccount', '/my-account/' ) : home_url( '/my-account/' ) ) ) . '#mrsh-del';
		if ( empty( $_POST['sure'] ) || empty( $_POST['pw'] ) || ! wp_check_password( wp_unslash( $_POST['pw'] ), $u->user_pass, $u->ID ) ) { // phpcs:ignore
			wp_safe_redirect( $back );
			exit;
		}
		$ids = get_posts( array( 'post_type' => array( 'listing_type', 'ppt_message' ), 'post_status' => 'any', 'author' => $u->ID, 'numberposts' => -1, 'fields' => 'ids' ) );
		foreach ( $ids as $id ) {
			wp_delete_post( (int) $id, true );
		}
		$name = $u->user_login;
		require_once ABSPATH . 'wp-admin/includes/user.php';
		wp_logout();
		wp_delete_user( $u->ID );
		wp_mail( get_option( 'admin_email' ), 'A member deleted their account', 'Member "' . $name . '" deleted their own account on ' . home_url( '/' ) . '.' );
		wp_safe_redirect( home_url( '/?acct_deleted=1' ) );
		exit;
	}
}
MRSH_Delacct::init();
