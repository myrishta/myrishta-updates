<?php
/**
 * Thin content checker: lists guides with too few words (ad networks call this "low value content"),
 * and lets you hide them from Google and the sitemap until they are expanded, one by one, in bulk, or all at once.
 * Uses the existing per-post _mrsh_noindex flag. Posts hidden by this tool are remembered (_mrsh_thin_hid) so
 * "Allow again" never touches pages you hid yourself. Posts hidden here also get no ads (the ads checkup skips noindex pages).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Thin {

	const OPT = 'mrsh_thin_min';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 41 );
		add_action( 'admin_post_mrsh_thin_one', array( __CLASS__, 'one' ) );
		add_action( 'admin_post_mrsh_thin_bulk', array( __CLASS__, 'bulk' ) );
		add_action( 'admin_post_mrsh_thin_all', array( __CLASS__, 'all' ) );
		add_action( 'admin_post_mrsh_thin_min', array( __CLASS__, 'save_min' ) );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Thin content', 'Thin content', 'manage_options', 'mrsh-thin', array( __CLASS__, 'page' ) );
	}

	public static function min() {
		$v = (int) get_option( self::OPT, 400 );
		return max( 100, min( 1500, $v ) );
	}

	/** Words in a post, works for Urdu and English (splits on spaces, not letters). */
	public static function words( $p ) {
		$t = wp_strip_all_tags( strip_shortcodes( (string) $p->post_content ) );
		$t = html_entity_decode( $t, ENT_QUOTES, 'UTF-8' );
		return (int) preg_match_all( '/\S+/u', $t );
	}

	private static function guard( $action ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( $action );
	}

	private static function back( $msg = '' ) {
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-thin' . ( $msg ? '&done=' . rawurlencode( $msg ) : '' ) ) );
		exit;
	}

	/** Hide ($hide true) or allow a post. Returns true when something changed. */
	private static function set( $id, $hide ) {
		$id = (int) $id;
		if ( ! $id || 'post' !== get_post_type( $id ) ) {
			return false;
		}
		if ( $hide ) {
			if ( get_post_meta( $id, '_mrsh_noindex', true ) ) {
				return false; // already hidden (by you or another tool): leave it alone
			}
			update_post_meta( $id, '_mrsh_noindex', '1' );
			update_post_meta( $id, '_mrsh_thin_hid', '1' );
		} else {
			delete_post_meta( $id, '_mrsh_noindex' );
			delete_post_meta( $id, '_mrsh_thin_hid' );
		}
		do_action( 'litespeed_purge_post', $id );
		return true;
	}

	/** Posts under the word limit that are published. array( post, words ) */
	public static function thin() {
		$out   = array();
		$limit = self::min();
		foreach ( self::posts() as $p ) {
			$w = self::words( $p );
			if ( $w < $limit ) {
				$out[] = array( $p, $w );
			}
		}
		return $out;
	}

	private static function posts() {
		return get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'numberposts' => 1000, 'orderby' => 'date', 'order' => 'DESC', 'suppress_filters' => true ) );
	}

	public static function one() {
		$id = absint( $_GET['post'] ?? 0 ); // phpcs:ignore
		self::guard( 'mrsh_thin_' . $id );
		$hide = 'hide' === ( $_GET['mode'] ?? '' ); // phpcs:ignore
		self::set( $id, $hide );
		self::back( $hide ? 'Hidden from Google.' : 'Allowed in Google again.' );
	}

	public static function bulk() {
		self::guard( 'mrsh_thin_bulk' );
		$hide = 'hide' === ( $_POST['mode'] ?? '' ); // phpcs:ignore
		$n    = 0;
		foreach ( array_map( 'absint', (array) ( $_POST['ids'] ?? array() ) ) as $id ) { // phpcs:ignore
			if ( self::set( $id, $hide ) ) {
				++$n;
			}
		}
		self::back( $n . ( $hide ? ' hidden from Google.' : ' allowed in Google again.' ) );
	}

	public static function all() {
		self::guard( 'mrsh_thin_all' );
		$hide = 'hide' === ( $_POST['mode'] ?? '' ); // phpcs:ignore
		$n    = 0;
		if ( $hide ) {
			foreach ( self::thin() as $r ) {
				if ( self::set( $r[0]->ID, true ) ) {
					++$n;
				}
			}
			$msg = $n . ' thin guides hidden from Google until you expand them.';
		} else {
			foreach ( self::posts() as $p ) {
				if ( get_post_meta( $p->ID, '_mrsh_thin_hid', true ) && self::set( $p->ID, false ) ) {
					++$n;
				}
			}
			$msg = $n . ' guides allowed in Google again.';
		}
		self::back( $msg );
	}

	public static function save_min() {
		self::guard( 'mrsh_thin_min' );
		update_option( self::OPT, max( 100, min( 1500, (int) ( $_POST['min'] ?? 400 ) ) ), false ); // phpcs:ignore
		self::back( 'Word limit saved.' );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$limit = self::min();
		$rows  = array();
		$thin  = 0;
		$hid   = 0;
		foreach ( self::posts() as $p ) {
			$w  = self::words( $p );
			$nx = (bool) get_post_meta( $p->ID, '_mrsh_noindex', true );
			if ( $w < $limit ) {
				++$thin;
			}
			if ( $nx && get_post_meta( $p->ID, '_mrsh_thin_hid', true ) ) {
				++$hid;
			}
			$rows[] = array( $p, $w, $nx );
		}
		usort( $rows, function ( $a, $b ) { return $a[1] <=> $b[1]; } );
		$total = count( $rows );
		$post  = esc_url( admin_url( 'admin-post.php' ) );
		MRSH_Admin::open( 'Thin content', 'Ad networks and Google refuse sites with many very short guides. Expand them, or hide them until they are ready.' );
		if ( ! empty( $_GET['done'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( wp_unslash( $_GET['done'] ) ) . '</p></div>'; // phpcs:ignore
		}
		echo '<div class="mrsh-grid mrsh-grid-3">';
		echo MRSH_Admin::stat( 'Guides', (int) $total, 'published guides' ); // phpcs:ignore
		echo MRSH_Admin::stat( 'Under ' . (int) $limit . ' words', (int) $thin, $thin ? 'need more advice or hiding' : 'all guides are long enough' ); // phpcs:ignore
		echo MRSH_Admin::stat( 'Hidden by this tool', (int) $hid, 'not in Google, sitemap or ads' ); // phpcs:ignore
		echo '</div>';

		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>Rules and quick actions</h2></div>';
		echo '<p class="mrsh-muted">Guides under the word limit are listed first. 600 words or more is best. Hidden guides stay on your site for visitors but get no ads.</p>';
		echo '<form method="post" action="' . $post . '" class="mrsh-toolbar">';
		wp_nonce_field( 'mrsh_thin_min' );
		echo '<input type="hidden" name="action" value="mrsh_thin_min"><label>Word limit <input type="number" name="min" min="100" max="1500" step="50" value="' . (int) $limit . '" style="width:90px"></label><button class="button">Save limit</button></form>';
		echo '<div class="mrsh-actions">';
		foreach ( array( array( 'hide', 'Hide all thin guides from Google', true ), array( 'allow', 'Allow all hidden guides again', false ) ) as $b ) {
			echo '<form method="post" action="' . $post . '" class="mrsh-inline">';
			wp_nonce_field( 'mrsh_thin_all' );
			echo '<input type="hidden" name="action" value="mrsh_thin_all"><input type="hidden" name="mode" value="' . esc_attr( $b[0] ) . '"><button class="button ' . ( $b[2] ? 'button-primary' : '' ) . '">' . esc_html( $b[1] ) . '</button></form>';
		}
		echo '</div><p class="description">"Allow all hidden guides again" only undoes what this page hid. Guides you hid yourself are not touched.</p></div>';

		echo '<div class="mrsh-card"><div class="mrsh-card-head"><h2>All guides, shortest first</h2></div><form method="post" action="' . $post . '">';
		wp_nonce_field( 'mrsh_thin_bulk' );
		echo '<input type="hidden" name="action" value="mrsh_thin_bulk"><div class="mrsh-toolbar"><button class="button" name="mode" value="hide">Hide ticked from Google</button><button class="button" name="mode" value="allow">Allow ticked again</button><label><input type="checkbox" onclick="document.querySelectorAll(\'.mrsh-thin-cb\').forEach(function(c){c.checked=this.checked}.bind(this))"> Tick all</label></div>';
		echo '<div style="overflow-x:auto"><table class="widefat striped mrsh-table"><thead><tr><th></th><th>Guide</th><th>Words</th><th>Size</th><th>In Google</th><th>Date</th><th></th></tr></thead><tbody>';
		foreach ( $rows as $r ) {
			$p    = $r[0];
			$mode = $r[2] ? 'allow' : 'hide';
			$url  = wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_thin_one&mode=' . $mode . '&post=' . (int) $p->ID ), 'mrsh_thin_' . (int) $p->ID );
			$size = $r[1] < $limit ? MRSH_Admin::badge( 'fail', 'Thin' ) : MRSH_Admin::badge( 'pass', 'OK' );
			echo '<tr><td><input type="checkbox" class="mrsh-thin-cb" name="ids[]" value="' . (int) $p->ID . '"></td>'
				. '<td><a href="' . esc_url( (string) get_edit_post_link( $p->ID ) ) . '">' . esc_html( get_the_title( $p ) ) . '</a></td>'
				. '<td>' . (int) $r[1] . '</td><td>' . $size . '</td>' // phpcs:ignore
				. '<td>' . ( $r[2] ? MRSH_Admin::badge( 'unknown', 'Hidden' ) : MRSH_Admin::badge( 'pass', 'Visible' ) ) . '</td>' // phpcs:ignore
				. '<td>' . esc_html( get_the_date( 'Y-m-d', $p ) ) . '</td>'
				. '<td style="white-space:nowrap"><a class="button button-small" href="' . esc_url( (string) get_edit_post_link( $p->ID ) ) . '">Expand</a> <a class="button button-small" href="' . esc_url( $url ) . '">' . ( $r[2] ? 'Allow again' : 'Hide' ) . '</a></td></tr>';
		}
		echo '</tbody></table></div></form></div>';
		MRSH_Admin::close();
	}
}
MRSH_Thin::init();
