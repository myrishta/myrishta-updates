<?php
/**
 * Theme Options: a premium-theme style control panel (colours, fonts, layout, header, hero, buttons, cards, footer,
 * extras, custom code, presets, export/import, reset). Saved in the database in option mrsh_topt and printed as CSS
 * after the theme CSS, so it works with the My Rishta theme without editing any file.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Mem_ThemeOpts {

	const OPT = 'mrsh_topt';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 24 );
		add_action( 'admin_post_mrsh_topt_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_mrsh_topt_tools', array( __CLASS__, 'tools' ) );
		add_action( 'wp_head', array( __CLASS__, 'css' ), 99 );
		add_action( 'wp_head', array( __CLASS__, 'head_code' ), 100 );
		add_action( 'wp_footer', array( __CLASS__, 'foot_code' ), 100 );
		add_action( 'wp_footer', array( __CLASS__, 'top_btn' ), 50 );
		add_filter( 'body_class', array( __CLASS__, 'body' ) );
		add_action( 'login_head', array( __CLASS__, 'login' ) );
		add_filter( 'show_admin_bar', array( __CLASS__, 'adminbar' ) );
		add_action( 'admin_enqueue_scripts', function ( $h ) {
			if ( false !== strpos( (string) $h, 'mrsh-themeopts' ) ) {
				wp_enqueue_style( 'wp-color-picker' );
				wp_enqueue_script( 'wp-color-picker' );
			}
		} );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Theme Options', 'Theme Options', 'manage_options', 'mrsh-themeopts', array( __CLASS__, 'page' ) );
	}

	private static function fonts() {
		return array(
			'system'  => array( 'System default', '-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif', '' ),
			'inter'   => array( 'Inter', '"Inter",sans-serif', 'Inter:wght@400;500;600;700;800' ),
			'poppins' => array( 'Poppins', '"Poppins",sans-serif', 'Poppins:wght@400;500;600;700' ),
			'nunito'  => array( 'Nunito', '"Nunito",sans-serif', 'Nunito:wght@400;600;700;800' ),
			'lato'    => array( 'Lato', '"Lato",sans-serif', 'Lato:wght@400;700;900' ),
			'dmsans'  => array( 'DM Sans', '"DM Sans",sans-serif', 'DM+Sans:wght@400;500;700' ),
			'mont'    => array( 'Montserrat', '"Montserrat",sans-serif', 'Montserrat:wght@400;500;600;700;800' ),
			'playfair' => array( 'Playfair Display (serif)', '"Playfair Display",Georgia,serif', 'Playfair+Display:wght@500;600;700' ),
			'lora'    => array( 'Lora (serif)', '"Lora",Georgia,serif', 'Lora:wght@400;500;600;700' ),
			'nastaliq' => array( 'Noto Nastaliq Urdu', '"Noto Nastaliq Urdu",serif', 'Noto+Nastaliq+Urdu:wght@400;500;700' ),
			'naskh'   => array( 'Noto Naskh Arabic', '"Noto Naskh Arabic",serif', 'Noto+Naskh+Arabic:wght@400;500;700' ),
		);
	}

	/** Field list: key => [tab, label, type, default, help/choices]. */
	public static function fields() {
		$f   = array_map( function ( $a ) { return $a[0]; }, self::fonts() );
		$sh  = array( 'none' => 'None', 'soft' => 'Soft', 'strong' => 'Strong' );
		$btn = array( 'sq' => 'Square', 'round' => 'Rounded', 'pill' => 'Pill' );
		return array(
			// Colours.
			'col_brand'  => array( 'colors', 'Main colour', 'color', '', 'Buttons, links, highlights' ),
			'col_brand2' => array( 'colors', 'Second colour', 'color', '', 'Second end of gradients' ),
			'col_accent' => array( 'colors', 'Accent colour (gold)', 'color', '', 'Badges and small highlights' ),
			'col_text'   => array( 'colors', 'Text colour', 'color', '' ),
			'col_muted'  => array( 'colors', 'Soft text colour', 'color', '' ),
			'col_bg'     => array( 'colors', 'Page background', 'color', '' ),
			'col_soft'   => array( 'colors', 'Section background', 'color', '' ),
			'col_card'   => array( 'colors', 'Card background', 'color', '' ),
			'col_line'   => array( 'colors', 'Border colour', 'color', '' ),
			'col_link'   => array( 'colors', 'Link colour', 'color', '' ),
			'col_btntxt' => array( 'colors', 'Button text colour', 'color', '' ),
			// Typography.
			'font_body'  => array( 'type', 'Body font', 'select', 'system', $f ),
			'font_head'  => array( 'type', 'Heading font', 'select', 'system', $f ),
			'font_ur'    => array( 'type', 'Urdu font', 'select', 'nastaliq', $f ),
			'fs_base'    => array( 'type', 'Base text size (px)', 'num', 16, array( 13, 20 ) ),
			'lh'         => array( 'type', 'Line height (x10, 14 = 1.4)', 'num', 16, array( 12, 22 ) ),
			'hw'         => array( 'type', 'Heading weight', 'select', '700', array( '500' => 'Medium', '600' => 'Semi bold', '700' => 'Bold', '800' => 'Extra bold' ) ),
			'ur_scale'   => array( 'type', 'Urdu text size (%)', 'num', 100, array( 80, 140 ) ),
			// Layout.
			'wrap_w'     => array( 'layout', 'Page width (px)', 'num', 1180, array( 960, 1600 ) ),
			'radius'     => array( 'layout', 'Corner roundness (px)', 'num', 18, array( 0, 32 ) ),
			'shadow'     => array( 'layout', 'Card shadow', 'select', 'soft', $sh ),
			'gap'        => array( 'layout', 'Space between cards (px)', 'num', 16, array( 6, 40 ) ),
			'sec_pad'    => array( 'layout', 'Space between sections (px)', 'num', 36, array( 12, 100 ) ),
			'card_ratio' => array( 'layout', 'Profile photo shape', 'select', 'tall', array( 'tall' => 'Tall (3:4)', 'square' => 'Square', 'wide' => 'Wide (4:3)' ) ),
			'card_hover' => array( 'layout', 'Lift cards on hover', 'check', 1 ),
			'card_border' => array( 'layout', 'Show card border', 'check', 1 ),
			// Buttons.
			'btn_shape'  => array( 'buttons', 'Button shape', 'select', 'pill', $btn ),
			'btn_size'   => array( 'buttons', 'Button size', 'select', 'normal', array( 'small' => 'Small', 'normal' => 'Normal', 'large' => 'Large' ) ),
			'btn_grad'   => array( 'buttons', 'Gradient buttons', 'check', 1 ),
			'btn_upper'  => array( 'buttons', 'Capital letters on buttons', 'check', 0 ),
			'btn_shadow' => array( 'buttons', 'Button shadow', 'check', 0 ),
			'inp_round'  => array( 'buttons', 'Form field roundness (px)', 'num', 12, array( 0, 28 ) ),
			// Header.
			'h_sticky'   => array( 'header', 'Keep header fixed on scroll', 'check', 1 ),
			'h_style'    => array( 'header', 'Header style', 'select', 'light', array( 'light' => 'Light', 'brand' => 'Main colour', 'dark' => 'Dark', 'glass' => 'Glass (blur)' ) ),
			'h_height'   => array( 'header', 'Header height (px)', 'num', 64, array( 44, 110 ) ),
			'h_logo'     => array( 'header', 'Logo height (px)', 'num', 38, array( 20, 90 ) ),
			'h_shadow'   => array( 'header', 'Line under header', 'check', 1 ),
			'h_bar_bg'   => array( 'header', 'Announcement bar colour', 'color', '' ),
			'h_bar_tx'   => array( 'header', 'Announcement text colour', 'color', '' ),
			// Hero.
			'hero_pad'   => array( 'hero', 'Hero height (px padding)', 'num', 56, array( 16, 160 ) ),
			'hero_align' => array( 'hero', 'Hero text', 'select', 'center', array( 'center' => 'Centre', 'left' => 'Left' ) ),
			'hero_c1'    => array( 'hero', 'Hero background colour 1', 'color', '' ),
			'hero_c2'    => array( 'hero', 'Hero background colour 2', 'color', '' ),
			'hero_tx'    => array( 'hero', 'Hero text colour', 'color', '' ),
			'hero_img'   => array( 'hero', 'Hero background picture address', 'url', '', 'Optional. Paste a Media Library link.' ),
			'hero_ov'    => array( 'hero', 'Picture darkness (%)', 'num', 35, array( 0, 90 ) ),
			'hero_size'  => array( 'hero', 'Hero heading size (px)', 'num', 40, array( 24, 72 ) ),
			// Footer.
			'f_bg'       => array( 'footer', 'Footer background', 'color', '' ),
			'f_tx'       => array( 'footer', 'Footer text colour', 'color', '' ),
			'f_link'     => array( 'footer', 'Footer link colour', 'color', '' ),
			'f_pad'      => array( 'footer', 'Footer space (px)', 'num', 40, array( 12, 120 ) ),
			// Extras.
			'x_top'      => array( 'extras', 'Back to top button', 'check', 1 ),
			'x_smooth'   => array( 'extras', 'Smooth scrolling', 'check', 1 ),
			'x_anim'     => array( 'extras', 'Fade-in effect on cards', 'check', 0 ),
			'x_abar'     => array( 'extras', 'Hide the black WordPress bar for members', 'check', 1 ),
			'x_login'    => array( 'extras', 'Brand the login page (logo and colours)', 'check', 1 ),
			'x_noselect' => array( 'extras', 'Stop copying of profile photos by long-press', 'check', 0 ),
			'x_toptxt'   => array( 'extras', 'Back to top button colour', 'color', '' ),
			// Code.
			'code_css'   => array( 'code', 'Your own CSS', 'area', '', 'Added after everything else.' ),
			'code_head'  => array( 'code', 'Code in the head', 'area', '', 'For example a verification tag or analytics. Only add code you trust.' ),
			'code_foot'  => array( 'code', 'Code before the end of the page', 'area', '', 'For example a chat widget script. Only add code you trust.' ),
		);
	}

	private static function tabs() {
		return array( 'colors' => 'Colours', 'type' => 'Fonts', 'layout' => 'Layout and cards', 'buttons' => 'Buttons and forms', 'header' => 'Header', 'hero' => 'Hero', 'footer' => 'Footer', 'extras' => 'Extras', 'code' => 'Custom code', 'presets' => 'Presets', 'tools' => 'Backup and reset' );
	}

	public static function presets() {
		return array(
			'Rose'    => array( 'col_brand' => '#e11d74', 'col_brand2' => '#7c3aed', 'hero_c1' => '#ffe4ef', 'hero_c2' => '#efe5ff' ),
			'Emerald' => array( 'col_brand' => '#0f7a55', 'col_brand2' => '#14b8a6', 'hero_c1' => '#d9f5ea', 'hero_c2' => '#e0f7f4' ),
			'Royal'   => array( 'col_brand' => '#4338ca', 'col_brand2' => '#9333ea', 'hero_c1' => '#e5e7ff', 'hero_c2' => '#f1e5ff' ),
			'Sunset'  => array( 'col_brand' => '#ea580c', 'col_brand2' => '#db2777', 'hero_c1' => '#ffedd5', 'hero_c2' => '#ffe0ec' ),
			'Ocean'   => array( 'col_brand' => '#0369a1', 'col_brand2' => '#06b6d4', 'hero_c1' => '#dbeefe', 'hero_c2' => '#d9f6fb' ),
			'Gold'    => array( 'col_brand' => '#b8860b', 'col_brand2' => '#e0a800', 'col_accent' => '#b8860b', 'hero_c1' => '#fff4d1', 'hero_c2' => '#ffeacb' ),
			'Midnight' => array( 'col_brand' => '#818cf8', 'col_brand2' => '#c084fc', 'col_text' => '#f2f2f7', 'col_muted' => '#a1a1aa', 'col_bg' => '#0b0b12', 'col_soft' => '#12121c', 'col_card' => '#171724', 'col_line' => '#2a2a3b', 'hero_c1' => '#1b1b2e', 'hero_c2' => '#241a38', 'hero_tx' => '#f2f2f7', 'f_bg' => '#07070c', 'f_tx' => '#c8c8d4' ),
		);
	}

	public static function get( $k = null ) {
		static $o = null;
		if ( null === $o ) {
			$s = get_option( self::OPT, array() );
			$o = is_array( $s ) ? $s : array();
			foreach ( self::fields() as $key => $d ) {
				if ( ! isset( $o[ $key ] ) ) {
					$o[ $key ] = $d[3];
				}
			}
		}
		return null === $k ? $o : ( $o[ $k ] ?? '' );
	}

	/* ---------- Front end ---------- */

	private static function on() {
		$s = get_option( self::OPT, null );
		return is_array( $s ) && $s;
	}

	public static function css() {
		if ( ! self::on() ) {
			return;
		}
		$g = function ( $k ) { return self::get( $k ); };
		$fonts = self::fonts();
		$link  = array();
		foreach ( array( 'font_body', 'font_head', 'font_ur' ) as $k ) {
			$fk = $g( $k );
			if ( isset( $fonts[ $fk ] ) && $fonts[ $fk ][2] && ! isset( $link[ $fk ] ) ) {
				$link[ $fk ] = 'family=' . $fonts[ $fk ][2];
			}
		}
		if ( $link ) {
			echo '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link rel="stylesheet" href="' . esc_url( 'https://fonts.googleapis.com/css2?' . implode( '&', $link ) . '&display=swap' ) . '">' . "\n"; // phpcs:ignore
		}
		$v = array();
		$map = array( 'col_brand' => '--brand', 'col_accent' => '--gold', 'col_text' => '--ink', 'col_muted' => '--mut', 'col_bg' => '--bg', 'col_soft' => '--soft', 'col_card' => '--card', 'col_line' => '--line' );
		foreach ( $map as $k => $var ) {
			if ( $g( $k ) ) {
				$v[] = $var . ':' . $g( $k );
			}
		}
		if ( $g( 'col_brand2' ) ) {
			$v[] = '--s:' . $g( 'col_brand2' );
		}
		if ( $g( 'col_brand' ) ) {
			$v[] = '--p:' . $g( 'col_brand' );
		}
		$v[] = '--r:' . (int) $g( 'radius' ) . 'px';
		$c   = ':root{' . implode( ';', $v ) . '}';
		$b1  = $g( 'col_brand' );
		$b2  = $g( 'col_brand2' ) ? $g( 'col_brand2' ) : $b1;
		$bt  = $g( 'col_btntxt' ) ? $g( 'col_btntxt' ) : '#fff';
		$bsz = array( 'small' => '8px 14px;font-size:.85rem', 'normal' => '11px 20px;font-size:.95rem', 'large' => '15px 28px;font-size:1.05rem' );
		$shp = array( 'sq' => '6px', 'round' => '12px', 'pill' => '999px' );
		$btn = '.btn,.nav a.btn,button.btn,a.btn{border-radius:' . $shp[ $g( 'btn_shape' ) ?: 'pill' ] . ';padding:' . $bsz[ $g( 'btn_size' ) ?: 'normal' ] . ';' . ( $g( 'btn_upper' ) ? 'text-transform:uppercase;letter-spacing:.04em;' : '' ) . ( $g( 'btn_shadow' ) ? 'box-shadow:0 6px 16px rgba(0,0,0,.16);' : '' ) . '}';
		if ( $b1 ) {
			$sel = '.btn,.nav a.btn,.pager .current,.tabs a.cur,.chip.on,.hsearch .btn,.btn.alt';
			$btn .= $sel . '{background:' . ( $g( 'btn_grad' ) ? "linear-gradient(90deg,$b1,$b2)" : $b1 ) . ';color:' . $bt . '}';
		}
		$c .= $btn;
		$c .= 'html{font-size:' . (int) $g( 'fs_base' ) . 'px;' . ( $g( 'x_smooth' ) ? 'scroll-behavior:smooth;' : '' ) . '}';
		$c .= 'body{font-family:' . ( $fonts[ $g( 'font_body' ) ][1] ?? $fonts['system'][1] ) . ';line-height:' . ( (int) $g( 'lh' ) / 10 ) . '}';
		$c .= 'h1,h2,h3,h4,.shead h2,.hero h1{font-family:' . ( $fonts[ $g( 'font_head' ) ][1] ?? $fonts['system'][1] ) . ';font-weight:' . (int) $g( 'hw' ) . '}';
		$ur = $fonts[ $g( 'font_ur' ) ][1] ?? $fonts['nastaliq'][1];
		$c .= 'html.ur body,html.ur body *,[lang^="ur"],.ur{font-family:' . $ur . '}html.ur body{font-size:' . (int) $g( 'ur_scale' ) . '%;line-height:1.9}';
		$c .= '.wrap{max-width:' . (int) $g( 'wrap_w' ) . 'px}';
		$sh = array( 'none' => 'none', 'soft' => '0 2px 14px rgba(20,20,50,.07)', 'strong' => '0 10px 30px rgba(20,20,50,.18)' );
		$c .= '.card,.box,.card2,.feat,.gcard,.plan{border-radius:' . (int) $g( 'radius' ) . 'px;box-shadow:' . $sh[ $g( 'shadow' ) ?: 'soft' ] . ( $g( 'card_border' ) ? '' : ';border-color:transparent' ) . '}';
		$c .= '.grid{gap:' . (int) $g( 'gap' ) . 'px}section.sec,.sec{padding-top:' . (int) $g( 'sec_pad' ) . 'px;padding-bottom:' . (int) $g( 'sec_pad' ) . 'px}';
		$ar = array( 'tall' => '3/4', 'square' => '1/1', 'wide' => '4/3' );
		$c .= '.card .ph{aspect-ratio:' . $ar[ $g( 'card_ratio' ) ?: 'tall' ] . ';object-fit:cover}';
		if ( $g( 'card_hover' ) ) {
			$c .= '.card,.gcard,.plan{transition:transform .2s,box-shadow .2s}.card:hover,.gcard:hover,.plan:hover{transform:translateY(-4px)}';
		}
		$c .= 'input[type=text],input[type=email],input[type=password],input[type=search],input[type=tel],input[type=number],select,textarea{border-radius:' . (int) $g( 'inp_round' ) . 'px}';
		if ( $g( 'col_link' ) ) {
			$c .= 'a{color:' . $g( 'col_link' ) . '}.btn,.nav a.btn{color:' . $bt . '}';
		}
		// Header.
		$hs = $g( 'h_style' );
		$c .= '.site-head{' . ( $g( 'h_sticky' ) ? 'position:sticky;top:0;z-index:60;' : 'position:relative;' ) . 'min-height:' . (int) $g( 'h_height' ) . 'px;' . ( $g( 'h_shadow' ) ? '' : 'border-bottom:0;box-shadow:none;' ) . '}.site-head .wrap{min-height:' . (int) $g( 'h_height' ) . 'px}.site-head .brand img{max-height:' . (int) $g( 'h_logo' ) . 'px;width:auto}';
		if ( 'brand' === $hs && $b1 ) {
			$c .= ".site-head{background:linear-gradient(90deg,$b1,$b2);color:#fff}.site-head a,.site-head .nav a{color:#fff}.site-head .nav a.btn{background:#fff;color:$b1}";
		} elseif ( 'dark' === $hs ) {
			$c .= '.site-head{background:#14141c;color:#f2f2f7;border-color:#26263a}.site-head a,.site-head .nav a{color:#f2f2f7}';
		} elseif ( 'glass' === $hs ) {
			$c .= '.site-head{background:rgba(255,255,255,.72);-webkit-backdrop-filter:saturate(180%) blur(16px);backdrop-filter:saturate(180%) blur(16px)}';
		}
		if ( $g( 'h_bar_bg' ) ) {
			$c .= '.annbar{background:' . $g( 'h_bar_bg' ) . '}';
		}
		if ( $g( 'h_bar_tx' ) ) {
			$c .= '.annbar,.annbar a{color:' . $g( 'h_bar_tx' ) . '}';
		}
		// Hero.
		$h1 = $g( 'hero_c1' );
		$h2 = $g( 'hero_c2' ) ? $g( 'hero_c2' ) : $h1;
		$bg = $h1 ? "linear-gradient(120deg,$h1,$h2)" : '';
		if ( $g( 'hero_img' ) ) {
			$o  = max( 0, min( 90, (int) $g( 'hero_ov' ) ) ) / 100;
			$bg = 'linear-gradient(rgba(0,0,0,' . $o . '),rgba(0,0,0,' . $o . ')),url("' . esc_url( $g( 'hero_img' ) ) . '") center/cover no-repeat';
		}
		$c .= '.hero{padding-top:' . (int) $g( 'hero_pad' ) . 'px;padding-bottom:' . (int) $g( 'hero_pad' ) . 'px;text-align:' . ( 'left' === $g( 'hero_align' ) ? 'left' : 'center' ) . ( $bg ? ';background:' . $bg : '' ) . ( $g( 'hero_tx' ) ? ';color:' . $g( 'hero_tx' ) : ( $g( 'hero_img' ) ? ';color:#fff' : '' ) ) . '}.hero h1{font-size:clamp(1.5rem,4.5vw,' . (int) $g( 'hero_size' ) / 16 . 'rem);' . ( $g( 'hero_tx' ) || $g( 'hero_img' ) ? '-webkit-text-fill-color:currentColor;background:none;' : '' ) . '}' . ( 'left' === $g( 'hero_align' ) ? '.hero p{margin-left:0}' : '.hero p{margin-left:auto;margin-right:auto}' );
		// Footer.
		$c .= 'footer.site-foot{' . ( $g( 'f_bg' ) ? 'background:' . $g( 'f_bg' ) . ';' : '' ) . ( $g( 'f_tx' ) ? 'color:' . $g( 'f_tx' ) . ';' : '' ) . 'padding-top:' . (int) $g( 'f_pad' ) . 'px;padding-bottom:' . (int) $g( 'f_pad' ) . 'px}';
		if ( $g( 'f_link' ) ) {
			$c .= 'footer a{color:' . $g( 'f_link' ) . '}';
		}
		if ( $g( 'x_anim' ) ) {
			$c .= '@keyframes mrfade{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}.card,.gcard,.plan,.feat{animation:mrfade .5s ease both}@media(prefers-reduced-motion:reduce){*{animation:none!important}}';
		}
		if ( $g( 'x_noselect' ) ) {
			$c .= '.card img,.gallery img{-webkit-touch-callout:none;-webkit-user-select:none;user-select:none}';
		}
		$c .= '#mr-top{position:fixed;right:16px;bottom:78px;width:44px;height:44px;border-radius:50%;border:0;cursor:pointer;display:none;align-items:center;justify-content:center;font-size:20px;line-height:1;z-index:55;background:' . ( $g( 'x_toptxt' ) ? $g( 'x_toptxt' ) : ( $b1 ? $b1 : '#111' ) ) . ';color:#fff;box-shadow:0 6px 18px rgba(0,0,0,.25)}#mr-top.on{display:flex}';
		if ( $g( 'code_css' ) ) {
			$c .= str_ireplace( '</style', '', (string) $g( 'code_css' ) );
		}
		echo '<style id="mrsh-topt">' . $c . "</style>\n"; // phpcs:ignore
	}

	public static function head_code() {
		$x = trim( (string) self::get( 'code_head' ) );
		if ( $x && ! is_admin() ) {
			echo $x . "\n"; // phpcs:ignore -- admin-entered code
		}
	}

	public static function foot_code() {
		$x = trim( (string) self::get( 'code_foot' ) );
		if ( $x && ! is_admin() ) {
			echo $x . "\n"; // phpcs:ignore
		}
	}

	public static function top_btn() {
		if ( ! self::on() || ! self::get( 'x_top' ) ) {
			return;
		}
		echo '<button type="button" id="mr-top" aria-label="Back to top">&#8593;</button><script>(function(){var b=document.getElementById("mr-top");if(!b)return;window.addEventListener("scroll",function(){b.classList.toggle("on",window.scrollY>500)},{passive:true});b.onclick=function(){window.scrollTo({top:0,behavior:"smooth"})}})();</script>';
	}

	public static function body( $c ) {
		if ( self::on() ) {
			$c[] = 'mrt-opts';
			$c[] = 'hdr-' . sanitize_html_class( self::get( 'h_style' ) );
		}
		return $c;
	}

	public static function adminbar( $show ) {
		if ( self::on() && self::get( 'x_abar' ) && ! current_user_can( 'edit_posts' ) ) {
			return false;
		}
		return $show;
	}

	public static function login() {
		if ( ! self::on() || ! self::get( 'x_login' ) ) {
			return;
		}
		$logo = function_exists( 'mrt_site' ) ? mrt_site( 'logo', '' ) : '';
		$b1   = self::get( 'col_brand' ) ? self::get( 'col_brand' ) : '#e11d74';
		$b2   = self::get( 'col_brand2' ) ? self::get( 'col_brand2' ) : $b1;
		echo '<style>body.login{background:linear-gradient(135deg,' . esc_attr( $b1 ) . '22,' . esc_attr( $b2 ) . '22)}.login h1 a{' . ( $logo ? 'background-image:url(' . esc_url( $logo ) . ');' : '' ) . 'background-size:contain;width:120px;height:90px}.login form{border-radius:18px;border:0;box-shadow:0 10px 30px rgba(0,0,0,.1)}.wp-core-ui .button-primary{background:' . esc_attr( $b1 ) . ';border-color:' . esc_attr( $b1 ) . ';border-radius:999px}.login #backtoblog a,.login #nav a{color:' . esc_attr( $b1 ) . '}</style>'; // phpcs:ignore
	}

	/* ---------- Admin ---------- */

	private static function field( $k, $d ) {
		$v = self::get( $k );
		$n = esc_attr( $k );
		echo '<tr><th><label for="' . $n . '">' . esc_html( $d[1] ) . '</label></th><td>';
		switch ( $d[2] ) {
			case 'color':
				echo '<input type="text" class="mrsh-col" id="' . $n . '" name="' . $n . '" value="' . esc_attr( $v ) . '" data-default-color="">';
				break;
			case 'check':
				echo '<label><input type="checkbox" id="' . $n . '" name="' . $n . '" value="1"' . checked( (int) $v, 1, false ) . '> On</label>';
				break;
			case 'num':
				echo '<input type="number" id="' . $n . '" name="' . $n . '" value="' . (int) $v . '" min="' . (int) $d[4][0] . '" max="' . (int) $d[4][1] . '" style="width:90px">';
				break;
			case 'select':
				echo '<select id="' . $n . '" name="' . $n . '">';
				foreach ( $d[4] as $ok => $ol ) {
					echo '<option value="' . esc_attr( $ok ) . '"' . selected( (string) $v, (string) $ok, false ) . '>' . esc_html( $ol ) . '</option>';
				}
				echo '</select>';
				break;
			case 'area':
				echo '<textarea id="' . $n . '" name="' . $n . '" rows="9" class="large-text code">' . esc_textarea( $v ) . '</textarea>';
				break;
			default:
				echo '<input type="text" id="' . $n . '" name="' . $n . '" value="' . esc_attr( $v ) . '" class="regular-text">';
		}
		if ( 'select' !== $d[2] && 'num' !== $d[2] && ! empty( $d[4] ) && is_string( $d[4] ) ) {
			echo ' <span class="description">' . esc_html( $d[4] ) . '</span>';
		}
		echo '</td></tr>';
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$tabs = self::tabs();
		$tab  = isset( $_GET['tab'] ) && isset( $tabs[ $_GET['tab'] ] ) ? sanitize_key( $_GET['tab'] ) : 'colors'; // phpcs:ignore
		echo '<div class="wrap"><h1>Theme Options</h1>';
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success is-dismissible"><p>Saved. If you use LiteSpeed Cache, click Purge All. <a href="' . esc_url( home_url( '/' ) ) . '" target="_blank">View the website</a></p></div>';
		}
		echo '<div class="mrt-sub">';
		foreach ( $tabs as $k => $l ) {
			echo '<a class="' . ( $k === $tab ? 'on' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=mrsh-themeopts&tab=' . $k ) ) . '">' . esc_html( $l ) . '</a>';
		}
		echo '</div>';
		if ( 'presets' === $tab ) {
			echo '<p>One click sets the colours. You can still change every colour afterwards.</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( 'mrsh_topt_tools' );
			echo '<input type="hidden" name="action" value="mrsh_topt_tools"><div style="display:flex;gap:12px;flex-wrap:wrap">';
			foreach ( self::presets() as $name => $p ) {
				$a = $p['col_brand'];
				$b = $p['col_brand2'];
				echo '<button class="button" name="preset" value="' . esc_attr( $name ) . '" style="padding:12px 18px;height:auto;border-radius:14px"><span style="display:inline-block;width:46px;height:18px;border-radius:9px;vertical-align:middle;margin-right:8px;background:linear-gradient(90deg,' . esc_attr( $a ) . ',' . esc_attr( $b ) . ')"></span>' . esc_html( $name ) . '</button>';
			}
			echo '</div></form></div>';
			return;
		}
		if ( 'tools' === $tab ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( 'mrsh_topt_tools' );
			echo '<input type="hidden" name="action" value="mrsh_topt_tools"><h2>Copy settings</h2><p>Copy these settings to another site, or keep a backup. They are also inside the normal WordPress database backup.</p><textarea readonly rows="6" class="large-text code" onclick="this.select()">' . esc_textarea( wp_json_encode( get_option( self::OPT, array() ) ) ) . '</textarea><h2>Paste settings</h2><textarea name="import" rows="5" class="large-text code" placeholder="Paste settings here"></textarea><p><button class="button button-primary" name="do" value="import">Import settings</button> <button class="button" name="do" value="reset" onclick="return confirm(\'Go back to the default look?\')">Reset to default look</button></p></form></div>';
			return;
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_topt_save"><input type="hidden" name="tab" value="' . esc_attr( $tab ) . '">';
		wp_nonce_field( 'mrsh_topt_save' );
		echo '<table class="form-table">';
		foreach ( self::fields() as $k => $d ) {
			if ( $d[0] === $tab ) {
				self::field( $k, $d );
			}
		}
		echo '</table><p><button class="button button-primary button-large">Save</button> <a class="button button-large" href="' . esc_url( home_url( '/' ) ) . '" target="_blank">View website</a></p></form>';
		// On phones and tablets the WordPress colour picker pops up out of reach, so each box gets a native colour button,
		// ready-made swatches and a clear button instead. Computers keep the normal picker.
		echo '<script>jQuery(function($){var touch=window.matchMedia("(max-width:900px)").matches||("ontouchstart" in window);'
			. 'var P=["#6e1230","#9b1b4b","#c9962f","#12a375","#0f7a55","#1d4ed8","#6366f1","#111827","#ffffff","#f7f1e8"];'
			. '$(".mrsh-col").each(function(){var i=$(this);if(!touch){i.wpColorPicker();return;}'
			. 'var hex=/^#[0-9a-f]{6}$/i.test(i.val())?i.val():"#6e1230";'
			. 'i.css({width:"110px",display:"inline-block",verticalAlign:"middle",fontSize:"16px"});'
			. 'var c=$(\'<input type="color" aria-label="Pick a colour">\').val(hex).css({width:"56px",height:"44px",padding:"2px",border:"1px solid #ccc",borderRadius:"8px",marginLeft:"8px",verticalAlign:"middle",background:"#fff"});'
			. 'var x=$(\'<button type="button" class="button">Clear</button>\').css({marginLeft:"8px",minHeight:"44px"});'
			. 'var w=$(\'<div></div>\').css({display:"flex",flexWrap:"wrap",gap:"8px",margin:"10px 0 4px"});'
			. 'P.forEach(function(k){$(\'<button type="button" aria-label="\'+k+\'"></button>\').css({width:"40px",height:"40px",borderRadius:"50%",border:"2px solid #d1d5db",background:k,padding:0}).on("click",function(){i.val(k).trigger("change");c.val(k);}).appendTo(w);});'
			. 'c.on("input change",function(){i.val(c.val()).trigger("change");});'
			. 'i.on("input change",function(){if(/^#[0-9a-f]{6}$/i.test(i.val())){c.val(i.val());}});'
			. 'x.on("click",function(){i.val("").trigger("change");});'
			. 'i.after(c);c.after(x);x.after(w);});});</script></div>';
	}

	private static function clean( $k, $d, $raw ) {
		switch ( $d[2] ) {
			case 'color':
				return preg_match( '/^#[0-9a-fA-F]{6}$/', trim( $raw ) ) ? trim( $raw ) : '';
			case 'check':
				return $raw ? 1 : 0;
			case 'num':
				return max( (int) $d[4][0], min( (int) $d[4][1], (int) $raw ) );
			case 'select':
				return isset( $d[4][ $raw ] ) ? (string) $raw : (string) $d[3];
			case 'url':
				return esc_url_raw( $raw );
			case 'area':
				return in_array( $k, array( 'code_head', 'code_foot' ), true ) && ! current_user_can( 'unfiltered_html' ) ? '' : ( 'code_css' === $k ? wp_strip_all_tags( $raw ) : (string) $raw );
		}
		return sanitize_text_field( $raw );
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_topt_save' );
		$tab = isset( $_POST['tab'] ) && isset( self::tabs()[ $_POST['tab'] ] ) ? sanitize_key( $_POST['tab'] ) : 'colors';
		$cur = get_option( self::OPT, array() );
		$cur = is_array( $cur ) ? $cur : array();
		foreach ( self::fields() as $k => $d ) {
			if ( $d[0] === $tab ) {
				$raw       = isset( $_POST[ $k ] ) ? wp_unslash( $_POST[ $k ] ) : '';
				$cur[ $k ] = self::clean( $k, $d, $raw );
			}
		}
		update_option( self::OPT, $cur, false );
		do_action( 'litespeed_purge_all' );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-themeopts&tab=' . $tab . '&ok=1' ) );
		exit;
	}

	public static function tools() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_topt_tools' );
		$cur = get_option( self::OPT, array() );
		$cur = is_array( $cur ) ? $cur : array();
		$go  = 'colors';
		if ( ! empty( $_POST['preset'] ) ) {
			$p = self::presets();
			$n = sanitize_text_field( wp_unslash( $_POST['preset'] ) );
			if ( isset( $p[ $n ] ) ) {
				foreach ( array( 'col_brand', 'col_brand2', 'col_accent', 'col_text', 'col_muted', 'col_bg', 'col_soft', 'col_card', 'col_line', 'hero_c1', 'hero_c2', 'hero_tx', 'f_bg', 'f_tx' ) as $k ) {
					$cur[ $k ] = $p[ $n ][ $k ] ?? '';
				}
			}
		} elseif ( 'reset' === ( $_POST['do'] ?? '' ) ) {
			$cur = array();
			delete_option( self::OPT );
		} elseif ( 'import' === ( $_POST['do'] ?? '' ) ) {
			$j = json_decode( wp_unslash( (string) ( $_POST['import'] ?? '' ) ), true );
			if ( is_array( $j ) ) {
				$f = self::fields();
				foreach ( $j as $k => $raw ) {
					if ( isset( $f[ $k ] ) && is_scalar( $raw ) ) {
						$cur[ $k ] = self::clean( $k, $f[ $k ], (string) $raw );
					}
				}
			}
			$go = 'tools';
		}
		if ( $cur ) {
			update_option( self::OPT, $cur, false );
		}
		do_action( 'litespeed_purge_all' );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-themeopts&tab=' . $go . '&ok=1' ) );
		exit;
	}
}
MRSH_Mem_ThemeOpts::init();
