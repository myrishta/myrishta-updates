<?php
/**
 * Reliable log out.
 * Logged-in pages are kept in a private cache for a short time, so the log-out link inside them can carry an old security code.
 * WordPress then shows "Do you really want to log out?" and the person stays signed in. Here a log-out request that comes from
 * a page of this same site is accepted even if the code is old. A request from another site still gets WordPress's own check.
 * Also hides the PHP version header.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Logout {

	public static function init() {
		add_action( 'login_form_logout', array( __CLASS__, 'logout' ), 1 );
		add_action( 'send_headers', array( __CLASS__, 'headers' ), 99 );
	}

	public static function headers() {
		if ( ! headers_sent() ) {
			header_remove( 'X-Powered-By' );
		}
	}

	private static function same_site() {
		$ref = isset( $_SERVER['HTTP_REFERER'] ) ? wp_unslash( $_SERVER['HTTP_REFERER'] ) : ''; // phpcs:ignore
		if ( '' === $ref ) {
			return false;
		}
		$a = strtolower( (string) wp_parse_url( $ref, PHP_URL_HOST ) );
		$b = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
		$strip = function ( $h ) {
			return preg_replace( '/^www\./', '', $h );
		};
		return '' !== $a && $strip( $a ) === $strip( $b );
	}

	public static function logout() {
		if ( ! is_user_logged_in() ) {
			return; // Nothing to do: WordPress shows its normal page.
		}
		$nonce = isset( $_REQUEST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['_wpnonce'] ) ) : ''; // phpcs:ignore
		if ( $nonce && wp_verify_nonce( $nonce, 'log-out' ) ) {
			return; // Good code: WordPress logs out as usual.
		}
		if ( ! self::same_site() ) {
			return; // From elsewhere: keep WordPress's confirmation step.
		}
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		nocache_headers();
		header( 'X-LiteSpeed-Cache-Control: no-cache' );
		wp_logout();
		$to = isset( $_REQUEST['redirect_to'] ) ? wp_validate_redirect( esc_url_raw( wp_unslash( $_REQUEST['redirect_to'] ) ), home_url( '/' ) ) : home_url( '/' ); // phpcs:ignore
		wp_safe_redirect( add_query_arg( 'loggedout', 'true', $to ) );
		exit;
	}
}
MRSH_Logout::init();
