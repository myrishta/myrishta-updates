<?php
/**
 * Settings hub (3.101.108): one page with an on/off switch and the main numbers for each feature, and a searchable
 * list of every settings screen. Switches default to ON so nothing that already runs is changed.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Master {

	const OPT  = 'mrsh_master';
	const SLUG = 'mrsh-settings';

	/** key => array( label, help ) */
	public static function switches() {
		return array(
			'activity'   => array( 'Activity log', 'Record what members do (messages, interests, profile edits, logins) and flag bad words. Off = nothing new is recorded; the old log stays.' ),
			'inbox'      => array( 'Inbox and red badges', 'Collect plan requests, new members, pending profiles and other events into the Inbox and show the red numbers on the admin bar.' ),
			'ticket_form' => array( 'Support ticket form', 'Let visitors send a ticket from the [mrsh_support] page. Off = the form shows a message to email instead.' ),
			'ticket_mail' => array( 'Tickets from incoming email', 'Read the support mailbox and create a ticket for each real person who writes (also needs the mailbox set in Tickets).' ),
			'flag_mail'  => array( 'Email me about flagged behaviour', 'Send the admin an email when the Activity log flags abuse or scam words.' ),
			'captcha'    => array( 'reCAPTCHA (I am not a robot)', 'Show the box on sign up, login, register, contact and ticket forms. Needs both keys in Website keys.' ),
			'nudge'      => array( 'Profile reminder emails', 'Hourly reminders to members whose profile is not complete.' ),
		);
	}

	public static function on( $k ) {
		$o = get_option( self::OPT, array() );
		if ( is_array( $o ) && isset( $o[ $k ] ) ) {
			return (bool) $o[ $k ];
		}
		return 'flag_mail' === $k ? false : true;
	}

	public static function init() {
		if ( is_admin() ) {
			add_action( 'admin_menu', array( __CLASS__, 'menu' ), 18 );
			add_action( 'admin_post_mrsh_master_save', array( __CLASS__, 'save' ) );
		}
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'All settings', 'All settings', 'manage_options', self::SLUG, array( __CLASS__, 'page' ) );
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_master' );
		$p = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.NonceVerification
		$o = array();
		foreach ( self::switches() as $k => $d ) {
			$o[ $k ] = empty( $p[ 'sw_' . $k ] ) ? 0 : 1;
		}
		update_option( self::OPT, $o, false );

		// Write the same switches and numbers through to each feature's own settings.
		$n = get_option( 'mrsh_nudge', array() );
		$n = is_array( $n ) ? $n : array();
		$n['on']    = $o['nudge'];
		$n['every_h'] = max( 1, (int) ( $p['n_every'] ?? 36 ) );
		$n['verify']  = empty( $p['n_verify'] ) ? 0 : 1;
		$n['max']   = max( 1, (int) ( $p['n_max'] ?? 4 ) );
		$n['batch'] = max( 1, (int) ( $p['n_batch'] ?? 20 ) );
		update_option( 'mrsh_nudge', $n, false );

		$m = get_option( 'mrsh_mailq', array() );
		$m = is_array( $m ) ? $m : array();
		$m['per_run']   = max( 1, (int) ( $p['q_run'] ?? 5 ) );
		$m['per_day']   = max( 0, (int) ( $p['q_day'] ?? 150 ) );
		$m['max_tries'] = max( 1, (int) ( $p['q_tries'] ?? 5 ) );
		update_option( 'mrsh_mailq', $m, false );

		$t = get_option( 'mrsh_tk_set', array() );
		$t = is_array( $t ) ? $t : array();
		$t['imap'] = $o['ticket_mail'];
		if ( ! empty( $p['t_hours'] ) ) {
			$t['hours'] = max( 1, (int) $p['t_hours'] );
		}
		update_option( 'mrsh_tk_set', $t, false );

		$a = get_option( 'mrsh_act_set', array() );
		$a = is_array( $a ) ? $a : array();
		$a['days'] = max( 7, (int) ( $p['a_days'] ?? 120 ) );
		$a['text'] = empty( $p['a_text'] ) ? 0 : 1;
		update_option( 'mrsh_act_set', $a, false );

		delete_transient( 'mrsh_cnt' );
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::SLUG . '&ok=1' ) );
		exit;
	}

	private static function num( $name, $label, $val, $help ) {
		echo '<tr><th>' . esc_html( $label ) . '</th><td><input type="number" min="0" name="' . esc_attr( $name ) . '" value="' . esc_attr( $val ) . '" style="width:90px"> <span class="description">' . esc_html( $help ) . '</span></td></tr>';
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$n = MRSH_Nudge::get();
		$m = class_exists( 'MRSH_Mailq' ) ? MRSH_Mailq::get() : array( 'per_run' => 5, 'per_day' => 150, 'max_tries' => 5 );
		$t = class_exists( 'MRSH_Tickets' ) ? MRSH_Tickets::get() : array( 'hours' => 48 );
		$a = class_exists( 'MRSH_Act' ) ? MRSH_Act::get() : array( 'days' => 120, 'text' => 1 );
		MRSH_Boost::ui_open( 'All settings', 'One place to switch each feature on or off and set its main numbers. Every other settings screen is listed below.', 'g-blue', 'M4 6h10v2H4zm0 5h16v2H4zm0 5h10v2H4zM17 5a2 2 0 1 1 0 4 2 2 0 0 1 0-4zM8 15a2 2 0 1 1 0 4 2 2 0 0 1 0-4z' );
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			MRSH_Boost::ui_ok( 'Settings saved.' );
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_master_save">';
		wp_nonce_field( 'mrsh_master' );
		echo '<div class="mx-card"><h2>Feature switches</h2><table class="form-table" role="presentation">';
		foreach ( self::switches() as $k => $d ) {
			$v = 'nudge' === $k ? ! empty( $n['on'] ) : ( 'ticket_mail' === $k ? ! empty( $t['imap'] ) : self::on( $k ) );
			echo '<tr><th>' . esc_html( $d[0] ) . '</th><td><label><input type="checkbox" name="sw_' . esc_attr( $k ) . '" value="1"' . checked( $v, true, false ) . '> On</label> <span class="description">' . esc_html( $d[1] ) . '</span></td></tr>';
		}
		echo '</table></div><div class="mx-card"><h2>Main numbers</h2><table class="form-table" role="presentation">';
		self::num( 'q_run', 'Emails sent every 5 minutes', $m['per_run'], 'Most emails the queue sends in one run.' );
		self::num( 'q_day', 'Emails per day', $m['per_day'], 'Daily limit. 0 pauses all sending.' );
		self::num( 'q_tries', 'Tries per email', $m['max_tries'], 'After this many failures the email is marked failed.' );
		self::num( 'n_every', 'Hours between reminders', $n['every_h'], 'Profile and email-confirmation reminders (36 = every day and a half).' );
		echo '<tr><th>Remind to confirm email</th><td><label><input type="checkbox" name="n_verify" value="1"' . checked( ! empty( $n['verify'] ), true, false ) . '> On</label></td></tr>';
		self::num( 'n_max', 'Most reminders per member', $n['max'], '' );
		self::num( 'n_batch', 'Reminders per hour', $n['batch'], '' );
		self::num( 't_hours', 'Ticket answer time (hours)', $t['hours'] ?? 48, 'Shown to the person who sends a ticket.' );
		self::num( 'a_days', 'Keep activity log (days)', $a['days'], 'Older rows are deleted every day.' );
		echo '<tr><th>Store message text in log</th><td><label><input type="checkbox" name="a_text" value="1"' . checked( ! empty( $a['text'] ), true, false ) . '> On</label> <span class="description">Off = only who wrote to whom is kept, not the words (flags still work).</span></td></tr>';
		echo '</table></div><p><button class="button button-primary mx-btn">Save all settings</button></p></form>';

		echo '<div class="mx-card"><h2>Every settings screen</h2><p><input type="search" id="mrsh-sfind" placeholder="Search settings, e.g. email, plan, photo" style="min-width:280px"></p><table class="widefat striped mx-tbl" id="mrsh-stbl"><thead><tr><th>Screen</th><th>Section</th><th></th></tr></thead><tbody>';
		foreach ( MRSH_Tabs::groups() as $g => $d ) {
			foreach ( $d[2] as $slug => $label ) {
				echo '<tr><td><b>' . esc_html( $label ) . '</b></td><td>' . esc_html( $d[0] ) . '</td><td><a class="button mx-btn" href="' . esc_url( admin_url( 'admin.php?page=' . $slug ) ) . '">Open</a></td></tr>';
			}
		}
		echo '</tbody></table></div><script>document.getElementById("mrsh-sfind").addEventListener("input",function(){var q=this.value.toLowerCase();document.querySelectorAll("#mrsh-stbl tbody tr").forEach(function(r){r.style.display=r.textContent.toLowerCase().indexOf(q)<0?"none":""})});</script></div>';
	}
}
MRSH_Master::init();
