<?php
/**
 * Integrations (all optional, all off until you add keys in My Rishta SEO > Integrations):
 * SMS phone verification, chat message translation, auto posts to Telegram / Facebook / Instagram,
 * stolen-photo check with Google Vision, coupon codes, homepage heading A/B test.
 * Keys are stored in option mrsh_int (not autoloaded). Nothing is sent anywhere until you fill a section in.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Mem_Integr {

	public static function defaults() {
		return array(
			'sms_provider' => 'none', 'tw_sid' => '', 'tw_token' => '', 'tw_from' => '', 'sms_url' => '', 'sms_body' => '',
			'tr_provider' => 'none', 'tr_key' => '', 'tr_url' => '',
			'tg_token' => '', 'tg_chat' => '', 'fb_page' => '', 'fb_token' => '', 'ig_id' => '', 'social_on' => 0,
			'vis_key' => '', 'coupons' => '', 'ab_title_b' => '',
		);
	}

	public static function get( $k = null ) {
		$o  = array_merge( self::defaults(), (array) get_option( 'mrsh_int', array() ) );
		$wk = (array) get_option( 'mrsh_keys', array() ); // keys saved on the Website keys page fill any empty box here
		if ( '' === (string) $o['vis_key'] && ! empty( $wk['vision_key'] ) ) {
			$o['vis_key'] = (string) $wk['vision_key'];
		}
		if ( '' === (string) $o['tr_key'] && 'google' === $o['tr_provider'] && ! empty( $wk['translate_key'] ) ) {
			$o['tr_key'] = (string) $wk['translate_key'];
		}
		return null === $k ? $o : ( $o[ $k ] ?? '' );
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 27 );
		add_action( 'admin_post_mrsh_int_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_mrsh_int_test', array( __CLASS__, 'test' ) );
		// SMS
		add_action( 'wp_ajax_mrsh_sms_send', array( __CLASS__, 'sms_send' ) );
		add_action( 'wp_ajax_mrsh_sms_check', array( __CLASS__, 'sms_check' ) );
		// translate
		add_action( 'wp_ajax_mrsh_translate', array( __CLASS__, 'translate' ) );
		// social + photo check
		add_action( 'transition_post_status', array( __CLASS__, 'on_status' ), 10, 3 );
		add_action( 'mrsh_social_post', array( __CLASS__, 'social_post' ) );
		add_action( 'mrsh_photo_check', array( __CLASS__, 'photo_check' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'metabox' ) );
		// coupons
		add_action( 'admin_post_mrsh_coupon', array( __CLASS__, 'coupon' ) );
		// account + profile
		add_action( 'mrt_account_extra', array( __CLASS__, 'account' ), 30 );
		add_action( 'mrt_profile_after', array( __CLASS__, 'profile_badge' ) );
		add_action( 'wp_footer', array( __CLASS__, 'js' ), 80 );
		// A/B test
		add_action( 'wp_ajax_mrsh_ab', array( __CLASS__, 'ab' ) );
		add_action( 'wp_ajax_nopriv_mrsh_ab', array( __CLASS__, 'ab' ) );
	}

	/* ---------- helpers ---------- */

	private static function sms_ready() {
		$o = self::get();
		return ( 'twilio' === $o['sms_provider'] && $o['tw_sid'] && $o['tw_token'] && $o['tw_from'] ) || ( 'custom' === $o['sms_provider'] && $o['sms_url'] );
	}

	private static function tr_ready() {
		$o = self::get();
		return 'mymemory' === $o['tr_provider'] || ( 'google' === $o['tr_provider'] && $o['tr_key'] ) || ( 'libre' === $o['tr_provider'] && $o['tr_url'] );
	}

	/** Sends one SMS. Returns true or an error text. */
	public static function sms( $to, $msg ) {
		$o = self::get();
		if ( 'twilio' === $o['sms_provider'] ) {
			$r = wp_remote_post( 'https://api.twilio.com/2010-04-01/Accounts/' . rawurlencode( $o['tw_sid'] ) . '/Messages.json', array(
				'timeout' => 15, 'headers' => array( 'Authorization' => 'Basic ' . base64_encode( $o['tw_sid'] . ':' . $o['tw_token'] ) ),
				'body'    => array( 'To' => $to, 'From' => $o['tw_from'], 'Body' => $msg ),
			) );
		} elseif ( 'custom' === $o['sms_provider'] && $o['sms_url'] ) {
			$sub = function ( $t ) use ( $to, $msg ) { return str_replace( array( '{to}', '{msg}' ), array( rawurlencode( $to ), rawurlencode( $msg ) ), $t ); };
			$url = $sub( $o['sms_url'] );
			if ( 0 !== strpos( $url, 'https://' ) ) {
				return 'The SMS address must start with https://';
			}
			$r = $o['sms_body'] ? wp_remote_post( $url, array( 'timeout' => 15, 'body' => str_replace( array( '{to}', '{msg}' ), array( $to, $msg ), $o['sms_body'] ) ) ) : wp_remote_get( $url, array( 'timeout' => 15 ) );
		} else {
			return 'SMS is not set up.';
		}
		if ( is_wp_error( $r ) ) {
			return $r->get_error_message();
		}
		$c = (int) wp_remote_retrieve_response_code( $r );
		return ( $c >= 200 && $c < 300 ) ? true : 'SMS service answered ' . $c;
	}

	private static function norm_phone( $p ) {
		$d = preg_replace( '/\D/', '', (string) $p );
		if ( 0 === strpos( $d, '00' ) ) {
			$d = substr( $d, 2 );
		}
		if ( 0 === strpos( $d, '0' ) && 11 === strlen( $d ) ) { // 03xx xxxxxxx
			$d = '92' . substr( $d, 1 );
		}
		return ( strlen( $d ) >= 10 && strlen( $d ) <= 15 ) ? '+' . $d : '';
	}

	private static function out( $ok, $msg, $x = array() ) {
		wp_send_json( array_merge( array( 'ok' => $ok, 'msg' => $msg ), $x ) );
	}

	/* ---------- SMS verification ---------- */

	public static function sms_send() {
		check_ajax_referer( 'mrt', 'n' );
		$uid = get_current_user_id();
		if ( ! $uid || ! self::sms_ready() ) {
			self::out( false, 'SMS verification is not available.' );
		}
		$ph = self::norm_phone( wp_unslash( $_POST['phone'] ?? '' ) ); // phpcs:ignore
		if ( ! $ph ) {
			self::out( false, 'Enter a valid mobile number.' );
		}
		if ( get_transient( 'mrsh_smsw_' . $uid ) ) {
			self::out( false, 'Please wait one minute before asking for another code.' );
		}
		$dk = 'mrsh_smsd_' . $uid . '_' . gmdate( 'Ymd' );
		if ( (int) get_transient( $dk ) >= 3 ) {
			self::out( false, 'Daily limit reached. Try again tomorrow.' );
		}
		$taken = get_users( array( 'meta_key' => 'mrt_phone_v', 'meta_value' => $ph, 'exclude' => array( $uid ), 'fields' => 'ID', 'number' => 1 ) );
		if ( $taken ) {
			self::out( false, 'This number is already verified on another account.' );
		}
		$code = (string) wp_rand( 100000, 999999 );
		$r    = self::sms( $ph, 'Your ' . get_bloginfo( 'name' ) . ' code is ' . $code . '. Do not share it.' );
		if ( true !== $r ) {
			self::out( false, 'Could not send the SMS. Please try later.' );
		}
		set_transient( 'mrsh_smsw_' . $uid, 1, 60 );
		set_transient( $dk, (int) get_transient( $dk ) + 1, DAY_IN_SECONDS );
		set_transient( 'mrsh_smsc_' . $uid, array( 'h' => wp_hash( $code . $ph ), 'p' => $ph, 't' => 0 ), 10 * MINUTE_IN_SECONDS );
		self::out( true, 'Code sent. It works for 10 minutes.' );
	}

	public static function sms_check() {
		check_ajax_referer( 'mrt', 'n' );
		$uid = get_current_user_id();
		$s   = $uid ? get_transient( 'mrsh_smsc_' . $uid ) : false;
		if ( ! $s ) {
			self::out( false, 'The code expired. Ask for a new one.' );
		}
		$code = preg_replace( '/\D/', '', (string) wp_unslash( $_POST['code'] ?? '' ) ); // phpcs:ignore
		if ( $s['t'] >= 5 ) {
			delete_transient( 'mrsh_smsc_' . $uid );
			self::out( false, 'Too many tries. Ask for a new code.' );
		}
		if ( ! hash_equals( $s['h'], wp_hash( $code . $s['p'] ) ) ) {
			$s['t']++;
			set_transient( 'mrsh_smsc_' . $uid, $s, 10 * MINUTE_IN_SECONDS );
			self::out( false, 'Wrong code.' );
		}
		delete_transient( 'mrsh_smsc_' . $uid );
		update_user_meta( $uid, 'mrt_phone_v', $s['p'] );
		update_user_meta( $uid, 'mrt_phone_ok', time() );
		if ( class_exists( 'MRSH_Mem_Growth' ) ) {
			MRSH_Mem_Growth::log( 'Phone verified by SMS for user #' . $uid );
		}
		self::out( true, 'Your phone is verified.' );
	}

	public static function profile_badge( $pid ) {
		$p = get_post( $pid ? $pid : get_the_ID() );
		if ( $p && get_user_meta( (int) $p->post_author, 'mrt_phone_ok', true ) ) {
			echo '<div class="wrap"><p class="chip on" style="display:inline-block">&#10003; Phone verified by SMS</p></div>';
		}
	}

	/* ---------- translate ---------- */

	public static function translate() {
		check_ajax_referer( 'mrt', 'n' );
		$uid = get_current_user_id();
		if ( ! $uid || ! self::tr_ready() ) {
			self::out( false, 'Translation is not available.' );
		}
		$k = 'mrsh_tr_' . $uid . '_' . gmdate( 'Ymd' );
		if ( (int) get_transient( $k ) >= 80 ) {
			self::out( false, 'Daily translation limit reached.' );
		}
		$text = mb_substr( trim( wp_strip_all_tags( (string) wp_unslash( $_POST['text'] ?? '' ) ) ), 0, 1000 ); // phpcs:ignore
		$to   = 'ur' === ( $_POST['to'] ?? '' ) ? 'ur' : 'en'; // phpcs:ignore
		if ( '' === $text ) {
			self::out( false, 'Nothing to translate.' );
		}
		set_transient( $k, (int) get_transient( $k ) + 1, DAY_IN_SECONDS );
		$o = self::get();
		if ( 'mymemory' === $o['tr_provider'] ) {
			// Free service, no account. Each request is limited to about 500 bytes, so long text is sent in pieces.
			$src   = 'en' === $to ? 'ur' : 'en';
			$parts = array();
			$cur   = '';
			foreach ( preg_split( '/(?<=[.!?\x{06D4}\x{061F}\n])\s+/u', $text ) as $sent ) {
				if ( strlen( $cur . ' ' . $sent ) > 400 && '' !== $cur ) {
					$parts[] = $cur;
					$cur     = '';
				}
				$cur = trim( $cur . ' ' . $sent );
			}
			if ( '' !== $cur ) {
				$parts[] = $cur;
			}
			$out = array();
			foreach ( array_slice( $parts, 0, 4 ) as $piece ) {
				$piece = mb_strcut( $piece, 0, 450, 'UTF-8' );
				$args  = array( 'q' => $piece, 'langpair' => $src . '|' . $to );
				if ( is_email( $o['tr_key'] ) ) {
					$args['de'] = $o['tr_key'];
				}
				$r = wp_remote_get( add_query_arg( $args, 'https://api.mymemory.translated.net/get' ), array( 'timeout' => 12 ) );
				$d = is_wp_error( $r ) ? null : json_decode( wp_remote_retrieve_body( $r ), true );
				if ( ! $d || 200 !== (int) ( $d['responseStatus'] ?? 0 ) || empty( $d['responseData']['translatedText'] ) ) {
					$out = array();
					break;
				}
				$out[] = $d['responseData']['translatedText'];
			}
			$t = implode( ' ', $out );
		} elseif ( 'google' === $o['tr_provider'] ) {
			$r = wp_remote_post( 'https://translation.googleapis.com/language/translate/v2?key=' . rawurlencode( $o['tr_key'] ), array( 'timeout' => 12, 'body' => array( 'q' => $text, 'target' => $to, 'format' => 'text' ) ) );
			$d = is_wp_error( $r ) ? null : json_decode( wp_remote_retrieve_body( $r ), true );
			$t = $d['data']['translations'][0]['translatedText'] ?? '';
		} else {
			$u = rtrim( $o['tr_url'], '/' );
			if ( 0 !== strpos( $u, 'https://' ) ) {
				self::out( false, 'Translation address must start with https://' );
			}
			$r = wp_remote_post( $u . '/translate', array( 'timeout' => 12, 'headers' => array( 'Content-Type' => 'application/json' ), 'body' => wp_json_encode( array( 'q' => $text, 'source' => 'auto', 'target' => $to, 'format' => 'text', 'api_key' => $o['tr_key'] ) ) ) );
			$d = is_wp_error( $r ) ? null : json_decode( wp_remote_retrieve_body( $r ), true );
			$t = $d['translatedText'] ?? '';
		}
		$t ? self::out( true, '', array( 'text' => wp_strip_all_tags( html_entity_decode( $t ) ) ) ) : self::out( false, 'Could not translate.' );
	}

	/* ---------- social posts + photo check ---------- */

	public static function on_status( $new, $old, $post ) {
		if ( $new === $old ) {
			return;
		}
		if ( 'post' === $post->post_type && 'publish' === $new && self::get( 'social_on' ) && ! get_post_meta( $post->ID, '_mrsh_social_done', true ) ) {
			update_post_meta( $post->ID, '_mrsh_social_done', 1 );
			wp_schedule_single_event( time() + 20, 'mrsh_social_post', array( $post->ID ) );
		}
		if ( 'listing_type' === $post->post_type && in_array( $new, array( 'pending', 'publish' ), true ) && self::get( 'vis_key' ) && ! get_post_meta( $post->ID, '_mrsh_vis_done', true ) ) {
			update_post_meta( $post->ID, '_mrsh_vis_done', 1 );
			wp_schedule_single_event( time() + 30, 'mrsh_photo_check', array( $post->ID ) );
		}
	}

	public static function social_post( $id ) {
		$p = get_post( $id );
		if ( ! $p || 'publish' !== $p->post_status ) {
			return;
		}
		$o    = self::get();
		$link = get_permalink( $p );
		$text = html_entity_decode( get_the_title( $p ), ENT_QUOTES, 'UTF-8' ) . "\n" . wp_trim_words( wp_strip_all_tags( $p->post_excerpt ? $p->post_excerpt : $p->post_content ), 28 );
		if ( $o['tg_token'] && $o['tg_chat'] ) {
			wp_remote_post( 'https://api.telegram.org/bot' . rawurlencode( $o['tg_token'] ) . '/sendMessage', array( 'timeout' => 12, 'body' => array( 'chat_id' => $o['tg_chat'], 'text' => $text . "\n" . $link ) ) );
		}
		if ( $o['fb_page'] && $o['fb_token'] ) {
			wp_remote_post( 'https://graph.facebook.com/v19.0/' . rawurlencode( $o['fb_page'] ) . '/feed', array( 'timeout' => 15, 'body' => array( 'message' => $text, 'link' => $link, 'access_token' => $o['fb_token'] ) ) );
		}
		$img = get_the_post_thumbnail_url( $p, 'large' );
		if ( $o['ig_id'] && $o['fb_token'] && $img ) {
			$r = wp_remote_post( 'https://graph.facebook.com/v19.0/' . rawurlencode( $o['ig_id'] ) . '/media', array( 'timeout' => 20, 'body' => array( 'image_url' => $img, 'caption' => $text . "\n" . $link, 'access_token' => $o['fb_token'] ) ) );
			$d = is_wp_error( $r ) ? null : json_decode( wp_remote_retrieve_body( $r ), true );
			if ( ! empty( $d['id'] ) ) {
				wp_remote_post( 'https://graph.facebook.com/v19.0/' . rawurlencode( $o['ig_id'] ) . '/media_publish', array( 'timeout' => 20, 'body' => array( 'creation_id' => $d['id'], 'access_token' => $o['fb_token'] ) ) );
			}
		}
		if ( class_exists( 'MRSH_Mem_Growth' ) ) {
			MRSH_Mem_Growth::log( 'Shared to social: ' . $p->post_title );
		}
	}

	public static function photo_check( $id ) {
		$key = self::get( 'vis_key' );
		$tid = get_post_thumbnail_id( $id );
		$f   = $tid ? get_attached_file( $tid ) : '';
		$f   = $f && file_exists( $f ) ? $f : '';
		if ( ! $key || ! $f || filesize( $f ) > 4 * MB_IN_BYTES ) {
			return;
		}
		$r = wp_remote_post( 'https://vision.googleapis.com/v1/images:annotate?key=' . rawurlencode( $key ), array( 'timeout' => 25, 'headers' => array( 'Content-Type' => 'application/json' ),
			'body' => wp_json_encode( array( 'requests' => array( array( 'image' => array( 'content' => base64_encode( file_get_contents( $f ) ) ), 'features' => array( array( 'type' => 'WEB_DETECTION', 'maxResults' => 10 ) ) ) ) ) ) ) ); // phpcs:ignore
		$d = is_wp_error( $r ) ? null : json_decode( wp_remote_retrieve_body( $r ), true );
		$w = $d['responses'][0]['webDetection'] ?? null;
		if ( ! $w ) {
			return;
		}
		$full  = count( (array) ( $w['fullMatchingImages'] ?? array() ) );
		$pages = count( (array) ( $w['pagesWithMatchingImages'] ?? array() ) );
		if ( $full > 0 || $pages >= 2 ) {
			$note = $full . ' exact copies and ' . $pages . ' pages with this picture found online.';
			foreach ( array_slice( (array) ( $w['pagesWithMatchingImages'] ?? array() ), 0, 3 ) as $pg ) {
				$note .= "\n" . esc_url_raw( $pg['url'] ?? '' );
			}
			update_post_meta( $id, 'mrt_photo_flag', $note );
			wp_mail( get_option( 'admin_email' ), 'Photo check: please review a profile', "This profile photo appears elsewhere online. It may be a stolen picture.\n\nProfile: " . get_edit_post_link( $id, 'raw' ) . "\n\n" . $note );
			if ( class_exists( 'MRSH_Mem_Growth' ) ) {
				MRSH_Mem_Growth::log( 'Photo flagged on profile #' . $id );
			}
		}
	}

	public static function metabox() {
		add_meta_box( 'mrsh_photoflag', 'Photo check', function ( $p ) {
			$f = get_post_meta( $p->ID, 'mrt_photo_flag', true );
			echo $f ? '<p style="color:#b42318"><b>Possible stolen photo.</b></p><pre style="white-space:pre-wrap">' . esc_html( $f ) . '</pre>' : '<p>No problem found (or not checked yet).</p>';
		}, 'listing_type', 'side' );
	}

	/* ---------- coupons ---------- */

	private static function coupons() {
		$out = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) self::get( 'coupons' ) ) as $l ) {
			$p = array_map( 'trim', explode( '|', $l ) );
			if ( count( $p ) >= 3 && '' !== $p[0] ) {
				$out[ strtoupper( $p[0] ) ] = array( 'plan' => $p[1], 'days' => max( 1, (int) $p[2] ), 'max' => isset( $p[3] ) ? max( 0, (int) $p[3] ) : 0 );
			}
		}
		return $out;
	}

	public static function coupon() {
		$uid = get_current_user_id();
		$bk  = home_url( '/my-account/' );
		if ( ! $uid || ! check_admin_referer( 'mrsh_coupon' ) ) {
			wp_safe_redirect( $bk );
			exit;
		}
		$k = 'mrsh_cpl_' . $uid;
		if ( (int) get_transient( $k ) >= 5 ) {
			wp_safe_redirect( add_query_arg( 'coupon', 'bad', $bk ) );
			exit;
		}
		set_transient( $k, (int) get_transient( $k ) + 1, HOUR_IN_SECONDS );
		$code = strtoupper( trim( sanitize_text_field( wp_unslash( $_POST['code'] ?? '' ) ) ) ); // phpcs:ignore
		$all  = self::coupons();
		$used = (array) get_option( 'mrsh_coupon_uses', array() );
		$mine = (array) get_user_meta( $uid, 'mrt_coupons', true );
		$cur  = trim( (string) get_user_meta( $uid, 'mrt_plan', true ) );
		if ( ! isset( $all[ $code ] ) || in_array( $code, $mine, true ) || ( $all[ $code ]['max'] && (int) ( $used[ $code ] ?? 0 ) >= $all[ $code ]['max'] ) || ( $cur && 0 !== strcasecmp( $cur, 'free' ) ) ) {
			wp_safe_redirect( add_query_arg( 'coupon', 'bad', $bk ) );
			exit;
		}
		update_user_meta( $uid, 'mrt_plan', $all[ $code ]['plan'] );
		update_user_meta( $uid, 'mrt_plan_exp', time() + $all[ $code ]['days'] * DAY_IN_SECONDS );
		$mine[] = $code;
		update_user_meta( $uid, 'mrt_coupons', $mine );
		$used[ $code ] = (int) ( $used[ $code ] ?? 0 ) + 1;
		update_option( 'mrsh_coupon_uses', $used, false );
		if ( class_exists( 'MRSH_Mem_Growth' ) ) {
			MRSH_Mem_Growth::log( 'Coupon ' . $code . ' used by user #' . $uid );
		}
		wp_safe_redirect( add_query_arg( 'coupon', 'ok', $bk ) );
		exit;
	}

	/* ---------- member account blocks ---------- */

	public static function account( $uid ) {
		if ( ! $uid ) {
			return;
		}
		echo '<div class="wrap narrow">';
		if ( isset( $_GET['coupon'] ) ) { // phpcs:ignore
			echo '<div class="note2">' . ( 'ok' === $_GET['coupon'] ? 'Coupon accepted. Your plan is active.' : 'This code is not valid, already used, or you already have a plan.' ) . '</div>'; // phpcs:ignore
		}
		if ( self::sms_ready() ) {
			echo '<div class="box" id="mrsh-sms"><h3>Verify my phone</h3>';
			if ( get_user_meta( $uid, 'mrt_phone_ok', true ) ) {
				echo '<p>&#10003; Your phone is verified. Others see a "Phone verified" mark. Your number stays private.</p>';
			} else {
				echo '<p class="mut">We send a code by SMS. Your number stays private.</p><p><input type="tel" id="sms-ph" placeholder="03xx xxxxxxx" style="width:100%"></p><p><button type="button" class="btn" id="sms-go">Send code</button></p><p id="sms-c" style="display:none"><input type="text" id="sms-code" inputmode="numeric" maxlength="6" placeholder="6-digit code" style="width:100%"></p><p><button type="button" class="btn alt" id="sms-ok" style="display:none">Verify</button></p><p class="mut" id="sms-m"></p>';
			}
			echo '</div>';
		}
		if ( self::coupons() ) {
			$cur = trim( (string) get_user_meta( $uid, 'mrt_plan', true ) );
			if ( ! $cur || 0 === strcasecmp( $cur, 'free' ) ) {
				echo '<div class="box"><h3>Have a coupon?</h3><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_coupon">' . wp_nonce_field( 'mrsh_coupon', '_wpnonce', true, false ) . '<p><input type="text" name="code" placeholder="Coupon code" maxlength="30" required style="width:100%"></p><p><button class="btn">Apply</button></p></form></div>';
			}
		}
		echo '</div>';
	}

	/* ---------- front end scripts ---------- */

	public static function js() {
		if ( 'myrishta' !== get_template() ) {
			return;
		}
		$n   = wp_create_nonce( 'mrt' );
		$b   = trim( (string) self::get( 'ab_title_b' ) );
		$ab  = ( $b && is_front_page() ) ? 1 : 0;
		?>
<script>
(function(){
var AJ=<?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>,N=<?php echo wp_json_encode( $n ); ?>,TR=<?php echo self::tr_ready() ? 1 : 0; ?>;
function post(d,cb){var f=new FormData();for(var k in d)f.append(k,d[k]);f.append('n',N);fetch(AJ,{method:'POST',body:f,credentials:'same-origin'}).then(function(r){return r.json()}).then(cb).catch(function(){})}
/* SMS */
var g=document.getElementById('sms-go');if(g){var m=document.getElementById('sms-m');
g.onclick=function(){post({action:'mrsh_sms_send',phone:document.getElementById('sms-ph').value},function(r){m.textContent=r.msg;if(r.ok){document.getElementById('sms-c').style.display='block';document.getElementById('sms-ok').style.display='inline-block'}})};
document.getElementById('sms-ok').onclick=function(){post({action:'mrsh_sms_check',code:document.getElementById('sms-code').value},function(r){m.textContent=r.msg;if(r.ok)setTimeout(function(){location.reload()},900)})}}
/* translate chat messages */
var cl=document.querySelector('#mrt-chat .cl');if(TR&&cl){
function dec(b){if(b.getAttribute('data-tr')||/^\[voice:/.test(b.textContent))return;b.setAttribute('data-tr','1');var a=document.createElement('a');a.href='#';a.textContent='Translate';a.style.cssText='display:block;font-size:.75rem;opacity:.8;margin-top:2px';
a.onclick=function(e){e.preventDefault();var t=b.firstChild?b.firstChild.textContent:b.textContent;var to=/[؀-ۿ]/.test(t)?'en':'ur';a.textContent='...';post({action:'mrsh_translate',text:t,to:to},function(r){if(r.ok){a.remove();var d=document.createElement('div');d.style.cssText='font-size:.85rem;margin-top:4px;border-top:1px dashed currentColor;padding-top:4px';d.textContent=r.text;b.appendChild(d)}else a.textContent=r.msg||'Translate'})};b.appendChild(a)}
function all(){cl.querySelectorAll('.bub').forEach(dec)}all();new MutationObserver(all).observe(cl,{childList:true})}
/* A/B test of the home heading */
<?php if ( $ab ) : ?>
(function(){var h=document.querySelector('.hero h1');if(!h)return;var v=(document.cookie.match(/(?:^|; )mrab=(a|b)/)||[])[1];if(!v){v=Math.random()<.5?'a':'b';document.cookie='mrab='+v+';path=/;max-age=2592000;samesite=lax'}
if(v==='b')h.textContent=<?php echo wp_json_encode( $b ); ?>;
try{if(!sessionStorage.getItem('mrab_seen')){sessionStorage.setItem('mrab_seen','1');var f=new FormData();f.append('action','mrsh_ab');f.append('v',v);f.append('e','view');navigator.sendBeacon?navigator.sendBeacon(AJ,f):0}}catch(e){}
var hs=document.querySelector('.hero form,.hero .btn');if(hs)(document.querySelector('.hero form')||hs).addEventListener(document.querySelector('.hero form')?'submit':'click',function(){var f=new FormData();f.append('action','mrsh_ab');f.append('v',v);f.append('e','click');navigator.sendBeacon?navigator.sendBeacon(AJ,f):0})})();
<?php endif; ?>
})();
</script>
		<?php
	}

	public static function ab() {
		$v = 'b' === ( $_POST['v'] ?? '' ) ? 'b' : 'a'; // phpcs:ignore
		$e = 'click' === ( $_POST['e'] ?? '' ) ? 'click' : 'view'; // phpcs:ignore
		$k = 'mrsh_ab_' . md5( function_exists( 'mrt_ip' ) ? mrt_ip() : '0' ) . $e;
		if ( (int) get_transient( $k ) >= 20 ) {
			wp_die();
		}
		set_transient( $k, (int) get_transient( $k ) + 1, DAY_IN_SECONDS );
		$s = (array) get_option( 'mrsh_ab', array() );
		$s[ $v . '_' . $e ] = (int) ( $s[ $v . '_' . $e ] ?? 0 ) + 1;
		update_option( 'mrsh_ab', $s, false );
		wp_die();
	}

	/* ---------- admin ---------- */

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Integrations', 'Integrations', 'manage_options', 'mrsh-int', array( __CLASS__, 'page' ) );
	}

	private static function f( $k, $label, $help = '', $type = 'text', $opts = array() ) {
		$v = self::get( $k );
		echo '<tr><th><label for="' . esc_attr( $k ) . '">' . esc_html( $label ) . '</label></th><td>';
		if ( 'select' === $type ) {
			echo '<select name="' . esc_attr( $k ) . '" id="' . esc_attr( $k ) . '">';
			foreach ( $opts as $ov => $ol ) {
				echo '<option value="' . esc_attr( $ov ) . '"' . selected( $v, $ov, false ) . '>' . esc_html( $ol ) . '</option>';
			}
			echo '</select>';
		} elseif ( 'check' === $type ) {
			echo '<label><input type="checkbox" name="' . esc_attr( $k ) . '" value="1"' . checked( (int) $v, 1, false ) . '> On</label>';
		} elseif ( 'area' === $type ) {
			echo '<textarea name="' . esc_attr( $k ) . '" id="' . esc_attr( $k ) . '" rows="4" class="large-text code">' . esc_textarea( $v ) . '</textarea>';
		} else {
			echo '<input type="' . ( 'secret' === $type ? 'password' : 'text' ) . '" name="' . esc_attr( $k ) . '" id="' . esc_attr( $k ) . '" value="' . esc_attr( $v ) . '" class="regular-text" autocomplete="off">';
		}
		echo $help ? ' <span class="description">' . esc_html( $help ) . '</span>' : '';
		echo '</td></tr>';
	}

	public static function page() {
		echo '<div class="wrap"><h1>Integrations</h1>';
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success is-dismissible"><p>' . ( 'test' === $_GET['ok'] ? esc_html( (string) get_transient( 'mrsh_int_test' ) ) : 'Saved.' ) . '</p></div>'; // phpcs:ignore
		}
		echo '<p>Everything here is optional and stays off until you add the keys. Keys are saved in the database (not shown on the website).</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_int_save">';
		wp_nonce_field( 'mrsh_int_save' );
		echo '<h2>SMS phone verification</h2><table class="form-table">';
		self::f( 'sms_provider', 'Service', 'Twilio, or any service that works with a web address.', 'select', array( 'none' => 'Off', 'twilio' => 'Twilio', 'custom' => 'Other (web address)' ) );
		self::f( 'tw_sid', 'Twilio Account SID' );
		self::f( 'tw_token', 'Twilio Auth token', '', 'secret' );
		self::f( 'tw_from', 'Twilio sender number', 'Example +15551234567' );
		self::f( 'sms_url', 'Other: address', 'Must start with https://. Use {to} for the number and {msg} for the text.' );
		self::f( 'sms_body', 'Other: body (optional)', 'If filled, sent as POST. Use {to} and {msg}.' );
		echo '</table><h2>Translate chat messages (Urdu / English)</h2><p class="description">Message text is sent to the service you choose when a member presses Translate.</p><table class="form-table">';
		self::f( 'tr_provider', 'Service', '', 'select', array( 'none' => 'Off', 'mymemory' => 'MyMemory (free, no account)', 'google' => 'Google Cloud Translation', 'libre' => 'LibreTranslate server' ) );
		self::f( 'tr_key', 'API key (MyMemory: optional email for a bigger free daily limit)', '', 'secret' );
		self::f( 'tr_url', 'LibreTranslate address', 'Example https://translate.example.com' );
		echo '</table><h2>Share new articles automatically</h2><table class="form-table">';
		self::f( 'social_on', 'Share new articles', 'Posts to every service below that has keys.', 'check' );
		self::f( 'tg_token', 'Telegram bot token', 'From @BotFather', 'secret' );
		self::f( 'tg_chat', 'Telegram channel', 'Example @myrishta_pk (add the bot as admin)' );
		self::f( 'fb_page', 'Facebook Page ID' );
		self::f( 'fb_token', 'Facebook Page access token', 'Also used for Instagram.', 'secret' );
		self::f( 'ig_id', 'Instagram business account ID', 'Needs an article picture.' );
		echo '</table><h2>Stolen photo check</h2><table class="form-table">';
		self::f( 'vis_key', 'Google Vision API key', 'New profile photos are checked once. A warning appears on the profile and you get an email.', 'secret' );
		echo '</table><h2>Coupon codes</h2><table class="form-table">';
		self::f( 'coupons', 'Codes', 'One per line: CODE | Plan | days | max uses (0 or empty = unlimited). Example: EID2026 | Silver | 30 | 100. Works only for members without a paid plan.', 'area' );
		echo '</table><h2>Homepage heading test (A/B)</h2><table class="form-table">';
		self::f( 'ab_title_b', 'Heading B', 'Half of visitors see this heading instead of your normal one. Empty = no test. Results below.' );
		$s = (array) get_option( 'mrsh_ab', array() );
		echo '<tr><th>Results</th><td>A: ' . (int) ( $s['a_view'] ?? 0 ) . ' views, ' . (int) ( $s['a_click'] ?? 0 ) . ' clicks. B: ' . (int) ( $s['b_view'] ?? 0 ) . ' views, ' . (int) ( $s['b_click'] ?? 0 ) . ' clicks.</td></tr>';
		echo '</table><p><button class="button button-primary">Save</button></p></form><h2>Test</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_int_test">';
		wp_nonce_field( 'mrsh_int_test' );
		echo '<p><input type="text" name="phone" placeholder="Your mobile for the SMS test"> <button class="button" name="what" value="sms">Send test SMS</button> <button class="button" name="what" value="tg">Send test to Telegram</button> <button class="button" name="what" value="tr">Test translation</button></p></form></div>';
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_int_save' );
		$o = array();
		foreach ( array_keys( self::defaults() ) as $k ) {
			$raw = isset( $_POST[ $k ] ) ? wp_unslash( $_POST[ $k ] ) : ''; // phpcs:ignore
			if ( in_array( $k, array( 'coupons' ), true ) ) {
				$o[ $k ] = sanitize_textarea_field( $raw );
			} elseif ( 'social_on' === $k ) {
				$o[ $k ] = empty( $_POST[ $k ] ) ? 0 : 1; // phpcs:ignore
			} elseif ( in_array( $k, array( 'sms_provider' ), true ) ) {
				$o[ $k ] = in_array( $raw, array( 'none', 'twilio', 'custom' ), true ) ? $raw : 'none';
			} elseif ( 'tr_provider' === $k ) {
				$o[ $k ] = in_array( $raw, array( 'none', 'mymemory', 'google', 'libre' ), true ) ? $raw : 'none';
			} elseif ( in_array( $k, array( 'sms_url', 'tr_url' ), true ) ) {
				$o[ $k ] = esc_url_raw( str_replace( array( '{to}', '{msg}' ), array( 'TOKENTO', 'TOKENMSG' ), $raw ) );
				$o[ $k ] = str_replace( array( 'TOKENTO', 'TOKENMSG' ), array( '{to}', '{msg}' ), $o[ $k ] );
			} else {
				$o[ $k ] = sanitize_text_field( $raw );
			}
		}
		update_option( 'mrsh_int', $o, false );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-int&ok=1' ) );
		exit;
	}

	public static function test() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_int_test' );
		$w = sanitize_key( $_POST['what'] ?? '' ); // phpcs:ignore
		$m = 'Nothing to test.';
		if ( 'sms' === $w ) {
			$ph = self::norm_phone( wp_unslash( $_POST['phone'] ?? '' ) ); // phpcs:ignore
			$r  = $ph ? self::sms( $ph, 'Test SMS from ' . get_bloginfo( 'name' ) ) : 'Enter a valid number.';
			$m  = true === $r ? 'SMS sent.' : 'SMS failed: ' . $r;
		} elseif ( 'tg' === $w ) {
			$o = self::get();
			if ( $o['tg_token'] && $o['tg_chat'] ) {
				$r = wp_remote_post( 'https://api.telegram.org/bot' . rawurlencode( $o['tg_token'] ) . '/sendMessage', array( 'timeout' => 12, 'body' => array( 'chat_id' => $o['tg_chat'], 'text' => 'Test from ' . get_bloginfo( 'name' ) ) ) );
				$m = ( ! is_wp_error( $r ) && 200 === (int) wp_remote_retrieve_response_code( $r ) ) ? 'Telegram message sent.' : 'Telegram failed. Check the token and channel.';
			} else {
				$m = 'Add the Telegram token and channel first.';
			}
		} elseif ( 'tr' === $w ) {
			$m = self::tr_ready() ? 'Translation keys are saved. Open a chat and press Translate under a message.' : 'Add the translation service and key first.';
		}
		set_transient( 'mrsh_int_test', $m, 60 );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-int&ok=test' ) );
		exit;
	}
}
MRSH_Mem_Integr::init();
