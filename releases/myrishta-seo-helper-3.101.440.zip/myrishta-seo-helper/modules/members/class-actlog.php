<?php
/**
 * Activity log: what each member does on the site and who they contact, with automatic flags for bad behaviour.
 * Recorded: logins, messages and interests (with the receiver), winks, shortlist, gifts, phone requests, profile edits,
 * photo uploads, plan and verification requests, blocks, reports, email and password changes.
 * Flagged: abusive words, scam / money words, attempts to share contact details, and messages the site blocked.
 * The admin sees a red number on "Activity log", can mark flags as reviewed, warn the member by email, or block them.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Act {

	const OPT  = 'mrsh_act_set';
	const DBV  = 'mrsh_act_db';
	const SLUG = 'mrsh-activity';
	const CRON = 'mrsh_act_purge';

	public static function defaults() {
		return array(
			'abuse'  => "fuck\nfucking\nshit\nbitch\nbastard\nasshole\nslut\nwhore\ndick\npussy\nharami\nharamzada\nharamzadi\nkutta\nkutti\nkamina\nkameena\nkameeni\nchutiya\nbhenchod\nbehnchod\nmadarchod\ngandu\nlund\nrandi\nbewakoof\nstupid\nidiot",
			'scam'   => "easypaisa\njazzcash\nwestern union\nsend money\nsend me money\nbitcoin\ncrypto\ninvestment\nloan\nbank account\naccount number\nadvance payment\nprocessing fee\ngift card",
			'contact' => "whatsapp\nwhats app\ntelegram\nimo\ninstagram\nfacebook\nsnapchat\ncall me\nmy number\nmy phone\nphone number\ngmail.com\nyahoo.com\nhotmail.com",
			'days'   => 120,
			'text'   => 1,
		);
	}

	public static function get() {
		$o = get_option( self::OPT, array() );
		return array_merge( self::defaults(), is_array( $o ) ? $o : array() );
	}

	public static function tbl() {
		global $wpdb;
		return $wpdb->prefix . 'mrsh_actlog';
	}

	public static function init() {
		add_action( 'init', array( __CLASS__, 'install' ), 6 );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
		add_action( self::CRON, array( __CLASS__, 'purge' ) );
		if ( class_exists( 'MRSH_Master' ) && ! MRSH_Master::on( 'activity' ) ) {
			if ( is_admin() ) {
				add_action( 'admin_menu', array( __CLASS__, 'menu' ), 23 );
				add_action( 'admin_post_mrsh_act_do', array( __CLASS__, 'act' ) );
			}
			return;
		}
		add_action( 'wp_login', array( __CLASS__, 'on_login' ), 10, 2 );
		add_action( 'mrsh_member_act', array( __CLASS__, 'on_act' ), 10, 3 );
		add_action( 'mrsh_msg_sent', array( __CLASS__, 'on_msg' ), 10, 5 );
		add_action( 'added_user_meta', array( __CLASS__, 'on_umeta' ), 10, 4 );
		add_action( 'updated_user_meta', array( __CLASS__, 'on_umeta' ), 10, 4 );
		add_action( 'added_post_meta', array( __CLASS__, 'on_pmeta' ), 10, 4 );
		add_action( 'updated_post_meta', array( __CLASS__, 'on_pmeta' ), 10, 4 );
		add_action( 'profile_update', array( __CLASS__, 'on_profile_update' ), 10, 2 );
		add_action( 'after_password_reset', array( __CLASS__, 'on_pw_reset' ), 10, 1 );
		add_action( 'add_attachment', array( __CLASS__, 'on_attachment' ) );
		if ( is_admin() ) {
			add_action( 'admin_menu', array( __CLASS__, 'menu' ), 23 );
			add_action( 'admin_post_mrsh_act_do', array( __CLASS__, 'act' ) );
		}
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::CRON ) ) {
			wp_schedule_event( time() + 3600, 'daily', self::CRON );
		}
	}

	public static function install() {
		if ( (int) get_option( self::DBV, 0 ) >= 1 ) {
			return;
		}
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( 'CREATE TABLE ' . self::tbl() . " (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			uid BIGINT UNSIGNED NOT NULL DEFAULT 0,
			type VARCHAR(20) NOT NULL DEFAULT '',
			target BIGINT UNSIGNED NOT NULL DEFAULT 0,
			pid BIGINT UNSIGNED NOT NULL DEFAULT 0,
			detail TEXT NULL,
			flag TINYINT NOT NULL DEFAULT 0,
			reason VARCHAR(160) NOT NULL DEFAULT '',
			ip VARCHAR(45) NOT NULL DEFAULT '',
			created INT UNSIGNED NOT NULL DEFAULT 0,
			PRIMARY KEY  (id),
			KEY uid (uid),
			KEY flag (flag),
			KEY created (created)
		) " . $wpdb->get_charset_collate() . ';' );
		update_option( self::DBV, 1, false );
	}

	public static function purge() {
		global $wpdb;
		$d = max( 7, (int) self::get()['days'] );
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . self::tbl() . ' WHERE created < %d AND flag = 0', time() - $d * DAY_IN_SECONDS ) ); // phpcs:ignore WordPress.DB
		$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . self::tbl() . ' WHERE created < %d', time() - 2 * $d * DAY_IN_SECONDS ) ); // phpcs:ignore WordPress.DB
	}

	/* ---------- recording ---------- */

	/** Place of an IP address (cached 30 days). Looks up at most $budget new addresses per call; returns array or null. */
	public static function geo( $ip, &$budget ) {
		if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			return null;
		}
		if ( ! filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
			return array( 'cc' => '', 'place' => 'Private network', 'isp' => '', 'lat' => '', 'lon' => '' );
		}
		$key = 'mrsh_geo_' . md5( $ip );
		$c   = get_transient( $key );
		if ( is_array( $c ) ) {
			return $c;
		}
		if ( $budget <= 0 ) {
			return null;
		}
		$budget--;
		$r = wp_remote_get( 'https://ipwho.is/' . rawurlencode( $ip ) . '?fields=success,country,country_code,region,city,latitude,longitude,connection', array( 'timeout' => 3 ) );
		$j = is_wp_error( $r ) ? null : json_decode( wp_remote_retrieve_body( $r ), true );
		if ( ! is_array( $j ) || empty( $j['success'] ) ) {
			set_transient( $key, array( 'cc' => '', 'place' => 'Unknown', 'isp' => '', 'lat' => '', 'lon' => '' ), 6 * HOUR_IN_SECONDS );
			return null;
		}
		$place = implode( ', ', array_filter( array( $j['city'] ?? '', $j['region'] ?? '', $j['country'] ?? '' ) ) );
		$c     = array(
			'cc'    => strtoupper( (string) ( $j['country_code'] ?? '' ) ),
			'place' => $place ? $place : 'Unknown',
			'isp'   => (string) ( $j['connection']['isp'] ?? '' ),
			'lat'   => isset( $j['latitude'] ) ? (string) $j['latitude'] : '',
			'lon'   => isset( $j['longitude'] ) ? (string) $j['longitude'] : '',
		);
		set_transient( $key, $c, 30 * DAY_IN_SECONDS );
		return $c;
	}

	private static function geo_html( $ip, &$budget ) {
		if ( class_exists( 'MRSH_Switch' ) && ! MRSH_Switch::on( 'geoip' ) ) {
			return '';
		}
		$g = self::geo( $ip, $budget );
		if ( ! $g ) {
			return '<br><span class="description">Place not known yet</span>';
		}
		$flag = '';
		if ( 2 === strlen( $g['cc'] ) ) {
			$flag = mb_chr( 0x1F1E6 + ord( $g['cc'][0] ) - 65, 'UTF-8' ) . mb_chr( 0x1F1E6 + ord( $g['cc'][1] ) - 65, 'UTF-8' ) . ' ';
		}
		$out = '<br><b>' . esc_html( $flag . $g['place'] ) . '</b>';
		if ( $g['cc'] && 'PK' !== $g['cc'] ) {
			$out .= ' <span class="mx-pill bad">Outside Pakistan</span>';
		}
		if ( $g['isp'] ) {
			$out .= '<br><span class="description">' . esc_html( $g['isp'] ) . '</span>';
		}
		if ( '' !== $g['lat'] && '' !== $g['lon'] ) {
			$out .= '<br><a href="' . esc_url( 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $g['lat'] . ',' . $g['lon'] ) ) . '" target="_blank" rel="noopener">Map</a>';
		}
		return $out;
	}

	public static function ip() {
		foreach ( array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' ) as $k ) {
			if ( ! empty( $_SERVER[ $k ] ) ) {
				$v = trim( explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $k ] ) ) )[0] );
				if ( filter_var( $v, FILTER_VALIDATE_IP ) ) {
					return $v;
				}
			}
		}
		return '';
	}

	private static function skip_user( $uid ) {
		return ! $uid;
	}

	public static function log( $uid, $type, $target = 0, $pid = 0, $detail = '', $flag = 0, $reason = '' ) {
		if ( self::skip_user( $uid ) ) {
			return 0;
		}
		global $wpdb;
		self::install();
		$ok = $wpdb->insert( self::tbl(), array(
			'uid'     => (int) $uid,
			'type'    => substr( $type, 0, 20 ),
			'target'  => (int) $target,
			'pid'     => (int) $pid,
			'detail'  => mb_substr( (string) $detail, 0, 2000 ),
			'flag'    => $flag ? 1 : 0,
			'reason'  => mb_substr( (string) $reason, 0, 160 ),
			'ip'      => self::ip(),
			'created' => time(),
		) ); // phpcs:ignore WordPress.DB
		if ( $ok && $flag ) {
			update_user_meta( $uid, 'mrsh_flags', (int) get_user_meta( $uid, 'mrsh_flags', true ) + 1 );
			delete_transient( 'mrsh_cnt' );
			if ( class_exists( 'MRSH_Master' ) && MRSH_Master::on( 'flag_mail' ) ) {
				$u = get_userdata( $uid );
				wp_mail( get_option( 'admin_email' ), 'Flagged behaviour on My Rishta', ( $u ? $u->display_name : 'Member ' . $uid ) . ': ' . $reason . "\n\n" . admin_url( 'admin.php?page=mrsh-activity&uid=' . (int) $uid ) );
			}
		}
		return $ok ? (int) $wpdb->insert_id : 0;
	}

	/* ---------- bad behaviour detection ---------- */

	private static function terms( $key ) {
		$out = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) self::get()[ $key ] ) as $w ) {
			$w = strtolower( trim( $w ) );
			if ( '' !== $w ) {
				$out[] = $w;
			}
		}
		return $out;
	}

	private static function has( $text, $term ) {
		if ( preg_match( '/^[a-z0-9 .@_\-]+$/', $term ) ) {
			return (bool) preg_match( '/(?<![a-z0-9])' . preg_quote( $term, '/' ) . '(?![a-z0-9])/i', $text );
		}
		return false !== mb_stripos( $text, $term );
	}

	/** Returns a short reason when the text breaks the rules, else an empty string. */
	public static function scan( $text, $allow_contact = false ) {
		$t = mb_strtolower( (string) $text );
		if ( '' === trim( $t ) ) {
			return '';
		}
		$leet = strtr( $t, array( '0' => 'o', '1' => 'i', '3' => 'e', '@' => 'a', '$' => 's', '!' => 'i' ) );
		$why  = array();
		foreach ( self::terms( 'abuse' ) as $w ) {
			if ( self::has( $t, $w ) || self::has( $leet, $w ) ) {
				$why[] = 'abusive word "' . $w . '"';
				break;
			}
		}
		foreach ( self::terms( 'scam' ) as $w ) {
			if ( self::has( $t, $w ) ) {
				$why[] = 'money / scam word "' . $w . '"';
				break;
			}
		}
		if ( ! $allow_contact ) {
			foreach ( self::terms( 'contact' ) as $w ) {
				if ( self::has( $t, $w ) ) {
					$why[] = 'contact detail "' . $w . '"';
					break;
				}
			}
			if ( preg_match( '#https?://|www\.#i', $t ) ) {
				$why[] = 'link';
			}
			if ( preg_match( '/\b(?:\+?92|0)?3\d{2}[\s\-]?\d{7}\b|\b\d[\d\s\-]{8,}\d\b/', $t ) ) {
				$why[] = 'phone number';
			}
		}
		return implode( ', ', $why );
	}

	private static function shown( $text ) {
		return self::get()['text'] ? (string) $text : '(text not stored)';
	}

	/* ---------- hooks ---------- */

	public static function on_login( $login, $user ) {
		if ( $user && ! user_can( $user, 'manage_options' ) ) {
			self::log( $user->ID, 'login', 0, 0, 'Logged in' );
		}
	}

	/** Every ajax action of the member area (see MRSH_Members::ajax). */
	public static function on_act( $ctx, $ok, $msg ) {
		$uid = (int) $ctx['uid'];
		$act = (string) $ctx['act'];
		$to  = (int) $ctx['to'];
		$pid = (int) $ctx['pid'];
		if ( 'msg' === $act || 'interest' === $act ) {
			if ( $ok ) {
				return; // a sent message is recorded by on_msg with its text
			}
			$txt = isset( $_POST['text'] ) ? trim( wp_strip_all_tags( (string) wp_unslash( $_POST['text'] ) ) ) : ''; // phpcs:ignore
			$blk = preg_match( '/not allowed|links and phone|money|safety|cannot be sent/i', $msg );
			if ( 'msg' === $act && '' !== $txt ) {
				$r = self::scan( $txt );
				self::log( $uid, 'blocked', $to, $pid, self::shown( $txt ) . "\n[Site said: " . $msg . ']', $blk || $r ? 1 : 0, $blk ? 'message blocked by the site' . ( $r ? ': ' . $r : '' ) : $r );
			}
			return;
		}
		if ( ! $ok ) {
			return;
		}
		$types = array( 'wink' => 'wink', 'fav' => 'shortlist', 'gift' => 'gift', 'phonereq' => 'phone_req', 'hit' => 'rate', 'miss' => 'rate' );
		if ( isset( $types[ $act ] ) ) {
			self::log( $uid, $types[ $act ], $to, $pid, ucfirst( $act ) . ': ' . $msg );
		}
	}

	public static function on_msg( $id, $from, $to, $text, $pid ) {
		if ( user_can( $from, 'manage_options' ) ) {
			return;
		}
		$int = 0 === strpos( $text, 'I am interested in your profile' );
		$r   = $int ? '' : self::scan( $text );
		self::log( $from, $int ? 'interest' : 'message', $to, $pid, $int ? 'Sent interest' : self::shown( $text ), $r ? 1 : 0, $r );
	}

	public static function on_umeta( $mid, $uid, $key, $val ) {
		if ( get_current_user_id() !== (int) $uid ) {
			return;
		}
		$map = array( 'mrt_plan' => 'plan', 'mrt_plan_req' => 'plan', 'mrt_vreq' => 'verify', 'mrt_phone' => 'profile', 'mrt_photo_priv' => 'profile', 'mrt_hidden' => 'profile', 'mrt_away' => 'profile', 'blocked' => 'block', 'mrt_my_blocks' => 'block', 'mrt_my_reports' => 'report' );
		if ( ! isset( $map[ $key ] ) ) {
			return;
		}
		$v = is_scalar( $val ) ? (string) $val : wp_json_encode( $val );
		$k = 'mrsh_ac_' . md5( $uid . $key . $v );
		if ( get_transient( $k ) ) {
			return;
		}
		set_transient( $k, 1, 30 );
		$names = array( 'mrt_plan' => 'Plan changed to', 'mrt_plan_req' => 'Asked for plan', 'mrt_vreq' => 'Asked to be verified', 'mrt_phone' => 'Phone number changed', 'mrt_photo_priv' => 'Photo privacy set to', 'mrt_hidden' => 'Profile hidden setting', 'mrt_away' => 'Away mode', 'blocked' => 'Blocked members list changed', 'mrt_my_blocks' => 'Blocked members list changed', 'mrt_my_reports' => 'Reported a profile' );
		$show = in_array( $key, array( 'mrt_plan', 'mrt_plan_req', 'mrt_photo_priv', 'mrt_away' ), true ) ? ' ' . mb_substr( $v, 0, 80 ) : '';
		self::log( $uid, $map[ $key ], 0, 0, $names[ $key ] . $show );
	}

	public static function on_pmeta( $mid, $pid, $key, $val ) {
		$p = get_post( $pid );
		if ( ! $p || 'listing_type' !== $p->post_type || get_current_user_id() !== (int) $p->post_author || user_can( $p->post_author, 'manage_options' ) ) {
			return;
		}
		if ( '_' === substr( (string) $key, 0, 1 ) || preg_match( '/^(winks|hits|views|msg_|mrt_|featured|expire|ppt_|_)/i', (string) $key ) || ! is_scalar( $val ) ) {
			return;
		}
		$v = trim( (string) $val );
		if ( '' === $v ) {
			return;
		}
		$k = 'mrsh_ap_' . md5( $pid . $key . $v );
		if ( get_transient( $k ) ) {
			return;
		}
		set_transient( $k, 1, 120 );
		$r = strlen( $v ) > 3 ? self::scan( $v, true ) : '';
		self::log( (int) $p->post_author, 'profile_edit', 0, (int) $pid, $key . ': ' . mb_substr( $v, 0, 300 ), $r ? 1 : 0, $r );
	}

	public static function on_profile_update( $uid, $old ) {
		if ( get_current_user_id() !== (int) $uid ) {
			return;
		}
		$u = get_userdata( $uid );
		if ( $u && $old && $u->user_email !== $old->user_email ) {
			self::log( $uid, 'account', 0, 0, 'Email changed from ' . $old->user_email . ' to ' . $u->user_email );
		}
		if ( $u && $old && $u->user_pass !== $old->user_pass ) {
			self::log( $uid, 'account', 0, 0, 'Password changed' );
		}
	}

	public static function on_pw_reset( $user ) {
		if ( $user ) {
			self::log( $user->ID, 'account', 0, 0, 'Password reset by email link' );
		}
	}

	public static function on_attachment( $aid ) {
		$a = get_post( $aid );
		if ( $a && get_current_user_id() === (int) $a->post_author && ! user_can( $a->post_author, 'manage_options' ) && wp_attachment_is_image( $aid ) ) {
			self::log( (int) $a->post_author, 'photo', 0, 0, 'Uploaded a picture (#' . (int) $aid . ')' );
		}
	}

	/* ---------- admin page ---------- */

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Activity log', 'Activity log', 'manage_options', self::SLUG, array( __CLASS__, 'page' ) );
	}

	public static function open_flags() {
		global $wpdb;
		self::install();
		return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::tbl() . ' WHERE flag=1' ); // phpcs:ignore WordPress.DB
	}

	public static function act() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_act_do' );
		global $wpdb;
		delete_transient( 'mrsh_cnt' );
		$do   = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
		$back = wp_get_referer() ? remove_query_arg( 'msg', wp_get_referer() ) : admin_url( 'admin.php?page=' . self::SLUG );
		$msg  = 'Done.';
		if ( ! empty( $_POST['bip'] ) && class_exists( 'MRSH_Guard' ) ) {
			$msg = MRSH_Guard::add_ip( sanitize_text_field( wp_unslash( $_POST['bip'] ) ) );
			wp_safe_redirect( add_query_arg( 'msg', rawurlencode( $msg ), $back ) );
			exit;
		}
		if ( 'save_set' === $do ) {
			$o = get_option( self::OPT, array() );
			$o = is_array( $o ) ? $o : array();
			foreach ( array( 'abuse', 'scam', 'contact' ) as $k ) {
				$o[ $k ] = isset( $_POST[ $k ] ) ? sanitize_textarea_field( wp_unslash( $_POST[ $k ] ) ) : '';
			}
			$o['days'] = max( 7, min( 730, absint( $_POST['days'] ?? 120 ) ) );
			$o['text'] = empty( $_POST['text'] ) ? 0 : 1;
			update_option( self::OPT, array_merge( self::defaults(), $o ), false );
			$msg = 'Settings saved.';
		} elseif ( 'review_all' === $do ) {
			$wpdb->query( 'UPDATE ' . self::tbl() . ' SET flag=2 WHERE flag=1' ); // phpcs:ignore WordPress.DB
			$msg = 'All flags marked as reviewed.';
		} else {
			$rid = 0;
			$uid = 0;
			if ( preg_match( '/^(review|warn|block)_(\d+)_(\d+)$/', $do, $m ) ) {
				$do  = $m[1];
				$rid = (int) $m[2];
				$uid = (int) $m[3];
			}
			if ( 'review' === $do && $rid ) {
				$wpdb->update( self::tbl(), array( 'flag' => 2 ), array( 'id' => $rid ) ); // phpcs:ignore WordPress.DB
				$msg = 'Marked as reviewed.';
			} elseif ( 'warn' === $do && $uid && ( $u = get_userdata( $uid ) ) ) { // phpcs:ignore WordPress.CodeAnalysis.AssignmentInCondition
				$text = "Hello " . ( $u->display_name ?: '' ) . ",\n\nWe noticed activity on your My Rishta account that goes against our rules (respectful language, no sharing of phone numbers or links in messages, and no requests for money).\n\nPlease keep your messages respectful and safe. If this continues, your account may be suspended.\n\nMy Rishta Pakistan Support\n" . home_url( '/' );
				if ( class_exists( 'MRSH_Mailq' ) ) {
					MRSH_Mailq::add( $u->user_email, 'A reminder about My Rishta rules', $text, array( 'kind' => 'warning', 'uid' => $uid ) );
				} else {
					wp_mail( $u->user_email, 'A reminder about My Rishta rules', $text );
				}
				self::log( $uid, 'admin', 0, 0, 'Admin sent a warning email' );
				if ( $rid ) {
					$wpdb->update( self::tbl(), array( 'flag' => 2 ), array( 'id' => $rid ) ); // phpcs:ignore WordPress.DB
				}
				$msg = 'Warning email queued for ' . $u->user_email . '.';
			} elseif ( 'block' === $do && $uid && ! user_can( $uid, 'manage_options' ) ) {
				update_user_meta( $uid, 'mrt_banned', 1 );
				$p = class_exists( 'MRSH_Members' ) ? MRSH_Members::my_profile( $uid ) : null;
				if ( $p && 'publish' === $p->post_status ) {
					wp_update_post( array( 'ID' => $p->ID, 'post_status' => 'draft' ) );
				}
				self::log( $uid, 'admin', 0, 0, 'Admin blocked this member' );
				if ( $rid ) {
					$wpdb->update( self::tbl(), array( 'flag' => 2 ), array( 'id' => $rid ) ); // phpcs:ignore WordPress.DB
				}
				$msg = 'Member blocked and profile paused.';
			}
		}
		wp_safe_redirect( add_query_arg( 'msg', rawurlencode( $msg ), $back ) );
		exit;
	}

	private static function who( $uid ) {
		$u = $uid ? get_userdata( $uid ) : null;
		if ( ! $u ) {
			return '<span class="description">-</span>';
		}
		return '<a href="' . esc_url( add_query_arg( array( 'page' => self::SLUG, 'uid' => (int) $uid ), admin_url( 'admin.php' ) ) ) . '"><b>' . esc_html( $u->display_name ?: $u->user_login ) . '</b></a> <span class="description">#' . (int) $uid . '</span><br><span class="description">' . esc_html( $u->user_email ) . '</span>';
	}

	private static function types() {
		return array( 'message' => 'Message', 'interest' => 'Interest', 'blocked' => 'Message blocked', 'wink' => 'Wink', 'shortlist' => 'Shortlist', 'gift' => 'Gift', 'phone_req' => 'Phone request', 'rate' => 'Hit / Miss', 'login' => 'Login', 'profile_edit' => 'Profile edit', 'profile' => 'Profile setting', 'photo' => 'Photo', 'plan' => 'Plan', 'verify' => 'Verification', 'block' => 'Block', 'report' => 'Report', 'account' => 'Account', 'admin' => 'Admin action' );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		self::install();
		if ( ! class_exists( 'MRSH_Boost' ) ) {
			echo '<div class="wrap"><h1>Activity log</h1><p>The page styles are missing. Reinstall the plugin zip.</p></div>';
			return;
		}
		global $wpdb;
		$t   = self::tbl();
		$uid = isset( $_GET['uid'] ) ? absint( $_GET['uid'] ) : 0; // phpcs:ignore
		$q   = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : ''; // phpcs:ignore
		$ty  = isset( $_GET['ty'] ) ? sanitize_key( $_GET['ty'] ) : ''; // phpcs:ignore
		$fl  = isset( $_GET['fl'] ) ? sanitize_key( $_GET['fl'] ) : ''; // phpcs:ignore
		$rg  = isset( $_GET['rg'] ) ? sanitize_key( $_GET['rg'] ) : '7'; // phpcs:ignore
		$pg  = isset( $_GET['pg'] ) ? max( 1, absint( $_GET['pg'] ) ) : 1; // phpcs:ignore
		MRSH_Boost::ui_open( 'Activity log', 'What members do and who they contact. Messages with bad words, scam or contact details are flagged in red. Open a flag, then warn or block the member.', 'g-red', 'M3 4h18v2H3zm0 5h18v2H3zm0 5h12v2H3zm0 5h18v2H3z' );
		if ( isset( $_GET['msg'] ) ) { // phpcs:ignore
			MRSH_Boost::ui_ok( sanitize_text_field( wp_unslash( $_GET['msg'] ) ) ); // phpcs:ignore
		}
		$open  = self::open_flags();
		$today = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . $t . ' WHERE created > %d', time() - DAY_IN_SECONDS ) ); // phpcs:ignore WordPress.DB
		$msgs  = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . $t . " WHERE type='message' AND created > %d", time() - DAY_IN_SECONDS ) ); // phpcs:ignore WordPress.DB
		echo '<div class="mx-stats">' . MRSH_Boost::ui_stat( $open, 'Flags to review', '#e11d48' ) . MRSH_Boost::ui_stat( $today, 'Actions in 24 h', '#4a69d6' ) . MRSH_Boost::ui_stat( $msgs, 'Messages in 24 h', '#7c3aed' ) . '</div>'; // phpcs:ignore

		$where = '1=1';
		$fip   = isset( $_GET['ip'] ) ? sanitize_text_field( wp_unslash( $_GET['ip'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		if ( $fip && filter_var( $fip, FILTER_VALIDATE_IP ) ) {
			$where .= $wpdb->prepare( ' AND ip=%s', $fip );
		}
		if ( $uid ) {
			$where .= $wpdb->prepare( ' AND (uid=%d OR target=%d)', $uid, $uid );
		}
		if ( '' !== $q ) {
			$like  = '%' . $wpdb->esc_like( $q ) . '%';
			$ids   = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->users} WHERE user_email LIKE %s OR display_name LIKE %s OR user_login LIKE %s LIMIT 50", $like, $like, $like ) ); // phpcs:ignore WordPress.DB
			$where .= $ids ? ' AND (uid IN (' . implode( ',', array_map( 'intval', $ids ) ) . ') OR target IN (' . implode( ',', array_map( 'intval', $ids ) ) . '))' : ' AND 1=0';
		}
		if ( '' !== $ty && isset( self::types()[ $ty ] ) ) {
			$where .= $wpdb->prepare( ' AND type=%s', $ty );
		}
		if ( 'open' === $fl ) {
			$where .= ' AND flag=1';
		} elseif ( 'all' === $fl ) {
			$where .= ' AND flag>0';
		}
		if ( 'all' !== $rg ) {
			$where .= $wpdb->prepare( ' AND created > %d', time() - max( 1, (int) $rg ) * DAY_IN_SECONDS );
		}
		$per   = 50;
		$total = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . $t . ' WHERE ' . $where ); // phpcs:ignore WordPress.DB
		$rows  = $wpdb->get_results( 'SELECT * FROM ' . $t . ' WHERE ' . $where . ' ORDER BY id DESC LIMIT ' . (int) $per . ' OFFSET ' . (int) ( ( $pg - 1 ) * $per ) ); // phpcs:ignore WordPress.DB
		$base  = admin_url( 'admin.php?page=' . self::SLUG );

		if ( $uid && ( $uu = get_userdata( $uid ) ) ) { // phpcs:ignore WordPress.CodeAnalysis.AssignmentInCondition
			echo '<div class="mx-card"><b>Showing everything about ' . esc_html( $uu->display_name ) . '</b> (' . esc_html( $uu->user_email ) . '), actions by this member and actions towards them. Flags so far: <b>' . (int) get_user_meta( $uid, 'mrsh_flags', true ) . '</b>. <a class="mx-btn s" href="' . esc_url( $base ) . '">Show everyone</a> <a class="mx-btn s" href="' . esc_url( add_query_arg( array( 'page' => 'mrsh-desk', 'q' => $uu->user_email ), admin_url( 'admin.php' ) ) ) . '">Member manager</a></div>';
		}
		if ( $fip ) {
			echo '<div class="mx-card"><b>Showing only IP ' . esc_html( $fip ) . '</b> <a class="mx-btn s" href="' . esc_url( admin_url( 'admin.php?page=' . self::SLUG ) ) . '">Show all</a></div>';
		}
		echo '<form method="get" class="mx-tabs"><input type="hidden" name="page" value="' . esc_attr( self::SLUG ) . '">' . ( $uid ? '<input type="hidden" name="uid" value="' . (int) $uid . '">' : '' );
		echo '<input type="search" name="q" value="' . esc_attr( $q ) . '" placeholder="Member name or email"> <select name="ty"><option value="">All actions</option>';
		foreach ( self::types() as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $ty, $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select> <select name="fl">';
		foreach ( array( '' => 'Everything', 'open' => 'Flags to review', 'all' => 'All flags' ) as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $fl, $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select> <select name="rg">';
		foreach ( array( '1' => 'Last 24 hours', '7' => 'Last 7 days', '30' => 'Last 30 days', 'all' => 'All time' ) as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $rg, (string) $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select> <button class="mx-btn p s">Show</button> <span class="mx-msg" style="margin:0">' . (int) $total . ' records</span></form>';

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_act_do">';
		wp_nonce_field( 'mrsh_act_do' );
		echo '<p class="mx-tabs"><button name="do" value="review_all" class="mx-btn s">Mark all flags as reviewed</button></p>';
		echo '<div class="mx-tbl"><table class="widefat striped"><thead><tr><th>When</th><th>Member</th><th>Action</th><th>To / about</th><th>Detail</th><th>IP</th><th></th></tr></thead><tbody>';
		if ( ! $rows ) {
			echo '<tr><td colspan="7">Nothing recorded for this filter yet. Records start after the plugin update.</td></tr>';
		}
		$ty_l = self::types();
		$gb   = 8;
		foreach ( $rows as $r ) {
			$bg = 1 === (int) $r->flag ? ' style="background:#fff1f2"' : '';
			echo '<tr' . $bg . '><td>' . esc_html( wp_date( 'j M H:i', (int) $r->created ) ) . '</td><td>' . self::who( (int) $r->uid ) . '</td><td><span class="mx-pill' . ( $r->flag ? ' bad' : '' ) . '">' . esc_html( $ty_l[ $r->type ] ?? $r->type ) . '</span></td><td>' . self::who( (int) $r->target );
			if ( $r->pid && get_post( (int) $r->pid ) ) {
				echo '<br><a href="' . esc_url( get_permalink( (int) $r->pid ) ) . '" target="_blank" rel="noopener">View profile</a>';
			}
			echo '</td><td style="max-width:380px;word-break:break-word">' . nl2br( esc_html( $r->detail ) );
			if ( $r->flag ) {
				echo '<br><b style="color:#b42318">' . ( 2 === (int) $r->flag ? 'Reviewed: ' : 'FLAG: ' ) . esc_html( $r->reason ) . '</b>';
			}
			echo '</td><td style="min-width:170px"><span class="description">' . esc_html( $r->ip ) . '</span>' . self::geo_html( (string) $r->ip, $gb ) . ( class_exists( 'MRSH_Guard' ) ? MRSH_Guard::ip_tools( (string) $r->ip ) : '' ) . '</td><td style="min-width:150px">';
			if ( 1 === (int) $r->flag ) {
				echo '<button name="do" value="review_' . (int) $r->id . '_' . (int) $r->uid . '" class="mx-btn s">Reviewed</button> <button name="do" value="warn_' . (int) $r->id . '_' . (int) $r->uid . '" class="mx-btn s">Warn</button> <button name="do" value="block_' . (int) $r->id . '_' . (int) $r->uid . '" class="mx-btn s d" onclick="return confirm(\'Block this member and pause the profile?\')">Block</button>';
			}
			echo '</td></tr>';
		}
		echo '</tbody></table></div></form>';
		$pages = max( 1, (int) ceil( $total / $per ) );
		if ( $pages > 1 ) {
			echo '<div class="mx-tabs" style="margin-top:12px">';
			for ( $i = max( 1, $pg - 4 ); $i <= min( $pages, $pg + 4 ); $i++ ) {
				echo '<a class="mx-btn s' . ( $i === $pg ? ' p' : '' ) . '" href="' . esc_url( add_query_arg( array( 'uid' => $uid ?: null, 'q' => $q, 'ty' => $ty, 'fl' => $fl, 'rg' => $rg, 'pg' => $i ), $base ) ) . '">' . (int) $i . '</a>';
			}
			echo '</div>';
		}

		$s = self::get();
		echo '<div class="mx-card" style="margin-top:20px"><h2>Settings: what counts as bad behaviour</h2><p class="mx-sub">One word or phrase per line. Matching ignores capital letters. Messages the site already blocks (links, phone numbers, money requests, your blocked words) are also logged and flagged.</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_act_do"><input type="hidden" name="do" value="save_set">';
		wp_nonce_field( 'mrsh_act_do' );
		echo '<table class="form-table">';
		foreach ( array( 'abuse' => 'Abusive words', 'scam' => 'Money and scam words', 'contact' => 'Contact details' ) as $k => $l ) {
			echo '<tr><th>' . esc_html( $l ) . '</th><td><textarea name="' . esc_attr( $k ) . '" rows="5" class="large-text">' . esc_textarea( $s[ $k ] ) . '</textarea></td></tr>';
		}
		echo '<tr><th>Keep records for</th><td><input type="number" name="days" min="7" max="730" value="' . (int) $s['days'] . '" style="width:90px"> days. <span class="description">Flagged items are kept twice as long.</span></td></tr>';
		echo '<tr><th>Store message text</th><td><label><input type="checkbox" name="text" value="1"' . checked( $s['text'], 1, false ) . '> Keep the text of messages in the log</label></td></tr></table>';
		echo '<p><button class="mx-btn p s">Save</button></p></form><p class="description">Tell your members that activity is monitored for safety: add one sentence about it in your Privacy Policy page.</p></div>';
		echo '</div>';
	}
}
MRSH_Act::init();
