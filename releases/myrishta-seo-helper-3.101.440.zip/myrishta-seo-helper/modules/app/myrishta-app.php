<?php
/**
 * Plugin Name: My Rishta App
 * Description: Serves the My Rishta App (installable phone app, PWA) at /app/ on this site. Reads the site's own guides and links to its real pages. No tracking, no data stored.
 * Version: 1.13.1
 * Author: MyRishta
 * Requires PHP: 7.4
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'MRAPP_VERSION', '1.13.1' );
define( 'MRAPP_DIR', plugin_dir_path( __FILE__ ) . 'app/' );

/** Path of the request below the site folder, e.g. "/app/assets/x.js". */
function mrapp_request_path() {
	$uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '/';
	$path = (string) wp_parse_url( $uri, PHP_URL_PATH );
	$base = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
	$base = '' === $base ? '/' : $base;
	if ( '/' !== $base && 0 === strpos( $path, rtrim( $base, '/' ) ) ) {
		$path = substr( $path, strlen( rtrim( $base, '/' ) ) );
	}
	return rawurldecode( '' === $path ? '/' : $path );
}

function mrapp_mime( $file ) {
	$map = array(
		'html' => 'text/html; charset=utf-8', 'js' => 'application/javascript; charset=utf-8',
		'css' => 'text/css; charset=utf-8', 'json' => 'application/json; charset=utf-8',
		'webmanifest' => 'application/manifest+json; charset=utf-8', 'svg' => 'image/svg+xml',
		'png' => 'image/png', 'webp' => 'image/webp', 'jpg' => 'image/jpeg', 'ico' => 'image/x-icon',
		'woff2' => 'font/woff2', 'txt' => 'text/plain; charset=utf-8',
	);
	$ext = strtolower( pathinfo( $file, PATHINFO_EXTENSION ) );
	return isset( $map[ $ext ] ) ? $map[ $ext ] : 'application/octet-stream';
}

function mrapp_serve() {
	$path = mrapp_request_path();
	if ( '/app' === $path ) {
		wp_safe_redirect( home_url( '/app/' ), 301 );
		exit;
	}
	if ( 0 !== strpos( $path, '/app/' ) ) {
		return;
	}
	// Always run on the main site address (for example not on the www. copy), because the app reads the site's pages
	// and the browser only allows that on the same address.
	$home_host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
	$req_host  = isset( $_SERVER['HTTP_HOST'] ) ? strtolower( preg_replace( '/:\d+$/', '', (string) wp_unslash( $_SERVER['HTTP_HOST'] ) ) ) : '';
	if ( $home_host && $req_host && $req_host !== strtolower( $home_host ) && preg_match( '/^www\./', $req_host ) ) {
		$qs = isset( $_SERVER['QUERY_STRING'] ) && '' !== $_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '';
		wp_redirect( home_url( $path ) . $qs, 301 ); // phpcs:ignore WordPress.Security.SafeRedirect
		exit;
	}
	$rel = ltrim( substr( $path, 5 ), '/' );
	if ( '' === $rel ) {
		$rel = 'index.html';
	}
	// The My Rishta theme is now the app itself (installable, with its own add-profile form). Old /app/ visitors
	// and phones that installed the old app are moved to the new site, and the old app's saved files are cleared.
	if ( 'myrishta' === get_option( 'template' ) && ( 'index.html' === $rel || 'sw.js' === $rel ) ) {
		$home = home_url( '/?pwa=1' );
		nocache_headers();
		header( 'X-LiteSpeed-Cache-Control: no-cache' );
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		status_header( 200 );
		if ( 'sw.js' === $rel ) {
			header( 'Content-Type: application/javascript; charset=utf-8' );
			header( 'Service-Worker-Allowed: ' . (string) wp_parse_url( home_url( '/app/' ), PHP_URL_PATH ) );
			echo "self.addEventListener('install',function(){self.skipWaiting()});self.addEventListener('activate',function(e){e.waitUntil(caches.keys().then(function(k){return Promise.all(k.map(function(n){return caches.delete(n)}))}).then(function(){return self.registration.unregister()}).then(function(){return self.clients.matchAll({type:'window'})}).then(function(cs){cs.forEach(function(c){c.navigate(" . wp_json_encode( $home ) . ")})}))});self.addEventListener('fetch',function(){});"; // phpcs:ignore
			exit;
		}
		header( 'Content-Type: text/html; charset=utf-8' );
		echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="1;url=' . esc_url( $home ) . '"><title>My Rishta</title></head><body style="margin:0;font-family:system-ui,sans-serif;text-align:center;padding:22vh 24px;background:#fff7fa;color:#1f2937"><h2 style="margin:0 0 6px">My Rishta has a new look</h2><p style="color:#6b7280">Opening the new app...</p><p><a href="' . esc_url( $home ) . '" style="display:inline-block;margin-top:10px;padding:12px 24px;border-radius:12px;background:#e11d74;color:#fff;font-weight:700;text-decoration:none">Open now</a></p><script>try{navigator.serviceWorker&&navigator.serviceWorker.getRegistrations().then(function(r){r.forEach(function(x){x.unregister()})});caches&&caches.keys().then(function(k){k.forEach(function(n){caches.delete(n)})})}catch(e){}location.replace(' . wp_json_encode( $home ) . ');</script></body></html>'; // phpcs:ignore
		exit;
	}
	$base = realpath( MRAPP_DIR );
	$file = $base ? realpath( MRAPP_DIR . $rel ) : false;
	// Never serve anything outside the app folder.
	if ( ! $file || 0 !== strpos( $file, $base . DIRECTORY_SEPARATOR ) || ! is_file( $file ) ) {
		status_header( 404 );
		nocache_headers();
		echo 'Not found';
		exit;
	}
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );
	}
	status_header( 200 );
	header( 'Content-Type: ' . mrapp_mime( $file ) );
	header( 'X-Content-Type-Options: nosniff' );
	$hashed = 0 === strpos( $rel, 'assets/' ) || 0 === strpos( $rel, 'fonts/' ) || 0 === strpos( $rel, 'art/' );
	if ( $hashed ) {
		header( 'Cache-Control: public, max-age=2592000' );
	} else {
		header( 'Cache-Control: no-cache' ); // index.html, sw.js, manifest: always re-check.
		header( 'X-LiteSpeed-Cache-Control: no-cache' );
	}
	if ( 'sw.js' === $rel ) {
		header( 'Service-Worker-Allowed: ' . (string) wp_parse_url( home_url( '/app/' ), PHP_URL_PATH ) );
	}
	// Files are pre-compressed with Brotli at the highest level when the build made a .br copy (about 70% smaller
	// than the plain file, and smaller than the server's on-the-fly compression).
	if ( class_exists( 'MRSH_Names' ) && MRSH_Names::active() && preg_match( '/\.(js|html|json|webmanifest)$/i', $file ) && 'sw.js' !== $rel ) {
		header( 'Cache-Control: no-cache' );
		$txt = (string) file_get_contents( $file ); // phpcs:ignore
		$txt = preg_match( '/\.js$/i', $file ) ? MRSH_Names::t_js( $txt ) : MRSH_Names::t( $txt );
		header( 'Content-Length: ' . strlen( $txt ) );
		echo $txt; // phpcs:ignore
		exit;
	}
	$send = $file;
	$ae   = isset( $_SERVER['HTTP_ACCEPT_ENCODING'] ) ? (string) $_SERVER['HTTP_ACCEPT_ENCODING'] : '';
	header( 'Vary: Accept-Encoding' );
	if ( false !== stripos( $ae, 'br' ) && is_readable( $file . '.br' ) ) {
		$send = $file . '.br';
		header( 'Content-Encoding: br' );
	}
	header( 'Content-Length: ' . filesize( $send ) );
	readfile( $send );
	exit;
}
// Runs as soon as plugins are loaded (before the theme, Elementor and other plugins start up), so /app/ files are served quickly and no rewrite rules are needed.
add_action( 'plugins_loaded', 'mrapp_serve', 0 );

/**
 * Phone visitors who open the home page are taken to the app (/app/).
 * Done in the browser (not in PHP) so page caching cannot get in the way.
 * Not applied to search engines and link previews, to tablets/desktops, to pages shown
 * inside the app, or to people who chose "Full website" (remembered on that phone).
 * Other pages (profiles, blog, shared links) always open as normal.
 */
function mrapp_mobile_redirect() {
	if ( is_admin() || ! is_front_page() ) {
		return;
	}
	$app = esc_url_raw( home_url( '/app/' ) );
	?>
<script id="mrapp-redirect">(function(){try{
var u=navigator.userAgent||"",q=location.search;
if(window.self!==window.top)return;
if(/bot|crawl|spider|slurp|google|bing|yandex|baidu|duckduck|facebookexternalhit|whatsapp|telegram|preview|lighthouse|headless/i.test(u))return;
if(!/iPhone|iPod|Android.*Mobile|Windows Phone/i.test(u))return;
if(/[?&]web=1/.test(q)){localStorage.setItem("mr_web","1");return}
if(localStorage.getItem("mr_web")==="1")return;
if(/[?&](s|reset)=/.test(q))return;
location.replace(<?php echo wp_json_encode( $app ); ?>);
}catch(e){}})();</script>
	<?php
}
add_action( 'wp_head', 'mrapp_mobile_redirect', 1 );
