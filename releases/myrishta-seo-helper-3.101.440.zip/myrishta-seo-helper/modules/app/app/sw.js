// Fast start + offline: the app files are kept on the phone. Only files under /app/ are touched,
// never the website's own pages (those must always be fresh, for example sign-in forms).
const CACHE = 'myrishta-v3';
const SCOPE = new URL(self.registration.scope).pathname;
self.addEventListener('install', () => { self.skipWaiting(); });
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
const save = (req, res) => { if (res && res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); } return res; };
self.addEventListener('fetch', (e) => {
  const req = e.request; const url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== location.origin || !url.pathname.startsWith(SCOPE)) return;
  // Built files have a fingerprint in their name: serve from the phone first.
  if (/\/(assets|fonts|art)\//.test(url.pathname) || /icon-\d+\.png$/.test(url.pathname)) {
    e.respondWith(caches.match(req).then((hit) => hit || fetch(req).then((res) => save(req, res))));
    return;
  }
  // The page itself: ask the network, but do not make anyone wait more than 2.5 seconds.
  e.respondWith(new Promise((resolve) => {
    let settled = false;
    const fromCache = () => caches.match(req).then((r) => r || caches.match(SCOPE)).then((r) => { if (r && !settled) { settled = true; resolve(r); } });
    const t = setTimeout(fromCache, 2500);
    fetch(req).then((res) => { clearTimeout(t); if (!settled) { settled = true; resolve(save(req, res)); } else save(req, res); })
      .catch(() => { clearTimeout(t); fromCache().then(() => { if (!settled) fetch(req).then(resolve); }); });
  }));
});
