import{c as i,u as e,G as f,k as u,P as b,O as o,R as a,o as t,L as s,l as w,U as g,m as N,p as x,q as v,f as C,r as M,M as P,s as S,I as c,i as A}from"./index-B0C3EaDV.js";import{M as I}from"./message-circle-BNGxonfW.js";import{S as R}from"./share-2-5ZkdgI4J.js";import{M as H}from"./mail-Dgn-vVKr.js";/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const U=i("CircleHelp",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3",key:"1u773s"}],["path",{d:"M12 17h.01",key:"p32p05"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const r=i("Download",[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"7 10 12 15 17 10",key:"2ggqvy"}],["line",{x1:"12",x2:"12",y1:"15",y2:"3",key:"1vk2je"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const E=i("Facebook",[["path",{d:"M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z",key:"1jg4f8"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const F=i("Newspaper",[["path",{d:"M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-2 2Zm0 0a2 2 0 0 1-2-2v-9c0-1.1.9-2 2-2h2",key:"7pis2x"}],["path",{d:"M18 14h-8",key:"sponae"}],["path",{d:"M15 18h-5",key:"95g1m2"}],["path",{d:"M10 6h8v4h-8V6Z",key:"smlsk5"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const G=i("Phone",[["path",{d:"M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z",key:"foiqr5"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const L=i("ScrollText",[["path",{d:"M15 12h-5",key:"r7krc0"}],["path",{d:"M15 8h-5",key:"1khuty"}],["path",{d:"M19 17V5a2 2 0 0 0-2-2H4",key:"zz82l3"}],["path",{d:"M8 21h12a2 2 0 0 0 2-2v-1a1 1 0 0 0-1-1H11a1 1 0 0 0-1 1v1a2 2 0 1 1-4 0V5a2 2 0 1 0-4 0v2a1 1 0 0 0 1 1h3",key:"1ph1d7"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const O=i("Settings2",[["path",{d:"M20 7h-9",key:"3s1dr2"}],["path",{d:"M14 17H5",key:"gfn3mx"}],["circle",{cx:"17",cy:"17",r:"3",key:"18b49y"}],["circle",{cx:"7",cy:"7",r:"3",key:"dfmy0x"}]]),T=typeof navigator<"u"&&/iPhone|iPad|iPod/.test(navigator.userAgent);var h;const V=typeof window<"u"&&(navigator.standalone===!0||((h=window.matchMedia)==null?void 0:h.call(window,"(display-mode: standalone)").matches));function D({canInstall:d,install:p,goNews:m,goSafety:y}){const k=()=>{const n="https://myrishta.pk/app/",l="My Rishta App: free rishta service for Pakistani families";navigator.share?navigator.share({title:"My Rishta App",text:l,url:n}).catch(()=>{}):window.open("https://wa.me/?text="+encodeURIComponent(l+`
`+n),"_blank","noopener")};return e("div",{className:"space-y-3 text-xs",children:[e("div",{className:"text-center py-2",children:[e("img",{src:"mark.svg",alt:"My Rishta Pakistan",className:"mx-auto w-24 h-24 rounded-3xl shadow-lg border border-gold/40 mb-3"}),e("span",{className:"bg-gold/15 text-gold-light text-[11px] font-bold px-3 py-1 rounded-full border border-gold/30",children:"Free for Every Family"}),e("h3",{className:"text-base font-black text-white mt-2",dir:"rtl",children:f}),e("p",{className:"text-xs text-slate-400",children:u})]}),e(b,{className:"space-y-1.5 border-green-700/40 text-xs text-slate-300",children:[e("p",{className:"font-bold text-gold text-xs",children:"No fees, no packages"}),e("p",{children:[o.name," is an independent non-profit based in Lahore. Using the service is free for every family."]}),e("p",{className:"text-slate-500",children:"It is not connected with any government body or political party. Never pay anyone for a “guaranteed” rishta."})]}),e("p",{className:"text-xs font-bold text-gold pt-1",children:"My account"}),e("div",{className:"space-y-2",children:[e(a,{icon:e(w,{className:"w-4 h-4"}),title:"Sign in",sub:"Messages, shortlist and search every member",onClick:()=>t(s.login)}),e(a,{icon:e(g,{className:"w-4 h-4"}),title:"Register free",onClick:()=>t(s.register)}),e(a,{icon:e(N,{className:"w-4 h-4"}),title:"My account",sub:"Edit your profile, photos and settings",onClick:()=>t(s.account)}),e(a,{icon:e(I,{className:"w-4 h-4"}),title:"My messages",sub:"Open your inbox on myrishta.pk",onClick:()=>t(s.account)}),e(a,{icon:e(x,{className:"w-4 h-4"}),title:"Add my profile",sub:"Free for every family",onClick:()=>t(s.addProfile)}),e(a,{icon:e(v,{className:"w-4 h-4"}),title:"Add study, caste & job",onClick:()=>t(s.details)}),e(a,{icon:e(C,{className:"w-4 h-4"}),title:"Verify my account",sub:"Two-step login and ID check",onClick:y}),e(a,{icon:e(M,{className:"w-4 h-4"}),title:"What the badges mean",onClick:()=>t(s.badges)})]}),e("p",{className:"text-xs font-bold text-gold pt-1",children:"Help & share"}),e("div",{className:"space-y-2",children:[e(a,{icon:e(R,{className:"w-4 h-4"}),title:"Share this app",sub:"Send it to family and friends",onClick:k}),T&&!V&&e(a,{icon:e(r,{className:"w-4 h-4"}),title:"Install on your iPhone",sub:"Open in Safari, tap Share, then “Add to Home Screen”",onClick:()=>{}}),d&&e(a,{icon:e(r,{className:"w-4 h-4"}),title:"Install this app",sub:"Add My Rishta App to your home screen",onClick:p}),e(a,{icon:e(G,{className:"w-4 h-4"}),title:o.phone,sub:"Call the office",onClick:()=>location.href=`tel:${o.tel}`}),e(a,{icon:e(H,{className:"w-4 h-4"}),title:o.email,sub:"Email support",onClick:()=>location.href=`mailto:${o.email}`}),e(a,{icon:e(P,{className:"w-4 h-4"}),title:o.line,sub:o.name,onClick:()=>t(s.contact)}),e(a,{icon:e(F,{className:"w-4 h-4"}),title:"News & Updates",sub:"Public-service explainers",onClick:m}),e(a,{icon:e(c,{className:"w-4 h-4"}),title:"Open the full website",sub:"Use myrishta.pk as a normal website on this phone",onClick:()=>{try{localStorage.setItem("mr_web","1")}catch{}S("https://myrishta.pk/?web=1")}}),e(a,{icon:e(O,{className:"w-4 h-4"}),title:"How it works",onClick:()=>t(s.how)}),e(a,{icon:e(U,{className:"w-4 h-4"}),title:"FAQ",onClick:()=>t(s.faq)}),e(a,{icon:e(c,{className:"w-4 h-4"}),title:"About Us",onClick:()=>t(s.about)}),e(a,{icon:e(E,{className:"w-4 h-4"}),title:"Facebook",onClick:()=>t(o.facebook)}),e(a,{icon:e(A,{className:"w-4 h-4"}),title:"Privacy Policy",onClick:()=>t(s.privacy)}),e(a,{icon:e(L,{className:"w-4 h-4"}),title:"Terms and Conditions",onClick:()=>t(s.terms)})]})]})}export{D as default};
