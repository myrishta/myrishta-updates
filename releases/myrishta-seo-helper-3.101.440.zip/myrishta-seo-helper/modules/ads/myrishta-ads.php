<?php
/**
 * Plugin Name:       MyRishta Ads
 * Description:       Promotes the My Rishta app and places ad-network ads on guide pages, with safety rules. Everything is off until you switch it on. ads.txt is managed in MyRishta SEO Helper.
 * Version:           1.1.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            MyRishta
 * License:           GPLv2 or later
 * Text Domain:       myrishta-ads
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRADS {

	const OPT = 'mrads';

	public static function defaults() {
		return array(
			'enabled'      => 0,   // ad-network ads, master switch.
			'members_off'  => 1,   // hide ads from logged-in members.
			'consent'      => 1,   // honour the visitor's cookie choice when a consent plugin is present.
			'minwords'     => 400, // only on pages with enough real text.
			'exclude'      => "login\nmy-account\nprofile-details\nmemberships\ncheckout\ncart\nregister\nlost-password\nreport-profile-misuse\ncontact\nprivacy-policy\nterms\nsitemap",
			'slots'        => array(
				'top' => array( 'on' => 0, 'code' => '', 'dev' => 'all', 'h' => 280 ),
				'mid' => array( 'on' => 0, 'code' => '', 'dev' => 'all', 'h' => 280, 'p' => 4 ),
				'end' => array( 'on' => 0, 'code' => '', 'dev' => 'all', 'h' => 280 ),
			),
			'card_on'      => 1,   // first-party app card in guides.
			'card_p'       => 3,
			'bar_on'       => 1,   // first-party install bar on phones.
			'from'         => '',  // ads run from this date (Y-m-d), empty = no start limit.
			'to'           => '',  // ads stop after this date, empty = no end.
			'types'        => 'both', // post, page or both.
			'cap'          => 3,   // most ads on one page.
			'card_title'   => 'Get the free My Rishta app',
			'card_text'    => 'Read guides and browse rishta on your phone. Free, private, no sign-up needed to install.',
			'card_btn'     => 'Open the app',
			'bar_text'     => 'Get the free My Rishta app',
		);
	}

	public static function get() {
		$s = get_option( self::OPT, array() );
		$d = self::defaults();
		$s = is_array( $s ) ? array_replace_recursive( $d, $s ) : $d;
		return $s;
	}

	public static function init() {
		add_filter( 'the_content', array( __CLASS__, 'content' ), 30 );
		add_action( 'wp_footer', array( __CLASS__, 'footer' ), 50 );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_post_mrads_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_mrads_off', array( __CLASS__, 'kill' ) );
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'admin_post_mrads_export', array( __CLASS__, 'export' ) );
		add_action( 'admin_post_mrads_import', array( __CLASS__, 'import' ) );
		add_action( 'admin_post_mrads_reset_stats', array( __CLASS__, 'reset_stats' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'metabox' ) );
		add_action( 'save_post', array( __CLASS__, 'save_meta' ), 10, 2 );
	}

	public static function metabox() {
		foreach ( array( 'post', 'page' ) as $t ) {
			add_meta_box( 'mrads_box', 'Ads on this page', array( __CLASS__, 'box' ), $t, 'side', 'low' );
		}
	}

	public static function box( $post ) {
		wp_nonce_field( 'mrads_meta', 'mrads_meta_n' );
		echo '<label><input type="checkbox" name="mrads_off" value="1"' . checked( (bool) get_post_meta( $post->ID, '_mrads_off', true ), true, false ) . '> Hide ads and the app card on this page</label>';
	}

	public static function save_meta( $id, $post ) {
		if ( ! isset( $_POST['mrads_meta_n'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['mrads_meta_n'] ) ), 'mrads_meta' ) || ! current_user_can( 'edit_post', $id ) ) {
			return;
		}
		if ( ! empty( $_POST['mrads_off'] ) ) {
			update_post_meta( $id, '_mrads_off', 1 );
		} else {
			delete_post_meta( $id, '_mrads_off' );
		}
	}

	/* ---------- where may anything show ---------- */

	/** Ad-network ads are within their date window. */
	private static function in_window( $s ) {
		$today = current_time( 'Y-m-d' );
		return ( '' === $s['from'] || $today >= $s['from'] ) && ( '' === $s['to'] || $today <= $s['to'] );
	}

	private static function page_ok( $s ) {
		if ( is_admin() || is_feed() || is_preview() || is_customize_preview() || isset( $_GET['elementor-preview'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return false;
		}
		$types = 'post' === $s['types'] ? array( 'post' ) : ( 'page' === $s['types'] ? array( 'page' ) : array( 'post', 'page' ) );
		if ( ! is_singular( $types ) || is_front_page() ) {
			return false;
		}
		$p = get_queried_object();
		if ( ! $p || get_post_meta( $p->ID, '_mrsh_noindex', true ) || get_post_meta( $p->ID, '_mrads_off', true ) ) {
			return false;
		}
		$ex = array_filter( array_map( 'trim', preg_split( '/\R/', (string) $s['exclude'] ) ) );
		return ! in_array( $p->post_name, $ex, true );
	}

	private static function words( $post ) {
		return str_word_count( wp_strip_all_tags( strip_shortcodes( (string) $post->post_content ) ) );
	}

	/* ---------- inserting into the page text ---------- */

	public static function content( $html ) {
		if ( ! in_the_loop() || ! is_main_query() ) {
			return $html;
		}
		$s = self::get();
		if ( ! self::page_ok( $s ) ) {
			return $html;
		}
		$post = get_post();
		if ( ! $post ) {
			return $html;
		}
		$ads = ! empty( $s['enabled'] ) && self::in_window( $s ) && ! ( ! empty( $s['members_off'] ) && is_user_logged_in() );
		self::$cap = max( 1, (int) $s['cap'] );
		self::$preview = isset( $_GET['mrads_preview'] ) && current_user_can( 'manage_options' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( self::$preview ) {
			$ads = true;
		} elseif ( self::words( $post ) < (int) $s['minwords'] ) {
			return $html;
		}
		$out = $html;
		// the app card after paragraph N, then the middle ad.
		if ( ! empty( $s['card_on'] ) ) {
			$out = self::after_para( $out, max( 1, (int) $s['card_p'] ), self::card() );
		}
		$out = self::after_para( $out, max( 2, (int) $s['slots']['mid']['p'] ), self::slot( 'mid', $s, $ads ) );
		$out = self::slot( 'top', $s, $ads ) . $out . self::slot( 'end', $s, $ads );
		return $out;
	}

	private static function after_para( $html, $n, $block ) {
		if ( '' === $block ) {
			return $html;
		}
		$parts = preg_split( '#(</p>)#i', $html, -1, PREG_SPLIT_DELIM_CAPTURE );
		if ( ! is_array( $parts ) || count( $parts ) < $n * 2 + 2 ) { // keep it off short texts.
			return $html;
		}
		$count = 0;
		$out   = '';
		foreach ( $parts as $i => $part ) {
			$out .= $part;
			if ( 0 === stripos( $part, '</p>' ) ) {
				$count++;
				if ( $count === $n ) {
					$out .= $block;
				}
			}
		}
		return $out;
	}

	public static $preview = false;
	public static $cap     = 3;
	public static $shown   = 0;

	private static function slot( $key, $s, $ads ) {
		if ( self::$preview ) {
			self::$used = true;
			$n = array( 'top' => 'top of the text', 'mid' => 'inside the text', 'end' => 'end of the text' );
			return '<div class="mrads-slot" style="min-height:' . (int) $s['slots'][ $key ]['h'] . 'px;border:2px dashed #0f7a55;background:#f3faf6;display:flex;align-items:center;justify-content:center;color:#0f7a55;font:600 14px sans-serif">Ad slot: ' . esc_html( $n[ $key ] ) . ' (preview, only you see this)</div>';
		}
		if ( ! $ads || empty( $s['slots'][ $key ]['on'] ) || '' === trim( (string) $s['slots'][ $key ]['code'] ) ) {
			return '';
		}
		if ( self::$shown >= self::$cap ) {
			return '';
		}
		self::$shown++;
		$c    = $s['slots'][ $key ];
		$code = str_ireplace( '</template', '&lt;/template', (string) $c['code'] );
		$dev  = in_array( $c['dev'], array( 'mobile', 'desktop' ), true ) ? ' mrads-only-' . $c['dev'] : '';
		self::$used = true;
		return '<div class="mrads-slot' . $dev . '" style="min-height:' . (int) $c['h'] . 'px" data-mrads="' . esc_attr( $key ) . '"><span class="mrads-lbl">Advertisement</span><template class="mrads-t">' . $code . '</template></div>';
	}

	public static $used = false;
	public static $card = false;

	private static function card() {
		self::$card = true;
		$s = self::get();
		$u = esc_url( home_url( '/app/' ) );
		return '<aside class="mrads-card" aria-label="My Rishta app"><strong>' . esc_html( $s['card_title'] ) . '</strong><span>' . esc_html( $s['card_text'] ) . '</span><a class="mrads-btn" data-mrads-t="card" href="' . $u . '">' . esc_html( $s['card_btn'] ) . '</a></aside>';
	}

	/* ---------- scripts and styles (only when needed) ---------- */

	public static function footer() {
		$s = self::get();
		if ( is_admin() || is_feed() ) {
			return;
		}
		$bar = ! empty( $s['bar_on'] ) && self::page_ok_bar( $s );
		if ( ! self::$used && ! self::$card && ! $bar ) {
			return;
		}
		$css = '.mrads-slot{display:block;margin:24px 0;text-align:center;overflow:hidden;clear:both}.mrads-lbl{display:block;font:11px/1.4 sans-serif;color:#6b7280;margin-bottom:4px}.mrads-card{display:flex;flex-wrap:wrap;align-items:center;gap:8px 14px;margin:22px 0;padding:14px 16px;border:1px solid #d6e4dc;border-radius:12px;background:#f3faf6;color:#134e3a}.mrads-card strong{flex:1 0 100%;font-size:16px}.mrads-card span{flex:1 1 220px;font-size:14px;line-height:1.5}.mrads-btn{display:inline-block;padding:9px 16px;border-radius:8px;background:#0f7a55;color:#fff!important;text-decoration:none;font-weight:600;font-size:14px}@media(max-width:767px){.mrads-only-desktop{display:none!important}}@media(min-width:768px){.mrads-only-mobile{display:none!important}}#mrads-bar{position:fixed;left:0;right:0;bottom:0;z-index:9990;display:none;align-items:center;gap:10px;padding:10px 14px;background:#134e3a;color:#fff;font:14px/1.3 sans-serif;box-shadow:0 -2px 10px rgba(0,0,0,.2)}#mrads-bar span{flex:1}#mrads-bar a,#mrads-bar button{border:0;border-radius:8px;padding:8px 14px;font:600 14px sans-serif;cursor:pointer}#mrads-bar a{background:#fff;color:#134e3a;text-decoration:none}#mrads-bar button{background:transparent;color:#fff;font-size:20px;padding:4px 8px}@media(min-width:768px){#mrads-bar{display:none!important}}';
		echo '<style id="mrads-css">' . $css . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		$cons = ! empty( $s['consent'] ) ? 'true' : 'false';
		$js   = '(function(){var C=' . $cons . ';function ok(){if(!C||typeof window.wp_has_consent!=="function")return true;try{return !!window.wp_has_consent("marketing");}catch(e){return true;}}function fill(el){if(el.getAttribute("data-done"))return;var t=el.querySelector("template.mrads-t");if(!t)return;if(!ok()){el.style.display="none";document.addEventListener("wp_listen_for_consent_change",function(){if(ok()){el.style.display="";fill(el);}},{once:true});return;}el.setAttribute("data-done","1");var d=t.content.cloneNode(true),sc=d.querySelectorAll("script");for(var i=0;i<sc.length;i++){var n=document.createElement("script");for(var a=0;a<sc[i].attributes.length;a++)n.setAttribute(sc[i].attributes[a].name,sc[i].attributes[a].value);n.text=sc[i].text;sc[i].parentNode.replaceChild(n,sc[i]);}el.appendChild(d);}var l=document.querySelectorAll(".mrads-slot[data-mrads]");if(!l.length)return;if(!("IntersectionObserver" in window)){for(var i=0;i<l.length;i++)fill(l[i]);return;}var o=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){o.unobserve(e.target);fill(e.target);}});},{rootMargin:"300px 0px"});for(var j=0;j<l.length;j++)o.observe(l[j]);})();';
		echo '<script id="mrads-js">' . $js . '</script>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<script id="mrads-t">document.addEventListener("click",function(e){var a=e.target.closest&&e.target.closest("[data-mrads-t]");if(!a||!navigator.sendBeacon)return;try{navigator.sendBeacon(' . wp_json_encode( esc_url_raw( rest_url( 'mrads/v1/t' ) ) ) . ',new URLSearchParams({k:a.getAttribute("data-mrads-t")}));}catch(x){}},true);</script>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		if ( $bar ) {
			$u = esc_url( home_url( '/app/' ) );
			echo '<div id="mrads-bar" role="region" aria-label="Install the app"><span>' . esc_html( $s['bar_text'] ) . '</span><a id="mrads-go" data-mrads-t="bar" href="' . $u . '">Install</a><button type="button" id="mrads-x" aria-label="Close">&times;</button></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			echo '<script id="mrads-bar-js">(function(){var b=document.getElementById("mrads-bar");if(!b)return;try{if(window.matchMedia("(display-mode: standalone)").matches||navigator.standalone)return;var t=localStorage.getItem("mrads_x");if(t&&Date.now()-parseInt(t,10)<6048e5)return;}catch(e){}var ev=null;window.addEventListener("beforeinstallprompt",function(e){e.preventDefault();ev=e;});document.getElementById("mrads-go").addEventListener("click",function(e){if(ev){e.preventDefault();ev.prompt();ev=null;}});document.getElementById("mrads-x").addEventListener("click",function(){b.style.display="none";try{localStorage.setItem("mrads_x",String(Date.now()));}catch(e){}});var shown=false;function show(){if(shown)return;if((window.pageYOffset||0)>window.innerHeight*0.6){shown=true;b.style.display="flex";}}window.addEventListener("scroll",show,{passive:true});})();</script>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}

	private static function page_ok_bar( $s ) {
		return self::page_ok( $s );
	}


	/* ---------- tap counter (no personal data: only a daily count per button) ---------- */

	public static function routes() {
		register_rest_route( 'mrads/v1', '/t', array( 'methods' => 'POST', 'permission_callback' => '__return_true', 'callback' => array( __CLASS__, 'tap' ) ) );
	}

	public static function tap( $req ) {
		$k = sanitize_key( (string) $req->get_param( 'k' ) );
		if ( in_array( $k, array( 'card', 'bar' ), true ) ) {
			$st = get_option( 'mrads_stats', array() );
			$st = is_array( $st ) ? $st : array();
			$d  = current_time( 'Y-m-d' );
			if ( empty( $st[ $d ][ $k ] ) || $st[ $d ][ $k ] < 5000 ) {
				$st[ $d ][ $k ] = ( isset( $st[ $d ][ $k ] ) ? (int) $st[ $d ][ $k ] : 0 ) + 1;
			}
			krsort( $st );
			update_option( 'mrads_stats', array_slice( $st, 0, 45, true ), false );
		}
		return new WP_REST_Response( array( 'ok' => true ), 200 );
	}

	private static function tallies() {
		$st  = get_option( 'mrads_stats', array() );
		$out = array( 'card7' => 0, 'bar7' => 0, 'card30' => 0, 'bar30' => 0 );
		foreach ( (array) $st as $d => $v ) {
			$age = ( strtotime( current_time( 'Y-m-d' ) ) - strtotime( $d ) ) / DAY_IN_SECONDS;
			foreach ( array( 'card', 'bar' ) as $k ) {
				if ( $age < 30 ) {
					$out[ $k . '30' ] += (int) ( $v[ $k ] ?? 0 );
				}
				if ( $age < 7 ) {
					$out[ $k . '7' ] += (int) ( $v[ $k ] ?? 0 );
				}
			}
		}
		return $out;
	}

	public static function reset_stats() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrads_reset_stats' );
		delete_option( 'mrads_stats' );
		self::back( 'App tap counts were reset.' );
	}

	/* ---------- export and import settings ---------- */

	public static function export() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrads_export' );
		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="myrishta-ads-settings.json"' );
		echo wp_json_encode( self::get(), JSON_PRETTY_PRINT ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	public static function import() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrads_import' );
		$f = isset( $_FILES['mrads_file']['tmp_name'] ) ? (string) $_FILES['mrads_file']['tmp_name'] : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$j = '' !== $f && is_uploaded_file( $f ) ? json_decode( (string) file_get_contents( $f ), true ) : null; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		if ( ! is_array( $j ) ) {
			self::back( 'That file is not a settings file from this plugin.' );
		}
		$cur = self::get();
		$new = array_replace_recursive( $cur, array_intersect_key( $j, $cur ) );
		if ( ! current_user_can( 'unfiltered_html' ) ) {
			foreach ( array( 'top', 'mid', 'end' ) as $k ) {
				$new['slots'][ $k ]['code'] = $cur['slots'][ $k ]['code'];
			}
		}
		update_option( self::OPT, $new, false );
		self::back( 'Settings imported.' );
	}

	/* ---------- health check ---------- */

	private static function health( $s ) {
		$w  = array();
		$any = false;
		foreach ( $s['slots'] as $k => $c ) {
			$has = '' !== trim( (string) $c['code'] );
			$any = $any || ( ! empty( $c['on'] ) && $has );
			if ( ! empty( $c['on'] ) && ! $has ) {
				$w[] = 'The "' . $k . '" slot is switched on but has no ad code.';
			}
			if ( $has && empty( $c['on'] ) ) {
				$w[] = 'The "' . $k . '" slot has ad code but is switched off.';
			}
			if ( $has && false !== stripos( (string) $c['code'], 'adsbygoogle' ) && class_exists( 'MRSH_Tools' ) && false === strpos( MRSH_Tools::ads_txt_body(), 'google.com' ) ) {
				$w[] = 'Google AdSense code is in the "' . $k . '" slot but ads.txt has no Google line. Add your pub- number in MyRishta SEO.';
			}
		}
		if ( ! empty( $s['enabled'] ) && ! $any ) {
			$w[] = 'Ads are switched on, but no slot has code yet, so nothing shows.';
		}
		if ( ! empty( $s['enabled'] ) && ! self::in_window( $s ) ) {
			$w[] = 'Ads are outside their date window (' . ( $s['from'] ? $s['from'] : 'any' ) . ' to ' . ( $s['to'] ? $s['to'] : 'any' ) . '), so they are paused.';
		}
		if ( ! empty( $s['consent'] ) && ! function_exists( 'wp_has_consent' ) ) {
			$w[] = 'No cookie-consent plugin is active, so ads will show to everyone. Check this against your privacy policy and your network\'s rules.';
		}
		if ( (int) $s['minwords'] < 300 ) {
			$w[] = 'Ads on short pages can hurt AdSense approval. 400 words or more is safer.';
		}
		return $w;
	}

	/* ---------- admin ---------- */

	public static function menu() {
		add_menu_page( 'MyRishta Ads', 'MyRishta Ads', 'manage_options', 'myrishta-ads', array( __CLASS__, 'page' ), ( class_exists( 'MRSH_Tabs' ) ? MRSH_Tabs::menu_icon( 'megaphone' ) : 'dashicons-megaphone' ), 81 );
	}

	private static function back( $m ) {
		wp_safe_redirect( admin_url( 'admin.php?page=myrishta-ads&msg=' . rawurlencode( $m ) ) );
		exit;
	}

	public static function kill() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrads_off' );
		$s            = self::get();
		$s['enabled'] = 0;
		update_option( self::OPT, $s, false );
		self::back( 'All ad-network ads are switched off. The app card and bar are unchanged.' );
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrads_save' );
		$s   = self::get();
		$raw = isset( $_POST['m'] ) && is_array( $_POST['m'] ) ? wp_unslash( $_POST['m'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$s['enabled']     = empty( $raw['enabled'] ) ? 0 : 1;
		$s['members_off'] = empty( $raw['members_off'] ) ? 0 : 1;
		$s['consent']     = empty( $raw['consent'] ) ? 0 : 1;
		$s['bar_on']      = empty( $raw['bar_on'] ) ? 0 : 1;
		$s['card_on']     = empty( $raw['card_on'] ) ? 0 : 1;
		$s['card_p']      = max( 1, min( 12, (int) ( $raw['card_p'] ?? 3 ) ) );
		$s['minwords']    = max( 0, min( 3000, (int) ( $raw['minwords'] ?? 400 ) ) );
		$s['exclude']     = sanitize_textarea_field( (string) ( $raw['exclude'] ?? '' ) );
		$ok_date          = static function ( $v ) {
			$v = trim( (string) $v );
			return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) ? $v : '';
		};
		$s['from']       = $ok_date( $raw['from'] ?? '' );
		$s['to']         = $ok_date( $raw['to'] ?? '' );
		$s['types']      = in_array( $raw['types'] ?? 'both', array( 'post', 'page', 'both' ), true ) ? $raw['types'] : 'both';
		$s['cap']        = max( 1, min( 3, (int) ( $raw['cap'] ?? 3 ) ) );
		$s['card_title'] = sanitize_text_field( (string) ( $raw['card_title'] ?? '' ) ) ?: 'Get the free My Rishta app';
		$s['card_text']  = sanitize_text_field( (string) ( $raw['card_text'] ?? '' ) ) ?: 'Read guides and browse rishta on your phone.';
		$s['card_btn']   = sanitize_text_field( (string) ( $raw['card_btn'] ?? '' ) ) ?: 'Open the app';
		$s['bar_text']   = sanitize_text_field( (string) ( $raw['bar_text'] ?? '' ) ) ?: 'Get the free My Rishta app';
		$can_code         = current_user_can( 'unfiltered_html' );
		foreach ( array( 'top', 'mid', 'end' ) as $k ) {
			$r = isset( $raw['slots'][ $k ] ) && is_array( $raw['slots'][ $k ] ) ? $raw['slots'][ $k ] : array();
			$s['slots'][ $k ]['on']  = empty( $r['on'] ) ? 0 : 1;
			$s['slots'][ $k ]['dev'] = in_array( $r['dev'] ?? 'all', array( 'all', 'mobile', 'desktop' ), true ) ? $r['dev'] : 'all';
			$s['slots'][ $k ]['h']   = max( 50, min( 700, (int) ( $r['h'] ?? 280 ) ) );
			if ( 'mid' === $k ) {
				$s['slots'][ $k ]['p'] = max( 2, min( 20, (int) ( $r['p'] ?? 4 ) ) );
			}
			if ( $can_code ) {
				$s['slots'][ $k ]['code'] = (string) ( $r['code'] ?? '' );
			}
		}
		update_option( self::OPT, $s, false );
		self::back( $can_code ? 'Saved.' : 'Saved, but ad code was not changed: your account is not allowed to save scripts.' );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s     = self::get();
		$ap    = esc_url( admin_url( 'admin-post.php' ) );
		$filled = 0;
		foreach ( $s['slots'] as $c ) {
			if ( ! empty( $c['on'] ) && '' !== trim( (string) $c['code'] ) ) {
				$filled++;
			}
		}
		$lines = 0;
		if ( class_exists( 'MRSH_Tools' ) ) {
			$lines = count( array_filter( explode( "\n", MRSH_Tools::ads_txt_body() ) ) );
		}
		$pill = static function ( $on, $label ) {
			return '<span class="mra-pill ' . ( $on ? 'on' : 'off' ) . '">' . esc_html( $label ) . ': <b>' . ( $on ? 'ON' : 'OFF' ) . '</b></span>';
		};
		$sw = static function ( $name, $on ) {
			return '<label class="mra-sw"><input type="checkbox" name="' . esc_attr( $name ) . '" value="1"' . checked( $on, 1, false ) . '><i></i></label>';
		};
		echo '<style>.mra{max-width:1040px}.mra *{box-sizing:border-box}.mra-hero{display:flex;flex-wrap:wrap;align-items:center;gap:14px;background:linear-gradient(135deg,#0f7a55,#0b5a3f);color:#fff;border-radius:14px;padding:20px 24px;margin:14px 0 16px}.mra-hero h1{color:#fff;margin:0;font-size:24px;padding:0}.mra-hero p{margin:4px 0 0;opacity:.88}.mra-hero .l{flex:1 1 320px}.mra-hero .st{display:flex;gap:8px;flex-wrap:wrap}.mra-pills{display:flex;flex-wrap:wrap;gap:8px;margin:0 0 16px}.mra-pill{padding:6px 12px;border-radius:999px;background:#fff;border:1px solid #dcdcde;font-size:13px}.mra-pill.on{border-color:#0f7a55;background:#eaf6f0;color:#0b5a3f}.mra-pill.off{color:#646970}.mra-tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin:0 0 12px}.mra-tile{background:#f6f8f7;border:1px solid #e3e8e6;border-radius:10px;padding:12px 14px}.mra-tile b{display:block;font-size:26px;line-height:1.1;color:#0b5a3f}.mra-tile span{color:#646970;font-size:12px}.mra-spark{display:flex;align-items:flex-end;gap:3px;height:46px;margin:6px 0 12px}.mra-spark i{flex:1;background:#0f7a55;border-radius:3px 3px 0 0;min-height:2px;opacity:.85}.mra-card{background:#fff;border:1px solid #dcdcde;border-radius:12px;padding:18px 20px;margin:0 0 14px;box-shadow:0 1px 2px rgba(0,0,0,.03)}.mra-card h2{margin:0 0 4px;font-size:16px;padding:0}.mra-card h2 em{font-style:normal;display:inline-block;width:24px;height:24px;line-height:24px;text-align:center;border-radius:50%;background:#0f7a55;color:#fff;font-size:12px;margin-right:8px}.mra-card .d{color:#646970;margin:0 0 12px}.mra-row{display:flex;align-items:center;gap:12px;padding:10px 0;border-top:1px solid #f0f0f1}.mra-row:first-of-type{border-top:0}.mra-row .t{flex:1}.mra-row .t small{display:block;color:#646970}.mra-sw{position:relative;display:inline-block;width:42px;height:24px;flex:none}.mra-sw input{opacity:0;width:0;height:0}.mra-sw i{position:absolute;inset:0;background:#c3c4c7;border-radius:24px;transition:.2s;cursor:pointer}.mra-sw i:before{content:"";position:absolute;width:18px;height:18px;left:3px;top:3px;background:#fff;border-radius:50%;transition:.2s}.mra-sw input:checked+i{background:#0f7a55}.mra-sw input:checked+i:before{transform:translateX(18px)}.mra-slot{border:1px solid #dcdcde;border-left:4px solid #0f7a55;border-radius:10px;padding:12px 14px;margin:10px 0;background:#fafcfb}.mra-slot .h{display:flex;flex-wrap:wrap;align-items:center;gap:10px;margin-bottom:8px}.mra-slot .h b{flex:1 0 180px}.mra-bar{display:flex;flex-wrap:wrap;gap:8px;margin:10px 0}.mra textarea{width:100%;font-family:monospace;border-radius:8px}.mra-help li{margin:4px 0}.mra input[type=number]{width:72px}.mra-save{position:sticky;bottom:0;z-index:5;display:flex;flex-wrap:wrap;align-items:center;gap:10px;background:rgba(255,255,255,.96);border:1px solid #dcdcde;border-radius:12px;padding:12px 16px;margin:0 0 14px;box-shadow:0 -4px 14px rgba(0,0,0,.06)}.mra-save span{flex:1;color:#646970}</style>';
		echo '<div class="wrap mra"><div class="mra-hero"><div class="l"><h1>MyRishta Ads</h1><p>Promote your app for free and place ad-network ads, with safety rules built in.</p></div><div class="st"><span class="mra-pill ' . ( $s['enabled'] ? 'on' : 'off' ) . '">Ads: <b>' . ( $s['enabled'] ? 'ON' : 'OFF' ) . '</b></span></div></div>';
		if ( isset( $_GET['msg'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['msg'] ) ) ) . '</p></div>';
		}
		echo '<div class="mra-pills">' . $pill( $s['card_on'], 'App card' ) . $pill( $s['bar_on'], 'Install bar' ) . $pill( $s['enabled'], 'Ads' ) . '<span class="mra-pill ' . ( $filled ? 'on' : 'off' ) . '">Ad slots filled: <b>' . (int) $filled . ' of 3</b></span><span class="mra-pill ' . ( $lines ? 'on' : 'off' ) . '">ads.txt lines: <b>' . (int) $lines . '</b></span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		$hw = self::health( $s );
		if ( $hw ) {
			echo '<div class="notice notice-warning inline"><p><b>Check these:</b></p><ul style="list-style:disc;margin-left:20px">';
			foreach ( $hw as $w ) {
				echo '<li>' . esc_html( $w ) . '</li>';
			}
			echo '</ul></div>';
		}
		$t = self::tallies();
		$days = array();
		$stt  = (array) get_option( 'mrads_stats', array() );
		$mx   = 1;
		for ( $i = 13; $i >= 0; $i-- ) {
			$d = gmdate( 'Y-m-d', strtotime( current_time( 'Y-m-d' ) ) - $i * DAY_IN_SECONDS );
			$n = (int) ( $stt[ $d ]['card'] ?? 0 ) + (int) ( $stt[ $d ]['bar'] ?? 0 );
			$days[ $d ] = $n;
			$mx = max( $mx, $n );
		}
		$spark = '';
		foreach ( $days as $d => $n ) {
			$spark .= '<i title="' . esc_attr( $d . ': ' . $n ) . '" style="height:' . max( 4, (int) round( $n / $mx * 100 ) ) . '%"></i>';
		}
		echo '<div class="mra-card"><h2>App taps</h2><p class="d">How many people tapped your app card or install bar. Only counts, no personal data.</p><div class="mra-tiles"><div class="mra-tile"><b>' . (int) $t['card7'] . '</b><span>Card taps, 7 days</span></div><div class="mra-tile"><b>' . (int) $t['bar7'] . '</b><span>Install bar taps, 7 days</span></div><div class="mra-tile"><b>' . (int) $t['card30'] . '</b><span>Card taps, 30 days</span></div><div class="mra-tile"><b>' . (int) $t['bar30'] . '</b><span>Install bar taps, 30 days</span></div></div><div class="mra-spark" title="Taps per day, last 14 days">' . $spark . '</div><form method="post" action="' . $ap . '" style="display:inline"><input type="hidden" name="action" value="mrads_reset_stats">' . wp_nonce_field( 'mrads_reset_stats', '_wpnonce', true, false ) . '<button class="button">Reset counts</button></form></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<div class="mra-card"><h2>Quick start</h2><p class="d">Press a button to fill the form below, then press Save.</p><div class="mra-bar"><button type="button" class="button" data-preset="app">App promotion only (safe start)</button><button type="button" class="button" data-preset="one">App promotion + one ad inside the text</button><button type="button" class="button" data-preset="three">App promotion + three ads</button><a class="button" target="_blank" rel="noopener" href="' . esc_url( add_query_arg( 'mrads_preview', '1', home_url( '/marriage-proposals-pakistan-guide/' ) ) ) . '">Preview on a guide page</a></div></div>';
		echo '<form method="post" action="' . $ap . '" id="mra-form"><input type="hidden" name="action" value="mrads_save">';
		wp_nonce_field( 'mrads_save' );
		echo '<div class="mra-card"><h2><em>1</em>Promote your app</h2><p class="d">Your own promotion. It is free, light and never needs an ad network.</p>';
		echo '<div class="mra-row"><div class="t"><b>"Open the app" card inside guides</b><small>After paragraph <input type="number" name="m[card_p]" min="1" max="12" value="' . (int) $s['card_p'] . '"></small></div>' . $sw( 'm[card_on]', $s['card_on'] ) . '</div>';
		echo '<div class="mra-row"><div class="t"><b>"Install the app" bar on phones</b><small>Appears after the visitor scrolls. Hidden inside the installed app and for a week once closed.</small></div>' . $sw( 'm[bar_on]', $s['bar_on'] ) . '</div>';
		echo '<div class="mra-row"><div class="t"><b>Card words</b><small>Title, line and button. Plain text only.</small></div></div><p><input type="text" class="regular-text" name="m[card_title]" value="' . esc_attr( $s['card_title'] ) . '"> <input type="text" class="regular-text" name="m[card_btn]" value="' . esc_attr( $s['card_btn'] ) . '" style="width:150px"><br><input type="text" name="m[card_text]" style="width:100%;margin-top:6px" value="' . esc_attr( $s['card_text'] ) . '"><br><input type="text" class="regular-text" name="m[bar_text]" style="margin-top:6px" value="' . esc_attr( $s['bar_text'] ) . '"> <small>words on the phone bar</small></p></div>';
		echo '<div class="mra-card"><h2><em>2</em>Ad-network ads</h2><p class="d">Off until you switch the master switch on. Paste each network\'s code only after it approves you.</p>';
		echo '<div class="mra-row"><div class="t"><b>Show ads (master switch)</b><small>Turns all three slots on or off together.</small></div>' . $sw( 'm[enabled]', $s['enabled'] ) . '</div>';
		echo '<div class="mra-row"><div class="t"><b>Hide ads from logged-in members</b></div>' . $sw( 'm[members_off]', $s['members_off'] ) . '</div>';
		echo '<div class="mra-row"><div class="t"><b>Respect the cookie choice</b><small>Ads wait for consent when a consent plugin is active.</small></div>' . $sw( 'm[consent]', $s['consent'] ) . '</div>';
		echo '<div class="mra-row"><div class="t"><b>Only on pages with at least this many words</b><small>Thin pages get no ads (better for approval).</small></div><input type="number" name="m[minwords]" min="0" max="3000" value="' . (int) $s['minwords'] . '"></div>';
		echo '<div class="mra-row"><div class="t"><b>Run ads between these dates</b><small>Leave empty for no limit.</small></div><input type="date" name="m[from]" value="' . esc_attr( $s['from'] ) . '"> to <input type="date" name="m[to]" value="' . esc_attr( $s['to'] ) . '"></div>';
		echo '<div class="mra-row"><div class="t"><b>Show on</b></div><select name="m[types]"><option value="both"' . selected( $s['types'], 'both', false ) . '>Guides and pages</option><option value="post"' . selected( $s['types'], 'post', false ) . '>Guides (posts) only</option><option value="page"' . selected( $s['types'], 'page', false ) . '>Pages only</option></select></div>';
		echo '<div class="mra-row"><div class="t"><b>Most ads on one page</b></div><select name="m[cap]">';
		foreach ( array( 1, 2, 3 ) as $n ) {
			echo '<option value="' . $n . '"' . selected( (int) $s['cap'], $n, false ) . '>' . $n . '</option>';
		}
		echo '</select></div>';
		$names = array( 'top' => 'Top of the page text', 'mid' => 'Inside the text', 'end' => 'End of the page text' );
		foreach ( $names as $k => $label ) {
			$c = $s['slots'][ $k ];
			echo '<div class="mra-slot"><div class="h"><b>' . esc_html( $label ) . '</b>';
			if ( 'mid' === $k ) {
				echo '<span>after paragraph <input type="number" name="m[slots][mid][p]" min="2" max="20" value="' . (int) $c['p'] . '"></span>';
			}
			echo '<select name="m[slots][' . $k . '][dev]">';
			foreach ( array( 'all' => 'Phones and computers', 'mobile' => 'Phones only', 'desktop' => 'Computers only' ) as $v => $l ) {
				echo '<option value="' . esc_attr( $v ) . '"' . selected( $c['dev'], $v, false ) . '>' . esc_html( $l ) . '</option>';
			}
			echo '</select><span>height <input type="number" name="m[slots][' . $k . '][h]" min="50" max="700" value="' . (int) $c['h'] . '"> px</span>' . $sw( 'm[slots][' . $k . '][on]', $c['on'] ) . '</div>';
			echo '<textarea name="m[slots][' . $k . '][code]" rows="3" placeholder="Paste the ad code from your network here">' . esc_textarea( (string) $c['code'] ) . '</textarea></div>';
		}
		echo '</div>';
		echo '<div class="mra-card"><h2><em>3</em>Pages without ads</h2><p class="d">One page address ending (slug) per line. You can also tick "Hide ads" in any page\'s editor sidebar.</p><textarea name="m[exclude]" rows="6" style="max-width:420px">' . esc_textarea( (string) $s['exclude'] ) . '</textarea></div>';
		echo '<div class="mra-save"><span>Changes apply to the whole site after you press Save.</span><button class="button button-primary button-large">Save</button></div></form>';
		echo '<form method="post" action="' . $ap . '"><input type="hidden" name="action" value="mrads_off">';
		wp_nonce_field( 'mrads_off' );
		echo '<p><button class="button" onclick="return confirm(\'Switch off all ad-network ads now?\')">Turn all ads off now</button></p></form>';
		echo '<div class="mra-card"><h2>Backup settings</h2><p class="d">Save your settings to a file, or load them on another site.</p><form method="post" action="' . $ap . '" style="display:inline-block;margin-right:12px"><input type="hidden" name="action" value="mrads_export">' . wp_nonce_field( 'mrads_export', '_wpnonce', true, false ) . '<button class="button">Download settings</button></form><form method="post" action="' . $ap . '" enctype="multipart/form-data" style="display:inline-block"><input type="hidden" name="action" value="mrads_import">' . wp_nonce_field( 'mrads_import', '_wpnonce', true, false ) . '<input type="file" name="mrads_file" accept=".json" required> <button class="button">Load settings</button></form></div>';
		if ( class_exists( 'MRSH_AdsTools' ) ) {
			MRSH_AdsTools::panel( 'ads' );
		}
		echo '<div class="mra-card mra-help"><h2>Where to get ad code</h2><ol><li><b>Google AdSense:</b> Ads &rarr; By ad unit &rarr; Display ads. Copy the code, paste it above. Add your publisher line to ads.txt in <a href="' . esc_url( admin_url( 'admin.php?page=myrishta-seo' ) ) . '">MyRishta SEO</a>.</li><li><b>Media.net and other networks:</b> after approval, the dashboard gives an ad unit code and the ads.txt line. Paste the code here and the line in MyRishta SEO.</li><li>Never paste a line with made-up numbers into ads.txt. Networks treat it as invalid.</li><li>Use <b>Preview on a guide page</b> above to see where each slot sits before you save real code.</li></ol></div></div>';
		echo '<script>(function(){var f=document.getElementById("mra-form");if(!f)return;function set(n,v){var e=f.querySelector("[name=\'"+n+"\']");if(!e)return;if(e.type==="checkbox")e.checked=!!v;else e.value=v;}var P={app:{"m[card_on]":1,"m[bar_on]":1,"m[enabled]":0,"m[slots][top][on]":0,"m[slots][mid][on]":0,"m[slots][end][on]":0},one:{"m[card_on]":1,"m[bar_on]":1,"m[enabled]":1,"m[slots][top][on]":0,"m[slots][mid][on]":1,"m[slots][end][on]":0},three:{"m[card_on]":1,"m[bar_on]":1,"m[enabled]":1,"m[slots][top][on]":1,"m[slots][mid][on]":1,"m[slots][end][on]":1}};document.querySelectorAll("[data-preset]").forEach(function(b){b.addEventListener("click",function(){var p=P[b.getAttribute("data-preset")];for(var k in p)set(k,p[k]);window.scrollTo({top:document.body.scrollHeight/3,behavior:"smooth"});});});})();</script>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
MRADS::init();
