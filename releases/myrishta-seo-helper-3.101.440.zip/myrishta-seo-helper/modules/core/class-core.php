<?php
/**
 * MyRishta Core (data layer). Registers the same profile type, filters and statuses the DA10 theme registered, with the same
 * names and web addresses, so every existing profile, user, message and order keeps working without that theme or its licence.
 * It steps aside when DA10 is the active theme (that theme registers them itself), so nothing is registered twice.
 * It also protects the profile-field list (option "cfields") from being wiped or shortened by mistake.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Core {

	const CPT = 'listing_type';

	/** Filter taxonomies (names exactly as stored in the database). */
	public static function taxonomies() {
		return array(
			'dagender', 'dasexuality', 'dathnicity', 'daeyes', 'dahair', 'dabody', 'dasmoke', 'dadrink', 'dahairlength',
			'features', 'caste', 'education', 'maritalstatus', 'nationality', 'occupation', 'profilecreated', 'religion', 'sect',
		);
	}

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ), 20 );
		add_filter( 'pre_update_option_cfields', array( __CLASS__, 'guard_fields' ), 10, 2 );
	}

	/** True when the DA10 theme is doing this job itself. */
	private static function theme_does_it() {
		return post_type_exists( self::CPT ) || defined( 'THEME_TAXONOMY' );
	}

	public static function register() {
		if ( self::theme_does_it() ) {
			return;
		}
		$slug = (string) get_option( 'premiumpress_custompermalink' );
		$slug = strlen( $slug ) > 1 ? $slug : 'listing';
		$cat  = (string) get_option( 'premiumpress_customcategorypermalink' );
		$cat  = strlen( $cat ) > 1 ? $cat : $slug . '-category';
		$cty  = (string) get_option( 'premiumpress_countrypermalink' );
		$cty  = strlen( $cty ) > 1 ? $cty : 'country';

		register_post_type( self::CPT, array(
			'labels'              => array( 'name' => 'Profiles', 'singular_name' => 'Profile' ),
			'public'              => true,
			'publicly_queryable'  => true,
			'rewrite'             => array( 'slug' => $slug ),
			'supports'            => array( 'title', 'editor', 'author', 'comments', 'excerpt', 'thumbnail', 'custom-fields' ),
			'taxonomies'          => array( 'category', 'post_tag' ),
			'menu_icon'           => 'dashicons-heart',
			'menu_position'       => 4,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_nav_menus'   => true,
			'show_in_rest'        => false,
		) );

		foreach ( array( 'payment' => 'Waiting Payment', 'pending_approval' => 'Pending Approval', 'expired' => 'Expired' ) as $st => $label ) {
			register_post_status( $st, array(
				'label'                     => $label,
				'public'                    => true,
				'show_in_admin_all_list'    => true,
				'show_in_admin_status_list' => true,
				'label_count'               => _n_noop( $label . ' <span class="count">(%s)</span>', $label . ' <span class="count">(%s)</span>' ),
			) );
		}

		// Star signs ("listing") and countries have public pages; the other filters are internal lists.
		register_taxonomy( 'listing', self::CPT, array(
			'hierarchical' => true,
			'labels'       => array( 'name' => 'Star Signs', 'singular_name' => 'Star Sign' ),
			'query_var'    => true,
			'show_ui'      => true,
			'rewrite'      => array( 'slug' => $cat ),
		) );
		register_taxonomy( 'country', self::CPT, array(
			'hierarchical' => true,
			'labels'       => array( 'name' => 'Country' ),
			'query_var'    => true,
			'show_ui'      => true,
			'rewrite'      => array( 'slug' => $cty ),
		) );
		foreach ( self::taxonomies() as $t ) {
			register_taxonomy( $t, self::CPT, array(
				'hierarchical' => true,
				'labels'       => array( 'name' => ucfirst( $t ) ),
				'public'       => false,
				'show_ui'      => true,
				'rewrite'      => false,
				'query_var'    => false,
			) );
		}

		foreach ( array( 'ppt_message' => 'Messages', 'ppt_orders' => 'Orders', 'ppt_offer' => 'Offers', 'ppt_news' => 'News', 'ppt_logs' => 'Logs' ) as $pt => $name ) {
			if ( ! post_type_exists( $pt ) ) {
				register_post_type( $pt, array(
					'labels'       => array( 'name' => $name ),
					'public'       => false,
					'show_ui'      => true,
					'show_in_menu' => true,
					'rewrite'      => false,
					'supports'     => array( 'title', 'editor', 'author', 'custom-fields' ),
				) );
			}
		}
	}

	/**
	 * The profile-field list is the heart of the profile form. Refuse an update that empties it or cuts it to less than half
	 * (a reset), keep the last good copy in "mrsh_cfields_keep" and note it in the log.
	 */
	public static function guard_fields( $new, $old ) {
		$old_n = ( is_array( $old ) && ! empty( $old['dbkey'] ) ) ? count( (array) $old['dbkey'] ) : 0;
		$new_n = ( is_array( $new ) && ! empty( $new['dbkey'] ) ) ? count( (array) $new['dbkey'] ) : 0;
		if ( $old_n >= 6 && $new_n < $old_n * 0.5 ) {
			$log   = (array) get_option( 'mrsh_core_log', array() );
			$log[] = gmdate( 'c' ) . ' blocked a reset of the profile fields (' . $old_n . ' -> ' . $new_n . ')';
			update_option( 'mrsh_core_log', array_slice( $log, -30 ), false );
			return $old;
		}
		if ( $new_n >= 6 ) {
			update_option( 'mrsh_cfields_keep', $new, false );
		}
		return $new;
	}
}
MRSH_Core::init();
