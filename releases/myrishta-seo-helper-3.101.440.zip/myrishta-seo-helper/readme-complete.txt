MyRishta SEO Helper 3.52.1 - COMPLETE (SEO + App + Ads in one plugin)

Inside this one plugin:
 - SEO, AI visibility, profile reminders, security, speed (as before)
 - My Rishta App at /app/ (version 1.13.1)  -> modules/app
 - MyRishta Ads + app promotion (version 1.1.0) -> modules/ads

On a new site install ONLY this plugin. Do not also install the separate "My Rishta App" or "MyRishta Ads" plugins.
If they are already active, this plugin skips its own copy and nothing breaks; deactivate and delete them to finish the merge.

3.53.0 - members + match making + theme inside
- Match making: compatibility %, why-matched reasons, match both ways, partner preferences, hide, weekly email, admin Match Desk with one-click introductions.
- Members: send interest, message (same format as before), wink, shortlist, block, report (3 reports pause a profile), last seen, pause profile, add/edit profile form, inbox.
- Admin: Overview (counts, approve queue, reports), CSV export without phone numbers, Theme and App installer.
- App: installable from the site (PWA); no redirect to /app/ when the My Rishta theme is active.

3.53.1 - admin screens: Member settings (daily limits, approval, blocked words, min match %), Profiles manager (approve, pause, feature, verify, trash), Messages monitor, Members (last seen, ban/unban), Orders (read only). Members get a "Viewed me" tab.
