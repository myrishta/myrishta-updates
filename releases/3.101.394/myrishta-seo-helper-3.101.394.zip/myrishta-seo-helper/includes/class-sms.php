<?php
/**
 * Self-hosted SMS gateway. An Android phone with a SIM runs the free open-source "SMSGate" app
 * (android-sms-gateway); this site sends it a request and the phone sends the SMS. No per-message company fees.
 * Used for two-step login codes (see MRSH_TwoFactor, method "sms"). Off by default; email stays the fallback.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_SMS {

	const OPT = 'mrsh_sms_settings';

	public static function settings() {
		$d = array(
			'enabled' => 0,
			'sent_ok' => 0,
			'url'     => 'https://api.sms-gate.app/3rdparty/v1/message',
			'user'    => '',
			'pass'    => '',
			'cc'      => '92',
			'message' => 'Your {site} verification code is {code}. It works for {minutes} minutes. Never share this code with anyone.',
			'last'    => array(),
		);
		$s = get_option( self::OPT, array() );
		return is_array( $s ) ? array_merge( $d, $s ) : $d;
	}

	public static function enabled() {
		$s = self::settings();
		return ! empty( $s['enabled'] ) && '' !== trim( (string) $s['url'] ) && '' !== trim( (string) $s['user'] ) && '' !== (string) $s['pass'];
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 22 );
		add_action( 'admin_post_mrsh_sms_settings', array( __CLASS__, 'save_settings' ) );
		add_action( 'admin_post_mrsh_sms_test', array( __CLASS__, 'test' ) );
	}

	public static function message_for( $code, $minutes ) {
		return str_replace(
			array( '{site}', '{code}', '{minutes}' ),
			array( wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ), $code, (int) $minutes ),
			(string) self::settings()['message']
		);
	}

	/** Pure: builds the request for the SMSGate API (easy to test). */
	public static function build_request( $s, $digits, $msg ) {
		return array(
			'url'     => trim( (string) $s['url'] ),
			'headers' => array(
				'Content-Type'  => 'application/json',
				'Authorization' => 'Basic ' . base64_encode( trim( (string) $s['user'] ) . ':' . (string) $s['pass'] ),
			),
			'body'    => wp_json_encode( array( 'message' => $msg, 'phoneNumbers' => array( '+' . $digits ) ) ),
		);
	}

	/** Sends one SMS. Returns true or a WP_Error with a plain reason. Never fatal. */
	public static function send( $digits, $code, $minutes = 10 ) {
		$s = self::settings();
		if ( ! self::enabled() ) {
			return new WP_Error( 'mrsh_sms_off', 'The SMS gateway is switched off or not filled in.' );
		}
		$digits = preg_replace( '/\D/', '', (string) $digits );
		if ( ! preg_match( '/^[1-9]\d{7,14}$/', $digits ) ) {
			return new WP_Error( 'mrsh_sms_num', 'That phone number does not look right.' );
		}
		$url = trim( (string) $s['url'] );
		if ( 0 !== strpos( $url, 'https://' ) && 0 !== strpos( $url, 'http://' ) ) {
			return new WP_Error( 'mrsh_sms_url', 'The gateway address must start with https://' );
		}
		$req = self::build_request( $s, $digits, self::message_for( $code, $minutes ) );
		$r   = wp_remote_post( $req['url'], array( 'timeout' => 15, 'headers' => $req['headers'], 'body' => $req['body'] ) );
		if ( is_wp_error( $r ) ) {
			$err = 'Could not reach the gateway: ' . $r->get_error_message();
			self::note( false, $err );
			return new WP_Error( 'mrsh_sms_http', $err );
		}
		$http = (int) wp_remote_retrieve_response_code( $r );
		if ( $http < 200 || $http > 299 ) {
			$err = 'The gateway answered ' . $http . ': ' . mb_substr( wp_strip_all_tags( wp_remote_retrieve_body( $r ) ), 0, 200 );
			self::note( false, $err );
			return new WP_Error( 'mrsh_sms_http', $err );
		}
		self::note( true, '' );
		return true;
	}

	private static function note( $ok, $err ) {
		$s         = self::settings();
		$s['last'] = array( 'ok' => $ok ? 1 : 0, 'time' => time(), 'err' => $err );
		if ( $ok ) {
			$s['sent_ok'] = 1;
		}
		update_option( self::OPT, $s, false );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'SMS Gateway', 'SMS Gateway', 'manage_options', 'mrsh-sms', array( __CLASS__, 'page' ) );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s    = self::settings();
		$last = is_array( $s['last'] ) ? $s['last'] : array();
		$have = '' !== trim( (string) $s['user'] ) && '' !== (string) $s['pass'];
		MRSH_Admin::open( 'SMS Gateway', 'Send login codes by SMS from your own Android phone and SIM. Free app, no per-message fees. Switch it on only after the test SMS reaches you.' );
		if ( isset( $_GET['msg'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="notice notice-info"><p>' . esc_html( rawurldecode( (string) wp_unslash( $_GET['msg'] ) ) ) . '</p></div>'; // phpcs:ignore
		}
		?>
<style>
.msms{max-width:980px;margin:18px 0 40px;font-size:14px}
.msms *{box-sizing:border-box}
.msms .chips{display:flex;gap:10px;flex-wrap:wrap;margin:0 0 18px}
.msms .chip{background:#fff;border-radius:14px;padding:12px 16px;box-shadow:0 1px 3px rgba(17,24,39,.08),0 0 0 1px rgba(17,24,39,.04);min-width:170px}
.msms .chip small{display:block;color:#6b7280;text-transform:uppercase;letter-spacing:.06em;font-size:11px}
.msms .chip b{font-size:15px}
.msms .ok{color:#047857}.msms .no{color:#b91c1c}.msms .wn{color:#b45309}
.msms .card{background:#fff;border-radius:20px;padding:22px 26px;margin:0 0 16px;box-shadow:0 1px 3px rgba(17,24,39,.07),0 0 0 1px rgba(17,24,39,.04)}
.msms .hd{display:flex;align-items:center;gap:12px;margin:0 0 6px}
.msms .hd h2{margin:0;font-size:17px}
.msms .n{width:30px;height:30px;border-radius:10px;background:linear-gradient(135deg,#6366f1,#4338ca);color:#fff;display:grid;place-items:center;font-weight:700}
.msms .sub{margin:0 0 16px;color:#6b7280;line-height:1.55;max-width:760px}
.msms label.f{display:block;font-weight:600;margin:0 0 14px}
.msms label.f span{display:block;font-weight:400;color:#6b7280;font-size:12.5px;margin-top:3px}
.msms input[type=text],.msms input[type=password],.msms textarea{width:100%;max-width:520px;border:1px solid #d6dae1;border-radius:12px;padding:10px 14px;font-size:14px;background:#f8fafc;margin-top:6px}
.msms textarea{max-width:760px}
.msms input:focus,.msms textarea:focus{outline:0;border-color:#4338ca;box-shadow:0 0 0 3px rgba(99,102,241,.2);background:#fff}
.msms .sw{display:flex;gap:12px;align-items:flex-start;padding:12px 14px;border:1px solid #e5e7eb;border-radius:14px;margin:0 0 10px;cursor:pointer}
.msms .sw input{margin-top:4px;width:18px;height:18px;accent-color:#4338ca}
.msms .sw b{display:block}.msms .sw span{color:#6b7280;font-size:13px}
.msms .btn{border:0;border-radius:12px;padding:10px 20px;font-weight:700;cursor:pointer;background:#fff;color:#111827;box-shadow:0 0 0 1px #d6dae1}
.msms .btn.p{background:linear-gradient(135deg,#6366f1,#4338ca);color:#fff;box-shadow:none}
.msms .bar{position:sticky;bottom:0;background:rgba(255,255,255,.92);backdrop-filter:blur(6px);padding:12px 0;display:flex;gap:10px;align-items:center}
.msms .steps{margin:0 0 0 18px;color:#374151;line-height:1.7}
</style>
<div class="msms">
	<div class="chips">
		<div class="chip"><small>SMS codes</small><b class="<?php echo self::enabled() ? 'ok' : 'no'; ?>"><?php echo self::enabled() ? 'ON' : 'OFF'; ?></b></div>
		<div class="chip"><small>Login details</small><b class="<?php echo $have ? 'ok' : 'wn'; ?>"><?php echo $have ? 'Saved' : 'Not entered yet'; ?></b></div>
		<div class="chip"><small>Last SMS</small><b class="<?php echo $last ? ( ! empty( $last['ok'] ) ? 'ok' : 'no' ) : ''; ?>"><?php echo $last ? esc_html( ( ! empty( $last['ok'] ) ? 'Sent ' : 'Failed ' ) . wp_date( 'j M H:i', (int) $last['time'] ) ) : 'None yet'; ?></b></div>
		<div class="chip"><small>Tested OK once</small><b class="<?php echo ! empty( $s['sent_ok'] ) ? 'ok' : 'wn'; ?>"><?php echo ! empty( $s['sent_ok'] ) ? 'Yes' : 'Not yet'; ?></b></div>
	</div>
	<?php if ( $last && empty( $last['ok'] ) && ! empty( $last['err'] ) ) : ?><div class="card" style="border-left:5px solid #dc2626"><b class="no">Last error:</b> <?php echo esc_html( $last['err'] ); ?></div><?php endif; ?>

	<div class="card">
		<div class="hd"><span class="n">1</span><h2>Set up the phone (once, about 10 minutes)</h2></div>
		<ol class="steps">
			<li>Use a spare Android phone with a working SIM that can send SMS. Keep it charged and online.</li>
			<li>Install the free <b>SMSGate</b> app (android-sms-gateway, from sms-gate.app or F-Droid / GitHub) and allow SMS permission.</li>
			<li>In the app switch on <b>Cloud server</b>. It shows a <b>username</b> and <b>password</b>. Enter them below.</li>
			<li>Press <b>Send test SMS</b> below with your own number.</li>
		</ol>
	</div>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="mrsh_sms_settings">
		<?php wp_nonce_field( 'mrsh_sms_settings' ); ?>
		<div class="card">
			<div class="hd"><span class="n">2</span><h2>Gateway details</h2></div>
			<p class="sub">The password is stored but never shown again. Leave it empty to keep the saved one.</p>
			<label class="f">Gateway address<input type="text" name="url" value="<?php echo esc_attr( $s['url'] ); ?>"><span>Default is the free SMSGate cloud. If you run your own SMSGate server, put its address here.</span></label>
			<label class="f">Username<input type="text" name="user" value="<?php echo esc_attr( $s['user'] ); ?>" autocomplete="off"></label>
			<label class="f">Password<input type="password" name="pass" value="" autocomplete="new-password" placeholder="<?php echo $s['pass'] ? '(saved)' : ''; ?>"></label>
			<label class="f">Country code for numbers starting with 0<input type="text" name="cc" value="<?php echo esc_attr( $s['cc'] ); ?>" style="max-width:120px"><span>Pakistan is 92.</span></label>
			<label class="f">Message<textarea name="message" rows="3"><?php echo esc_textarea( $s['message'] ); ?></textarea><span>Keep {code}. You can also use {site} and {minutes}.</span></label>
		</div>
		<div class="card">
			<div class="hd"><span class="n">3</span><h2>Switch on</h2></div>
			<label class="sw"><input type="checkbox" name="enabled" value="1"<?php checked( $s['enabled'], 1 ); ?>><div><b>Allow login codes by SMS</b><span>Members can then pick "Code by SMS" on their account page (also tick it under Login Security). If the phone is off, the code goes by email instead.</span></div></label>
		</div>
		<div class="bar"><button class="btn p" type="submit">Save settings</button></div>
	</form>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="card">
		<input type="hidden" name="action" value="mrsh_sms_test">
		<?php wp_nonce_field( 'mrsh_sms_test' ); ?>
		<div class="hd"><span class="n">4</span><h2>Send test SMS</h2></div>
		<p class="sub">Save first, then enter your own number (for example 0300 1234567).</p>
		<label class="f">Your phone number<input type="text" name="phone" placeholder="0300 1234567"></label>
		<button class="btn p" type="submit">Send test SMS</button>
	</form>
</div>
		<?php
		MRSH_Admin::close();
	}

	public static function save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_sms_settings' );
		$new            = self::settings();
		$new['enabled'] = empty( $_POST['enabled'] ) ? 0 : 1;
		$new['url']     = esc_url_raw( trim( (string) wp_unslash( $_POST['url'] ?? $new['url'] ) ) );
		$new['user']    = sanitize_text_field( wp_unslash( $_POST['user'] ?? '' ) );
		$pass           = (string) wp_unslash( $_POST['pass'] ?? '' );
		if ( '' !== $pass ) {
			$new['pass'] = $pass;
		}
		$new['cc']      = preg_replace( '/\D/', '', (string) wp_unslash( $_POST['cc'] ?? '92' ) ) ?: '92';
		$m              = sanitize_textarea_field( wp_unslash( $_POST['message'] ?? $new['message'] ) );
		if ( false !== strpos( $m, '{code}' ) ) {
			$new['message'] = $m;
		}
		update_option( self::OPT, $new, false );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-sms&msg=' . rawurlencode( 'Saved.' ) ) );
		exit;
	}

	public static function test() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_sms_test' );
		$s = self::settings();
		$n = MRSH_WhatsApp::normalize( sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) ), (string) $s['cc'] );
		if ( '' === $n ) {
			$msg = 'That phone number does not look right.';
		} elseif ( empty( $s['user'] ) || '' === (string) $s['pass'] ) {
			$msg = 'Enter the username and password and save first.';
		} else {
			// The test works even while the switch is off, so you can check before going live.
			$on = $s['enabled'];
			$s['enabled'] = 1;
			update_option( self::OPT, $s, false );
			$r = self::send( $n, (string) random_int( 100000, 999999 ), 10 );
			$s = self::settings();
			$s['enabled'] = $on;
			update_option( self::OPT, $s, false );
			$msg = true === $r ? 'The gateway accepted the message. Check your phone.' : $r->get_error_message();
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-sms&msg=' . rawurlencode( $msg ) ) );
		exit;
	}
}
