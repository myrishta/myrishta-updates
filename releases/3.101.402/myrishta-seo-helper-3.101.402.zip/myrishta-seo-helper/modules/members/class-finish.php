<?php
/**
 * Profile finishers: members who signed up but never made a profile get up to two friendly reminders
 * (English and Urdu), sent by the Autopilot. Also records the last step each member reached in the
 * step-by-step profile builder, so the admin can see where people stop.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Finish {

	const STEPS = 'mrsh_pf_steps'; // option: array( step => count of members who stopped at it )

	public static function init() {
		add_action( 'mrsh_tk_poll', array( __CLASS__, 'tick' ), 40 );
		add_action( 'wp_ajax_mrsh_pf_step', array( __CLASS__, 'step' ) );
	}

	/** Remember how far a member got in the builder (only the highest step counts). */
	public static function step() {
		$uid = get_current_user_id();
		$s   = isset( $_POST['s'] ) ? absint( $_POST['s'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		$n   = isset( $_POST['n'] ) ? absint( $_POST['n'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		if ( $uid && $s >= 1 && $s <= 20 ) {
			$old = (int) get_user_meta( $uid, 'mrsh_pf_step', true );
			if ( $s > $old ) {
				update_user_meta( $uid, 'mrsh_pf_step', $s );
				update_user_meta( $uid, 'mrsh_pf_of', max( $s, $n ) );
			}
		}
		wp_send_json_success();
	}

	private static function has_profile( $uid ) {
		if ( class_exists( 'MRSH_Members' ) && method_exists( 'MRSH_Members', 'my_profile' ) ) {
			return (bool) MRSH_Members::my_profile( $uid );
		}
		return (bool) get_posts( array( 'post_type' => 'listing_type', 'author' => $uid, 'post_status' => array( 'publish', 'draft', 'pending' ), 'numberposts' => 1, 'fields' => 'ids', 'no_found_rows' => true ) );
	}

	/** Called every 5 minutes with the ticket cycle; sends a few reminders at a time. */
	public static function tick() {
		if ( ! class_exists( 'MRSH_Mem_Mail' ) || ( class_exists( 'MRSH_Autopilot' ) && ! MRSH_Autopilot::can( 'members' ) ) ) {
			return;
		}
		if ( get_transient( 'mrsh_nudge_run' ) ) {
			return;
		}
		set_transient( 'mrsh_nudge_run', 1, 20 * MINUTE_IN_SECONDS );
		$now  = time();
		$sent = 0;
		$cand = get_users( array(
			'role'       => 'subscriber',
			'number'     => 60,
			'orderby'    => 'registered',
			'order'      => 'DESC',
			'date_query' => array( array( 'after' => gmdate( 'Y-m-d H:i:s', $now - 14 * DAY_IN_SECONDS ), 'before' => gmdate( 'Y-m-d H:i:s', $now - DAY_IN_SECONDS ), 'inclusive' => true, 'column' => 'user_registered' ) ),
		) );
		foreach ( $cand as $u ) {
			if ( $sent >= 8 ) {
				break;
			}
			if ( get_user_meta( $u->ID, 'mrsh_nudge2', true ) || get_user_meta( $u->ID, 'mrsh_nudge_off', true ) || get_user_meta( $u->ID, 'mrt_helper', true ) || ! is_email( $u->user_email ) ) {
				continue;
			}
			if ( self::has_profile( $u->ID ) ) {
				update_user_meta( $u->ID, 'mrsh_nudge_off', 1 ); // done, never remind again
				continue;
			}
			$age = $now - strtotime( $u->user_registered . ' UTC' );
			$n1  = (int) get_user_meta( $u->ID, 'mrsh_nudge1', true );
			if ( ! $n1 && $age >= DAY_IN_SECONDS ) {
				$key = 'nudge1';
			} elseif ( $n1 && $now - $n1 >= 3 * DAY_IN_SECONDS && $age >= 4 * DAY_IN_SECONDS ) {
				$key = 'nudge2';
			} else {
				continue;
			}
			$link = add_query_arg( array( 'utm_source' => 'email', 'utm_medium' => 'nudge', 'utm_campaign' => $key ), home_url( '/add-listing/' ) );
			$ok   = MRSH_Mem_Mail::send( $u->user_email, $key, array( 'name' => $u->display_name ? $u->display_name : $u->user_login, 'link' => $link ) );
			update_user_meta( $u->ID, 'nudge1' === $key ? 'mrsh_nudge1' : 'mrsh_nudge2', $now );
			if ( $ok ) {
				$sent++;
			}
		}
		if ( $sent && class_exists( 'MRSH_Autopilot' ) ) {
			MRSH_Autopilot::log( 'Profile reminders', 'Sent ' . $sent . ' friendly reminder(s) to members who have not finished their profile.' );
		}
	}

	/** Small card for the Autopilot page: where members stop in the builder, and how many are waiting. */
	public static function card() {
		global $wpdb;
		$rows = $wpdb->get_results( "SELECT meta_value AS s, COUNT(*) AS c FROM {$wpdb->usermeta} WHERE meta_key='mrsh_pf_step' GROUP BY meta_value ORDER BY CAST(meta_value AS UNSIGNED)" ); // phpcs:ignore WordPress.DB
		$sent = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key='mrsh_nudge1'" ); // phpcs:ignore WordPress.DB
		echo '<div class="mx-card"><h2 class="mx-h">Profile builder</h2><p style="color:#6b7280;margin:0 0 10px">Members who opened the step-by-step builder, by the furthest step they reached. Reminders sent so far: <b>' . (int) $sent . '</b>.</p>';
		if ( ! $rows ) {
			echo '<p style="margin:0;color:#6b7280">No data yet. It fills in as new members use the builder.</p></div>';
			return;
		}
		echo '<div class="mx-stats">';
		foreach ( $rows as $r ) {
			echo class_exists( 'MRSH_Boost' ) ? MRSH_Boost::ui_stat( (int) $r->c, 'Reached step ' . (int) $r->s, '#7c3aed' ) : '<span>Step ' . (int) $r->s . ': ' . (int) $r->c . '</span> '; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</div></div>';
	}
}

MRSH_Finish::init();
