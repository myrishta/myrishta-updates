<?php
/**
 * Growth tools: saved-search alerts, plan expiry and free trial, "we miss you" email, referrals, activity log,
 * admin charts, site checklist, success-story submissions, extra pages, chat safety helpers, pull to refresh.
 * Settings are stored in option mrsh_growth. Admin page: My Rishta SEO > Growth tools.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Mem_Growth {

	public static function defaults() {
		return array( 'trial_days' => 0, 'trial_plan' => 'Silver', 'miss_days' => 30, 'miss_on' => 1, 'alerts_on' => 1, 'ref_on' => 1, 'warn_days' => 3, 'story_on' => 1 );
	}

	public static function get( $k = null ) {
		$o = array_merge( self::defaults(), (array) get_option( 'mrsh_growth', array() ) );
		return null === $k ? $o : ( $o[ $k ] ?? '' );
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 25 );
		add_action( 'admin_post_mrsh_growth_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_mrsh_story_act', array( __CLASS__, 'story_act' ) );
		add_action( 'init', array( __CLASS__, 'cron_setup' ) );
		add_action( 'mrsh_growth_daily', array( __CLASS__, 'daily' ) );
		add_action( 'user_register', array( __CLASS__, 'on_register' ), 20 );
		add_action( 'init', array( __CLASS__, 'ref_cookie' ) );
		add_action( 'wp_ajax_mrsh_save_search', array( __CLASS__, 'ajax_save_search' ) );
		add_action( 'wp_ajax_mrsh_del_search', array( __CLASS__, 'ajax_del_search' ) );
		add_action( 'mrt_account_extra', array( __CLASS__, 'account_box' ) );
		add_action( 'wp_footer', array( __CLASS__, 'front_js' ), 70 );
		add_shortcode( 'mrsh_story_form', array( __CLASS__, 'story_form' ) );
		add_action( 'init', array( __CLASS__, 'story_post' ) );
		add_action( 'admin_init', array( __CLASS__, 'make_pages' ) );
		add_action( 'show_user_profile', array( __CLASS__, 'user_fields' ) );
		add_action( 'edit_user_profile', array( __CLASS__, 'user_fields' ) );
		add_action( 'edit_user_profile_update', array( __CLASS__, 'user_fields_save' ) );
		add_action( 'personal_options_update', array( __CLASS__, 'user_fields_save' ) );
		add_action( 'updated_user_meta', array( __CLASS__, 'log_meta' ), 10, 4 );
		add_action( 'added_user_meta', array( __CLASS__, 'log_meta' ), 10, 4 );
		add_action( 'transition_post_status', array( __CLASS__, 'log_post' ), 10, 3 );
	}

	/* ---------- schedule ---------- */

	public static function cron_setup() {
		if ( ! wp_next_scheduled( 'mrsh_growth_daily' ) ) {
			wp_schedule_event( time() + 1800, 'daily', 'mrsh_growth_daily' );
		}
	}

	public static function daily() {
		self::plan_expiry();
		self::saved_alerts();
		if ( 1 === (int) gmdate( 'N' ) ) { // Mondays
			self::miss_you();
		}
	}

	private static function mail( $to, $subject, $body ) {
		$sig = "\n\n" . get_bloginfo( 'name' ) . "\n" . home_url( '/' ) . "\nNever send money to anyone you meet online.";
		wp_mail( $to, $subject, $body . $sig );
	}

	/* ---------- plan expiry and trial ---------- */

	public static function on_register( $uid ) {
		$d = (int) self::get( 'trial_days' );
		$p = trim( (string) self::get( 'trial_plan' ) );
		if ( $d > 0 && $p && ! get_user_meta( $uid, 'mrt_plan', true ) ) {
			update_user_meta( $uid, 'mrt_plan', $p );
			update_user_meta( $uid, 'mrt_plan_exp', time() + $d * DAY_IN_SECONDS );
			update_user_meta( $uid, 'mrt_trial', 1 );
		}
		$ref = isset( $_COOKIE['mrsh_ref'] ) ? absint( $_COOKIE['mrsh_ref'] ) : 0; // phpcs:ignore
		if ( $ref && $ref !== (int) $uid && get_userdata( $ref ) && self::get( 'ref_on' ) ) {
			update_user_meta( $uid, 'mrt_ref', $ref );
		}
	}

	public static function plan_expiry() {
		$now  = time();
		$warn = (int) self::get( 'warn_days' ) * DAY_IN_SECONDS;
		$q    = get_users( array( 'meta_key' => 'mrt_plan_exp', 'meta_compare' => 'EXISTS', 'number' => 300 ) );
		foreach ( $q as $u ) {
			$exp = (int) get_user_meta( $u->ID, 'mrt_plan_exp', true );
			if ( ! $exp ) {
				continue;
			}
			$link = home_url( '/memberships/' );
			if ( $exp <= $now ) {
				$old = (string) get_user_meta( $u->ID, 'mrt_plan', true );
				delete_user_meta( $u->ID, 'mrt_plan' );
				delete_user_meta( $u->ID, 'mrt_plan_exp' );
				delete_user_meta( $u->ID, 'mrt_exp_warn' );
				self::log( 'Plan ' . $old . ' ended for user #' . $u->ID );
				self::mail( $u->user_email, 'Your plan has ended | آپ کا پلان ختم ہو گیا', 'Assalam o Alaikum ' . $u->display_name . ",\n\nYour " . $old . ' plan has ended. Your profile stays live. To renew, open: ' . $link . "\n\nآپ کا پلان ختم ہو گیا ہے۔ آپ کی پروفائل بدستور فعال ہے۔ تجدید کے لیے دیکھیں: " . $link );
			} elseif ( $exp - $now <= $warn && ! get_user_meta( $u->ID, 'mrt_exp_warn', true ) ) {
				update_user_meta( $u->ID, 'mrt_exp_warn', 1 );
				self::mail( $u->user_email, 'Your plan ends soon | آپ کا پلان جلد ختم ہو گا', 'Assalam o Alaikum ' . $u->display_name . ",\n\nYour plan ends on " . wp_date( 'j F Y', $exp ) . '. To renew, open: ' . $link . "\n\nآپ کا پلان " . wp_date( 'j F Y', $exp ) . ' کو ختم ہو گا۔ تجدید: ' . $link );
			}
		}
	}

	public static function user_fields( $u ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$exp = (int) get_user_meta( $u->ID, 'mrt_plan_exp', true );
		$ref = (int) get_user_meta( $u->ID, 'mrt_ref', true );
		echo '<h2>My Rishta (admin only)</h2><table class="form-table"><tr><th>Plan ends on</th><td><input type="date" name="mrt_plan_exp" value="' . esc_attr( $exp ? wp_date( 'Y-m-d', $exp ) : '' ) . '"> <span class="description">Empty = no end date. Set the plan itself in My Rishta SEO > Members.</span></td></tr>';
		echo '<tr><th>Private note</th><td><textarea name="mrt_note" rows="3" class="large-text">' . esc_textarea( (string) get_user_meta( $u->ID, 'mrt_note', true ) ) . '</textarea><p class="description">Only admins see this.</p></td></tr>';
		echo '<tr><th>Joined through</th><td>' . ( $ref ? 'Invite link of user #' . (int) $ref : 'Direct' ) . '</td></tr></table>';
	}

	public static function user_fields_save( $uid ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		if ( isset( $_POST['mrt_plan_exp'] ) ) { // phpcs:ignore
			$t = strtotime( sanitize_text_field( wp_unslash( $_POST['mrt_plan_exp'] ) ) . ' 23:59:59' ); // phpcs:ignore
			if ( $t ) {
				update_user_meta( $uid, 'mrt_plan_exp', $t );
				delete_user_meta( $uid, 'mrt_exp_warn' );
			} else {
				delete_user_meta( $uid, 'mrt_plan_exp' );
			}
		}
		if ( isset( $_POST['mrt_note'] ) ) { // phpcs:ignore
			update_user_meta( $uid, 'mrt_note', sanitize_textarea_field( wp_unslash( $_POST['mrt_note'] ) ) ); // phpcs:ignore
		}
	}

	/* ---------- we miss you ---------- */

	public static function miss_you() {
		if ( ! self::get( 'miss_on' ) ) {
			return;
		}
		$cut = time() - max( 7, (int) self::get( 'miss_days' ) ) * DAY_IN_SECONDS;
		$q   = get_users( array( 'meta_query' => array( array( 'key' => 'mrt_seen', 'value' => $cut, 'type' => 'NUMERIC', 'compare' => '<' ) ), 'number' => 100 ) );
		foreach ( $q as $u ) {
			$last = (int) get_user_meta( $u->ID, 'mrt_miss_sent', true );
			if ( $last && $last > time() - 60 * DAY_IN_SECONDS ) {
				continue;
			}
			$p = MRSH_Members::my_profile( $u->ID );
			if ( ! $p || 'publish' !== $p->post_status ) {
				continue;
			}
			update_user_meta( $u->ID, 'mrt_miss_sent', time() );
			$n     = MRSH_Members::unread_count( $u->ID );
			$extra = $n ? "\nYou have " . $n . " unread message(s).\nآپ کے " . $n . " پیغامات نہیں پڑھے گئے۔\n" : '';
			self::mail( $u->user_email, 'We miss you | ہمیں آپ کی یاد آ رہی ہے', 'Assalam o Alaikum ' . $u->display_name . ",\n\nNew profiles have joined since your last visit.\n" . $extra . "\nOpen your account: " . home_url( '/my-account/' ) . "\n\nآپ کے آخری وزٹ کے بعد نئی پروفائلز شامل ہوئی ہیں۔ اپنا اکاؤنٹ کھولیں: " . home_url( '/my-account/' ) );
		}
	}

	/* ---------- referrals ---------- */

	public static function ref_cookie() {
		if ( isset( $_GET['ref'] ) && self::get( 'ref_on' ) && ! headers_sent() ) { // phpcs:ignore
			$r = absint( $_GET['ref'] ); // phpcs:ignore
			if ( $r && get_userdata( $r ) ) {
				setcookie( 'mrsh_ref', (string) $r, time() + 30 * DAY_IN_SECONDS, COOKIEPATH ? COOKIEPATH : '/', '', is_ssl(), true );
			}
		}
	}

	/* ---------- saved searches ---------- */

	private static function clean_qs( $qs ) {
		parse_str( ltrim( (string) $qs, '?' ), $a );
		$out = array();
		foreach ( $a as $k => $v ) {
			$k = sanitize_key( $k );
			if ( in_array( $k, array( 'paged', 'pwa', 'lang', 'orderby', 'order' ), true ) || is_array( $v ) ) {
				continue;
			}
			$out[ $k ] = sanitize_text_field( (string) $v );
		}
		return $out;
	}

	public static function ajax_save_search() {
		$uid = get_current_user_id();
		if ( ! $uid || ! check_ajax_referer( 'mrt', 'n', false ) ) {
			wp_send_json( array( 'ok' => false, 'msg' => 'Please log in.' ) );
		}
		$a = self::clean_qs( wp_unslash( $_POST['qs'] ?? '' ) ); // phpcs:ignore
		unset( $a['post_type'] );
		if ( ! $a ) {
			wp_send_json( array( 'ok' => false, 'msg' => 'Choose some filters first.' ) );
		}
		$list = array_values( array_filter( (array) get_user_meta( $uid, 'mrt_saved', true ), 'is_array' ) );
		if ( count( $list ) >= 5 ) {
			wp_send_json( array( 'ok' => false, 'msg' => 'You can keep 5 saved searches. Delete one first.' ) );
		}
		$label  = sanitize_text_field( wp_unslash( $_POST['label'] ?? '' ) ); // phpcs:ignore
		$list[] = array( 'qs' => $a, 'label' => $label ? mb_substr( $label, 0, 60 ) : 'Search ' . ( count( $list ) + 1 ), 'last' => time() );
		update_user_meta( $uid, 'mrt_saved', $list );
		wp_send_json( array( 'ok' => true, 'msg' => 'Saved. We email you when new profiles match.' ) );
	}

	public static function ajax_del_search() {
		$uid = get_current_user_id();
		if ( ! $uid || ! check_ajax_referer( 'mrt', 'n', false ) ) {
			wp_send_json( array( 'ok' => false ) );
		}
		$i    = absint( $_POST['i'] ?? 0 ); // phpcs:ignore
		$list = array_values( array_filter( (array) get_user_meta( $uid, 'mrt_saved', true ), 'is_array' ) );
		unset( $list[ $i ] );
		update_user_meta( $uid, 'mrt_saved', array_values( $list ) );
		wp_send_json( array( 'ok' => true ) );
	}

	public static function saved_alerts() {
		if ( true ) { // replaced by the single alert in MRSH_Ideas::alerts (one saved-search list)
			return;
		}
		if ( ! self::get( 'alerts_on' ) ) {
			return;
		}
		$q = get_users( array( 'meta_key' => 'mrt_saved', 'meta_compare' => 'EXISTS', 'number' => 200 ) );
		foreach ( $q as $u ) {
			$list = array_values( array_filter( (array) get_user_meta( $u->ID, 'mrt_saved', true ), 'is_array' ) );
			$body = '';
			foreach ( $list as $i => $s ) {
				$args = array( 'post_type' => 'listing_type', 'post_status' => 'publish', 'posts_per_page' => 1, 'fields' => 'ids', 'author__not_in' => array( $u->ID ), 'date_query' => array( array( 'after' => gmdate( 'Y-m-d H:i:s', (int) $s['last'] ), 'column' => 'post_date_gmt' ) ) );
				$tax  = array();
				foreach ( (array) $s['qs'] as $k => $v ) {
					if ( 's' === $k ) {
						$args['s'] = $v;
					} elseif ( taxonomy_exists( $k ) ) {
						$tax[] = array( 'taxonomy' => $k, 'field' => 'slug', 'terms' => $v );
					}
				}
				if ( $tax ) {
					$args['tax_query'] = $tax;
				}
				$r = new WP_Query( $args );
				if ( $r->found_posts > 0 ) {
					$body .= "\n" . $s['label'] . ': ' . $r->found_posts . " new profile(s)\n" . add_query_arg( array_merge( array( 'post_type' => 'listing_type' ), (array) $s['qs'] ), home_url( '/' ) ) . "\n";
				}
				$list[ $i ]['last'] = time();
			}
			update_user_meta( $u->ID, 'mrt_saved', $list );
			if ( $body ) {
				self::mail( $u->user_email, 'New profiles for your saved search | آپ کی محفوظ تلاش کے لیے نئی پروفائلز', 'Assalam o Alaikum ' . $u->display_name . ",\n" . $body . "\nمحفوظ تلاش میں نئی پروفائلز ملی ہیں، اوپر لنک دیکھیں۔\nTo stop, delete the search in My account." );
			}
		}
	}

	public static function account_box( $uid ) {
		if ( ! $uid ) {
			return;
		}
		$n    = wp_create_nonce( 'mrt' );
		$list = array_values( array_filter( (array) get_user_meta( $uid, 'mrt_saved', true ), 'is_array' ) );
		$cnt  = count( get_users( array( 'meta_key' => 'mrt_ref', 'meta_value' => $uid, 'fields' => 'ID' ) ) );
		$exp  = (int) get_user_meta( $uid, 'mrt_plan_exp', true );
		echo '<div class="wrap narrow" style="margin-top:16px">';
		if ( $exp && get_user_meta( $uid, 'mrt_plan', true ) ) {
			echo '<div class="box"><h3>Your plan</h3><p>' . esc_html( (string) get_user_meta( $uid, 'mrt_plan', true ) ) . ' plan' . ( get_user_meta( $uid, 'mrt_trial', true ) ? ' (free trial)' : '' ) . ' ends on <b>' . esc_html( wp_date( 'j F Y', $exp ) ) . '</b>.</p></div>';
		}
		// Saved searches now live in one place: the Saved searches tab.
		if ( self::get( 'ref_on' ) ) {
			$link = add_query_arg( 'ref', $uid, home_url( '/' ) );
			echo '<div class="box inv1"><h3>Invite a friend</h3><p>Share this link with families who need a rishta. ' . ( $cnt ? '<b>' . (int) $cnt . '</b> joined through you.' : '' ) . '</p><p><input type="text" readonly value="' . esc_attr( $link ) . '" onclick="this.select()" style="width:100%"></p><p><a class="btn" href="https://wa.me/?text=' . rawurlencode( 'Free rishta service for Pakistani families: ' . $link ) . '" target="_blank" rel="noopener">Share on WhatsApp</a></p></div>';
		}
		echo '</div><script>(function(){var b=document.getElementById("mrsh-saved");if(!b)return;b.addEventListener("click",function(e){var t=e.target.closest("[data-del]");if(!t)return;var f=new FormData();f.append("action","mrsh_del_search");f.append("n",' . wp_json_encode( $n ) . ');f.append("i",t.getAttribute("data-del"));fetch(' . wp_json_encode( admin_url( 'admin-ajax.php' ) ) . ',{method:"POST",body:f,credentials:"same-origin"}).then(function(){location.reload()})})})();</script>';
	}

	/* ---------- front end helpers: save-search button, chat safety, pull to refresh ---------- */

	public static function front_js() {
		if ( 'myrishta' !== get_template() ) {
			return;
		}
		$n  = wp_create_nonce( 'mrt' );
		$in = is_user_logged_in() ? 1 : 0;
		?>
<script>
(function(){
var AJ=<?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>,N=<?php echo wp_json_encode( $n ); ?>,IN=<?php echo (int) $in; ?>,LOGIN=<?php echo wp_json_encode( wp_login_url() ); ?>;
function toast(t){var d=document.getElementById('mrt-toast');if(d){d.textContent=t;d.classList.add('on');setTimeout(function(){d.classList.remove('on')},2600)}else alert(t)}
var box=document.getElementById('mrt-chat');
if(box){var ta=box.querySelector('textarea'),cl=box.querySelector('.cl');
var qr=['Assalam o Alaikum','JazakAllah khair','Please share family details','Can our families speak?','Thank you, not a match for us'];
var q=document.createElement('div');q.className='qrow';
var w=document.createElement('div');w.className='qwarn';w.style.cssText='display:none;background:#fff4e5;color:#7a4a00;border:1px solid #ffd49a;border-radius:12px;padding:8px 12px;margin:8px 0;font-size:.9rem';
w.textContent='Safety: never send money, card or bank details to someone you met here. Meet only with your families. / کسی کو رقم نہ بھیجیں، خاندان کے ساتھ ملاقات کریں۔';
var re=/(send\s*money|money|rupees|rs\.?\s*\d|easypaisa|jazzcash|western\s*union|bank\s*account|account\s*number|iban|gift\s*card|paisa|ٹرانسفر|پیسے|رقم)/i;
function chk(){var v=(ta?ta.value:'')+' '+(cl?cl.textContent.slice(-600):'');w.style.display=re.test(v)?'block':'none'}
qr.forEach(function(t){var c=document.createElement('button');c.type='button';c.className='chip';c.textContent=t;c.onclick=function(){if(ta){ta.value=(ta.value?ta.value+' ':'')+t;ta.focus();chk()}};q.appendChild(c)});
if(ta){var cp=ta.closest('.cmp')||ta.parentNode;cp.parentNode.insertBefore(w,cp);cp.parentNode.insertBefore(q,cp);ta.addEventListener('input',function(){chk();ta.style.height='auto';ta.style.height=Math.min(ta.scrollHeight,140)+'px'});ta.addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing&&window.innerWidth>700){e.preventDefault();var sb=box.querySelector('.send');if(sb)sb.click()}})}
if(cl)new MutationObserver(chk).observe(cl,{childList:true});chk()}
if(false){var y0=null,pt=document.createElement('div');pt.style.cssText='position:fixed;top:0;left:0;right:0;text-align:center;font-size:13px;padding:6px;background:rgba(0,0,0,.7);color:#fff;transform:translateY(-100%);transition:transform .2s;z-index:100';pt.textContent='Release to refresh';document.body.appendChild(pt);
addEventListener('touchstart',function(e){y0=window.scrollY<=0?e.touches[0].clientY:null},{passive:true});
addEventListener('touchmove',function(e){if(y0===null)return;pt.style.transform=(e.touches[0].clientY-y0>90)?'translateY(0)':'translateY(-100%)'},{passive:true});
addEventListener('touchend',function(e){if(y0!==null&&e.changedTouches[0].clientY-y0>90){location.reload()}pt.style.transform='translateY(-100%)';y0=null},{passive:true})}
})();
</script>
		<?php
	}

	/* ---------- activity log ---------- */

	public static function log( $msg ) {
		$l   = (array) get_option( 'mrsh_actlog', array() );
		$who = is_user_logged_in() ? wp_get_current_user()->user_login : 'system';
		array_unshift( $l, array( time(), $who, $msg ) );
		update_option( 'mrsh_actlog', array_slice( $l, 0, 200 ), false );
	}

	public static function log_meta( $mid, $uid, $key, $val ) {
		if ( ! in_array( $key, array( 'mrt_plan', '_mrsh_id_verified', 'ppt_verified', 'ppt_membership', 'mrt_ban' ), true ) ) {
			return;
		}
		if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
			return;
		}
		self::log( $key . ' = ' . ( is_scalar( $val ) ? $val : 'changed' ) . ' for user #' . (int) $uid );
	}

	public static function log_post( $new, $old, $post ) {
		if ( 'listing_type' !== $post->post_type || $new === $old || ! is_admin() ) {
			return;
		}
		self::log( 'Profile #' . $post->ID . ' ' . $old . ' to ' . $new );
	}

	/* ---------- extra pages ---------- */

	public static function make_pages() {
		if ( get_option( 'mrsh_growth_pages' ) || ! current_user_can( 'manage_options' ) || 'myrishta' !== get_template() ) {
			return;
		}
		$email = function_exists( 'mrt_site' ) ? mrt_site( 'email', '' ) : '';
		$mail  = $email ? ' at <a href="mailto:' . esc_attr( $email ) . '">' . esc_html( $email ) . '</a>' : ' through the contact page';
		$pages = array(
			'safe-meeting-guide' => array( 'Safe Meeting Guide | محفوظ ملاقات کی رہنمائی',
				'<p>A rishta meeting should always be family-led and in a public, safe place. Follow these steps.</p><ul><li>Tell your family where, when and with whom you are meeting.</li><li>Meet first in a public place, such as a family restaurant, with an elder present.</li><li>Do not send money, gifts, card or bank details before the families have met and verified each other.</li><li>Check the person through relatives, workplace or neighbours.</li><li>Never share your CNIC copy, OTP codes or passwords.</li><li>Report any profile that asks for money from the profile page.</li></ul><p dir="rtl" lang="ur">رشتے کی ملاقات ہمیشہ خاندان کے ساتھ اور کسی محفوظ عوامی جگہ پر کریں۔ ملاقات سے پہلے رقم، تحفے یا بینک کی معلومات ہرگز نہ بھیجیں۔ خاندان کو بتا کر جائیں، اور رشتہ داروں کے ذریعے تصدیق کریں۔ پیسے مانگنے والی پروفائل کی رپورٹ کریں۔</p>' ),
			'rishta-glossary'    => array( 'Rishta Glossary | رشتہ کی اصطلاحات',
				'<dl><dt><b>Rishta</b></dt><dd>A marriage proposal or match.</dd><dt><b>Wali</b></dt><dd>Guardian who represents the bride in marriage.</dd><dt><b>Nikah</b></dt><dd>The Islamic marriage contract.</dd><dt><b>Mehr</b></dt><dd>Gift due to the bride from the groom, agreed at the nikah.</dd><dt><b>Rukhsati</b></dt><dd>The bride\'s farewell and moving to the husband\'s home.</dd><dt><b>Istikhara</b></dt><dd>A prayer asking Allah for guidance in a decision.</dd><dt><b>Mangni</b></dt><dd>Engagement.</dd><dt><b>Walima</b></dt><dd>Wedding feast hosted by the groom\'s family.</dd></dl>' ),
			'volunteer'          => array( 'Become a Volunteer Matchmaker',
				'<p>Do you help families find suitable matches? We welcome honest, respectful volunteers. Tell us your city, your languages and how much time you can give' . $mail . '. Volunteers never receive private phone numbers and never take money from families.</p>' ),
			'share-your-story'   => array( 'Share Your Success Story', '<p>Did you find your rishta here? Tell others. We publish only stories with your permission after we read them.</p>[mrsh_story_form]' ),
		);
		foreach ( $pages as $slug => $p ) {
			if ( ! get_page_by_path( $slug ) ) {
				wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => $p[0], 'post_name' => $slug, 'post_content' => $p[1] ) );
			}
		}
		update_option( 'mrsh_growth_pages', 1, false );
	}

	/* ---------- success story submissions ---------- */

	public static function story_form() {
		if ( ! self::get( 'story_on' ) ) {
			return '';
		}
		$msg = isset( $_GET['story'] ) ? ( 'ok' === $_GET['story'] ? '<p class="note2">Thank you. We will read your story and publish it after approval.</p>' : '<p class="note2">Please fill in all fields and try again.</p>' ) : ''; // phpcs:ignore
		return $msg . '<form method="post" class="card2" style="padding:16px"><input type="hidden" name="mrsh_story" value="1"><input type="hidden" name="t0" value="' . time() . '"><p style="position:absolute;left:-9999px"><input type="text" name="website" tabindex="-1" autocomplete="off"></p>'
			. '<p><label>Your name<br><input type="text" name="sname" maxlength="60" required style="width:100%"></label></p><p><label>City<br><input type="text" name="scity" maxlength="40" required style="width:100%"></label></p>'
			. '<p><label>Your story (up to 400 characters)<br><textarea name="stext" rows="5" maxlength="400" required style="width:100%"></textarea></label></p><p><label><input type="checkbox" name="sok" value="1" required style="width:auto"> I allow My Rishta Pakistan to publish this story with my first name and city.</label></p><p><button class="btn">Send story</button></p></form>';
	}

	public static function story_post() {
		if ( empty( $_POST['mrsh_story'] ) || ! self::get( 'story_on' ) ) { // phpcs:ignore
			return;
		}
		$back = wp_get_referer() ? remove_query_arg( 'story', wp_get_referer() ) : home_url( '/' );
		$ip   = function_exists( 'mrt_ip' ) ? mrt_ip() : '0';
		$k    = 'mrsh_st_' . md5( $ip );
		$t0   = (int) ( $_POST['t0'] ?? 0 ); // phpcs:ignore
		$n    = sanitize_text_field( wp_unslash( $_POST['sname'] ?? '' ) ); // phpcs:ignore
		$c    = sanitize_text_field( wp_unslash( $_POST['scity'] ?? '' ) ); // phpcs:ignore
		$x    = sanitize_textarea_field( wp_unslash( $_POST['stext'] ?? '' ) ); // phpcs:ignore
		if ( ! empty( $_POST['website'] ) || time() - $t0 < 6 || (int) get_transient( $k ) >= 3 || ! $n || ! $c || ! $x || empty( $_POST['sok'] ) || preg_match( '#https?://|www\.|\d{9,}#i', $x ) ) { // phpcs:ignore
			wp_safe_redirect( add_query_arg( 'story', 'bad', $back ) );
			exit;
		}
		set_transient( $k, (int) get_transient( $k ) + 1, DAY_IN_SECONDS );
		$q   = (array) get_option( 'mrsh_story_q', array() );
		$q[] = array( 'n' => mb_substr( $n, 0, 60 ), 'c' => mb_substr( $c, 0, 40 ), 't' => mb_substr( $x, 0, 400 ), 'd' => time() );
		update_option( 'mrsh_story_q', array_slice( $q, -100 ), false );
		wp_safe_redirect( add_query_arg( 'story', 'ok', $back ) );
		exit;
	}

	public static function story_act() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_story_act' );
		$q = array_values( (array) get_option( 'mrsh_story_q', array() ) );
		$i = absint( $_POST['i'] ?? 0 ); // phpcs:ignore
		if ( isset( $q[ $i ] ) ) {
			if ( 'approve' === ( $_POST['do'] ?? '' ) ) { // phpcs:ignore
				$s            = (array) get_option( 'mrsh_site', array() );
				$s['stories'] = trim( ( $s['stories'] ?? '' ) . "\n" . str_replace( array( '|', "\n" ), ' ', $q[ $i ]['n'] . ', ' . $q[ $i ]['c'] ) . ' | ' . str_replace( array( "\r", "\n" ), ' ', $q[ $i ]['t'] ) );
				update_option( 'mrsh_site', $s, false );
				self::log( 'Story approved: ' . $q[ $i ]['n'] );
			}
			unset( $q[ $i ] );
			update_option( 'mrsh_story_q', array_values( $q ), false );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-growth&ok=1' ) );
		exit;
	}

	/* ---------- admin page ---------- */

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Growth tools', 'Growth tools', 'manage_options', 'mrsh-growth', array( __CLASS__, 'page' ) );
	}

	private static function weekly_counts( $table, $where, $col ) {
		global $wpdb;
		$out = array();
		for ( $i = 7; $i >= 0; $i-- ) {
			$from  = gmdate( 'Y-m-d', strtotime( '-' . ( $i + 1 ) . ' weeks' ) );
			$to    = gmdate( 'Y-m-d', strtotime( '-' . $i . ' weeks' ) );
			$out[] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE {$where} AND {$col} >= %s AND {$col} < %s", $from, $to ) ); // phpcs:ignore WordPress.DB
		}
		return $out;
	}

	private static function bars( $title, $data ) {
		$max = max( 1, max( $data ) );
		echo '<div style="background:#fff;border:1px solid #e3e3e8;border-radius:14px;padding:14px 16px;min-width:260px;flex:1"><b>' . esc_html( $title ) . '</b> <span class="description">8 weeks, total ' . (int) array_sum( $data ) . '</span><div style="display:flex;align-items:flex-end;gap:6px;height:90px;margin-top:10px">';
		foreach ( $data as $v ) {
			echo '<div title="' . (int) $v . '" style="flex:1;background:#e11d74;border-radius:6px 6px 0 0;height:' . max( 3, (int) round( $v / $max * 100 ) ) . '%;opacity:.85"></div>';
		}
		echo '</div></div>';
	}

	private static function checks() {
		$s   = function ( $k ) { return (bool) ( function_exists( 'mrt_site' ) && mrt_site( $k ) ); };
		$c   = array();
		$c[] = array( 'My Rishta theme is active', 'myrishta' === get_template() );
		$c[] = array( 'Pretty links are on (Settings > Permalinks)', (bool) get_option( 'permalink_structure' ) );
		$c[] = array( 'Site address uses https', 0 === strpos( home_url(), 'https://' ) );
		$c[] = array( 'Search engines allowed (Settings > Reading)', (bool) get_option( 'blog_public' ) );
		$ro  = class_exists( 'MRSH_Options' ) ? (array) MRSH_Options::get() : array();
		$c[] = array( 'Site icon (the built-in My Rishta icon is used until you upload your own)', (bool) get_site_icon_url( 512 ) || is_readable( MRSH_DIR . 'assets/favicon.svg' ) );
		$c[] = array( 'Logo (the built-in My Rishta logo is used until you upload your own)', $s( 'logo' ) || ! empty( $ro['org_logo'] ) );
		$c[] = array( 'Contact email set', $s( 'email' ) || is_email( $ro['org_email'] ?? '' ) || is_email( get_option( 'admin_email' ) ) );
		$c[] = array( 'WhatsApp number (skipped for now: waiting for Meta approval)', true );
		$c[] = array( 'Payment instructions written', $s( 'payinfo' ) );
		$c[] = array( 'Membership prices written by you', $s( 'plans' ) );
		$c[] = array( 'Success stories (none yet on a new site; real ones are added when members share them, none are invented)', true );
		$c[] = array( 'Push keys created (Notifications page)', (bool) get_option( 'mrsh_vapid' ) );
		$c[] = array( 'WordPress background tasks are running', ! ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) );
		foreach ( array( 'about-us', 'contact', 'memberships', 'blog', 'safe-meeting-guide' ) as $p ) {
			$c[] = array( 'Page exists: /' . $p . '/', (bool) get_page_by_path( $p ) );
		}
		return $c;
	}

	public static function page() {
		global $wpdb;
		$o = self::get();
		echo '<div class="wrap"><h1>Growth tools</h1>';
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success is-dismissible"><p>Done.</p></div>';
		}
		echo '<h2>Last 8 weeks</h2><div style="display:flex;gap:14px;flex-wrap:wrap">';
		self::bars( 'New members', self::weekly_counts( $wpdb->users, '1=1', 'user_registered' ) );
		self::bars( 'New profiles', self::weekly_counts( $wpdb->posts, "post_type='listing_type' AND post_status IN ('publish','pending','draft')", 'post_date' ) );
		self::bars( 'Messages', self::weekly_counts( $wpdb->posts, "post_type='ppt_message'", 'post_date' ) );
		echo '</div><h2>Settings</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_growth_save">';
		wp_nonce_field( 'mrsh_growth_save' );
		echo '<table class="form-table">';
		$chk = function ( $k, $l, $h ) use ( $o ) {
			echo '<tr><th>' . esc_html( $l ) . '</th><td><label><input type="checkbox" name="' . esc_attr( $k ) . '" value="1"' . checked( (int) $o[ $k ], 1, false ) . '> On</label> <span class="description">' . esc_html( $h ) . '</span></td></tr>';
		};
		echo '<tr><th>Free trial for new members</th><td><input type="number" name="trial_days" min="0" max="365" value="' . (int) $o['trial_days'] . '" style="width:80px"> days of plan <input type="text" name="trial_plan" value="' . esc_attr( $o['trial_plan'] ) . '" style="width:120px"> <span class="description">0 = no trial. The plan name must be one of your plans.</span></td></tr>';
		echo '<tr><th>Plan reminder</th><td><input type="number" name="warn_days" min="1" max="30" value="' . (int) $o['warn_days'] . '" style="width:80px"> days before a plan ends <span class="description">Set an end date on any member in Users > Edit.</span></td></tr>';
		$chk( 'alerts_on', 'Saved search alerts', 'Daily email when new profiles match a member\'s saved search.' );
		$chk( 'miss_on', '"We miss you" email', 'Monday email to members away for the days below. Once per 60 days each.' );
		echo '<tr><th>Away for</th><td><input type="number" name="miss_days" min="7" max="365" value="' . (int) $o['miss_days'] . '" style="width:80px"> days</td></tr>';
		$chk( 'ref_on', 'Invite links', 'Each member gets a link to invite friends.' );
		$chk( 'story_on', 'Success story form', 'Page /share-your-story/. Stories wait for your approval below.' );
		echo '</table><p><button class="button button-primary">Save</button></p></form><h2>Stories waiting for approval</h2>';
		$q = array_values( (array) get_option( 'mrsh_story_q', array() ) );
		if ( ! $q ) {
			echo '<p>None.</p>';
		}
		foreach ( $q as $i => $s ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="background:#fff;border:1px solid #e3e3e8;border-radius:12px;padding:10px 14px;margin:8px 0;max-width:680px"><input type="hidden" name="action" value="mrsh_story_act"><input type="hidden" name="i" value="' . (int) $i . '">';
			wp_nonce_field( 'mrsh_story_act' );
			echo '<b>' . esc_html( $s['n'] . ', ' . $s['c'] ) . '</b><p>' . esc_html( $s['t'] ) . '</p><button class="button button-primary" name="do" value="approve">Approve and publish</button> <button class="button" name="do" value="delete">Delete</button></form>';
		}
		echo '<h2>Site checklist</h2><table class="widefat striped" style="max-width:680px"><tbody>';
		foreach ( self::checks() as $c ) {
			echo '<tr><td style="width:36px;font-size:18px">' . ( $c[1] ? '&#9989;' : '&#9888;&#65039;' ) . '</td><td>' . esc_html( $c[0] ) . '</td></tr>';
		}
		echo '</tbody></table><h2>Top inviters</h2>';
		$top = $wpdb->get_results( "SELECT meta_value AS u, COUNT(*) AS n FROM {$wpdb->usermeta} WHERE meta_key='mrt_ref' GROUP BY meta_value ORDER BY n DESC LIMIT 10" ); // phpcs:ignore WordPress.DB
		if ( ! $top ) {
			echo '<p>No invites yet.</p>';
		} else {
			echo '<ol>';
			foreach ( $top as $t ) {
				$u = get_userdata( (int) $t->u );
				echo '<li>' . esc_html( $u ? $u->display_name : '#' . (int) $t->u ) . ': ' . (int) $t->n . '</li>';
			}
			echo '</ol>';
		}
		echo '<h2>Activity log</h2><table class="widefat striped" style="max-width:780px"><tbody>';
		$l = (array) get_option( 'mrsh_actlog', array() );
		if ( ! $l ) {
			echo '<tr><td>Nothing yet. Plan changes, verification changes and profile approvals appear here.</td></tr>';
		}
		foreach ( array_slice( $l, 0, 60 ) as $r ) {
			echo '<tr><td style="width:150px">' . esc_html( wp_date( 'j M Y H:i', (int) $r[0] ) ) . '</td><td style="width:100px">' . esc_html( $r[1] ) . '</td><td>' . esc_html( $r[2] ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_growth_save' );
		$n = array(
			'trial_days' => min( 365, absint( $_POST['trial_days'] ?? 0 ) ), // phpcs:ignore
			'trial_plan' => sanitize_text_field( wp_unslash( $_POST['trial_plan'] ?? '' ) ), // phpcs:ignore
			'warn_days'  => max( 1, min( 30, absint( $_POST['warn_days'] ?? 3 ) ) ), // phpcs:ignore
			'miss_days'  => max( 7, min( 365, absint( $_POST['miss_days'] ?? 30 ) ) ), // phpcs:ignore
		);
		foreach ( array( 'alerts_on', 'miss_on', 'ref_on', 'story_on' ) as $k ) {
			$n[ $k ] = empty( $_POST[ $k ] ) ? 0 : 1; // phpcs:ignore
		}
		update_option( 'mrsh_growth', $n, false );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-growth&ok=1' ) );
		exit;
	}
}
MRSH_Mem_Growth::init();
