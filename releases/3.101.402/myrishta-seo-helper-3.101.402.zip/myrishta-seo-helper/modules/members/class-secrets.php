<?php
/** Encrypts saved API keys, tokens and passwords with the site's AUTH_KEY (AES-256-GCM). Old plain values still read fine and are converted on the first run. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Secrets {

	const TAG = 'mrsec1:';

	public static function opts() {
		return array( 'mrsh_options', 'mrsh_smtp', 'mrsh_fb', 'mrsh_mobile', 'mrsh_social', 'mrsh_keys', 'mrsh_autoads', 'mrsh_ads_conn', 'mrsh_ads_ch', 'mrsh_site', 'mrsh_wa_cfg', 'mrads' );
	}

	public static function ok() {
		return defined( 'AUTH_KEY' ) && AUTH_KEY && function_exists( 'openssl_encrypt' ) && in_array( 'aes-256-gcm', openssl_get_cipher_methods(), true );
	}

	private static function key() {
		return hash( 'sha256', 'mrsh-secrets|' . AUTH_KEY, true );
	}

	public static function enc_str( $s ) {
		if ( ! self::ok() || ! is_string( $s ) || '' === $s || 0 === strpos( $s, self::TAG ) ) {
			return $s;
		}
		$iv  = random_bytes( 12 );
		$tag = '';
		$c   = openssl_encrypt( $s, 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, $iv, $tag, '', 16 );
		return false === $c ? $s : self::TAG . base64_encode( $iv . $tag . $c );
	}

	public static function dec_str( $s ) {
		if ( ! is_string( $s ) || 0 !== strpos( $s, self::TAG ) ) {
			return $s;
		}
		if ( ! self::ok() ) {
			return '';
		}
		$raw = base64_decode( substr( $s, strlen( self::TAG ) ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
		if ( false === $raw || strlen( $raw ) < 29 ) {
			return '';
		}
		$p = openssl_decrypt( substr( $raw, 28 ), 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, substr( $raw, 0, 12 ), substr( $raw, 12, 16 ) );
		return false === $p ? '' : $p;
	}

	/** Applies $fn to every string stored under a sensitive key name (secret, token, pass, key, ...). */
	public static function walk( $v, $fn, $sec = false ) {
		if ( is_array( $v ) ) {
			foreach ( $v as $k => $x ) {
				$s    = $sec || ( is_string( $k ) && preg_match( '/(secret|token|pass|key|pwd|sid|auth|cred)/i', $k ) );
				$v[ $k ] = self::walk( $x, $fn, $s );
			}
			return $v;
		}
		return ( $sec && is_string( $v ) ) ? call_user_func( $fn, $v ) : $v;
	}

	/** Encryption on write runs only when the Features switch is on (reading encrypted values always works). */
	public static function enabled() {
		return ! class_exists( 'MRSH_Feat' ) || MRSH_Feat::on( 'secrets' );
	}

	public static function init() {
		if ( ! self::ok() ) {
			return;
		}
		foreach ( self::opts() as $o ) {
			if ( self::enabled() ) {
				add_filter( 'pre_update_option_' . $o, function ( $v ) {
					return MRSH_Secrets::walk( $v, array( 'MRSH_Secrets', 'enc_str' ) );
				} );
				add_filter( 'pre_add_option_' . $o, function ( $v ) {
					return MRSH_Secrets::walk( $v, array( 'MRSH_Secrets', 'enc_str' ) );
				} );
			}
			add_filter( 'option_' . $o, function ( $v ) {
				return MRSH_Secrets::walk( $v, array( 'MRSH_Secrets', 'dec_str' ) );
			} );
		}
		if ( self::enabled() ) {
			add_action( 'init', array( __CLASS__, 'migrate' ), 99 );
		}
	}

	/** One-time: re-save existing options so their plain keys become encrypted. */
	public static function migrate() {
		if ( get_option( 'mrsh_secrets_v' ) === '1' ) {
			return;
		}
		foreach ( self::opts() as $o ) {
			$v = get_option( $o, null );
			if ( null !== $v ) {
				update_option( $o, $v );
			}
		}
		update_option( 'mrsh_secrets_v', '1', false );
	}
}

MRSH_Secrets::init();
