<?php
/**
 * Boost tools (3.101.34):
 *  1. Reports page: who reported which profile and why, with Pause / Restore / Dismiss. Red number on the tab.
 *  2. Founding members: the first members get a "Founding member" badge (automatic for the first N, or one button for those already in).
 *  3. Ad links: builds tracking links (source + campaign) for ads, counts visits and sign-ups per campaign,
 *     and creates two landing pages (for the family of a bride, for the family of a groom).
 * Options: mrsh_found (settings), mrsh_utm (counters). User meta: mrt_founding, mrt_utm_src, mrt_utm_camp.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Boost {

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 23 );
		add_action( 'admin_post_mrsh_rep_do', array( __CLASS__, 'rep_do' ) );
		add_action( 'admin_post_mrsh_found_save', array( __CLASS__, 'found_save' ) );
		add_action( 'admin_post_mrsh_found_mark', array( __CLASS__, 'found_mark' ) );
		add_action( 'admin_post_mrsh_land_make', array( __CLASS__, 'land_make' ) );
		add_action( 'user_register', array( __CLASS__, 'on_register' ), 20 );
		add_action( 'wp_footer', array( __CLASS__, 'utm_js' ), 99 );
		add_action( 'wp_ajax_nopriv_mrsh_utm', array( __CLASS__, 'utm_hit' ) );
		add_action( 'wp_ajax_mrsh_utm', array( __CLASS__, 'utm_hit' ) );
		add_shortcode( 'mrsh_landing', array( __CLASS__, 'landing' ) );
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Reports', 'Reports', 'manage_options', 'mrsh-reports', array( __CLASS__, 'page_reports' ) );
		add_submenu_page( 'myrishta-seo', 'Founding members', 'Founding members', 'manage_options', 'mrsh-founding', array( __CLASS__, 'page_found' ) );
		add_submenu_page( 'myrishta-seo', 'Ad links', 'Ad links', 'manage_options', 'mrsh-adlinks', array( __CLASS__, 'page_ads' ) );
	}

	/** Number of profiles with at least one report (red number on the Reports tab). */
	public static function report_count() {
		$q = new WP_Query( array( 'post_type' => 'listing_type', 'post_status' => array( 'publish', 'draft' ), 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => 'mrt_reports', 'meta_compare' => 'EXISTS', 'no_found_rows' => false ) );
		return (int) $q->found_posts;
	}

	/* ---------------- shared modern admin look (used by Reports, Founding, Ad links, Photo diagnosis) ---------------- */

	public static function ui_css() {
		return '
.mx{max-width:1100px;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Inter,sans-serif;color:#1f2937}
.mx *{box-sizing:border-box}
.mx .mx-hero{position:relative;overflow:hidden;display:flex;align-items:center;gap:18px;padding:24px 28px;margin:8px 0 18px;border-radius:24px;color:#fff;box-shadow:0 16px 36px rgba(60,50,150,.22);background:linear-gradient(135deg,#139a86 0,#4a69d6 55%,#7c3aed 100%)}
.mx .mx-hero.g-red{background:linear-gradient(135deg,#f97316 0,#e11d48 55%,#9d174d 100%)}
.mx .mx-hero.g-gold{background:linear-gradient(135deg,#f59e0b 0,#e11d74 60%,#7c3aed 100%)}
.mx .mx-hero.g-blue{background:linear-gradient(135deg,#0ea5e9 0,#4a69d6 55%,#7c3aed 100%)}
.mx .mx-hero:after{content:"";position:absolute;right:-70px;top:-80px;width:250px;height:250px;border-radius:50%;background:rgba(255,255,255,.13)}
.mx .mx-hero:before{content:"";position:absolute;right:80px;bottom:-90px;width:160px;height:160px;border-radius:50%;background:rgba(255,255,255,.09)}
.mx .mx-hero .ic{position:relative;z-index:1;flex:none;width:58px;height:58px;border-radius:18px;display:grid;place-items:center;background:rgba(255,255,255,.2);box-shadow:inset 0 0 0 1px rgba(255,255,255,.25)}
.mx .mx-hero .tx{position:relative;z-index:1;min-width:0}
.mx .mx-hero h1{margin:0;padding:0;color:#fff;font-size:26px;font-weight:700;letter-spacing:-.02em;line-height:1.2}
.mx .mx-hero p{margin:6px 0 0;color:rgba(255,255,255,.92);font-size:14.5px;line-height:1.5;max-width:660px}
.mx .mx-ok{display:flex;align-items:center;gap:10px;padding:12px 16px;margin:0 0 16px;border-radius:14px;background:#ecfdf5;color:#065f46;font-weight:600;box-shadow:0 0 0 1px #a7f3d0}
.mx .mx-card{background:#fff;border-radius:22px;padding:24px 26px;margin:0 0 18px;box-shadow:0 1px 3px rgba(17,24,39,.07),0 0 0 1px rgba(17,24,39,.04)}
.mx .mx-h{display:flex;align-items:center;gap:12px;margin:0 0 4px}
.mx .mx-h h2{margin:0;padding:0;font-size:18px;font-weight:700;letter-spacing:-.01em;color:#111827}
.mx .mx-n{flex:none;width:32px;height:32px;border-radius:50%;display:grid;place-items:center;color:#fff;font-weight:700;font-size:14px;background:linear-gradient(135deg,#e11d74,#7c3aed);box-shadow:0 4px 10px rgba(124,58,237,.3)}
.mx .mx-sub{margin:0 0 18px;color:#6b7280;font-size:14px;line-height:1.55;max-width:720px}
.mx .mx-card>.mx-sub:first-child{margin-top:0}
.mx .mx-h+.mx-sub{margin-left:44px}
.mx .mx-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:14px;margin:0 0 18px}
.mx .mx-stat{background:#fff;border-radius:20px;padding:18px 20px;box-shadow:0 1px 3px rgba(17,24,39,.07),0 0 0 1px rgba(17,24,39,.04);position:relative;overflow:hidden}
.mx .mx-stat:before{content:"";position:absolute;left:0;top:0;bottom:0;width:5px;background:var(--c,#7c3aed)}
.mx .mx-stat b{display:block;font-size:32px;line-height:1.1;letter-spacing:-.03em;color:#111827}
.mx .mx-stat span{display:block;margin-top:4px;color:#6b7280;font-size:13px;line-height:1.35}
.mx .mx-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px}
.mx .mx-f label.t{display:block;margin:0 0 7px;font-weight:600;font-size:13px;color:#374151}
.mx .mx-f select,.mx .mx-f input[type=text],.mx .mx-f input[type=password],.mx .mx-f input[type=number]{width:100%;max-width:100%;height:46px;padding:0 14px;border-radius:14px;border:1px solid #d9dbe8;background:#fff;font-size:14px}
.mx .mx-f .hint{display:block;margin-top:6px;color:#8a90a2;font-size:12.5px}
.mx .mx-chips{display:flex;flex-wrap:wrap;gap:8px}
.mx .mx-chip{position:relative;margin:0}
.mx .mx-chip input{position:absolute;opacity:0;width:1px;height:1px}
.mx .mx-chip span{display:inline-flex;align-items:center;gap:7px;padding:9px 16px;border-radius:99px;background:#f3f4fa;color:#4b5563;font-weight:600;font-size:13.5px;cursor:pointer;transition:all .15s;box-shadow:inset 0 0 0 1px #e6e8f3}
.mx .mx-chip span:before{content:"";width:9px;height:9px;border-radius:50%;background:var(--d,#9ca3af)}
.mx .mx-chip:hover span{background:#ede9fe}
.mx .mx-chip input:checked+span{background:#1f2937;color:#fff;box-shadow:0 6px 14px rgba(31,41,55,.28)}
.mx .mx-chip input:focus-visible+span{outline:3px solid rgba(124,58,237,.4);outline-offset:2px}
.mx .mx-link{display:flex;flex-wrap:wrap;gap:10px;align-items:stretch;margin-top:18px;padding:14px;border-radius:18px;background:linear-gradient(135deg,#f5f3ff,#fdf2f8);box-shadow:inset 0 0 0 1px #e9d5ff}
.mx .mx-link input{flex:1 1 260px;min-width:0;height:48px;border-radius:12px;border:1px solid #ddd6fe;background:#fff;padding:0 14px;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:13px;color:#4c1d95}
.mx .mx-link button{height:48px;padding:0 24px;border-radius:12px;border:0;cursor:pointer;color:#fff;font-weight:700;font-size:14px;background:linear-gradient(135deg,#e11d74,#7c3aed);box-shadow:0 8px 18px rgba(124,58,237,.3);transition:transform .12s,filter .15s}
.mx .mx-link button:hover{filter:brightness(.93);transform:translateY(-1px)}
.mx .mx-link button:active{transform:scale(.97)}
.mx .mx-msg{display:block;margin-top:8px;min-height:18px;color:#6b7280;font-size:13px}
.mx .mx-btn{display:inline-flex;align-items:center;gap:8px;height:44px;padding:0 22px;border-radius:13px;border:1px solid #d9dbe8;background:#fff;color:#374151;font-weight:700;font-size:14px;text-decoration:none;cursor:pointer;transition:all .15s}
.mx .mx-btn:hover{background:#f6f0ff;border-color:#c4a8f7;color:#7c3aed;transform:translateY(-1px)}
.mx .mx-btn.p{border:0;color:#fff;background:linear-gradient(135deg,#e11d74,#7c3aed);box-shadow:0 8px 18px rgba(124,58,237,.28)}
.mx .mx-btn.p:hover{color:#fff;filter:brightness(.93)}
.mx .mx-btn.s{height:36px;padding:0 15px;font-size:13px;border-radius:11px}
.mx .mx-btn.d{color:#b42318}.mx .mx-btn.d:hover{background:#fef3f2;border-color:#fda29b;color:#b42318}
.mx .mx-btn[disabled]{opacity:.55;pointer-events:none}
.mx .mx-acts{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.mx .mx-pill{display:inline-flex;align-items:center;gap:6px;padding:4px 11px;border-radius:99px;font-size:12px;font-weight:700;background:#f3f4f6;color:#4b5563}
.mx .mx-pill.ok{background:#dcfce7;color:#166534}.mx .mx-pill.bad{background:#fee2e2;color:#991b1b}.mx .mx-pill.warn{background:#fef3c7;color:#92400e}
.mx .mx-pill.src:before{content:"";width:8px;height:8px;border-radius:50%;background:var(--d,#9ca3af)}
.mx .mx-th,.mx .mx-row{display:grid;grid-template-columns:minmax(0,2.2fr) repeat(3,minmax(80px,1fr));gap:14px;align-items:center}
.mx .mx-th{padding:0 4px 10px;color:#8a90a2;font-size:11.5px;font-weight:700;text-transform:uppercase;letter-spacing:.06em}
.mx .mx-row{padding:15px 4px;border-top:1px solid #eef0f6}
.mx .mx-row .nm{min-width:0}.mx .mx-row .nm b{display:block;font-size:15px;color:#111827;overflow-wrap:anywhere}
.mx .mx-row .num{font-size:20px;font-weight:700;letter-spacing:-.02em}
.mx .mx-bar{height:7px;border-radius:99px;background:#eceef6;margin-top:7px;overflow:hidden}.mx .mx-bar i{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,#e11d74,#7c3aed)}
.mx .mx-empty{display:flex;flex-direction:column;align-items:center;text-align:center;gap:10px;padding:34px 16px;color:#6b7280}
.mx .mx-empty .bub{width:64px;height:64px;border-radius:50%;display:grid;place-items:center;background:linear-gradient(135deg,#ede9fe,#fce7f3);color:#7c3aed}
.mx .mx-empty b{font-size:16px;color:#374151}
.mx .mx-empty p{margin:0;max-width:460px;line-height:1.55}
.mx .mx-note{margin:14px 0 0;color:#8a90a2;font-size:12.5px}
.mx .mx-rep{display:flex;flex-wrap:wrap;gap:16px;align-items:center;justify-content:space-between;padding:18px 0;border-top:1px solid #eef0f6}
.mx .mx-rep:first-of-type{border-top:0}
.mx .mx-rep .who{min-width:0;flex:1 1 280px}
.mx .mx-rep .who a.t{font-size:16px;font-weight:700;color:#111827;text-decoration:none}
.mx .mx-rep .who a.t:hover{color:#7c3aed}
.mx .mx-rep .cnt{display:inline-grid;place-items:center;min-width:26px;height:26px;padding:0 8px;border-radius:99px;background:#fee2e2;color:#991b1b;font-weight:700;font-size:13px}
.mx .mx-rep .why{display:flex;flex-wrap:wrap;gap:6px;margin-top:9px}
.mx .mx-sw{display:flex;align-items:center;gap:14px;cursor:pointer;margin:0}
.mx .mx-sw input{position:absolute;opacity:0;width:1px;height:1px}
.mx .mx-sw .tr{flex:none;position:relative;width:52px;height:30px;border-radius:99px;background:#d1d5db;transition:background .2s}
.mx .mx-sw .tr:after{content:"";position:absolute;left:3px;top:3px;width:24px;height:24px;border-radius:50%;background:#fff;box-shadow:0 2px 5px rgba(0,0,0,.25);transition:transform .2s}
.mx .mx-sw input:checked+.tr{background:linear-gradient(135deg,#10b981,#139a86)}
.mx .mx-sw input:checked+.tr:after{transform:translateX(22px)}
.mx .mx-sw input:focus-visible+.tr{outline:3px solid rgba(124,58,237,.4);outline-offset:2px}
.mx .mx-sw .lb{font-weight:600;color:#374151;line-height:1.4}
.mx .mx-prog{max-width:560px;height:12px;border-radius:99px;background:#eceef6;overflow:hidden;margin-top:14px}
.mx .mx-prog i{display:block;height:100%;width:0;background:linear-gradient(90deg,#e11d74,#7c3aed);transition:width .2s}
.mx .mx-tabs{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:0 0 14px}
.mx .mx-tbl{overflow-x:auto;border-radius:16px;box-shadow:0 0 0 1px #eceef6}
.mx .mx-tbl table{border:0;box-shadow:none;border-radius:0;margin:0}
@media(max-width:700px){
.mx .mx-hero{padding:20px 18px;gap:14px;border-radius:20px}.mx .mx-hero h1{font-size:21px}.mx .mx-hero .ic{width:48px;height:48px}
.mx .mx-card{padding:20px 16px;border-radius:18px}.mx .mx-h+.mx-sub{margin-left:0}
.mx .mx-th{display:none}
.mx .mx-row{grid-template-columns:repeat(3,1fr)}.mx .mx-row .nm{grid-column:1/-1}
}
';
	}

	/** Opens the page wrapper with the colourful header. Close with "</div>" after the page content. */
	public static function ui_open( $title, $sub, $tone, $ico ) {
		echo '<div class="wrap mx"><style>' . self::ui_css() . '</style>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<div class="mx-hero ' . esc_attr( $tone ) . '"><span class="ic"><svg viewBox="0 0 24 24" width="28" height="28" fill="#fff" aria-hidden="true"><path d="' . esc_attr( $ico ) . '"/></svg></span><div class="tx"><h1>' . esc_html( $title ) . '</h1><p>' . esc_html( $sub ) . '</p></div></div><hr class="wp-header-end" style="display:none">';
	}

	public static function ui_ok( $msg ) {
		echo '<div class="mx-ok"><svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm-1.2 14.4-4-4 1.4-1.4 2.6 2.6 5-5 1.4 1.4z"/></svg>' . esc_html( $msg ) . '</div>';
	}

	public static function ui_stat( $n, $label, $color = '#7c3aed', $id = '' ) {
		return '<div class="mx-stat" style="--c:' . esc_attr( $color ) . '"><b' . ( $id ? ' id="' . esc_attr( $id ) . '"' : '' ) . '>' . esc_html( $n ) . '</b><span>' . esc_html( $label ) . '</span></div>';
	}

	/* ---------------- 1. reports ---------------- */

	public static function page_reports() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		self::ui_open( 'Reports', 'Profiles that members have reported, with the reason. Check each one, then pause it, restore it, or dismiss the reports.', 'g-red', 'M5 3h2v18H5zM8 4h11l-2.5 4L19 12H8z' );
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			self::ui_ok( 'Done.' );
		}
		$ps = get_posts( array( 'post_type' => 'listing_type', 'post_status' => array( 'publish', 'draft' ), 'numberposts' => 100, 'meta_key' => 'mrt_reports', 'meta_compare' => 'EXISTS' ) );
		$ps = array_filter( $ps, function ( $p ) {
			return count( array_filter( (array) get_post_meta( $p->ID, 'mrt_reports', true ) ) ) > 0;
		} );
		if ( ! $ps ) {
			echo '<div class="mx-card"><div class="mx-empty"><span class="bub"><svg viewBox="0 0 24 24" width="30" height="30" fill="currentColor" aria-hidden="true"><path d="M12 2 4 5v6c0 5 3.4 9.4 8 11 4.6-1.6 8-6 8-11V5zm-1.2 14.4-3.6-3.6 1.4-1.4 2.2 2.2 4.6-4.6 1.4 1.4z"/></svg></span><b>No reports waiting</b><p>When a member reports a profile, it appears here with the reason, so you can check it quickly.</p></div></div></div>';
			return;
		}
		$pause = 0;
		foreach ( $ps as $p ) {
			if ( 'publish' !== $p->post_status ) {
				$pause++;
			}
		}
		echo '<div class="mx-stats">' . self::ui_stat( count( $ps ), 'Profiles reported', '#e11d48' ) . self::ui_stat( count( $ps ) - $pause, 'Still live', '#f59e0b' ) . self::ui_stat( $pause, 'Paused', '#6b7280' ) . '</div>'; // phpcs:ignore
		echo '<div class="mx-card"><p class="mx-sub">A profile is paused automatically when it reaches the report limit in Member settings. If a profile is fine, press <b>Dismiss reports</b>.</p>';
		foreach ( $ps as $p ) {
			$n   = count( array_filter( (array) get_post_meta( $p->ID, 'mrt_reports', true ) ) );
			$why = array();
			foreach ( (array) get_post_meta( $p->ID, 'mrt_report_log', true ) as $l ) {
				$r         = isset( $l['r'] ) && '' !== $l['r'] ? $l['r'] : 'No reason given';
				$why[ $r ] = ( $why[ $r ] ?? 0 ) + 1;
			}
			$mk = function ( $do ) use ( $p ) {
				return esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_rep_do&pid=' . (int) $p->ID . '&do=' . $do ), 'mrsh_rep' . $p->ID ) );
			};
			$live = 'publish' === $p->post_status;
			echo '<div class="mx-rep"><div class="who"><a class="t" href="' . esc_url( get_permalink( $p ) ) . '" target="_blank" rel="noopener">' . esc_html( $p->post_title ) . '</a> <span class="mx-pill">#' . (int) $p->ID . '</span> <span class="mx-pill ' . ( $live ? 'ok' : 'warn' ) . '">' . ( $live ? 'Live' : 'Paused' ) . '</span> <span class="cnt" title="Reports">' . (int) $n . '</span>';
			echo '<div class="why">';
			if ( $why ) {
				foreach ( $why as $r => $c ) {
					echo '<span class="mx-pill bad">' . esc_html( $r ) . ' &times; ' . (int) $c . '</span>';
				}
			} else {
				echo '<span class="mx-pill">Reasons were not recorded for older reports</span>';
			}
			echo '</div></div><div class="mx-acts"><a class="mx-btn s" href="' . esc_url( get_edit_post_link( $p->ID ) ) . '">Open</a>';
			echo $live ? '<a class="mx-btn s d" href="' . $mk( 'pause' ) . '">Pause profile</a>' : '<a class="mx-btn s" href="' . $mk( 'restore' ) . '">Restore profile</a>'; // phpcs:ignore
			echo '<a class="mx-btn s p" href="' . $mk( 'dismiss' ) . '">Dismiss reports</a></div></div>'; // phpcs:ignore
		}
		echo '</div></div>';
	}

	public static function rep_do() {
		$pid = isset( $_GET['pid'] ) ? absint( $_GET['pid'] ) : 0; // phpcs:ignore
		$do  = isset( $_GET['do'] ) ? sanitize_key( wp_unslash( $_GET['do'] ) ) : ''; // phpcs:ignore
		if ( ! current_user_can( 'manage_options' ) || ! $pid || ! check_admin_referer( 'mrsh_rep' . $pid ) || 'listing_type' !== get_post_type( $pid ) ) {
			wp_die( 'Not allowed.' );
		}
		if ( 'pause' === $do ) {
			wp_update_post( array( 'ID' => $pid, 'post_status' => 'draft' ) );
		} elseif ( 'restore' === $do ) {
			wp_update_post( array( 'ID' => $pid, 'post_status' => 'publish' ) );
		} elseif ( 'dismiss' === $do ) {
			delete_post_meta( $pid, 'mrt_reports' );
			delete_post_meta( $pid, 'mrt_report_log' );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-reports&ok=1' ) );
		exit;
	}

	/* ---------------- 2. founding members ---------------- */

	private static function fset() {
		$o = get_option( 'mrsh_found', array() );
		return array_merge( array( 'on' => 1, 'n' => 100 ), is_array( $o ) ? $o : array() );
	}

	private static function found_total() {
		$q = new WP_User_Query( array( 'meta_key' => 'mrt_founding', 'meta_value' => '1', 'fields' => 'ID', 'number' => 1, 'count_total' => true ) );
		return (int) $q->get_total();
	}

	public static function on_register( $uid ) {
		$s = self::fset();
		if ( ! empty( $s['on'] ) && self::found_total() < (int) $s['n'] ) {
			update_user_meta( (int) $uid, 'mrt_founding', 1 );
		}
		// Which ad brought this member (cookie set by the tracking script).
		if ( ! empty( $_COOKIE['mrt_utm'] ) ) {
			$p = explode( '|', sanitize_text_field( wp_unslash( $_COOKIE['mrt_utm'] ) ) );
			$s2 = substr( preg_replace( '/[^a-z0-9_.\-]/i', '', (string) ( $p[0] ?? '' ) ), 0, 40 );
			$c2 = substr( preg_replace( '/[^a-z0-9_.\-]/i', '', (string) ( $p[1] ?? '' ) ), 0, 60 );
			if ( $c2 ) {
				update_user_meta( (int) $uid, 'mrt_utm_src', $s2 );
				update_user_meta( (int) $uid, 'mrt_utm_camp', $c2 );
				$u = (array) get_option( 'mrsh_utm', array() );
				$k = $s2 . '|' . $c2;
				$u[ $k ] = isset( $u[ $k ] ) && is_array( $u[ $k ] ) ? $u[ $k ] : array( 'v' => 0, 's' => 0 );
				$u[ $k ]['s'] = (int) $u[ $k ]['s'] + 1;
				update_option( 'mrsh_utm', $u, false );
			}
		}
	}

	public static function page_found() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s = self::fset();
		self::ui_open( 'Founding members', 'Early members get a Founding member badge on their profile card and page. It is a free thank-you for helping the site start.', 'g-gold', 'M12 2l2.9 6.3 6.9.7-5.2 4.6 1.5 6.8L12 17l-6.1 3.4 1.5-6.8L2.2 9l6.9-.7z' );
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			self::ui_ok( 'Saved.' );
		}
		$have = self::found_total();
		echo '<div class="mx-stats">' . self::ui_stat( $have, 'Members with the badge', '#f59e0b' ) . self::ui_stat( (int) $s['n'], 'Badges to give in total', '#7c3aed' ) . self::ui_stat( max( 0, (int) $s['n'] - $have ), 'Badges left', '#139a86' ) . '</div>'; // phpcs:ignore
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">1</span><h2>Automatic badge for new members</h2></div><p class="mx-sub">New members get the badge as they register, until the number below is reached.</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'mrsh_found_save' );
		echo '<input type="hidden" name="action" value="mrsh_found_save"><div class="mx-grid"><div class="mx-f"><label class="mx-sw"><input type="checkbox" name="on" value="1"' . checked( ! empty( $s['on'] ), true, false ) . '><span class="tr"></span><span class="lb">Give the badge automatically</span></label></div>';
		echo '<div class="mx-f"><label class="t" for="mxn">How many founding members</label><input type="number" id="mxn" name="n" min="1" max="5000" value="' . (int) $s['n'] . '"></div></div>';
		echo '<p style="margin:18px 0 0"><button class="mx-btn p">Save</button></p></form></div>';
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">2</span><h2>Give the badge to members already here</h2></div><p class="mx-sub">This gives the badge to the earliest registered members (not administrators), up to the number above. It never removes a badge.</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'mrsh_found_mark' );
		echo '<input type="hidden" name="action" value="mrsh_found_mark"><button class="mx-btn">Mark the first members now</button></form></div></div>';
	}


	public static function found_save() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'mrsh_found_save' ) ) {
			wp_die( 'Not allowed.' );
		}
		update_option( 'mrsh_found', array( 'on' => empty( $_POST['on'] ) ? 0 : 1, 'n' => max( 1, min( 5000, absint( $_POST['n'] ?? 100 ) ) ) ), false );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-founding&ok=1' ) );
		exit;
	}

	public static function found_mark() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'mrsh_found_mark' ) ) {
			wp_die( 'Not allowed.' );
		}
		$s   = self::fset();
		$ids = get_users( array( 'orderby' => 'registered', 'order' => 'ASC', 'number' => (int) $s['n'], 'fields' => 'ID', 'role__not_in' => array( 'administrator' ) ) );
		foreach ( $ids as $id ) {
			update_user_meta( (int) $id, 'mrt_founding', 1 );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-founding&ok=1' ) );
		exit;
	}

	/* ---------------- 3. ad links ---------------- */

	/** Runs in the visitor's browser, so page caches cannot hide a visit. */
	public static function utm_js() {
		if ( is_admin() || is_user_logged_in() ) {
			return;
		}
		?>
<script>
(function(){try{var q=new URLSearchParams(location.search),c=q.get('utm_campaign');if(!c)return;
var s=(q.get('utm_source')||'ad').replace(/[^a-z0-9_.\-]/gi,'').slice(0,40),k=c.replace(/[^a-z0-9_.\-]/gi,'').slice(0,60);if(!k)return;
var v=s+'|'+k,had=document.cookie.indexOf('mrt_utm='+encodeURIComponent(v))>-1;
document.cookie='mrt_utm='+encodeURIComponent(v)+';max-age=2592000;path=/;SameSite=Lax';
if(had)return;var f=new FormData();f.append('action','mrsh_utm');f.append('s',s);f.append('c',k);
if(navigator.sendBeacon){navigator.sendBeacon('<?php echo esc_js( admin_url( 'admin-ajax.php' ) ); ?>',f)}else{fetch('<?php echo esc_js( admin_url( 'admin-ajax.php' ) ); ?>',{method:'POST',body:f,keepalive:true})}}catch(e){}})();
</script>
		<?php
	}

	public static function utm_hit() {
		$s = substr( preg_replace( '/[^a-z0-9_.\-]/i', '', (string) ( $_POST['s'] ?? '' ) ), 0, 40 ); // phpcs:ignore
		$c = substr( preg_replace( '/[^a-z0-9_.\-]/i', '', (string) ( $_POST['c'] ?? '' ) ), 0, 60 ); // phpcs:ignore
		if ( $c ) {
			$u = (array) get_option( 'mrsh_utm', array() );
			if ( count( $u ) < 300 || isset( $u[ $s . '|' . $c ] ) ) {
				$k       = $s . '|' . $c;
				$u[ $k ] = isset( $u[ $k ] ) && is_array( $u[ $k ] ) ? $u[ $k ] : array( 'v' => 0, 's' => 0 );
				$u[ $k ]['v'] = (int) $u[ $k ]['v'] + 1;
				update_option( 'mrsh_utm', $u, false );
			}
		}
		wp_send_json_success();
	}

	private static function land_pages() {
		return array(
			'for-brides-families' => array( 'brides', 'Find a good rishta for your daughter' ),
			'for-grooms-families' => array( 'grooms', 'Find a good rishta for your son' ),
		);
	}

	public static function landing( $a ) {
		$a    = shortcode_atts( array( 'for' => 'brides' ), $a );
		$gr   = 'grooms' === $a['for'];
		$cta  = esc_url( function_exists( 'mrt_link' ) ? mrt_link( 'add-listing', '/add-listing/' ) : home_url( '/add-listing/' ) );
		$srch = esc_url( home_url( '/?post_type=listing_type&s=' ) );
		$t    = $gr ? 'Find a good rishta for your son' : 'Find a good rishta for your daughter';
		$s    = $gr ? 'Meet respectable Pakistani families looking for a suitable bride. Free, private and family friendly.' : 'Meet respectable Pakistani families looking for a suitable groom. Free, private and family friendly.';
		ob_start();
		?>
<section class="mrl" style="max-width:860px;margin:0 auto;padding:8px 0 24px">
<div style="padding:34px 26px;border-radius:26px;color:#fff;background:linear-gradient(145deg,#139a86 0,#4a69d6 56%,#7c3aed 100%);box-shadow:0 20px 50px rgba(60,40,120,.2)">
<h1 style="margin:0 0 10px;color:#fff;font-size:clamp(1.6rem,4.5vw,2.3rem);line-height:1.2"><?php echo esc_html( $t ); ?></h1>
<p style="margin:0 0 20px;font-size:1.05rem;color:rgba(255,255,255,.92)"><?php echo esc_html( $s ); ?></p>
<p style="margin:0;display:flex;flex-wrap:wrap;gap:10px"><a href="<?php echo $cta; // phpcs:ignore ?>" style="display:inline-block;padding:14px 24px;border-radius:15px;background:#fff;color:#4a2fb0;font-weight:700;text-decoration:none">Create a free profile</a><a href="<?php echo $srch; // phpcs:ignore ?>" style="display:inline-block;padding:14px 24px;border-radius:15px;border:2px solid rgba(255,255,255,.7);color:#fff;font-weight:700;text-decoration:none">Browse profiles</a></p>
</div>
<ul style="list-style:none;margin:22px 0 0;padding:0;display:grid;gap:12px;grid-template-columns:repeat(auto-fit,minmax(230px,1fr))">
<li style="padding:18px;border:1px solid #e6e1f0;border-radius:18px;background:#fff;color:#2b2433"><b>Free for every family</b><br>No fees to join, message or search. We are a non-profit service.</li>
<li style="padding:18px;border:1px solid #e6e1f0;border-radius:18px;background:#fff;color:#2b2433"><b>Your phone stays private</b><br>Phone numbers are never shown. Families agree to share them.</li>
<li style="padding:18px;border:1px solid #e6e1f0;border-radius:18px;background:#fff;color:#2b2433"><b>Checked by our team</b><br>Profiles are reviewed, and members can report anything wrong.</li>
</ul>
<p style="margin:20px 0 0;color:#667085;font-size:.95rem">Always meet with your family, verify details yourself, and never send money to someone you meet online.</p>
</section>
		<?php
		return (string) ob_get_clean();
	}

	public static function land_make() {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'mrsh_land_make' ) ) {
			wp_die( 'Not allowed.' );
		}
		foreach ( self::land_pages() as $slug => $d ) {
			if ( get_page_by_path( $slug ) ) {
				continue;
			}
			wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => $d[1], 'post_name' => $slug, 'post_content' => '[mrsh_landing for="' . $d[0] . '"]' ) );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-adlinks&ok=1' ) );
		exit;
	}

	public static function page_ads() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$dest = array(
			'Home page'                          => home_url( '/' ),
			'Create a profile'                   => function_exists( 'mrt_link' ) ? mrt_link( 'add-listing', '/add-listing/' ) : home_url( '/add-listing/' ),
			'Memberships'                        => function_exists( 'mrt_link' ) ? mrt_link( 'memberships', '/memberships/' ) : home_url( '/memberships/' ),
			'Landing page: family of a bride'    => home_url( '/for-brides-families/' ),
			'Landing page: family of a groom'    => home_url( '/for-grooms-families/' ),
		);
		$src = array( 'facebook' => '#1877f2', 'instagram' => '#e1306c', 'google' => '#34a853', 'youtube' => '#ff0000', 'whatsapp' => '#25d366', 'tiktok' => '#111827', 'other' => '#6b7280' );
		self::ui_open( 'Ad links', 'Make a tracking link for each ad, so you can see which ad brings real visitors and real sign-ups. Use the link as the ad destination.', '', 'M10.6 13.4a1 1 0 0 1 0-1.4l3-3a3 3 0 1 1 4.2 4.2l-1.5 1.5-1.4-1.4 1.5-1.5a1 1 0 0 0-1.4-1.4l-3 3a1 1 0 0 1-1.4 0zM13.4 10.6a1 1 0 0 1 0 1.4l-3 3a3 3 0 1 1-4.2-4.2l1.5-1.5 1.4 1.4-1.5 1.5a1 1 0 0 0 1.4 1.4l3-3a1 1 0 0 1 1.4 0z' );
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			self::ui_ok( 'Done.' );
		}

		// 1. landing pages
		$have = true;
		foreach ( array_keys( self::land_pages() ) as $sl ) {
			$have = $have && (bool) get_page_by_path( $sl );
		}
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">1</span><h2>Landing pages</h2></div><p class="mx-sub">Two simple pages made for ads: one speaks to the family of a bride, one to the family of a groom.</p>';
		if ( $have ) {
			echo '<div class="mx-acts"><span class="mx-pill ok">Both pages are ready</span><a class="mx-btn s" href="' . esc_url( $dest['Landing page: family of a bride'] ) . '" target="_blank" rel="noopener">View bride page</a><a class="mx-btn s" href="' . esc_url( $dest['Landing page: family of a groom'] ) . '" target="_blank" rel="noopener">View groom page</a></div>';
		} else {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( 'mrsh_land_make' );
			echo '<input type="hidden" name="action" value="mrsh_land_make"><button class="mx-btn p">Create the two landing pages</button></form>';
		}
		echo '</div>';

		// 2. link builder
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">2</span><h2>Make a tracking link</h2></div><p class="mx-sub">Choose where the ad goes, where it will run, and give the campaign a short name. The link is made as you type.</p>';
		echo '<div class="mx-grid"><div class="mx-f"><label class="t" for="mrad-d">Where should the ad go</label><select id="mrad-d">';
		foreach ( $dest as $l => $u ) {
			echo '<option value="' . esc_attr( $u ) . '">' . esc_html( $l ) . '</option>';
		}
		echo '</select></div><div class="mx-f"><label class="t" for="mrad-c">Campaign name</label><input type="text" id="mrad-c" value="" placeholder="for example brides-lahore-nov" autocomplete="off"><span class="hint">Letters, numbers and dashes. No spaces.</span></div></div>';
		echo '<div class="mx-f" style="margin-top:16px"><label class="t">Where will the ad run</label><div class="mx-chips" id="mrad-s">';
		$first = true;
		foreach ( $src as $k => $c ) {
			echo '<label class="mx-chip" style="--d:' . esc_attr( $c ) . '"><input type="radio" name="mrad-src" value="' . esc_attr( $k ) . '"' . ( $first ? ' checked' : '' ) . '><span>' . esc_html( ucfirst( $k ) ) . '</span></label>';
			$first = false;
		}
		echo '</div></div>';
		echo '<div class="mx-link"><input type="text" id="mrad-out" readonly placeholder="Your tracking link appears here" aria-label="Tracking link"><button type="button" id="mrad-copy">Copy link</button></div><span id="mrad-msg" class="mx-msg"></span></div>';

		// 3. results
		$u = (array) get_option( 'mrsh_utm', array() );
		echo '<div class="mx-card"><div class="mx-h"><span class="mx-n">3</span><h2>Results</h2></div><p class="mx-sub">A sign-up counts when the visitor from an ad creates an account within 30 days.</p>';
		if ( ! $u ) {
			echo '<div class="mx-empty"><span class="bub"><svg viewBox="0 0 24 24" width="30" height="30" fill="currentColor" aria-hidden="true"><path d="M4 20V10h4v10zm6 0V4h4v16zm6 0v-7h4v7z"/></svg></span><b>No visits yet</b><p>Numbers appear here after someone opens a tracking link.</p></div>';
		} else {
			uasort( $u, function ( $a, $b ) {
				return (int) ( $b['v'] ?? 0 ) <=> (int) ( $a['v'] ?? 0 );
			} );
			$tv = 0;
			$ts = 0;
			foreach ( $u as $r ) {
				$tv += (int) ( $r['v'] ?? 0 );
				$ts += (int) ( $r['s'] ?? 0 );
			}
			echo '<div class="mx-stats">' . self::ui_stat( number_format_i18n( $tv ), 'Visits from ads', '#4a69d6' ) . self::ui_stat( number_format_i18n( $ts ), 'Sign-ups from ads', '#e11d74' ) . self::ui_stat( $tv ? round( $ts / $tv * 100, 1 ) . '%' : '-', 'Sign-up rate', '#139a86' ) . '</div>'; // phpcs:ignore
			echo '<div class="mx-th"><span>Ad</span><span>Visits</span><span>Sign-ups</span><span>Sign-up rate</span></div>';
			foreach ( $u as $k => $r ) {
				$v    = (int) ( $r['v'] ?? 0 );
				$s    = (int) ( $r['s'] ?? 0 );
				$pr   = explode( '|', (string) $k, 2 );
				$sk   = $pr[0] ?? '';
				$cm   = $pr[1] ?? $k;
				$rate = $v ? min( 100, $s / $v * 100 ) : 0;
				echo '<div class="mx-row"><div class="nm"><b>' . esc_html( $cm ) . '</b><span class="mx-pill src" style="--d:' . esc_attr( $src[ $sk ] ?? '#9ca3af' ) . ';margin-top:5px">' . esc_html( $sk ?: 'ad' ) . '</span></div><div class="num">' . (int) $v . '</div><div class="num">' . (int) $s . '</div><div><span class="num">' . ( $v ? esc_html( round( $s / $v * 100, 1 ) . '%' ) : '-' ) . '</span><div class="mx-bar"><i style="width:' . (float) round( $rate, 1 ) . '%"></i></div></div></div>';
			}
		}
		echo '<p class="mx-note">Visitors who block scripts or cookies are not counted, so real numbers are a little higher.</p></div>';
		?>
<script>
(function(){var d=document.getElementById('mrad-d'),c=document.getElementById('mrad-c'),o=document.getElementById('mrad-out'),b=document.getElementById('mrad-copy'),m=document.getElementById('mrad-msg'),rs=[].slice.call(document.querySelectorAll('input[name=mrad-src]'));
function src(){for(var i=0;i<rs.length;i++){if(rs[i].checked)return rs[i].value}return 'other'}
function mk(){var k=c.value.trim().toLowerCase().replace(/[^a-z0-9\-_.]+/g,'-').replace(/^-+|-+$/g,'');if(!k){o.value='';return}
o.value=d.value+(d.value.indexOf('?')>-1?'&':'?')+'utm_source='+encodeURIComponent(src())+'&utm_medium=ad&utm_campaign='+encodeURIComponent(k)}
[d,c].concat(rs).forEach(function(e){e.addEventListener('input',mk);e.addEventListener('change',mk)});
b.onclick=function(){if(!o.value){m.textContent='Type a campaign name first.';c.focus();return}o.select();var ok=false;try{ok=document.execCommand('copy')}catch(e){}
if(navigator.clipboard){navigator.clipboard.writeText(o.value).then(function(){m.textContent='Copied. Paste it as the ad destination.'},function(){m.textContent=ok?'Copied. Paste it as the ad destination.':'Select the link and copy it.'})}else{m.textContent=ok?'Copied. Paste it as the ad destination.':'Select the link and copy it.'}}})();
</script>
</div>
		<?php
	}
}
MRSH_Boost::init();
