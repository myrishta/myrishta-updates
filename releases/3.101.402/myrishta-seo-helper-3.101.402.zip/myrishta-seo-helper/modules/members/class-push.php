<?php
/**
 * Push notifications (web push, VAPID). A member turns them on from My account; when something new happens
 * (message, interest, wink, phone request, gift) their phone or browser shows an alert, even when the site is closed.
 * The alert carries no private text: the service worker asks the site what is new when the alert arrives.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Mem_Push {

	public static function init() {
		add_action( 'wp_ajax_mrt_push_sub', array( __CLASS__, 'subscribe' ) );
		add_action( 'wp_ajax_mrt_notif', array( __CLASS__, 'notif' ) );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 22 );
		add_action( 'admin_post_mrsh_push_test', array( __CLASS__, 'test' ) );
	}

	private static function b64( $s ) {
		return rtrim( strtr( base64_encode( $s ), '+/', '-_' ), '=' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
	}

	/** Server key pair, created once. Returns array( public key (base64url), private key (PEM) ) or array(). */
	private static function keys() {
		$k = get_option( 'mrsh_vapid' );
		if ( is_array( $k ) && ! empty( $k['pub'] ) && ! empty( $k['pem'] ) ) {
			return $k;
		}
		if ( ! function_exists( 'openssl_pkey_new' ) ) {
			return array();
		}
		$res = openssl_pkey_new( array( 'curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC ) );
		if ( ! $res ) {
			return array();
		}
		openssl_pkey_export( $res, $pem );
		$d = openssl_pkey_get_details( $res );
		if ( empty( $d['ec']['x'] ) || empty( $d['ec']['y'] ) || ! $pem ) {
			return array();
		}
		$pub = "\x04" . str_pad( $d['ec']['x'], 32, "\0", STR_PAD_LEFT ) . str_pad( $d['ec']['y'], 32, "\0", STR_PAD_LEFT );
		$k   = array( 'pub' => self::b64( $pub ), 'pem' => $pem );
		update_option( 'mrsh_vapid', $k, false );
		return $k;
	}

	public static function public_key() {
		$k = self::keys();
		return $k ? $k['pub'] : '';
	}

	/** Only the known browser push services are accepted as destinations. */
	private static function allowed( $url ) {
		$p = wp_parse_url( $url );
		return ! empty( $p['scheme'] ) && 'https' === $p['scheme'] && ! empty( $p['host'] ) && preg_match( '/(^|\.)(googleapis\.com|mozilla\.com|mozaws\.net|apple\.com|windows\.com|microsoft\.com)$/i', $p['host'] );
	}

	public static function subscribe() {
		check_ajax_referer( 'mrt', 'n' );
		$uid = get_current_user_id();
		if ( ! $uid ) {
			wp_send_json( array( 'ok' => false, 'msg' => 'Please log in first.' ) );
		}
		$s = json_decode( isset( $_POST['sub'] ) ? wp_unslash( $_POST['sub'] ) : '', true ); // phpcs:ignore
		$e = is_array( $s ) && ! empty( $s['endpoint'] ) ? esc_url_raw( (string) $s['endpoint'] ) : '';
		if ( ! $e || ! self::allowed( $e ) ) {
			wp_send_json( array( 'ok' => false, 'msg' => 'This browser cannot receive notifications.' ) );
		}
		$list = array_values( array_filter( (array) get_user_meta( $uid, 'mrt_push', true ) ) );
		if ( ! in_array( $e, $list, true ) ) {
			$list[] = $e;
		}
		update_user_meta( $uid, 'mrt_push', array_slice( $list, -5 ) );
		wp_send_json( array( 'ok' => true, 'msg' => 'Notifications are on for this device.' ) );
	}

	/** What the alert should say (asked by the service worker when a push arrives). */
	public static function notif() {
		$uid = get_current_user_id();
		$n   = $uid && class_exists( 'MRSH_Members' ) ? (int) MRSH_Members::unread_count( $uid ) : 0;
		$url = function_exists( 'mrt_login_url' ) ? add_query_arg( 'tab', 'messages', mrt_login_url() ) : home_url( '/my-account/' );
		wp_send_json( array(
			'title' => get_bloginfo( 'name' ),
			'body'  => $n > 0 ? sprintf( _n( 'You have %d unread message.', 'You have %d unread messages.', $n, 'myrishta-seo-helper' ), $n ) : 'You have new activity on your profile.',
			'url'   => $url,
		) );
	}

	/** Tell a member's devices that something new happened. At most one alert every two minutes per member. */
	public static function ping( $uid, $kind = '' ) {
		$uid = (int) $uid;
		if ( ! $uid || get_transient( 'mrsh_pp_' . $uid ) ) {
			return 0;
		}
		$list = array_values( array_filter( (array) get_user_meta( $uid, 'mrt_push', true ) ) );
		if ( ! $list ) {
			return 0;
		}
		set_transient( 'mrsh_pp_' . $uid, 1, 120 );
		$ok   = 0;
		$keep = array();
		foreach ( $list as $e ) {
			$code = self::push( $e );
			if ( 404 === $code || 410 === $code ) {
				continue; // device removed its permission
			}
			$keep[] = $e;
			if ( $code >= 200 && $code < 300 ) {
				$ok++;
			}
		}
		if ( count( $keep ) !== count( $list ) ) {
			update_user_meta( $uid, 'mrt_push', $keep );
		}
		return $ok;
	}

	/** One empty push to one device, signed with our key. Returns the HTTP status (0 on failure). */
	private static function push( $endpoint ) {
		$k = self::keys();
		if ( ! $k || ! self::allowed( $endpoint ) ) {
			return 0;
		}
		$p   = wp_parse_url( $endpoint );
		$aud = $p['scheme'] . '://' . $p['host'] . ( ! empty( $p['port'] ) ? ':' . $p['port'] : '' );
		$in  = self::b64( wp_json_encode( array( 'typ' => 'JWT', 'alg' => 'ES256' ) ) ) . '.' . self::b64( wp_json_encode( array( 'aud' => $aud, 'exp' => time() + 12 * HOUR_IN_SECONDS, 'sub' => 'mailto:' . get_option( 'admin_email' ) ) ) );
		if ( ! openssl_sign( $in, $der, $k['pem'], OPENSSL_ALGO_SHA256 ) ) {
			return 0;
		}
		$raw = self::der_to_raw( $der );
		if ( ! $raw ) {
			return 0;
		}
		$r = wp_remote_post( $endpoint, array(
			'timeout' => 8,
			'body'    => '',
			'headers' => array( 'Authorization' => 'vapid t=' . $in . '.' . self::b64( $raw ) . ', k=' . $k['pub'], 'TTL' => '86400', 'Urgency' => 'normal', 'Content-Length' => '0' ),
		) );
		return is_wp_error( $r ) ? 0 : (int) wp_remote_retrieve_response_code( $r );
	}

	/** An ECDSA signature from OpenSSL (DER) as the 64 plain bytes a web push service expects. */
	private static function der_to_raw( $der ) {
		if ( strlen( $der ) < 8 || "\x30" !== $der[0] ) {
			return '';
		}
		$i = 2;
		if ( ord( $der[1] ) & 0x80 ) {
			$i = 2 + ( ord( $der[1] ) & 0x7f );
		}
		$out = '';
		for ( $n = 0; $n < 2; $n++ ) {
			if ( ! isset( $der[ $i + 1 ] ) || "\x02" !== $der[ $i ] ) {
				return '';
			}
			$len = ord( $der[ $i + 1 ] );
			$v   = substr( $der, $i + 2, $len );
			$v   = ltrim( $v, "\0" );
			$out .= str_pad( $v, 32, "\0", STR_PAD_LEFT );
			$i   += 2 + $len;
		}
		return 64 === strlen( $out ) ? $out : '';
	}

	/* ---------- admin ---------- */
	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Notifications', 'Notifications', 'manage_options', 'mrsh-push', array( __CLASS__, 'page' ) );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$n = count( get_users( array( 'meta_key' => 'mrt_push', 'meta_compare' => 'EXISTS', 'fields' => 'ID', 'number' => 5000 ) ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		echo '<div class="wrap"><h1>Push notifications</h1><p>Members turn notifications on from My account. They then get an alert on their phone or browser for new messages and interests. No private text is sent in the alert.</p>';
		if ( isset( $_GET['t'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-info"><p>' . ( '0' === $_GET['t'] ? 'No device is subscribed on your own account yet, or the alert could not be sent. Open My account on your phone, press Turn on notifications, then try again.' : 'Test alert sent to ' . (int) $_GET['t'] . ' device(s).' ) . '</p></div>'; // phpcs:ignore
		}
		echo '<p>Members with notifications on: <b>' . (int) $n . '</b>. Key: ' . ( self::public_key() ? '<b>ready</b>' : '<b style="color:#b32d2e">not available (PHP OpenSSL is missing)</b>' ) . '.</p>';
		echo '<p><a class="button button-primary" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_push_test' ), 'mrsh_push_test' ) ) . '">Send a test alert to my devices</a></p>';
		echo '<p class="description">iPhone and iPad: notifications work only after the member adds the site to the Home Screen (the My Rishta app). Android and computers work in the browser. The site must use HTTPS.</p></div>';
	}

	public static function test() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_push_test' );
		delete_transient( 'mrsh_pp_' . get_current_user_id() );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-push&t=' . (int) self::ping( get_current_user_id(), 'test' ) ) );
		exit;
	}
}
MRSH_Mem_Push::init();
