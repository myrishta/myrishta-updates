<?php
/**
 * Members: wink, shortlist (favourites), express interest, messages, profile form, matches.
 * Uses the same data the old theme used (post meta "winks", user meta "favorite", post type ppt_message with sender_id /
 * reciever_id / msg_stick / msg_status, profile fields from option "cfields"), so existing members and messages keep working.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Members {

	const CPT = 'listing_type';
	const MSG = 'ppt_message';

	public static function init() {
		add_action( 'wp_ajax_mrt_act', array( __CLASS__, 'ajax' ) );
		add_action( 'wp_ajax_mrt_geo', array( __CLASS__, 'geo' ) );
		add_action( 'wp_ajax_mrt_cities', array( __CLASS__, 'cities' ) );
		add_action( 'admin_post_mrt_save_profile', array( __CLASS__, 'save_profile' ) );
		add_action( 'admin_post_nopriv_mrt_signup', array( __CLASS__, 'signup' ) );
		add_action( 'admin_post_mrt_signup', array( __CLASS__, 'signup' ) );
		add_action( 'admin_post_mrt_myplan', array( __CLASS__, 'my_plan' ) );
		add_action( 'admin_post_mrt_phone', array( __CLASS__, 'phone_answer' ) );
		add_action( 'admin_post_mrt_pause_profile', array( __CLASS__, 'pause_profile' ) );
	}

	/* ---------- helpers ---------- */

	private static function limit( $act, $max ) {
		$k = 'mrt_lim_' . $act . '_' . get_current_user_id() . '_' . gmdate( 'Ymd' );
		$n = (int) get_transient( $k );
		if ( $n >= $max ) {
			return false;
		}
		set_transient( $k, $n + 1, DAY_IN_SECONDS );
		return true;
	}

	/** Who is doing what in the current ajax call, so the activity log can record it (see MRSH_Act). */
	private static $ctx = array();

	private static function out( $ok, $msg, $extra = array() ) {
		if ( self::$ctx ) {
			do_action( 'mrsh_member_act', self::$ctx, (bool) $ok, (string) $msg );
		}
		wp_send_json( array_merge( array( 'ok' => (bool) $ok, 'msg' => $msg ), $extra ) );
	}

	/** The member's own profile post (any status) or null. */
	public static function my_profile( $uid = 0 ) {
		$uid = $uid ? $uid : get_current_user_id();
		if ( ! $uid ) {
			return null;
		}
		$q = get_posts( array( 'post_type' => self::CPT, 'author' => $uid, 'post_status' => array( 'publish', 'draft', 'pending', 'pending_approval', 'payment', 'expired' ), 'numberposts' => 1, 'orderby' => 'ID', 'order' => 'ASC' ) );
		return $q ? $q[0] : null;
	}

	/* ---------- ajax: wink / fav / interest / msg ---------- */

	public static function ajax() {
		check_ajax_referer( 'mrt', 'n' );
		$uid = get_current_user_id();
		if ( ! $uid ) {
			self::out( false, 'Please log in first.' );
		}
		$act = isset( $_POST['act'] ) ? sanitize_key( wp_unslash( $_POST['act'] ) ) : '';
		$pid = isset( $_POST['pid'] ) ? absint( $_POST['pid'] ) : 0;
		$p   = $pid ? get_post( $pid ) : null;
		if ( ! $p || self::CPT !== $p->post_type || 'publish' !== $p->post_status ) {
			self::out( false, 'Profile not found.' );
		}
		$to = (int) $p->post_author;
		self::$ctx = array( 'uid' => $uid, 'act' => $act, 'pid' => $pid, 'to' => $to );

		if ( 'fav' === $act ) {
			$list = get_user_meta( $uid, 'favorite', true );
			$list = is_array( $list ) ? $list : array();
			if ( in_array( $pid, $list, true ) || in_array( (string) $pid, $list, true ) ) {
				$list = array_values( array_diff( array_map( 'intval', $list ), array( $pid ) ) );
				update_user_meta( $uid, 'favorite', $list );
				self::out( true, 'Removed from your shortlist.', array( 'state' => 0 ) );
			}
			if ( count( $list ) >= 300 ) {
				self::out( false, 'Your shortlist is full.' );
			}
			$list[] = $pid;
			update_user_meta( $uid, 'favorite', array_values( array_unique( array_map( 'intval', $list ) ) ) );
			self::out( true, 'Saved to your shortlist.', array( 'state' => 1 ) );
		}

		if ( $to === $uid || ! $to ) {
			self::out( false, 'This is your own profile.' );
		}
		if ( in_array( $uid, (array) get_user_meta( $to, 'blocked', true ), true ) ) {
			self::out( false, 'You cannot contact this member.' );
		}

		if ( 'hit' === $act || 'miss' === $act ) {
			$h         = get_post_meta( $pid, 'mrt_rate', true );
			$h         = is_array( $h ) ? $h : array();
			$h[ $uid ] = 'hit' === $act ? 1 : 0;
			update_post_meta( $pid, 'mrt_rate', $h );
			self::out( true, 'hit' === $act ? 'Marked as Hit.' : 'Marked as Miss.', array( 'hits' => count( array_filter( $h ) ), 'state' => (int) $h[ $uid ] ) );
		}
		if ( 'gift' === $act ) {
			$gl = array( 'rose' => 'a rose', 'heart' => 'a heart', 'cake' => 'a cake', 'dua' => 'a dua', 'star' => 'a star', 'ring' => 'a ring' );
			$g  = isset( $_POST['gift'] ) ? sanitize_key( wp_unslash( $_POST['gift'] ) ) : '';
			if ( ! isset( $gl[ $g ] ) ) {
				self::out( false, 'Choose a gift.' );
			}
			if ( ! self::limit( 'gift', (int) MRSH_Manage::get()['maxgift'] ) ) {
				self::out( false, 'Daily gift limit reached. Try again tomorrow.' );
			}
			$gs   = get_post_meta( $pid, 'mrt_gifts', true );
			$gs   = is_array( $gs ) ? $gs : array();
			$gs[] = array( 'from' => $uid, 'gift' => $g, 'date' => current_time( 'mysql' ) );
			update_post_meta( $pid, 'mrt_gifts', array_slice( $gs, -200 ) );
			self::notify( $to, 'gift' );
			self::out( true, 'You sent ' . $gl[ $g ] . '.', array( 'gifts' => count( $gs ) ) );
		}
		if ( 'phonereq' === $act ) {
			$r = get_post_meta( $pid, 'mrt_phone_req', true );
			$r = is_array( $r ) ? $r : array();
			if ( isset( $r[ $uid ] ) ) {
				self::out( true, 'You already asked. You will be notified if it is approved.' );
			}
			if ( ! self::limit( 'phonereq', 10 ) ) {
				self::out( false, 'Daily limit reached. Try again tomorrow.' );
			}
			$r[ $uid ] = 'pending';
			update_post_meta( $pid, 'mrt_phone_req', $r );
			self::notify( $to, 'phone' );
			self::out( true, 'Request sent. The family will decide whether to share the number.' );
		}

		if ( 'wink' === $act ) {
			$w = get_post_meta( $pid, 'winks', true );
			$w = is_array( $w ) ? $w : array();
			if ( isset( $w[ $uid ] ) ) {
				self::out( true, 'You already winked at this profile.' );
			}
			if ( ! self::limit( 'wink', (int) MRSH_Manage::get()['wink'] ) ) {
				self::out( false, 'Daily limit reached. Try again tomorrow.' );
			}
			$w[ $uid ] = array( 'to' => $to, 'from' => $uid, 'date' => current_time( 'mysql' ) );
			update_post_meta( $pid, 'winks', $w );
			self::notify( $to, 'wink' );
			self::out( true, 'Wink sent.' );
		}

		if ( 'interest' === $act || 'msg' === $act ) {
			if ( 'interest' === $act ) {
				$done = get_post_meta( $pid, 'mrt_interests', true );
				$done = is_array( $done ) ? $done : array();
				if ( in_array( $uid, $done, true ) ) {
					self::out( true, 'You already sent your interest.' );
				}
				if ( ! self::limit( 'interest', (int) MRSH_Manage::get()['interest'] ) ) {
					self::out( false, 'Daily limit reached. Try again tomorrow.' );
				}
				$text   = 'I am interested in your profile. Please reply if you are interested too.';
				$done[] = $uid;
				update_post_meta( $pid, 'mrt_interests', $done );
			} else {
				$text = isset( $_POST['text'] ) ? trim( wp_strip_all_tags( (string) wp_unslash( $_POST['text'] ) ) ) : '';
				if ( strlen( $text ) < 5 || strlen( $text ) > 1000 ) {
					self::out( false, 'Write between 5 and 1000 characters.' );
				}
				if ( preg_match( '#https?://|www\.|\b\d[\d\s\-]{8,}\d\b#i', $text ) ) {
					self::out( false, 'For your safety, links and phone numbers cannot be sent here.' );
				}
				if ( class_exists( 'MRSH_Queue' ) && ( $m = MRSH_Queue::money_block( $text, $uid, $to ) ) ) {
					self::out( false, $m );
				}
				foreach ( preg_split( '/\r\n|\r|\n/', (string) MRSH_Manage::get()['words'] ) as $w ) {
					if ( '' !== trim( $w ) && false !== stripos( $text, trim( $w ) ) ) {
						self::out( false, 'This message contains a word that is not allowed.' );
					}
				}
				if ( ! self::limit( 'msg', (int) MRSH_Manage::get()['msg'] ) ) {
					self::out( false, 'Daily limit reached. Try again tomorrow.' );
				}
			}
			self::send( $uid, $to, $text, $pid );
			self::notify( $to, 'msg' );
			self::out( true, 'interest' === $act ? 'Interest sent.' : 'Message sent.' );
		}
		self::out( false, 'Unknown action.' );
	}

	/** Same message format as the old theme. */
	public static function send( $from, $to, $text, $pid = 0 ) {
		$id = wp_insert_post( array( 'post_title' => 'new conversation', 'post_content' => $text, 'post_status' => 'publish', 'post_type' => self::MSG, 'post_author' => $from ) );
		if ( $id && ! is_wp_error( $id ) ) {
			add_post_meta( $id, 'sender_id', $from );
			add_post_meta( $id, 'reciever_id', $to );
			if ( $pid ) {
				add_post_meta( $id, 'pid', $pid );
			}
			add_post_meta( $id, 'msg_stick', '[' . $to . '][' . $from . ']' );
			add_post_meta( $id, 'msg_status', 'unread_' . $to );
			do_action( 'mrsh_msg_sent', (int) $id, (int) $from, (int) $to, (string) $text, (int) $pid );
		}
		return $id;
	}

	/** One short email per member per hour, never with message text. */
	public static function notify( $to, $kind ) {
		if ( class_exists( 'MRSH_Mem_More5' ) && MRSH_Mem_More5::quiet( $to ) ) {
			return;
		}
		if ( class_exists( 'MRSH_Mem_Push' ) ) {
			MRSH_Mem_Push::ping( $to, $kind );
		}
		$k = 'mrt_nt_' . $to;
		if ( get_transient( $k ) ) {
			return;
		}
		set_transient( $k, 1, HOUR_IN_SECONDS );
		$u = get_userdata( $to );
		if ( ! $u || ! $u->user_email ) {
			return;
		}
		$link = function_exists( 'mrt_link' ) ? mrt_link( 'myaccount', '/my-account/' ) : home_url( '/my-account/' );
		if ( class_exists( 'MRSH_Mem_Mail' ) ) {
			MRSH_Mem_Mail::send( $u->user_email, 'phone' === $kind ? 'phonereq' : 'interest', array( 'name' => $u->display_name, 'link' => $link ) );
			return;
		}
		wp_mail( $u->user_email, 'Someone is interested in your profile - ' . get_bloginfo( 'name' ), "Assalam o Alaikum,\n\nYou have new activity on your profile. Log in to see it:\n" . $link . "\n\nNever send money to anyone you meet online.\n\n" . get_bloginfo( 'name' ) );
	}

	/** Phone number of a profile (private field), or ''. */
	public static function phone_of( $pid ) {
		$cf = get_option( 'cfields' );
		if ( is_array( $cf ) && ! empty( $cf['dbkey'] ) ) {
			foreach ( (array) $cf['dbkey'] as $n => $key ) {
				if ( preg_match( '/phone|mobile|contact|whatsapp/i', ( $cf['name'][ $n ] ?? '' ) . ' ' . $key ) && 'title' !== ( $cf['fieldtype'][ $n ] ?? '' ) ) {
					$v = trim( (string) get_post_meta( $pid, $key, true ) );
					if ( '' !== $v && preg_match( '/^[0-9+\-\s]{6,20}$/', $v ) ) {
						return $v;
					}
				}
			}
		}
		return '';
	}

	/** State of the viewer's phone request for a profile: '', pending, yes, no. */
	public static function phone_state( $pid, $uid ) {
		$r = get_post_meta( $pid, 'mrt_phone_req', true );
		return is_array( $r ) && isset( $r[ $uid ] ) ? $r[ $uid ] : '';
	}

	public static function phone_answer() {
		if ( ! is_user_logged_in() ) {
			wp_die( 'Please log in.' );
		}
		$pid = isset( $_GET['pid'] ) ? absint( $_GET['pid'] ) : 0;
		$who = isset( $_GET['who'] ) ? absint( $_GET['who'] ) : 0;
		check_admin_referer( 'mrt_phone' . $pid . '_' . $who );
		$p = get_post( $pid );
		if ( $p && self::CPT === $p->post_type && (int) $p->post_author === get_current_user_id() ) {
			$r = (array) get_post_meta( $pid, 'mrt_phone_req', true );
			if ( isset( $r[ $who ] ) ) {
				$r[ $who ] = isset( $_GET['ok'] ) && '1' === $_GET['ok'] ? 'yes' : 'no';
				update_post_meta( $pid, 'mrt_phone_req', $r );
			}
		}
		wp_safe_redirect( add_query_arg( 'tab', 'requests', function_exists( 'mrt_link' ) ? mrt_link( 'myaccount', '/my-account/' ) : home_url( '/my-account/' ) ) );
		exit;
	}

	/** Free sign up: name, email, password. Then the member is logged in and sent to the profile form. */
	public static function signup() {
		$add = function_exists( 'mrt_link' ) ? mrt_link( 'add', '/add-listing/' ) : home_url( '/add-listing/' );
		$bad = function ( $m ) use ( $add ) {
			set_transient( 'mrt_su_' . md5( self::ip() ), $m, 300 );
			wp_safe_redirect( add_query_arg( 'su', 1, $add ) );
			exit;
		};
		if ( is_user_logged_in() && ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ), 'mrt_signup' ) ) ) {
			$bad( 'Please try again.' ); // guests: cached pages carry old nonces; honeypot, timer and per-IP limit protect sign up
		}
		if ( ! empty( $_POST['website'] ) || ( isset( $_POST['t'] ) && time() - absint( $_POST['t'] ) < 3 ) ) {
			$bad( 'Please try again.' );
		}
		if ( class_exists( 'MRSH_Captcha' ) && ! MRSH_Captcha::ok() ) {
			$bad( 'Please tick "I am not a robot" and try again.' );
		}
		$k = 'mrt_sul_' . md5( self::ip() );
		$n = (int) get_transient( $k );
		if ( $n >= 5 ) {
			$bad( 'Too many sign ups from this connection. Please try later.' );
		}
		set_transient( $k, $n + 1, HOUR_IN_SECONDS );
		$name  = isset( $_POST['name'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['name'] ) ) ) : '';
		$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		$pass  = isset( $_POST['pass'] ) ? (string) wp_unslash( $_POST['pass'] ) : '';
		if ( strlen( $name ) < 2 || ! is_email( $email ) ) {
			$bad( 'Enter your name and a valid email.' );
		}
		if ( strlen( $pass ) < 8 ) {
			$bad( 'Password must be at least 8 characters.' );
		}
		if ( empty( $_POST['terms'] ) ) {
			$bad( 'Please accept the terms.' );
		}
		if ( email_exists( $email ) ) {
			$bad( 'This email already has an account. Please log in.' );
		}
		if ( class_exists( 'MRSH_Noprofile' ) && MRSH_Noprofile::is_blocked( $email ) ) {
			$bad( 'This email cannot be used to register.' );
		}
		$login = sanitize_user( strstr( $email, '@', true ), true );
		$login = $login ? $login : 'member';
		$base  = $login;
		for ( $i = 1; username_exists( $login ); $i++ ) {
			$login = $base . $i;
		}
		$uid = wp_create_user( $login, $pass, $email );
		if ( is_wp_error( $uid ) ) {
			$bad( 'Could not create the account. Please try again.' );
		}
		wp_update_user( array( 'ID' => $uid, 'display_name' => $name, 'first_name' => $name ) );
		if ( class_exists( 'MRSH_Mobile' ) && ! empty( $_POST['mobile'] ) ) { // optional: lets the member log in with the number
			$mn = MRSH_Mobile::norm( wp_unslash( $_POST['mobile'] ) ); // phpcs:ignore
			if ( $mn && ! MRSH_Mobile::user_by( $mn ) ) {
				update_user_meta( $uid, 'mrt_mobile', $mn );
			}
		}
		$plan = isset( $_POST['plan'] ) ? sanitize_text_field( wp_unslash( $_POST['plan'] ) ) : '';
		if ( $plan ) {
			self::set_plan_request( $uid, $plan );
		}
		wp_set_current_user( $uid );
		wp_set_auth_cookie( $uid, true );
		wp_safe_redirect( $add );
		exit;
	}

	/** A logged-in member changes or requests a plan from My account. Free plans apply at once; paid plans wait for the team. */
	public static function my_plan() {
		$uid = get_current_user_id();
		$bk  = function_exists( 'mrt_link' ) ? mrt_link( 'myaccount', '/my-account/' ) : home_url( '/my-account/' );
		if ( ! $uid ) {
			wp_safe_redirect( wp_login_url( $bk ) );
			exit;
		}
		check_admin_referer( 'mrt_myplan' );
		$plan = isset( $_POST['plan'] ) ? sanitize_text_field( wp_unslash( $_POST['plan'] ) ) : '';
		if ( '' === $plan ) { // cancel a waiting request
			delete_user_meta( $uid, 'mrt_plan_req' );
			wp_safe_redirect( add_query_arg( array( 'tab' => 'home', 'plan' => 'cancel' ), $bk ) );
			exit;
		}
		if ( 0 !== strcasecmp( $plan, (string) get_user_meta( $uid, 'mrt_plan', true ) ) ) {
			self::set_plan_request( $uid, $plan );
		}
		wp_safe_redirect( add_query_arg( array( 'tab' => 'home', 'plan' => 'ok' ), $bk ) );
		exit;
	}

	/** A member asks for a plan. Free plans are given at once; paid plans wait until the team assigns them. */
	public static function set_plan_request( $uid, $plan ) {
		$found = null;
		if ( function_exists( 'mrt_plans' ) ) {
			foreach ( mrt_plans() as $i => $p ) {
				if ( 0 === strcasecmp( $p[0], $plan ) ) {
					$found = array( $i, $p );
				}
			}
		}
		if ( ! $found ) {
			return;
		}
		$free = 0 === $found[0] || preg_match( '/^(free|0|rs\.?\s*0)$/i', trim( $found[1][1] ) );
		if ( $free ) {
			update_user_meta( $uid, 'mrt_plan', $found[1][0] );
			delete_user_meta( $uid, 'mrt_plan_req' );
		} else {
			update_user_meta( $uid, 'mrt_plan_req', $found[1][0] );
			wp_mail( get_option( 'admin_email' ), 'Membership requested: ' . $found[1][0], 'User #' . (int) $uid . ' asked for the ' . $found[1][0] . ' plan. Assign it in My Rishta SEO > Members and matches > Members.' );
		}
	}

	/** Country (top level) and city (child) of a profile, from the hierarchical "country" taxonomy used by the old theme. */
	public static function loc_of( $pid ) {
		$out = array( '', '' );
		if ( ! $pid || ! taxonomy_exists( 'country' ) ) {
			return $out;
		}
		foreach ( (array) wp_get_object_terms( $pid, 'country' ) as $t ) {
			if ( 0 === (int) $t->parent ) {
				$out[0] = $t->name;
			} else {
				$out[1] = $t->name;
				$par    = get_term( (int) $t->parent, 'country' );
				if ( $par && ! is_wp_error( $par ) && ! $out[0] ) {
					$out[0] = $par->name;
				}
			}
		}
		return $out;
	}

	private static function loc_term( $name, $parent ) {
		$name = trim( preg_replace( '/[^\p{L}\p{N} .\'-]/u', '', $name ) );
		if ( '' === $name || mb_strlen( $name ) > 40 ) {
			return 0;
		}
		$ex = get_terms( array( 'taxonomy' => 'country', 'name' => $name, 'parent' => $parent, 'hide_empty' => false, 'number' => 1, 'fields' => 'ids' ) );
		if ( $ex && ! is_wp_error( $ex ) ) {
			return (int) $ex[0];
		}
		$r = wp_insert_term( $name, 'country', array( 'parent' => $parent ) );
		return is_wp_error( $r ) ? ( isset( $r->error_data['term_exists'] ) ? (int) $r->error_data['term_exists'] : 0 ) : (int) $r['term_id'];
	}

	private static function save_location( $id ) {
		if ( ! taxonomy_exists( 'country' ) || ! isset( $_POST['loc_country'] ) ) { // phpcs:ignore
			return;
		}
		$c  = sanitize_text_field( wp_unslash( $_POST['loc_country'] ) ); // phpcs:ignore
		$ci = isset( $_POST['loc_city'] ) ? sanitize_text_field( wp_unslash( $_POST['loc_city'] ) ) : ''; // phpcs:ignore
		$ci = trim( preg_replace( '/\s+/', ' ', $ci ) );
		if ( strlen( $ci ) > 40 || preg_match( '#https?://|www\.|[0-9@<>]#i', $ci ) ) {
			$ci = ''; // a city or village name has no links or numbers
		}
		$cid = $c ? self::loc_term( $c, 0 ) : 0;
		if ( ! $cid ) {
			return;
		}
		$ids = array( $cid );
		if ( '' !== $ci ) {
			$yid = self::loc_term( $ci, $cid );
			if ( $yid ) {
				$ids[] = $yid;
			}
		}
		wp_set_object_terms( $id, $ids, 'country', false );
	}

	/** Cities (children) of a country, for the suggestion list. */
	public static function cities() {
		check_ajax_referer( 'mrt', 'n' );
		$name = isset( $_POST['c'] ) ? sanitize_text_field( wp_unslash( $_POST['c'] ) ) : '';
		$out  = array();
		$par  = $name ? get_terms( array( 'taxonomy' => 'country', 'name' => $name, 'parent' => 0, 'hide_empty' => false, 'number' => 1, 'fields' => 'ids' ) ) : array();
		if ( $par && ! is_wp_error( $par ) ) {
			$kids = get_terms( array( 'taxonomy' => 'country', 'parent' => (int) $par[0], 'hide_empty' => false, 'orderby' => 'name', 'number' => 800, 'fields' => 'names' ) );
			$out  = is_wp_error( $kids ) ? array() : array_values( $kids );
		}
		wp_send_json( array( 'ok' => true, 'cities' => $out ) );
	}

	/** Country and city from the visitor's address, looked up on the server so ad-blockers and CORS cannot stop it. */
	public static function geo() {
		check_ajax_referer( 'mrt', 'n' );
		$ip = '';
		foreach ( array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' ) as $k ) {
			if ( ! empty( $_SERVER[ $k ] ) ) {
				$c = trim( explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $k ] ) ) )[0] );
				if ( filter_var( $c, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
					$ip = $c;
					break;
				}
			}
		}
		if ( ! $ip ) {
			wp_send_json( array( 'ok' => false ) );
		}
		$key = 'mrt_geo_' . md5( $ip );
		$out = get_transient( $key );
		if ( ! $out ) {
			$tries = array(
				'https://ipwho.is/' . $ip                            => array( 'country', 'city', 'region' ),
				'https://ipapi.co/' . $ip . '/json/'                 => array( 'country_name', 'city', 'region' ),
				'http://ip-api.com/json/' . $ip . '?fields=country,city,regionName' => array( 'country', 'city', 'regionName' ),
			);
			foreach ( $tries as $url => $k ) {
				$r = wp_remote_get( $url, array( 'timeout' => 4 ) );
				if ( is_wp_error( $r ) ) {
					continue;
				}
				$d = json_decode( wp_remote_retrieve_body( $r ), true );
				if ( is_array( $d ) && ! empty( $d[ $k[0] ] ) ) {
					$out = array( 'country' => (string) $d[ $k[0] ], 'city' => (string) ( $d[ $k[1] ] ?? '' ), 'state' => (string) ( $d[ $k[2] ] ?? '' ) );
					set_transient( $key, $out, DAY_IN_SECONDS );
					break;
				}
			}
		}
		wp_send_json( $out ? array_merge( array( 'ok' => true ), $out ) : array( 'ok' => false ) );
	}

	private static function ip() {
		if ( function_exists( 'mrt_ip' ) ) {
			return mrt_ip();
		}
		return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'x'; // phpcs:ignore
	}

	/* ---------- inbox ---------- */

	/** Conversations for a member: array of other_uid => [last text, date, unread count]. */
	public static function inbox( $uid ) {
		$q = get_posts( array(
			'post_type' => self::MSG, 'post_status' => 'publish', 'numberposts' => 300, 'orderby' => 'date', 'order' => 'DESC',
			'meta_query' => array( 'relation' => 'OR', array( 'key' => 'sender_id', 'value' => $uid ), array( 'key' => 'reciever_id', 'value' => $uid ) ),
		) );
		$out = array();
		foreach ( $q as $m ) {
			$s     = (int) get_post_meta( $m->ID, 'sender_id', true );
			$r     = (int) get_post_meta( $m->ID, 'reciever_id', true );
			$other = $s === (int) $uid ? $r : $s;
			if ( ! $other ) {
				continue;
			}
			if ( ! isset( $out[ $other ] ) ) {
				$out[ $other ] = array( 'text' => wp_trim_words( $m->post_content, 14 ), 'date' => $m->post_date, 'unread' => 0 );
			}
			if ( 'unread_' . $uid === get_post_meta( $m->ID, 'msg_status', true ) ) {
				$out[ $other ]['unread']++;
			}
		}
		return $out;
	}

	public static function thread( $uid, $other ) {
		$q = get_posts( array(
			'post_type' => self::MSG, 'post_status' => 'publish', 'numberposts' => 100, 'orderby' => 'date', 'order' => 'ASC',
			'meta_query' => array( 'relation' => 'OR',
				array( 'key' => 'msg_stick', 'value' => '[' . $uid . '][' . $other . ']' ),
				array( 'key' => 'msg_stick', 'value' => '[' . $other . '][' . $uid . ']' ),
			),
		) );
		foreach ( $q as $m ) {
			if ( 'unread_' . $uid === get_post_meta( $m->ID, 'msg_status', true ) ) {
				update_post_meta( $m->ID, 'msg_status', 'read' );
			}
		}
		return $q;
	}

	public static function unread_count( $uid ) {
		$n = 0;
		foreach ( self::inbox( $uid ) as $c ) {
			$n += $c['unread'];
		}
		return $n;
	}

	/* ---------- completeness and matches ---------- */

	public static function completeness( $post ) {
		if ( class_exists( 'MRSH_Nudge' ) && method_exists( 'MRSH_Nudge', 'score' ) ) {
			return MRSH_Nudge::score( $post ); // array( percent, missing list )
		}
		return array( 0, array() );
	}

	/** Matches for a member: opposite gender, similar age, same religion if known. */
	public static function matches( $post, $limit = 12 ) {
		$gender = (string) get_post_meta( $post->ID, 'key4', true );
		$age    = (int) get_post_meta( $post->ID, 'daage', true );
		$rel    = (string) get_post_meta( $post->ID, 'custom-18', true );
		$want   = '';
		if ( stripos( $gender, 'female' ) !== false ) {
			$want = 'Male';
		} elseif ( stripos( $gender, 'male' ) !== false ) {
			$want = 'Female';
		}
		$args = array( 'post_type' => self::CPT, 'post_status' => 'publish', 'posts_per_page' => $limit, 'post__not_in' => array( $post->ID ), 'no_found_rows' => true, 'meta_query' => array( 'relation' => 'AND' ) );
		if ( $want ) {
			$args['tax_query'] = array( array( 'taxonomy' => 'dagender', 'field' => 'name', 'terms' => $want ) );
		}
		if ( $age ) {
			$args['meta_query'][] = array( 'key' => 'daage', 'value' => array( max( 18, $age - 6 ), $age + 8 ), 'type' => 'NUMERIC', 'compare' => 'BETWEEN' );
		}
		if ( $rel ) {
			$args['meta_query'][] = array( 'key' => 'custom-18', 'value' => $rel );
		}
		return get_posts( $args );
	}

	/* ---------- profile form ---------- */

	/** Fields for the form: label, key, type, options, required, private. */
	public static function form_fields() {
		$cf  = get_option( 'cfields' );
		$out = array();
		if ( ! is_array( $cf ) || empty( $cf['dbkey'] ) ) {
			return $out;
		}
		foreach ( (array) $cf['dbkey'] as $n => $key ) {
			$type = $cf['fieldtype'][ $n ] ?? 'input';
			$name = trim( (string) ( $cf['name'][ $n ] ?? $key ) );
			if ( 'title' === $type || '' === $name ) {
				continue;
			}
			$vals = array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) ( $cf['values'][ $n ] ?? '' ) ) ) ) );
			if ( 'taxonomy' === $type && 'key4' === $key ) {
				$vals = array( 'Male', 'Female' );
			}
			$out[] = array(
				'label' => $name, 'key' => $key, 'type' => $type, 'opts' => $vals,
				'req'   => 'yes' === ( $cf['required'][ $n ] ?? '' ),
				'priv'  => (bool) preg_match( '/phone|mobile|contact|whatsapp/i', $name . ' ' . $key ),
				'num'   => 'daage' === $key,
			);
		}
		return $out;
	}

	public static function is_caste( $f ) {
		return (bool) preg_match( '/^\s*(caste|cast)\s*$/i', (string) ( $f['label'] ?? '' ) );
	}

	public static function tax_for( $label ) {
		$map = array( 'gender' => 'dagender', 'religion' => 'religion', 'sect' => 'sect', 'caste' => 'caste', 'education' => 'education', 'occupation' => 'occupation', 'marital status' => 'maritalstatus', 'nationalty' => 'nationality', 'nationality' => 'nationality', 'profile created by' => 'profilecreated' );
		return $map[ strtolower( trim( $label ) ) ] ?? '';
	}

	private static function back( $args ) {
		$url = function_exists( 'mrt_link' ) ? mrt_link( 'add', '/add-listing/' ) : home_url( '/add-listing/' );
		wp_safe_redirect( add_query_arg( $args, $url ) );
		exit;
	}

	public static function save_profile() {
		if ( ! is_user_logged_in() ) {
			wp_safe_redirect( wp_login_url() );
			exit;
		}
		// A phone photo bigger than the server's post limit empties the whole form; say so instead of "link expired".
		if ( empty( $_POST ) && ! empty( $_SERVER['CONTENT_LENGTH'] ) ) { // phpcs:ignore
			self::back( array( 'e' => 'Your photos are too big for this server. Choose smaller photos (the form now shrinks them for you) and try again.' ) );
		}
		check_admin_referer( 'mrt_save_profile' );
		$uid  = get_current_user_id();
		$edit = isset( $_POST['pid'] ) ? absint( $_POST['pid'] ) : 0;
		$mine = self::my_profile( $uid );
		if ( $edit ) {
			$cur = get_post( $edit );
			if ( ! $cur || self::CPT !== $cur->post_type || ( (int) $cur->post_author !== $uid && ! current_user_can( 'manage_options' ) ) ) {
				wp_die( 'Not allowed.' );
			}
		} elseif ( $mine ) {
			self::back( array( 'edit' => $mine->ID, 'e' => 'You already have a profile. You can edit it here.' ) );
		}
		$title = isset( $_POST['title'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['title'] ) ) ) : '';
		$about = isset( $_POST['about'] ) ? trim( wp_strip_all_tags( (string) wp_unslash( $_POST['about'] ) ) ) : '';
		$err   = array();
		if ( strlen( $title ) < 2 || strlen( $title ) > 60 || preg_match( '#https?://|www\.|\d{5,}#i', $title ) ) {
			$err[] = 'Enter a first name (no links or numbers).';
		}
		if ( strlen( $about ) < 20 || strlen( $about ) > 1500 || preg_match( '#https?://|www\.|\b\d[\d\s\-]{8,}\d\b#i', $about ) ) {
			$err[] = 'Write at least 20 characters about yourself, without links or phone numbers.';
		}
		if ( empty( $_POST['terms'] ) ) {
			$err[] = 'Please accept the terms.';
		}
		if ( MRSH_Manage::get()['wordsprof'] ) {
			foreach ( preg_split( '/\r\n|\r|\n/', (string) MRSH_Manage::get()['words'] ) as $w ) {
				if ( '' !== trim( $w ) && ( false !== stripos( $title, trim( $w ) ) || false !== stripos( $about, trim( $w ) ) ) ) {
					$err[] = 'Your name or text contains a word that is not allowed.';
					break;
				}
			}
		}
		$meta = array();
		foreach ( self::form_fields() as $f ) {
			$v = isset( $_POST['f'][ $f['key'] ] ) ? trim( sanitize_text_field( wp_unslash( $_POST['f'][ $f['key'] ] ) ) ) : '';
			if ( '' === $v ) {
				if ( $f['req'] && ! ( $edit && $f['priv'] ) ) {
					$err[] = $f['label'] . ' is required.';
				}
				continue;
			}
			if ( $f['num'] ) {
				$ma = max( 18, (int) MRSH_Manage::get()['minage'] );
				if ( ! ctype_digit( $v ) || (int) $v < $ma || (int) $v > 80 ) {
					$err[] = 'Age must be between ' . $ma . ' and 80.';
					continue;
				}
			} elseif ( self::is_caste( $f ) ) {
				// Members may type a caste that is not on the list. Keep it short and clean; it becomes a new caste for everyone.
				$v = trim( preg_replace( '/\s+/', ' ', $v ) );
				if ( strlen( $v ) < 2 || strlen( $v ) > 40 || preg_match( '#https?://|www\.|[0-9@<>]#i', $v ) ) {
					$err[] = 'Caste: use letters only, up to 40 characters.';
					continue;
				}
				$known = array_filter( $f['opts'], function ( $o ) use ( $v ) { return 0 === strcasecmp( $o, $v ); } );
				$v     = $known ? reset( $known ) : $v;
			} elseif ( $f['opts'] && ! in_array( $v, $f['opts'], true ) ) {
				$err[] = $f['label'] . ': choose from the list.';
				continue;
			} elseif ( $f['priv'] && ! preg_match( '/^[0-9+\-\s]{7,20}$/', $v ) ) {
				$err[] = 'Enter a valid phone number (it is never shown publicly).';
				continue;
			}
			$meta[ $f['key'] ] = $v;
		}
		$files = array();
		foreach ( array( 'photo', 'photo2', 'photo3' ) as $k ) {
			if ( ! empty( $_FILES[ $k ]['name'] ) && in_array( (int) $_FILES[ $k ]['error'], array( UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE ), true ) ) {
				$err[] = 'A photo is too big for this server (limit ' . esc_html( size_format( wp_max_upload_size() ) ) . '). Choose a smaller photo.';
			}
			if ( ! empty( $_FILES[ $k ]['name'] ) && UPLOAD_ERR_OK === (int) $_FILES[ $k ]['error'] ) {
				$ft = wp_check_filetype_and_ext( $_FILES[ $k ]['tmp_name'], $_FILES[ $k ]['name'], array( 'jpg|jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' ) ); // phpcs:ignore
				if ( empty( $ft['type'] ) || (int) $_FILES[ $k ]['size'] > 6 * MB_IN_BYTES ) {
					$err[] = 'Photos must be JPG, PNG or WebP, up to 6 MB.';
				} else {
					$files[] = $k;
				}
			}
		}
		if ( MRSH_Manage::get()['dupphone'] ) {
			foreach ( self::form_fields() as $f ) {
				if ( $f['priv'] && ! empty( $meta[ $f['key'] ] ) ) {
					$dp = get_posts( array( 'post_type' => self::CPT, 'post_status' => 'any', 'meta_key' => $f['key'], 'meta_value' => $meta[ $f['key'] ], 'post__not_in' => array( (int) $edit ), 'numberposts' => 1, 'fields' => 'ids' ) );
					if ( $dp ) {
						$err[] = 'This phone number is already used by another profile.';
					}
				}
			}
		}
		if ( $err ) {
			set_transient( 'mrt_form_' . $uid, array( 'title' => $title, 'about' => $about, 'f' => $meta, 'err' => $err ), 600 );
			self::back( $edit ? array( 'edit' => $edit, 'bad' => 1 ) : array( 'bad' => 1 ) );
		}

		$s   = get_option( 'core_admin_values' );
		$st  = MRSH_Manage::get()['status'];
		$st  = in_array( $st, array( 'publish', 'pending' ), true ) ? $st : 'publish';
		$arr = array( 'post_title' => $title, 'post_content' => $about, 'post_type' => self::CPT, 'post_author' => $uid );
		if ( $edit ) {
			$arr['ID'] = $edit;
			$id        = wp_update_post( $arr, true );
		} else {
			if ( MRSH_Manage::get()['needphoto'] && ! $files ) {
				$st = 'pending';
			}
			$arr['post_status'] = $st;
			$id                 = wp_insert_post( $arr, true );
		}
		if ( is_wp_error( $id ) || ! $id ) {
			self::back( array( 'e' => 'Could not save. Please try again.' ) );
		}
		delete_user_meta( $uid, 'mrt_draft' );
		foreach ( self::form_fields() as $f ) {
			if ( isset( $meta[ $f['key'] ] ) ) {
				update_post_meta( $id, $f['key'], $meta[ $f['key'] ] );
				$tax = self::tax_for( $f['label'] );
				if ( $tax && taxonomy_exists( $tax ) ) {
					wp_set_object_terms( $id, $meta[ $f['key'] ], $tax, false );
				}
			} elseif ( $edit && ! $f['priv'] ) {
				delete_post_meta( $id, $f['key'] );
			}
		}
		self::save_location( $id );
		if ( $files ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
			foreach ( $files as $i => $k ) {
				$aid = media_handle_upload( $k, $id );
				if ( ! is_wp_error( $aid ) && 0 === $i && 'photo' === $k ) {
					set_post_thumbnail( $id, $aid );
				}
			}
		}
		if ( ! empty( $_POST['plan'] ) ) {
			self::set_plan_request( $uid, sanitize_text_field( wp_unslash( $_POST['plan'] ) ) );
		}
		delete_transient( 'mrt_form_' . $uid );
		wp_safe_redirect( get_permalink( $id ) );
		exit;
	}

	public static function pause_profile() {
		check_admin_referer( 'mrt_pause_profile' );
		$id = isset( $_GET['pid'] ) ? absint( $_GET['pid'] ) : 0;
		$p  = $id ? get_post( $id ) : null;
		if ( $p && self::CPT === $p->post_type && ( (int) $p->post_author === get_current_user_id() || current_user_can( 'manage_options' ) ) ) {
			wp_update_post( array( 'ID' => $id, 'post_status' => 'publish' === $p->post_status ? 'draft' : 'publish' ) );
		}
		wp_safe_redirect( function_exists( 'mrt_link' ) ? mrt_link( 'myaccount', '/my-account/' ) : home_url( '/my-account/' ) );
		exit;
	}
}
MRSH_Members::init();
