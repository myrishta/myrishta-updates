<?php
/**
 * Admin helpers: Today dashboard, quick WhatsApp replies, duplicate finder, bulk actions on profiles, moderation rules,
 * matched-profiles tracker, weekly report email, restore readiness check with settings export, Urdu coverage checker,
 * and a Moderator role. Everything is switched on from the Quality and safety page (option mrsh_m4).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Mem_More4 {

	const CPT  = 'listing_type';
	const ROLE = 'mrt_moderator';

	public static function defaults() {
		return array( 'report' => 1, 'rules' => 1, 'words' => '', 'phone_rule' => 1, 'link_rule' => 1 );
	}

	public static function get( $k = null ) {
		$o = array_merge( self::defaults(), (array) get_option( 'mrsh_m4', array() ) );
		return null === $k ? $o : ( $o[ $k ] ?? '' );
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 27 );
		add_action( 'admin_init', array( __CLASS__, 'role' ) );
		add_action( 'admin_post_mrsh_m4_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_mrsh_m4_act', array( __CLASS__, 'act' ) );
		add_action( 'admin_post_mrsh_m4_export', array( __CLASS__, 'export' ) );
		add_filter( 'bulk_actions-edit-' . self::CPT, array( __CLASS__, 'bulk_list' ) );
		add_filter( 'handle_bulk_actions-edit-' . self::CPT, array( __CLASS__, 'bulk_do' ), 10, 3 );
		add_action( 'admin_notices', array( __CLASS__, 'bulk_notice' ) );
		add_action( 'save_post_' . self::CPT, array( __CLASS__, 'moderate' ), 20, 2 );
		add_action( 'mrsh_growth_daily', array( __CLASS__, 'weekly' ) );
		add_action( 'wp_footer', array( __CLASS__, 'urdu_check' ), 99 );
	}

	/* ---------- moderator role ---------- */

	public static function role() {
		if ( get_option( 'mrsh_m4_role' ) === '1' ) {
			return;
		}
		add_role( self::ROLE, 'Moderator', array(
			'read' => true, 'edit_posts' => true, 'edit_others_posts' => true, 'edit_published_posts' => true, 'edit_private_posts' => true,
			'publish_posts' => true, 'moderate_comments' => true, 'upload_files' => true,
		) );
		update_option( 'mrsh_m4_role', '1', false );
	}

	private static function cap() {
		return 'edit_others_posts';
	}

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Today', 'Today', self::cap(), 'mrsh-today', array( __CLASS__, 'today' ) );
		add_submenu_page( 'myrishta-seo', 'Quality and safety', 'Quality and safety', 'manage_options', 'mrsh-clean', array( __CLASS__, 'clean' ) );
	}

	/* ---------- helpers ---------- */

	private static function count( $args ) {
		$q = new WP_Query( array_merge( array( 'post_type' => self::CPT, 'posts_per_page' => 1, 'fields' => 'ids', 'no_found_rows' => false ), $args ) );
		return (int) $q->found_posts;
	}

	private static function pending_ids( $n = 12 ) {
		return get_posts( array( 'post_type' => self::CPT, 'post_status' => array( 'pending', 'pending_approval', 'draft' ), 'numberposts' => $n, 'orderby' => 'date', 'order' => 'DESC', 'fields' => 'ids' ) );
	}

	private static function btn( $action, $id, $label, $extra = '' ) {
		$u = wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_m4_act&do=' . $action . '&id=' . (int) $id ), 'mrsh_m4_' . $action . $id );
		return '<a class="button' . ( 'approve' === $action ? ' button-primary' : '' ) . '" href="' . esc_url( $u ) . '"' . $extra . '>' . esc_html( $label ) . '</a> ';
	}

	/* ---------- Today dashboard ---------- */

	public static function today() {
		echo '<div class="wrap"><h1>Today</h1>';
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success is-dismissible"><p>Done.</p></div>';
		}
		$pend  = self::count( array( 'post_status' => array( 'pending', 'pending_approval' ) ) );
		$week  = self::count( array( 'post_status' => 'publish', 'date_query' => array( array( 'after' => '7 days ago' ) ) ) );
		$flag  = self::count( array( 'post_status' => array( 'pending', 'pending_approval', 'draft', 'publish' ), 'meta_key' => 'mrt_flag', 'meta_value' => '1' ) ); // phpcs:ignore
		$ver   = count( (array) get_option( 'mrsh_checks', array() ) );
		$voice = count( (array) get_users( array( 'meta_key' => 'mrt_voice_ok', 'meta_value' => 'wait', 'fields' => 'ID' ) ) ); // phpcs:ignore
		$exp   = count( (array) get_users( array( 'meta_key' => 'mrt_plan_exp', 'meta_value' => time() + 7 * DAY_IN_SECONDS, 'meta_compare' => '<=', 'meta_type' => 'NUMERIC', 'fields' => 'ID' ) ) ); // phpcs:ignore
		$tiles = array(
			array( 'Waiting for approval', $pend, '#e11d74' ), array( 'New this week', $week, '#10b981' ), array( 'Held by safety rules', $flag, '#ef4444' ),
			array( 'Selfie and video checks', $ver, '#6366f1' ), array( 'Voice intros', $voice, '#f59e0b' ), array( 'Plans ending in 7 days', $exp, '#0ea5e9' ),
		);
		echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;max-width:1000px;margin:14px 0">';
		foreach ( $tiles as $t ) {
			echo '<div style="background:#fff;border-radius:16px;padding:16px;box-shadow:0 1px 3px rgba(0,0,0,.08);border-top:4px solid ' . esc_attr( $t[2] ) . '"><div style="font-size:28px;font-weight:800;color:' . esc_attr( $t[2] ) . '">' . (int) $t[1] . '</div><div style="color:#667085">' . esc_html( $t[0] ) . '</div></div>';
		}
		echo '</div>';

		echo '<h2>Profiles to check</h2>';
		$ids = self::pending_ids();
		if ( ! $ids ) {
			echo '<p>Nothing waiting.</p>';
		} else {
			echo '<table class="widefat striped" style="max-width:1000px"><thead><tr><th>Profile</th><th>Why</th><th>Actions</th></tr></thead><tbody>';
			foreach ( $ids as $id ) {
				$why = (string) get_post_meta( $id, 'mrt_flag_reason', true );
				echo '<tr><td><a href="' . esc_url( get_edit_post_link( $id ) ) . '"><b>' . esc_html( get_the_title( $id ) ) . '</b></a><br><small>' . esc_html( get_post_status( $id ) ) . ' &middot; ' . esc_html( get_the_date( '', $id ) ) . '</small></td><td>' . esc_html( $why ? $why : 'New profile' ) . '</td><td>' . self::btn( 'approve', $id, 'Approve' ) . self::btn( 'verify', $id, 'Approve and verify' ) . self::btn( 'hide', $id, 'Hide' ) . '<a class="button" target="_blank" href="' . esc_url( get_permalink( $id ) ) . '">View</a></td></tr>';
			}
			echo '</tbody></table>';
		}

		$vo = get_users( array( 'meta_key' => 'mrt_voice_ok', 'meta_value' => 'wait', 'number' => 10 ) ); // phpcs:ignore
		if ( $vo ) {
			echo '<h2>Voice introductions</h2><table class="widefat striped" style="max-width:1000px"><tbody>';
			$up = wp_get_upload_dir();
			foreach ( $vo as $u ) {
				$rel = (string) get_user_meta( $u->ID, 'mrt_voice_intro', true );
				echo '<tr><td>' . esc_html( $u->display_name ) . '</td><td><audio controls preload="none" src="' . esc_url( trailingslashit( $up['baseurl'] ) . $rel ) . '"></audio></td><td><a class="button button-primary" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_m4_act&do=voice_ok&id=' . $u->ID ), 'mrsh_m4_voice_ok' . $u->ID ) ) . '">Approve</a> <a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_m4_act&do=voice_no&id=' . $u->ID ), 'mrsh_m4_voice_no' . $u->ID ) ) . '">Remove</a></td></tr>';
			}
			echo '</tbody></table>';
		}

		// quick reply
		$l = array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) get_option( 'mrsh_replies', '' ) ) ) );
		echo '<h2>Quick reply</h2><div style="max-width:760px;background:#fff;border-radius:16px;padding:16px;box-shadow:0 1px 3px rgba(0,0,0,.08)">';
		if ( ! $l ) {
			echo '<p>Add replies first on the Redirects and replies page.</p>';
		} else {
			echo '<p><label>Member name <input id="qr-name" type="text" placeholder="e.g. Ayesha"></label> <label>Reply <select id="qr-t" style="max-width:420px">';
			foreach ( $l as $i => $t ) {
				echo '<option value="' . esc_attr( $t ) . '">' . esc_html( wp_trim_words( $t, 9 ) ) . '</option>';
			}
			echo '</select></label></p><p><textarea id="qr-out" rows="3" class="large-text" readonly></textarea></p><p><button type="button" class="button" id="qr-copy">Copy</button> <a class="button button-primary" id="qr-wa" target="_blank" rel="noopener" href="#">Open in WhatsApp</a></p>';
			echo '<script>(function(){var n=document.getElementById("qr-name"),t=document.getElementById("qr-t"),o=document.getElementById("qr-out"),w=document.getElementById("qr-wa");function f(){var nm=n.value.trim();var s=t.value;o.value=nm?s.replace(/^Assalam o Alaikum,?/,"Assalam o Alaikum "+nm+","):s;w.href="https://wa.me/?text="+encodeURIComponent(o.value)}n.oninput=t.onchange=f;f();document.getElementById("qr-copy").onclick=function(){navigator.clipboard.writeText(o.value);this.textContent="Copied"}})();</script>';
		}
		echo '</div></div>';
	}

	/** One-click actions from the Today page. */
	public static function act() {
		if ( ! current_user_can( self::cap() ) ) {
			wp_die( 'Not allowed.' );
		}
		$do = isset( $_GET['do'] ) ? sanitize_key( $_GET['do'] ) : ''; // phpcs:ignore
		$id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0; // phpcs:ignore
		check_admin_referer( 'mrsh_m4_' . $do . $id );
		if ( in_array( $do, array( 'approve', 'verify' ), true ) && self::CPT === get_post_type( $id ) ) {
			remove_action( 'save_post_' . self::CPT, array( __CLASS__, 'moderate' ), 20 );
			wp_update_post( array( 'ID' => $id, 'post_status' => 'publish' ) );
			delete_post_meta( $id, 'mrt_flag' );
			delete_post_meta( $id, 'mrt_flag_reason' );
			update_post_meta( $id, 'mrt_approved', 1 );
			if ( 'verify' === $do ) {
				update_post_meta( $id, 'ppt_verified', 1 );
			}
		} elseif ( 'hide' === $do && self::CPT === get_post_type( $id ) ) {
			remove_action( 'save_post_' . self::CPT, array( __CLASS__, 'moderate' ), 20 );
			wp_update_post( array( 'ID' => $id, 'post_status' => 'draft' ) );
		} elseif ( 'voice_ok' === $do ) {
			update_user_meta( $id, 'mrt_voice_ok', 'yes' );
		} elseif ( 'voice_no' === $do ) {
			$rel = (string) get_user_meta( $id, 'mrt_voice_intro', true );
			if ( $rel ) {
				$up = wp_get_upload_dir();
				$f  = trailingslashit( $up['basedir'] ) . $rel;
				if ( 0 === strpos( realpath( $f ) ?: '', realpath( $up['basedir'] ) ) && is_file( $f ) ) {
					wp_delete_file( $f );
				}
			}
			delete_user_meta( $id, 'mrt_voice_intro' );
			delete_user_meta( $id, 'mrt_voice_ok' );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-today&ok=1' ) );
		exit;
	}

	/* ---------- bulk actions ---------- */

	public static function bulk_list( $a ) {
		$a['mrsh_approve'] = 'Approve and publish';
		$a['mrsh_verify']  = 'Approve and mark verified';
		$a['mrsh_hide']    = 'Hide (draft)';
		$a['mrsh_unverify'] = 'Remove verified badge';
		return $a;
	}

	public static function bulk_do( $url, $action, $ids ) {
		if ( 0 !== strpos( (string) $action, 'mrsh_' ) || ! current_user_can( self::cap() ) ) {
			return $url;
		}
		remove_action( 'save_post_' . self::CPT, array( __CLASS__, 'moderate' ), 20 );
		$n = 0;
		foreach ( (array) $ids as $id ) {
			$id = (int) $id;
			if ( 'mrsh_approve' === $action || 'mrsh_verify' === $action ) {
				wp_update_post( array( 'ID' => $id, 'post_status' => 'publish' ) );
				delete_post_meta( $id, 'mrt_flag' );
				if ( 'mrsh_verify' === $action ) {
					update_post_meta( $id, 'ppt_verified', 1 );
				}
			} elseif ( 'mrsh_hide' === $action ) {
				wp_update_post( array( 'ID' => $id, 'post_status' => 'draft' ) );
			} elseif ( 'mrsh_unverify' === $action ) {
				delete_post_meta( $id, 'ppt_verified' );
			}
			$n++;
		}
		return add_query_arg( 'mrsh_bulk', $n, $url );
	}

	public static function bulk_notice() {
		if ( isset( $_GET['mrsh_bulk'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success is-dismissible"><p>' . (int) $_GET['mrsh_bulk'] . ' profile(s) updated.</p></div>'; // phpcs:ignore
		}
	}

	/* ---------- moderation rules ---------- */

	public static function moderate( $post_id, $post ) {
		if ( ! self::get( 'rules' ) || wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) || 'publish' !== $post->post_status ) {
			return;
		}
		if ( current_user_can( 'edit_others_posts' ) || get_post_meta( $post_id, 'mrt_approved', true ) ) {
			return; // staff edits and profiles you approved are trusted
		}
		$text = $post->post_title . ' ' . $post->post_content . ' ' . wp_json_encode( get_post_meta( $post_id, 'mrt_about', true ) );
		foreach ( array( 'about', 'story', 'bio', 'description' ) as $k ) {
			$text .= ' ' . (string) get_post_meta( $post_id, $k, true );
		}
		$why = '';
		if ( self::get( 'phone_rule' ) && preg_match( '/(\+?92|0)?\s?3\d{2}[\s\-]?\d{7}\b|\b\d[\d\s\-]{9,}\d\b/', $text ) ) {
			$why = 'Contains a phone number';
		} elseif ( self::get( 'link_rule' ) && preg_match( '#https?://|www\.|\.com\b|@[a-z0-9_.]{3,}#i', $text ) ) {
			$why = 'Contains a link or social handle';
		} else {
			foreach ( preg_split( '/\r\n|\r|\n/', (string) self::get( 'words' ) ) as $w ) {
				$w = trim( $w );
				if ( '' !== $w && false !== stripos( $text, $w ) ) {
					$why = 'Contains the word "' . $w . '"';
					break;
				}
			}
		}
		if ( $why ) {
			remove_action( 'save_post_' . self::CPT, array( __CLASS__, 'moderate' ), 20 );
			wp_update_post( array( 'ID' => $post_id, 'post_status' => 'pending' ) );
			update_post_meta( $post_id, 'mrt_flag', 1 );
			update_post_meta( $post_id, 'mrt_flag_reason', $why );
		}
	}

	/* ---------- weekly report ---------- */

	public static function weekly() {
		if ( ! self::get( 'report' ) || (int) gmdate( 'N' ) !== 1 || get_option( 'mrsh_m4_report_week' ) === gmdate( 'o-W' ) ) {
			return;
		}
		update_option( 'mrsh_m4_report_week', gmdate( 'o-W' ), false );
		$new  = self::count( array( 'post_status' => 'publish', 'date_query' => array( array( 'after' => '7 days ago' ) ) ) );
		$all  = self::count( array( 'post_status' => 'publish' ) );
		$pend = self::count( array( 'post_status' => array( 'pending', 'pending_approval' ) ) );
		$msgs = (int) ( new WP_Query( array( 'post_type' => 'ppt_message', 'post_status' => 'publish', 'posts_per_page' => 1, 'fields' => 'ids', 'date_query' => array( array( 'after' => '7 days ago' ) ) ) ) )->found_posts;
		$usr  = count( get_users( array( 'role__not_in' => array( 'administrator' ), 'date_query' => array( array( 'after' => '7 days ago' ) ), 'fields' => 'ID' ) ) );
		$city = array();
		foreach ( get_terms( array( 'taxonomy' => 'country', 'orderby' => 'count', 'order' => 'DESC', 'number' => 5, 'hide_empty' => true ) ) as $t ) {
			if ( ! is_wp_error( $t ) ) {
				$city[] = $t->name . ' (' . $t->count . ')';
			}
		}
		$body = "Assalam o Alaikum,\n\nYour weekly report for " . get_bloginfo( 'name' ) . ":\n\n- New profiles this week: $new\n- Live profiles in total: $all\n- Waiting for approval: $pend\n- New members this week: $usr\n- Messages and interests this week: $msgs\n- Top places: " . ( $city ? implode( ', ', $city ) : 'none yet' ) . "\n\nWhat to do now:\n" . ( $pend ? "- Approve $pend waiting profile(s): " . admin_url( 'admin.php?page=mrsh-today' ) . "\n" : '' ) . "- Add a success story or tip to the blog to keep members returning.\n\nTurn this email off in My Rishta > Quality and safety.";
		wp_mail( get_option( 'admin_email' ), 'Weekly report - ' . get_bloginfo( 'name' ), $body );
	}

	/* ---------- Quality and safety page ---------- */

	public static function clean() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		$o = self::get();
		echo '<div class="wrap"><h1>Quality and safety</h1>';
		if ( isset( $_GET['ok'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success is-dismissible"><p>Saved.</p></div>';
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_m4_save">';
		wp_nonce_field( 'mrsh_m4_save' );
		echo '<h2>Safety rules for new and edited profiles</h2><p class="description">A profile that breaks a rule goes back to "pending" and shows on the Today page with the reason. Profiles you approved yourself are not checked again.</p><table class="form-table"><tbody>';
		$cb = function ( $k, $l ) use ( $o ) {
			echo '<tr><th>' . esc_html( $l ) . '</th><td><label><input type="checkbox" name="' . esc_attr( $k ) . '" value="1"' . checked( ! empty( $o[ $k ] ), true, false ) . '> On</label></td></tr>';
		};
		$cb( 'rules', 'Use the safety rules' );
		$cb( 'phone_rule', 'Hold profiles that show a phone number' );
		$cb( 'link_rule', 'Hold profiles that show a link or social handle' );
		echo '<tr><th>Words to hold (one per line)</th><td><textarea name="words" rows="4" class="large-text">' . esc_textarea( (string) $o['words'] ) . '</textarea></td></tr>';
		$cb( 'report', 'Email me a report every Monday' );
		echo '</tbody></table><p><button class="button button-primary">Save</button></p></form>';

		// duplicates
		echo '<h2>Possible duplicate profiles</h2>';
		global $wpdb;
		$dups = $wpdb->get_results( "SELECT post_title t, COUNT(*) c, GROUP_CONCAT(ID) ids FROM {$wpdb->posts} WHERE post_type='" . self::CPT . "' AND post_status IN ('publish','pending','draft') AND post_title<>'' GROUP BY post_title HAVING c>1 ORDER BY c DESC LIMIT 25" ); // phpcs:ignore
		$ph   = $wpdb->get_results( "SELECT meta_value v, COUNT(*) c, GROUP_CONCAT(post_id) ids FROM {$wpdb->postmeta} WHERE meta_key IN ('custom-14','phone','mrt_phone') AND meta_value<>'' GROUP BY meta_value HAVING c>1 ORDER BY c DESC LIMIT 25" ); // phpcs:ignore
		if ( ! $dups && ! $ph ) {
			echo '<p>No duplicates found.</p>';
		} else {
			echo '<table class="widefat striped" style="max-width:900px"><thead><tr><th>Match</th><th>Profiles</th></tr></thead><tbody>';
			foreach ( $dups as $d ) {
				echo '<tr><td>Same name: ' . esc_html( $d->t ) . '</td><td>' . wp_kses_post( self::links( $d->ids ) ) . '</td></tr>';
			}
			foreach ( $ph as $d ) {
				echo '<tr><td>Same phone number (' . esc_html( substr( $d->v, 0, 4 ) . '***' ) . ')</td><td>' . wp_kses_post( self::links( $d->ids ) ) . '</td></tr>';
			}
			echo '</tbody></table><p class="description">Same names are often different people. Open both and compare photos before you act.</p>';
		}

		// matched tracker
		echo '<h2>Matched profiles (success stories)</h2><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="max-width:900px"><input type="hidden" name="action" value="mrsh_m4_save">';
		wp_nonce_field( 'mrsh_m4_save' );
		echo '<p>Profile ID 1 <input type="number" name="m_a" style="width:90px"> Profile ID 2 <input type="number" name="m_b" style="width:90px"> <label><input type="checkbox" name="m_c" value="1"> Both families agreed to a story</label> <button class="button">Mark as matched</button></p></form>';
		$mt = (array) get_option( 'mrsh_matched', array() );
		if ( $mt ) {
			echo '<table class="widefat striped" style="max-width:900px"><thead><tr><th>Date</th><th>Profiles</th><th>Consent for story</th></tr></thead><tbody>';
			foreach ( array_reverse( $mt ) as $m ) {
				echo '<tr><td>' . esc_html( $m['d'] ) . '</td><td>' . esc_html( get_the_title( $m['a'] ) ) . ' (#' . (int) $m['a'] . ') and ' . esc_html( get_the_title( $m['b'] ) ) . ' (#' . (int) $m['b'] . ')</td><td>' . ( ! empty( $m['c'] ) ? 'Yes' : 'Ask first' ) . '</td></tr>';
			}
			echo '</tbody></table>';
		}

		// restore readiness
		echo '<h2>Restore readiness</h2><p class="description">A quick check before you move to another host.</p>';
		$up   = wp_get_upload_dir();
		$miss = 0;
		$chk  = 0;
		foreach ( get_posts( array( 'post_type' => self::CPT, 'post_status' => 'publish', 'numberposts' => 40, 'fields' => 'ids', 'orderby' => 'rand' ) ) as $pid ) {
			$tid = get_post_thumbnail_id( $pid );
			if ( $tid ) {
				$chk++;
				$f = get_attached_file( $tid );
				if ( ! $f || ! file_exists( $f ) ) {
					$miss++;
				}
			}
		}
		$rows = array(
			array( 'Profiles live', self::count( array( 'post_status' => 'publish' ) ) > 0, self::count( array( 'post_status' => 'publish' ) ) . ' live profiles' ),
			array( 'Photo files exist (sample of ' . $chk . ')', 0 === $miss, $miss ? $miss . ' sampled photo files are missing from uploads' : 'All sampled photos found' ),
			array( 'Uploads folder writable', wp_is_writable( $up['basedir'] ), $up['basedir'] ),
			array( 'Daily jobs scheduled', (bool) wp_next_scheduled( 'mrsh_growth_daily' ), wp_next_scheduled( 'mrsh_growth_daily' ) ? 'Next run ' . gmdate( 'Y-m-d H:i', wp_next_scheduled( 'mrsh_growth_daily' ) ) . ' UTC' : 'Not scheduled. Deactivate and activate the plugin' ),
			array( 'Permalinks pretty', (bool) get_option( 'permalink_structure' ), (string) get_option( 'permalink_structure' ) ),
			array( 'Site address uses https', 0 === strpos( home_url(), 'https://' ), home_url() ),
		);
		echo '<table class="widefat striped" style="max-width:900px"><tbody>';
		foreach ( $rows as $r ) {
			echo '<tr><td style="width:44px;font-size:18px;color:' . ( $r[1] ? '#10b981' : '#ef4444' ) . '">' . ( $r[1] ? '&#10003;' : '&#10007;' ) . '</td><td><b>' . esc_html( $r[0] ) . '</b></td><td>' . esc_html( $r[2] ) . '</td></tr>';
		}
		echo '</tbody></table><p><a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_m4_export' ), 'mrsh_m4_export' ) ) . '">Download all My Rishta settings (JSON)</a></p><p class="description">Keep this file with your database backup. It holds every setting of this plugin (secret keys are left out).</p>';

		// urdu checker
		echo '<h2>Urdu coverage check</h2><p>Open any page of the website in Urdu with this check on. A panel lists the English words that are still showing, so you can send them to be translated.</p><p>';
		foreach ( array( '/' => 'Home', '/my-account/' => 'My account', '/add-profile/' => 'Add profile', '/memberships/' => 'Memberships', '/contact/' => 'Contact' ) as $p => $l ) {
			echo '<a class="button" target="_blank" href="' . esc_url( home_url( $p ) . '?lang=ur&mrt_urdu_check=1' ) . '">' . esc_html( $l ) . '</a> ';
		}
		echo '</p></div>';
	}

	private static function links( $ids ) {
		$o = array();
		foreach ( array_map( 'absint', explode( ',', $ids ) ) as $id ) {
			$o[] = '<a href="' . esc_url( get_edit_post_link( $id ) ) . '">#' . $id . '</a>';
		}
		return implode( ', ', $o );
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_m4_save' );
		if ( isset( $_POST['m_a'] ) ) { // phpcs:ignore
			$a = absint( $_POST['m_a'] ); // phpcs:ignore
			$b = absint( $_POST['m_b'] ?? 0 ); // phpcs:ignore
			if ( $a && $b && self::CPT === get_post_type( $a ) && self::CPT === get_post_type( $b ) ) {
				$mt   = (array) get_option( 'mrsh_matched', array() );
				$mt[] = array( 'a' => $a, 'b' => $b, 'd' => gmdate( 'Y-m-d' ), 'c' => empty( $_POST['m_c'] ) ? 0 : 1 ); // phpcs:ignore
				update_option( 'mrsh_matched', $mt, false );
				update_post_meta( $a, 'mrt_matched', $b );
				update_post_meta( $b, 'mrt_matched', $a );
				do_action( 'mrsh_matched_made', $a, $b );
			}
		} else {
			update_option( 'mrsh_m4', array(
				'rules' => empty( $_POST['rules'] ) ? 0 : 1, 'phone_rule' => empty( $_POST['phone_rule'] ) ? 0 : 1, 'link_rule' => empty( $_POST['link_rule'] ) ? 0 : 1,
				'report' => empty( $_POST['report'] ) ? 0 : 1, 'words' => sanitize_textarea_field( wp_unslash( $_POST['words'] ?? '' ) ), // phpcs:ignore
			), false );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-clean&ok=1' ) );
		exit;
	}

	public static function export() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_m4_export' );
		global $wpdb;
		$rows = $wpdb->get_results( "SELECT option_name n, option_value v FROM {$wpdb->options} WHERE option_name LIKE 'mrsh\\_%' OR option_name LIKE 'mrt\\_%' OR option_name LIKE 'myrishta%'" ); // phpcs:ignore
		$out  = array();
		foreach ( $rows as $r ) {
			if ( preg_match( '/key|secret|token|password|smtp|auth|vapid|license|sid|salt/i', $r->n ) || strpos( $r->n, '_transient' ) === 0 ) {
				continue;
			}
			$out[ $r->n ] = maybe_unserialize( $r->v );
		}
		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=myrishta-settings-' . gmdate( 'Y-m-d' ) . '.json' );
		echo wp_json_encode( $out, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ); // phpcs:ignore
		exit;
	}

	/* ---------- Urdu coverage checker (front end, admins only) ---------- */

	public static function urdu_check() {
		if ( ! isset( $_GET['mrt_urdu_check'] ) || ! current_user_can( 'manage_options' ) ) { // phpcs:ignore
			return;
		}
		echo '<div id="mrt-uc" style="position:fixed;z-index:99999;left:8px;right:8px;bottom:8px;max-height:46vh;overflow:auto;background:#111;color:#fff;border-radius:14px;padding:12px;font:13px/1.5 system-ui" dir="ltr"><b>Urdu check</b> <button type="button" id="mrt-uc-c" style="margin-left:8px">Copy list</button> <button type="button" onclick="this.parentNode.remove()" style="float:right">Close</button><pre id="mrt-uc-o" style="white-space:pre-wrap;margin:8px 0 0">Scanning...</pre></div>';
		echo '<script>setTimeout(function(){var s={},w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT),n;while(n=w.nextNode()){var p=n.parentElement;if(!p||/^(SCRIPT|STYLE|NOSCRIPT|TEXTAREA|CODE)$/.test(p.tagName)||p.closest("#mrt-uc,#wpadminbar"))continue;var t=n.nodeValue.replace(/\s+/g," ").trim();if(/[A-Za-z]{3,}/.test(t)&&!/[؀-ۿ]/.test(t)&&t.length<200)s[t]=1}var a=Object.keys(s);document.getElementById("mrt-uc-o").textContent=a.length?a.join("\n"):"Everything on this page is in Urdu.";document.getElementById("mrt-uc-c").onclick=function(){navigator.clipboard.writeText(a.join("\n"));this.textContent="Copied"}},2500);</script>';
	}
}
MRSH_Mem_More4::init();
