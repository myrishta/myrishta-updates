<?php
/**
 * Member emails in English and Urdu: one branded HTML layout, editable text, a test button.
 * Templates can be changed under Site settings > Emails. Placeholders: {name} {site} {link} {plan} {profile} {phone}.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Mem_Mail {

	/** key => array( label, [en subject, en body, ur subject, ur body] ) */
	public static function defaults() {
		return array(
			'welcome'   => array( 'Welcome (new member)', array(
				'Welcome to {site}',
				"Assalam o Alaikum {name},\n\nWelcome to {site}, a free rishta service for Pakistani families. Your account is ready.\n\nNext step: complete your profile and add a clear photo. Your phone number is never shown to others.\n\nNever send money to anyone you meet online.",
				'{site} میں خوش آمدید',
				"السلام علیکم {name}،\n\n{site} میں خوش آمدید۔ یہ پاکستانی خاندانوں کے لیے مفت رشتہ سروس ہے۔ آپ کا اکاؤنٹ تیار ہے۔\n\nاگلا مرحلہ: اپنا پروفائل مکمل کریں اور صاف تصویر لگائیں۔ آپ کا فون نمبر کسی کو نہیں دکھایا جاتا۔\n\nآن لائن ملنے والے کسی شخص کو کبھی رقم نہ بھیجیں۔",
			) ),
			'interest'  => array( 'New interest or message', array(
				'Someone is interested in your profile',
				"Assalam o Alaikum {name},\n\nYou have new activity on your profile. Log in to read it.\n\nNever send money, gifts or ID photos to someone you have not met. Involve your family.",
				'کسی نے آپ کے پروفائل میں دلچسپی ظاہر کی ہے',
				"السلام علیکم {name}،\n\nآپ کے پروفائل پر نئی سرگرمی ہوئی ہے۔ پڑھنے کے لیے لاگ اِن کریں۔\n\nجس سے ملے نہ ہوں اسے کبھی رقم، تحائف یا شناختی کارڈ کی تصاویر نہ بھیجیں۔ اپنے خاندان کو شامل رکھیں۔",
			) ),
			'live'      => array( 'Profile published', array(
				'Your profile is live',
				"Assalam o Alaikum {name},\n\nYour profile is now published and visible to members. Share it with your family and check your matches often.",
				'آپ کا پروفائل شائع ہو گیا ہے',
				"السلام علیکم {name}،\n\nآپ کا پروفائل اب شائع ہو چکا ہے اور اراکین کو نظر آ رہا ہے۔ اسے اپنے خاندان کے ساتھ شیئر کریں اور اپنے میچز دیکھتے رہیں۔",
			) ),
			'nudge1'    => array( 'Reminder 1: finish your profile', array(
				'{name}, your profile is almost ready',
				"Assalam o Alaikum {name},\n\nThank you for joining {site}. Your account is ready, but your profile is not created yet, so other families cannot see you.\n\nIt takes about 2 minutes: a few short questions, one step at a time. You can stop and come back, your answers are kept.\n\nYour phone number is never shown to others.",
				'{name}، آپ کا پروفائل بس تیار ہونے والا ہے',
				"السلام علیکم {name}،\n\n{site} میں شامل ہونے کا شکریہ۔ آپ کا اکاؤنٹ تیار ہے مگر پروفائل ابھی نہیں بنا، اس لیے دوسرے خاندان آپ کو دیکھ نہیں سکتے۔\n\nصرف تقریباً 2 منٹ لگتے ہیں: چند مختصر سوال، ایک وقت میں ایک مرحلہ۔ آپ رک کر واپس آ سکتے ہیں، آپ کے جوابات محفوظ رہتے ہیں۔\n\nآپ کا فون نمبر کسی کو نہیں دکھایا جاتا۔",
			) ),
			'nudge2'    => array( 'Reminder 2: last reminder to finish your profile', array(
				'A last reminder: finish your free profile',
				"Assalam o Alaikum {name},\n\nA quick last reminder from {site}. Complete profiles get many more replies, and it is free.\n\nJust press the button and answer a few short questions. If you need help, reply to this email and our team will help you.\n\nWe will not send more reminders about this.",
				'آخری یاددہانی: اپنا مفت پروفائل مکمل کریں',
				"السلام علیکم {name}،\n\n{site} کی طرف سے ایک مختصر آخری یاددہانی۔ مکمل پروفائل پر بہت زیادہ جوابات آتے ہیں، اور یہ مفت ہے۔\n\nبس بٹن دبائیں اور چند مختصر سوالوں کے جواب دیں۔ مدد چاہیے ہو تو اس ای میل کا جواب دیں، ہماری ٹیم مدد کرے گی۔\n\nاس بارے میں ہم مزید یاددہانی نہیں بھیجیں گے۔",
			) ),
			'namefix1'  => array( 'Please use your real name on your profile', array(
				'Please update the name on your profile',
				"Assalam o Alaikum {name},\n\nThank you for joining {site}. The name shown on your profile looks like a placeholder, not a real first name. Families trust profiles with real names, and they get many more replies.\n\nPlease open the link below and enter your real first name. It takes about a minute.\n\n{link}\n\nIf the name is already correct, you can ignore this message.",
				'براہ کرم اپنے پروفائل کا نام درست کریں',
				"السلام علیکم {name}،\n\n{site} میں شامل ہونے کا شکریہ۔ آپ کے پروفائل پر جو نام لکھا ہے وہ اصل پہلا نام نہیں لگتا۔ خاندان اصل نام والے پروفائلز پر زیادہ بھروسا کرتے ہیں اور ان کو زیادہ جواب ملتے ہیں۔\n\nبراہ کرم نیچے دیے گئے لنک پر جا کر اپنا اصل پہلا نام لکھ دیں۔ اس میں تقریباً ایک منٹ لگتا ہے۔\n\n{link}\n\nاگر نام پہلے سے درست ہے تو اس پیغام کو نظر انداز کر دیں۔",
			) ),
			'namefix2'  => array( 'Last reminder: use your real name', array(
				'A last reminder: please use your real name',
				"Assalam o Alaikum {name},\n\nA quick last reminder from {site}. Your profile name still looks like a placeholder. Profiles with a placeholder or a made-up name may be hidden from search to keep the site trusted for families.\n\nPlease enter your real first name here:\n\n{link}\n\nIf you need help, reply to this email.",
				'آخری یاددہانی: اپنا اصل نام لکھیں',
				"السلام علیکم {name}،\n\n{site} کی طرف سے ایک مختصر آخری یاددہانی۔ آپ کے پروفائل کا نام ابھی تک اصل نام نہیں لگتا۔ خاندانوں کا اعتماد برقرار رکھنے کے لیے عارضی یا من گھڑت نام والے پروفائلز سرچ سے چھپائے جا سکتے ہیں۔\n\nبراہ کرم یہاں اپنا اصل پہلا نام لکھ دیں:\n\n{link}\n\nمدد چاہیے ہو تو اس ای میل کا جواب دیں۔",
			) ),
			'verified'  => array( 'Verified by our team', array(
				'You are now verified',
				"Assalam o Alaikum {name},\n\nGood news. Our team verified your profile and a green Verified badge now shows on it. Verified profiles get more trust and more replies.",
				'آپ کی تصدیق ہو گئی ہے',
				"السلام علیکم {name}،\n\nخوشخبری۔ ہماری ٹیم نے آپ کے پروفائل کی تصدیق کر دی ہے اور اب اس پر سبز تصدیق شدہ نشان نظر آئے گا۔ تصدیق شدہ پروفائلز پر زیادہ اعتماد اور زیادہ جوابات آتے ہیں۔",
			) ),
			'unverified' => array( 'Verification not approved', array(
				'About your verification request',
				"Assalam o Alaikum {name},\n\nWe could not verify your profile yet. Please check that your photo is clear, your name and details are correct, then ask again from My account. You can also contact us for help.",
				'آپ کی تصدیق کی درخواست کے بارے میں',
				"السلام علیکم {name}،\n\nہم ابھی آپ کے پروفائل کی تصدیق نہیں کر سکے۔ براہِ کرم دیکھ لیں کہ تصویر صاف ہے اور نام اور تفصیلات درست ہیں، پھر میرے اکاؤنٹ سے دوبارہ درخواست دیں۔ مدد کے لیے ہم سے رابطہ بھی کر سکتے ہیں۔",
			) ),
			'plan'      => array( 'Membership plan assigned', array(
				'Your {plan} membership is active',
				"Assalam o Alaikum {name},\n\nYour {plan} membership is now active and its badge shows on your profile. Thank you for being with us.",
				'آپ کی {plan} رکنیت فعال ہو گئی ہے',
				"السلام علیکم {name}،\n\nآپ کی {plan} رکنیت اب فعال ہے اور اس کا نشان آپ کے پروفائل پر نظر آ رہا ہے۔ ہمارے ساتھ رہنے کا شکریہ۔",
			) ),
			'planreq'   => array( 'Membership request received', array(
				'We received your {plan} request',
				"Assalam o Alaikum {name},\n\nWe received your request for the {plan} plan. How to pay: {payinfo}\n\nPlease pay only to the details above or through our official contact, never to an agent.",
				'ہمیں آپ کی {plan} درخواست موصول ہو گئی',
				"السلام علیکم {name}،\n\nہمیں {plan} پلان کے لیے آپ کی درخواست مل گئی ہے۔ ادائیگی کا طریقہ: {payinfo}\n\nبراہِ کرم صرف اوپر دی گئی تفصیلات یا ہمارے سرکاری رابطے پر ادائیگی کریں، کسی ایجنٹ کو نہیں۔",
			) ),
			'phonereq'  => array( 'Phone number request', array(
				'A member asked for your phone number',
				"Assalam o Alaikum {name},\n\nA member asked to see your phone number. Log in to approve or decline. Your number is shared only if you approve.",
				'ایک رکن نے آپ کا فون نمبر مانگا ہے',
				"السلام علیکم {name}،\n\nایک رکن نے آپ کا فون نمبر دیکھنے کی درخواست کی ہے۔ منظور یا انکار کرنے کے لیے لاگ اِن کریں۔ آپ کا نمبر صرف منظوری کی صورت میں دکھایا جائے گا۔",
			) ),
			'contact'   => array( 'Contact form reply', array(
				'We received your message',
				"Assalam o Alaikum {name},\n\nThank you for contacting {site}. We received your message and will reply within 48 hours.",
				'ہمیں آپ کا پیغام مل گیا',
				"السلام علیکم {name}،\n\n{site} سے رابطہ کرنے کا شکریہ۔ ہمیں آپ کا پیغام مل گیا ہے اور ہم 48 گھنٹوں میں جواب دیں گے۔",
			) ),
			'news'      => array( 'Newsletter welcome', array(
				'You are on the list',
				"Assalam o Alaikum,\n\nThank you for joining the {site} newsletter. We send short rishta and safety tips, not spam.",
				'آپ فہرست میں شامل ہو گئے',
				"السلام علیکم،\n\n{site} نیوز لیٹر میں شامل ہونے کا شکریہ۔ ہم رشتہ اور حفاظت کے مختصر مشورے بھیجتے ہیں، سپیم نہیں۔",
			) ),

			'safety'    => array( 'Monthly safety reminder', array(
				'Monthly safety reminder',
				"Assalam o Alaikum {name},\n\nA short reminder to keep you safe:\n- Never send money, bank details or OTP codes to someone you have not met in person.\n- Meet in a public place and tell a family member.\n- Report any profile that asks for money or personal documents.\n\nStay safe, and involve your family.",
				'ماہانہ حفاظتی یاددہانی',
				"السلام علیکم {name}،\n\nآپ کی حفاظت کے لیے ایک مختصر یاددہانی:\n- جس سے ملاقات نہ ہوئی ہو اسے کبھی پیسے، بینک کی تفصیل یا OTP کوڈ نہ بھیجیں۔\n- ملاقات عوامی جگہ پر کریں اور گھر والوں کو بتائیں۔\n- جو پروفائل پیسے یا ذاتی دستاویزات مانگے اسے رپورٹ کریں۔\n\nمحفوظ رہیں، اور اپنے خاندان کو شامل رکھیں۔",
			) ),
			'match'     => array( 'New matches for your saved search', array(
				'New profiles match your saved search',
				"Assalam o Alaikum {name},\n\nNew profiles match your saved search. Log in to see them and send interest.\n\nRemember: never send money to anyone you meet online.",
				'آپ کی محفوظ تلاش سے نئے پروفائلز ملتے ہیں',
				"السلام علیکم {name}،\n\nآپ کی محفوظ تلاش سے نئے پروفائلز ملتے ہیں۔ انہیں دیکھنے اور دلچسپی بھیجنے کے لیے لاگ اِن کریں۔\n\nیاد رکھیں: آن لائن ملنے والے کسی شخص کو کبھی رقم نہ بھیجیں۔",
			) ),
			'reportack' => array( 'We received your report', array(
				'Thank you for your report',
				"Assalam o Alaikum {name},\n\nThank you for reporting a profile. Our team reviews every report, usually within 48 hours. You do not need to do anything else.\n\nIf you feel unsafe, stop replying and tell a family member.",
				'آپ کی رپورٹ موصول ہو گئی',
				"السلام علیکم {name}،\n\nکسی پروفائل کی رپورٹ کرنے کا شکریہ۔ ہماری ٹیم ہر رپورٹ دیکھتی ہے، عموماً 48 گھنٹوں میں۔ آپ کو کچھ اور کرنے کی ضرورت نہیں۔\n\nاگر آپ کو خطرہ محسوس ہو تو جواب دینا بند کریں اور گھر والوں کو بتائیں۔",
			) ),
			'paused'    => array( 'Profile paused by our team', array(
				'Your profile has been paused',
				"Assalam o Alaikum {name},\n\nYour profile {profile} has been paused while our team checks it. Please make sure your photo is yours and your details are correct. If you need help, contact us from My account.",
				'آپ کا پروفائل عارضی طور پر روک دیا گیا ہے',
				"السلام علیکم {name}،\n\nآپ کا پروفائل {profile} ہماری ٹیم کی جانچ تک عارضی طور پر روک دیا گیا ہے۔ براہِ کرم یقینی بنائیں کہ تصویر آپ کی اپنی ہے اور تفصیلات درست ہیں۔ مدد کے لیے میرے اکاؤنٹ سے ہم سے رابطہ کریں۔",
			) ),
			'photo'     => array( 'Photo review result', array(
				'About your profile photo',
				"Assalam o Alaikum {name},\n\nWe reviewed the photo on your profile. Please upload a clear photo of yourself with good lighting and a visible face. Photos of other people or celebrities are not allowed.",
				'آپ کی پروفائل تصویر کے بارے میں',
				"السلام علیکم {name}،\n\nہم نے آپ کے پروفائل کی تصویر دیکھی ہے۔ براہِ کرم اپنی صاف تصویر لگائیں جس میں روشنی اچھی ہو اور چہرہ نظر آئے۔ کسی اور شخص یا مشہور شخصیت کی تصویر کی اجازت نہیں۔",
			) ),
			'invite'    => array( 'Family invite', array(
				'{name} invited you to My Rishta',
				"Assalam o Alaikum,\n\n{name} invited you to join My Rishta, a free rishta service for Pakistani families. Create your profile with your family's help.\n\nNever pay anyone to join.",
				'{name} نے آپ کو مائی رشتہ میں مدعو کیا ہے',
				"السلام علیکم،\n\n{name} نے آپ کو مائی رشتہ میں شامل ہونے کی دعوت دی ہے۔ یہ پاکستانی خاندانوں کے لیے مفت رشتہ سروس ہے۔ اپنے خاندان کی مدد سے اپنا پروفائل بنائیں۔\n\nشامل ہونے کے لیے کسی کو کبھی پیسے نہ دیں۔",
			) ),
			'nudge'     => array( 'Finish your profile', array(
				'Finish your profile to get more replies',
				"Assalam o Alaikum {name},\n\nProfiles with a clear photo and complete details get more replies. Add your education, profession, city and a short 'looking for' note to finish your profile.",
				'اپنا پروفائل مکمل کریں',
				"السلام علیکم {name}،\n\nصاف تصویر اور مکمل تفصیلات والے پروفائلز کو زیادہ جواب ملتے ہیں۔ اپنی تعلیم، پیشہ، شہر اور مختصر 'تلاش' لکھ کر پروفائل مکمل کریں۔",
			) ),
			'moneyblock' => array( 'Message stopped for safety', array(
				'A message was stopped for your safety',
				"Assalam o Alaikum {name},\n\nA message you tried to send asked for money, so it was not delivered. Our system blocks requests for money to protect members.\n\nIf someone you have not met asks you to pay, do not send money and report them.",
				'حفاظت کے لیے ایک پیغام روک دیا گیا',
				"السلام علیکم {name}،\n\nآپ نے جو پیغام بھیجنے کی کوشش کی وہ پیسوں کی درخواست پر مشتمل تھا، اس لیے پہنچایا نہیں گیا۔ ہمارا نظام اراکین کی حفاظت کے لیے پیسوں کی درخواستیں روکتا ہے۔\n\nاگر کوئی ایسا شخص جس سے ملاقات نہ ہوئی ہو ادائیگی مانگے تو رقم نہ بھیجیں اور اسے رپورٹ کریں۔",
			) ),

			'digest'    => array( 'Weekly profile views', array(
				'People viewed your profile this week',
				"Assalam o Alaikum {name},\n\n{count} people viewed your profile this week. Log in to see your matches and send interest.\n\nNever send money to anyone you meet online.",
				'اس ہفتے آپ کا پروفائل {count} لوگوں نے دیکھا',
				"السلام علیکم {name}،\n\nاس ہفتے {count} لوگوں نے آپ کا پروفائل دیکھا۔ اپنے میچز دیکھنے اور دلچسپی بھیجنے کے لیے لاگ اِن کریں۔\n\nآن لائن ملنے والے کسی شخص کو کبھی رقم نہ بھیجیں۔",
			) ),
		);
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 20 );
		add_action( 'admin_post_mrsh_mail_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_mrsh_mail_test', array( __CLASS__, 'test' ) );
		add_action( 'user_register', function ( $uid ) {
			$u = get_userdata( $uid );
			if ( $u && ! user_can( $u, 'manage_options' ) && ! defined( 'WP_IMPORTING' ) ) {
				self::send( $u->user_email, 'welcome', array( 'name' => $u->display_name ? $u->display_name : $u->user_login, 'link' => self::acct() ) );
			}
		}, 30 );
		add_action( 'transition_post_status', function ( $new, $old, $post ) {
			if ( 'listing_type' === $post->post_type && 'publish' === $new && 'publish' !== $old && ! get_post_meta( $post->ID, '_mrsh_live_mail', true ) ) {
				update_post_meta( $post->ID, '_mrsh_live_mail', time() );
				$u = get_userdata( (int) $post->post_author );
				if ( $u && ! user_can( $u, 'manage_options' ) ) {
					self::send( $u->user_email, 'live', array( 'name' => $u->display_name, 'link' => get_permalink( $post ), 'profile' => $post->post_title ) );
				}
			}
		}, 10, 3 );
		add_action( 'updated_user_meta', array( __CLASS__, 'on_meta' ), 10, 4 );
		add_action( 'added_user_meta', array( __CLASS__, 'on_meta' ), 10, 4 );
	}

	/** Verified and plan emails are sent when the meta changes, wherever it was changed from. */
	public static function on_meta( $mid, $uid, $key, $val ) {
		$u = get_userdata( $uid );
		if ( ! $u || ! $val ) {
			return;
		}
		$name = $u->display_name ? $u->display_name : $u->user_login;
		if ( '_mrsh_id_verified' === $key && ! get_transient( 'mrsh_mv_' . $uid ) ) {
			set_transient( 'mrsh_mv_' . $uid, 1, DAY_IN_SECONDS );
			self::send( $u->user_email, 'verified', array( 'name' => $name, 'link' => self::acct() ) );
		}
		if ( 'mrt_plan' === $key && ! get_transient( 'mrsh_mp_' . $uid . md5( (string) $val ) ) ) {
			set_transient( 'mrsh_mp_' . $uid . md5( (string) $val ), 1, DAY_IN_SECONDS );
			self::send( $u->user_email, 'plan', array( 'name' => $name, 'plan' => (string) $val, 'link' => self::acct() ) );
		}
		if ( 'mrt_plan_req' === $key && ! get_transient( 'mrsh_mr_' . $uid . md5( (string) $val ) ) ) {
			set_transient( 'mrsh_mr_' . $uid . md5( (string) $val ), 1, DAY_IN_SECONDS );
			self::send( $u->user_email, 'planreq', array( 'name' => $name, 'plan' => (string) $val, 'link' => self::acct() ) );
		}
	}

	public static function acct() {
		return function_exists( 'mrt_link' ) ? mrt_link( 'myaccount', '/my-account/' ) : home_url( '/my-account/' );
	}

	public static function opts() {
		$o = get_option( 'mrsh_mail', array() );
		return is_array( $o ) ? $o : array();
	}

	/** Text for one template: saved edit, else the default. Returns array( en subj, en body, ur subj, ur body ). */
	public static function tpl( $key ) {
		$d = self::defaults();
		if ( ! isset( $d[ $key ] ) ) {
			return null;
		}
		$t = $d[ $key ][1];
		$o = self::opts();
		foreach ( array( 'es', 'eb', 'us', 'ub' ) as $i => $f ) {
			if ( ! empty( $o['t'][ $key ][ $f ] ) ) {
				$t[ $i ] = (string) $o['t'][ $key ][ $f ];
			}
		}
		return $t;
	}

	private static function fill( $s, $v ) {
		$v += array( 'name' => '', 'link' => home_url( '/' ), 'plan' => '', 'profile' => '', 'phone' => '' );
		$v['site'] = get_bloginfo( 'name' );
		$pi        = function_exists( 'mrt_site' ) ? trim( (string) mrt_site( 'payinfo', '' ) ) : '';
		$v['payinfo'] = '' !== $pi ? $pi : 'our team will send you the details.';
		foreach ( $v as $k => $x ) {
			$s = str_replace( '{' . $k . '}', (string) $x, $s );
		}
		return $s;
	}

	/** Lay out one email: brand bar, English block, Urdu block (right to left), button, footer. */
	public static function html( $key, $v ) {
		$t = self::tpl( $key );
		if ( ! $t ) {
			return array( '', '' );
		}
		$o    = self::opts();
		$mode = isset( $o['lang'] ) ? $o['lang'] : 'both';
		$v    = (array) $v;
		$link = isset( $v['link'] ) ? $v['link'] : home_url( '/' );
		$site = get_bloginfo( 'name' );
		$blk  = function ( $body, $rtl ) use ( $v ) {
			$b = nl2br( esc_html( self::fill( $body, $v ) ) );
			return '<div style="padding:18px 22px;font-size:16px;line-height:1.7;color:#1f2430;' . ( $rtl ? 'direction:rtl;text-align:right;font-family:\'Noto Nastaliq Urdu\',\'Jameel Noori Nastaleeq\',Tahoma,Arial,sans-serif;line-height:2.1;' : '' ) . '"' . ( $rtl ? ' dir="rtl" lang="ur"' : '' ) . '>' . $b . '</div>';
		};
		$btn  = function ( $label, $rtl ) use ( $link ) {
			return '<div style="padding:0 22px 18px;' . ( $rtl ? 'text-align:right;direction:rtl' : '' ) . '"><a href="' . esc_url( $link ) . '" style="display:inline-block;background:#e11d74;color:#fff;text-decoration:none;padding:11px 22px;border-radius:10px;font-weight:700;font-family:Arial,sans-serif">' . esc_html( $label ) . '</a></div>';
		};
		$rv   = ( 'live' === $key && class_exists( 'MRSH_Gbp' ) ) ? MRSH_Gbp::review_ask_url() : '';
		$rev  = function ( $rtl ) use ( $rv ) {
			if ( '' === $rv ) {
				return '';
			}
			$txt = $rtl ? 'اگر ہماری سروس پسند آئی تو گوگل پر مختصر سچا تبصرہ لکھ کر دوسرے خاندانوں کی مدد کریں۔' : 'Happy with our free service? A short honest Google review helps other families find us.';
			$lbl = $rtl ? 'گوگل پر تبصرہ لکھیں' : 'Review us on Google';
			return '<div style="padding:0 22px 18px;font-size:14px;line-height:1.7;color:#4b5563;' . ( $rtl ? 'direction:rtl;text-align:right;' : '' ) . '"' . ( $rtl ? ' dir="rtl" lang="ur"' : '' ) . '>' . esc_html( $txt ) . '<br><a href="' . esc_url( $rv ) . '" style="color:#7c3aed;font-weight:700">' . esc_html( $lbl ) . '</a></div>';
		};
		$body = '';
		$subj = self::fill( 'ur' === $mode ? $t[2] : $t[0], $v );
		if ( 'ur' !== $mode ) {
			$body .= $blk( $t[1], false ) . $btn( 'Open My Rishta', false ) . $rev( false );
		}
		if ( 'en' !== $mode ) {
			if ( 'both' === $mode ) {
				$body .= '<div style="border-top:1px dashed #e5e7eb;margin:0 22px"></div>';
			}
			$body .= $blk( $t[3], true ) . $btn( 'مائی رشتہ کھولیں', true ) . $rev( true );
		}
		if ( 'both' === $mode ) {
			$subj = self::fill( $t[0], $v ) . ' | ' . self::fill( $t[2], $v );
		}
		$out = '<!doctype html><html><body style="margin:0;background:#f3f4f8"><div style="max-width:600px;margin:0 auto;padding:16px"><div style="background:#fff;border-radius:16px;overflow:hidden;border:1px solid #e5e7eb">'
			. '<div style="background:linear-gradient(110deg,#e11d74,#7c3aed);color:#fff;padding:16px 22px;font-size:20px;font-weight:800;font-family:Arial,sans-serif">' . esc_html( $site ) . '</div>'
			. $body
			. '<div style="background:#f9fafb;padding:12px 22px;font-size:12px;color:#6b7280;font-family:Arial,sans-serif;line-height:1.5">We never ask for money or ID photos by email. / ہم ای میل پر کبھی رقم یا شناختی کارڈ کی تصاویر نہیں مانگتے۔<br>' . esc_html( $site ) . ' &middot; ' . esc_html( home_url( '/' ) ) . '</div>'
			. '</div></div></body></html>';
		return array( $subj, $out );
	}

	/** Send a templated email. Returns true when handed to the mail system. */
	public static function send( $to, $key, $vars = array() ) {
		$o = self::opts();
		if ( ! is_email( $to ) || ( isset( $o['off'][ $key ] ) && $o['off'][ $key ] ) ) {
			return false;
		}
		list( $subj, $html ) = self::html( $key, $vars );
		if ( ! $html ) {
			return false;
		}
		$h = array( 'Content-Type: text/html; charset=UTF-8' );
		if ( ! empty( $o['from_name'] ) ) {
			$fn = wp_specialchars_decode( $o['from_name'], ENT_QUOTES );
			$h[] = 'From: ' . $fn . ' <' . ( function_exists( 'mrt_site' ) && mrt_site( 'email' ) ? sanitize_email( mrt_site( 'email' ) ) : get_option( 'admin_email' ) ) . '>';
		}
		$h[] = 'Reply-To: ' . ( function_exists( 'mrt_site' ) && is_email( mrt_site( 'email' ) ) ? mrt_site( 'email' ) : get_option( 'admin_email' ) );
		return (bool) wp_mail( $to, $subj, $html, $h );
	}

	/* ---------- admin ---------- */
	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Emails', 'Emails', 'manage_options', 'mrsh-mail', array( __CLASS__, 'page' ) );
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$o  = self::opts();
		$d  = self::defaults();
		$lg = isset( $o['lang'] ) ? $o['lang'] : 'both';
		echo '<div class="wrap"><h1>Emails to members</h1><p>Every email is sent in English and Urdu (you can choose one). Edit the text if you like; leave a box as it is to keep the built-in text. Placeholders: <code>{name} {site} {link} {plan} {profile}</code>.</p>';
		if ( isset( $_GET['saved'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success"><p>Saved.</p></div>';
		}
		if ( isset( $_GET['tested'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-info"><p>Test email handed to the mail system (' . ( '1' === $_GET['tested'] ? 'sent' : 'failed' ) . '). Check your inbox and spam folder.</p></div>'; // phpcs:ignore
		}
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="mrsh_mail_save">';
		wp_nonce_field( 'mrsh_mail' );
		echo '<p><label><b>Language</b> <select name="lang">';
		foreach ( array( 'both' => 'English and Urdu', 'en' => 'English only', 'ur' => 'Urdu only' ) as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $lg, $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select></label> &nbsp; <label><b>Sender name</b> <input name="from_name" value="' . esc_attr( isset( $o['from_name'] ) ? $o['from_name'] : '' ) . '" placeholder="' . esc_attr( get_bloginfo( 'name' ) ) . '"></label></p>';
		foreach ( $d as $k => $row ) {
			$t = self::tpl( $k );
			$s = isset( $o['t'][ $k ] ) ? $o['t'][ $k ] : array();
			echo '<details style="background:#fff;border:1px solid #dcdcde;border-radius:8px;margin:8px 0;padding:8px 12px"><summary><b>' . esc_html( $row[0] ) . '</b></summary>';
			echo '<p><label><input type="checkbox" name="off[' . esc_attr( $k ) . ']" value="1"' . checked( ! empty( $o['off'][ $k ] ), true, false ) . '> Do not send this email</label></p>';
			echo '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px"><div><b>English subject</b><input class="widefat" name="t[' . esc_attr( $k ) . '][es]" value="' . esc_attr( isset( $s['es'] ) ? $s['es'] : '' ) . '" placeholder="' . esc_attr( $row[1][0] ) . '"><b>English text</b><textarea class="widefat" rows="6" name="t[' . esc_attr( $k ) . '][eb]" placeholder="' . esc_attr( $row[1][1] ) . '">' . esc_textarea( isset( $s['eb'] ) ? $s['eb'] : '' ) . '</textarea></div>';
			echo '<div dir="rtl"><b>اردو موضوع</b><input class="widefat" name="t[' . esc_attr( $k ) . '][us]" value="' . esc_attr( isset( $s['us'] ) ? $s['us'] : '' ) . '" placeholder="' . esc_attr( $row[1][2] ) . '"><b>اردو متن</b><textarea class="widefat" rows="6" name="t[' . esc_attr( $k ) . '][ub]" placeholder="' . esc_attr( $row[1][3] ) . '">' . esc_textarea( isset( $s['ub'] ) ? $s['ub'] : '' ) . '</textarea></div></div>';
			echo '<p><a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mrsh_mail_test&key=' . $k ), 'mrsh_mail_test' ) ) . '">Send me a test</a></p></details>';
		}
		echo '<p><button class="button button-primary">Save emails</button></p></form></div>';
	}

	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_mail' );
		$o   = array( 'lang' => 'both', 'from_name' => '', 't' => array(), 'off' => array() );
		$lg  = isset( $_POST['lang'] ) ? sanitize_key( wp_unslash( $_POST['lang'] ) ) : 'both';
		$o['lang']      = in_array( $lg, array( 'both', 'en', 'ur' ), true ) ? $lg : 'both';
		$o['from_name'] = isset( $_POST['from_name'] ) ? sanitize_text_field( wp_unslash( $_POST['from_name'] ) ) : '';
		$d = self::defaults();
		foreach ( $d as $k => $row ) {
			$o['off'][ $k ] = ! empty( $_POST['off'][ $k ] ) ? 1 : 0; // phpcs:ignore
			foreach ( array( 'es', 'eb', 'us', 'ub' ) as $f ) {
				$x = isset( $_POST['t'][ $k ][ $f ] ) ? wp_unslash( $_POST['t'][ $k ][ $f ] ) : ''; // phpcs:ignore
				$o['t'][ $k ][ $f ] = in_array( $f, array( 'es', 'us' ), true ) ? sanitize_text_field( $x ) : sanitize_textarea_field( $x );
			}
		}
		update_option( 'mrsh_mail', $o, false );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-mail&saved=1' ) );
		exit;
	}

	public static function test() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_mail_test' );
		$k  = isset( $_GET['key'] ) ? sanitize_key( wp_unslash( $_GET['key'] ) ) : 'welcome';
		$u  = wp_get_current_user();
		$ok = self::send( $u->user_email, $k, array( 'name' => $u->display_name, 'plan' => 'Gold', 'profile' => 'Test profile', 'link' => self::acct() ) );
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-mail&tested=' . ( $ok ? '1' : '0' ) ) );
		exit;
	}
}
MRSH_Mem_Mail::init();
