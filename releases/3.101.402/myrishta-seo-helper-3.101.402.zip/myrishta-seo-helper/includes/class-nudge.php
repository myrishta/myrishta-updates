<?php
/**
 * Profile reminders: a gentle email to members whose profile is missing a photo, text or details.
 * Honest by design: the "views" line is only used when the profile really has views, every email has an unsubscribe link,
 * there is a limit on how many reminders one member gets, and it stops by itself once the profile is complete.
 * Off until the admin switches it on.
 */
defined( 'ABSPATH' ) || exit;

class MRSH_Nudge {
	const OPT  = 'mrsh_nudge';
	const HOOK = 'mrsh_nudge_run';
	const LOG  = 'mrsh_nudge_log';
	const CPT  = 'listing_type';

	public static function get() {
		$o = get_option( self::OPT, array() );
		return wp_parse_args( is_array( $o ) ? $o : array(), array(
			'on'      => 0,
			'every'   => 2,   // (old) days between reminders; used only when every_h is 0.
			'every_h' => 36,  // hours between reminders.
			'verify'  => 1,   // also remind members who have not confirmed their email.
			'max'     => 4,   // most reminders one member ever gets.
			'batch'   => 20,  // most emails sent per hourly run.
			'min_age' => 1,   // member must be at least this many days old.
			'goal'    => 80,  // profile counts as complete at this percent.
		) );
	}

	public static function init() {
		add_action( self::HOOK, array( __CLASS__, 'run' ) );
		add_action( 'init', array( __CLASS__, 'confirm_email' ), 1 );
		add_action( 'after_password_reset', function ( $u ) {
			if ( $u && ! empty( $u->ID ) ) {
				update_user_meta( $u->ID, 'mrsh_email_ok', time() );
			}
		} );
		add_action( 'init', array( __CLASS__, 'schedule' ) );
		add_action( 'init', array( __CLASS__, 'unsubscribe' ) );
		if ( is_admin() ) {
			add_action( 'admin_menu', array( __CLASS__, 'menu' ), 25 );
			foreach ( array( 'save', 'test', 'run_now', 'reset' ) as $a ) {
				add_action( 'admin_post_mrsh_nudge_' . $a, array( __CLASS__, 'act_' . $a ) );
			}
		}
	}

	public static function schedule() {
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + 600, 'hourly', self::HOOK );
		}
	}

	/* ---------- profile facts ---------- */

	/** The member's profile posts (any status that is shown or waiting). */
	private static function profiles( $uid ) {
		return get_posts( array( 'post_type' => self::CPT, 'author' => $uid, 'post_status' => array( 'publish', 'draft', 'pending' ), 'numberposts' => 5, 'orderby' => 'date', 'order' => 'DESC' ) );
	}

	private static function views( $ids ) {
		$n = 0;
		foreach ( $ids as $id ) {
			$d = get_post_meta( $id, 'hits_array', true );
			if ( is_array( $d ) ) {
				foreach ( $d as $h ) {
					$n += isset( $h['hits'] ) ? (int) $h['hits'] : 0;
				}
			}
		}
		return $n;
	}

	/**
	 * Score 0 to 100 and the list of what is missing. Photo 30, a few lines about yourself 20, the rest is the share of the
	 * profile's detail groups (religion, education, occupation and so on) that have a value.
	 */
	public static function score( $post ) {
		$miss = array();
		$pts  = 0;
		if ( has_post_thumbnail( $post ) ) {
			$pts += 30;
		} else {
			$miss[] = array( 'a clear photo', 'صاف تصویر' );
		}
		if ( strlen( trim( wp_strip_all_tags( (string) $post->post_content ) ) ) >= 40 ) {
			$pts += 20;
		} else {
			$miss[] = array( 'a few lines about yourself', 'اپنے بارے میں چند سطریں' );
		}
		// The site's own required profile fields (option "cfields", parallel arrays). Phone is never asked for by email.
		$cf    = get_option( 'cfields' );
		$names = array();
		$total = 0;
		$have  = 0;
		if ( is_array( $cf ) && ! empty( $cf['dbkey'] ) ) {
			foreach ( (array) $cf['dbkey'] as $n => $key ) {
				$req  = isset( $cf['required'][ $n ] ) && 'yes' === $cf['required'][ $n ];
				$type = isset( $cf['fieldtype'][ $n ] ) ? $cf['fieldtype'][ $n ] : '';
				$name = isset( $cf['name'][ $n ] ) ? trim( (string) $cf['name'][ $n ] ) : '';
				if ( ! $req || '' === $name || 'title' === $type || preg_match( '/phone|mobile|contact|whatsapp/i', $name . ' ' . $key ) ) {
					continue;
				}
				$total++;
				$val = get_post_meta( $post->ID, $key, true );
				$ok  = is_array( $val ) ? ! empty( $val ) : '' !== trim( (string) $val );
				if ( ! $ok && 'country' === ( isset( $cf['taxonomy'][ $n ] ) ? $cf['taxonomy'][ $n ] : '' ) && taxonomy_exists( 'country' ) ) {
					$t  = wp_get_object_terms( $post->ID, 'country', array( 'fields' => 'ids' ) );
					$ok = ! is_wp_error( $t ) && $t;
				}
				if ( $ok ) {
					$have++;
				} else {
					$names[] = strtolower( $name );
				}
			}
		}
		if ( $total ) {
			$pts += (int) round( 50 * $have / $total );
			if ( $names ) {
				$miss[] = array( 'your ' . implode( ', ', array_slice( array_unique( $names ), 0, 6 ) ), 'آپ کی مطلوبہ تفصیلات (مذہب، تعلیم، پیشہ وغیرہ)' );
			}
		} else {
			$pts += 50;
		}
		return array( min( 100, $pts ), $miss );
	}

	/** Everything the email needs about one member, or null when there is nothing to remind about. */
	public static function status( $user ) {
		$s    = self::get();
		$list = self::profiles( $user->ID );
		$ev   = ! empty( $s['verify'] ) && ! get_user_meta( $user->ID, 'mrsh_email_ok', true );
		if ( ! $list ) {
			return array( 'kind' => 'none', 'score' => 0, 'miss' => array( array( 'your free profile', 'اپنا مفت پروفائل' ) ), 'views' => 0, 'ev' => $ev, 'ev_only' => false );
		}
		$best = null;
		foreach ( $list as $p ) {
			$sc = self::score( $p );
			if ( null === $best || $sc[0] > $best['score'] ) {
				$best = array( 'kind' => 'part', 'score' => $sc[0], 'miss' => $sc[1], 'views' => 0, 'ev' => $ev, 'ev_only' => false );
			}
		}
		$best['views'] = self::views( wp_list_pluck( $list, 'ID' ) );
		if ( $best['score'] >= (int) $s['goal'] ) {
			if ( ! $ev ) {
				return null;
			}
			$best['ev_only'] = true;
			$best['miss']    = array();
		}
		return $best;
	}

	private static function eligible( $user, $s ) {
		if ( user_can( $user, 'manage_options' ) || user_can( $user, 'publish_posts' ) || user_can( $user, 'edit_others_posts' ) ) {
			return false;
		}
		if ( get_user_meta( $user->ID, 'mrsh_nudge_stop', true ) ) {
			return false;
		}
		if ( (int) get_user_meta( $user->ID, 'mrsh_nudge_count', true ) >= (int) $s['max'] ) {
			return false;
		}
		$age = ( time() - strtotime( $user->user_registered . ' UTC' ) ) / DAY_IN_SECONDS;
		if ( $age < (int) $s['min_age'] ) {
			return false;
		}
		$last = (int) get_user_meta( $user->ID, 'mrsh_nudge_last', true );
		$gap = (int) $s['every_h'] > 0 ? (int) $s['every_h'] * HOUR_IN_SECONDS : (int) $s['every'] * DAY_IN_SECONDS;
		if ( $last && ( time() - $last ) < $gap - 600 ) {
			return false;
		}
		return is_email( $user->user_email );
	}

	/* ---------- the email ---------- */

	private static function unsub_url( $uid ) {
		return add_query_arg( array( 'mrsh_unsub' => $uid, 't' => hash_hmac( 'sha256', 'nudge' . $uid, wp_salt( 'auth' ) ) ), home_url( '/' ) );
	}

	public static function ev_url( $uid ) {
		return add_query_arg( array( 'mrsh_ev' => $uid, 't' => hash_hmac( 'sha256', 'ev' . $uid, wp_salt( 'auth' ) ) ), home_url( '/' ) );
	}

	/** The link in the email: marks the email as confirmed, no login needed. */
	public static function confirm_email() {
		if ( empty( $_GET['mrsh_ev'] ) || empty( $_GET['t'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$uid = (int) $_GET['mrsh_ev']; // phpcs:ignore WordPress.Security.NonceVerification
		$t   = sanitize_text_field( wp_unslash( $_GET['t'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( $uid > 0 && hash_equals( hash_hmac( 'sha256', 'ev' . $uid, wp_salt( 'auth' ) ), $t ) && get_userdata( $uid ) ) {
			update_user_meta( $uid, 'mrsh_email_ok', time() );
			delete_transient( 'mrsh_cnt' );
			wp_die( '<p style="font-size:18px">Thank you. Your email is confirmed.<br>شکریہ، آپ کا ای میل تصدیق ہو گیا ہے۔</p><p><a href="' . esc_url( home_url( '/my-account/' ) ) . '">Go to my account</a></p>', 'Email confirmed', array( 'response' => 200 ) );
		}
	}

	public static function build( $user, $st, $n ) {
		$name  = '' !== trim( (string) $user->display_name ) ? trim( $user->display_name ) : 'there';
		$url   = home_url( $st['kind'] === 'none' ? '/add-listing/' : '/my-account/' );
		$views = (int) $st['views'];
		$en    = array();
		$ur    = array();
		if ( ! empty( $st['ev_only'] ) ) {
			$en[] = 'Your profile looks good. One last step: please confirm your email address so we know it is really you.';
			$ur[] = 'آپ کا پروفائل اچھا ہے۔ آخری قدم: براہ کرم اپنا ای میل تصدیق کریں تاکہ ہمیں معلوم ہو کہ یہ آپ ہی ہیں۔';
		} elseif ( $views > 0 ) {
			$en[] = 'Good news: your profile has been viewed ' . number_format_i18n( $views ) . ( 1 === $views ? ' time' : ' times' ) . ' on My Rishta Pakistan.';
			$ur[] = 'خوشخبری: مائی رشتہ پاکستان پر آپ کا پروفائل ' . number_format_i18n( $views ) . ' بار دیکھا جا چکا ہے۔';
			$en[] = 'A complete profile helps those families trust it and reply.';
			$ur[] = 'مکمل پروفائل پر خاندان زیادہ اعتماد کرتے ہیں۔';
		} elseif ( 'none' === $st['kind'] ) {
			$en[] = 'You joined My Rishta Pakistan, but your free profile is not created yet. Families can only find you once it is.';
			$ur[] = 'آپ مائی رشتہ پاکستان میں شامل ہوئے مگر آپ کا مفت پروفائل ابھی نہیں بنا۔';
		} else {
			$en[] = 'Your profile is almost ready. Families trust profiles that are clear and complete.';
			$ur[] = 'آپ کا پروفائل تقریباً تیار ہے۔ خاندان واضح اور مکمل پروفائل پر زیادہ اعتماد کرتے ہیں۔';
		}
		$todo_en = array();
		$todo_ur = array();
		foreach ( $st['miss'] as $m ) {
			$todo_en[] = $m[0];
			$todo_ur[] = $m[1];
		}
		if ( 'none' !== $st['kind'] && $todo_en ) {
			$en[] = 'To finish, please add: ' . implode( ', ', $todo_en ) . '.';
			$ur[] = 'مکمل کرنے کے لیے یہ شامل کریں: ' . implode( '، ', $todo_ur ) . '۔';
		}
		$evurl = ! empty( $st['ev'] ) ? self::ev_url( $user->ID ) : '';
		if ( $evurl ) {
			$en[] = 'Confirm your email (one click): ' . $evurl;
			$ur[] = 'ای میل تصدیق کرنے کے لیے یہاں کلک کریں: ' . $evurl;
		}
		$nophoto = false;
		foreach ( $st['miss'] as $m ) {
			if ( 'a clear photo' === $m[0] ) {
				$nophoto = true;
			}
		}
		if ( $nophoto && 'none' !== $st['kind'] ) {
			array_unshift( $en, 'Your profile has no photo yet. Profiles with a clear photo get far more replies.' );
			array_unshift( $ur, 'آپ کے پروفائل پر ابھی تصویر نہیں ہے۔ صاف تصویر والے پروفائل پر زیادہ جواب آتے ہیں۔' );
		}
		$subject = ! empty( $st['ev_only'] ) ? 'Please confirm your email on My Rishta Pakistan' : ( $nophoto && 'none' !== $st['kind'] ? 'Please add your photo to your My Rishta profile' : ( $views > 0 ? 'Your profile was viewed ' . number_format_i18n( $views ) . ' times: finish it on My Rishta' : ( 'none' === $st['kind'] ? 'Create your free profile on My Rishta Pakistan' : 'Finish your profile on My Rishta Pakistan' ) ) );
		$body    = 'Assalamualaikum ' . $name . ",\n\n" . implode( "\n", $en ) . "\n\nComplete it here (free): " . $url . "\n\n"
			. 'Rules for photos and text: ' . home_url( '/profile-guidelines/' ) . "\n\n"
			. "السلام علیکم،\n\n" . implode( "\n", $ur ) . "\n\n" . $url . "\n\n"
			. "My Rishta Pakistan, a free non-profit service in Lahore.\n" . home_url( '/' ) . "\n\n"
			. 'You get a few reminders only until your profile is complete. To stop them now: ' . self::unsub_url( $user->ID ) . "\n";
		return array( $subject, $body );
	}

	private static function send( $user, $st, $n ) {
		list( $subject, $body ) = self::build( $user, $st, $n );
		$un   = self::unsub_url( $user->ID );
		$hdr  = array(
			'Reply-To: My Rishta Support <support@myrishta.pk>',
			'List-Unsubscribe: <' . $un . '>, <mailto:support@myrishta.pk?subject=Unsubscribe>',
			'List-Unsubscribe-Post: List-Unsubscribe=One-Click',
		);
		$html = '<div style="font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.65;color:#222;max-width:560px;margin:0 auto;padding:8px">' . nl2br( make_clickable( esc_html( $body ) ) ) . '</div>';
		if ( class_exists( 'MRSH_Mailq' ) ) {
			// Queued: sent a few at a time, retried if the host fails, and never lost.
			return (bool) MRSH_Mailq::add( $user->user_email, $subject, $body, array( 'html' => $html, 'headers' => $hdr, 'kind' => 'nudge', 'uid' => $user->ID ) );
		}
		return wp_mail( $user->user_email, $subject, $body, $hdr );
	}

	/* ---------- the hourly run ---------- */

	public static function run( $force = false ) {
		$s = self::get();
		if ( empty( $s['on'] ) && ! $force ) {
			return 0;
		}
		$sent  = 0;
		$limit = max( 1, min( 50, (int) $s['batch'] ) );
		$ids   = get_users( array( 'fields' => 'ID', 'number' => 1000, 'orderby' => 'registered', 'order' => 'ASC' ) );
		foreach ( $ids as $id ) {
			if ( $sent >= $limit ) {
				break;
			}
			$u = get_userdata( $id );
			if ( ! $u || ! self::eligible( $u, $s ) ) {
				continue;
			}
			$st = self::status( $u );
			if ( null === $st ) {
				update_user_meta( $u->ID, 'mrsh_nudge_done', time() );
				continue;
			}
			$n = (int) get_user_meta( $u->ID, 'mrsh_nudge_count', true ) + 1;
			if ( self::send( $u, $st, $n ) ) {
				update_user_meta( $u->ID, 'mrsh_nudge_count', $n );
				update_user_meta( $u->ID, 'mrsh_nudge_last', time() );
				self::log( $u->ID, $st, $n );
				$sent++;
			}
		}
		return $sent;
	}

	private static function log( $uid, $st, $n ) {
		$l   = get_option( self::LOG, array() );
		$l   = is_array( $l ) ? $l : array();
		$l[] = array( 't' => time(), 'u' => $uid, 'n' => $n, 's' => (int) $st['score'], 'v' => (int) $st['views'] );
		update_option( self::LOG, array_slice( $l, -300 ), false );
	}

	/** One click, no login needed, signed link. */
	public static function unsubscribe() {
		if ( empty( $_GET['mrsh_unsub'] ) || empty( $_GET['t'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		$uid = (int) $_GET['mrsh_unsub']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$t   = sanitize_text_field( wp_unslash( $_GET['t'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( $uid > 0 && hash_equals( hash_hmac( 'sha256', 'nudge' . $uid, wp_salt( 'auth' ) ), $t ) ) {
			update_user_meta( $uid, 'mrsh_nudge_stop', time() );
			wp_die( '<p>You will not get profile reminders any more. You can still finish your profile any time at My Rishta Pakistan.</p><p dir="rtl">اب آپ کو پروفائل یاددہانی کی ای میل نہیں آئے گی۔</p><p><a href="' . esc_url( home_url( '/' ) ) . '">My Rishta Pakistan</a></p>', 'Reminders stopped', array( 'response' => 200 ) );
		}
	}

	/* ---------- admin ---------- */

	public static function menu() {
		add_submenu_page( 'myrishta-seo', 'Profile reminders', 'Profile reminders', 'manage_options', 'mrsh-nudge', array( __CLASS__, 'page' ) );
	}

	private static function back( $m ) {
		wp_safe_redirect( admin_url( 'admin.php?page=mrsh-nudge&msg=' . rawurlencode( $m ) ) );
		exit;
	}

	private static function guard( $a ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Not allowed.' );
		}
		check_admin_referer( 'mrsh_nudge_' . $a );
	}

	public static function act_save() {
		self::guard( 'save' );
		$in = isset( $_POST['n'] ) && is_array( $_POST['n'] ) ? wp_unslash( $_POST['n'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$n  = array(
			'on'      => empty( $in['on'] ) ? 0 : 1,
			'every'   => max( 1, min( 30, (int) ( $in['every'] ?? 2 ) ) ),
			'every_h' => max( 1, min( 720, (int) ( $in['every_h'] ?? 36 ) ) ),
			'verify'  => empty( $in['verify'] ) ? 0 : 1,
			'max'     => max( 1, min( 10, (int) ( $in['max'] ?? 4 ) ) ),
			'batch'   => max( 1, min( 50, (int) ( $in['batch'] ?? 20 ) ) ),
			'min_age' => max( 0, min( 30, (int) ( $in['min_age'] ?? 1 ) ) ),
			'goal'    => max( 10, min( 100, (int) ( $in['goal'] ?? 80 ) ) ),
		);
		update_option( self::OPT, $n, false );
		self::back( $n['on'] ? 'Saved. Reminders are ON.' : 'Saved. Reminders are OFF.' );
	}

	public static function act_test() {
		self::guard( 'test' );
		$u  = wp_get_current_user();
		$st = array( 'kind' => 'part', 'score' => 40, 'miss' => array( array( 'a clear photo', 'صاف تصویر' ), array( 'a few lines about yourself', 'اپنے بارے میں چند سطریں' ) ), 'views' => 7 );
		self::back( self::send( $u, $st, 1 ) ? 'Test email sent to ' . $u->user_email . ' (it shows example numbers).' : 'The test email could not be sent. Check your site email settings.' );
	}

	public static function act_run_now() {
		self::guard( 'run_now' );
		self::back( 'Sent ' . (int) self::run( true ) . ' reminder(s) now.' );
	}

	public static function act_reset() {
		self::guard( 'reset' );
		global $wpdb;
		$wpdb->query( "DELETE FROM {$wpdb->usermeta} WHERE meta_key IN ('mrsh_nudge_count','mrsh_nudge_last','mrsh_nudge_done')" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		self::back( 'Reminder counts were reset. People who unsubscribed stay unsubscribed.' );
	}

	/** Dry run: who would get a reminder, without sending anything. */
	private static function preview() {
		$s   = self::get();
		$out = array( 'ready' => 0, 'none' => 0, 'part' => 0, 'done' => 0, 'stopped' => 0, 'maxed' => 0, 'total' => 0 );
		foreach ( get_users( array( 'number' => 1000 ) ) as $u ) {
			if ( user_can( $u, 'manage_options' ) || user_can( $u, 'publish_posts' ) || user_can( $u, 'edit_others_posts' ) ) {
				continue;
			}
			$out['total']++;
			if ( get_user_meta( $u->ID, 'mrsh_nudge_stop', true ) ) {
				$out['stopped']++;
				continue;
			}
			if ( (int) get_user_meta( $u->ID, 'mrsh_nudge_count', true ) >= (int) $s['max'] ) {
				$out['maxed']++;
				continue;
			}
			$st = self::status( $u );
			if ( null === $st ) {
				$out['done']++;
				continue;
			}
			$out[ $st['kind'] ]++;
			$out['ready']++;
		}
		return $out;
	}

	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s  = self::get();
		$ap = esc_url( admin_url( 'admin-post.php' ) );
		$f  = static function ( $a ) {
			return '<input type="hidden" name="action" value="mrsh_nudge_' . $a . '">' . wp_nonce_field( 'mrsh_nudge_' . $a, '_wpnonce', true, false );
		};
		echo '<div class="wrap"><h1>Profile reminders</h1><p>A gentle email to members whose profile is missing a photo, text or details. It stops by itself when the profile is complete.</p>';
		if ( isset( $_GET['msg'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['msg'] ) ) ) . '</p></div>';
		}
		$p = self::preview();
		echo '<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:14px 16px;max-width:760px;margin:12px 0"><b>Who would get a reminder right now</b><br>'
			. 'Members checked: <b>' . (int) $p['total'] . '</b> &nbsp;|&nbsp; Would get one: <b>' . (int) $p['ready'] . '</b> (no profile yet: ' . (int) $p['none'] . ', unfinished profile: ' . (int) $p['part'] . ') &nbsp;|&nbsp; Profile complete: ' . (int) $p['done'] . ' &nbsp;|&nbsp; Unsubscribed: ' . (int) $p['stopped'] . ' &nbsp;|&nbsp; Reached the limit: ' . (int) $p['maxed'] . '</div>';
		echo '<form method="post" action="' . $ap . '">' . $f( 'save' ) . '<table class="form-table">';
		echo '<tr><th>Send reminders</th><td><label><input type="checkbox" name="n[on]" value="1"' . checked( $s['on'], 1, false ) . '> On</label><p class="description">Off until you switch it on. Send yourself a test first.</p></td></tr>';
		echo '<tr><th>Send again after</th><td><input type="number" min="1" max="720" name="n[every_h]" value="' . (int) $s['every_h'] . '" style="width:70px"> hours <span class="description">(36 = every day and a half)</span></td></tr>';
		echo '<tr><th>Email confirmation</th><td><label><input type="checkbox" name="n[verify]" value="1"' . checked( $s['verify'], 1, false ) . '> Also remind members who have not confirmed their email</label><p class="description">The email has a one-click confirm link. Members who already used password reset count as confirmed.</p></td></tr>';
		echo '<tr><th>Most reminders per member</th><td><input type="number" min="1" max="10" name="n[max]" value="' . (int) $s['max'] . '" style="width:70px"> <span class="description">Then they are left alone. Keeps you out of the spam folder.</span></td></tr>';
		echo '<tr><th>Emails per hour</th><td><input type="number" min="1" max="50" name="n[batch]" value="' . (int) $s['batch'] . '" style="width:70px"> <span class="description">Spreads sending out so your host does not block it.</span></td></tr>';
		echo '<tr><th>Wait after sign-up</th><td><input type="number" min="0" max="30" name="n[min_age]" value="' . (int) $s['min_age'] . '" style="width:70px"> days</td></tr>';
		echo '<tr><th>Profile counts as complete at</th><td><input type="number" min="10" max="100" name="n[goal]" value="' . (int) $s['goal'] . '" style="width:70px"> %</td></tr>';
		echo '</table><p><button class="button button-primary">Save</button></p></form>';
		echo '<p><form method="post" action="' . $ap . '" style="display:inline">' . $f( 'test' ) . '<button class="button">Send a test to me</button></form> '
			. '<form method="post" action="' . $ap . '" style="display:inline" onsubmit="return confirm(\'Send reminders to eligible members now (up to the hourly limit)?\')">' . $f( 'run_now' ) . '<button class="button">Send one batch now</button></form> '
			. '<form method="post" action="' . $ap . '" style="display:inline" onsubmit="return confirm(\'Reset all reminder counts?\')">' . $f( 'reset' ) . '<button class="button">Reset counts</button></form></p>';
		$log = get_option( self::LOG, array() );
		$log = is_array( $log ) ? array_reverse( array_slice( $log, -15 ) ) : array();
		if ( $log ) {
			echo '<h2>Last reminders</h2><table class="widefat striped" style="max-width:760px"><thead><tr><th>When</th><th>Member</th><th>Reminder no.</th><th>Profile score</th><th>Views</th></tr></thead><tbody>';
			foreach ( $log as $r ) {
				$u = get_userdata( $r['u'] );
				echo '<tr><td>' . esc_html( wp_date( 'j M H:i', $r['t'] ) ) . '</td><td>' . esc_html( $u ? $u->user_login : '#' . $r['u'] ) . '</td><td>' . (int) $r['n'] . '</td><td>' . (int) $r['s'] . '%</td><td>' . (int) $r['v'] . '</td></tr>';
			}
			echo '</tbody></table>';
		}
		echo '<p class="description" style="max-width:760px;margin-top:14px">Every email has an unsubscribe link. The "viewed N times" line is only used when the profile really has views; otherwise a neutral line is used. Phone numbers and other members\' details are never put in these emails.</p></div>';
	}
}
