<?php
/**
 * Speed engine: lightweight Core Web Vitals helpers that work with or without
 * a cache plugin. Page caching itself is left to the server (LiteSpeed/Hostinger).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MRSH_Speed {

	public static function init() {
		$o = MRSH_Options::get();
		if ( is_admin() ) {
			return;
		}
		// Logged-out visitors cannot list usernames through the REST API.
		add_filter( 'rest_endpoints', array( __CLASS__, 'hide_user_endpoints' ) );
		if ( ! empty( $o['speed_hide_adminbar'] ) ) {
			// The admin bar pulls in Site Kit's dashboard scripts (about 2 MB) on every page you open while logged in.
			add_filter( 'show_admin_bar', '__return_false', 100 );
		}
		if ( ! empty( $o['speed_fonts'] ) ) {
			add_filter( 'style_loader_src', array( __CLASS__, 'font_swap_src' ), 20 );
		}
		if ( ! empty( $o['speed_dashicons'] ) ) {
			add_action( 'wp_enqueue_scripts', array( __CLASS__, 'dashicons' ), 100 );
		}
		if ( ! empty( $o['speed_heartbeat'] ) ) {
			add_filter( 'heartbeat_settings', array( __CLASS__, 'heartbeat' ) );
		}
		if ( ! empty( $o['speed_blocks'] ) ) {
			add_action( 'wp_enqueue_scripts', array( __CLASS__, 'block_css' ), 100 );
		}
		if ( ! empty( $o['speed_defer'] ) ) {
			add_filter( 'script_loader_tag', array( __CLASS__, 'defer_tag' ), 20, 3 );
		}
		if ( '' !== trim( (string) $o['speed_preload_img'] ) ) {
			add_action( 'wp_head', array( __CLASS__, 'preload_img' ), 1 );
		}
		if ( ! empty( $o['speed_images'] ) || ! empty( $o['speed_fonts'] ) || ! empty( $o['fix_access'] ) ) {
			add_action( 'template_redirect', array( __CLASS__, 'start' ), 1 );
		}
		add_action( 'init', array( 'MRSH_PK', 'swap_locked_file' ), 20 );
		if ( ! is_admin() ) {
			add_filter( 'the_content', array( 'MRSH_PK', 'topic_figure' ), 5 );
		}
	}

	public static function skip() {
		if ( is_admin() || is_feed() || is_robots() || is_customize_preview() || is_user_logged_in() && current_user_can( 'edit_posts' ) && isset( $_GET['elementor-preview'] ) || isset( $_GET['elementor-preview'] ) || isset( $_GET['preview'] ) || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || wp_doing_ajax() ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return true;
		}
		$path = isset( $_SERVER['REQUEST_URI'] ) ? strtok( (string) wp_unslash( $_SERVER['REQUEST_URI'] ), '?' ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		return (bool) preg_match( '/\.(xml|xsl|txt|json)$/i', $path );
	}

	/** Facts about the requested page, taken before the theme template can replace the main query (some page templates do). */
	public static $is_page = false;
	public static $is_term = false;
	public static $title   = '';
	public static $term    = '';

	public static function start() {
		if ( self::skip() ) {
			return;
		}
		self::$is_page = is_singular() && ! is_front_page();
		self::$is_term = is_category() || is_tag() || is_tax();
		self::$title   = self::$is_page ? get_the_title( get_queried_object_id() ) : '';
		self::$term    = self::$is_term ? single_term_title( '', false ) : '';
		ob_start( array( __CLASS__, 'filter' ) );
	}

	/** Add display=swap to Google font links so text shows at once. */
	public static function font_swap_src( $src ) {
		if ( is_string( $src ) && false !== strpos( $src, 'fonts.googleapis.com' ) && false === strpos( $src, 'display=' ) ) {
			$src .= ( false === strpos( $src, '?' ) ? '?' : '&' ) . 'display=swap';
		}
		return $src;
	}

	public static function dashicons() {
		if ( ! is_user_logged_in() ) {
			wp_dequeue_style( 'dashicons' );
		}
	}

	public static function block_css() {
		wp_dequeue_style( 'wp-block-library' );
		wp_dequeue_style( 'wp-block-library-theme' );
		wp_dequeue_style( 'global-styles' );
		wp_dequeue_style( 'classic-theme-styles' );
	}

	public static function heartbeat( $s ) {
		$s['interval'] = 60;
		return $s;
	}

	public static function defer_tag( $tag, $handle, $src ) {
		if ( is_user_logged_in() || self::skip() || ! $src || false !== stripos( $tag, ' defer' ) || false !== stripos( $tag, ' async' ) || false === stripos( $tag, ' src=' ) ) {
			return $tag;
		}
		if ( false !== stripos( $tag, 'type="module"' ) || false !== stripos( $tag, "type='module'" ) ) {
			return $tag;
		}
		$o       = MRSH_Options::get();
		$exclude = array_merge( array( 'jquery', 'jquery-core', 'jquery-migrate', 'elementor-frontend-modules', 'elementor-webpack-runtime', 'elementor-frontend' ), MRSH_Options::to_list( $o['speed_defer_exclude'] ) );
		if ( in_array( $handle, $exclude, true ) ) {
			return $tag;
		}
		foreach ( MRSH_Options::to_list( $o['speed_defer_exclude'] ) as $frag ) {
			if ( '' !== $frag && false !== stripos( $src, $frag ) ) {
				return $tag;
			}
		}
		return preg_replace( '/<script\b/i', '<script defer', $tag, 1 );
	}

	public static function preload_img() {
		$u = trim( (string) MRSH_Options::get()['speed_preload_img'] );
		if ( '' !== $u && 0 === strpos( $u, '/' ) && 0 !== strpos( $u, '//' ) ) {
			$u = home_url( $u );
		} elseif ( '' !== $u && ! preg_match( '#^https://#i', $u ) ) {
			$u = ''; // A bare file name or an http:// address would be a broken or mixed-content link.
		}
		// Home.webp is only a 56-byte stand-in; the picture people see is hero-art.svg (about 1 KB). Preload that one.
		$u = preg_replace( '#/assets/img/Home\.webp.*$#', '/assets/hero-art.svg?v=' . MRSH_VERSION, $u );
		$u = esc_url( $u );
		if ( '' !== $u && ( is_front_page() || is_home() ) ) {
			echo '<link rel="preload" as="image" href="' . $u . '" fetchpriority="high">' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}

	/** Page body pass: lazy-load images below the fold, prioritise the first, swap fonts in inline CSS. */
	/**
	 * PremiumPress hides #wrapper and shows a spinner until its JavaScript runs plus one second,
	 * and loads its stylesheets at the end of the body. Show the page at once and move the
	 * theme stylesheets into the head, so first paint is the real page.
	 */
	public static function unhide( $html ) {
		if ( false === strpos( $html, 'id="page-loading"' ) || false === strpos( $html, 'id="wrapper"' ) ) {
			return $html;
		}
		$out = preg_replace( '/(<div\s+id="wrapper")\s+style="display:\s*none;?"\s+class="([^"]*)"/i', '$1 class="$2 d-flex preload-hide"', $html, 1, $c1 );
		if ( ! $c1 ) {
			return $html;
		}
		$out = preg_replace( '/<div id="page-loading"[^>]*>.*?<\/div>/is', '', $out, 1 );
		// Move theme stylesheets that sit in the body into the head.
		$moved = '';
		$out   = preg_replace_callback( '/<link\s[^>]*rel=["\']stylesheet["\'][^>]*href=["\'][^"\']*b-cdn\.net\/css\/[^"\']*["\'][^>]*>/i', function ( $m ) use ( &$moved ) {
			$moved .= $m[0] . "\n";
			return '';
		}, $out );
		if ( '' !== $moved ) {
			$moved = self::bundle( $moved );
			$moved = '<link rel="preconnect" href="https://ppt1080.b-cdn.net" crossorigin>' . "\n" . $moved;
			$pos   = strripos( $out, '</head>' );
			if ( false !== $pos ) {
				$out = substr( $out, 0, $pos ) . $moved . substr( $out, $pos );
			}
		}
		if ( null !== $out ) {
			$out = self::crit( $out );
		}
		return null === $out ? $html : $out;
	}

	/**
	 * Home page only: put the small set of CSS the page really uses straight into the head
	 * and load the full stylesheets once the page has loaded. Visitors who are logged in,
	 * and every other page, keep the normal stylesheets.
	 */
	public static function crit( $html ) {
		if ( ! is_front_page() || is_user_logged_in() || ! defined( 'MRSH_DIR' ) ) {
			return $html;
		}
		$file = MRSH_DIR . 'assets/css/crit-home.css';
		if ( ! is_readable( $file ) ) {
			return $html;
		}
		if ( ! preg_match( '/<link\s[^>]*href=["\']([^"\']*\/mrsh-css\/[a-f0-9]+\.css)["\'][^>]*>/i', $html, $bm ) ) {
			return $html;
		}
		$links = array( $bm[1] );
		$out   = str_replace( $bm[0], '', $html );
		if ( preg_match( '/<link\s[^>]*href=["\']([^"\']*\/block-library\/style(?:\.min)?\.css[^"\']*)["\'][^>]*>/i', $out, $wm ) ) {
			if ( self::uses_blocks( $out ) ) {
				array_unshift( $links, html_entity_decode( $wm[1] ) );
			}
			$out = str_replace( $wm[0], '', $out );
		}
		$css = file_get_contents( $file );
		if ( false === $css || strlen( $css ) < 500 ) {
			return $html;
		}
		$js    = '(function(){var u=' . wp_json_encode( $links ) . ',d=0;function go(){if(d)return;d=1;u.forEach(function(h){var l=document.createElement("link");l.rel="stylesheet";l.href=h;document.head.appendChild(l);});}window.addEventListener("load",go);setTimeout(go,4000);})();';
		$block = '<style id="mrsh-crit" data-no-optimize="1">' . $css . '</style><script data-no-optimize="1" data-cfasync="false">' . $js . '</script><noscript>';
		foreach ( $links as $l ) {
			$block .= '<link rel="stylesheet" href="' . esc_url( $l ) . '">';
		}
		$block .= '</noscript>' . "\n";
		$pos    = strripos( $out, '</head>' );
		if ( false === $pos ) {
			return $html;
		}
		return substr( $out, 0, $pos ) . $block . substr( $out, $pos );
	}

	/**
	 * Join the theme stylesheets (about nine files on another host) into one file on this site,
	 * so the browser makes one request instead of nine plus a new connection. Falls back to the
	 * original links if anything goes wrong.
	 */
	public static function bundle( $links ) {
		if ( ! preg_match_all( '/href=["\']([^"\']+)["\']/i', $links, $mm ) || count( $mm[1] ) < 2 ) {
			return $links;
		}
		$urls = array_map( 'html_entity_decode', $mm[1] );
		$up   = wp_upload_dir();
		if ( empty( $up['basedir'] ) ) {
			return $links;
		}
		$key  = md5( 'v2|' . implode( '|', $urls ) );
		$file = $up['basedir'] . '/mrsh-css/' . $key . '.css';
		$url  = $up['baseurl'] . '/mrsh-css/' . $key . '.css';
		if ( file_exists( $file ) && filesize( $file ) > 1000 ) {
			return '<link rel="stylesheet" href="' . esc_url( $url ) . '">' . "\n";
		}
		if ( get_transient( 'mrsh_bundle_fail' ) ) {
			return $links;
		}
		$css = '';
		foreach ( $urls as $u ) {
			$r = wp_remote_get( $u, array( 'timeout' => 10 ) );
			if ( is_wp_error( $r ) || 200 !== (int) wp_remote_retrieve_response_code( $r ) ) {
				set_transient( 'mrsh_bundle_fail', 1, 600 );
				return $links;
			}
			$c    = wp_remote_retrieve_body( $r );
			$base = preg_replace( '#[^/]*$#', '', strtok( $u, '?' ) );
			$c    = preg_replace( '/@charset[^;]*;/i', '', $c );
			$c    = preg_replace_callback( '/url\(\s*([\'"]?)([^\'")]+)\1\s*\)/i', function ( $m ) use ( $base ) {
				$x = $m[2];
				if ( preg_match( '#^(data:|https?:|//|/|\#)#i', $x ) ) {
					return $m[0];
				}
				return 'url(' . $m[1] . $base . $x . $m[1] . ')';
			}, $c );
			$c    = preg_replace( '#/\*.*?\*/#s', '', $c );
			$css .= trim( $c ) . "\n";
		}
		if ( preg_match( '/@import/i', $css ) ) {
			set_transient( 'mrsh_bundle_fail', 1, 3600 );
			return $links;
		}
		$css = preg_replace( '/font-display\s*:[^;}]*;?/i', '', $css );
		$css = str_replace( '@font-face{', '@font-face{font-display:swap;', preg_replace( '/@font-face\s*\{/i', '@font-face{', $css ) );
		$css = preg_replace( '/\s+/', ' ', $css );
		$css = preg_replace( '/\s*([{};>])\s*|([:,])\s+/', '$1$2', $css );
		$css = str_replace( ';}', '}', $css );
		wp_mkdir_p( dirname( $file ) );
		if ( ! @file_put_contents( $file, $css ) ) {
			set_transient( 'mrsh_bundle_fail', 1, 3600 );
			return $links;
		}
		return '<link rel="stylesheet" href="' . esc_url( $url ) . '">' . "\n";
	}

	/**
	 * Load the Google Analytics / Tag Manager library after the first touch, scroll or click
	 * (or after 6 seconds), so it does not compete with the first paint. The AdSense tag is
	 * left exactly as it is so Google can still find it.
	 */
	public static function delay_analytics( $html ) {
		$n    = 0;
		// The theme ships a hidden demo notification template that names a placeholder member ("Mark"). Use a neutral word so no stray name appears in the page text; the theme still fills in the real sender name when a message arrives.
		$html = str_replace( '<strong class="_username">Mark</strong> Has sent you a message', '<strong class="_username">A member</strong> has sent you a message', $html );
		$out = preg_replace_callback( '/<script\b([^>]*)\ssrc=(["\'])(https:\/\/www\.googletagmanager\.com\/[^"\']+)\2([^>]*)><\/script>/i', function ( $m ) use ( &$n ) {
			++$n;
			return '<script type="text/mrsh-delay"' . $m[1] . ' data-mrsh-src="' . $m[3] . '"' . $m[4] . '></script>';
		}, $html );
		if ( null === $out ) {
			return $html;
		}
		// Optional (turn on after AdSense approval): load the ad library after the first touch too.
		$opt = MRSH_Options::get();
		if ( ! empty( $opt['speed_delay_ads'] ) ) {
			$out = preg_replace_callback( '/<script\b([^>]*)\ssrc=(["\'])(https:\/\/pagead2\.googlesyndication\.com\/pagead\/js\/adsbygoogle\.js[^"\']*)\2([^>]*)><\/script>/i', function ( $m ) use ( &$n ) {
				++$n;
				return '<script type="text/mrsh-delay"' . $m[1] . ' data-mrsh-src="' . $m[3] . '"' . $m[4] . '></script>';
			}, $out );
			if ( null === $out ) {
				return $html;
			}
		}
		// On profile pages reCAPTCHA (about 350 KB) loads at the first touch. Google sign-in must NOT be delayed: its Site Kit script runs once at page load and fails if the library is missing.
		$libs = array();
		if ( function_exists( 'is_singular' ) && ( is_singular( 'listing_type' ) || is_singular( 'post' ) ) ) {
			$libs[] = 'https:\/\/www\.google\.com\/recaptcha\/api\.js[^"\']*';
		}
		foreach ( $libs as $lib ) {
			$o2 = preg_replace_callback( '/<script\b([^>]*)\ssrc=(["\'])(' . $lib . ')\2([^>]*)><\/script>/i', function ( $m ) use ( &$n ) {
				++$n;
				return '<script type="text/mrsh-delay"' . $m[1] . ' data-mrsh-src="' . $m[3] . '"' . $m[4] . '></script>';
			}, $out );
			if ( null !== $o2 ) {
				$out = $o2;
			}
		}
		// Inline Tag Manager and Clarity starters (they pull in many more scripts).
		$out = preg_replace_callback( '/<script\b(?![^>]*\ssrc=)(?![^>]*\stype=)([^>]*)>((?:(?!<\/script>).)*?(?:googletagmanager\.com\/gtm\.js|clarity\.ms\/tag)(?:(?!<\/script>).)*?)<\/script>/is', function ( $m ) use ( &$n ) {
			++$n;
			return '<script type="text/mrsh-delay-inline"' . $m[1] . '>' . $m[2] . '</script>';
		}, $out );
		if ( ! $n || null === $out ) {
			return $html;
		}
		$loader = '<script>(function(){var d=false;function go(){if(d)return;d=true;document.querySelectorAll("script[type=\'text/mrsh-delay\']").forEach(function(o){var s=document.createElement("script");s.async=true;s.src=o.getAttribute("data-mrsh-src");if(o.id)s.id=o.id;document.head.appendChild(s);});document.querySelectorAll("script[type=\'text/mrsh-delay-inline\']").forEach(function(o){var s=document.createElement("script");s.text=o.textContent;document.head.appendChild(s);});}["click","touchstart","keydown","wheel"].forEach(function(e){window.addEventListener(e,go,{once:true,passive:true});});window.addEventListener("scroll",function(){if((window.pageYOffset||0)>40)go();},{passive:true});setTimeout(go,15000);})();</script>';
		$pos    = strripos( $out, '</body>' );
		return false === $pos ? $out . $loader : substr( $out, 0, $pos ) . $loader . substr( $out, $pos );
	}

	/** Use FILE.webp for uploads images that have one (made by the image compressor). */
	public static function webp_swap( $html ) {
		$up = wp_get_upload_dir();
		if ( empty( $up['baseurl'] ) || empty( $up['basedir'] ) ) {
			return $html;
		}
		$base = preg_quote( $up['baseurl'], '/' );
		$seen = array();
		$out  = preg_replace_callback( '/' . $base . '\/([^"\'\s)<>?]+\.(?:png|jpe?g))(?![\w\-]|\.webp|\.avif)/i', function ( $m ) use ( $up, &$seen ) {
			$rel = $m[1];
			if ( ! isset( $seen[ $rel ] ) ) {
				$seen[ $rel ] = file_exists( $up['basedir'] . '/' . $rel . '.webp' );
			}
			if ( $seen[ $rel ] ) {
				return $m[0] . '.webp';
			}
			// Optimised copies of the two homepage pictures that ship with the plugin.
			$name  = preg_replace( '/\.(png|jpe?g)$/i', '', basename( $rel ) );
			$local = defined( 'MRSH_DIR' ) ? MRSH_DIR . 'assets/img/' . $name . '.webp' : '';
			if ( $local && defined( 'MRSH_URL' ) && preg_match( '/^[A-Za-z0-9_\-]+$/', $name ) && file_exists( $local ) ) {
				return MRSH_URL . 'assets/img/' . $name . '.webp';
			}
			return $m[0];
		}, $html );
		return null === $out ? $html : $out;
	}

	/**
	 * The first picture on the page is usually the largest paint. Theme and cache plugins load it
	 * late through data-src; give it a real src and tell the browser to fetch it first.
	 */
	public static function hero( $html ) {
		$split = stripos( $html, '<body' );
		if ( false === $split ) {
			return $html;
		}
		$head = substr( $html, 0, $split );
		$body = substr( $html, $split );
		$urls = array();
		$body = preg_replace_callback( '/<img\b[^>]*>/i', function ( $m ) use ( &$urls ) {
			static $done = false;
			if ( $done ) {
				return $m[0];
			}
			$done = true;
			$t = $m[0];
			if ( ! preg_match( '/\sdata-src=["\']([^"\']+)["\']/i', $t, $d ) ) {
				if ( preg_match( '/\ssrc=["\']([^"\']+)["\']/i', $t, $s ) && 0 !== strpos( $s[1], 'data:' ) ) {
					$urls[] = $s[1];
				}
				return $t;
			}
			if ( ! preg_match( '/\ssrc=["\'](?!data:)/i', $t ) ) {
				$t = preg_replace( '/\ssrc=["\']data:[^"\']*["\']/i', '', $t );
				$t = preg_replace( '/<img\b/i', '<img src="' . esc_url( $d[1] ) . '"', $t, 1 );
				$t = preg_replace( '/\sloading=(["\'])lazy\1/i', '', $t );
				$urls[] = $d[1];
			}
			return $t;
		}, $body, -1 );
		// First inline background picture.
		if ( preg_match( '/background-image:\s*url\(\s*[\'"]?(https?:[^\'")]+\.(?:png|jpe?g|webp))/i', $body, $bg ) ) {
			// The hero picture is the only one that is on screen first; the first <img> is often far below it.
			$urls = array( $bg[1] );
		}
		$tags = '';
		foreach ( array_slice( array_unique( $urls ), 0, 2 ) as $u ) {
			// A big PNG or JPEG preloaded on a slow phone steals bandwidth from the page itself.
			if ( ! preg_match( '/\.webp(\?|$)/i', $u ) || false !== strpos( $u, '/assets/img/Home.webp' ) ) {
				continue;
			}
			$tags .= '<link rel="preload" as="image" href="' . esc_url( $u ) . '" fetchpriority="high">' . "\n";
		}
		if ( '' !== $tags ) {
			$pos = strripos( $head, '</head>' );
			if ( false !== $pos ) {
				$head = substr( $head, 0, $pos ) . $tags . substr( $head, $pos );
			}
		}
		return null === $body ? $html : $head . $body;
	}

	/** Profile-card pictures are CSS backgrounds. Load them only when they are about to be seen (hidden duplicates never load). */
	public static function lazy_bg( $html ) {
		$n   = 0;
		$out = preg_replace_callback( '/<div\b[^>]*\sclass="[^"]*\bbg-image\b[^"]*"[^>]*\sdata-bg="[^"]+"[^>]*>|<div\b[^>]*\sdata-bg="[^"]+"[^>]*\sclass="[^"]*\bbg-image\b[^"]*"[^>]*>/i', function ( $m ) use ( &$n ) {
			++$n;
			return str_replace( ' data-bg="', ' data-mrsh-bg="', $m[0] );
		}, $html );
		if ( ! $n || null === $out ) {
			return $html;
		}
		$js  = '<script>(function(){var l=document.querySelectorAll("[data-mrsh-bg]");function s(e){var u=e.getAttribute("data-mrsh-bg");e.removeAttribute("data-mrsh-bg");e.style.backgroundImage="url(\""+u+"\")";}if(!("IntersectionObserver" in window)){for(var i=0;i<l.length;i++)s(l[i]);return;}var o=new IntersectionObserver(function(a){a.forEach(function(x){if(x.isIntersecting){o.unobserve(x.target);s(x.target);}});},{rootMargin:"300px 0px"});for(var j=0;j<l.length;j++)o.observe(l[j]);})();</script>';
		$pos = strripos( $out, '</body>' );
		return false === $pos ? $out . $js : substr( $out, 0, $pos ) . $js . substr( $out, $pos );
	}

	/** True when the page body contains WordPress block markup that needs the block stylesheet. */
	public static function uses_blocks( $html ) {
		$pos  = stripos( $html, '<body' );
		$body = false === $pos ? $html : substr( $html, $pos );
		return (bool) preg_match( '/class="[^"]*\bwp-block-[a-z]|class="[^"]*\bhas-(?:[a-z-]+-)?(?:color|background|font-size)\b/i', $body );
	}

	/** Drop the 138 KB block stylesheet from pages that use no blocks (every other page type than the home page). */
	public static function strip_blocks( $html ) {
		if ( self::uses_blocks( $html ) ) {
			return $html;
		}
		$out = preg_replace( '/<link\s[^>]*href=["\'][^"\']*\/block-library\/style(?:\.min)?\.css[^"\']*["\'][^>]*>\s*/i', '', $html );
		return null === $out ? $html : $out;
	}

	/** Remove duplicate or broken structured data printed by the theme and Site Kit (wrong logo, placeholder picture, mixed types). */
	public static function clean_schema( $html ) {
		$out = preg_replace_callback( '/<script\b[^>]*type=["\']application\/ld\+json["\'][^>]*>(.*?)<\/script>/is', function ( $m ) {
			$j = $m[1];
			if ( preg_match( '/"@context"\s*:\s*"https:\/\/schema\.org\/"/', $j ) || false !== strpos( $j, 'productID' ) || false !== strpos( $j, 'openaccess' ) || preg_match( '/"@type"\s*:\s*\[\s*"BreadcrumbList"\s*,\s*"NewsArticle"/', $j ) ) {
				return '';
			}
			return $m[0];
		}, $html );
		return null === $out ? $html : $out;
	}

	/**
	 * Remove advertising/analytics trackers (Tag Manager, Google Analytics / Ads tag, Clarity).
	 * AdSense and Google sign-in are not touched. A do-nothing gtag() is left so other scripts do not error.
	 */
	public static function strip_trackers( $html ) {
		$n   = 0;
		$out = preg_replace_callback( '/<script\b([^>]*)>(.*?)<\/script>/is', function ( $m ) use ( &$n ) {
			$all = $m[0];
			if ( false !== stripos( $all, 'data-mrsh-ads' ) ) { // the Google Ads tag and its conversion events, added by the Google Ads page
				return $all;
			}
			if ( false !== stripos( $all, 'adsbygoogle' ) || false !== stripos( $all, 'pagead2' ) || false !== stripos( $all, 'fundingchoices' ) || false !== stripos( $all, 'accounts.google.com' ) ) {
				return $all;
			}
			if ( preg_match( '/googletagmanager\.com|clarity\.ms|google-analytics\.com|id=["\']google_gtagjs|gtag\s*\(|GTM-[A-Z0-9]{5,}/i', $all ) ) {
				++$n;
				return '';
			}
			return $all;
		}, $html );
		if ( null === $out ) {
			return $html;
		}
		$out = preg_replace( '/<noscript>\s*<iframe[^>]*googletagmanager\.com[^>]*>.*?<\/iframe>\s*<\/noscript>/is', '', $out );
		$out = null === $out ? $html : $out;
		$pos = stripos( $out, '</head>' );
		$stub = '<script data-no-optimize="1">window.dataLayer=window.dataLayer||[];window.gtag=window.gtag||function(){};</script>';
		return false === $pos ? $out : substr( $out, 0, $pos ) . $stub . substr( $out, $pos );
	}

	/** Spelling fixes for profile-field labels from the theme. Only the visible text changes; saved values and option values stay the same. */
	public static function spelling( $html ) {
		static $map = array(
			'Children Satus'                 => "Children's Status",
			'Please provide children satus'  => "Please select the children's status",
			'Nationalty'                     => 'Nationality',
			'My Habbits'                     => 'My Habits',
			'Please select you gender'       => 'Please select your gender',
			'>Suni<'                         => '>Sunni<',
			'>Bralvi<'                       => '>Barelvi<',
			'>Satying Saprate<'              => '>Staying Separate<',
			'>Satying With Mother<'          => '>Staying With Mother<',
		);
		// Visible text only: never touch the inside of <script> or <style>, where an apostrophe would break the code.
		$parts = preg_split( '#(<script\b.*?</script>|<style\b.*?</style>)#is', $html, -1, PREG_SPLIT_DELIM_CAPTURE );
		if ( ! is_array( $parts ) ) {
			return $html;
		}
		foreach ( $parts as $i => $part ) {
			if ( 0 === $i % 2 ) {
				$parts[ $i ] = strtr( $part, $map );
			}
		}
		return implode( '', $parts );
	}

	/** Runs the page changes, then makes sure the finished page really has one main heading (a safety net for page templates the earlier steps miss). */
	public static function filter( $html ) {
		$out = self::filter_inner( $html );
		if ( ! is_string( $out ) || '' === $out ) {
			return $html;
		}
		if ( self::$is_page ) {
			$bp    = stripos( $out, '<body' );
			$title = trim( (string) self::$title );
			if ( '' === $title && preg_match( '/<title>([^<|]+)/i', $out, $tm ) ) {
				$title = trim( html_entity_decode( $tm[1] ) );
			}
			if ( '' !== $title && false !== $bp && ! preg_match( '/<h1[\s>]/i', substr( $out, $bp ) ) ) {
				$r = preg_replace( '/<body\b[^>]*>/i', '$0<h1 style="position:absolute;left:-9999px;top:auto;width:1px;height:1px;overflow:hidden">' . esc_html( $title ) . '</h1>', $out, 1 );
				if ( is_string( $r ) && '' !== $r ) {
					$out = $r;
				}
			}
		}
		return $out;
	}

	/** Heading order fix for the theme's small sidebar titles, and a Twitter card tag where missing. */
	public static function tidy_head( $html ) {
		// Contact page: the old sentence contradicts the address shown elsewhere.
		$html = preg_replace( '#We don(?:\'|&\#8217;|&\#039;|\x{2019})t have any physical location so we are providing,? an online service\.?#u', 'My Rishta Pakistan is a non-profit based in Shahdara, Lahore. Our service is provided online. <style>.mrsh-off{display:flex;max-width:520px;margin:14px 0;border-radius:14px;overflow:hidden;box-shadow:0 4px 18px rgba(0,0,0,.18);text-decoration:none;background:#f1f8fb;color:#12313b}.mrsh-off .lg{flex:0 0 38%;background:#6e1230;color:#fff;text-align:center;padding:22px 10px;font-family:Georgia,serif;display:flex;flex-direction:column;justify-content:center}.mrsh-off .lg b{color:#e8b95a;font-size:21px;font-weight:700;line-height:1.1}.mrsh-off .lg strong{font-size:23px;display:block;line-height:1.15}.mrsh-off .lg i{display:block;border-top:1px solid #e8b95a;width:60%;margin:8px auto}.mrsh-off .lg small{font-size:12px;opacity:.9}.mrsh-off .tx{padding:18px;font-family:Arial,sans-serif}.mrsh-off .tx h3{margin:0 0 6px;font-size:18px}.mrsh-off .tx p{margin:0 0 8px;font-size:14px;color:#46606a;line-height:1.4}.mrsh-off .tx u{color:#0b6b82;font-size:14px}@media(max-width:480px){.mrsh-off{flex-direction:column}.mrsh-off .lg{flex-basis:auto}}</style><a class="mrsh-off" href="https://maps.app.goo.gl/KytbDLdkV5KrPZSj7" target="_blank" rel="noopener"><span class="lg"><b>My Rishta</b><strong>Pakistan</strong><i></i><small>Free Rishta Service</small><small>Non-profit &bull; Lahore</small></span><span class="tx"><h3>My Rishta Office</h3><p>J778+P35, Lahore - Sheikhupura - Faisalabad Rd, Lahore</p><u>maps.app.goo.gl</u></span></a><iframe title="My Rishta Office on Google Maps, Lahore-Sheikhupura-Faisalabad Rd" src="https://www.google.com/maps?q=31.614324,74.265098&amp;z=16&amp;output=embed" width="100%" height="280" style="border:0;display:block;margin:12px 0;border-radius:8px" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>', $html );
		$html = is_string( $html ) ? $html : '';
		// Currency switcher links (?c=AUD) must not create new indexable URLs.
		if ( isset( $_GET['c'] ) ) {
			$html = preg_replace_callback( '#(<link[^>]+rel=["\']canonical["\'][^>]*href=["\'])([^"\']+)(["\'])#i', static function ( $m ) { return $m[1] . remove_query_arg( 'c', html_entity_decode( $m[2] ) ) . $m[3]; }, $html, 1 );
		}
		// FAQPage structured data from the "Frequently asked questions" section of guide pages.
		if ( false === strpos( $html, '"FAQPage"' ) && preg_match( '#<h2[^>]*>\s*(?:Frequently asked questions|FAQs?|Common questions[^<]*)\s*</h2>(.*?)(?=<h2|</article>|<footer|$)#is', $html, $sec ) ) {
			$faq = array();
			if ( preg_match_all( '#<h3[^>]*>(.*?)</h3>\s*<p>(.*?)</p>#is', $sec[1], $qa, PREG_SET_ORDER ) ) {
				foreach ( array_slice( $qa, 0, 10 ) as $x ) {
					$q = trim( wp_strip_all_tags( $x[1] ) );
					$a = trim( wp_strip_all_tags( $x[2] ) );
					if ( '' !== $q && '' !== $a ) { $faq[] = array( '@type' => 'Question', 'name' => html_entity_decode( $q, ENT_QUOTES, 'UTF-8' ), 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => html_entity_decode( $a, ENT_QUOTES, 'UTF-8' ) ) ); }
				}
			}
			if ( count( $faq ) >= 2 ) {
				$json = wp_json_encode( array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $faq ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
				$out  = preg_replace( '#</head>#i', '<script type="application/ld+json">' . str_replace( '</', '<\\/', $json ) . "</script>\n</head>", $html, 1 );
				if ( is_string( $out ) ) { $html = $out; }
			}
		}
		$out = preg_replace( '#<h5 class="mt-0 mb-2 small">(.*?)</h5>#s', '<div class="mt-0 mb-2 small" style="font-weight:500">$1</div>', $html );
		if ( is_string( $out ) ) { $html = $out; }
		if ( false === stripos( $html, 'name="twitter:card"' ) && false === stripos( $html, "name='twitter:card'" ) ) {
			$html = preg_replace( '#</head>#i', '<meta name="twitter:card" content="summary_large_image">' . "\n" . '</head>', $html, 1 );
		}
		return is_string( $html ) ? $html : '';
	}

	/**
	 * Home page only: a real "about and questions" section the theme does not have. It is written in plain server HTML (not by a
	 * script), sits just above the footer so nothing above it moves, and its FAQ is turned into FAQPage data by tidy_head().
	 * Only things that are true of the site are stated: free, non-profit, Shahdara Lahore, phone number private.
	 */
	public static function home_about( $html ) {
		if ( ! function_exists( 'is_front_page' ) || ! ( is_front_page() || is_home() ) || false !== strpos( $html, 'id="mrsh-about"' ) ) {
			return $html;
		}
		$u  = static function ( $p ) { return esc_url( home_url( $p ) ); };
		$qa = array(
			array( 'Is MyRishta.pk really free?', 'Yes. Creating a profile, browsing proposals and contacting families is free. There are no packages and no membership fees, and we never ask for money to introduce a proposal.' ),
			array( 'Who runs MyRishta.pk?', 'My Rishta Pakistan, a non-profit based in Shahdara, Lahore. The service is provided online for families across Pakistan and overseas.' ),
			array( 'Is my phone number shown to everyone?', 'No. Your phone number stays private. Share contact details only when both families agree.' ),
			array( 'How do I create a profile?', 'Press Add Profile, fill in a few honest details about education, work and family, and save. It takes a few minutes, and you can create one for a son, daughter or relative.' ),
			array( 'How can I stay safe when looking for a rishta?', 'Never send money to anyone you have not met. Meet in a public place with elders present, and check jobs and degrees yourself. Read our safety tips and report any suspicious profile.' ),
			array( 'Can overseas Pakistanis use the site?', 'Yes. Families in the UAE, Saudi Arabia, the UK, the USA, Canada and elsewhere use it to find proposals in Pakistan, and the site works in any phone browser.' ),
		);
		$faq = '';
		foreach ( $qa as $x ) {
			$faq .= '<h3>' . esc_html( $x[0] ) . '</h3><p>' . esc_html( $x[1] ) . '</p>';
		}
		$app = array(
			'@context'            => 'https://schema.org',
			'@type'               => 'WebApplication',
			'name'                => 'My Rishta App',
			'url'                 => home_url( '/app/' ),
			'applicationCategory' => 'LifestyleApplication',
			'operatingSystem'     => 'Any (installable web app)',
			'offers'              => array( '@type' => 'Offer', 'price' => '0', 'priceCurrency' => 'PKR' ),
			'publisher'           => array( '@type' => 'NGO', 'name' => 'My Rishta Pakistan', 'url' => home_url( '/' ) ),
		);
		$css = '#mrsh-about{background:#fff;padding:44px 16px;color:#1b2a22;line-height:1.7}#mrsh-about .in{max-width:1000px;margin:0 auto}#mrsh-about h2{font-size:26px;color:#063d1d;margin:0 0 12px}#mrsh-about h3{font-size:18px;color:#0a4a25;margin:22px 0 4px}#mrsh-about p{margin:0 0 12px;font-size:16px}#mrsh-about a{color:#0a5a32;font-weight:600}#mrsh-about .ct{display:flex;flex-wrap:wrap;gap:8px 14px;margin:6px 0 14px}';
		$box = '<section id="mrsh-about"><style>' . $css . '</style><div class="in">'
			. '<h2>Free rishta service for Pakistani families</h2>'
			. '<p>MyRishta.pk is a free, non-profit rishta service run by My Rishta Pakistan from Shahdara, Lahore. Families in Pakistan and overseas can create a profile for a son, daughter or relative, browse proposals by city, age, education and work, and contact each other directly. There are no packages and no membership fees.</p>'
			. '<h2>How it works</h2>'
			. '<p><a href="' . $u( '/add-listing/' ) . '">Create a free profile</a> with honest details about education, work and family. Search by city, age and education, shortlist the proposals that suit you, and send a message. Share contact details and meet only when both families agree, with elders present. You can read the full steps on the <a href="' . $u( '/how-it-works/' ) . '">how it works</a> page, or look at our guide on <a href="' . $u( '/how-to-find-rishta-online-pakistan/' ) . '">how to find a rishta online</a>.</p>'
			. '<h2>Rishta by city</h2>'
			. '<div class="ct"><a href="' . $u( '/rishta-lahore/' ) . '">Lahore</a><a href="' . $u( '/rishta-karachi/' ) . '">Karachi</a><a href="' . $u( '/rishta-islamabad-rawalpindi/' ) . '">Islamabad &amp; Rawalpindi</a><a href="' . $u( '/rishta-faisalabad/' ) . '">Faisalabad</a><a href="' . $u( '/rishta-multan/' ) . '">Multan</a><a href="' . $u( '/rishta-peshawar-quetta/' ) . '">Peshawar &amp; Quetta</a></div>'
			. '<h2>Rishta for overseas Pakistanis</h2>'
			. '<div class="ct"><a href="' . $u( '/rishta-uae-pakistani-families/' ) . '">UAE and Dubai</a><a href="' . $u( '/rishta-saudi-arabia-pakistani-families/' ) . '">Saudi Arabia</a><a href="' . $u( '/rishta-uk-pakistani-families/' ) . '">United Kingdom</a><a href="' . $u( '/rishta-usa-pakistani-families/' ) . '">USA</a><a href="' . $u( '/rishta-canada-pakistani-families/' ) . '">Canada</a></div>'
			. '<h2>Safe and honest</h2>'
			. '<p>Fake profiles and fee scams are common in the rishta world. We never ask for money, and your phone number stays private. Look for the green tick explained on our <a href="' . $u( '/verification-badges/' ) . '">verification badges</a> page, read the <a href="' . $u( '/rishta-safety-tips-avoid-fake-profiles-scams/' ) . '">rishta safety tips</a>, <a href="' . $u( '/report-profile-misuse/' ) . '">report a profile or misuse</a> and the <a href="' . $u( '/public-notice-fake-accounts/' ) . '">public notice on fake accounts</a>. Looking for a marriage bureau instead? See our page on a <a href="' . $u( '/free-marriage-bureau-online-pakistan/' ) . '">free marriage bureau online</a>. You can also use the <a href="' . $u( '/app/' ) . '">My Rishta app</a> on your phone.</p>'
			. '<h2>Frequently asked questions</h2>' . $faq
			. '<script type="application/ld+json">' . str_replace( '</', '<\\/', wp_json_encode( $app, JSON_UNESCAPED_SLASHES ) ) . '</script>'
			. '</div></section>';
		$out = preg_replace( '#<section data-ppt-blockid="footer1"#', $box . '<section data-ppt-blockid="footer1"', $html, 1, $n );
		return ( is_string( $out ) && $n ) ? $out : $html;
	}

	/** Pages whose theme prints no H1 get a screen-reader-only one, so every page has exactly one. */
	public static function ensure_h1( $html ) {
		$path = (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH );
		$map  = array(
			'/contact/'     => 'Contact My Rishta Pakistan',
			'/blog/'        => 'Rishta Advice and Guides for Pakistani Families',
			'/add-listing/' => 'Create Your Free Rishta Profile',
		);
		if ( 0 === strpos( $path, '/category/' ) && ! isset( $map[ $path ] ) ) {
			$slug = trim( substr( $path, 10 ), '/' );
			if ( '' !== $slug && false === strpos( $slug, '/' ) ) {
				$map[ $path ] = ucwords( str_replace( '-', ' ', $slug ) ) . ': Articles and Advice from My Rishta Pakistan';
			}
		}
		if ( ! isset( $map[ $path ] ) || preg_match( '#<h1[\s>]#i', preg_replace( '#<script\b.*?</script>#is', '', $html ) ) ) {
			return $html;
		}
		$h1 = '<h1 style="position:absolute;width:1px;height:1px;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap">' . esc_html( $map[ $path ] ) . '</h1>';
		$out = preg_replace( '#(<body\b[^>]*>)#i', '$1' . $h1, $html, 1 );
		return is_string( $out ) ? $out : $html;
	}

	/** Loads the small flag-icon stylesheet without blocking the first paint (visitors only). */
	public static function async_flags( $html ) {
		if ( is_user_logged_in() || is_admin() ) {
			return $html;
		}
		$parts = preg_split( '#(<script\b.*?</script>)#is', $html, -1, PREG_SPLIT_DELIM_CAPTURE );
		if ( ! is_array( $parts ) ) {
			return $html;
		}
		$done = false;
		foreach ( $parts as $i => $part ) {
			if ( $done || 0 === stripos( $part, '<script' ) ) {
				continue;
			}
			$new = preg_replace_callback( '#<link\b[^>]*rel=["\']stylesheet["\'][^>]*css\.plugins-flag\.css[^>]*>#i', function ( $m ) {
				$t = $m[0];
				if ( false !== stripos( $t, 'onload' ) || false !== stripos( $t, 'media=' ) ) {
					return $t;
				}
				$a = preg_replace( '#\s*/?>$#', '', $t );
				return $a . ' media="print" onload="this.media=\'all\'">' . '<noscript>' . $t . '</noscript>';
			}, $part, 1, $count );
			if ( is_string( $new ) && $count ) {
				$parts[ $i ] = $new;
				$done = true;
			}
		}
		return implode( '', $parts );
	}

	/** Removes the user list from the REST API for visitors who are not logged in. */
	public static function hide_user_endpoints( $endpoints ) {
		if ( ! is_user_logged_in() && is_array( $endpoints ) ) {
			foreach ( array( '/wp/v2/users', '/wp/v2/users/(?P<id>[\\d]+)' ) as $r ) {
				unset( $endpoints[ $r ] );
			}
		}
		return $endpoints;
	}

	/** Footer links to the member-only category pages send visitors to the login page; point them at the public profiles page. */
	public static function fix_member_links( $html ) {
		if ( is_user_logged_in() || is_admin() ) {
			return $html;
		}
		$to  = home_url( '/latest-profiles/' );
		$out = preg_replace( '#https?://[^"\'\s<>]*?/listing-category/(?:married|unmarried)/?#i', $to, $html );
		return is_string( $out ) ? $out : $html;
	}

	public static function filter_inner( $html ) {
		if ( ! is_string( $html ) || false === stripos( $html, '<body' ) ) {
			return $html;
		}
		$o = MRSH_Options::get();
		if ( ! empty( $o['speed_unhide'] ) ) {
			$html = self::unhide( $html );
		}
		$html = self::strip_trackers( $html );
		$html = self::spelling( $html );
		$html = self::ensure_h1( $html );
		$html = self::home_about( $html );
		$html = self::async_flags( $html );
		$html = self::fix_member_links( $html );
		$html = self::tidy_head( $html );
		$html = self::clean_schema( $html );
		if ( ! empty( $o['speed_delay_ga'] ) ) {
			$html = self::delay_analytics( $html );
		}
		if ( ! empty( $o['speed_webp'] ) ) {
			$html = self::webp_swap( $html );
		}
		if ( ! empty( $o['speed_hero'] ) ) {
			$html = self::hero( $html );
		}
		if ( ! empty( $o['speed_fonts'] ) ) {
			$html = preg_replace( '/(https:\/\/fonts\.googleapis\.com\/css2?\?[^"\'\s>]*?)display=(auto|block|fallback|optional)/i', '$1display=swap', $html );
			$html = preg_replace( '/@font-face\s*\{(?![^}]*font-display)/i', '@font-face{font-display:swap;', $html );
		}
		if ( ! empty( $o['fix_access'] ) ) {
			$html = self::access( $html );
		}
		if ( self::$is_page ) {
			$html = self::h1( $html );
			if ( ! empty( $o['fix_access'] ) ) {
				$html = self::h2fix( $html );
			}
		} elseif ( self::$is_term ) {
			$html = self::h1_archive( $html );
		}
		if ( ! is_admin() ) {
			$html = self::lazy_bg( $html );
			$html = self::strip_blocks( $html );
			$html = MRSH_PK::direct_links( $html );
		}
		$mrt = 'myrishta' === get_option( 'template' );
		if ( ! empty( $o['org_footer'] ) && ! is_admin() && ! $mrt ) {
			$html = MRSH_PK::org_footer( $html );
		}
		if ( ! is_admin() && is_page( array( 'contact', 'top-listings', 'latest-profiles', 'success-stories' ) ) ) {
			$html = MRSH_PK::page_text( $html );
		}
		if ( ! empty( $o['pk_theme'] ) && ! is_admin() && ! $mrt ) {
			$html = MRSH_PK::filter( $html );
		}
		if ( empty( $o['speed_images'] ) ) {
			return $html;
		}
		$split = stripos( $html, '<body' );
		$head  = substr( $html, 0, $split );
		$body  = substr( $html, $split );
		$n     = 0;
		$keep  = max( 0, (int) $o['speed_eager_images'] );
		$body  = preg_replace_callback( '/<img\b[^>]*>/i', function ( $m ) use ( &$n, $keep, $o ) {
			$tag = $m[0];
			++$n;
			if ( ! empty( $o['speed_dimensions'] ) ) {
				$tag = self::add_size( $tag );
			}
			if ( false === stripos( $tag, ' decoding=' ) ) {
				$tag = preg_replace( '/<img\b/i', '<img decoding="async"', $tag, 1 );
			}
			if ( $n <= $keep ) {
				if ( false === stripos( $tag, 'fetchpriority=' ) && 1 === $n ) {
					$tag = preg_replace( '/<img\b/i', '<img fetchpriority="high"', $tag, 1 );
				}
				$tag = preg_replace( '/\sloading=(["\'])lazy\1/i', '', $tag );
			} elseif ( false === stripos( $tag, ' loading=' ) && false === stripos( $tag, 'data-lazy' ) ) {
				$tag = preg_replace( '/<img\b/i', '<img loading="lazy"', $tag, 1 );
			}
			return $tag;
		}, $body );
		return null === $body ? $html : $head . $body;
	}

	/** Add width and height to local images that lack them, so the page does not jump while loading. */
	public static function add_size( $tag ) {
		$has_w = (bool) preg_match( '/\swidth\s*=/i', $tag );
		$has_h = (bool) preg_match( '/\sheight\s*=/i', $tag );
		if ( $has_w && $has_h ) {
			return $tag;
		}
		if ( ! preg_match( '/\ssrc\s*=\s*(["\'])(.*?)\1/i', $tag, $m ) ) {
			return $tag;
		}
		$src = html_entity_decode( $m[2] );
		$up  = wp_get_upload_dir();
		if ( empty( $up['baseurl'] ) || 0 !== strpos( $src, $up['baseurl'] ) ) {
			return $tag;
		}
		$rel = strtok( substr( $src, strlen( $up['baseurl'] ) ), '?' );
		if ( false !== strpos( $rel, '..' ) || ! preg_match( '/\.(jpe?g|png|gif|webp|avif)$/i', $rel ) ) {
			return $tag;
		}
		$key  = 'mrsh_dim_' . md5( $rel );
		$dims = get_transient( $key );
		if ( false === $dims ) {
			$file = $up['basedir'] . $rel;
			$info = is_readable( $file ) ? @getimagesize( $file ) : false; // phpcs:ignore WordPress.PHP.NoSilencedErrors
			$dims = $info && $info[0] > 0 && $info[1] > 0 ? array( (int) $info[0], (int) $info[1] ) : array( 0, 0 );
			set_transient( $key, $dims, 30 * DAY_IN_SECONDS );
		}
		if ( empty( $dims[0] ) ) {
			return $tag;
		}
		$add = '';
		if ( ! $has_w && ! $has_h ) {
			$add = ' width="' . $dims[0] . '" height="' . $dims[1] . '"';
		} elseif ( $has_w && ! $has_h && preg_match( '/\swidth\s*=\s*["\']?(\d+)/i', $tag, $w ) && (int) $w[1] > 0 ) {
			$add = ' height="' . (int) round( $w[1] * $dims[1] / $dims[0] ) . '"';
		} elseif ( $has_h && ! $has_w && preg_match( '/\sheight\s*=\s*["\']?(\d+)/i', $tag, $h ) && (int) $h[1] > 0 ) {
			$add = ' width="' . (int) round( $h[1] * $dims[0] / $dims[1] ) . '"';
		}
		return '' === $add ? $tag : preg_replace( '/<img\b/i', '<img' . $add, $tag, 1 );
	}

	/** Pages that jump from H1 straight to H3 (card lists): make those H3 headings H2, keeping their look. */
	public static function h2fix( $html ) {
		$bp = stripos( $html, '<body' );
		if ( false === $bp ) {
			return $html;
		}
		$body = substr( $html, $bp );
		if ( preg_match( '/<h2\b/i', $body ) || preg_match_all( '/<h3\b/i', $body ) < 2 ) {
			return $html;
		}
		$out = preg_replace_callback( '/<h3\b([^>]*)>(.*?)<\/h3>/is', function ( $m ) {
			$a = $m[1];
			if ( preg_match( '/\sclass=(["\'])(.*?)\1/i', $a ) ) {
				$a = preg_replace( '/\sclass=(["\'])(.*?)\1/i', ' class="$2 h3"', $a, 1 );
			} else {
				$a .= ' class="h3"';
			}
			return '<h2' . $a . '>' . $m[2] . '</h2>';
		}, $body );
		return null === $out ? $html : substr( $html, 0, $bp ) . $out;
	}

	/**
	 * Pages built with page builders often have no H1. Promote the first H2 (keeping its look with
	 * the .h2 class), or add a screen-reader-only H1 with the page title, so every page has one.
	 */
	/** Category and tag pages: one heading with the archive name, hidden visually so the theme layout is unchanged. */
	public static function h1_archive( $html ) {
		$bp = stripos( $html, '<body' );
		if ( false === $bp || preg_match( '/<h1\b/i', substr( $html, $bp ) ) ) {
			return $html;
		}
		$name = '' !== self::$term ? self::$term : single_term_title( '', false );
		if ( '' === trim( (string) $name ) ) {
			return $html;
		}
		$r = preg_replace( '/<body\b[^>]*>/i', '$0<h1 style="position:absolute;left:-9999px;top:auto;width:1px;height:1px;overflow:hidden">' . esc_html( $name ) . ' | Rishta Guides</h1>', $html, 1 );
		return null === $r ? $html : $r;
	}

	public static function h1( $html ) {
		$bp = stripos( $html, '<body' );
		if ( false === $bp || preg_match( '/<h1\b/i', substr( $html, $bp ) ) ) {
			return $html;
		}
		$n = 0;
		$out = null;
		// Listing pages (blog index): the first H2 is a post card, so use a hidden page-title H1 instead.
		if ( false === stripos( substr( $html, $bp, 600 ), 'tpl-page-blog' ) ) {
		$out = preg_replace_callback( '/<h2\b([^>]*)>(.*?)<\/h2>/is', function ( $m ) {
			$attrs = $m[1];
			if ( preg_match( '/\sclass=(["\'])(.*?)\1/i', $attrs ) ) {
				$attrs = preg_replace( '/\sclass=(["\'])(.*?)\1/i', ' class="$2 h2"', $attrs, 1 );
			} else {
				$attrs .= ' class="h2"';
			}
			return '<h1' . $attrs . '>' . $m[2] . '</h1>';
		}, substr( $html, $bp ), 1, $n );
		}
		if ( $n && null !== $out ) {
			return substr( $html, 0, $bp ) . $out;
		}
		$title = '' !== self::$title ? self::$title : get_the_title();
		if ( '' === trim( $title ) ) {
			return $html;
		}
		$r = preg_replace( '/<body\b[^>]*>/i', '$0<h1 style="position:absolute;left:-9999px;top:auto;width:1px;height:1px;overflow:hidden">' . esc_html( $title ) . '</h1>', $html, 1 );
		return null === $r ? $html : $r;
	}

	/** Names for icon-only links and empty headings (accessibility and SEO audits). */
	public static function access( $html ) {
		$names = array( 'facebook' => 'Facebook', 'fb.com' => 'Facebook', 'twitter' => 'Twitter', 'x.com' => 'X', 'instagram' => 'Instagram', 'youtube' => 'YouTube', 'whatsapp' => 'WhatsApp', 'wa.me' => 'WhatsApp', 'tiktok' => 'TikTok', 'linkedin' => 'LinkedIn', 'pinterest' => 'Pinterest', 'telegram' => 'Telegram', 'snapchat' => 'Snapchat', 'tel:' => 'Call us', 'mailto:' => 'Email us' );
		$out   = preg_replace_callback( '/<a\b([^>]*)>(.*?)<\/a>/is', function ( $m ) use ( $names ) {
			$attrs = $m[1];
			if ( preg_match( '/\saria-label\s*=/i', $attrs ) || preg_match( '/\saria-labelledby\s*=/i', $attrs ) ) {
				return $m[0];
			}
			$inner = $m[2];
			if ( '' !== trim( html_entity_decode( strip_tags( preg_replace( '/<(?:svg|style|script)\b.*?<\/(?:svg|style|script)>/is', '', $inner ) ) ), " \t\n\r\xC2\xA0" ) ) {
				return $m[0];
			}
			if ( preg_match( '/<img\b[^>]*\salt\s*=\s*["\'][^"\']+["\']/i', $inner ) ) {
				return $m[0];
			}
			$label = '';
			if ( preg_match( '/\stitle\s*=\s*(["\'])(.*?)\1/i', $attrs, $t ) && '' !== trim( $t[2] ) ) {
				$label = $t[2];
			} else {
				$probe = strtolower( $attrs . ' ' . $inner );
				foreach ( $names as $needle => $name ) {
					if ( false !== strpos( $probe, $needle ) ) {
						$label = $name;
						break;
					}
				}
			}
			if ( '' === $label ) {
				if ( false !== stripos( $attrs, 'processLanguages' ) ) {
					$label = 'Change language';
				} elseif ( preg_match( '#href=["\'][^"\']*/listing/#i', $attrs ) ) {
					$label = 'View profile';
				} elseif ( preg_match( '#href=["\'][^"\']*/add-listing#i', $attrs ) || false !== stripos( $attrs, 'menu-add' ) ) {
					$label = 'Add profile';
				} elseif ( false !== stripos( $attrs, 'dropdown-toggle' ) ) {
					$label = 'Open menu';
				} elseif ( false !== stripos( $attrs, 'processLogin' ) ) {
					$label = 'Log in';
				}
			}
			if ( '' === $label ) {
				return $m[0];
			}
			return '<a' . $attrs . ' aria-label="' . esc_attr( $label ) . '">' . $inner . '</a>';
		}, $html );
		$html = null === $out ? $html : $out;
		// Script-only links become crawlable anchors; the click still runs the original handler.
		$out = preg_replace( '/href=(["\'])javascript:void\(0\);?\1/i', 'href="#" data-mrsh-js="1"', $html, -1, $jc );
		if ( $jc && null !== $out ) {
			$html = $out;
		}
		$extra = '<style id="mrsh-a11y">.button-featured-new{background-color:#c8080f!important;color:#fff!important}a.opacity-8{text-decoration:underline}.button-featured.bg-primary{background-color:#12766f!important;color:#fff!important}a[class^=icon-][target=_blank]{display:inline-block;min-width:24px;min-height:24px;padding:4px;box-sizing:content-box}</style>';
		if ( $jc ) {
			$extra .= '<script>document.addEventListener("click",function(e){var a=e.target.closest&&e.target.closest("a[data-mrsh-js]");if(a)e.preventDefault();});</script>';
		}
		$bp = strripos( $html, '</body>' );
		if ( false !== $bp ) {
			$html = substr( $html, 0, $bp ) . $extra . substr( $html, $bp );
		}
		// Headings with no text become plain blocks so audits stop reporting empty headings.
		$out = preg_replace_callback( '/<(h[1-6])\b([^>]*)>(.*?)<\/\1>/is', function ( $m ) {
			$text = trim( html_entity_decode( strip_tags( $m[3] ) ), " \t\n\r\xC2\xA0#" );
			if ( '' === $text && false === stripos( $m[3], '<img' ) && false === stripos( $m[3], '<svg' ) ) {
				return '<div' . $m[2] . '>' . $m[3] . '</div>';
			}
			return $m[0];
		}, $html );
		return null === $out ? $html : $out;
	}
}
