<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** "Report this profile": a safe, rate-limited form for the website and the app. Goes to the site admin by email and is kept in a short log. */
class MRSH_Report {

	const LOG = 'mrsh_reports';

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( 'wp_footer', array( __CLASS__, 'button' ), 30 );
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
	}

	public static function routes() {
		register_rest_route( 'mrsh/v1', '/report', array(
			'methods'             => 'POST',
			'permission_callback' => '__return_true',
			'callback'            => array( __CLASS__, 'handle' ),
		) );
	}

	private static $REASONS = array( 'fake' => 'Fake or false profile', 'photo' => 'Photo is not theirs', 'scam' => 'Asking for money / scam', 'abuse' => 'Rude or abusive behaviour', 'married' => 'Already married / not genuine', 'other' => 'Something else' );

	public static function handle( WP_REST_Request $r ) {
		$id     = (int) $r->get_param( 'id' );
		$reason = sanitize_key( (string) $r->get_param( 'reason' ) );
		$note   = mb_substr( sanitize_textarea_field( (string) $r->get_param( 'note' ) ), 0, 500 );
		if ( '' !== (string) $r->get_param( 'website' ) ) { // hidden trap field for bots
			return array( 'ok' => true );
		}
		$p = $id ? get_post( $id ) : null;
		if ( ! $p || 'listing_type' !== $p->post_type || ! isset( self::$REASONS[ $reason ] ) ) {
			return new WP_REST_Response( array( 'ok' => false, 'error' => 'Please choose a reason.' ), 400 );
		}
		$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '';
		$key = 'mrsh_rp_' . md5( $ip );
		$n   = (int) get_transient( $key );
		if ( $n >= 5 ) {
			return new WP_REST_Response( array( 'ok' => false, 'error' => 'Too many reports from this connection. Please try again later.' ), 429 );
		}
		set_transient( $key, $n + 1, HOUR_IN_SECONDS );
		$log   = get_option( self::LOG, array() );
		$log   = is_array( $log ) ? $log : array();
		array_unshift( $log, array( 'time' => time(), 'id' => $id, 'title' => get_the_title( $p ), 'reason' => $reason, 'note' => $note ) );
		update_option( self::LOG, array_slice( $log, 0, 200 ), false );
		wp_mail( get_option( 'admin_email' ), 'Profile report: ' . get_the_title( $p ), "Reason: " . self::$REASONS[ $reason ] . "\nNote: " . $note . "\nProfile: " . get_permalink( $p ) . "\nEdit: " . admin_url( 'post.php?post=' . $id . '&action=edit' ) );
		return array( 'ok' => true );
	}

	/** A small button on every profile page of the website. */
	public static function button() {
		if ( ! is_singular( 'listing_type' ) ) {
			return;
		}
		$id  = (int) get_the_ID();
		$url = esc_url_raw( rest_url( 'mrsh/v1/report' ) );
		$opt = '';
		foreach ( self::$REASONS as $k => $v ) {
			$opt .= '<option value="' . esc_attr( $k ) . '">' . esc_html( $v ) . '</option>';
		}
		?>
<button type="button" id="mrsh-rp-b" aria-label="Report this profile" title="Report this profile · رپورٹ کریں" style="position:fixed;left:0;top:38%;z-index:9998;background:#fff;color:#8a1c1c;border:1px solid #8a1c1c;border-left:0;border-radius:0 12px 12px 0;width:24px;height:38px;opacity:.85;padding:0;font-size:15px;line-height:1;box-shadow:0 2px 8px rgba(0,0,0,.2)">&#9873;</button>
<div id="mrsh-rp" hidden style="position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.55);display:none;align-items:center;justify-content:center;padding:16px">
<form style="background:#fff;color:#111;border-radius:14px;padding:18px;max-width:360px;width:100%;font-size:15px">
<b>Report this profile</b><p style="margin:6px 0 10px;font-size:13px">Tell us what is wrong. Our team will review it. Your report is private.</p>
<select name="reason" required style="width:100%;padding:8px;margin-bottom:8px"><option value="">Choose a reason</option><?php echo $opt; // phpcs:ignore ?></select>
<textarea name="note" maxlength="500" rows="3" placeholder="Details (optional)" style="width:100%;padding:8px"></textarea>
<input name="website" tabindex="-1" autocomplete="off" style="position:absolute;left:-9999px">
<div style="display:flex;gap:8px;margin-top:10px"><button type="submit" style="flex:1;padding:10px;background:#8a1c1c;color:#fff;border:0;border-radius:8px">Send report</button><button type="button" id="mrsh-rp-x" style="padding:10px;border:1px solid #999;border-radius:8px;background:#fff">Cancel</button></div>
<p id="mrsh-rp-m" style="margin:8px 0 0;font-size:13px"></p></form></div>
<script>(function(){var b=document.getElementById('mrsh-rp-b'),m=document.getElementById('mrsh-rp'),f=m.querySelector('form'),s=document.getElementById('mrsh-rp-m');
b.onclick=function(){m.style.display='flex'};document.getElementById('mrsh-rp-x').onclick=function(){m.style.display='none'};
f.onsubmit=function(e){e.preventDefault();s.textContent='Sending…';fetch(<?php echo wp_json_encode( $url ); ?>,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:<?php echo (int) $id; ?>,reason:f.reason.value,note:f.note.value,website:f.website.value})}).then(function(r){return r.json()}).then(function(j){s.textContent=j.ok?'Thank you. We will review this profile.':(j.error||'Could not send.');if(j.ok)setTimeout(function(){m.style.display='none'},1800)}).catch(function(){s.textContent='Could not send. Try again.'})};})();</script>
		<?php
	}

	public static function menu() {
		add_management_page( 'Profile reports', 'Profile reports', 'manage_options', 'mrsh-reports', array( __CLASS__, 'page' ) );
	}

	public static function page() {
		$log = get_option( self::LOG, array() );
		echo '<div class="wrap"><h1>Profile reports</h1>';
		if ( ! $log ) {
			echo '<p>No reports yet.</p></div>';
			return;
		}
		echo '<table class="widefat striped"><thead><tr><th>When</th><th>Profile</th><th>Reason</th><th>Note</th></tr></thead><tbody>';
		foreach ( $log as $r ) {
			echo '<tr><td>' . esc_html( wp_date( 'Y-m-d H:i', $r['time'] ) ) . '</td><td><a href="' . esc_url( get_edit_post_link( $r['id'] ) ) . '">' . esc_html( $r['title'] ) . '</a></td><td>' . esc_html( isset( self::$REASONS[ $r['reason'] ] ) ? self::$REASONS[ $r['reason'] ] : $r['reason'] ) . '</td><td>' . esc_html( $r['note'] ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
	}
}
